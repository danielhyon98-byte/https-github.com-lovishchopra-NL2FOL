early checkpoint: agents were still editing; work in progress not captured
