export const meta = {
  name: 'translator-optimization-once',
  description: 'One optimisation pass on the translator infrastructure: a strongest-tier overseer runs the optimisation tests once (per-transfer cost on every recorded round, profiling, input-size scaling, several agents on one task; no stress testing of any model) and reports optimisation issues with measured evidence; if there are any, one strongest-tier fix round, verified (suite green, replay counts not lower), committed and pushed',
  whenToUse: 'A single optimisation test and fix pass requested by the founder',
  phases: [
    { title: 'Test', detail: 'optimisation tests, run once, judged by an overseer' },
    { title: 'Fix', detail: 'one optimisation fix round if issues were found' },
    { title: 'Verify', detail: 'suite, replays, before/after measurement, commit and push' },
  ],
}

const REPO = '/home/user/https-github.com-lovishchopra-NL2FOL'
const S = '/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad'
const PY = S + '/z3venv/bin/python -I'
const ARENA = S + '/arena'
const CLR = S + '/clearance'
const OPT = S + '/optimization'
const BRANCH = 'claude/z3-verification-engine-plan-nk3luq'
const ATTR = 'Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>\nClaude-Session: https://claude.ai/code/session_016YotQwcC83EEJm8zshdxtW'
const CTX = `INFRASTRUCTURE (code, not an agent): the Epinoic code logic translator at ${REPO} (package epinoic_logic, branch ${BRANCH}); it converts specialist agents' English outputs into logical code (IR the Z3 engine decides) so that no miscommunication passes between agents. Python: ${PY} (editable install of ${REPO}/src). Tests: cd ${REPO} && ${PY} -m pytest -q -p no:cacheprovider. Arena tools: ${PY} ${REPO}/scripts/arena/run_arena.py <round_dir>, list_claims.py, relay_peer.py (read their docstrings). Recorded rounds: ${ARENA}/r1, r1-adv, r2 ... the highest r<N> present.
SAFETY (repository CLAUDE.md): the IR is data, never eval/exec agent text; consistency before entailment; non-success statuses never shown as success; never weaken or delete tests; no model names or session ids in code or docs. FOUNDER'S RULE: no stress testing of any model and no stress tests after bug fixes; the optimisation tests below measure the infrastructure's own efficiency and its behaviour with several agents on one task, once.`

const STR = { type: 'string' }
const STRS = { type: 'array', items: STR }
const ISSUE = { type: 'object', properties: { severity: { type: 'string', enum: ['major', 'minor'] }, file: STR, summary: STR, evidence: STR, expected_gain: STR, fix: STR }, required: ['severity', 'file', 'summary', 'evidence', 'fix'] }
const TEST_SCHEMA = { type: 'object', properties: { head: STR, measurements: STR, issues: { type: 'array', items: ISSUE } }, required: ['head', 'measurements', 'issues'] }
const FIX_SCHEMA = { type: 'object', properties: { fixed: { type: 'array', items: { type: 'object', properties: { issue: STR, change: STR, test: STR }, required: ['issue', 'change'] } }, left_undone: STRS }, required: ['fixed', 'left_undone'] }
const VERIFY_SCHEMA = { type: 'object', properties: { suite_passed: { type: 'boolean' }, suite_tail: STR, harness_line: STR, harness_dropped: { type: 'boolean' }, harness_detail: STR, before_after: STR }, required: ['suite_passed', 'suite_tail', 'harness_line', 'harness_dropped', 'before_after'] }
const COMMIT_SCHEMA = { type: 'object', properties: { committed: { type: 'boolean' }, pushed: { type: 'boolean' }, sha: STR, reverted: { type: 'boolean' }, patch: STR }, required: ['committed', 'pushed'] }

// ================================================================== Test
phase('Test')
const test = await agent(`${CTX}
You are the OVERSEER of an optimisation test, run ONCE. Work in ${OPT}/test/ (mkdir -p); do not modify anything under ${REPO}. First confirm git -C ${REPO} status --short is empty and record git -C ${REPO} rev-parse HEAD.
Measure, on the current code:
1. Per-transfer cost through RouterHub for every recorded arena round (replay each round's specialist answers, relays and syntheses sequentially, as run_arena.py does, without its mutations): p50, p95 and worst per transfer, per round, and the share of time in each stage (parsing, packs, formal checks, engine, integrity, ledger, cross-agent consistency). Use cProfile on the five slowest transfers and name the hot functions.
2. Input-size scaling of the hub on one real answer repeated to 1x, 4x, 16x and 64x length: time per transfer should grow about linearly; report the measured growth.
3. Several agents on one task: one task whose reports come from 2, 4, 8 and 16 agents (copies of real answers from the recorded rounds, as duplicated agents would give): time per transfer, cross-agent consistency time and memory as the number of agents grows.
4. Repeated work: anything computed again and again for the same input (same supplied text normalised repeatedly, the same engine problem decided twice, the same claims re-parsed).
Then, as the overseer, report every OPTIMISATION ISSUE you found with measured evidence (the numbers, the profile lines), its expected gain and a concrete fix; major = a cost that grows faster than linearly, a hot path taking more than a third of transfer time with an avoidable cause, or a repeated decision worth more than 20% of time; minor otherwise. Report only real issues; correctness bugs are out of scope unless they cost time. Write your report, exactly the JSON you return, to ${OPT}/test/report.json.`, { label: 'optimization:test', phase: 'Test', schema: TEST_SCHEMA })

if (!test) { log('optimisation test produced no report'); return { test: null } }
log(`optimisation test on ${test.head}: ${test.issues.length} issues (${test.issues.filter(i => i.severity === 'major').length} major)`)
if (!test.issues.length) return { test, fixed: null, note: 'no optimisation issues found; no fix run' }

// ================================================================== Fix (one round)
phase('Fix')
const fix = await agent(`${CTX}
You are the OPTIMISATION FIXER, one round only. The overseer's optimisation test (${OPT}/test/report.json) found these issues:
${JSON.stringify(test.issues, null, 1)}
Fix them, majors first, without changing any result: every receipt, finding, status and engine verdict must stay exactly the same on every recorded round (compare run_arena.py results.json before and after on copies of the rounds under ${OPT}/fix/). Prefer caching keyed by content digests, linear algorithms and avoiding repeated engine calls for identical problems. Add tests that pin each optimisation's behaviour (same outputs; bounded work). Never weaken or delete a test. Do not commit or push. Return what you changed per issue and anything left undone.`, { label: 'optimization:fix', phase: 'Fix', schema: FIX_SCHEMA })

// ================================================================== Verify
phase('Verify')
const v = await agent(`${CTX}
Verification only; do not modify source files. (1) cd ${REPO} && ${PY} -m pytest -q -p no:cacheprovider 2>&1 | tail -15 ; suite_passed only with 0 failed and 0 errors. (2) Run the harness on every recorded arena round and give harness_line as "r1 a/b, r1-adv a/b, r2 a/b, ..."; compare with the "Harness after the change:" line of the most recent non-WIP commit on ${BRANCH}; harness_dropped if any round is lower now (harness_detail names it). (3) Re-run exactly the measurements of ${OPT}/test/report.json that the fix targeted and give before_after (measured numbers). Return the result.`, { label: 'optimization:verify', phase: 'Verify', schema: VERIFY_SCHEMA, effort: 'medium' })
const green = !!(v && v.suite_passed && !v.harness_dropped)
const lines = fix ? fix.fixed.map(f => '- ' + f.issue.slice(0, 160) + ': ' + f.change.slice(0, 240)).join('\n') : '(no fix result)'
const msg = `Fix the optimization findings\n\nOne optimisation test pass judged by an overseer found ${test.issues.length} issue(s) (${test.issues.filter(i => i.severity === 'major').length} major); one fix round:\n${lines}\nBefore and after: ${v ? v.before_after.slice(0, 1500) : 'unavailable'}\nLeft undone: ${fix ? fix.left_undone.join('; ').slice(0, 1000) : ''}\n\nHarness after the change: ${v ? v.harness_line : 'unavailable'}. Suite: ${v ? v.suite_tail.split('\n').slice(-1)[0] : 'unavailable'}\n\n${ATTR}`
const c = await agent(green
  ? `In ${REPO} on branch ${BRANCH}: git add -A and commit with git -c user.name=Claude -c user.email=noreply@anthropic.com commit -q -F <a file you write in ${S}/optimization-msg.txt> whose content is exactly:\n---\n${msg}\n---\n(without the --- lines); then git push -u origin ${BRANCH} (retry up to 4 times on network errors only; never force). Return committed, pushed and the sha.`
  : `The optimisation fix in ${REPO} did NOT verify (suite: ${v ? v.suite_tail.split('\n').slice(-1)[0] : 'unavailable'}; harness drop: ${v ? v.harness_detail : 'unknown'}). Preserve it and restore the verified tree: write git -C ${REPO} diff --binary HEAD to ${OPT}/rejected-fix.patch, copy every untracked file listed by git -C ${REPO} status --porcelain into ${OPT}/rejected-untracked/ keeping paths, then git -C ${REPO} checkout -- . and remove exactly those untracked files. Confirm git status is clean. Do not commit. Return committed=false, pushed=false, reverted=true and the patch path.`,
  { label: 'optimization:commit', phase: 'Verify', schema: COMMIT_SCHEMA, effort: 'low' })
log(`optimisation fix: ${green ? 'verified and committed ' + (c ? c.sha : '') : 'not verified; reverted and kept as a patch'}`)
return { test: { head: test.head, issues: test.issues.length, majors: test.issues.filter(i => i.severity === 'major').length }, fix: fix ? { fixed: fix.fixed.length, undone: fix.left_undone } : null, verified: green, before_after: v ? v.before_after : null, commit: c }
