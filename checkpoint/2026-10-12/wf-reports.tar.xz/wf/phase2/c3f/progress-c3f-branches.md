# progress c3f branches

- started; nothing done yet
- step 1 (done): read push check, lenses (filtered to wf/phase2/c3f/br_lens_items.txt), c3e-left (wf/phase2/c3f/br_c3e_left.txt)
- probe: wf/phase2/c3f/branches/probe.py items1.tsv reproduces items 1-4 (all still open on tree)
- step 2 (in progress): rewrite geography._yt_named_row (own clause, main-subject fallback, modifier+head row naming, linear precompute)
