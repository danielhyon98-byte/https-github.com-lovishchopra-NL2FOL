# progress c3f channel
- started fresh; working tree clean at 6847812b

- P1 done (code): INSTEAD_OF_WORDS in markdown, roles replaces_next, own_text _PHRASE_AFTER_RE/_REPLACED_GAP_RE; tests TODO
- next: P2 frames list ll-t16 (feedback only)
