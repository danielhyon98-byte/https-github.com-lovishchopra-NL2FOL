# repair clearance-c3f-1 progress
- started: profiling test_a_long_run_of_check_marks_is_read_in_linear_time
- DONE: profiled. WT 1.9 s CPU vs HEAD 1.45 s on '✓'*20000 (HEAD export in c3f/head-r1). Cause: per-mark scans of the whole
  clause/sentence in selfcert/reader.py _clause_found_bounded (own = any(... for x in toks) per mark, HEAD too), plus new
  _pair_site linear lookup and _example_mark_line slicing sent[:k] per mark.
- DONE: edited selfcert/reader.py: own computed once per clause; _pair_site index dict built once; pair lookup skipped when no cross;
  _example_mark_line stops at the first word before the mark. WT now ~1.0 s CPU.
- NEXT: linearity check, run failing test alone x3, test file, selfcert tests, self-certification tests.
- DONE: removed the no-cross guard (strict equivalence); _pair_site uses the per-clause index. Linear: '✓'*N 0.12/0.23/0.61/1.00/2.29 s
  CPU at 2.5k..40k (HEAD 0.29/0.58/0.73/1.39/3.12). Failing test passes alone 3x; tests/adapters/test_verification_labels.py 127 passed.
- IN PROGRESS: tests/selfcert (log c3f/r1_selfcert.log), tests/adapters (log c3f/r1_adapters.log); then hygiene test.
- DONE: tests/selfcert: 4560 passed in 332.95s (0:05:32); tests/adapters: 1235 passed in 927.27s (0:15:27); hygiene 8 passed.
- IN PROGRESS: tests/branches + tests/channel (log c3f/r1_branches.log).
- DONE: tests/branches + tests/channel 12739 passed, 1 skipped (recorded rounds env not set). Task complete; nothing committed.
