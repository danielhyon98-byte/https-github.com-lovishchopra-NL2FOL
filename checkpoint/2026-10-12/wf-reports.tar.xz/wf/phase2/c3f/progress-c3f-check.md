# progress-c3f-check (check fixer, follow-up 4)
Started fresh (no earlier progress file). Base: HEAD 87dcd0af + c3f fixers' uncommitted edits (24 M, 4 new).
Probe dir: wf/phase2/c3f/check (bprobe.py <tsv> = appended-sentence branch probe; g1/g2/g3.tsv)
## Done (uncommitted, geography.py / chronology.py)
- geography _table_change_by: stall (period search once), band -> printed-cell difference (half of stated)
- _YtIndex: 'X and <non-row word>' no modifier naming (share and supplied); subject span ignores numbers in apposition; opening year 'In 2025 ...'
- _table_column_change: every change (finditer), own clause column (_column_change_at)
- attr table cell column: no column after a clause cut; own clause column before (site 4 pedestrian 97)
- per capita: 'per person, 1,050 PJ shared among 24.9 million' swaps total/figure
- chronology: fronted cue after 'and,' orders the next clause's event (after coal declined FP)
## Next
ledger INT-LEDGER-029 / selfcert G8 'flags as from memory'; selfcert FPs; overseer patches (ll-t16); OVS-FID-009 tick pair; LB FPs; misses; tests; timing
- DONE selfcert: ownverdict _governs (negator governs crit; 'without' own complement); reader _neg_count brackets; motion pass (meaning);
  attributive 'accepted value' (reader _REFERENCE_*); grammar-noun mention (meaning _mention_quote + window 10); example tick
  (_example_mark_key/_example_mark_line/line_rest/example_mark_at + meaning content_free); dated 'underwent review' (meaning regex);
  attributive adj not an act (ownverdict); tick pair cut at tick (reader mark rule + _runon_breaks zzmark words);
  self_report.mask_outside_quotations no double blank (gloss FID-005)
- e2e probe: check/e2e.py 'text' [subjects] [x]
NEXT: overseer patch pair (ll-t16), LB/geo misses, selfcert misses, tests, timing
- DONE: overseer patch pair applied (api 1.4 + fidelity correction-role + test_c3f_correction_role); own_text 'You wrote X; write Y' frame;
  markdown Spanish imperatives; language_b elided noun + hoy present + population synonyms; geography from-to pct years, clock peak/worked times
- DONE selfcert misses (all 39 named now gated; dev 0 wrong; genuine c1-c3 = HEAD): runon ')'+Capital; misspelt ')' window + 'Al';
  meaning performative after fronted 'After'; worked keys (wide words, answer/evaluator key, denied defect, _credited_lead, concord);
  ownverdict extras (scope extra, tool result, score label, beyond question, came through, praise, experts, control, line-break join)
- tests/branches run #1 in background -> check/t_branches1.txt (started before selfcert misses)
NEXT: test file tests/selfcert/test_c3f_check_round12.py + tests/branches/test_c3f_check_round12.py; run tests/selfcert, branches, overseer, channel; timing
- DONE: ge-p9c request-figure FPs (_not_the_requests_object: part area, request's own figure in sentence, other object's dimension);
  sp-t16 count clause concepts; test_d9d10_recorded ge-t15 pin +2 ENTAILED (stricter); test_c3f_check subjunctive pin rewritten
  (free outside marking per round 12; near twins gated)
- tests: tests/selfcert all pass; tests/branches 10033 passed + 1 (pin updated) before latest geo/lb edits
- NEW tests: tests/selfcert/test_c3f_check_round12.py (94), tests/branches/test_c3f_check_round12.py (56)
NEXT: version bump assessment; overseer/channel/integrity/adapters targeted runs; timing; remaining branch misses
- DONE: _AREA_UNITS name clash fixed (_FACT_AREA_UNITS; had broken density -> 15 branch failures); selfcert rules_closure/digest memo by stored state (cold identity 1 s -> 0.01 s)
- timing set (69 files) under branches load: 3542 passed, 1 failed: adapters_history r5 bracket-heavy History 2.6s/2.0 (HEAD same ~1.4-1.9 alone: pre-existing low headroom)
- RUNNING: tests/branches #3 (t_branches3.txt) + validation dirs (t_val1.txt)
## Run 2 (resumed 09:57; previous run interrupted; tests/branches #3 had stopped at 74%)
- re-verified on tree: all 39 selfcert misses True, all named FPs False, dev 0 wrong, ctl ok; ledger r1 hi-t2 []; e2e tick pair/gloss/10%/subjunctive 15/15 delivered
- branch probes (check/all.out, rest.tsv): geo regressions + wrong ENTAILED fixed; remaining = misses failing open (ge-t14 row diff/multiple, ge-t16, ge-p9c request facts, LB speakers/counts/English restatements)
- run2: added geography _row_pair_comparison (ge-t14 row diff/multiple) + _TIMES_OF_RE (ge-t16 160 times); tests/branches #4 running (t_branches4.txt, started before these edits)
