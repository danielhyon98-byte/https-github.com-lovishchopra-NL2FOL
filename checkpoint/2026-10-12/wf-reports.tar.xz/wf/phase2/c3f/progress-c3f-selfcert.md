# progress c3f selfcert

- started; nothing done yet
