# progress c3f selfcert (fixer "selfcert")

Probe: scratchpad wf/phase2/c3f/selfcert-probe/{items.py,run.py} (run.py [group]); challenger reader probe copies there too.

Done (uncommitted, in working tree):
- 1a tick pair: reader._tick_of_correction_pair restricted to quoted or prose-of-language halves (_pair_half/_quoted_half/_prose_half);
  pair read in sentence when clause cut (_pair_site); _runon_breaks keeps cross..tick pair whole (_PAIR_CROSSES).
- 1b worked key: _computation_verdict_key (the/this + singular computation noun), _neutral_check_key, _key_verdict_word,
  X1 keeps own_key/_wide_verdict findings; _gate key_verdict; label branch gates wide verdict keys over computation;
  _percent_of + '·' in _OPS (25 % de 80 = 20 ✓, Prueba: ... 2 · 2 = 4 free); meaning frame (6) excludes wide/part keys.
In progress: running tests/selfcert after 1a/1b.
Next: 1c ownverdict fail-open (clauses/windows, '?' only frees its clause), 2 misses, 3 over-blocks, 5 policy identity, tests, timing.
- (step 2) 1c done: ownverdict.clause_pieces/read_by_clauses (question frees only its span; coordinated clauses; 400-char windows),
  meaning._own_verdict_c3d wraps it, own-verdict calls moved before the 400-token bound, _frame_cue no 2000 bound;
  meaning._clause_parts reads coordinated clauses (_coordinated_clauses), statement after '?', windows over 400 tokens.
- (step 2) item 2 misses: ownverdict new frames (_SUPPORT_RE give/sign-off idioms, _NOUN_ACT_RE, _DELIVERY_RE, _COMPARED_RE,
  _PERFORMATIVE_RE, _QUANT_SCOPE_RE, _WANT_RE, _QUALITY_LABEL_RE, _TOOL_SAME_RE, _WORD_APPLIES_RE, deductions);
  lexicon fuzzy target 'everything'; misspelt _WHOLE_SUBJECTS, 5-letter prefix, misspelt prefix of lexicon compound.
- test_c3e_repair_linear tick test rewritten stricter (implication + fixed values).
Remaining: 'No:/Wrong: the answer is verified.'; item 3 over-blocks; item 5 identity; tests; timing; dev sets/genuine.
- (step 3) item 2/3 all probe items pass (0 wrong of 339): gloss frames other languages (+G9 clear for short gloss), emphasis pairs
  via original line, correction-imperative key, rejected-form bracket (_REJECTED_BRACKET_RE in _quoted_then_label, pair_bracket in
  review, _REJECTED_FORM_RE in right-key alone frame), quality-noun heading (Validity:), census as m_ref + M2 reference agreement,
  short label key splits polarity segments (No:/Wrong: the answer is verified).
Next: subjunctive decision pin; run tests/selfcert; dev sets & genuine clearance; e2e paths; item 5; timing.
- (step 4) item 5 done: selfcert/__init__.py rules_closure() (AST import closure of package + RULE_APPLICATION_CODE, parent inits),
  rules_external_code(), rules_digest over closure; RULES_EXTERNAL_CODE removed; stale comments fixed (identity.py, eligibility.py).
  test_c3e_check section 4 rewritten stricter; new tests/selfcert/test_c3f_check.py (228 passed).
  NOT bumped SELFCERT_RULES/POLICY_VERSION (version.py, kit, tests/contract pins not mine) -> left_undone.
- language form after corrected key (meaning._language_form); Spanish B emphasis pair delivered.
Next: full tests/selfcert, related dirs, dev sets/genuine clearance, timing tests.
- (step 5) genuine c1-c3 delivery equals HEAD (gated only c2/bi-p9b, c2/sp-t15, pre-existing) after: writer check key ('I checked
  this by hand:'), 'Working:' heading not a verdict key. Regressions fixed: census moved from lexicon m_ref to
  meaning._DATA_SOURCE_HEADS (lexicon.json restored to HEAD); anaphoric coordinated clause skipped; negative-key ':' split only
  before a clause. Next: rerun tests/selfcert, overseer selfcert tests, gate2 parsers, timing.
- (step 6) e2e probe (selfcert-probe/e2e_out.json): all named positives NC 0/15, router 0/5, comb refused; negatives NC 15/15,
  router 5/5. Pre-existing: unquoted '✗ Ella es cansada ✓ Ella está cansada' withheld on 11/15 NC via OVS-FID-009 (claim text loses
  the cross; same at HEAD) -> left_undone. 'The manuscript underwent a peer review in 1950.' gated at HEAD too -> left_undone.
Next: timing run (tests/branches concurrently) with the wall-clock test set.
