# Handoff from the core fixer (round-9 clearance, second fix pass c2b)

Owner of this note: core (`src/epinoic_logic/channel/**`, `integrity/**`, `translate/**`, `engine/**`, `ir/**`, `service/**`,
`cli.py` and their tests). Everything below needs a change outside those paths. Each item names the finding, the file and
function, what to change and the test that shows it. Evidence was measured on the working tree of 13 Nov (every owner's
first-pass edits included); the recorded material is in `tests/channel/data/c2_core_material.json` and
`tests/channel/data/c2b_core_material.json`.

## 1. Overseer: an evaded revision must not end `done` (push check of c4f276c, major)

- The channel side is done in this pass: `channel/feedback.preservation_findings` now names a claim the revision request
  named when the revision WEAKENS it instead of correcting it (made approximate, turned into a range, hedged, its
  calculation's relation dropped): INT-REV-002, warning, message "claims [...] that the revision request named are weakened
  instead of corrected: the statement the flaw names is made approximate (...) / is turned into a range (...) / is hedged
  (..., or the certainty of claims lowered) / is no longer stated as a calculation (...)". Each wording contains one of the
  substrings of `overseer/src/epinoic_overseer/feedback.py::_WEAKENING`, so `revision_outcome` already reads these claims as
  weakened. Tests: `tests/channel/test_c2b_clearance_core.py` (PH_BAD's s1.2 turned into "a is about 6 m s⁻²" carries
  "is made approximate" and "is no longer stated", both naming s1.2; the corrected revision carries no INT-REV-002).
- Still needed (overseer, `feedback.revision_outcome` and `consolidate._superseded_by_revision`): an outcome with an
  `evaded` flaw ends `next="done"` with no escalation, and the delivered revision then supersedes (excludes) the original in
  consolidation, so the weakened answer replaces the flagged one. Change: escalate on evaded (for example
  `elif any(o.bucket == "evaded" for o in outcomes): nxt, why = "escalated", "evaded_after_feedback"`, adding the reason to
  `ESCALATION_REASONS` and OVS-FB-002), and do not let a revision whose outcome is escalated or evaded supersede the
  original (keep the original excluded for its error, or exclude the revision too). Test: extend
  `overseer_tests/test_feedback_outcome.py::test_a_calculation_turned_into_an_estimate_is_evaded` with `out.next ==
  "escalated"` and a consolidation that does not deliver the revision as the answer; and assert the revision's receipt now
  carries the INT-REV-002 naming s1.2.

## 2. Packs: a quoted label is no quotation (c2 results-audit, CORE-SRC-003 on maa-t15 m11.1; minor)

- Still reproduces on the current tree: maa-t15 genuine carries CORE-SRC-003 (warning) "2 quotation(s) cannot be verified: no
  text was supplied and no from-memory label is present: 'at least one blue'; 'both blue'" on m11.1 ('Let E be "at least
  one blue" and F be "both blue".'). The finding is emitted by `src/epinoic_logic/branches/packs.py` (the core pack's
  unverifiable-quotation rule, around the `CORE-SRC-003` returns), not by the channel.
- Change: read a quoted phrase introduced as a label or a definition as a mention, never a quotation: right after
  "Let <X> be", "<X> be" in a let-list ("and F be"), "call(ed) <it|X>", "define(d) <X> as", "denote(d) by", "<X> stands for",
  "the event", "named". The simplest place is beside `_absent_mentions` (the mentions set read on every span).
- Test: maa-t15 genuine (C2 material) carries no CORE-SRC-003; control: 'The author writes "the house was dark"' with no
  text supplied still draws CORE-SRC-003.

## 3. Integration / packaging: the declared z3-solver range (restored-environment check 12 Nov; major)

- `pyproject.toml` declares `z3-solver>=4.13`, while the integration bootstrap accepts only `[5.1.0, 5.2)`; a fresh install
  resolved 5.3.3 and every service entry refused with KIT-HS-003 (five integration tests fail). Change: declare
  `z3-solver>=5.1.0,<5.2` (wherever the dependency is listed, extras included) or widen the bootstrap's accepted range only
  with evidence; add a test that reads the declared specifier from `pyproject.toml` and the bootstrap's accepted range and
  asserts they agree.
- For information: the companion pydantic record (E303 vs E100 with pydantic 2.14.3) is fixed in this pass in
  `engine/validator.py` (the nesting is bounded on the parsed JSON before pydantic validates, and every recursion error type
  maps to E303); reproduced and verified with pydantic 2.14.3 in a scratch environment
  (`tests/engine/test_pack_policies.py::test_no_policy_lifts_a_structural_bound` passes there). No pin of pydantic is needed
  for it.

## 4. Overseer: the auditor's translator floor and the step input from the previous line (c2 translation-fidelity, minor; c2 stem-integration F17, critical)

- maa-t15 m7.3 and mai-t15 m10.1 (F17's two remaining instances) are faithful step checks from the previous line, as the
  translation-fidelity lens and the results audit judged; the auditor's rule `stated-input` already exempts them (checked on
  the current tree: `restatement(...)` gives `exempt (('q7-eq2', 'stated-input'),)` for m7.3), so their ENTAILED receipts agree
  with the audit. Nothing more is needed for those two.
- maa-t15 m2.4 ("4k < 36" from m2.3's "36 − 4k > 0") and m7.2 ("2x + 2 = x − 3" from m7.1) are the same shape, but the
  translator's step 4c refuses them (E112, rule semantic-restatement) and the auditor's floor agrees: `translator_semantic_floor`
  calls `translate.restatement.semantic_restatement(grounded, located, claim_text=...)` and its result is never exempt
  (`restatement(...)`: `if pid in floor ...: continue`). Measured on the current tree: floor `full ('m24-prev',)` and
  `full ('q7-eq1',)`.
- This pass adds the translator's rule `previous-line-step` (`translate/restatement._previous_line_step`, parameter
  `prior_texts` of `semantic_restatement`) and `translate/pipeline.previous_lines(claim, report)` (the report's three claims before
  the claim, nearest last, and the claims it cites: the auditor's `prior_lines` plus the cited claims). With them both encodings
  read as step checks (`tests/translate/test_c2b_clearance_core_translate.py::test_maa_t15_m2_4_and_m7_2_step_checks_read_from_their_previous_lines`).
  The pipeline does NOT pass the lines yet: a decided m2.4 or m7.2 would reach a receipt ENTAILED while the floor still names it
  OVS-TRN-006.
- Needed (overseer, `checks/translation.translator_semantic_floor`): pass `prior_texts` = the texts of `prior_lines(report,
  problem.claim_id)` plus the texts of the claim's `supporting_claim_ids` (exactly `translate.pipeline.previous_lines`), so the
  floor is the translator's rule as the pipeline will run it. Then the core owner changes the one call in
  `translate/pipeline.Translator._process_attempt` (`self._circularity(..., prior_texts=previous_lines(claim, report))`, the
  comment there says so) and turns the test above into "ENTAILED with no E112"; both in one commit. Test on the overseer side:
  m2.4 and m7.2 carry no OVS-TRN-006 once decided.

## 5. `src/epinoic_logic/named.py` (its owner): a capped ARG-CIRC-002 on a step check from the previous line (c2 results-audit, minor)

- maa-t15 m7.3 ("x = −5" from m7.2's "2x + 2 = x − 3") still carries INT-ARG-001 circular_reasoning [ARG-CIRC-002] at warning:
  the engine's `circ_equivalent` reads the premise as the writer's own unsourced restatement, which it cannot tell from a
  translator-invented one (the re-run review's "2 × dt = 82" for "dt = 41" must stay circular). The claim layer can tell
  (the premise is written on the claim's previous line: `translate.restatement._previous_line_step`), but capping an engine
  diagnostic needs a cap reason of the code table: `named.CAP_REASONS` holds only `ambiguous_translation` and
  `not_source_bound`.
- Needed: a cap reason (for example `stated_step_input`) in `named.CAP_REASONS` (and wherever the reasons are listed or
  digested); then `translate/diag_core.claim_diagnostics` caps ARG-CIRC-002 at info when its first assertion id is a premise
  `_previous_line_step` exempts. Tell the core owner when the reason exists and the core side follows.

## 6. Overseer: the response limit before the auditor's own readers (queued q211b, critical; defence in depth)

- The channel refuses a response over the contract's 400,000 characters before any reader runs (first pass,
  `tests/channel/test_c2_clearance_core.py::test_a_response_over_the_contract_limit_is_refused_before_any_reader_runs`), so no
  such response is delivered and `checks/fidelity.check_reparse` (delivered transfers only) never sees one from the channel.
  The finding also asks that the overseer apply the same limit before `check_reparse` and the decision-time readers
  (`meta_notes.note_paragraphs`, `non_material.parser_units`, `english_units`, `parser_claims`), so a journal whose raw text
  exceeds the limit is refused unread there too. Not done on the overseer side as of 13 Nov (no length check in those
  readers on the current tree).

## 7. For information: findings of the core list that other owners' first passes fixed

- ST-RANGE-001 on ch-p9b s5.3 and s11.3 (c2 results-audit, `src/epinoic_logic/stem`): no ST-RANGE-001 on the ch-p9b genuine
  receipt of the current tree.
- ec-t15 g4.2's "paragraph [3]" (c2 communication-fidelity, adapters): the claim now keeps "... linked to paragraph [3]."
- The role of declines, numbered fix-it steps and framing notes (c2 results-audit, adapters): the synthesis side is the
  ledger's rule framing-content (first pass, INT-LEDGER-019 on ps-t15 g1.1, ec-t15 g4.11, cs-t15 c7.6); the parsers' roles
  are the parsers' (their handoff).

## 8. For whoever reads the core harness runs of 13 Nov

- During this pass the c1 replay showed mai-t14 m6.2, m9.2 and m21.2 gone from the parse (the c1 synthesis then cites unknown
  claims, INT-LEDGER-001), and the c2 replay showed stale fixtures on maa-t15 and mai-t15 while the STEM fixer was editing;
  none of those came from core files.
