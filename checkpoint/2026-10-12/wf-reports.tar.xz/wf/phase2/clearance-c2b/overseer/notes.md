# overseer fixer, second pass (c2b) working notes

B1  circular ENTAILED (ra) critical: overseer TRN-006 rules; translator E112 = handoff?
B2  Model: quotation (ra) critical: OVS-FID-004 own-model (1st pass); CORE-SRC-006 translator
B3  INT-HANDOFF-004 task (ra) critical: divergence task-in-scope (1st pass); integrity translator
B4  translation faults exclude (ra) critical: translation-faults (1st pass)
B5  self-cert fallback (ra) critical: self-certification-gate (1st pass) -- test 'note by negation' FAILS now (translator parser keeps 'Final note:' assurance as a point claim)
B6  single refuted candidate (ra) critical: absolute-refutation (1st pass)
B7  feedback declined item (ra) critical: feedback-hold (1st pass)
B8  closing lines source-list/note-clauses (ra) minor
B9  COUNTEREXAMPLE W111 refuted (ra) minor: recorded only (1st pass) -> check
B10 fixture binding supporting quotations (ra) minor: auditor premise excerpt trace
B11 revision feedback (cf) critical: channel/feedback translator + overseer feedback
B12 evaluation point conflict (cf) critical: joint evaluation-point (1st pass); cross_check translator
B13 c1 bug 4 circular (cf) critical: translator E112
B14 FID-004 model answers (cf) major: own-model (1st pass)
B15 score_verdicts injection + gold adjudication (cf) major
B16 runner attestation (cf) minor: recorded reply provider (1st pass)
B17 false-conflict recheck validate (al) major
B18 E112 vs TRN-006 (al) major: translator
B19 FID-004 model (al) critical: same as B14
B20 '[n]' stripped (al) major: generic_parser translator + validate.py compare before stripping
B21 revision request builder (al) critical
B22 overseer-agent stage gold/runner (al) minor
B23 _assess_claim accurate on silence (stem) critical: unchecked-working (1st pass); incomplete inspections?
B24 TRN-006/005/004 false findings (tf) critical: 1st pass
B25 export_dossier issue_variant (tf) major: merge_auditor_faults (1st pass)
B26 apply_fidelity_reference (tf) major: 1st pass
B27 standing shared function (merged c1) critical
B28 quantities _figure_unit + TRN-005 years-months (c1 tf) major
B29 gold false receipt finding (c1 al) minor: 1st pass
B30 INT-SUBJ-003 one fault two errors (lu) minor: formal._structural_implied
B31 docstrings 'assertions are unchanged' (q215b) minor
B32 q222a minor: 1st pass
B33 q222b minor: 1st pass
B34 q222d minor: 1st pass
B35 q222e tamper lost codes minor
B36 p5060a declining target minor
B37 p5060b minor: 1st pass
B38 p5060c minor: 1st pass
B39 p5060d docs minor (tests/README.md not mine)
B40 recorded reply provider minor: 1st pass
B41 twofold merged review NOT reviewed (push-check) minor
B42 TemporaryContext.build default mode (push-check) minor
B43 BLIND_HIDDEN_KINDS (push-check) minor
B44 stem_fault_classes_named + maa-t13 (12 Nov) major
