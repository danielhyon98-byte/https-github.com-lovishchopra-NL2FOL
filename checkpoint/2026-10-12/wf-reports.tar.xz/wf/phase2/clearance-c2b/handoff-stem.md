# Handoff from the STEM fixer (round 9, clearance c2, second fix pass)

Owner of this note: stem (src/epinoic_logic/stem/**, tests/stem/**, tests/fixtures/stem/**, docs/STEM_*.md). Everything below is a
finding of the STEM list that still reproduces on the current tree and needs a change outside those paths. Each item names the finding,
the file and function, what to change, and the regression test that shows it. Reproductions use the recorded answers
(`tests/fixtures/stem/round9/c2_answers.json`, `clearance/c2/specialists/<task>.json`) or a c2 harness run on a copy.

Re-checked on 13 Nov after the container restart (the STEM fixer's resumed pass): items 1a, 1b, 3a and 3b still reproduce; item 2 is done
on both sides now; items 1c, 1d and 5 are new; item 4 is updated.

Nothing here blocks the STEM fixes: the STEM pack's own changes (docs/STEM_DESIGN.md section 41, `tests/stem/test_clearance_c2b_stem.py`,
`tests/stem/test_layout.py`) pass on their own, and round 7's maa-t13 receipt is back to the 16 formal checks the overseer pins
(`overseer/tests/overseer_tests/test_stem_completion.py::test_every_recorded_stem_receipt_is_the_image_of_its_re_derivation`), so the
overseer's handoff item 6 (maa-t13) needs no re-pin.

## 1. Parsers: roles of STEM claims (`src/epinoic_logic/adapters/stem_specialist/parser.py`, `branches/generic_parser.assign_roles`)

### 1a. A 'Judgement:' line is the part's judgement (c2 results-audit "verdict roles", communication-fidelity c1 bug 6, adversarial-live bug 23; minor/major, not critical)
- Still reproduces (13 Nov, resumed pass): ess-p9c genuine delivered on the sciences branch roles s13.1 'Judgement: sustainable drainage is a
  partial solution.' as `analysis` / `supporting`, and the receipt carries `INT-REQ-008 item i4 uses the command term 'evaluate' ... no
  judgement/point claim was found`. The overseer's handoff item 2 asks for the same fix ("channel or parser owner").
- Change: a sentence that opens with 'Judgement:' or 'Conclusion:' (any case, after an optional part label or list marker) is roled
  `judgement` and `material` on every branch's role pass, the STEM adapter's included.
- Test: ess-p9c genuine (recorded) delivered on the sciences branch: s13.1 `judgement`/`material`, no INT-REQ-008.

### 1b. The first line of a result list is a result (c2 stem-integration "label: value" roles; minor)
- Still reproduces: ch-p9b s14.2 'Stock solution: 0.984' is `other`/`supporting` while s14.1 and s14.3 ('Made from 10.00 cm³ of stock:
  0.197', ...) are `quantitative`; the c2 synthesis drops it as "a note or source line (role other)".
- Change: give every 'label: value' line of a list (a run of two or more such lines after a heading line ending with ':') the same
  `quantitative` role; only lines that open with Sources/Note/Next step are notes.
- Test: ch-p9b genuine: s14.2 to s14.6 all `quantitative`. (The STEM pack checks each line of that list against the working its label
  names, rule result-list, at warning severity: `tests/stem/test_clearance_c2b_stem.py::test_a_misread_line_of_a_result_list_is_named`.)

### 1c. Question restatements, checks, headings and framing lines carry the material role (c2 communication-fidelity c1 bug 6, c1 communication-fidelity#6, c2 results-audit "headings"; major/minor, not critical)
Seen still reproducing on the current tree (delivered alone through `RouterHub`, the recorded c2 answers and questions):
- maa-t15 m8.1 'Write R for red and B for blue.' is `point`/`material`; m6.3 'Check: g((x − 3)/2) = ... = x.' is `point`/`material` while
  the result m6.2 'g⁻¹(x) = (x − 3)/2' is `quantitative`/`supporting`.
- mai-t15 m8.1 'Check: $(6,\ -1)$ lies on this line, ...' is `point`/`material` while the answer m7.1 '$y = -3x + 17$ A1' is `supporting`.
- ch-t15 s16.1 'Why high pressure and a moderate temperature are used' (a heading) is `analysis`; ch-p9b s12.1 'Why a volumetric flask is
  used' is `analysis` and s10.1 'Sucrose molecules in 1.00 cm³ of the most dilute solution' (a heading) is `quantitative` (both supporting
  now, so no INT-LEDGER-019 is charged for dropping them, but they are no claims of the answer).
- bi-p9b s1.1 'Practice answer for the Paper 2 Section A question.' (a framing remark) is `quantitative`.
- Generic and History branches (for the parsers owner, if not already in their list): ec-t15 g1.1 'Define the term current account deficit
  (paragraph [2]) — define — 2 marks' and g3.1 are `point`/`material` (question restatements); hi-t15 h1.1 'Question 1 — Examine — 15 marks
  / What the question wants: ...' is `point`/`material` while h1.4 'Provisional mark: 5–6 of 15 ...' is `analysis`/`supporting`.
- Change (as the findings state it): furniture first on every branch (a restatement of the question, a heading or label line, a framing
  remark: role `other`); a 'Check:' line supports the result it checks; the last result line of a part, a 'Provisional mark'/'Mark' line and
  a 'Judgement:'/'Conclusion:' line are the part's material claims; supports never cross a part label.
- Tests: the claim rows quoted here, delivered through the hub.

### 1d. A caveat is no self-certification (c2 communication-fidelity c1 bug 17; minor)
- Still reproduces: hi-t15 h1.19 'This session has no textbook library, so the dates above are course-standard knowledge; check them
  against your textbook before you rely on them.' carries `INT-HANDOFF-006 agent self-reported verification status; advisory only,
  ignored` (a caveat that asks the student to verify, not an assurance). The other half of the finding is fixed: bi-p9b s2.3 ('I recalculated
  these values by hand ... and they agree') now carries INT-HANDOFF-006.
- Change: in the self-report lexicon (`adapters/markdown.py` self-certification reader, or the History parser's use of it), read an
  instruction to the reader to check ('check them against your textbook', 'verify before you rely on them') as a caveat, not as a self-report.
- Test: hi-t15 h1.19 carries no INT-HANDOFF-006; bi-p9b s2.3 still does.

## 2. Parsers and STEM together: a bracketed citation is no mark annotation (c2 stem-integration "citation [3]"; minor) - DONE on both sides

- The generic parser keeps the locator's number (`generic_parser._strip_annotations` with `_LOCATOR_BEFORE_RE`, parsers' pass); the STEM
  half is now in `stem/layout.py` (`LOCATOR_BEFORE_RE`, `LEADING_BRACKET_NUMBER_RE`, `locator_number_end`, read by `annotation_ranges`), with
  `tests/stem/test_layout.py::test_the_locator_patterns_are_the_generic_parsers` holding the two pattern pairs identical and
  `test_the_stem_and_generic_parsers_keep_a_locators_number_in_the_same_claims` holding the claims equal. If the parsers owner changes
  `_LOCATOR_BEFORE_RE` or `_LEADING_BRACKET_NUMBER_RE`, change `stem/layout.py` in the same commit (the test fails otherwise).
- For the overseer owner (information): `overseer/src/epinoic_overseer/checks/fidelity.referring_bracket` keeps any bracket after a
  referring noun, a determiner before the noun included ('using the source [2].'), while both parsers treat a bracket after a determiner-led
  locator as a mark and leave it out of the claim. `annotation_ranges` (which `_parser_unmarked` filters) now drops the locator's own number
  itself, so the two agree everywhere except after a determiner; align `referring_bracket` with `layout.locator_number_end` if the overseer
  compares delivered claim texts with its unmarked text there.

## 3. Arena harness (`scripts/arena/`)

### 3a. A STEM mutation on a list-item line keeps the bullet in its marker (c2 stem-integration, c1 stem-integration#26; minor)
- Still reproduces (no change in `scripts/arena/stem_mutations.py` on the current tree): `_link_marker` starts the marker at the line
  start when no '=' precedes the operand on its line, so for the breadth cs-2 line '- 181 − 128 = 53' the marker is '- 181 − 128 = 83'; the
  delivered claim text drops the list marker, so `run_arena.injected_claim_ids` finds no claim and the INT-SUBJ-001 that names c1.2 is
  counted a miss.
- Change: in `_link_marker`, after `s, e = _line_bounds(text, a)` and the part-label skip, skip a leading list marker
  (`[ \t]{0,8}(?:[-*•–—]|\d{1,3}[.)])[ \t]+`, the STEM front end's `spans._LIST_RE`) when it ends at or before `a`; or have
  `run_arena.norm_text` drop such a marker at the start of a marker before matching.
- Test: a harness test with a list-item STEM site (the cs-2 shape, `tests/fixtures/stem/round8/c1_answers.json` 'cs-2') credited when the
  finding quotes the mutated arithmetic, and still counted a miss when no finding names it.

### 3b. Mutated claims are never translated in the arena (c2 translation-fidelity c1 bug r8-8, carry-c2 item c1/translation-fidelity#8; major, not critical)
- Still reproduces (no `--mutations` option in `scripts/arena/list_claims.py` on the current tree): the recording step cannot list a
  round's mutated variants' claims, so it cannot have them translated; the fixture provider refuses the genuine fixtures for the changed
  claims (STALE_FIXTURE_REFUSED).
- Change: `list_claims.py <round> --mutations --json`, built from the harness's own mutation builder (`stem_mutations` and the prose
  mutations run_arena serves), printing each mutated variant's claims in the form the translation agents read, so they can be translated
  and bound with `bind_translations.py --listings`; document it in `scripts/arena/README.md`.
- Test: the listed texts equal what `run_arena.py` serves for each mutated variant of a recorded round.
- The STEM side of the same finding (the deterministic checks name the classes missed) is done: the c2 harness counts 188 of 188
  functional transmissions on the current tree (180 recorded), every STEM mutation named.

## 4. Core and translate (re-checked on the c2 harness run of the current tree)

- bm-t15 g7.3 `INT-ARG-001 invented_figure [EVD-FIG-001]` and ge-p9c `unchecked_source [EVD-SRC-005]`: no longer on the genuine receipts
  of the current tree (the core owner's pass). Nothing needed.
- maa-t15 m11.1/m11.7 `CORE-SRC-003` on 'at least one blue' and 'both blue' (quoted event definitions after 'Let E be'): still on the
  genuine receipt; the core owner's handoff (item 2) hands it to the packs owner (`branches/packs.py`). Not repeated here.
- ge-t15 INT-REQ-004 x3 on '(a)', '(i)', '(ii)' and sp-t15 INT-REQ-004 on its framing sentence: in the parsers' handoff (items 1c, 1d),
  not repeated here.

## 5. STEM and overseer together: a value with plain thousands spaces that stands alone (c2 adversarial-live previous bug 13, stem-integration CS units; decision, not a defect)

- This pass reads a numeral written with plain-space thousands groups whole where it stands in written arithmetic (rule spaced-thousands,
  docs/STEM_DESIGN.md 41.3): '6 000 000 bytes ÷ 1500 bytes per packet = 400 packets' (the lens's cs-t15-packets variant) is INT-SUBJ-001 and
  cs-t15 c4.2/c4.3 hold. A value that stands alone for a symbol or a Given ('P = 4 000 euros', 'Given: P = 4 000 euros') is still named
  ST-PARSE-001 and binds nothing, because the overseer pins that reading (`overseer/tests/overseer_tests/test_stem_repair2.py` row
  'Given: P = 4 000 euros' -> ["ST-PARSE-001"], `test_stem_repair6.py` 'principal 4 000 euros' -> ST-PARSE-001) and its knowledge pack's
  D31 says such a numeral is never read in part.
- If the two owners decide to read the standalone value whole too (P = 4000, set against the request, as a thin-space value is): the
  overseer changes those two pins and D31's sentence in one commit, and the STEM owner drops the `_plain_grouped` branch of
  `relations._thousands_cut` and of the Given rule (`relations.py`, rule thousands-value) with tests
  `tests/stem/test_clearance_c2b_stem.py::test_a_value_standing_alone_with_plain_thousands_spaces_is_still_named` rewritten to the new rule.
  Nothing is needed until then.

## 6. Notes for the merge

- The STEM changes alter STEM receipts of recorded answers in ways that only add holding checks or remove false findings: ch-p9b gains
  five holding stem-res checks (rule result-list); maa-t15 loses its ST-PARSE-001 on m6.2 (the 'M1A1' after g⁻¹(x) is no unit now) and its
  inverse-function step; ph-t14 loses the failing stem-alg on s7.2's first link; round 7's maa-t13 regains its two holding comparisons;
  cs-t15 and its revision gain three holding checks on c4.2/c4.3 and lose two ST-PARSE-001 (rule spaced-thousands). An overseer or
  translator test that pins check counts of the round-9 or round-8 recorded STEM answers may need its count raised (none was found failing
  in the runs listed in the STEM fixer's report).
- Rule locator-number changes no recorded STEM claim text (no recorded STEM answer of rounds 7 to 9 writes a locator's number).
