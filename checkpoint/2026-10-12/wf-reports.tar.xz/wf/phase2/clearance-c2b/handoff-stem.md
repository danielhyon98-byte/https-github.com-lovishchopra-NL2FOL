# Handoff from the STEM fixer (round 9, clearance c2, second fix pass)

Owner of this note: stem (src/epinoic_logic/stem/**, tests/stem/**, tests/fixtures/stem/**, docs/STEM_*.md). Everything below is a
finding of the STEM list that still reproduces on the current tree and needs a change outside those paths. Each item names the finding,
the file and function, what to change, and the regression test that shows it. Reproductions use the recorded answers
(`tests/fixtures/stem/round9/c2_answers.json`, `clearance/c2/specialists/<task>.json`) or the latest c2 harness run on a copy.

Nothing here blocks the STEM fixes: the STEM pack's own changes (docs/STEM_DESIGN.md section 41, `tests/stem/test_clearance_c2b_stem.py`)
pass on their own, and round 7's maa-t13 receipt is back to the 16 formal checks the overseer pins (`overseer/tests/overseer_tests/
test_stem_completion.py::test_every_recorded_stem_receipt_is_the_image_of_its_re_derivation`, 8 of 8 passing), so the overseer's
handoff item 6 (maa-t13) needs no re-pin.

## 1. Parsers: roles of STEM claims (`src/epinoic_logic/adapters/stem_specialist/parser.py`, `branches/generic_parser.assign_roles`)

### 1a. A 'Judgement:' line is the part's judgement (c2 results-audit "verdict roles", communication-fidelity c1 bug 6, adversarial-live bug 23; minor/major, not critical)
- Still reproduces: `StemTextParser(mode="sciences").parse_response(<ess-p9c response>, ...)` roles s13.1 'Judgement: sustainable drainage
  is a partial solution.' as `analysis` / `supporting`; the latest c2 harness copy (overseer/final/c2, 18:57) still carries
  `INT-REQ-008 item i4 uses the command term 'evaluate' ... no judgement/point claim was found` on ess-p9c genuine. The overseer's handoff
  item 2 asks for the same fix ("channel or parser owner").
- Change: a sentence that opens with 'Judgement:' or 'Conclusion:' (any case, after an optional part label or list marker) is roled
  `judgement` and `material` on every branch's role pass, the STEM adapter's included.
- Test: ess-p9c genuine (recorded) delivered on the sciences branch: s13.1 `judgement`/`material`, no INT-REQ-008.

### 1b. The first line of a result list is a result (c2 stem-integration "label: value" roles; minor)
- Still reproduces: ch-p9b s14.2 'Stock solution: 0.984' is `other`/`supporting` while s14.3 to s14.6 ('Made from 10.00 cm³ of stock:
  0.197', ...) are `quantitative`; the c2 synthesis drops it as "a note or source line (role other)".
- Change: give every 'label: value' line of a list (a run of two or more such lines after a heading line ending with ':') the same
  `quantitative` role; only lines that open with Sources/Note/Next step are notes.
- Test: ch-p9b genuine: s14.2 to s14.6 all `quantitative`. (The STEM pack now checks each line of that list against the working its label
  names, rule result-list, at warning severity: `tests/stem/test_clearance_c2b_stem.py::test_a_misread_line_of_a_result_list_is_named`.)

## 2. Parsers and STEM together: a bracketed citation is no mark annotation (c2 stem-integration "citation [3]"; minor)

- Still reproduces: ec-t15 g4.2 '... linked to paragraph [3].' is cut to '... linked to paragraph.' (generic parser), and the STEM claims cut
  'linked to paragraph [3].' and 'Table [2].' the same way.
- Why it is not fixed in the STEM paths alone: the pattern is shared. `stem.layout.TRAILING_ANNOTATION_RE` and
  `branches.generic_parser._TRAILING_ANNOTATION_RE` are pinned to the same string (`tests/stem/test_layout.py::test_the_layout_patterns_are_the_generic_parsers`),
  `stem.layout.trailing_annotation_span` must equal the pattern's search (`tests/stem/test_integration_gate1_handoff.py::test_the_trailing_annotation_span_is_the_searchs_span`),
  and the generic parser imports `trailing_annotation_span` and `strip_trailing_annotations` from `stem.layout` while its
  `_strip_annotations` uses its own copy of the pattern. A change on one side only makes the two parsers cut different claims.
- Change (to land in one commit on both sides; the STEM owner applies the `stem/layout.py` half when the parsers half is ready, or the
  parsers owner applies both with the STEM owner's agreement, which this note gives): in `MARK_ALLOC`'s bracket form, exclude a bracketed
  number that directly follows a citation noun. Fixed-width lookbehinds keep the pattern linear, e.g. prefix the bracket alternative of
  `MARK_ALLOC` with `(?<!paragraph )(?<!paragraphs )(?<!para\. )(?<!table )(?<!figure )(?<!fig\. )(?<!equation )(?<!eq\. )(?<!reference )(?<!ref\. )(?<!source )(?<!line )(?<!page )`
  (and their capitalised forms, or apply the check case-insensitively in `trailing_annotation_span`/`_strip_annotations` with the same
  noun list), so both copies of the pattern stay one string and the equality tests keep holding.
- Tests: 'shown on an AD/AS diagram and linked to paragraph [3].' keeps '[3]' in its claim (generic and STEM parsers); 'Table [2].' keeps
  it; '... 5 [1].', '[1 spare]' and 'reaching 22 at E [1].' are still furniture (`tests/stem/test_layout.py` cases unchanged).

## 3. Arena harness (`scripts/arena/`)

### 3a. A STEM mutation on a list-item line keeps the bullet in its marker (c2 stem-integration, c1 stem-integration#26; minor)
- Still reproduces: `scripts/arena/stem_mutations._link_marker` starts the marker at the line start when no '=' precedes the operand on its
  line, so for the breadth cs-2 line '- 181 − 128 = 53' the marker is '- 181 − 128 = 83'; the delivered claim text drops the list marker,
  so `run_arena.injected_claim_ids` finds no claim and the INT-SUBJ-001 that names c1.2 is counted a miss.
- Change: in `_link_marker`, after `s, e = _line_bounds(text, a)` and the part-label skip, skip a leading list marker
  (`[ \t]{0,8}(?:[-*•–—]|\d{1,3}[.)])[ \t]+`, the STEM front end's `spans._LIST_RE`) when it ends at or before `a`; or have
  `run_arena.norm_text` drop such a marker at the start of a marker before matching.
- Test: a harness test with a list-item STEM site (the cs-2 shape, `tests/fixtures/stem/round8/c1_answers.json` 'cs-2') credited when the
  finding quotes the mutated arithmetic, and still counted a miss when no finding names it.

### 3b. Mutated claims are never translated in the arena (c2 translation-fidelity c1 bug r8-8, carry-c2 item c1/translation-fidelity#8; major, not critical)
- Still reproduces: `list_claims.py` has no option listing a round's mutated variants' claims, so the recording step cannot have them
  translated; the fixture provider refuses the genuine fixtures for the changed claims (STALE_FIXTURE_REFUSED).
- Change: `list_claims.py <round> --mutations --json`, built from the harness's own mutation builder (`stem_mutations` and the prose
  mutations run_arena serves), printing each mutated variant's claims in the form the translation agents read, so they can be translated
  and bound with `bind_translations.py --listings`; document it in `scripts/arena/README.md`.
- Test: the listed texts equal what `run_arena.py` serves for each mutated variant of a recorded round.

## 4. Core and translate (seen still reproducing on the latest c2 harness copy, overseer/final/c2 18:57; owners as named)

These belong to the c2 findings that the STEM list carries with other packages' parts (communication-fidelity c1 bug 17,
adversarial-live bug 23). The STEM parts of those findings are fixed (no false ST-RANGE-001 on ch-p9b, no INT-SUBJ-004 on ph-t15 or
cs-t15, no CORE-QNT-001 beside a STEM check on bi-t15); these parts are not in the STEM paths:

- bm-t15 g7.3 `INT-ARG-001 invented_figure [EVD-FIG-001]` ('no written calculation over stated figures gives' $59,000, which g7.2
  calculates) and `unchecked_source [EVD-SRC-005]`: `src/epinoic_logic/translate/grounding.py` / `engine/argument.py` should read the
  answer's own written calculations as the source of a figure (core owner).
- maa-t15 m11.1/m11.7 `CORE-SRC-003` on 'at least one blue' and 'both blue' (quoted event definitions after 'Let E be'): the core pack
  should exempt quoted definitions introduced by 'Let … be' (core owner).
- ge-t15 INT-REQ-004 x3 on '(a)', '(i)', '(ii)' and sp-t15 INT-REQ-004 on its framing sentence: in the parsers' handoff (items 1c, 1d),
  not repeated here.

## 5. Notes for the merge

- The STEM changes alter STEM receipts of recorded answers in ways that only add holding checks or remove false findings: ch-p9b gains
  five holding stem-res checks (rule result-list); maa-t15 loses its ST-PARSE-001 on m6.2 (the 'M1A1' after g⁻¹(x) is no unit now) and its
  inverse-function step; ph-t14 loses the failing stem-alg on s7.2's first link; round 7's maa-t13 regains its two holding comparisons.
  An overseer or translator test that pins check counts of the round-9 or round-8 recorded STEM answers may need its count raised (none
  was found failing in the runs listed in the STEM fixer's report).
