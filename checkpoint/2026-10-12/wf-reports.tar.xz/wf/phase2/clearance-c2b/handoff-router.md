# Handoff from the router fixer (round-9 clearance, second fix pass c2b)

Written 14 Nov by the owner of `flash-router/**`. My list held one record (push check of c4f276c, minor): "the flash-router
CLI maps every Exception to exit 2 or 3, so a planner bug can look like bad input. run_arena's delivery_pass and
revision_pass return 'skipped' (printed 'not run') when the overseer is absent. Under pytest older than 9, importorskip
of the overseer would also skip on a plain ImportError." The first part is in my paths and is fixed (section 4). The other
two are outside them and still reproduce on the current tree (sections 1 and 2). Nothing here asks anyone to loosen a
rule; I changed no file outside `flash-router/`.

## 1. Harness (owner of `scripts/arena/**`): the overseer's two passes are skipped with exit status 0, and under the prescribed `python -I` invocation they are always skipped here

- Still reproduces (current tree, 14 Nov). `run_arena.overseer_installed()` locates `epinoic_overseer` with
  `importlib.util.find_spec`, and `run_arena.py` puts only `scripts/arena/` on `sys.path`. The scratch venv of the arena
  tools has only `epinoic-logic` installed (`pip list`: no `epinoic-overseer`, `epinoic-flash-router` or
  `epinoic-combinator`); `overseer/src` reaches the path only through the root `pyproject.toml`'s pytest
  `pythonpath`, which a script run never reads. So under the prescribed `python -I scripts/arena/run_arena.py <round_dir>`:
  - `overseer_installed()` is False;
  - `delivery_pass(...)` returns `{"skipped": OVERSEER_NOT_INSTALLED, ...}` and `revision_pass(<round with feedback/>, ...)`
    likewise; the command line prints "delivery decisions (a separate measure): not run (...)" and "specialist revisions
    (a separate measure): not run (...)";
  - `main` returns 0. Only `--fail-on-revision-gates` with a `feedback/` directory turns the skipped revision pass into
    exit 1 (`revision_gate_failures`, the first pass's addition); nothing turns a skipped delivery pass into a failure.
  Measured: `python -I -c "import sys; sys.path.insert(0, 'scripts/arena'); import run_arena as A; print(A.overseer_installed())"`
  from the repository root prints False; `A.delivery_pass([], None, {}, [])["skipped"]` and
  `A.revision_pass(<dir with feedback/>, [], {})["skipped"]` are `OVERSEER_NOT_INSTALLED`. My read-only harness runs on
  copies of c1 and c2 this pass (14 Nov, `python -I scripts/arena/run_arena.py <copy>`, functional 203/203 and 188/188)
  printed "delivery decisions (a separate measure): not run (the overseer sub-project ... is not installed ...)" for
  both rounds and, for c2, which holds `feedback/`, "specialist revisions (a separate measure): not run (... not
  installed ...)" as well, and both exited 0 (the recorded c1/c2 results.json, made where the overseer was found, have
  their delivery pass run). Every harness run in this environment since the restore therefore ran without the delivery
  and revision measures, said only by those lines; the transport counts do not depend on them, so nothing else showed
  it.
- Needed (both, recommended):
  (a) find the overseer sub-project beside the harness, as the repository's pytest configuration does: when
      `epinoic_overseer` cannot be located and `<repo>/overseer/src/epinoic_overseer/__init__.py` exists (the repository
      root is `Path(__file__).resolve().parents[2]`), insert `<repo>/overseer/src` on `sys.path` before
      `overseer_installed()` is asked (so the documented invocation runs the overseer's passes inside the repository;
      after the documented split the directory is absent and nothing changes);
  (b) make a pass not run for `OVERSEER_NOT_INSTALLED` a failure of the run by default (exit status 1, "FAILED: the
      delivery pass and the revision pass were not run: the overseer is not installed"), unless the operator says so
      explicitly (`--without-overseer`, recorded in results.json and summary.md as a configuration, as
      `--without-task-record` is). A pass switched off by a harness (`DELIVERY_PASS`/`REVISION_PASS` False) and a round
      without `feedback/` stay as they are.
- Tests (`scripts/arena/test_arena_rules.py`): with `overseer_installed` patched to return False, `main([<a small round>])`
  exits 1 and names both passes, and exits 0 with `--without-overseer`; in a subprocess under `python -I` with only the
  translator installed, `overseer_installed()` is True once (a) runs (the overseer found beside the script). Keep
  `tests/channel/test_without_the_overseer.py`'s rule that the translator's suite runs without the overseer (the harness's
  opt-out is the explicit flag, not a silent skip).
- Environment note for the workflow (no file change): the restored venv lacks the sub-projects the README's install
  steps add (`pip install -e ./overseer --no-deps`, `pip install -e ./flash-router --no-deps`); installing them there
  would also make the harness find the overseer, but (a) and (b) make the harness right whatever the venv holds.

## 2. Translator tests and pins (owners of `tests/**`, `scripts/arena/test_arena_rules.py`, the root and `overseer/` `pyproject.toml`): `pytest.importorskip` of the overseer skips a broken install under pytest older than 9

- Still reproduces under the declared requirement (the venv has pytest 9.2.0, so it does not show there). The dev
  requirement is `pytest>=8` (root `pyproject.toml` line 20, `overseer/pyproject.toml` line 17). Under pytest 8.x
  `pytest.importorskip(modname, reason=...)` catches every `ImportError` (8.2 and later only warn when it is not a
  `ModuleNotFoundError`; 9.0 made `ModuleNotFoundError` the default). So an overseer that IS installed but fails to
  import (a module of it raising `ImportError`, a circular import, a broken install) is reported as "not installed" and
  every test that attaches it is SKIPPED, not failed.
  Measured with pytest 9.2.0 and a scratch package whose `__init__` raises `ImportError`: the default
  `pytest.importorskip("broken_pkg", reason=...)` raises ImportError (fails loudly); with `exc_type=ImportError` (the
  default before 9) it is Skipped with the "not installed" reason.
- The calls (none passes `exc_type`): `tests/overseer_attach.py` (`overseer()`, `overseer_module()`),
  `tests/integration/helpers.py:181`, `tests/integration/test_protocol_constants.py:43`,
  `tests/integration/test_overseer_subproject.py:157`, `tests/integration/test_preflight_handshake.py:68`,
  `scripts/arena/test_arena_rules.py:1864`.
- Needed: pass `exc_type=ModuleNotFoundError` at each of those calls and raise the dev pin to `pytest>=8.2` (where
  `exc_type` exists) in the root and overseer `pyproject.toml`, or pin `pytest>=9`; and extend the AST rule of
  `tests/channel/test_without_the_overseer.py` (`_unguarded_overseer_imports_in`, near line 447, which already requires `reason=`) to require
  `exc_type=ModuleNotFoundError` on every importorskip of the overseer, so the class stays closed. More precise still,
  since `ModuleNotFoundError` also covers a missing dependency of an installed overseer: skip only when
  `importlib.util.find_spec("epinoic_overseer") is None` and otherwise import it plainly (a broken install fails), as
  `run_arena.overseer_installed()` does (located, never imported).
- Test: in a subprocess, a scratch package named `epinoic_overseer` whose `__init__` raises `ImportError`, first on the
  path: a test using `overseer_attach.overseer()` FAILS (it is not skipped); with no such package on the path it is
  skipped with `REASON`, as now.
- `flash-router/` has no importorskip (its suite imports the translator's router port directly and fails loudly without
  it): nothing to change there.

## 3. Documentation only (owners of `tests/README.md` and `integration/**`)

- `tests/README.md` line ~767 ("Flash router 0.4.0 (`flash-router/tests/flash_router_tests/`, 94 tests, 79 before)"): the
  suite is now 158 tests (94 before). Its sentence on `test_runner.py` ("exit 3 never a traceback for a request nested
  200,000 deep (array and object), a zero quota, an out-of-range number and a repeated key, exit 2 for a data file nested
  too deep") now reads: exit 3 with the router's own `RequestError` reason for those requests (the test rewritten to
  that stricter rule), exit 2 for a data file nested too deep, and exit 4, never 2 or 3, for a fault of the router's own
  code (nine exception types, `ValueError` among them, raised while planning a request it reads, loading its data or
  writing a hello; and a real fault edited into a copy of the planner, with no traceback); new `test_contract.py`: what
  the router reads of a request (each refusal with its exact reason before anything is planned; any request mutated
  from one in contract planned or refused with a `RequestError`, never a fault of the router, and answered 0 or 3 by the
  runner; every pool port 1.2 request the port accepts planned).
- `integration/router-port/CONFORMANCE.md` line ~98 ("The released router shows them in ... `test_runner.py`"): add
  `test_contract.py` (the router refuses a request it does not read, before planning, with `RequestError`; it never
  fails on one it reads).

## 4. Done in `flash-router/` (no change asked; for the record)

- `epinoic_flash_router.contract` (new): before anything is planned, `port.plan`/`port.pool_plan` decode the text
  strictly (no NaN/Infinity, no member named twice) and `plan_for`, `transfer_decisions` and `pool_plan_for` check every
  member the planners read against the type and range the router port gives it (counts at most 2^53 - 1), refusing with
  `RequestError` (a `ValueError`) naming the member and the rule. A request that passes cannot make the planners fail
  (a property test over mutated requests in the suite; 410,000 mutated requests in a scratch fuzz, 320,000 over the
  current data and 90,000 over the released 0.2.0 data, none raised anything but `RequestError`).
  The checks are no stricter than the port: 8,011 port-validated requests (the vectors, 4,000 of the service's, 4,000 of
  the pool's at 1.1 and 1.2) are planned byte for byte as before, and the overseer's recorded-plans test passes, so the
  router's identity (version 0.4.0, the rules and cost-data digests) is unchanged.
- The runner: exit 2 the data's (`OSError`, `ValueError`, `RecursionError`), exit 3 the input's (`RequestError` with its
  reason, or standard input that is not text), exit 4 the router's own fault (any other exception while importing and
  loading, writing a hello or its identity, or planning a request it reads; named by type only), never a traceback.
- The callers never run the runner: their child process (`router_child`) reports any raise as `KIT-RT-016` and runs the
  floor plan, as before; a request they send is in contract and is planned exactly as before.
