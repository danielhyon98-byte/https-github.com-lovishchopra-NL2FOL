# Handoff from the combinator fixer: round-9 clearance c2, second fix pass (13 Nov)

Owner of this note: combinator (`combinator/**`). One finding was on the combinator's list; what remains of it lies
outside `combinator/**` and is written here for the owner of `src/epinoic_logic/integrity/ledger.py` (core) and of
`tests/integration/test_combinator_subproject.py` (core or integration).

## The finding (major; c2/communication-fidelity; Psychology, ps-t15)

A synthesis that drops the specialist's decline of the requested deliverable was delivered with no finding, and one that
carries it was charged INT-LEDGER-029. Expected: a decline or a deferral the channel records on the specialist's receipt
(INT-REQ-004 "declined, not answered" / "pending, not answered") reaches the student in the synthesis as a note for the
student, a synthesis that drops it is named, and self-certifications and verification labels stay excluded.

State on the current tree (checked 13 Nov; harness run read-only on copies of c1 and c2: functional 203/203 and 188/188):

| Part | Where | State |
|---|---|---|
| Instructions: rule 6 split, rule 7 carries a decline or a deferral word for word as a claim of its own (`carried`, citing only that claim, whatever its role); the faithful fake follows it | `combinator/` (pack 1.3, `providers.withheld_work`) | fixed in the first pass; tests `combinator/tests/test_withheld_work.py`, `test_pack_and_export.py` |
| A synthesis that leaves out a recorded **decline** is named | `integrity.ledger.framing_content_findings` (INT-LEDGER-019, rule framing-content) | fixed in the first pass (core); c2 ps-t15 and c1 ge-t14 syntheses carry it; `tests/channel/test_c2_clearance_core.py::test_a_synthesis_that_leaves_out_framing_content_is_named` |
| No INT-LEDGER-029 on the decline carried word for word | `integrity.ledger._self_report_findings` ("made only from notes") | **STILL REPRODUCES** (E9d: c2 ps-t15 synthesis carrying g1.1 word for word: INT-LEDGER-029 on s0); combinator strict xfail `test_through_the_hub_a_decline_carried_word_for_word_is_no_self_report` |
| A synthesis that leaves out a recorded **deferral** is named | `integrity.ledger.framing_content_findings` | **NOT NAMED**: the rule reads `adapters.markdown.declined_deliverable` only. Recorded instance: round-8 clearance c1, ps-p8d (group p8d): the receipt records "the answer defers the deliverable to the student's reply ... the item is pending, not answered" (INT-REQ-004) and the group's synthesis left out g6.1@psychology-specialist 'Reply "approve" and I will write the full evaluation within 500 words.' (reason "an offer and a request to the student, not a claim of the answer"): ACCEPTED, no finding. Combinator strict xfail `test_through_the_hub_a_synthesis_that_leaves_out_a_recorded_deferral_is_named` |

## Needed (core: `src/epinoic_logic/integrity/ledger.py`)

A trial patch implementing items 1 and 2 was applied to a scratch copy of the tree and tested there (never to the
repository): `/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/wf/phase2/clearance-c2b/combinator/patched/ledger.patch`
(a unified diff against the current `ledger.py`; 62 lines).

1. **`_self_report_findings`: do not charge INT-LEDGER-029 on a decline or a deferral carried word for word.** Add a
   predicate and use it before the "made only from notes" branch, so neither that branch nor the "carries the words of"
   branch runs for such a claim:

   ```python
   def _carries_withheld_work(sc, cited: list[str], notes: dict[str, ClaimRecord]) -> bool:
       if sc.transformation != "carried" or len(sc.source_claim_ids) != 1 or len(cited) != 1 or cited[0] not in notes:
           return False
       note = notes[cited[0]].claim_text or ""
       if _norm(_QUOTE_MARKS_RE.sub('"', note)) != _norm(_QUOTE_MARKS_RE.sub('"', sc.text or "")):
           return False
       from ..channel.bus import withheld_deliverable  # the channel imports this module, so import at call time
       return withheld_deliverable(note) is not None
   ...
           if _carries_withheld_work(sc, cited, notes):
               pass  # rule 7 of the combinator's instructions: carried word for word for the student
           elif cited and len(note_ids) == len(cited):
               ...  # unchanged
           else:
               ...  # unchanged
   ```

   The equality is the one the ledger's `carried` rule (INT-LEDGER-010) already applies. The reading is per claim text,
   as `framing_content_findings` reads a left-out claim and as the combinator's faithful fake reads a note (the
   combinator's conformance test `test_through_the_hub_the_fakes_reading_is_the_channels` holds the two readings equal).
   Unchanged by design (each pinned by a combinator test that passes before and after the patch,
   `test_through_the_hub_rule_7_frees_no_other_form_of_the_decline` and
   `test_through_the_hub_a_carried_self_certification_or_a_reworded_decline_is_still_named`): the verification-label and
   self-report-sentence part (`found`) still runs on every claim ("Verified: I can't write ..." is still named); the
   decline merged with a content claim ("carries the words of"), under another transformation with identical text,
   shortened (`narrowed`) or reworded (`paraphrased`) is still "made only from notes"; a carried self-certification or
   any other note is still named. Cleaner layering, if preferred: move `channel.bus._DEFERRAL_RE` (with
   `_DEFERRED_OBJECT`) beside `adapters.markdown.declined_deliverable` as a `deferred_deliverable` reader, have
   `withheld_deliverable` call both (behaviour unchanged) and import from `adapters.markdown` in the ledger.

2. **`framing_content_findings`: name a left-out deferral too.** Read each left-out non-material claim with
   `channel.bus.withheld_deliverable(text)` instead of `adapters.markdown.declined_deliverable(text)`; a decline keeps its
   reason word for word; a deferral gets "it defers a requested deliverable to the student's reply, so the student-facing
   answer no longer says that the item is pending or what the student must do to receive it". Update the docstring
   (it names `declined_deliverable`) and the rule's row in `src/epinoic_logic/integrity/README.md` (line ~472, rule
   framing-content).

3. **Docs** (`src/epinoic_logic/integrity/README.md`): the INT-LEDGER-029 row (line ~115) says a synthesized claim made
   only from notes "(... a decline, a question to the student, ...) carries a note back as a claim, under any
   transformation label"; add the exception: a decline or a deferral the channel reads (`withheld_deliverable`) carried
   word for word, alone, as `carried` (rule 7 of the combinator's instructions) is a note for the student and is not
   named; any other form still is. Also the docstring of `_self_report_findings`, which lists "I cannot answer the second
   part of the question." among the notes named when carried.

## Needed: one existing test conflicts with item 1 (owner of `tests/integration/test_combinator_subproject.py`)

With the trial patch, 1,048 tests of the 11 files that test INT-LEDGER-029, the synthesis readers and the decline
readers ran (`tests/integration/test_combinator_subproject.py`, `tests/channel/test_c2_clearance_core.py`,
`tests/channel/test_integration_gate4_synthesis.py`, `tests/integrity/test_synthesis_self_reports.py`,
`tests/integrity/test_integration_gate4_ledger.py`, `tests/adapters/test_verification_labels.py`,
`tests/adapters/test_integration_gate2_parsers.py`, `tests/adapters/test_integration_gate3_parsers.py`,
`tests/channel/test_c1_clearance_core.py`, `overseer/tests/overseer_tests/test_c1_name_substitution.py`,
`overseer/tests/overseer_tests/test_second_translator_merge.py`): exactly one failed,
`test_a_carried_note_is_caught_by_the_hub_whatever_its_wording[I cannot answer the second part of the question.]`.
`CARRIED_NOTES` holds that decline and the test carries every note word for word as `carried` (`_carry_all`), asserting
INT-LEDGER-029: the very charge this finding removes. Proposed rewrite, at least as strict, to be named as a rewrite to
the finding's rule in `tests/README.md`:

- replace that parameter with a note of the same shape that is no decline or deferral the channel records, so the
  parametrized test keeps nine notes: "I have not answered the second part of the question." (checked through the
  test's own `_with_note` and `_carry_all`: delivered as the note h2.1, `withheld_deliverable` reads nothing in it, and
  carried it is named INT-LEDGER-029, before and after the trial patch); and
- add a test that "I cannot answer the second part of the question." carried word for word (`_carry_all`) draws no
  INT-LEDGER-029 on its claim, while the same decline under a verification label, merged with the History claim, or
  carried under another transformation word draws it (the existing
  `test_a_note_reworded_under_any_label_is_caught_by_the_hub` keeps the paraphrased, generalized and narrowed forms).

## Needed when items 1 and 2 land: remove two strict-xfail marks (combinator's file)

`combinator/tests/test_withheld_work.py::test_through_the_hub_a_decline_carried_word_for_word_is_no_self_report` (item 1)
and `::test_through_the_hub_a_synthesis_that_leaves_out_a_recorded_deferral_is_named` (item 2) are `xfail(strict=True)`:
with the trial patch both XPASS and fail the combinator suite (and with it
`tests/integration/test_combinator_subproject.py::test_the_sub_projects_own_suite_passes_with_nothing_skipped`). Remove
each mark in the same change as its ledger item (a strengthening; the combinator owner agrees), and in
`combinator/README.md` and `combinator/docs/DESIGN.md` delete the item from the "open on the hub's side" passages (or
hand this step back to the combinator owner).

## Measured effect of the trial patch on the recorded rounds (harness on copies; ids of engine results normalised)

- c1: functional 203/203 before and after; one record changed: the p8d synthesis (ps-p8d.json) ACCEPTED ->
  ACCEPTED_WITH_FINDINGS, + INT-LEDGER-019 warning naming g6.1@psychology-specialist (the left-out deferral). Nothing else.
- c2: functional 188/188 before and after; no record changed (the ps-t15 synthesis keeps its INT-LEDGER-019 on the
  left-out decline; no recorded synthesis carries a decline).

## Not needed for this finding (for consideration)

The port gives every synthesized claim the materiality `material` (`combinator_port.synthesis_payload`, the contract's
default), so the carried decline arrives as a material synthesized claim although rule 7 calls it a note for the student.
No check or formal result is attached to it (its source is a note, carried word for word), so nothing presents it as
verified; marking it `supporting`, or a field of the synthesis for notes to the student, would be a contract change.

## Combinator paths: what this pass changed (no commit)

- `combinator/tests/test_withheld_work.py`: `_deliver` can return the receipts; new tests: the receipts record the
  decline and the deferral (INT-REQ-004); rule 7 frees no other form of the decline (merged, labelled, relabelled,
  shortened: INT-LEDGER-029); a deferral carried word for word draws no finding; strict xfail for the left-out deferral.
  Suite: 58 passed, 2 xfailed (strict); with the trial patch: 58 passed and both xfails XPASS.
- `combinator/README.md`, `combinator/docs/DESIGN.md`: the open hub-side items now name the left-out deferral too.
- Hostile-input probe of every public entry point of the combinator (runner, port, prompt, jsonio, the fake's reading),
  each standard hostile run of about 20,000 characters and the agent-output bound: slowest call 5.3 ms. No stall, no
  performance finding.
