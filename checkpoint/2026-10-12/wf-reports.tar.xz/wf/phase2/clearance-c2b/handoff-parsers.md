# Handoff from the parsers fixer (round 9, clearance c2, second fix pass)

Owner of this note: parsers (src/epinoic_logic/adapters/**, src/epinoic_logic/branches/**, tests/adapters/**, tests/adapters_history/**,
tests/branches/**). Everything below needs a change outside those paths. Each item names the finding, the file and function, what to change,
and the regression test that shows it. Reproductions use the recorded c2 round (`clearance/c2/specialists/<task>.json`) delivered through
`RouterHub` as `tests/branches/test_c2_clearance_parsers.through_hub` does.

## 1. Channel / core: `src/epinoic_logic/channel/request_parser.py`

### 1a. Spanish word bounds (c2 results-audit "Language B request not made explicit", communication-fidelity E7, adversarial-live bug 21; critical)
- Still reproduces: `extract_constraints(<sp-t15 question>)` returns `[]` for "Escribe entre 450 y 600 palabras." (sp-t15 genuine record).
- Change: read the Language B bound phrasings, keyed by the request's language or simply alongside the English ones:
  `entre N y M palabras` (min N, max M), `un mínimo de N palabras` / `al menos N palabras` (min), `como máximo N palabras` /
  `no más de N palabras` / `un máximo de N palabras` (max), `unas N palabras` / `alrededor de N palabras` (the approximate bound, as
  "about N words"). French at least `entre N et M mots`, `au moins N mots`, `au maximum N mots`, `pas plus de N mots`, `environ N mots`.
- Tests: sp-t15's question gives min_words 450 / max_words 600; the sp-t15 article cut to about 250 counted words draws INT-REQ-005;
  the genuine sp-t15 (499 words in the body) draws none.

### 1b. Spanish task imperatives (same finding)
- Still reproduces: `extract_items(<sp-t15 question>)` gives one item, the English meta-instruction.
- Change: read Spanish task verbs as item imperatives (`Escribe`, `Redacta`, `Explica`, `Describe`, `Compara`, `Analiza`, `Propón`, and the
  subjunctive after `que` / `en el que`: `expongas`, `propongas`, `expliques`, `describas`, `compares`, `analices`, `justifiques`).
- Test: sp-t15 has items for "expongas las ventajas y los inconvenientes del turismo" and "propongas dos medidas"; the genuine Spanish
  article addresses both (coverage by presence of a model text in the target language, not English word overlap: see 1c).

### 1c. Meta-instructions are no items (c2 results-audit "meta-instructions become items", communication-fidelity E7a; minor)
- Still reproduces: sp-t15 genuine receipt carries `INT-REQ-004 request item i1 appears unaddressed: 'Paper 1 writing practice: please skip
  the plan and write the full model text in Spanish.'`.
- Change: read "skip the plan", "write the full (model) text in <language>", "write it in <language>", "no plan" and similar form
  instructions as no item (or as addressed by a model text in that language). `bus._coverage`: a Language B deliverable is covered by its
  presence (the reply is a text in the target language), not by English word overlap.
- Test: sp-t15 genuine, no INT-REQ-004.

### 1d. Nested part labels (c2 results-audit "request items", communication-fidelity E6; minor and major)
- Still reproduces: ge-t15 genuine receipt carries INT-REQ-004 x3: i1 '(a)', i2 '(i) Calculate the change ...', i3 '(ii) Calculate the
  amount ...', although the answer answers them under '(a)(i)' and '(a)(ii)'.
- Change: a bare part label followed by sub-part labels ('(a) (i) ... (ii) ...') is the parent of the sub-items, not an item of its own;
  `bus._coverage` matches the answer's combined labels '(a)(i)', '(a) (i)', 'a(i)', 'a)(i)' against the sub-items.
- Tests: E6a ge-t15 genuine (no INT-REQ-004); E6b the same with the '(a)(ii)' block removed names item (ii).

### 1e. An approximate bound is a warning (c2 results-audit "about N words bounded ±10% at error level"; minor)
- Still reproduces: 'Keep to about 300 words' is max_words 330 at error level.
- Change: a breach of a bound read from "about / around / roughly / approximately N words" is INT-REQ-005 at warning level.
- NOTE for the merge: `tests/branches/test_c2_clearance_parsers.py::test_en_t15_the_assumption_and_the_note_are_no_words_paragraphs_or_thesis_of_the_answer`
  (parsers-owned, first pass) asserts that en-t15 lengthened by 110 words draws INT-REQ-005 **at error level** under "Keep to about 300
  words" (its last assertion). That assertion pins the behaviour this finding calls wrong. When 1e lands, that one assertion must change to
  "named at warning level" (the finding's rule, not a weakening); the parsers owner agrees to that change and will make it in the next
  pass if it is not made with 1e. Nothing else in the parsers' tests depends on the severity of an approximate bound.

## 2. Channel / core: `src/epinoic_logic/channel/bus.py`

### 2a. One fault reported once (c1 results-audit#21 + stem-integration#29, merged; critical, remainder)
- The la-3 Model sentence no longer draws CORE-SRC-006 (fixed in the first pass; tests: `test_the_writers_own_model_sentence_draws_no_source_error_and_no_copy`,
  and the stricter `tests/branches/test_c1_clearance_parsers.py::test_a_model_line_of_the_writers_own_words_is_no_quotation...`). The finding's
  second part stays open in the channel: every branch error is still copied as `INT-SUBJ-003 [<branch>] <code>: <message>` beside the branch
  finding itself, so one fault is reported twice (seen on the ll-p9a probe: `CORE-SRC-005` and `INT-SUBJ-003 [english] CORE-SRC-005`).
- Change: do not add an INT-SUBJ-003 copy of a branch error that the receipt already carries with the same claim ids, or merge the two
  into one finding.

### 2b. A three-word quotation with only a function word held is no altered quotation (found while verifying; not in the list)
- `_uncredited_quotations`: `0 < len(miss) <= 2 and len(miss) < words and words >= 3` makes "wind of change" (round-6 hi-t12, no text
  supplied) an altered quotation of the request because the request holds 'of': `INT-REQ-003 ... the request holds all of its words but
  'wind', 'change' (an altered quotation)`. Predates the first pass (it is at HEAD).
- Change: require the held words to include at least two words of four letters or more (or at least half of the quotation's words), as
  `adapters.sources._aligned_changes` requires for its aligned reading.
- Test: r6 hi-t12 (`tests/branches/r6_texts.HI_T12`, `HI_T12_Q`) delivered on the History branch draws no INT-REQ-003; the ps-t14 control
  ("makes his heart race and his handsly sweat") stays INT-REQ-003.

## 3. Integration: `src/epinoic_logic/integration/compat.py` (subject map) and its COMPATIBILITY pin

### 3a. Geography and Language B branches (c1 stem-integration#35 and c2 stem-integration "c1 #34"; major)
- Still reproduces at the routing level: ge-t15, ge-p9c, sp-t15 route to `generic`. The subject map (`_SUBJECT_MAP_JSON`) names
  `"branch": "generic"` for Geography and Language B: Spanish, and `integration/preflight.py` refuses (KIT-HS-010) any registry whose
  routing differs from the map; the map's sha256 is pinned in COMPATIBILITY. So a parsers-only change of `branches/registry.py` would
  break preflight and its tests.
- What the parsers side already gives these subjects on the generic branch (no routing change needed): Geography's worked arithmetic,
  clock times and SI-unit working are decided (first pass and this pass: `worked.clock_problems`, the coherent-unit worked reader, the
  case-label pair reader), every figure taken from a supplied table is checked (this pass: `branches/grounded_figures.py`), and the
  Spanish note, self-report and narrated-check lexicons are read on every branch (`adapters/markdown.py`).
- Change needed to give them branches of their own (decisions D9/D10 of the map are pending): add map rows naming new branch keys
  (`geography`, `language_b`) and re-pin the map; then the parsers owner adds `SubjectBranch(key="geography", profile_keys=("geography",),
  packs=(CORE, GeographyPack()))` and `SubjectBranch(key="language_b", profile_keys=("language_b",), ...)` with routing tests. Until the
  map changes, the registry must keep routing them to `generic`.

## 4. Overseer: `overseer/src/epinoic_overseer/emitted.py` and the knowledge pack

### 4a. CORE-SRC-002 per claim (c1 adversarial-live#22, c2 adversarial-live bug 22; minor)
- This pass adds a per-claim CORE-SRC-002 naming each claim that states precise real-world figures no supplied text and not the request
  holds ('about 262 million people worldwide have asthma, and 455,000 people died of it last year'). It is raised at **info**, the
  severity the code table and the knowledge pack hold for CORE-SRC-002. The findings ask for a warning: raising it at warning needs
  `("CORE-SRC-002", "info")` in `_BRANCH_ROWS` to become `"warning|info"` and the pack's code list updated (the code-table test
  `overseer_tests/test_integration_codes.py` scans the translator's emission sites). If that lands, change the one severity literal in
  `branches/packs.py::_unsourced_world_figures`.

### 4b. New formal check kind `supplied_figure` (c2 adversarial-live bug 16; major) - for information
- `branches/grounded_figures.py` adds FormalChecks of kind `supplied_figure` (a figure taken from a supplied table or text against its
  cell). A failure is INT-SUBJ-001 (error; a figure credited to the table, or one stated with its row and year) or INT-SUBJ-004 (warning;
  an ambiguous cell, or a figure of a supplied text's prose restated with another value), carrying `defect="source_mismatch"`. No new
  code; the overseer needs no table change unless it keys on check kinds.

### 4c. The History parser now takes the request text - for information
- `HistorySpecialistAdapter` declares `accepts_request_text = True` (c1 results-audit#27): the channel passes the request, and a body
  analysis sentence that states a position on the request item's own question in the item's words is roled `judgement`. Any re-parse of a
  History report (the overseer's `check_reparse`, `scripts/arena/list_claims.py`) must pass the same request text, as both already do for
  any parser declaring `accepts_request_text`; a re-parse without it can role those sentences `analysis`.

## 5. Arena replays (information for whoever reads the c2 replay)
- On the current tree the recorded c2 syntheses of en-t15 and lit-t15 draw INT-LEDGER-001 (unknown source claims `p3-point`, `p2-point`)
  and INT-LEDGER-003: the first pass made those answers' note paragraphs ('Assumption: ...', 'One note: ...', 'One correction for your
  planning: ...') notes with their own ids, so the recorded syntheses cite ids of the old parse. A live combinator cites the new ids; the
  replay error is an artefact of replaying a synthesis recorded against the earlier parse, not a parser fault.

## 6. Integration kit: fixture-verifier parity is fragile to a newly eligible claim without a fixture (information; not triggered now)
- While this pass briefly roled the synthetic corpus's hi-s1 h1.4 ('Historians still debate how far the treaty, rather than the
  hyperinflation, explains ...') as a judgement (it is now excluded as a reported view), `tests/integration/test_fixture_parity.py`
  failed: the kit's fixture verifier (`integration/sim/fixture_verifier.py`, `integration.verifier.FixtureCorpus`) gave hi-s1
  ACCEPTED_WITH_FINDINGS with INT-REQ-006, while `run_arena.run_round` gave ACCEPTED, so the two fixture providers treat an eligible
  claim that has no recorded fixture differently. The parsers no longer make that claim eligible, so the suite passes; the divergence
  itself is the integration owner's to look at (it will show again whenever a parser change makes a fixture-less claim of the synthetic
  corpus eligible).

## 7. Suite failures seen in the parsers' final run that are not the parsers' (information)
Full suite on the final tree (one run, 1:30 h): 4 failed, 24133 passed, 23 skipped, 45 deselected, 1 xfailed. Re-running the three
failing files alone: the two `overseer_tests/test_rebuild_merged_translator.py` cases (circularity agreement and same-quantity, an
`arithmetic_fact` premise read 'undecided' where 'own_kind' is pinned) passed, so they were another fixer mid-edit. Two remain:
- `overseer_tests/test_stem_completion.py::test_every_recorded_stem_receipt_is_the_image_of_its_re_derivation[maa-t13]`: the r7 maa-t13
  receipt carries 14 signed formal checks where `STEM_TASK_CONTENT` pins 16. All 14 are STEM front-end checks (stem-alg, stem-sub, stem-eq,
  stem-sol); the two missing look like the result restatements 'a = 0 m s⁻²  A1' and 'Distance travelled = 8 m  A1' (stem-res). With
  every SI-relevant change of the parsers' second pass switched off (the pair case labels, the narrated self-check, the single-quote frame)
  the count is still 14, and no core (quant or chronology) check is among them: the STEM owner's (`src/epinoic_logic/stem/`) to look at.
- `overseer_tests/test_subproject_layout.py::test_a_translator_without_a_name_this_release_imports_is_refused_at_import_with_one_clear_error`:
  the fresh interpreter it starts cannot import `epinoic_overseer` (ModuleNotFoundError) in this environment, where the overseer is only on
  the test session's path; environment, not code.
