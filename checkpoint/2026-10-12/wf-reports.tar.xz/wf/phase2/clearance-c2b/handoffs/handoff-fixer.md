# Round-9 clearance c2b: what the handoff fixer left to other owners

Working tree of the second fix pass, nothing committed. Every item below still reproduces or waits for a decision; each names
its owner and what is needed. Measured on the current tree on 14 Nov.

## Decisions needed before code (no change made here)

1. **Geography and Language B branches** (parsers handoff 3a, major). ge-t15, ge-p9c and sp-t15 still route to `generic`. The
   subject map (`integration/compat.py`, `_SUBJECT_MAP_JSON`, sha256 pinned in COMPATIBILITY) names `generic` for both, and
   preflight refuses (KIT-HS-010) a registry that differs. Needs decisions D9 and D10, then new map rows, a re-pin, and the
   parsers owner's `SubjectBranch` entries with routing tests.
2. **Plain spaces as thousands separators** (STEM handoff 5; critical sub-cases by design). The STEM owner and the overseer owner
   decide whether '6 000 000 bytes' reads whole. If yes: the overseer changes its gate-1 example (`test_gate1_overseer_fixes.py`,
   'The total is 1 500 × 2 = 30.') in the same commit, and the STEM owner restores rule spaced-thousands and rewrites its three
   withholding tests to the stricter rule.
3. **CORE-SRC-002 at warning** (parsers handoff 4a, minor). `_BRANCH_ROWS` holds `("CORE-SRC-002", "info")` and the knowledge pack
   (2.1, digest-pinned) teaches info. Needs a new pack version (overseer owner), then one literal in
   `branches/packs.py::_unsourced_world_figures`.
4. **A cap reason for a step input from the previous line** (core handoff 5, minor; maa-t15 m7.3 ARG-CIRC-002). `cap_reason` is a
   closed vocabulary the pack's D35 teaches as exactly two reasons, and `docs/integration-contract.md` lists them, so a third
   needs a new pack version and a contract update. Note that a capped diagnostic still blocks release (D35: the effective
   severity is the higher of `severity` and `capped_from`), so the cap removes the receipt's INT-ARG-001 accusation only. Then
   `translate/diag_core.claim_diagnostics` caps ARG-CIRC-002 at info when its first assertion id is a premise
   `restatement._previous_line_step` exempts.
5. **"About N words" breaches always at warning** (parsers handoff 1e). This conflicts with the pinned round-5 and round-8 rule (a
   gross miss of an "about N" bound is an error; `overseer_tests/test_c1_handoff_bounds.py` pins it). The c2 en-t15 instance no
   longer reproduces (no word-bound INT-REQ-005 on it). Changing the rule is the channel and overseer owners' decision.

## Harness (`scripts/arena/`)

6. **Mutated claims are never translated** (STEM handoff 3b, major). `list_claims.py --mutations` does not exist. A listing alone
   would not close the finding: `run_arena.make_verify_fn` serves one fixture per claim id, bound to one text digest, so a
   translation of a mutated claim (same id, other text) has no place in a translations file. Needed: a per-variant fixture
   format (for example `variants: {kind: {claims, claim_text_sha256}}`) that `bind_translations.py --listings` binds and
   `make_verify_fn` serves by the text's digest in the mutations pass. Then the listing replays each variant's own hub task
   (the peer's genuine report first for a peer-dependent task, ids qualified only against that peer) and is tested against what
   `run_round` serves.
7. **Fixture binding of supporting claims** (overseer handoff 4, minor; c2 ll-t15 altered_quotation p1-point). Binding a recorded
   translation to its supporting claims' texts changes what the replay serves on the recorded rounds. A refusal reported under
   the claim's own digest would name the wrong text as changed, so the harness owner decides how the refusal is reported.

## Owners' follow-ups from this pass's measurements

8. **ps-p8d (c1) under the judgement-label rule** (STEM handoff 1a applies the rule on every branch). The essay's opening
   'Judgement: ...' (g1.1) and closing 'Conclusion: ...' (g5.1) are now material judgements. ARG-BARE-001 names each as a bare
   assertion (two INT-ARG-001 warnings on the genuine receipt), because each stands alone in its paragraph and the reasons are
   in the other paragraphs. g5.1 moves from ENTAILED to NOT_ELIGIBLE (judgements are not translated). Functional counts do not
   move (203 of 203). Who acts: the argument-diagnostics owner (the rule's section is the paragraph) or the parsers owner (a
   labelled judgement alone in its paragraph gets no supports, since `_backward_conclusions` never links a later claim).
9. **A unit whose first word carries an exponent** ('7.0 dm³ min⁻¹', '21 m³ s⁻¹') is still read by its first word, a truncated
   unit that keeps a dimension. Reading it whole was measured: bi-t15 s3.2 and s3.3 then become INVALID_FORMALIZATION through
   the exactness rule (the written calculation '0.50 dm³ × 14 min⁻¹ = 7.0 dm³ min⁻¹' makes 7.0 exact, and the recorded
   encoding widens it). So it was left as before, for the translate owner to decide with that rule. The docs
   (`docs/ARGUMENT_DIAGNOSTICS.md`) say so now. Their old example "21 m³ s⁻¹" read whole was never true of the code.
10. **An altered quoted label** (maa-t15 'Let E be "at least one blue"'). The core pack reads it as a mention (rule quoted-label),
    while the channel's `_uncredited_quotations` still reads its alteration as an altered quotation of the request (INT-REQ-003,
    error). The harness now expects INT-REQ-003 for an altered quotation of the request's own words (`alters_request_words`).
    Whether the channel should read a quoted label as a mention too is the channel owner's decision. If it does, the
    altered_quotation mutation must also skip labels, or it injects nothing.
11. **Duplicates for contests no check can decide** (overseer handoff 11, minor; flash-router `pool.py`, `planner.py`). Not
    changed: the arena workflow plans the duplicates.
12. **Roles left as they were** (STEM handoff 1c, remainder). The framing remark 'Practice answer for the Paper 2 Section A
    question.' stays supporting. Noun-phrase headings ('Sucrose molecules in 1.00 cm³ of the most dilute solution') are not
    roled `other`. This pass read only the question-worded titles, check lines and notation lines; a reading of noun-phrase
    headings by their words alone risks demoting content lines and was not attempted. Left to the parsers owner.
13. **Environment, not code.** `overseer_tests/test_subproject_layout.py::test_a_translator_without_a_name_this_release_imports_is_refused_at_import_with_one_clear_error`
    fails here because its fresh `python -I` interpreter cannot import the overseer, which is not installed in this
    environment. The check itself was verified with the overseer on the path: it refuses with `TranslatorIncompatible`
    naming `api.channel.FEEDBACK_KEY_ID`.
14. **Deferred performance item.** The quotation readers of the ledger and the port take about 1 to 2 CPU s per call on a maximal
    hostile synthesis. Measurements and the proposed optimisation are in `performance.json` beside this file.
