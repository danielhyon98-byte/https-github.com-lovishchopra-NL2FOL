# Handoff from the overseer fixer (round-9 clearance, second fix pass c2b)

Written 13 Nov by the owner of `overseer/**` and the `docs/OVERSEER_*.md` stubs. Each item names what is needed OUTSIDE those
paths, the evidence measured on the working tree of 13 Nov (other owners' first-pass edits included), and what the overseer
already did on its side. Nothing here asks another owner to loosen a rule; the overseer changed no file outside its paths.

## 1. Channel coverage: compound part labels "(a)(i)" (channel owner, `src/epinoic_logic/channel/bus.py` `_answer_sections` / `_coverage`)

- Evidence: c2 ge-t15 answers under "(a)(i) [1]", "(a)(ii) [2]", "(b) [3]", "(c) [4]"; the request's items are "(a)", "(i) Calculate ...",
  "(ii) Calculate ...", "(b) ...", "(c) ...". `_answer_sections(ge-t15)` returns only `[(646, {'b'}), (1439, {'c'})]`, so the part-label
  coverage leaves items (a), (i) and (ii) unaddressed (method `part_label`) and the receipt carries three false INT-REQ-004 warnings.
- Effect: rebuilding the c2 feedback on the current tree (`scripts/arena/revision_feedback.py` on a copy) still issues ge-t15 a revision
  request "This part of the task appears unanswered: (a) ... Answer it" three times (c2 communication-fidelity bug 11, critical: "a coverage
  warning the channel labels (heuristic) is advisory"). The overseer's rule feedback-hold holds INT-REQ-004 only when every unaddressed
  record is `lexical_heuristic` or the answer declines; a `part_label` record is the channel's deterministic reading, so the overseer does
  not second-guess it.
- Needed: read a compound label "(a)(i)" (and "(a) (i)", "a(i)", "(a)(ii)") as addressing every label it names, the parent "(a)" and the
  sub-part "(i)", in `_answer_sections`; regression test with the recorded ge-t15 answer (no INT-REQ-004) and a control (an answer labelled
  "(a)(i)" only leaves "(ii)" unaddressed). Note: the INT-REQ-004 message says "(heuristic)" for `part_label` records too
  (`bus.py` ~2328); say "(part labels)" there, or the advisory reading the lens asks for cannot tell the two apart from the text.

## 2. Channel INT-REQ-008 on ess-p9c (channel or parser owner)

- Evidence: the rebuilt c2 feedback still sends ess-p9c "This part of the task asks for a judgement (evaluate), and the answer states none:
  (d) ..." (c2 bug 11 lists it as false: "ess-p9c INT-REQ-008 (the judgement demoted)"). The receipt's INT-REQ-008 rule needs a claim roled
  `judgement`, or a point/thesis/link/analysis claim with a verdict cue; the parser roles ess-p9c's evaluation otherwise.
- Needed: the parser's role (or the channel's verdict cue) for ess-p9c's (d) judgement; regression test with the recorded answer.

## 3. The coverage-gap reading waits for the translator's arena test (`tests/e2e/test_arena_deliveries.py`, its owner)

- c2 results-audit bug 9 (minor): a COUNTEREXAMPLE carrying the engine's W110/W111 (ch-p9b s5.3, lit-t15 p1-point) should be unresolved in
  the fallback's accuracy, not a refutation. The overseer names the warning beside the refutation (rule coverage-gap, recorded only) and
  cannot read it as unresolved yet: `test_a_refuted_answer_is_withheld_with_its_score` and
  `test_the_pass_never_goes_through_a_replaced_verifier` pin, as "the refuted answer", the History fixture `_fixture("h1.1")` of
  `tests/e2e/test_arena_measures.py`, whose conclusion `largest_city ∧ near_million` has `near_million` constrained by no premise (W111).
- Needed: give those two tests a genuine refutation (for example a premise `not near_million`, label "London had nowhere near a million
  inhabitants", so the counterexample constrains every conclusion symbol and carries no W110/W111), keeping their assertions. Then the
  overseer changes `delivery_policy._assess_claim` (a COUNTEREXAMPLE whose signed result carries W110/W111 is unassessed with the evidence,
  never `refuted_by_signed_result`) and its test `test_clearance_c2_overseer.py::test_a_counterexample_with_a_coverage_warning_is_named_on_the_refutation`
  in the same change.

## 4. Fixture binding of supporting claims (arena owner, `scripts/arena/run_arena.py`)

- c2 results-audit bug 10 (minor): in ll-t15 `altered_quotation` the recorded translation of p1-point is served though the answer now quotes
  'whichly is to say'; its premise excerpt 'which is to say' is verified against the supplied text, so nothing names the stale translation.
- Needed: bind a recorded translation to the texts of the supporting claims whose quotations its premises' excerpts carry (or to the
  digest of every excerpt it grounds), as it is bound to its own claim's text, and refuse it (STALE_FIXTURE_REFUSED) when one changed.
- Not done on the overseer side, on purpose: tracing every premise excerpt to the ANSWER (not the supplied text) would name faithful
  translations that quote the task or a supplied text for a fact the claim reports in its own words (rule task-quotation, c2 ess-t15 and
  cs-t15).

## 5. One fault, two INT-SUBJ-003 errors (channel owner `bus._branch_checks`, together with the overseer's `checks/formal._structural_implied`)

- Lu/handoffs#3 (minor): CORE-SRC-005 and ES-SRC-008 for one misattributed quotation give two INT-SUBJ-003 errors. The overseer's R2
  recount requires exactly one INT-SUBJ-003 per error-level branch finding (same claim set, its code in the message), so it must change in
  the same commit as the channel. Needed from the channel: the grouping rule (which key: the excerpt and the claim ids, or the excerpt
  alone, since CORE-SRC-005 names [p1-q01, p1-s01] and ES-SRC-008 [p1-q01]) and the message form ("[branch] CODE1, CODE2: ..."). The
  overseer owner then re-derives the same grouping in `_structural_implied` (exact match, never "a superset of the claims", which would
  let a dropped INT-SUBJ-003 hide behind another) and updates the pinned INT-SUBJ-003 tests to the grouped rule.

## 6. maa-t13's STEM checks (STEM owner, `src/epinoic_logic/stem/relations.py`, rule stated-condition)

- The 12 Nov baseline record (major): `overseer/tests/overseer_tests/test_stem_completion.py::test_every_recorded_stem_receipt_is_the_image_of_its_re_derivation[maa-t13]`
  still fails on the current tree: 14 formal checks where 16 are pinned (codes unchanged, {'ST-UNDEC-001'}). The two missing checks are
  m2.5's '0 ≤ t' and 't ≤ 3' of "Both values lie in 0 ≤ t ≤ 3.", which rule stated-condition now reads as a condition on t and checks
  nothing, with no named reason ("nothing recognised is dropped silently", README).
- Needed (the STEM owner decides): check the values the sentence refers to against the interval (ENTAILED), or record the relation
  undecided with a named reason (an ST code on m2.5); keep stated-condition for real conditions ("need Δ > 0"). The overseer owner then
  re-pins `STEM_TASK_CONTENT['maa-t13']` with that reason in the test. The contained gate's other part (physics-translation probe) is fixed
  on the overseer's side (rule stated-squares: a quotient over a square needs the root written); the full STEM probe run gives gate ok,
  677 of 677 counted, none failing.

## 7. The task-record path of the translator's circularity test (translator owner, `tests/channel/c1_core_support.py`)

- The merged c1 record (critical) notes that `tests/translate/test_c1_clearance_core_translate.py::test_the_circular_c1_translations_are_withheld_never_displayed_entailed`
  passes only because `c1_core_support.deliver`'s verifier is called without the task record (`_fixture_verifier`: "served ... without
  the task record"). On the harness (task record given) the current tree gives: bi-t14 s1.2 INVALID_FORMALIZATION (E112); bi-t14 s4.7 and
  ph-p8b s1.1 ENTAILED. The overseer now reads s4.7's 'task-both' and s1.1's 'k-task' (arithmetic facts the request states for the
  quantity they name) as undecided data (rule task-figures: OVS-TRN-011, a warning), so receipt and audit agree on all three.
- Needed: a translator test that delivers these three claims through a verifier taking `task=<TaskRecord>` (as `run_arena.make_verify_fn`
  does) and pins their display statuses as above.

## 8. Stale test paths in `tests/README.md` (its owner)

- p5060d (minor): `tests/README.md` cites `tests/overseer/test_rebuild_rekeyed_r7.py` (now line ~264; also `tests/overseer/...` at lines
  ~214, 223, 237); the files are under `overseer/tests/overseer_tests/`. Line 13's mapping note explains the old prefix, but the push check
  asks for the moved paths. The OVERSEER_RESULTS.md part of p5060d is done (it names the measured tree as it exists on this branch).
- q215b's `tests/README.md` lines ~678 and ~712 ("renamed, their assertions unchanged"): the overseer's own docstrings now say the rename
  left the assertions as rewritten to the stricter rule; the README's two sentences should say the same.

## 9. An observation for the parsers' owner (not a finding of this round's list)

- With the current parsers the English and generic branches set note paragraphs ("Next step: ...", "Note: ...") aside without a claim of
  role `other` (before, such a paragraph was an `other` claim). The overseer's parse-loss check (OVS-FID-006, warning) then names each
  such sentence as "response content no claim carries" on genuine answers: c1 en-t14, en-p8c, lit-t14, ll-t14 and c2 en-t15, lit-t15 on
  the current tree. Either keep notes as `other` claims (the contract's way of carrying text that is no claim of the answer), or tell the
  overseer owner that dropping them is intended, so OVS-FID-006 can read the parser's note leads as deliberate (a reading the overseer
  would add only with its own adversarial tests: a note lead must not hide content from the parse-loss check).

## 10. Compound units in the translator's quantity reader (translate owner, `src/epinoic_logic/translate/quantities.py` `_figure_unit` / `_reading_conflict`)

- c1 translation-fidelity #7, OVS-TRN-004/005 part (major, not critical): still reproduces on the current tree. The c1 delivery audit of
  ess-t14 s2.1 (and s3.1 ...) says: "task ess-t14 characters 346-362 ('2.5 × 10⁴ kJ m⁻²') states 2.5 × 10⁴ kJ m⁻², a kg s^-2; the
  symbol is declared in a unit of kg s^-3": the reader keeps at most two unit tokens and drops 'yr⁻¹'.
- Needed (as the record says): read a compound unit of three or more tokens ('kJ m⁻² yr⁻¹', 'kJ m⁻² s⁻¹', 'per year'); when a further
  unit token follows the two read, report no dimension conflict from the truncated unit. Controls: a unit that really differs stays a
  conflict. The overseer's side of the record is done (rule years-months: bm-p8a g8.2's 48, 117/2 and 119/2 traced; ch-t14 s3.20's −819
  still named, re-measured on the current tree).

## 11. Duplicates for contests no check can decide (flash-router owner, `flash-router/src/epinoic_flash_router/pool.py`, `planner.py`)

- c2 communication-fidelity #22 / c1 #22 (minor): the router advises duplication for agreement (`agreement_risk`, `agreement_advised`)
  on contested transfers whose groups no check decides, and the overseer's combination counts no agreement (no voting), so duplicates
  resolved 0 of 7 contested transfers by construction. Needed: route a contest whose kinds no check decides (`translation_unfaithful`,
  `other`) to the human-review queue and spend duplicates only on groups a check can decide. The overseer's side (the recorded-reply
  transport, so arena verdicts are runner-attested) is done; running the agents through it is the workflow's change.

## 12. For the packs owner: hi-t14's new CORE-QNT-001 reached an overseer test (no change asked, a notice)

- Between 17:01 and 17:07 on 13 Nov a change to `src/epinoic_logic/branches/packs.py` / `quant.py` made the recorded c1 hi-t14 answer
  carry CORE-QNT-001 on h1.12 ("A war of three years and one month ... a stated length of time whose dates cannot be paired: the
  paragraph dates the beginning of the war (25 June 1950) but neither this sentence nor the paragraph states its end"). The delivery
  policy's formal path then names that unchecked working beside the 6b rules, and
  `overseer/tests/overseer_tests/test_c1_push_check_round4.py::test_the_recorded_answers_the_6b_rules_alone_keep_off_the_label[hi-t14]`
  failed. The overseer owner rewrote that case to require the 6b reasons as before and to allow, on hi-t14 alone, exactly that one
  other reason (or none, should the pack's finding go). If the CORE-QNT-001 on h1.12 is not intended, say so and the overseer owner
  restores the stricter pin.
