# Handoff from the harness owner (round-9 clearance, second fix pass c2b)

Written 13 Nov by the owner of `scripts/arena/**`, `docs/**` (except the STEM_ and OVERSEER_ documents), `README.md` and
`tests/README.md`. Each item names what is needed OUTSIDE those paths, the evidence, and the test that should come with it.

## 1. Integration (combinator port): render a quotation claim only inside the sentence that quotes it (c2 communication fidelity, minor; ll-t15)

- Still reproduces on the current tree. The deployed composer is `combinator_port.synthesis_payload`
  (`src/epinoic_logic/integration/combinator_port.py`, line ~385): `text = " ".join(c.text for c in out.claims)`. The arena
  relays the same text (`run_arena.group_synthesis`), so `clearance/c2/syntheses/ll-t15.json` hands the student each of its
  10 quotation claims twice: '"I learned to swim at the Corran Street Baths in 1989, ..."' as a stray fragment, then
  'The column opens with a memory rather than an argument: "I learned to swim ..."'.
- Not done in the harness on purpose: the arena must relay the text production relays. Composed differently in the harness
  alone, the arena would show a clean text while production keeps sending the duplicate. The harness now composes through
  `run_arena.student_facing_text`, which calls the port's composer whenever the port defines one (`run_arena.PORT_TEXT_COMPOSER`
  = "student_facing_text") and otherwise joins with a space, exactly as `synthesis_payload` does today. So no harness change
  is needed after this item.
- Needed (integration owner): add `student_facing_text(claim_texts: Sequence[str]) -> str` to `combinator_port` and to its
  `__all__`: the claims' texts in order, joined by one space, leaving out each claim whose whole text is a quotation (the
  shape `integrity.ledger._WHOLE_QUOTATION_RE` reads, quotation marks normalised as `_QUOTE_MARKS_RE` does) that occurs, with
  its quotation marks, inside the text of ANOTHER claim of the same synthesis, before or after it. Linear in the total
  length (for example one dict of the quotation claims by normalised text, and one scan of each other claim). Use it for
  `text` and `text_sha256` in `synthesis_payload`. Every claim's text still occurs in the student-facing text (the hub's
  INT-LEDGER-017 presence check), and the text stays a composition of its claims (INT-LEDGER-031), so no hub rule objects.
- Tests (integration owner), with the ll-t15 claims: a quotation claim before the sentence that quotes it (p1-q01, p1-s02);
  two quotation claims before one sentence that quotes both (p2-q03 and p2-q04 before p2-s05); a quotation claim after the
  sentence (p3-q01 after p3-point); a one-word quotation ('"sink"' in p1-s03); and a control, a quotation no other claim
  holds, which stays rendered. `scripts/arena/test_arena_rules.py::test_the_arena_composes_the_student_facing_text_as_the_port_does`
  pins the parity between the harness and `synthesis_payload` and must keep passing (it does by construction once the
  function exists under that name and signature).
- Decide it together with item 2.

## 2. Integrity (core): rule duplicated-content reads the claims, not the text (c2 communication fidelity, minor; follows item 1)

- `ledger.contained_claims` names a whole-quotation claim only when the claim RIGHT AFTER it holds it, and the warning says
  "the student-facing text states their words twice". Measured on `clearance/c2/syntheses/ll-t15.json` (current tree): it
  names p1-q01, p1-q03, p1-q04, p1-q05, p2-q01, p2-q02 and p2-q04, and misses p2-q03 (held by p2-s05, two claims later),
  p3-q01 (held by p3-point, the claim before it) and p1-q02 ('"sink"', below the three-word floor).
- Needed: decide on the student-facing text. Name a whole-quotation claim whose quotation the text states outside every
  claim that holds it (held by any other claim, not only the next), so a text composed as item 1 asks draws no warning,
  and a joined text is named for every repeated quotation (the three-word floor may stay for the warning).
- Test: the c2 ll-t15 synthesis with the joined text (every repeated quotation named) and with item 1's composition (no
  finding).

## 3. Raw bidirectional controls in other owners' files (queued q215a, minor)

- My part is done: `scripts/arena/test_arena_rules.py` holds no raw control (first pass), and
  `test_no_file_the_harness_owner_keeps_holds_a_raw_bidirectional_control` now keeps every file of the harness owner free
  of them. A scan of the worktree on 13 Nov (U+202A to U+202E, U+2066 to U+2069; *.py, *.md, *.json) still finds:
  - `tests/channel/test_integration_gate1_synthesis_text.py`: lines 80, 82, 83 (U+2066), 85, 88, 89 and 116 (U+202E and
    U+2066): 8 controls (channel/core owner);
  - `tests/channel/test_revision_feedback_rules.py`: line 163 (U+202E and U+202C) and 166 (U+202E): 3 controls, newer than
    the record (channel owner);
  - `tests/stem/test_checks_safety.py:273`, `tests/stem/test_front_end_safety.py:101`, `tests/stem/test_si_reading.py:118`:
    one U+202E each (STEM owner);
  - `integration/vectors/combinator-port/output-text-with-a-bidi-override.json:86` and its copy
    `combinator/tests/vectors/combinator-port/output-text-with-a-bidi-override.json:86` (integration owner).
- Needed in the .py files: write each control as its escape in the same literal (\u202e, \u2066, \u202c); the values
  the tests see are unchanged (compare `ast.dump` of the file before and after).
- Needed for the vectors: they are generated. `integration/tools/vectors.py` `_dump` (line 44,
  `json.dumps(obj, indent=2, sort_keys=True, ensure_ascii=False)`) should write every U+202A to U+202E and U+2066 to U+2069
  as a JSON escape (replace each such character of the dumped text with \uXXXX; the parsed value is unchanged), then
  regenerate (`python integration/tools/vectors.py`, which writes both copies) and `integration/MANIFEST.sha256`, and
  check with `--check` (`tests/integration/test_vectors.py`).
- Then a repository-wide guard in the default suite (the harness owner's test covers its own files only and is run by path).

## 4. Channel README, the INT-REQ-005 row (queued q222c, minor)

- Still reproduces: `src/epinoic_logic/channel/README.md` line 201 still says the declined-bound record's detail opens with
  `DECLINED_BOUND_PREFIX` "and naming the declining sentence", and that "the transfer auditor accepts exactly that record
  exactly when `withheld_deliverable` reads a decline in the journaled response (rule declined-bound)". It omits the
  measurement the record states and the recount R2 requires.
- Needed (channel owner): replace that part of the row with: "... its detail reading `<DECLINED_BOUND_PREFIX> (<the
  declining sentence, cut to 160 characters>); measured N words|paragraphs; bound KIND VALUE` (the bound's own measure,
  unit, kind and value: `bus.py`, the not-applicable record). The transfer auditor (R2, rule declined-bound) accepts
  exactly that record exactly when `withheld_deliverable` reads a decline in the journaled response and the record's last
  '; measured N words|paragraphs; bound KIND VALUE' states the auditor's own recount in the constraint's unit, kind and
  value: a count other than the recount, or a detail that states none, is OVS-FORM-003 naming MEASURED (Decision 111),
  another unit, kind or value is OVS-FORM-003 too (round-9 clearance), and the same record on an answer that declines
  nothing is OVS-FORM-004 (Decision 96; design Decisions 96 and 111 of `overseer/docs/OVERSEER_DESIGN.md`,
  `overseer/src/epinoic_overseer/checks/formal.py` `declined_bound` and R2's recount)."
- Evidence: `bus.py` lines ~3261-3264 write the detail; `checks/formal.py` lines ~735-752 recount it (`_DECLINED_MEASURED_RE`).
  No test reads the row.

## 5. The overseer-selected fallback in arena rounds (c2 results audit, minor): what is left after the harness's part (overseer owner and the workflow; information)

- The harness's part is done (first pass, re-verified here): `run_arena.py --overseer-provider MODULE:FACTORY` runs the
  delivery pass's overseer agents through the package's runner and verdict intake (runner-attested), reports the decisions
  beside the withheld baseline, and says when the fallback was not exercised (`fallback_exercised`,
  `fallback_not_exercised`, `withheld_by_cause`). Tests: `test_an_overseer_provider_runs_the_fallback_beside_the_withheld_baseline`
  (OVERSEER-SELECTED at 2/2, withheld below the threshold at 1/2, labels honest) and
  `test_the_delivery_pass_says_when_the_overseer_selected_fallback_was_not_exercised`.
- Still not exercised by any recorded round: c1 and c2 hold no runner-produced verdict (c2: runner 0, self-reported 80),
  and the c2 replay on the current tree says "Overseer-selected fallback: NOT exercised ... no overseer agent is configured".
- Why recorded verdicts cannot simply be fed into a later replay: the delivery pass's dossiers carry fresh ids (uuid4
  message, receipt, result, outcome and translation ids) and timestamps on every run. Measured: two runs of one test round
  differ in 40 values of each dossier, and `receipt.formal_result_ids` changes order with the random ids, so a reply keyed
  by dossier digest never matches a later replay, and the intake rejects a verdict bound to another dossier.
- So a round exercises the fallback only when its overseer agents answer the delivery pass's own dossiers in the same run,
  through a provider (`--overseer-provider`); each decision's overseer stage has a 240 s budget. A replayable record of
  their replies would need deterministic dossiers (seeded ids and a fixed clock in the channel) or a re-binding of
  recorded verdicts by structure: the channel's and the overseer's design, not the harness's.

## 6. Notices (no change asked)

- STEM owner: `scripts/arena/test_arena_rules.py::test_a_mutation_of_the_second_stem_report_is_compared_with_its_genuine_record_claim_for_claim`
  failed on the current tree because this round's STEM fixes decide its work line ("W = F × d = 6.0 × d": stem-sub,
  ENTAILED), which left the answer no genuine warning to compare the mutations with. Its fixture was rewritten in this pass
  (a torque line added, "τ = F × r sin θ = 6.0 r sin θ", which the front end leaves undecided: ST-UNDEC-001 'a function of
  an unknown'); every assertion keeps its strength, now on s1.5. Should the front end later decide that line too, the test
  needs another line the front end leaves undecided (the fixture's comment names the line that carries the warning). Good
  news for the STEM side, not a defect.
- Handoff items other fixers addressed to the harness owner in this pass (overseer 4: binding a recorded translation to
  its supporting claims' texts; overseer 8: the moved overseer test paths in `tests/README.md`; STEM 3a: the bullet of a
  list-item STEM mutation site in `stem_mutations.py`; STEM 3b: `list_claims.py --mutations`) are not in this fixer's list
  and were not acted on in this step.
