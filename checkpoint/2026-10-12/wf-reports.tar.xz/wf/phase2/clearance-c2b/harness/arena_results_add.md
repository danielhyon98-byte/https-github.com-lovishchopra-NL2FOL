### Second fix pass (after the container replacement)

The first pass's edits were checked again on the restored tree before anything was changed.

- **The revision budget, checked again.** On the copy that the exercise checked (each feedback file's digest copied into
  its revision file), at the round's own code (HEAD's sources, exported to a scratch directory):
  - HEAD's harness re-issues none of the 15 requests identical. Each differs in `max_rounds` and the rendered digest,
    `feedback/summary.json` is compared as the feedback of a task named `summary`, and gate `feedback_as_read` fails.
  - This harness re-issues all 15 identical, under the budget each feedback file records (1). It names
    `feedback/summary.json` and does not compare it, and the gate passes. The other figures are the exercise's: 22
    answers checked, feedback on 15, 7 negative controls, 30 flaws fed back (18 fixed, 6 removed, 6 persisted), fix rate
    73.3%.
- **The overseer-selected fallback.** Unchanged since the first pass, and its tests pass. No recorded round can exercise
  it in a replay. c1 and c2 hold no runner-produced verdict, and a verdict written for one replay's dossier cannot be fed
  into another: the delivery pass's dossiers carry fresh ids and timestamps on every run (two runs of one round differ in
  40 values of each dossier). A round exercises the fallback only when its overseer agents answer the pass's own dossiers
  in the same run (`--overseer-provider`).
- **The student-facing text of a synthesis** (communication fidelity, minor). In ll-t15 the student reads each of the 10
  quotation claims twice. The combinator carries each quotation beside the sentence that quotes it, and the text is the
  claims' texts joined. The hub now names that synthesis (INT-LEDGER-017, rule duplicated-content, the core owner's
  fix). The harness composes the text exactly as the deployed combinator port does (`student_facing_text`: the port's
  composer when it has one, else the join that `synthesis_payload` writes), so the arena relays the text production would
  relay. Leaving the stray quotation out is a change of the port's composer, and it is handed to the port's owner; the
  harness then follows it with no change of its own. No record moves.
- **Raw bidirectional controls.** No file the harness owner keeps holds one, and a new test reads them all. The other
  owners' files still hold 16, in 7 files; they are handed to their owners.
- **A harness test rewritten in its fixture.** `test_a_mutation_of_the_second_stem_report_is_compared_with_its_genuine_record_claim_for_claim`
  relied on a work line that this round's STEM fixes now decide (stem-sub, ENTAILED), so the answer had no genuine warning
  left to compare. The answer now also states a torque line that the front end leaves undecided. Every assertion keeps
  its strength.

Measured at the end of this pass, on the working tree with the other owners' fixes in progress, on copies of the rounds
(the standard command; the overseer's two passes with the overseer importable):

| Round | Transport (functional) | Delivery pass | Revision pass |
| --- | --- | --- | --- |
C1_ROW
C2_ROW

No record of either round differs from the same tree's run before this pass's harness change (status, codes and functional
flag of every record).
