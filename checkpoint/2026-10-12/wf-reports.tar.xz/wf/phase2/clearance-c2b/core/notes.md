# core fixer c2b notes
F1  [crit] maa-t15 m5.3 eval point vs m7.1 (cross_check)  dup F14 F21  -> 1st pass test_c2 maa-t15 (check)
F2  [crit] hi-t15 '3)' INT-LEDGER-023 (ledger) dup F12 F15 -> 1st pass (check)
F3  [crit] decline/numbered step/framing note dropped (adapters roles + ledger 019) -> 1st pass framing-content (check)
F4  [min] INT-ARG-001 false: ch-p9b s13.2 HG, maa-t15 m7.3 CIRC, bm-t15 g7.3 FIG
F5  [min] INT-GLOSSARY-005 paraphrases dup F32 -> 1st pass (check)
F6  [min] unsupported links missed ps-t14 g2.4, hi-t14 h1.13 dup F38
F7  [min] CORE-SRC-003 'Let E be "at least one blue"' (bus)
F8  [min] INT-LEDGER-020 p9b locator-less excerpts -> 1st pass (check on recorded p9b)
F9  [min] ST-RANGE-001 (stem) -> not mine
F10 [min] ll-t15 duplicated content -> 1st pass (check)
F11 [crit] synonyms gloss (cross_check) -> 1st pass (check)
F13 [min] '[3]' after paragraph stripped (adapters) -> not mine; check parsers
F16 [maj] Spanish number words ledger -> 1st pass (check)
F17 [crit] E112 vs OVS-TRN-006 circular ENTAILED (ph-t15 s2.4, ch-t15 s13.1, maa-t15 m7.3, mai-t15 m10.1, ch-p9b s11.2, ge-p9c g3.1)
F18 [crit] unit=1 anchors; translator constants (ge-t15 g2.4..; ph-t15 s2.4, s3.3; ch-p9b s9.2)
F19 [crit] COUNTEREXAMPLE coverage (ess-p9c s4.1, ch-p9b s5.3, lit-t15 p1-point)
F20 [crit] clause-by-clause comparison (cs-t15 c6.6, ch-t15 s4.1, s15.4, ess-p9c s7.3, ph-t15 s7.4, ...)
F22 [min] exact results as intervals (precision)
F23 [min] spurious ambiguity flags
F24 [min] verbatim_match supplied_text content (ll-p9a p2-s10)
F25 [min] precision reader misreads
F26 [min] E112 step checks m2.4 m7.2
F27 [min] month/clock/LaTeX/Paper 1 -> partly 1st pass
F28 [min] introduced figures whole report dup F46 -> 1st pass (check ge-t14 g9.2)
F29 [min] precision marks [10] dup F45
F30 [min] E108 identity dup F47
F31 [min] 'task' doc id INT-HANDOFF-004 -> 1st pass (check)
F33 [min] partial_encoding wording dup F44
F34 [min] ARG-HG-001 definitional link ess-t15 s6.2
F35 [crit] tag characters -> 1st pass (check)
F36 [crit] response length limit -> 1st pass (check), overseer side handoff?
F37 [min] EVD-LACK-001 'only'
F39 [min] narrowing exact (dup F22)
F40 [min] input_precision flag (dup F23)
F41 [min] only while / dropped values / neighbour (F20)
F42 [min] short quoted phrase placeholder
F43 [min] translated quotation warning
F48 [perf] withheld_deliverable x3 -> defer performance.json
F49 [maj] feedback.py evaded revision
F50 [maj] pyproject z3 range -> not mine (handoff)
F51 [min] E303 nesting before pydantic (ir)

## status (13 Nov, 20:45)
first pass verified (no longer reproduces): F1/F14/F21, F2/F12/F15, F3 (ledger side), F5/F32, F8, F10, F11, F16, F17 (4 of 6; m7.3/m10.1 step checks), F18, F19 (ess-p9c s4.1, ch-p9b s5.3), F20 (ch-t15 s15.4), F27 (months/clock/LaTeX), F28/F46, F31, F35, F36 (channel/cli)
other owners fixed: F9 (stem), F13 (parsers)
this pass: F19 lit-t15 (UNENCODED_SUPPORT); F20 neighbour_content/qualifier_not_encoded/reason_unconnected/reported_conclusion (+ll-p9a via F24); F24 absence rule; F26 previous-line-step; F27 Paper 1 named items; F33/F44 partial_encoding non-content parts; F34 definitional majority; F37 quoted-word convention; F42 short quotation said; F4 bm-t15 g7.3 worked chain; F49 channel INT-REV-002 weakened named claims; F51 nesting bound
handoff: F7 packs, F49 overseer escalation, F50 pyproject, F17/F26 overseer agreement, F4 m7.3 named.py cap, F36 overseer readers
left undone: F4 (m7.3 needs named.py cap; s13.2 'each'), F6/F38, F20 c1 cs-t14 c25.1, F22/F39, F23/F40, F25, F29/F45, F30/F47, F41 (g8.7 converse, c25.1), F43
deferred perf: F48
harness after3: c1 203/203, c2 188/188 (= base)
