# progress c3j prompt (owner R3)
- step 1 DONE: read memo (whole), c3b design 3-3.13, dev-positive/negative rows
- step 2 in progress: writing src/epinoic_logic/selfcert_label/prompt.md (examples all original)
- next: freeze, measure length, timing tests (with tests/branches in parallel)
- step 2 DONE: prompt.md written and FROZEN (copy prompt.frozen.md in c3j); do not edit it again
- step 3 in progress: timing tests (4 named files) with tests/branches in parallel
- step 3 DONE: 4 timing files 332 passed under tests/branches load; headroom min 46% (growth ratio 4.33/8), shapes 55.5%, selfcert linear 65%, sweeps >=71%: no finding
- step 4: waiting for the tests/branches load run to finish, then StructuredOutput
- step 4 DONE: branches load run finished; task complete, returning StructuredOutput
