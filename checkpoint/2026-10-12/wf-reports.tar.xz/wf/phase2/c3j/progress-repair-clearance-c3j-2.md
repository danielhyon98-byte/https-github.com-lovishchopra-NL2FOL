# repair clearance-c3j 2 progress
- [done] cause confirmed by reading: conftest copies populated memo; memo key (stored state of names resolved under patched _HERE + absolute real dirs) matches the real tree when copy is made by copytree (copy2 keeps mtimes) -> stale closure
- [in progress] fix: tests/selfcert/conftest.py gives each test an EMPTY memo (no reader change); then run failing test alone, its file, and tests/selfcert + selfcert_label, plus identity test file
- [done] conftest empty-memo fix applied; probe wf/phase2/c3j/probe2/stale_memo.py confirms (copied memo: digest unchanged; empty: changed); failing test alone pass; fold_table+c3e_check+c3f_check+c3e_holds: 1106 passed
- [in progress] tests/selfcert + tests/selfcert_label in one process -> /tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/wf/phase2/c3j/selfcert-repair2.log
- [found] tests/selfcert_label/test_linear.py::test_a_200_kb_hostile_answer_through_build_input[short sentences] ratio 6.36>6 in selfcert+label run (small median 0.048, large 0.318); profiling build_input growth
- [done] fix 2: scope.own_scope pauses cyclic GC from 4096 chars (reader's pattern); growth probe probe2/grow.py: 25/50/100/200/400 kB min CPU 0.023/0.048/0.101/0.188/0.382 (was 0.023/0.050/0.097/0.222/0.473); label pin re-pinned to 84926593... in test_identity.py
- [in progress] rerun tests/selfcert + tests/selfcert_label -> selfcert-repair2b.log
