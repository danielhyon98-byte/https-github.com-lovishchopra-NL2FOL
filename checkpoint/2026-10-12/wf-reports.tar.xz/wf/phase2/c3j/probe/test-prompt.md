Test system prompt for probes.
