# progress c3j kit
started fresh (no earlier progress file).
- step 0: state read; next: (1) identity pin check
- step 1 DONE: T17 pin 6e16407d... confirmed; added test_t17_a_digest_change_without_a_version_change_fails + _check_pin in tests/selfcert_label/test_identity.py (11 passed)
- step 2 in progress: wheel build before/after package-data
- step 2 DONE: pyproject package-data += selfcert_label/*.md, *.json; wheel before/after in kit/wheel-{before,after}; extracted wheel digest = pin; added test_the_build_ships_every_data_file_of_the_package
- step 3 next: git diff/status scope check
- step 3 DONE: diff HEAD = pyproject.toml only; untracked = selfcert_label pkg + tests; no protected path changed
- step 4 in progress: kit checks
- step 4 DONE: generate/vectors/build_corpus/manifest --check exit 0; sha256sum -c 359 OK; kit does not cover selfcert_label (TREES = integration/, src/epinoic_logic/integration/), nothing regenerated
- step 5 in progress: test dirs
- step 5 DONE: selfcert_label+contract+hygiene 719 passed; selfcert 5278 passed; integration 1473 passed 1 skipped 1 xfailed
- step 6 in progress: timing under branches load (branches started in background; kill it after timing run: pkill -f "pytest.*tests/branches")
- step 6 DONE: 441 timing tests passed under branches load; history parser per-call max 0.84s vs 3.0s bound (28%); load stopped
- next: StructuredOutput
