probe prompt
