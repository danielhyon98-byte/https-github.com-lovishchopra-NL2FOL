# progress c3j check fixer
started fresh (no earlier progress file).
done: -
in progress: reading memo and package
next: fix items in lens order
- (step 1 done) code edits made in scope.py (clean order, whitespace controls -> space, linear sentence-end scan, TypeError/ValueError on bad input, relay frame for placeholders), exempt.py (+exemptions.json: E-Q rhetorical/G8 across paragraphs, E-IMP verb-use + report markers, E-OUT whole-word evaluator, E-GLOSS gloss noun + <=4 words, E-CORR actual pair, E-CMD governed quote), validate.py (linear depth, spans [] on none, every occurrence must be exempt), anchor.locate_all, labellers (bounded call thread + late reply = timeout, recording needs model_digest), record.py (seal, revalidate model_digest/writer), fakes reply_json spans [].
- next: run tests/selfcert_label, fix fallout, rewrite E-CORR case + T7 exact mismatches (stricter), add new tests
- (step 2 done) tests rewritten (E-CORR case, record field set + seal, T7 exact mismatches: stricter) and new tests/selfcert_label/test_attack16.py; docs (README, docstrings, schema else branch) updated. next: identity pin T17, timing under load, tests/selfcert
- (step 3) timing under load run 1: ratio 6.09 fail on build_input quotation marks 200kB (cause: uncached find_quotation_spans on text where no placeholder is possible, and _clean per-char loop). Fixed: _clean candidate scan, placeholder pre-check, _command_term lazy scan. run 2 (before precheck): 440 passed, worst ratio 4.79/6 (<25% headroom). next: run 3 under load, then T17 pin, tests/selfcert
- (step 4) T17 pin added (digest 561b9104...; recompute if the package changes again). next: tests/selfcert, final timing under load
- (step 5 DONE) breaker counts cut-off/late calls (+test); T17 re-pinned 6e16407d...; tests/selfcert 5278 passed unchanged; tests/selfcert_label + hygiene 214 passed; final timing run under tests/branches load: 538 passed, bound use max 38%, growth ratios of linear code 4.0-5.8 (noise; anchor/visible_map and reader fold dominate). Load stopped. prompt.md sha unchanged. next: StructuredOutput
