# progress c3j check fixer
started fresh (no earlier progress file).
done: -
in progress: reading memo and package
next: fix items in lens order
- (step 1 done) code edits made in scope.py (clean order, whitespace controls -> space, linear sentence-end scan, TypeError/ValueError on bad input, relay frame for placeholders), exempt.py (+exemptions.json: E-Q rhetorical/G8 across paragraphs, E-IMP verb-use + report markers, E-OUT whole-word evaluator, E-GLOSS gloss noun + <=4 words, E-CORR actual pair, E-CMD governed quote), validate.py (linear depth, spans [] on none, every occurrence must be exempt), anchor.locate_all, labellers (bounded call thread + late reply = timeout, recording needs model_digest), record.py (seal, revalidate model_digest/writer), fakes reply_json spans [].
- next: run tests/selfcert_label, fix fallout, rewrite E-CORR case + T7 exact mismatches (stricter), add new tests
- (step 2 done) tests rewritten (E-CORR case, record field set + seal, T7 exact mismatches: stricter) and new tests/selfcert_label/test_attack16.py; docs (README, docstrings, schema else branch) updated. next: identity pin T17, timing under load, tests/selfcert
