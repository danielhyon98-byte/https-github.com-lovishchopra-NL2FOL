Fixed system text of the selfcert-label test suite.
