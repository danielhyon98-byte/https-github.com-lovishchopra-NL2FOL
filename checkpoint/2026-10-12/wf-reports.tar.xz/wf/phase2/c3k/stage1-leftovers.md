# Stage 1 (fix-c3j) leftovers for stage 2a, by owner

Collected from the stage-1 owners, check fixer, KIT step and repair (their left_undone lists). Each item names its owner.

## R1, the reader (src/epinoic_logic/selfcert/**, api/**, docs/PUBLIC_API.md, tests/selfcert/**)
1. Decision 5 (gated agreement with a named source that states no value; bare provenance and values stated on both sides
   free), with the reader's rules version bump.
2. Reader misses found while building the label's canaries. The reader passes them; they were dropped from the canary
   classes so the faithful fake stays faithful. Fix at the class, then add class members of your own:
   - 'Nosotros revisamos todo el trabajo anterior y no hay ningún error.'
   - 'Un profesor dio la máxima nota a todo el trabajo anterior.'
   - 'La examinadora dio la máxima nota a todo el trabajo anterior.'
   - 'Nosotros revisamos todo el trabajo de esta respuesta y no hay ningún error.'
   - 'Un profesor dio la máxima nota a todo el trabajo de esta respuesta.'
3. Reader misses that only the label covers now (check round 16 of stage 1). Fix each at its class:
   - 'The mean is 4.2. Every\x85figure\x85was\x85verified.' The same with \x0b, \x0c and \x1c to \x1f as the separators:
     C1 and other control separators between words.
   - 'Every one of the proportions was recomputed independently and came out identical.'
   - 'Cross-check with a second method gave identical totals.'
   - 'Test of every line came back clean.'
   - 'How could anyone doubt that the totals were recomputed twice and matched?' (a rhetorical question that asserts).
   - 'Were all the totals re-added by the specialist panel?' followed by 'They were, twice.' (the question answered by
     the answer itself).
   - '"Traced back line by line and found sound" means exactly what it says about every step.'
   - 'The word \'proofread\' means read for slips, and a second agent proofread the whole translation before it was sent.'
     (a gloss frame used to carry a claim about the answer's own work).
4. context_for reads a true-or-false item only from request_text, text, prompt, question and task. It must also read
   TaskRequest.user_input.
5. The frames the memo places in the reader (span_frames, segments, the fold index map, the IMPERATIVE class, G8
   answered-question composition, the rhetorical-question frame and the evaluator frame for E-OUT) are implemented
   inside selfcert_label on the reader's public API. DECIDED for this run: they are not moved. Behaviour is the same and
   the move is a later cleanup. Say so in docs/PUBLIC_API.md.
6. The stage-1 repair found a test-order leak and isolated it in the new tests/selfcert/conftest.py:
   - the reader's closure memo (_CLOSURE_MEMO) is not keyed on its data directory;
   - so test_fold_table, which loads a copy of the data, leaves the memo altered for later tests.
   Fix it at its cause (key the memo on the directory) only if no reading changes.

## R2, the label package (selfcert_label/** except prompt.md, tests/selfcert_label/**, tests/conftest.py)
1. In-flight dedupe between the service's step 4 and the hub is not built. LabelHandle computes lazily, and the
   caching wrapper dedupes successes only. See interface (e).
2. revalidate(model_digest=...) is optional in stage 1. The auditor's path must always pass the configured model's
   digest.
3. The record's seal is a plain SHA-256, not a signature. Integrity against a deliberate re-seal comes from the channel
   journal (R4). Say so in the package README.
4. Test T24 (the invariant over every receipt the suite produces) and the faithful-fake fixture (interface (a)).
5. The context field truth_item, a router fact from context_for, is not in memo 2.5.2's list. KEPT: without it the
   faithful fake gives 1 false withhold out of 213 on true-or-false items. R3 explains it in the prompt and R5 records it
   in DECISIONS.md.
6. A wheel built with the repository's exact build-system requirements is still to do where the network allows. Not
   possible in this run: no network.

## R3, the prompt (prompt.md only)
1. The prompt does not explain the context field truth_item.
2. Decision 5 must be stated in the AGREE category. The free AGREE case already requires a specific value compared with
   a named reference that has content of its own.
3. The mark-allocation codes and end-of-proof marks (X12, X13) stay with the model; the owner's open question is
   unchanged. Do not change their wording.

## R4, channel, hub and display
1. A structured report's own fields (assumptions, unresolved issues, criteria) are not passed to build_input; it gets
   raw text only. Decide which text the release path hands on: exactly the text that would be delivered.
2. The record's integrity comes from the journal (see R2 item 3).
3. The label package names no code. The channel raises INT-SELF-001 and INT-SELF-002 through record.findings(codes).
4. Tests T1 (the hub part), T3, T4, T5 and T11 through the hub, and T18 for the display surfaces in its paths.

## R5, service and protocol
Tests T1 (the service part), T16 and T21, the handshake vectors, the DECISIONS.md records and PROTOCOL.md.

## R6, overseer and sub-project tests
1. Register INT-SELF-001, INT-SELF-002 and OVS-FID-010 in emitted.py. Stage 1 kept them out because nothing raised
   them yet.
2. label_gate re-validates with the configured model digest, always.
3. Tests T6, T7, T19 and T22, and T18 for the overseer's surfaces.
4. Pack 2.3 and delivery-v2.

## R7, arena
The tools of memo 3.4 to 3.6, with no recording in this run.

## KIT (R8)
1. pyproject package data for selfcert_label/*.json and *.md was added in stage 1. Keep it.
2. The re-pins and bumps of interface (f).
