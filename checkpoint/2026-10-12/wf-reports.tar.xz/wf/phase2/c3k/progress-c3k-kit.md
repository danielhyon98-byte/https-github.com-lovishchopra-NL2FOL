# progress c3k KIT (R8)
Started fresh (no earlier progress file). Working tree has all owners' + check fixer's work uncommitted.
Owner bumps verified present: LABEL_VERSION selfcert-label-2 (render.py), API 1.5, rules selfcert-5, contract 0.10 (protocol.py),
delivery-v2, pack 2.3 (pack.py digest d5c9a8e3... = installed pack identity).
NOTE: selfcert.rules_closure includes engine/identity.py and version.py -> label_digest moves with any edit of them; re-pin T17 LAST.
## Done
1. version.py POLICY_VERSION 2026.11-v9 + history entry; identity.py selfcert_meaning_label {version,digest,required}
2. overseer_port.py PINNED_PACK_DIGESTS -> 2.3 digest + comment
3. docs/PROTOTYPE.md versions, label status, pack 2.3, delivery-v2
4. T17 pin selfcert-label-2 (repin via kit/repin.py; RE-RUN after any edit to version.py/identity.py/closure), history test, README sentence + test, LABEL_USERS stricter (engine/identity, LABEL_FIXTURES, RELEASE_PATH_CALLS) -> 16 pass
5. DECISIONS.md c3k Changed-since entry + D36 who-acts line; PROTOCOL.md s13 v9/0.10; readiness EXPECTED_CONTRACT 0.10 + test_readiness pins; integration-contract.md header, s8 example (CLI baseline rerun: ENTAILED, same fields, policy v9), s11 0.9->0.10
6. COMPATIBILITY.json policy v9 contract 0.10; generate, vectors (66 written), build_corpus, manifest run in order; all --check rc=0; sha256sum -c OK (REDO manifest after any kit-file edit, e.g. patch M)
7. website patch M: exports of 2cd31820 in kit/web; --write-result, patched tests 364/361 (3 Playwright), --verify exact, anchors ok, baseline 290/287, rehearsal 1-4 PASS; TESTED.json note; manifest regenerated, all checks rc 0, sha256sum OK
8. tests: engine/test_review_engine_fixes pin, contract/test_versions_identity pins (v9, selfcert-5), test_policy_v7_stale + v8_stale version pins moved, NEW tests/contract/test_policy_v9_stale.py, NEW tests/engine/test_selfcert_label_manifest.py -> 75 pass
9. pins moved: tests/selfcert/test_c3e_holds (v9, 0.10, doc head), tests/translate/test_stem_subjects (v9), tests/e2e/test_arena_deliveries (delivery-v2)
## In progress
shard A (engine contract integration selfcert_label hygiene e2e deliveries stem_subjects) -> kit/runs/A.out; shard B tests/selfcert -> kit/runs/B.out
## Next
overseer/tests; timing under tests/branches load; StructuredOutput
T17 pin in tests/selfcert_label/test_identity.py; README sentence; LABEL_USERS (engine/identity.py, fixtures, calls);
COMPATIBILITY.json + generate/vectors/build_corpus/manifest; contract doc; readiness; PROTOCOL/DECISIONS current lines;
website kit patch M; tests/engine, tests/contract v9 stale; grep pins; run tests; timing under load
- shard A: 3606 pass, 1 fail = tests/integration/test_sim_wiring.py wiring record (integration/sim/run_sim.py changed by R5, TESTED.json not re-recorded; R5-owned, needs sim copies) -> left_undone
- tests/selfcert: 5549 passed. overseer/tests running (-c pyproject.toml --rootdir .) -> kit/runs/OV.out
- overseer/tests: 14025 passed, 22 skipped. NEXT timing under branches load (kit/runs/T.out, L.out)
- timing under tests/branches load: 12 timed files 1239 passed; worst median/bound 0.40 (60% headroom). Growth-ratio tests (bound 6 for 4x input) noisy 4.0-5.2 under load; standalone 8/32/128 KiB scaling 3.9-4.2 per 4x (linear; no super-linear cause) -> recorded, no code change. Rerun of both test_linear files under load: 45 passed.
- final: T17 pin matches label_digest; kit checks rc 0; sha256 OK. Waiting for tests/branches load result (kit/runs/L.out), then StructuredOutput.
- tests/branches (load run): 13309 passed, 1 skipped. DONE; StructuredOutput next.
