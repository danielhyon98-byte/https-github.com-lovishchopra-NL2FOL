# progress c3k prompt (R3)

- DONE: read memo, c3b 3-3.13, context_block (keys: writer, subject, task_type, marking, truth_item, known_sources)
- before copy: scratch prompt/prompt.before.md (sha 6c2d79f4..., 7098 chars)
- DONE: three edits (context block six fields + truth_item paragraph, AGREE decision 5, DIRECTIVE addressees); word diff checked
- DONE: tests/selfcert_label 272 passed, 3 failed = KIT-owned pins (T17 x2, stage-1 no-user test)
- DONE: timing tests under tests/branches load: 451 passed, worst median/bound 0.36 (64% headroom)
- FROZEN: 8056 chars, 8082 bytes, ~2014 tokens, sha256 66eeb01732f5651849c31a56b1c7a45bb2d7c951a2b4026da8dc145cd177996f
- next: nothing (returned)
