# progress c3k check fixer
Started fresh (no earlier progress file).
## Plan (findings)
F1 synthesis label text: ledger reasons, conflict description/basis (bus.synthesis_label_text + overseer _synthesis_self_report)
F2 overseer shadow replay / rederivation uses default_labeller instead of hub/channel labeller
F3 faithful fake loses line structure (fakes.reader_backed_reply)
F4 _named_claims by text containment -> by sentence/offset
F5 DIRECTIVE G11 misses (brackets, adjectives, addressees, no punctuation, conditional, proofreader...)
F6 arena _delivery_pass overseer import outside allowlist
F7 test_no_release_path... rewrite stricter (pinned set of release-path files)
F8 README/docstring stage-2a + README test
F9 flash-router cost data release pack 2.3
F10 decision 5 misses (Table N of source, bare name, reversed, Spanish verbs, fit/accord/mirror)
F11 label_gate SHA missing -> LabelUnavailable
F12 owner paths record (build_fold_table.py -> R1, tests/e2e/test_arena_labels.py -> R7)
F13 reader sentence edge no blank ("12.Every figure was verified.", control char)
L: T2 re-pin, FAMILY_CATEGORY DIRECTIVE, tests/README.md conftest/markers
## Done
- F3 DONE: render.py RenderedRequest.scope (not rendered, not keyed); fakes.reader_backed_reply reads scope.raw_text whole + maps hits by origin; FAMILY_CATEGORY DIRECTIVE; tests in test_faithful_fake.py (T2 unchanged 205/208)
- F7/F8 DONE: test_identity rewrite (LABEL_USERS pinned set + overseer only via api), README/docstring stage 2a, README test stricter
- F6 DONE: run_arena delivery_pass imports overseer, passes ovs namespace to _delivery_pass; DeliveryPolicy(labeller=lab.labeller)
- F1 DONE (bus.synthesis_label_text: locators, ledger reasons, conflict desc/basis); F4 DONE (bus._named_claims locates by alnum + label units; _label_units); F2 DONE (shadow.py uses live labeller); F11 DONE (_access.labelled_text requires digest; label_gate requires label_sha256). tests/channel/test_c3k_check_round.py (11 pass). NEXT: overseer test file for F2/F11/F1 combined; then reader F5/F10/F13; flash-router F9
- overseer test overseer/tests/overseer_tests/test_c3k_check_round.py (22 pass; F1 verified failing on old label text). NEXT: reader F5 directive, F10 decision 5, F13
- reader: F5 directive rewrite (_ADDRESSEE+, _MACHINE, _WHOEVER_RE, _INJECTION_RE, _directive_body), F10 _source_agreement_spans (G10 sentence pass), F13 _GLUED_SENTENCE_RE in _runon_breaks. probes p_dir.py p_d5.py all OK. NEXT: tests/selfcert run (bg, check/sc1.out), replay vs HEAD, tests file
- reader tests tests/selfcert/test_c3k_check_round.py (74 pass); replay 145 answers + 1933 synth claims: no change vs HEAD. NEXT: F9 flash-router cost data
- F9 DONE: flash-router 0.6.0 (cost-data-6 pack 2.3 sizes, rules-6 re-release, MANIFEST, version, docs, test_data.py: 0.5.0 assertions kept on released files; current test 0.6.0; dossier 202211). flash-router 160ish + pool test pass
- F2 service test tests/integration/test_c3k_check_round.py (12 pass with contract-0.9 toggle; fail KIT-HS-002 without, as every service test)
- running: tests/selfcert (check/sc1.out, started before quote fix), tests/channel (check/ch1.out). selfcert_label: 277 pass + T17 x2 KIT
- F12 (owner paths): recorded here for the round: scripts/selfcert/build_fold_table.py assigned to R1 (rules string selfcert-5, reproduces fold_table.json), tests/e2e/test_arena_labels.py assigned to R7 (arena label tests). F11 test rewrite stricter tests/selfcert/test_c3k_api.py (digest None -> None).
- overseer targeted (10 files): 1720 pass, 1 KIT pin (test_port_adapter hello pack). running: arena c3 faithful rerun (check/c3-faith2.out), compare to arena/c3-base via arena/compare.py
- tests/channel: 2741 pass; 2 fail = without_the_overseer subprocess runs: 61 KIT-HS-002 (was 62: R7 allowlist fixed) + delivery-v1 pin (KIT)
- c3 faithful rerun #2 (c3-faith2) invalid: reader edited mid-run -> label_digest mismatch; ph-t16 records equal HEAD though. rerun #3 check/c3-faith3 + tests/selfcert rerun check/sc2.out started; NO MORE CODE EDITS during runs
- c3 faithful rerun #3 == HEAD baseline (equal [], records/unexplained/deliveries; only timings + delivery-v2 text differ); label: answers named 0/24, mutations named 0/128
- e2e+arena rules+hub label+overseer subproject: 241 pass, 2 KIT (delivery-v1 pin, PINNED_PACK_DIGESTS). With round copies (check/rounds): arena labels, hub label, c3k_label_gate, revision_requests 94 pass
- tests/selfcert rerun: 5548 pass, 1 KIT (contract 0.10 pin in test_c3e_holds). overseer full shards running: check/ov_full_A.out, ov_full_B.out. NEXT: combinator tests, timing under branches load, StructuredOutput
- overseer full: A 11716 pass; B 2308 pass + 1 KIT (port hello pack). combinator 593 pass. NEXT: timing under branches load (check/timed.out, check/load_branches.out)
- timing (always-4 + 16 touched-module timed files, under tests/branches load): 2352 pass, 1 fail = selfcert_label/test_linear anchoring letter-spaced ratio 6.39>6 (code not changed this stage; 3 reruns under load pass; ratios measured 1.9 test-ratio). worst measure/bound 0.37 (63% headroom); worst growth ratios 5.83 (label letter-spaced 50->200kB), 5.03 (reader mark codes after prose)
- tests/branches (load run): 13309 pass. DONE: all steps complete; returning StructuredOutput.
