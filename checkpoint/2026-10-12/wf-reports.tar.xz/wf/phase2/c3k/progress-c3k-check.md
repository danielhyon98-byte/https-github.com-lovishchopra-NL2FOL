# progress c3k check fixer
Started fresh (no earlier progress file).
## Plan (findings)
F1 synthesis label text: ledger reasons, conflict description/basis (bus.synthesis_label_text + overseer _synthesis_self_report)
F2 overseer shadow replay / rederivation uses default_labeller instead of hub/channel labeller
F3 faithful fake loses line structure (fakes.reader_backed_reply)
F4 _named_claims by text containment -> by sentence/offset
F5 DIRECTIVE G11 misses (brackets, adjectives, addressees, no punctuation, conditional, proofreader...)
F6 arena _delivery_pass overseer import outside allowlist
F7 test_no_release_path... rewrite stricter (pinned set of release-path files)
F8 README/docstring stage-2a + README test
F9 flash-router cost data release pack 2.3
F10 decision 5 misses (Table N of source, bare name, reversed, Spanish verbs, fit/accord/mirror)
F11 label_gate SHA missing -> LabelUnavailable
F12 owner paths record (build_fold_table.py -> R1, tests/e2e/test_arena_labels.py -> R7)
F13 reader sentence edge no blank ("12.Every figure was verified.", control char)
L: T2 re-pin, FAMILY_CATEGORY DIRECTIVE, tests/README.md conftest/markers
## Done
- F3 DONE: render.py RenderedRequest.scope (not rendered, not keyed); fakes.reader_backed_reply reads scope.raw_text whole + maps hits by origin; FAMILY_CATEGORY DIRECTIVE; tests in test_faithful_fake.py (T2 unchanged 205/208)
- F7/F8 DONE: test_identity rewrite (LABEL_USERS pinned set + overseer only via api), README/docstring stage 2a, README test stricter
- F6 DONE: run_arena delivery_pass imports overseer, passes ovs namespace to _delivery_pass; DeliveryPolicy(labeller=lab.labeller)
- F1 DONE (bus.synthesis_label_text: locators, ledger reasons, conflict desc/basis); F4 DONE (bus._named_claims locates by alnum + label units; _label_units); F2 DONE (shadow.py uses live labeller); F11 DONE (_access.labelled_text requires digest; label_gate requires label_sha256). tests/channel/test_c3k_check_round.py (11 pass). NEXT: overseer test file for F2/F11/F1 combined; then reader F5/F10/F13; flash-router F9
- overseer test overseer/tests/overseer_tests/test_c3k_check_round.py (22 pass; F1 verified failing on old label text). NEXT: reader F5 directive, F10 decision 5, F13
