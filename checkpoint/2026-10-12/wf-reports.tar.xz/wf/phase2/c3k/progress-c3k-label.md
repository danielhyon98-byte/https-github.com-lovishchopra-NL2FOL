# progress c3k label (R2)
Started fresh (no earlier progress file; working tree clean at 2858bf6a).
Steps: 1 version bump | 2 default labeller + conftest | 3 in-flight/cache/budget/retry | 4 revalidate_record | 5 leftovers (oversized cap) | 6 T24 hook | 7 validation + timing
Done:
- 1 version bump: render.py, canaries.json, exemptions.json, README identity row; tests rewritten (test_identity version, test_results x2, T15 re-pinned 4234934d.../ad174165..., test_canaries stricter rewrite). T17 tests left failing (KIT-owned pin).
In progress: 2 default labeller
- 2/3/4 code written: labellers.py (default switch, in-flight table, shared LRU, background for ProviderLabeller, revalidate_record), inputs.cache_key binds input_key, fakes ReaderBacked global share scope, t24.py (check_t24), tests/conftest.py (faithful default, real_labeller, T24 hook). Tests for these: NOT yet written.
- 5 oversized cap: scope.py rewritten (_Cleaned offset map, str.translate, _Rendered, generators, CAP_CHARS/CAP_SEGMENTS early stop). Equivalence vs old (copy in c3k/scope_old.py) on 1500 random + 54 hostile inputs: identical. 2 MB answers 0.03-0.1 s (old 0.9-4.4 s).
In progress: tests for 2-6 (new test files), then hook run over channel/integration/service/e2e, README, timing.
- tests written and passing: tests/selfcert_label/test_default_labeller.py (11), test_submission.py (12), test_revalidate_record.py, test_oversized_cap.py (10). labellers SHARED_CALLS has cache_clear (timing helper empties it).
In progress: T24 tests (tests/selfcert_label/test_t24.py), then hook run over channel/integration/service/e2e, README, timing.
- T24: src/epinoic_logic/selfcert_label/t24.py + tests/selfcert_label/test_t24.py (14 pass); hook verified on a scratch probe (unmarked fails, module fixture errors at set-up, marked passes).
In progress: rounds copy c3k/rounds-label; hook run over tests/channel, tests/integration, tests/service, tests/e2e.
- README + __init__ docstring updated (seal note, stage 2a section). _SHARED_LOCK is an RLock; SHARED_CALLS has cache_clear + cache_info (tests/test_timing.py passes).
- hook run 1 (channel, integration, service, e2e) running in background -> c3k/hookrun1.out
Next: wait for hook run; timing step (with tests/branches in parallel); full selfcert_label + selfcert run; StructuredOutput.
- perf note (optimisation phase, not fixed): label_digest() ~4.2 ms per call, of which selfcert.rules_digest() ~3.8 ms (R1's, not memoised); every label() computes it once (faithful label ~6.4 ms total).
- tests/conftest.py prints a "T24 ... checked N ..." summary line.
- hook run 1 stopped (-x) at tests/channel/test_without_the_overseer.py::test_every_import_of_the_overseer_in_the_translator_tests_is_guarded: my conftest imported epinoic_overseer.delivery_policy unguarded -> FIXED (pytest.importorskip("epinoic_overseer", reason, exc_type=ModuleNotFoundError) inside try/except skip; public top-level names). Before the stop: ~35% of the 4 dirs passed with hook active.
- hook run 2 (full, no -x) running -> c3k/hookrun2.out
- tests/selfcert + tests/selfcert_label (non-timing): only fails were T17 x2 (KIT) and test_one_reader (t24 module-level pass-word tuple) -> FIXED by keeping the words local to _success_words() (a vocabulary for package output, not a reader). T24 hook checked 8378 ChannelEvent, 195 DeliveredAnswer, 12567 DeliveryReceipt, 16761 TransmissionReceipt in that run, 0 violations.
- hook run 2 (tests/channel, integration, service, e2e; EPINOIC_ARENA_ROUNDS=c3k/rounds-label): exit 0, all passed; T24 checked 597 ChannelEvent, 2 DeliveredAnswer, 135 DeliveryReceipt, 7791 TransmissionReceipt, 0 violations.
- timing (with tests/branches running concurrently): label test_linear/attack16/oversized_cap + gate2 chronology + gate2 handoff + selfcert test_linear + stem_shapes: 451 passed; worst measure() median/bound 0.36 (64% headroom); inline-bound files 316 passed under load (hub crossing 7.8 s total vs 20 s + 20 s).
Next: wait for branches_load.out, final label-suite run, StructuredOutput.
- tests/branches (load run): exit 0, T24 checked 13 ChannelEvent, 21658 TransmissionReceipt, 0 violations.
- final targeted run: tests/selfcert_label + test_timing + hygiene + one_reader: 304 passed, 2 failed (T17 x2, KIT-owned pin).
DONE: all steps complete; returning StructuredOutput.
