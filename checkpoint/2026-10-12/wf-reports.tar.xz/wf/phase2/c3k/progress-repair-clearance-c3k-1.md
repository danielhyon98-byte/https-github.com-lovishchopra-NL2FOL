# repair clearance-c3k-1

Done: (1) tests/selfcert_label/test_identity.py no longer walks overseer/tests; overseer half moved to new test test_the_overseers_test_fixture_that_names_the_label_package_is_pinned in overseer/tests/overseer_tests/test_c3k_label_gate.py. Targeted tests pass; hygiene ok.
(2) sim wiring record: NOT fixable here (copies absent, network forbidden, revert of run_sim.py refused by permission classifier; hand-editing TESTED.json would falsify). -> left_undone.
In progress: whole-file run test_without_the_overseer.py + selfcert tests (log c3k/repair1-files.log).
Next: report.
