# progress c3k channel (R4)
Started fresh (no earlier progress file). R2 done: tests/conftest.py installs ReaderBackedLabeller (checked).
Steps: 1 read memo/design/code | 2 channel codes+event fields+journal | 3 respond/relay label path | 4 hub labeller + build_input text | 5 display rule outcome.py + channel surfaces | 6 tests T1/T3/T4/T5/T11/relay/label-failed/T18 | 7 cost timing | 8 wall-clock under load
Done:
- baseline timing (before label wiring): gate2_handoff 65.6/70.8 s; test_hub 3.5/2.9 s (c3k/channel_timing_before.out)
- step 2-5 code applied: events.py (label_json, label_sha256, labelled_text, labelled_text_sha256, label_request_json), outcome.py (labelled_self_report, withhold_labelled), bus.py (SELFCERT_LABEL_CODES/SEVERITY, answer_label_text, synthesis_label_text, _label_begin/_label_end in respond, relay report/forward/synthesis; summary label sentence), hub.py (selfcert_labeller), gate.py (withhold on INT-SELF), feedback.py (INT-SELF-001 by place). Patch scripts in c3k/patch_*.py
- tests/channel/test_selfcert_label_channel.py written: 18 pass (T4, T4 feedback by place, T5, T3, T11, unconfigured, reader skipped, label-failed, use-time default, synthesis writer=combinator, forward shares, revalidate via label_request_json, digest-only)
- bus.py _summary_request: label flaw codes named apart (T24 found 'accepted' + INT-SELF-001 in the request summary)
- suites running in background: c3k/run_channel_translate.out, c3k/run_branches.out
Next: tests/translate T18 file; tests/branches hub tests (T4/T5/T3/T11 via hub; T1 real_labeller); README; timing
- tests/channel + tests/translate full run after wiring: 5927 passed (c3k/run_channel_translate.out), T24 hook 0 violations
- tests/translate/test_labelled_display.py (6 pass), tests/branches/test_selfcert_label_hub.py (6 pass; T1 pins 68 answers: 67 reader-passed, 1 refused r7/ch-t13), relay_report test added (19 pass in channel label file)
- channel README: INT-SELF-001/002 rows + 'The meaning label' section
Next: wait run_branches.out; timing after change; wall-clock under load
- decision 5 rewrite: tests/branches/c2_hold_texts.py + test_c2_hold_remedy2_round3.py (census sentence now expected True); branches run otherwise 13303 passed
- timing after wiring: gate2_handoff 64.3/66.2 s (before 65.6/70.8), test_hub 3.0/2.5 s (before 3.5/2.9): no growth (c3k/channel_timing_after.out)
- bus.py hardened: _label_begin takes request_fn; _label_begin_report and task record evaluated inside try (nothing raises into the router)
- wall-clock run under tests/branches load in progress: c3k/timed_under_load.out (-rP), load c3k/load_branches2.out
- wall-clock under load (tests/branches concurrently + R1's runs): 33 timed files of my modules + always-4: 3223 passed, 2 failed (tests/selfcert/test_linear.py unclosed brackets growth 6.04 <= 6; tests/selfcert/test_c3d_holds.py misspelt 6.05 <= 6: R1 reader growth ratios, pass on rerun 22/22); worst measure() median/bound 0.58 (42% headroom); load run was cut at 94% by the background limit with 0 failures
- final tests/channel + tests/translate: 5952 passed (c3k/final_channel_translate.out)
