# Handoff from the combinator fixer (clearance c3, arena round 10)

The author owns `combinator/**` only. The items below need changes outside it. Each names the file, the
change, the evidence on the current tree and the tests that pin it. Nothing here is committed.

What the combinator side did (for context): instruction pack 1.4 (`combinator/src/epinoic_combinator/pack/`) splits rule 6:
a question that asks the student or the router something back stays a note; a question the answer sets the student (a
practice, test, revision or guiding question) is content, kept like any other claim, and a kept sentence that announces
questions, a list or steps keeps every question, item and step it announces unless the delivery roled it `other`. The
faithful fake's reading of rule 7 now reads the decline forms the hub added this round ("I can't choose your line of
inquiry, ..."). Tests: `combinator/tests/test_questions_the_answer_sets.py`, data `combinator/tests/data/round10_ll_t16.json`
(the round's ll-t16 material, copied verbatim). Package 0.1.5, pack 1.4 (a new pack digest; no translator file pins it).

## H1 (integrity ledger; communication-fidelity bug 21, same class as results-audit bug 3): name a carried sentence whose announced questions or items were all left out

File: `src/epinoic_logic/integrity/ledger.py`, `framing_content_findings` (rule framing-content, INT-LEDGER-019, warning).

Evidence on the current tree: with the roles the round's delivery gave ll-t16 (`combinator/tests/data/round10_ll_t16.json`
"claims": the four questions p4-s02, p4-s04, p4-s06, p4-s07 roled `interpretation`, `supporting`) and the recorded
synthesis ("synthesis": p4-point "To test a direction, answer these from the adverts themselves: 1. ..." carried, the four
questions dropped as "a question or practice prompt to the student, a note rather than a claim of the answer"),
`check_synthesis_ledger` names nothing on the questions (only INT-LEDGER-019 on p8-point, the misroled Sources line). The
current delivery names the ll-t16 case only because the English parser now roles a question under an "answer these ...:"
lead as material `judgement` (handoff-parsers.md H9), so the materiality rule fires; on every other branch, and for an
announced item that is not a question, nothing names it (see H3 below for how the other parsers role such questions).

Change: in `framing_content_findings`, beside the decline/deferral, numbered-step gap and framing-note cases, add an
"announced items" case:

- an announcing claim: a claim of the report that the synthesis cites, whose text (quotations masked) holds an announcing
  cue: "answer these", "answer the following", "the following questions", "these questions", "ask yourself", "consider
  these", "try these", "work through these", "test (it|them|your ...) with these", a count of questions, steps or tasks
  ("four questions", "three steps"), a "Steps ...:" lead, or a text that ends with ":" (every pattern anchored at a clause
  start or end, every gap bounded, as the module's other patterns are);
- its announced items: the claims after it in the report's order that belong to the same block (the same paragraph id
  prefix: `p4-` for `p4-point`; `g2.` for `g2.1`), each an item when its text, list marker and quotations aside, is a
  question (ends with "?") or opens a numbered or marked list item (`_STEP_NUMBER_RE`, "- ", "• "); a quotation-only
  evidence claim between them is no item;
- when the synthesis cites NONE of the announced items that are not roled `other`, name each of those items that is not
  material (a material one is named by the materiality rule already): INT-LEDGER-019, warning, "source claim {id} ({role},
  {materiality}) was left out of the synthesis although it is one of the questions or items that {announcing id}, which the
  synthesis carries, announces: the student-facing answer tells the student to answer or follow items it does not hold
  (rule framing-content)". Name the announcing claim's id in the message (the combinator's test checks that it is there).

Linear in the claims (one pass, each claim read once); quotations masked before the cue is read; no item read past its block.

Tests to add on the translator's side (`tests/integrity/`), each with the controls:
1. the round's ll-t16 roles and the recorded synthesis (build the reports from the data file as
   `combinator/tests/test_questions_the_answer_sets.py::_ledger_as_delivered_in_the_round` does) give INT-LEDGER-019 on
   p4-s02, p4-s04, p4-s06 and p4-s07, each once, naming p4-point;
2. the same with the four questions kept (the synthesis rule 6 asks for): no finding names them;
3. one question kept, three left out: nothing (a narrowed list is not an empty one);
4. controls: a question back with no announcing lead left out ("Would you like me to say more about the reparations?")
   draws nothing new; announced questions roled `other` left out draw nothing (they are notes; the combinator is told to
   leave them out, rule 6); the round-9 ps-t15 recorded synthesis (`combinator/tests/data/round9_ps_t15.json`) draws no new
   finding (its questions are roled `other` under `other` headings);
5. hostile input (runs of about 20,000 characters of "answer these:", "?", ": ", list markers): linear, a wide time bound.

Pinned on the combinator's side: `combinator/tests/test_questions_the_answer_sets.py::
test_the_hubs_ledger_names_the_questions_the_recorded_synthesis_dropped_whatever_their_role` is a STRICT xfail until this
lands. The change must remove that one `@pytest.mark.xfail(strict=True, ...)` decorator in the same change (it is the only
edit needed in `combinator/`; the test body stays as it is), or the suite fails with XPASS(strict). Its control,
`test_the_hubs_ledger_names_nothing_on_the_questions_when_the_synthesis_keeps_them`, passes now and must keep passing.

## H2 (parsers, observation found while verifying rule 6): the English parsers role a question back to the student as a material point

Files: `src/epinoic_logic/adapters/english_specialist/` (English A: Language and Literature and English A: Literature) and
the note reader they share (`src/epinoic_logic/adapters/markdown.py`).

Evidence on the current tree: a closing paragraph that only asks the student something back is roled `other` by the History,
generic (Psychology, Economics) and STEM (Biology, Physics) parsers, but `point`/`thesis`, `material`, by the English parsers:

| closing question | History | Psychology, Economics | Biology, Physics | English A: Language and Literature | English A: Literature |
|---|---|---|---|---|---|
| "Would you like me to say more about the reparations?" | other | other | other | point, material | thesis, material |
| "Which edition are you using?" | other | other | other | point, material | point, material |
| "Which of the three directions interests you most?" | other | other | other | point, material | thesis, material |

(First paragraph a one-sentence claim, the question as the second paragraph, task type short_answer.) Rule 6 tells the
combinator to leave such a question out as a note, so on the English branches a faithful synthesis draws INT-LEDGER-019
("MATERIAL source claims ... were dropped") for it. Needed: role a question to the student or the router that asks something
back (an offer of more, a request for the edition, text or choice, with no announcing lead and no question the answer sets)
`other` on the English branches, as the other branches do. Test: the three sentences above on both English branches, role
`other`; controls: the questions under ll-t16's "answer these ...:" lead stay content (material, as H9 made them).

## H3 (parsers, same class as the finding): the generic and STEM parsers role the questions an answer sets as notes

Files: `src/epinoic_logic/branches/generic_parser.py`, `src/epinoic_logic/adapters/stem_specialist/parser.py` (and the
History parser, which roles them supporting).

Evidence on the current tree: the same coaching paragraph through each branch,

```
Your topic is allowed, but your aim needs a direction.

To test your design, answer these from your own plan:
1. Your plan uses two groups of students. Why an experiment rather than a survey for this aim?
2. Your plan times the reading. What does the time limit add to the stress of the task?
3. Does one measure work for both groups, or only one?

Next, write your aim as one sentence.
```

roles the three questions `other`, `supporting` on Psychology, Economics (generic) and Biology (STEM), `analysis`,
`supporting` on History, and `judgement`, `material` on English A: Language and Literature (H9 of handoff-parsers.md). A
question roled `other` is a note to every reader (the combinator is told never to cite it, and the hub names it
INT-LEDGER-029 if it is), so on the generic and STEM branches a faithful synthesis keeps "answer these from your own plan:"
and the two numbered statements and must drop the questions: the student is told to answer questions that are not there,
the defect of ll-t16. The round-9 ps-t15 answer is the recorded instance on the generic branch: its guiding questions under
the headings A to D (g4.3 to g4.5, g4.7, g5.3 to g5.9, g5.11, g6.3 to g6.6 and g7.3 to g7.5: "Which students exactly:
...?", "Can you state your independent variable, dependent variable and population in one sentence?") are roled `other`,
and the recorded synthesis carries "If that sentence is hard to write, that is your first task." without the question it
refers to. Needed: role a question the answer sets the student
(under an announcing lead, in a numbered list, or a guiding question a coaching answer poses) as content on every branch,
as the English parser now does for the "answer these ...:" lead; keep a question back to the student `other` (H2).

If the generic parser's roles of the ps-t15 questions change, `combinator/tests/test_withheld_work.py::_deliver` (used by
every through-the-hub test of that file) asserts that the hub delivers the round-9 claims exactly as recorded
(`delivered == DATA["claims"]`) and fails. Tell the combinator owner: `_deliver` must then be rewritten to the new delivery
(match the claims by text, keep every assertion on the decline, the deferral and the self-certification), never loosened;
the tests on the recorded input (the faithful fake's) read the recorded roles and are unaffected, and the combinator's
instructions need no change for it (pack 1.4 already keeps a question the answer sets unless it is roled `other`).

## H4 (integration docs, sync only): the combinator's release named outside its directory

The combinator is now 0.1.5 with instruction pack `combinator-instructions` 1.4 (0.1.4 with pack 1.3 since the round-9
clearance). Two documents outside `combinator/` still name an older release:

- `integration/README.md`, the components table: "combinator (`combinator/`, package `epinoic_combinator` 0.1.3)": write 0.1.5;
- `integration/DECISIONS.md`, row D33: "... now 0.1.3 with pack 1.2, which states the note rule ...": append "0.1.4 with pack
  1.3 (rule 7: a decline or a deferral of the requested work carried word for word, round-9 clearance) and 0.1.5 with pack
  1.4 (rule 6 split: a question that asks the student or the router something back is a note, a question the answer sets the
  student is content, and a kept sentence keeps every question, item and step it announces; round-10 clearance)".

No test pins either string; no code reads them.
