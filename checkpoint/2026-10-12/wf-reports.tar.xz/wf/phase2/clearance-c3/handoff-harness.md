# Handoff from the harness fixer, clearance of arena round 10 (c3)

The harness owner's paths are `scripts/arena/**`, `docs/**` (except STEM_ and OVERSEER_ documents), `README.md` and
`tests/README.md`. Everything below needs a change outside them: the workflow's own steps (not repository code), or a
default-suite test under `tests/`. Nothing here was changed by the harness fixer.

## H1. The overseer-agent stage: runner-attested verdicts and agents on the delivery pass (workflow step; minor)

Records: c3 communication-fidelity bug 19 (c1 bug 22 / c2 bug 18 still open) and c3 adversarial-live bug 17 (c2 bug 23,
round-8 bug 25). The round's overseer-agent verdicts were submitted to `VerdictIntake` as self-reports ("pack identity
self-reported, not runner-attested": `wf/phase2/c3/overseer-agents/plan.json`; 64 of 64 verdicts of wave 2 and 72 of 72 of
wave 3 `self_reported` in `work/w2-assess.json`, `work/w3-assess.json`), and the harness's delivery pass ran with no
overseer agent (`results.json` deliveries: "overseer: not configured (the harness calls no model)"), so the
overseer-selected fallback and its threshold were again not exercised.

What the repository already offers (no code change is needed for this):

- `run_arena.py <round> --overseer-provider MODULE:FACTORY [--overseer-pack ZIP]` runs the delivery pass with overseer
  agents built from the exported pack, through the overseer package's runner (`OverseerAgentRunner`: one dossier per call,
  the system text from the loaded pack) and verdict intake, so every verdict the pass counts is runner-attested; the same
  pass runs again without them and results.json carries `deliveries`, `deliveries_baseline` and `delivery_comparison`
  (`scripts/arena/README.md`, "Delivery decisions"). FACTORY maps an agent id to a completion provider
  (`epinoic_logic.translate.providers.base.CompletionProvider`).
- The module is imported by its dotted name. Under the documented `python -I scripts/arena/run_arena.py`, `PYTHONPATH` is
  ignored: the factory module must be importable from the interpreter's own site-packages (installed into the venv, or a
  `.pth` file there naming its directory), never placed in the repository.

What the workflow must do (the finding's own fix: "a workflow step, not hub code"):

1. Write the operator's factory module outside the repository: `factory(agent_id)` returns a completion provider for the
   deployed overseer tier (the founder's rule: deployed agents on the cheapest model tier), e.g. the translator's own
   provider classes (`epinoic_logic.translate.providers.anthropic_provider` or `openai_compatible`) configured with the
   environment's credential. Make it importable under `-I` as above.
2. Run the round's delivery pass with it: `python -I scripts/arena/run_arena.py <round copy> --overseer-provider
   <module>:factory` (optionally `--overseer-pack <the round's exported pack zip>`), and keep results.json's
   `deliveries.fallback_exercised`, `decided_on_established_accuracy` and `delivery_comparison` in the round report.
3. Run the overseer-agent stage's own reviews through `OverseerAgentRunner` (one dossier per call, the pack loaded by the
   runner), not as verdicts written by a subagent and submitted to the intake; keep the runner's attestation in the
   assessment files and report attested and self-reported verdicts apart.

If the workflow cannot make a live provider call in its environment, it should say so in the round report (the fallback
not exercised, and why), not submit self-reported verdicts as the stage's result.

## H2. Recording the translations of mutated claims (workflow step; the round-9 major, harness side done)

Record: round 9's push check of be91e89, "mutated claims are never translated by the harness" (major), the same record as
the STEM fixer's handoff H7 ("injected STEM faults never reach the translator"). The harness side is done this pass:

- `python -I scripts/arena/list_claims.py <round>/specialists/<task>.json --mutations --json` lists, per variant
  `run_arena.py` delivers, the claims the mutation changed (the texts the round delivers, under the ids the hub delivers
  them, with their digests), `translate` (the changed claims the pipeline translates) and `template` (the file to write);
- `run_arena.py` serves `<round>/mutation_translations/<file stem>/<variant>.json` (`{"task_id", "variant", "claims":
  {claim id: translator output}, "claim_text_sha256": {claim id: digest}}`) to the mutated claim of that variant whose text
  has the recorded digest, names on every mutation record what became of each changed claim (`mutated_claims`) and counts
  them on the replay configuration line (`metrics.replay.mutated_claims`). As recorded, no round holds a translation of a
  mutated text: c1 0 of 38 eligible mutated claims translated, c2 0 of 42, c3 0 of 30, each named in results.json. On a
  copy of c3 the listing printed, for all 128 variants, exactly the claims the round delivered.

What the workflow must do when it records a round: after the genuine translations, run the listing for every specialist
file, have the translation agent (the deployed tier) translate each variant's `translate` claims, and write its output into
the variant's `template` (keep `claim_text_sha256` as printed: a translation recorded without its digest is never served).
The round's report should then quote the replay line's "mutated claims ... translated" figure.

## H3. A default-suite pin of the harness's c3 rules (optional; tests/ owner)

The harness's regression tests live in `scripts/arena/test_arena_rules.py`, which the default suite does not collect
(run by path). If the integrator wants the round-c3 rules in the default suite, as `tests/e2e/test_r7_relay_file.py` keeps
the relayed-file rule, a test under `tests/e2e/` can run `run_arena.run_round` on a two-task round whose `tasks.json` plans
a peer-dependent task with no specialist file and assert: the dependent's genuine record `not_answered`, its peer relay
`relay_not_run`, the group's synthesis failing with `members_not_answered`, and `planned_tasks.not_answered` naming it; and
that `run_arena.load_items` on a directory holding a one-element list raises `run_arena.SpecialistFileError` naming the
file (`scripts/arena/test_arena_rules.py`, the three round-c3 tests, are the model).

## H4. Note for whoever runs the harness on round copies

`run_arena.py` now reads a round with its `tasks.json`: a round copy that holds only some of the specialist files beside
the full `tasks.json` (a probe directory, say `clearance/c3_iso`) reports every other planned task as never answered, and
fails their groups' syntheses. To replay a subset as a round of its own, copy or write a `tasks.json` of that subset (or
none), as `overseer/scripts/ovs_harness.mini_round` already does (it copies no tasks.json).
