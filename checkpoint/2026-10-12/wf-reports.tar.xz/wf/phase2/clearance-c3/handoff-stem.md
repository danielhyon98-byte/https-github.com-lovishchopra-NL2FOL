# Handoff from the STEM fixer (round-10 clearance, integrated round c3)

The STEM fixer owns `src/epinoic_logic/stem/**`, `tests/stem/**`, `tests/fixtures/stem/**` and `docs/STEM_*.md`. Every STEM finding of the
round is fixed there at its cause (docs/STEM_DESIGN.md section 42; `tests/stem/test_clearance_c3_stem.py`). The changes below are outside
those paths and are needed to close the rest of the records. Nothing here was edited by the STEM fixer.

## H1. STEM claim roles (critical-adjacent majors: records "headings, notes and labels delivered as material", "router receives the answers' structure distorted", "16 non-claims made eligible")

File: `src/epinoic_logic/adapters/stem_specialist/parser.py` (the STEM parser's roles; the generic and English parsers have the same
records in their own owners' lists).

Needed, in the STEM parser:

1. A marks label line ('Question 1(a) — calculate — 2 marks', ph-t16 s1.1, s2.1, s3.1, s4.1), a heading or title line followed by content
   ('Confusion matrix (rows show the actual class, columns the predicted class)', cs-p10a c2.1; 'Round robin, time slice 2 ms', cs-t16
   c5.1), a label line that ends with a colon and introduces the next line ('For the current cans, $r = 3.2$ cm:', mai-t16 m22.1; 'Sign of
   f′(x) = 3(x − 3)(x + 1):', maa-t16 m3.6), a 'Sources:' line, a 'Next step:' line, a practice task ('Next practice task (data for
   practice): …', ph-t16 s7.1) and a method remark ('I calculated everything by hand; I haven't run any code.', cs-p10a c1.1) are role
   `other` and not eligible. A heading line never takes its part's point slot; with no other point, the part's first content sentence or
   its result line is the point.
2. Each part's requested result, mark or judgement is material (bi-t16 s1.2 control mitotic index; ch-t16 s2.1, s3.1, s4.2; ch-p10c s4.9,
   s5.1, s5.3; cs-p10a c4.1, c5.1; cs-t16 c4.1, c8.3, c11.1; maa-t16 m2.2; mai-t16 m10.1), whatever its punctuation; 'Provisional mark:
   1 / 2' lines are the part's mark (ph-t16 1(a), 1(c), 1(d) had no material claim).
3. 'Option N', 'Question N', 'Part N' digits are labels, never figures (bm-t16).

Tests: the claim rows quoted in the records (clearance/c3 claims/*.full.json), and that no claim of the c3 STEM answers changes its text or
id (the STEM front end's statements are unchanged by this round: `tests/stem/test_clearance_c2b_stem.py` holds them).

## H2. The 'plus working' word bound and notes (records "STEM word-count view defeats 'plus working'", "two correct c3 answers get INT-REQ-005")

The STEM side is done: `stem.hub_hooks.word_count_view` keeps the relation sign of each maths span glued to its one word ('Xmath=') so
the working reader still finds working lines, and blanks the mark annotations and part labels that open or close a line (rule
working-view). ess-t16 now measures 457 words (it measured 488), and the lens's es-C3-noassume variant meets its bound.

Still needed on the channel side (`src/epinoic_logic/channel/request_parser.py` `measure_answer_words`; `src/epinoic_logic/adapters/markdown.py`
note readers), as the parsers' handoff H2/H4 also asks:

1. An 'Assumption:' or 'Assumptions:' paragraph that states how the answer reads the task ('Assumption: SL, Paper 1 practice. The Halden
   Moss booklet is a fictional practice case, so I use its figures as given …') is a note: its 24 words are what keep ess-t16 above 450
   (457 − 24 = 433 ≤ 450).
2. Mark annotations ('[1]', '[2 marks]', '(M1)') and part labels are no words of any branch's answer (the STEM view drops them; the
   non-STEM branches still count them).
3. Working lines are best found on the raw text before any view is applied (the STEM view keeps signs, so either order now works for STEM).

Test: ess-t16 genuine (no INT-REQ-005), es-C3-noassume, a non-STEM answer with '[1]' annotations under a word bound.

## H3. Cross-encoding disagreement (record "INT-XENC-001 beside a branch error")

File: `src/epinoic_logic/channel/bus.py` (where INT-XENC-001 is raised). The record asks: when the translation's engine result is ENTAILED
on a claim a STEM branch check fails (INT-XENC-001), demote the branch check's INT-SUBJ-001 to a warning until the two encodings agree. The
seven c3 cases no longer fail (the STEM readings are fixed), so this is the defensive rule only.

## H4. Wording and pairing of non-STEM findings on STEM answers (record "warnings tell the router things that are not so")

1. `src/epinoic_logic/translate/diag_evidence.py` (`evd_lack_001`): say that nothing cited supports the premise, not that 'nothing in the
   supplied texts or the task supports it', unless the supplied texts were searched (ess-t16 s5.1, s7.1).
2. The figure check behind EVD-SRC-005 (ch-p10c s3.1, "the task material does not state the premise's figures ['26', '12']"): read the
   subscript counts of a formula the task states (C₁₂H₂₆ states 12 and 26).
3. `src/epinoic_logic/branches/quant.py` (CORE-QNT-001): pair '(P$2,150 to P$2,880)' in brackets (ec-t16 g11.8); name a derived per cent
   whose operands are not in its sentence ('so 54% of dividing cells …', bi-t16; the STEM pack now names it ST-UNDEC-001).
4. `src/epinoic_logic/engine/argument.py` ARG-HG-001: a consequence of a definition ('Each user's catch therefore reduces what is left for
   everyone else.', ec-t16) is no hasty generalisation.

## H5. Request statement ids shown as claim ids (minor record)

File: `src/epinoic_logic/branches/stem_pack.py` (`_ClaimMap.relabel`). A check that rests on a formula of the request carries the request's
statement id among its statement ids ('[claims m2.1, s1.2]', 'against the formula stated in s1.2', 'formulas included: A (s1.5)'). Relabel a
request statement id as 'the request (s1.2)' in every description and finding message, never as a claim id. (The STEM front end keeps the
request statement ids it records; it does not know which ids the pack relabels.)

## H6. Plain thousands spaces (records c2 #21 and round 9 "left undone")

STEM_DESIGN section 41.4 records reading a plain space between digit groups of three as a thousands separator as a decision for both
owners, because it changes behaviour the overseer pins: `overseer/tests/overseer_tests/test_gate1_overseer_fixes.py` ('The total is 1 500 ×
2 = 30.' named ST-PARSE-001), `test_stem_repair2.py` and `test_stem_repair6.py` (a Given written with a thousands space named ST-PARSE-001),
and the knowledge pack's D31. The STEM fixer did not change it this round (the readings stay ST-PARSE-001: named, never an error). If the
overseer owner agrees, the STEM change is the one measured in round 9's second pass (section 41.4), and those three pins move from
ST-PARSE-001 to a decided check.

## H7. Arena: injected STEM faults never reach the translator (record "c1 bug r8-8 still open")

File: `scripts/arena/run_arena.py` (fixture provider). 26 fixtures are refused as STALE_FIXTURE_REFUSED for mutated STEM text. Record
translations of the mutated lines with their claim-text digests, or translate them live in a gated run. The STEM side of the record is
done: a derivative of a polynomial with π or negative powers is checked (the c3 mai-t16 stem_arithmetic_slip, m9.1, is now INT-SUBJ-001),
and the stem_substitution mutation (m5.1) is named now that the show-that target is no premise of its own part's steps.

## H8. C0 control characters at the channel (minor record)

`src/epinoic_logic/channel/bus.py`: refuse a response holding C0 controls other than tab, line feed and carriage return (INT-REQ-009), as
for bidirectional controls. The STEM side is done: the reading view reads each as a blank, rule control-character names the statement
(ST-PARSE-001), and a relation that holds one is withheld and named at its check (ST-PARSE-001), never decided.
