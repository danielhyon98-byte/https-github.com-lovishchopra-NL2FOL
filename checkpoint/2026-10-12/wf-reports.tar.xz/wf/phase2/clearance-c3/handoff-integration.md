# Handoff from the integration fixer (clearance c3, arena round 10)

The author owns `integration/**`, `src/epinoic_logic/integration/**` and `tests/integration/**` only. The items below need
changes outside them. Each names the file, the change, the evidence on the current tree and the tests that pin it. Nothing
here is committed.

What the integration side did (for context). Communication-fidelity minor (c2 bug 19 follow-up): the lit-t16 synthesis carried
the evidence claim p2-q01, '"The queen is somewhere in the dark"', and dropped the 'Next step' note that quoted it; the port
rendered the quotation alone at the end of the student-facing text and no finding named it (exchange x10 reproduces).
`src/epinoic_logic/integration/combinator_port.py` now has `orphaned_quotations(claim_texts, citations, sources)` (public, in
`__all__`): a synthesized claim that is one quotation and nothing else (three words or more), carrying a source's quotation
claim of the same words, quoted by no other synthesized claim, whose every quoting claim in the reports it cites the synthesis
left out (cited by no synthesized claim); it returns {synthesized claim index: [ids of those left-out quoting claims]}.
`student_facing_text(claim_texts, *, citations=None, sources=None)` leaves such a claim out of the text as well (never every
claim: a text is never left empty); called with the texts only it is the round-9 composer, unchanged. `synthesis_payload`
passes the output's citations and the input's sources, so production never renders an orphaned quotation on its own, and the
hub's presence check names the claim the student does not read (INT-LEDGER-017, warning, today's generic message). The reader
is linear: each text read once (a report's claims only when a quotation cites one of them), one lookup per quotation (0.53 s
CPU on 16 reports of 512 claims, 15 million characters; the standard hostile inputs in milliseconds). Tests:
`tests/integration/test_c3_orphaned_quotation.py`, data `tests/integration/data/c3_orphaned_quotation.json` (lit-t16 and x10
copied verbatim from the round: the answers, the deliveries as the round's hub delivered them, the recorded syntheses).

## H1 (integrity ledger; owner integrity/core): name the orphaned quotation with its own rule, whichever text composes it

File: `src/epinoic_logic/integrity/ledger.py`, `_text_coverage` (INT-LEDGER-017) as called from `check_synthesis_ledger`.

Evidence on the current tree: the port's payload for lit-t16 (either delivery: p2-point roled a point as the round delivered
it, or the note roled `other` as `p2-s01` as the parsers deliver it now) draws INT-LEDGER-017 "synthesized claims ['s22'] do not
appear in the student-facing text; the ledger does not describe what the student reads": true, but it does not say why. A
text that still renders the quotation alone (the arena's today, see H2; any text that joins every claim) draws nothing on it.

Change: read the orphans with the port's reader (one reader for both sides; a function-level import, as the ledger already
imports `channel.bus.withheld_deliverable`): `from ..integration.combinator_port import orphaned_quotations`;
`texts = [c.text for c in synthesis.claims]`, `citations = [list(c.source_claim_ids) for c in synthesis.claims]`,
`sources = [[(c.claim_id, c.claim_text) for c in r.claims] for r in <the reports synthesis.source_report_ids lists, in that order>]`.
For each orphan index i (claim s = synthesis.claims[i], quoting ids q):

- when `_norm(s.text)` is absent from the student-facing text (the port's composition): drop s from the generic presence
  message and name it instead: INT-LEDGER-017, warning, "synthesized claim {s.claim_id} carries a quotation ({its source ids})
  whose every quoting claim ({q}) the synthesis left out: the student-facing text leaves it out, as the combinator port composes
  it, and the synthesis carries evidence that nothing uses (rule orphaned-quotation)", claim_ids [s.claim_id, *q];
- when it is present (a text that renders it on its own): INT-LEDGER-017, warning, "synthesized claim {s.claim_id} is a
  quotation whose every quoting claim ({q}) the synthesis left out: the student reads it on its own, with no claim that uses
  it (rule orphaned-quotation)", claim_ids [s.claim_id, *q].

Keep INT-LEDGER-017 a warning (fixed severity in `overseer/src/epinoic_overseer/checks/receipts.py`); a synthesis is still
delivered. Tests to add (`tests/integrity/`): lit-t16 and x10 from the integration data file, both deliveries, with the joined
text (named, "on its own") and the port's text (named, "leaves it out"); the controls of
`tests/integration/test_c3_orphaned_quotation.py` (a specialist's own bare quotation, a quotation a carried claim quotes, one
only another report's claim quotes, one made from a claim that is not the quotation, a two-word quotation) name nothing; the
c2 ll-t15 duplicated-content case unchanged; the hostile-input sweep. The integration tests stay green with this change: they
accept any INT-LEDGER warning naming the orphan and require INT-LEDGER-017 to name no other synthesized claim.

Docs: `src/epinoic_logic/integrity/README.md`, "Rule duplicated-content" says of the port's composition "every claim's text
still occurs in it (INT-LEDGER-017's presence check)": add that an orphaned quotation does not (the port's composition since
round 10's clearance, `integration.combinator_port.orphaned_quotations`) and is named (rule orphaned-quotation).

## H2 (harness; owner harness): the arena composes the text with the citations and the delivered sources, as the port does

File: `scripts/arena/run_arena.py`, the wrapper `student_facing_text(texts)` and its call in `group_synthesis`.

Evidence on the current tree: the wrapper calls the port's composer with the texts only (`compose(list(texts))`), so the arena
still relays the lit-t16 text ending '... merged in the speaker's grief. "The queen is somewhere in the dark"', where
`combinator_port.synthesis_payload` now relays it without the quotation: the arena no longer relays the text production
relays (the harness's parity rule).

Change: `student_facing_text(texts, citations=None, sources=None)` passes `citations=` and `sources=` to the composer when it
declares them (`"citations" in inspect.signature(compose).parameters`; never a `try/except TypeError`, which would swallow a
TypeError raised inside the composer), else calls it with the texts as today. In `group_synthesis`, over the same claims whose
texts are composed (`kept = [c for c in s_claims if isinstance(c, dict) and isinstance(c.get("text"), str)]`):
`citations = [c.get("source_claim_ids") for c in kept]` (as written; the reader treats anything but a list of strings as no
citation) and `sources = [[(c["claim_id"], c["claim_text"]) for c in delivered[it["_path"].stem].payload["claims"]] for it in reporting]`
(the delivered members, in group order, as `source_report_ids` lists them).

Effect on the recorded rounds (scanned on the current tree with `orphaned_quotations` over every recorded synthesis and its
delivered reports): c1 none, c2 none, c3 one: the lit-t16 synthesis record's text loses the trailing quotation and its receipt
gains INT-LEDGER-017 (warning) on s22. Its status stays ACCEPTED_WITH_FINDINGS (it already carries INT-LEDGER-001 on the
recorded synthesis's dropped 'p2-point', which the current parse delivers as `p2-s01`, roled `other`) and it stays functional
(a warning is no reason in `synthesis_failure_reasons`): the functional counts do not change. Verified: a scratch copy of the
harness with exactly this change, run on a copy of c3, gives 164 of 176 functional as the harness does today, and one record
differs (lit-t16 synthesis: + INT-LEDGER-017, warning, on s22); the copy's overseer passes did not run (it does not find the
overseer sub-project beside itself), which leaves the transmission records unchanged. The round directories c2-hold and
c2-hold2 named for validation do not exist; c1, c2 and c3 were run.

Tests: `scripts/arena/test_arena_rules.py::test_the_arena_composes_the_student_facing_text_as_the_port_does` monkeypatches the
composer with `lambda texts: ...`; with the signature check above it keeps working unchanged (the stand-in declares no
`citations`). Add a parity case on the x10 or lit-t16 shape (data in `tests/integration/data/c3_orphaned_quotation.json`):
`group_synthesis(...)["text"] == CB.synthesis_payload(out, inp, ...)["text"]`, without the quotation.

Docs: `scripts/arena/README.md` (the composer paragraph, about lines 234 to 242) and the round-10 section of `tests/README.md`.

## H3 (optional; owner combinator): do not carry a quotation whose quoting claims are all dropped

File: `combinator/src/epinoic_combinator/pack/INSTRUCTIONS.md` (near rule 6) and the faithful fake.

A quotation claim that only claims the combinator drops quote (the 'Next step' note's quotation in lit-t16 and x10) is dropped
with them, with the same reason; it is evidence for nothing the answer keeps. The port and the hub handle it either way (the
port leaves it out of the text, the hub names it), so this only spares the warning.

## H4 (optional; owner parsers): a quotation that only a note quotes is part of the note

File: the English parser (`src/epinoic_logic/adapters/english_specialist/parser.py`).

Since this clearance the parser roles the 'Next step' note `other` and gives p2-q01 the assumption "the quotation is a label
relayed in a note, not evidence for the argument; it supports no claim", but keeps the role `evidence`. Roling it `other` as
well would let a combinator drop it with the note under rule 6, and the orphan would not arise.
