# Handoff from the core fixer (clearance c3, round 10)

The core fixer owns only `src/epinoic_logic/{channel,integrity,translate,engine,ir,service}/**`, `src/epinoic_logic/cli.py` and their
tests. Everything below needs a change outside those paths (or is a workflow matter). Each item says exactly what to change, why,
and how to test it. Ordered by urgency.

## K1 (URGENT, overseer test; caused by a critical fix): a sort clash no longer withholds the joint check

File: `overseer/tests/overseer_tests/test_audit_joint_divergence.py`, test `test_a_joint_check_that_cannot_be_built_is_joint_002`.

The critical c3 finding (ec-t16: 'boats19' and 'boats25' declared Real in g11.7 and Int in g11.9 gave two error-level
INT-GLOSSARY-001 on the answer and the synthesis, excluding a correct answer) is fixed in `integrity.cross_check`:
`check_cross_report_consistency` now reads a sort clash apart (`rename_sort_clashes_apart`: the first sort keeps the name, the
other sort's declarations are `<name>_<sort>`) and names it INT-GLOSSARY-005 (warning, both claims, "a translation fault, not the
specialist's"); the joint check is decided. The test builds exactly such a clash (`int_problem("en-point", "x", 7, ...)` Int beside
`_real_problem("h1.1", "x", "2.5")` Real) as its example of "a joint check that cannot be built", so line 82
(`assert any(f.code == "INT-GLOSSARY-001" for f in rc2.findings)`) now fails: the channel names the clash INT-GLOSSARY-005 and the
auditor's independent joint check (which calls `check_cross_report_consistency`) decides the pool, so no OVS-JOINT-002 either.

Rewrite (stricter, both halves asserted):

```python
def test_a_joint_check_that_cannot_be_built_is_joint_002(auditor):
    # round 10 (clearance c3, rewritten to a stricter rule): a sort clash between two translations is no longer a check that cannot
    # be built: the channel names it as a translation fault and decides the pool with the declarations read apart
    ch, _rc1, _rq2, rc2 = _two_responses(auditor, int_problem("en-point", "x", 7, op="gt", bound=5), _real_problem("h1.1", "x", "2.5"))
    clash = [f for f in rc2.findings if f.code == "INT-GLOSSARY-005" and "declared as" in f.message]
    assert clash and clash[0].severity == "warning" and not any(f.code == "INT-GLOSSARY-001" for f in rc2.findings)
    audit = auditor.audit(ch.uid)
    assert not findings(audit, "OVS-JOINT-001") and not findings(audit, "OVS-JOINT-002")
    # a joint check that cannot be built (a pool over the joint limits: INT-GLOSSARY-006) is still OVS-JOINT-002
    ...build a pool over JOINT_LIMITS (e.g. 100 claims of 11 Boolean symbols each, as
       tests/integrity/test_integrity_round1.py::test_glossary... builds `big`) and assert OVS-JOINT-002 naming INT-GLOSSARY-006...
```

No table change is needed: INT-GLOSSARY-001 keeps its one severity (error) in `emitted.RECEIPT_CODES`,
`checks/receipts.FIXED_SEVERITY` and the knowledge pack; it is still raised where a joint problem cannot read a clash apart (the
entailment of a synthesized claim over sources that clash). The knowledge pack's line on INT-GLOSSARY-005 may add "or declared
with different sorts" (`06-kinds-and-codes.md`), at the overseer owner's choice. The translator's own tests that pinned the old
rule were rewritten to the stricter one (`tests/integrity/test_inter_agent.py::test_glossary_sort_conflict_blocks_joint_check`,
`tests/integrity/test_integrity_round1.py::test_undisclosed_contradiction_found_by_the_entailment_path_is_flagged` and
`::test_glossary_findings_name_both_parties`).

## K1b (URGENT, overseer test; caused by a critical fix): the channel no longer names the pooled-only conflict it reads apart

File: `overseer/tests/overseer_tests/test_clearance_c3_overseer.py`, test
`test_a_false_conflict_accusation_of_one_name_pooled_for_two_quantities_is_never_refuted`, case `[glossed by a stated equation]`.

The critical c3 findings on ch-p10c ('x0' glossed "value of the left-hand side of a stated equation" in seven claims) are fixed on
the channel side by rule local-glosses in `integrity.cross_check` (`claim_local_gloss`, the pattern the overseer's own
`_CLAIM_LOCAL_GLOSS_RE` uses): the pool reads such a symbol apart before it is checked, so the receipt names NO INT-CONFLICT-001
for the pair, and the contradiction that exists only through pooling is INT-CONFLICT-004 (warning) "... each glossed by its own
claim's statement (each claim's own quantity, rule local-glosses) ...". Line 523 (`assert any(f.code == "INT-CONFLICT-001" for f in
task.receipts["rep_hi"].findings)`) assumes the channel still pools the pair, which the test's own neighbour already anticipates
("When the channel no longer pools the pair (the handoff), there is nothing to accuse"). The other two cases ("glossed by no
quantity", the control "one quantity glossed alike") pass unchanged: "the x the claim states" is a definite description, not
claim-local, so they are still INT-CONFLICT-001. Rewrite of the case (stricter: the false error never reaches the receipt):

```python
        receipt = task.receipts["rep_hi"].findings
        if outcome == "confirmed":
            # round 10 (core fixer, rule local-glosses in integrity.cross_check): the channel reads a claim-local gloss apart itself, so
            # no conflict is named to accuse; what pooling alone would charge is INT-CONFLICT-004, a warning naming the rule
            assert not any(f.code == "INT-CONFLICT-001" for f in receipt)
            assert any(f.code == "INT-CONFLICT-004" and "rule local-glosses" in f.message for f in receipt)
            return
        assert any(f.code == "INT-CONFLICT-001" for f in receipt)
```

(Checked: `check_cross_report_consistency` on the case's two problems gives CONSISTENT and one INT-CONFLICT-004 naming rule
local-glosses.)

## K2 (overseer, rule local-glosses agreement; no test fails): the channel now reads the same marks

`integrity.cross_check` now reads, before pooling, a gloss that refers to its own claim's statement (`claim_local_gloss`, the same
pattern as `overseer.checks.joint._CLAIM_LOCAL_GLOSS_RE`), functions with case and primes kept, the arithmetic a gloss writes and
signed figures (`gloss_reading`, `gloss_difference`). One difference remains: the overseer's `local_gloss_names` groups by the SET
of figures a gloss names, so '2019 number of boats' and '2019 number of boats (Table 1)' differ there ({2019} against {2019, 1});
the channel's same-gloss rule reads them as one quantity (a figure only one side states, a label number). If the overseer wants the
two to agree on channel-named conflicts, read a figure apart only when each side states one the other lacks (as
`cross_check.gloss_difference` does), or call `epinoic_logic.api.integrity.split_by_gloss`, which now applies rule local-glosses.

## K3 (stem/**; the c3 STEM criticals of the core list): verify on the STEM owner's tree

These items of the core fixer's list are in `src/epinoic_logic/stem/**` (not core paths). On the current shared tree the baseline
harness (`base/c3` of this fixer's work directory) already shows them gone: ch-p10c s4.7 and ch-t16 s6.1 have no INT-SUBJ-001
(tonne, ±), maa-t16's four INT-SUBJ-001 (m3.6/m3.4, m3.11/m3.4, m6.5, m6.6) are gone, mai-t16 m21.1/m21.2 has none, and the
mai-t16 stem_arithmetic_slip and stem_substitution mutations are now functional. The STEM owner should confirm each with its own
regression test (the core fixer added none): the tonne/± readings and "state c and r in every INT-SUBJ-001"; a function value
f(3) never read as the definition of f for the derivative rule; equations of a line (x, y) as a locus, consecutive lines as
equivalence steps; "at r = a" after a value as an evaluation point, never a stated root, and no math spans joined across prose; a
step decided from the earlier line only, never from a request formula; Leibniz derivatives (d/dx(...), dy/dx = ...) for the power
rule; multi-letter defined symbols (TP, FN), a subscripted constant split from the next symbol (k_B T), the real undecided reason.

## K4 (branches/**): written arithmetic in a Psychology answer

File: `src/epinoic_logic/branches/` (the psychology branch; CORE-QNT-001). ps-t16's '4.5 − 0.6 = 3.9', '4.5 ÷ 13.6 ≈ 33%',
'0.6 ÷ 13.4 ≈ 4%' and '3.7 ÷ 2.9 ≈ 1.3' are CORE-QNT-001 warnings ("written arithmetic in = form ... which this branch's prose
arithmetic reader does not decide"). Run the shared written-arithmetic check (the STEM front end's stem-eq, as the sciences
branches do) on '=' and '≈' forms in every branch, so a slip there is INT-SUBJ-001 as in a sciences answer. Test: ps-t16 (the four
hold, no CORE-QNT-001) and a slipped control ('4.5 − 0.6 = 3.8' is INT-SUBJ-001).

## K5 (branches/packs.py, the core pack's from-memory reader): the same reading as the ledger

ge-t16's mutations draw CORE-SRC-003 "the from-memory label concerns dates and figures, not quotations" on "... so I have left those
figures out rather than give them from memory." The ledger now reads a note as a from-memory label only through
`epinoic_logic.integrity.ledger.labels_report_figures_from_memory(note)` (a sentence with the from-memory wording and no word of a
withheld, declined, hypothetical or source-less figure: "would", "rather than", "cannot", "I have no", "left ... out", "not used",
...). The core pack's reader should call it (or the same pattern, `ledger._MEMORY_NOT_GIVEN_RE`) before reading a label. Test:
ge-t16 and its mutations (no CORE-SRC-003 from the decline), bm-t16 g16.2, and a "Figures quoted from memory." control.

## K6 (workflow / overseer agents): attested verdicts

The c3 overseer-agent waves recorded every verdict as `self_reported` (w2-assess 64 of 64, w3-assess 72 of 72): run the overseer
agents through `OverseerAgentRunner` (one dossier per call, system text from the loaded pack) and keep the attestation in the
assessment, reporting attested and self-reported verdicts apart. No code change in core paths; for the round driver and the
overseer owner.

## K7 (channel items the parsers' handoff lists, not applied in this pass)

The parsers' handoff (`handoff-parsers.md`) asks the core owner for H2 (word and paragraph measures reading notes by what they say,
`channel/request_parser.py`), H4 ('plus working' bound excluding all of the working), H5 (request items: a scenario sentence is no
item, an instruction 'so state ...' belongs to its item, part labels only at a line start), H6 (INT-REQ-008 accepting a point
claim for 'justify'; ARG-CIRC-002 beside an ENTAILED check of the same point) and H12 (ARG-BARE-001 on a closing pattern summary).
None is in the core fixer's c3 list; they are left for the next core pass. Applied from that handoff: H3 (declines and deferrals per
item, which is critical record 17 of the core list) and H11 (the bm-t14 g6.1 translate test, rewritten to the stricter rule with
both halves asserted).
