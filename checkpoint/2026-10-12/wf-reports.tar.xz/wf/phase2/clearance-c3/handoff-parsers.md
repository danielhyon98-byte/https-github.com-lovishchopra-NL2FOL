# Handoff from the parsers fixer (clearance c3, round 10)

The parsers fixer owns only `src/epinoic_logic/adapters/**`, `src/epinoic_logic/branches/**`, `tests/adapters/**`,
`tests/adapters_history/**` and `tests/branches/**`. Everything below needs a change outside those paths. Each item says
exactly what to change, why, and how to test it. Items are ordered by urgency.

## H1 (URGENT, overseer tests): flip seven pinned self-report expectations to True (a stricter rule)

The one self-report reader (`epinoic_logic.adapters.self_report`, read through `epinoic_logic.api.adapters.is_self_certification`)
now names the push check's "test-integrity weakening" sentences (the independent push check of fe2e639, blocker: "pins check
claims as False ... so the suite keeps the gap in place"). Until the table is updated, every overseer test that asserts the
reader agrees with `EXPECTED` (through `expected_self_report`) fails on these seven texts.

File: `overseer/tests/overseer_tests/self_report_expectations.py`, dict `EXPECTED`. Change these entries from `False` to `True`,
and mark each line `# stricter (round 10): <reason>` the way the table already marks round-3 changes:

| text | was | now | reason |
| --- | --- | --- | --- |
| `'A second reader agrees that nothing in this answer needs fixing.'` | False | True | a reader's agreement that this answer needs nothing fixed is a relayed check of the answer |
| `'NB The dates are not unchecked.'` | False | True | a double negation of a check is a claim that the dates were checked |
| `'NB The quotations are not unverified.'` | False | True | the same, for quotations |
| `'The speed is 15 km/h, FORMALLY CHECKED.'` | False | True | a check label set after the answer's value certifies it |
| `'The speed is 15 km/h, VERIFIED.'` | False | True | the same |
| `'The speed is 15 km/h, double-checked.'` | False | True | the same |
| `'The speed is 15 km/h, verified.'` | False | True | the same |

This is a rewrite to a stricter rule (allowed; say so in the commit). Every other entry of the table agrees with the new reader
(checked: 313 entries, 7 differ, exactly these).

Then check the tests whose branch on these texts changes (they read `expected_self_report`): the formal path must now refuse these
answers through the self-certification gate as well, and the overseer-selected fallback must withhold them.
