# Handoff from the parsers fixer (clearance c3, round 10)

The parsers fixer owns only `src/epinoic_logic/adapters/**`, `src/epinoic_logic/branches/**`, `tests/adapters/**`,
`tests/adapters_history/**` and `tests/branches/**`. Everything below needs a change outside those paths. Each item says
exactly what to change, why, and how to test it. Items are ordered by urgency.

## H1 (URGENT, overseer tests): flip seven pinned self-report expectations to True (a stricter rule) - APPLIED in the working tree

The one self-report reader (`epinoic_logic.adapters.self_report`, read through `epinoic_logic.api.adapters.is_self_certification`)
names the push check's "test-integrity weakening" sentences (the independent push check of fe2e639, blocker: "pins check claims
as False ... so the suite keeps the gap in place").

File: `overseer/tests/overseer_tests/self_report_expectations.py`, dict `EXPECTED`. These seven entries must read `True`, each
marked as a stricter rule:

| text | was | now | reason |
| --- | --- | --- | --- |
| `'A second reader agrees that nothing in this answer needs fixing.'` | False | True | a reader's agreement that this answer needs nothing fixed is a relayed check of the answer |
| `'NB The dates are not unchecked.'` | False | True | a double negation of a check is a claim that the dates were checked |
| `'NB The quotations are not unverified.'` | False | True | the same, for quotations |
| `'The speed is 15 km/h, FORMALLY CHECKED.'` | False | True | a check label set after the answer's value certifies it |
| `'The speed is 15 km/h, VERIFIED.'` | False | True | the same |
| `'The speed is 15 km/h, double-checked.'` | False | True | the same |
| `'The speed is 15 km/h, verified.'` | False | True | the same |

Status: the overseer owner's uncommitted working tree already carries exactly these seven flips with "stricter (round-10
clearance c3, was False)" comments (checked by diff). Every other entry of the table agrees with the reader (313 entries, 7
differ, exactly these). Keep them when committing.

## H2 (critical record 11, channel): word and paragraph measures must read notes by what they say

File: `src/epinoic_logic/channel/request_parser.py` (`measure_answer_words`, `count_paragraphs` and the local `is_note_block`
with its closed `_META_CUE_RE`).

The paragraph counter already calls `markdown.opens_note_paragraph`, which since this round also returns True for a paragraph
of nothing but answer notes (`markdown.answer_note_paragraph`: an omission with its reason about sources, the writer's own
omission in the first person, how the answer was produced, a decline, an offer of help). hi-t16 and hi-p10b are therefore one
paragraph now (no INT-REQ-005 'measured 2 paragraphs'). Still to do on the channel side:

1. In `measure_answer_words`, leave out the same paragraphs (`opens_note_paragraph(p)`) and, inside a counted paragraph, the
   sentences `markdown.is_answer_note` reads, exactly as the paragraph counter does, instead of the closed `_META_CUE_RE` list.
2. Replace the closed `_META_CUE_RE` decision of `is_note_block` by `markdown.opens_note_paragraph` or
   `markdown.answer_note_paragraph` (a superset of the current shapes).

Test: en-t15, lit-t15, ll-p9a (unchanged bounds), hi-t16 and hi-p10b (no INT-REQ-005 on paragraphs or words), and a paragraph
of content containing one omission note (the note's words alone are left out).

## H3 (critical record 4, channel): declines and deferrals

File: `src/epinoic_logic/channel/bus.py` (`withheld_deliverable`, the decline and deferral records, INT-REQ-004, constraint
measurement).

Since this round `markdown.declined_deliverable` (and `is_answer_note`) read a decline of a choice the student must make ("I
can't choose your line of inquiry, and I can't write your introduction ...", "I cannot set the question for you"; the object
must be the student's), so ll-t16's declined essay bound is no longer enforced (its INT-REQ-005 'measured 576 words; bound
min_words 810' error is gone on the genuine answer and on the ll-ctl-arith control). Still to do:

1. Item-level declines: a sentence that declines one item of the request ("LEGO comparison: I cannot give LEGO's latest annual
   revenue ...", ge-t16's Turkey and Syria items) should mark that request item declined (INT-REQ-004 'declines the item',
   not 'unaddressed'), and drop any bound of that item.
2. A deferral scoped to a named part ("Reply "approve" and I will write the full answer to part (d)") defers that part only.

Test: ll-t16, bm-t16, ge-t16, ec-t16 genuine answers (no false INT-REQ-004 or INT-REQ-005), x05b (decline recorded).

## H4 (critical record 3, channel): 'plus working' word bound

File: `src/epinoic_logic/channel/request_parser.py` (`bound_word_measure`): a 'plus working' bound must exclude all of the
working (every line of working `branches.quant.worked_equations` reads, and the STEM statement view's maths), not a
sliver of it. Test: ess-t16 (prose within 450 words, no INT-REQ-005 error).

## H5 (major record 7, channel): request items

File: `src/epinoic_logic/channel/request_parser.py` (`extract_items`): a scenario sentence ("The city of Port Aldwyn runs 240
diesel buses ...") is no item; an instruction 'so state ...' belongs to the item it closes; a part label matches only at a line
start or after a sentence end ('(c + 3b)' inside part (a) is no label (c)). Tests: maa-t16 i3 (covered by m4.1/m4.2), the c3
STEM requests.

## H6 (minor records 5 and 16, channel and engine)

1. `src/epinoic_logic/channel/bus.py` INT-REQ-008: accept a point claim as the answer to a 'justify' item (mai-t16 i5, answered
   by m20.1 and m21.1).
2. `src/epinoic_logic/engine/argument.py` ARG-CIRC-002 beside an ENTAILED check of the same point (maa-t15): a point the engine
   entails is not 'assumed'.
   (The History 'Yet' counter-case cue of record 5 is fixed in `history_specialist/structural.py`.)

## H7 (overseer, record 10): share the own-form reading with OVS-FID-004

`markdown.own_form_flags` (read by `markdown.parser_quotation_spans`) now also reads a base form a form is named after ('the
informal imperative of "andar"', 'a diminutive-style form of "mero"') and a standard form set beside it ('Standard Spanish says "ya
casi"') as the writer's own words. The overseer's OVS-FID-004 own-quotation reader should call `markdown.parser_quotation_spans`
(or `own_form_flags`) rather than a copy, so the channel and the auditor agree. Test: sp-p10d genuine (no OVS-FID-004 on the
glosses), spd-mq and spd-mq2 (named).

## H8 (overseer and channel, record 9): the request as a credited source

The core pack's CORE-SRC-005 now reads 'The question / the task / the prompt states that "..."' as a credit to the request and
checks the words against the request's text (ge-p10c g3.2 is named). The channel's own credit readers (INT-REQ-015 relay
credits) and the overseer's fidelity check should read the same phrases (`branches.packs._REQUEST_NAMES`) so a quotation
credited to the question but held only by a peer's report is named on every path.

## H9 (ledger, record 1): synthesis rule for guiding questions - no change needed, a test is

The English parser now roles the questions under an 'answer these ...:' lead as material (`judgement`), so the existing
materiality rule names a synthesis that drops them (INT-LEDGER-019 'MATERIAL source claims ... were dropped'; ll-t16, tested in
`tests/branches/test_c3_clearance_roles_sources.py`). If the integrity owner wants the framing-content rule to name a dropped
list item whatever its role, extend rule framing-content in `src/epinoic_logic/integrity/ledger.py` to a numbered item whose
question is dropped while its lead is carried.
