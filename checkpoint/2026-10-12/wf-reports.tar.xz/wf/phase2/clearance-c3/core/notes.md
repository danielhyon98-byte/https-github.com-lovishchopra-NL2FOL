# core fixer c3 notes
base harness (current shared tree at start): c1 203/203, c2 188/188, c3 168/168 (c2-hold, c2-hold2: no such round directory)
after fixes (after2 all rounds; after3 c3 final code): c1 203/203 (no record changed), c2 188/188 (ch-p9b s13.2 INT-ARG-001 gone), c3 168/168,
  genuine receipts with errors 9 -> 3
full suite (collected 18:37 before two small edits): 12 failed, 38397 passed, 23 skipped, 45 deselected, 1 xfailed
  mine: test_c2_hold_bidi_fail_closed (rewritten after collection, passes), overseer joint_002 + c3 [glossed by a stated equation] (handoff K1, K1b)
  others: tests/contract x5 ST-DIM-001 (stem), tests/stem x3 (stem), overseer test_c1_push_check_non_material (parsers H10)
core dirs rerun with final code (channel, integrity, translate, engine): 7784 passed, 1 skipped, 0 failed
