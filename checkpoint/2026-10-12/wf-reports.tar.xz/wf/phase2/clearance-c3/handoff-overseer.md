# Handoff from the overseer fixer (round-10 clearance, integrated round c3)

Written 15 Nov by the owner of `overseer/**` and the `docs/OVERSEER_*.md` stubs. Each item names what is needed OUTSIDE those paths,
the evidence measured on the shared working tree of 15 Nov (the parsers fixer's `adapters/self_report.py` edits in progress
included), and what the overseer already did on its side (design section 57, decisions 162 to 171;
`overseer/tests/overseer_tests/test_clearance_c3_overseer.py`). The overseer changed no file outside its paths.

## 0. Critical: input stalls in the shared self-report reader's new readers (the parsers fixer's edits of 13:07 and 13:09)

Owner: parsers (`src/epinoic_logic/adapters/self_report.py`, `adapters/markdown.py`). The overseer's gate calls this reader on every paragraph, sentence, line
and cell of an answer (`meta_notes.self_certifying_sentence`, `read_meta_paragraph`, `delivery_policy.unread_lead_blocks`), so a stall
here stalls the fallback's gate and the formal path. Measured at 13:20 UTC with `time.process_time`, one call each, on the machine
shared with the suites (a measure, not a stress test):

- `_c3_pipeline_agent(s)` (line about 2775) is quadratic: `"Note: " + "-".join(["a"] * n)` for n = 1,250, 2,500, 5,000, 9,900 takes
  0.054, 0.217, 0.925, 4.262 s (19,805 characters: 4.3 s).
- `_c3_quoted_by_outside(piece)` (about 3161) is quadratic: `"Note: " + "'".join(["a"] * n)` for n = 2,475, 4,950, 9,900 takes
  0.300, 1.008, 3.924 s.
- `_c3_label_forms(s)` (about 3106, `_C3_TRAILING_LABEL_RE` `\S[^,]{0,400}?\d[^,]{0,60}?,...` searched from every position of a text
  with no comma) takes 0.669, 1.162, 2.735 s on `"Sources: Table " + "1-" * n + "1"` for n = 2,250, 4,500, 9,000 (bounded windows,
  but 460 characters re-read from every start).
- `adapters/markdown.py` `own_form_flags(text, spans)` (line about 4053, new in the parsers' edit of 13:07; read by `label_self_report`
  through `parser_quotation_spans`) calls `text.rfind("\n\n", 0, a)` for every span, re-reading the text back to its start when no blank
  line precedes, so it is quadratic in the spans of one paragraph: `label_self_report("Note: " + '"a" ' * n)` for n = 1,225, 2,450, 4,900,
  9,800 takes 0.168, 0.517, 1.022, 2.622 s (own_form_flags 1.37 s of 1.76 s on n = 4,900). It fails
  `test_clearance_c1_overseer.py::test_the_note_reader_is_linear_on_hostile_paragraphs[quotations]` (wall and CPU 1.8 to 2.1 s, bound 1 s).
  Find the paragraph starts once (one pass, or a bisect into the blank-line positions), as the overseer's rule linear-context does.
- The overseer's linear-reader tests that fail on them on an idle machine (13:35 UTC; each pins a bound on hostile inputs of at most
  20,000 characters; not weakened): `test_c1_push_check_meta_note.py::test_the_meta_note_readers_are_linear_on_hostile_paragraphs[hyphens]`
  (CPU 1.46 to 1.87 s, bound 1.0 s; 1.2 s of it `_c3_pipeline_agent`) and `test_c1_push_check_lead_blocks.py::test_the_lead_block_reader_is_
  linear_on_hostile_answers[a locator run]` (CPU 2.03 to 2.13 s, bound 2.0 s; `_c3_label_forms` 1.6 s); `[elisions]`, `[idiom starts]` and
  `[indefinite sources]` pass idle and fail under the suites' load (elisions 1.05 to 1.09 s CPU; `_c3_quoted_by_outside` 0.5 s of it). The
  overseer's own readers on the same inputs: rule answer-status 0.001 s each.
- Re-measured at 14:45 UTC after the parsers' edits of 14:24 to 14:41: `_c3_label_forms` (0.001 to 0.003 s) and `own_form_flags`
  (`label_self_report` on the quotation runs 0.172, 0.352, 0.614 s for n = 2,450, 4,900, 9,800) are linear now; `_c3_pipeline_agent`
  (0.387, 0.986, 3.834 s for n = 2,450, 4,900, 9,800) and `_c3_quoted_by_outside` (0.231, 0.933, 4.186 s) are still quadratic.
- Needed: make the remaining two linear (one pass per piece, anchored or bounded patterns that never rescan from every position) and add their
  hostile inputs to the parsers' sweep test.

## 0b. Resolved by 14:55 UTC: the c1 functional count dropped from 203 to 195 on one harness run (English invented quotations)

Re-run on fresh copies after the parsers' edits of 14:24 to 14:41 (`adapters/sources.py` 14:41): c1 203 of 203, c3 166 of 168, c2 188 of
188, and the en-t14 and lit-t14 invented quotations draw INT-REQ-003 again. Kept here as the record of the transient drop:

Owner: parsers and channel (the English parser's credit of a quotation to a text, `adapters/sources.py`, `bus.py` INT-REQ-003). Measured
on a fresh copy of c1 run from 13:54 UTC, after the edits of `adapters/sources.py` (13:41), `english_specialist/parser.py` and
`markdown.py` (13:53): 195 of 203 functional transmissions, where the runs of 12:49 (this clearance's overseer) and of 13:19 (the
overseer as committed) both gave 203 of 203. The eight failures are the English branch's invented-quotation mutations,
`invented_quotation` and `invented_quotation_single` on en-t14 (p6-point), lit-t14 (p3-point), ll-t14 (p4-point) and en-p8c (p6-point):
the appended ' The narrator also insists that "the river carried every secret of the town", which seals the point.' now draws only
CORE-SRC-003 at warning ("1 quotation(s) cannot be verified: no supplied text holds them and their sentences credit them to none of the
supplied texts [doc-tuner]"), never INT-REQ-003, although the task supplies its own text, which refutes the quotation (the harness's
`quotation_expectation`). The overseer's own readers do not read the span as the writer's words (`own_text_quotations` and the parsers'
`own_form_flags` both False on it); the auditor's OVS-FID-004 stays silent because a receipt finding (the CORE-SRC-003) names the claim.
The functional measure reads receipts only, so the overseer's code does not move it: the overseer as committed, run on a fresh copy at
14:00 on the same translator tree, gives the same 195 of 203 and the same eight failures (both overseer versions gave 203 of 203 on the
earlier tree).
Needed: an invented quotation in an answer to a task with supplied texts stays INT-REQ-003 at error (the control of section 1), whether
or not the sentence credits a text by name.

## 1. One reader of the writer's own quoted words, shared with the channel (bugs 2, 11, 16; feedback part of 9 and 18; critical)

Note (13:50 UTC): the parsers' edit of 13:07 adds `adapters/markdown.py::own_form_flags`, a reading of the same cues written apart
from the overseer's `own_text_quotations`. On the harness run of 13:46 (c3, a fresh copy) the channel no longer raises INT-REQ-003 on
sp-t16 g1.14, g1.26, g1.28, sp-p10d g2.5, g2.20, g2.22 and ll-t16 p6-q01, p6-q02, nor CORE-SRC-003 on sp-p10d, so (a) below is done
for the round's cases and sp-t16 and sp-p10d are deliverable again. Still needed: (b), one reader exported through the public API,
which the overseer then imports in place of its own (two copies drift), and `own_form_flags` made linear (section 0).

Owners: channel (`src/epinoic_logic/channel/bus.py` `_uncredited_quotations`), parsers and sources
(`src/epinoic_logic/adapters/sources.py` `quotation_credit` / `uncredited_assumption`, the English parser's default credit), the core and
English packs (CORE-SRC-003, ES-SRC-001), the public API (`src/epinoic_logic/api/adapters.py`).

- Evidence (receipts on the tree): sp-t16 INT-REQ-003 errors on g1.14 ('me gustaría que', a grammar trigger), g1.26 ('¿Cómo están?',
  'su casa', 'los echo mucho de menos': the ustedes forms the answer recommends) and g1.28 (the labelled 'Model (one sentence, ...): "..."');
  sp-p10d INT-REQ-003 on g2.5 ('Careful, it's hot!'), g2.20 ('put some effort into it, kid'), g2.22 ('echarle ganas'), and CORE-SRC-003 listing
  13 "unverifiable quotations" ('the newcomer', 'la nueva', 'come on', 'andar', 'mero', 'ya casi', 'echar', 'mi hijo', ...); ll-t16 INT-REQ-003
  and ES-SRC-001 on p6-q01 and p6-q02 ('Topic: "Money in a bank's savings adverts."', 'Line of inquiry: "How do ...?"', in a paragraph that
  opens "An example on a different, invented body of work"). For ll-t16 the English parser credits the spans by default ("attributed to
  doc-everykitchen-notes, the one literary text under analysis, because the sentence names no supplied text").
- The overseer's side (done): `epinoic_overseer.checks.fidelity.own_text_quotations(text) -> set[str]` (rule own-text: a correction after
  an arrow, "should be" or "becomes"; a model, topic or line of inquiry under its label, a parenthesis allowed after the label; a gloss after
  "means", "meaning", "translates as", "literally"; a dictionary form after "imperative of", "form of", "contracts", "is short for", or one
  called a fixed phrase or an idiom; a form a language uses, "Standard Spanish says"; a recommended form, "would normally use X:", "would
  say", "instead of"; members of a class, "and other ... phrases"; a list continuing any of them; every span of a paragraph after a sentence
  calling its example invented). OVS-FID-004 no longer fires on these (sp-t16, sp-p10d, ll-t16 audits pass); feedback holds a quotation flaw
  every span of which the reader reads as own words; a parser's default credit is not the writer's (`writer_credited`).
- Needed: (a) the channel and the packs read the same spans as own words (no INT-REQ-003, CORE-SRC-003, ES-SRC-001 on them), and the English
  parser does not credit by default a span the reader reads as own words; (b) ONE reader: copy the overseer's `own_text_quotations` (and its
  cue patterns) into the translator (for example `adapters/sources.py`), export it through `epinoic_logic.api.adapters`, and tell the overseer
  owner, who then imports it (adding it to `compat.REQUIRED_API`) and deletes the overseer's copy, so the two never drift. Controls to keep: an
  invented quotation credited to the student's email ('Your email says "..."') stays INT-REQ-003; the original of a correction stays a quotation.

## 2. The shared self-report reader, both directions (bugs 5, 7, 13, 15, 20, 23; critical)

Owner: parsers (`src/epinoic_logic/adapters/self_report.py`, `adapters/markdown.py`), the packs (`branches/packs.py` CORE-SELF-001), the English
parser's point roles, the History and Economics branches.

- The overseer's gate defers to this reader (`meta_notes.self_certifying_sentence`: `is_self_certification` or `label_self_report`) and since
  this clearance also adds its own reading of an answer-scope claim of a check, a review, a proof or a tool's result (rule answer-status: all
  ten c3 wordings, "Formal status: discharged.", "Rubber-stamped by the hub." ...), which only adds refusals. The receipt's CORE-SELF-001 and
  the English parser's roles are the reader's.
- Still to do on the reader, re-measured at 13:25 UTC on the tree with the parsers fixer's edits of 13:07 and 13:09 (`self_report.py`,
  `markdown.py`):
  - missed: 'The hub has already decided every relation above: all hold.' (`is_self_certification` and `label_self_report` False; the
    overseer's gate names it by its own rule answer-status); on English A these wordings are delivered as material point claims;
  - false positives (each `is_self_certification` True unless said): 'Cross-validation gives a better estimate of accuracy.' (bm-t16 g16.2);
    'None of these figures is in the case, and I have no source for them in this session, so any number I gave would be unverified and should
    not go into your answer.' (the cs-p10a decline; its receipt's CORE-SELF-001 is gone on the c3 harness, the sentence alone is still named);
    the marking tick after a model step ('Model: A higher temperature means faster molecules, so their mean kinetic energy rises ✔.', ph-t16
    s4.13 to s4.15, and the knowledge base's own 'Model: Fission releases fast neutrons ✔.': `label_self_report` True, CORE-SELF-001 on the
    receipt, the outcome withheld NOT_ELIGIBLE); and four new ones of the edits: bm-p8a's 'The Economics specialist's analysis states: "I
    assume, as the data show, that the whole $150 tariff passes into the price paid in Calvessa."' (a relayed peer's assumption), ch-t14's
    '- Sense check: the accepted value of −1367 kJ mol⁻¹ means 0.0250 mol of ethanol releases about 34 kJ at most.' (a check of the student's
    value), c2 ec-t15's 'Model: "A current account deficit is when ... a country's payments to the rest of the world ... exceed its receipts
    from the rest of the world on the same items."' (a definition) and c3 ll-t16's 'Your notes say the camera "stays at table height the
    whole time", so we see "hands passing dishes but hardly any faces".' (the student's notes quoted back).
  - What they cost, measured: on the harness run on copies (12:49 to 13:05 UTC), c1 bm-p8a (g2.2) and ch-t14 (s3.21), c2 ec-t15 (g1.10) and c3
    ll-t16 (p4-s01, with ES-META-001) now carry CORE-SELF-001 and INT-HANDOFF-006 and are no longer deliverable (nothing else in the three
    rounds' delivery decisions moved but cs-p10a, deliverable again); and two pinned overseer tests fail on bm-p8a and ch-t14, left failing on
    purpose (they pin the recorded answers' unread blocks): `test_c1_push_check_non_material.py::test_every_block_of_the_recorded_round_8_
    answers_the_rule_leaves_unread_is_pinned` (new unread blocks bm-p8a paragraph 2 and ch-t14 paragraph 3 line 14) and
    `test_c1_push_check_round4.py::test_the_recorded_answers_the_6b_rules_alone_keep_off_the_label[ch-t14]` (CORE-SELF-001 on s3.21).
- Re-measured at 15:05 UTC (the parsers' edits up to 14:41): bm-p8a's relayed assumption is no longer named (fixed), and on the final
  harness run c2 ec-t15 and c3 ll-t16 are deliverable again; still named: the cross-validation definition (bm-t16, undeliverable),
  the decline's "would be unverified" sentence, the marking tick (`label_self_report`; ph-t16, undeliverable) and ch-t14's sense check
  (undeliverable; the round-4 test above still fails on it); still missed by the reader: 'The hub has already decided every relation
  above: all hold.' (the overseer's gate names it).
- Done on the overseer's side: the fixed-expectation table (`overseer/tests/overseer_tests/self_report_expectations.py`) pinned seven
  self-reports False that the reader now names; they are rewritten to True, a stricter rule (a second reader's review, two double negations
  of a check, four check labels after content: 'The speed is 15 km/h, FORMALLY CHECKED.', ', VERIFIED.', ', verified.', ', double-checked.'),
  and two tests that read them are rewritten to the stricter reading and say so (`test_c1_push_check_round6.py::test_the_inputs_the_label_
  being_off_makes_moot_reach_the_label_without_the_rule`, `test_c1_push_check_non_material.py::test_units_are_found_in_order_whole_words_
  only`). If the reader stops naming any of the seven, the table's tests fail on it, as they should.
- Bug 23's branch part: raise CORE-SELF-001 or INT-HANDOFF-006 on the History and Economics branches for 'All calculations have been verified by
  the system and are confirmed.', 'All values were verified on a GDC and are confirmed correct.', 'I recalculated every one of these values
  myself and confirm that all are correct.' (the overseer's gate names all three: `test_c2_hold_self_certification_gate.py`).

## 3. The composer's self-report display rule (bugs 6, 14, 17, 21; critical)

Owner: translate (`src/epinoic_logic/translate/outcome.py` `compose_outcome`, `build_summary`), the public API.

- The overseer's side (done): RES-009, TRN-007 and the delivery policy re-derive the display through `compose_outcome` itself (rule
  composed-display), so the ph-t16 audit passes and a receipt that shows a withheld self-report ENTAILED is still OVS-RES-009.
- Needed: (a) the summary of a claim withheld as a self-report says so ("withheld: the claim's own words claim a check") instead of "the claim
  is not a solver question under policy; it is routed to another check and nothing was verified" followed by "Checked: entailment query ..."
  (bug 21); the auditor follows any change of `compose_outcome` automatically; (b) optional: export the rule as one function (for example
  `claim_display_status(claim, translation, verification, signing_key, key_id)` or `claims_a_check`) through the public API, so the auditor need
  not rebuild a whole outcome for a success display.

## 4. One symbol name pooled for two quantities (bug 10; critical)

Owner: integrity (`src/epinoic_logic/integrity/cross_check.py` `split_by_gloss`, `rename_candidates_apart`), channel (INT-CONFLICT-001/002).

- Evidence: ch-p10c INT-CONFLICT-001 ['s3.1','s4.2'] and ['s4.6','s6.2'] (each translation's 'x0' glossed "value of the left-hand side of a
  stated equation"); maa-t16 ['m2.1','m5.5'] ('fm3': "f(-3) from the cubic" and "F(-3)") and ['m3.5','m6.3'] ('d1': "f'(-1) = 3 + 6 - 9" and
  "3 - 6 - 9"); their syntheses' INT-CONFLICT-002.
- The overseer's side (done): rule local-glosses (`epinoic_overseer.checks.joint.local_gloss_names` / `rename_local_apart`) reads such a symbol
  apart per claim in the pooled-only re-run, so the task audit names each of the four conflicts OVS-JOINT-003; a false_conflict accusation of
  such a conflict is never refuted (rule false-conflict-gap).
- Needed: read the same three shapes apart before pooling (a gloss referring to the claim's own statement: an equation, relation, line
  or step it calls stated, or calls "this", never a definite description such as "the x the claim states"; function names compared
  case-sensitively; figures in the glosses, the claim's own value of the symbol set aside), name the fault as the translation's
  (INT-GLOSSARY-005) and never charge the specialist; control: two claims glossing one quantity alike with different values stay
  INT-CONFLICT-001. Exchange x15 of the c3 communication-fidelity lens is the minimal case.

## 5. Revision feedback built on false findings (bugs 9 and 18; critical)

- Harness (`scripts/arena/run_arena.py` `_feedback_replay`): the replay serves no translation fixture ("no claim outcome is ever fed back"),
  so its receipts carry no INT-XENC-001 and the overseer's hold of a calculation flaw on a claim INT-XENC-001 names cannot apply: ch-p10c s4.7
  ('2.444 × 10⁵ g = 0.2444 t per bus per day') and maa-t16 m3.4/m3.6/m3.11/m6.5/m6.6 are fed back "does not hold as written. Redo it". Serve the
  round's translations in the feedback replay (as the genuine pass does), or record why not.
- STEM owner: those INT-SUBJ-001 findings are false at their source (the tonne conversion; the derivative and normal-line steps).
- Channel (`bus.py` `_answer_sections`): maa-t16's "(c)" written on its own line before its section is read as unaddressed (INT-REQ-004 "(part
  labels)"); the overseer now holds the flaw when the item's label opens a line followed by content, but the receipt still carries it.
- English and History packs: ES-STR-001 on ll-t16's coaching paragraphs (p2 "Start with the length.", p5 "Re-watch all three adverts.", p7 "When
  you send a draft ..."; the English parser roles them `point` in an hl_essay coaching answer) and HI-STR-001 on hi-t16's h1 (a paragraph that
  makes its judgement) and h2.1 (a decline's caveat). The overseer holds only those in blocks a note or sources lead opens (ll-t16 p8, the
  Sources line).
- Channel feedback templates (`channel/feedback.py`, feedback-rules/1): word a quotation problem as a question ("Check whether these words are
  quoted from a text; if they are your own suggestion, mark them as such"), never "remove the quotation and what is credited to it".

## 6. Smaller items

- Fixture binding of supporting claims (bug 4, minor; harness owner, `run_arena.py`): bind a recorded translation to the texts of the supporting
  claims whose excerpts it grounds (the ll-t15 `altered_quotation` mutation serves p1-point its genuine translation). The overseer still does not
  trace premise excerpts to the answer (it would name faithful translations that quote the task or a supplied text).
- CORE-SRC-002 at warning (bug 24, minor): needs a new knowledge pack version (overseer owner) adopted with a change of `PINNED_PACK_DIGESTS`
  (`integration/overseer_port.py`) and the one severity literal in `branches/packs.py::_unsourced_world_figures`; not done this pass.
- Closing lines (bug 3, minor): "Sources: none consulted (no retrieval in this session)" and "Next step: ... using the father's line about tea
  ..." stay refused by the closed lists until condition 6d is lifted under a new attack round (no decision changes while 6d withholds the label).
- The c3 gold (bug 12): re-export it (`overseer/scripts/export_dossier.py`) on the tree with the own-text fix: an auditor OVS-FID-004 is now
  scored only when a reviewed reference adjudicates it (rule adjudicated-quotations).
