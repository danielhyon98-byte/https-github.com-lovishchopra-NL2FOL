# Regeneration of writer wave 2 and the wave-1 top-ups under ruling R-15.1 (stage 2b, before wave 2 is launched)

Written by the regeneration step agent, 28 Nov 2026, 10:50-11:05 UTC. Shorthands as in S1c-w1.md: S = the scratchpad
/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad, W = S/wf/phase2, C = W/c3l,
PY = S/z3venv/bin/python -I. Counts and hashes only: no row text, no seen string and no brief text is quoted, apart from
the ruling's own new words (fixed texts written for this step).

Rules kept: nothing under the repository was modified (gen_briefs.py reads it through read-only `git cat-file`, as at
S1c; 0 .pyc or __pycache__ newer than 10:50 UTC in its src/ and tests/); the repository suite, run_arena, list_labels
and run_sim were not run; no recursive command was run anywhere (every command names its files or one directory);
W/c3b/heldout and C/ho-sealed were neither opened, listed nor counted (C itself was listed once, one level: it holds no
ho-sealed directory); no workflow and no agent was launched; nothing was written under /root/.claude/ (the agents
directory's mtime is still 08:09:50); no written row was read, and nothing was shown to a writer.

## Baseline

- `cd S && PY -m pytest -q C/tools/tests -p no:cacheprovider`: 188 passed (57.1 s), before any change.
- The SHA-256 of every file this step could touch (91 files): C/sets/s1c-work/superseded-r15/BEFORE.sha256.

## 1. Ruling R-15.1 in the fixed texts

**Plan** (W/meaning-check/stage2b-plan.md, Appendix A6, the category field; file SHA-256 24efd996... -> 03c4e554...):
after "appended when that applies" the parenthesis `("/other-language" is appended only for a row in a language other
than English and Spanish, never for a Spanish row)` is inserted. Every other word of the field is unchanged (the field
without the parenthesis equals the earlier field, asserted by the new test). Nothing else in the plan was changed.

**C/tools/s0b_briefs.py** (eee59e28... -> edb8a219...):
- `OTHER_LANGUAGE_RULE`: the words of the parenthesis. A6_FIELDS's category field holds it in the same place as the
  plan, and test_a6_row_format_equals_the_plan still compares the two fields.
- `TOPUP_FORMAT_NOTE` = "In the category, " + OTHER_LANGUAGE_RULE + "; injection and prompt-aware rows use the category
  forms of their quota.". `topup_line` appends it after one space, so every top-up line now ends with it. R-15.1 says
  "every brief and top-up line written from now on states it plainly". A top-up call is its slot's wave-1 brief
  (unchanged, so its item 8 still holds the pre-ruling field) + "\n" + the line, so only the line can carry the rule.
  The second clause is A6's own wording. It is kept so that the I1 and I2 writers are not led to use the suffix:
  parse_rows.py refuses "/other-language" on every injection and prompt-aware category.
- An R-15.1 paragraph in the module docstring.
- C/tools/gen_briefs.py: only its docstring line on top-up files changed, to name the closing sentence
  (f9139aa7... -> 1a2245a5...).
- Unchanged: parse_rows.py (b07ae264..., the parse rule) and gen_writer_batch.py (59a27766...). TOPUP_LINE_RE still
  matches a one-line top-up that ends in ".".

**Tests (C/tools/tests):**
- test_s0b_fixed_texts.py: a new test, `test_r15_the_other_language_rule_is_stated_plainly_in_a6_and_in_every_topup_line`.
  It asserts that:
  - the plan's category field holds OTHER_LANGUAGE_RULE once, right after "appended when that applies (";
  - the field without the parenthesis equals the pre-ruling field word for word;
  - TOPUP_FORMAT_NOTE is pinned;
  - a top-up line and a new-slot line end with ". " + TOPUP_FORMAT_NOTE, on one line.
  test_a6_row_format_equals_the_plan is unchanged and green. In-process control: the pre-R-15.1 category field fails
  test_a6_row_format_equals_the_plan against the amended plan, and the amended field passes.
- test_s0b_gen_briefs.py, test_topup_lines: the pinned line is rewritten to the ruling's line. It is pinned in full,
  closing sentence included, with the reason in a comment. Every other assertion is unchanged.
- `cd S && PY -m pytest -q C/tools/tests/test_s0b_fixed_texts.py C/tools/tests/test_s0b_gen_briefs.py -p no:cacheprovider`:
  26 passed.
- `cd S && PY -m pytest -q C/tools/tests -p no:cacheprovider`: 189 passed (188 + 1 new), 58.5 s.

## 2. Wave-2 briefs and top-up lines

The superseded files were moved (not deleted) to C/sets/s1c-work/superseded-r15/briefs/: the 24 wave-2 briefs and the 5
top-up lines (29 files), with copies HASHES.before (f5f4929e...), SOURCES.json.before (ba06039f...) and
PLAN.json.before (055f80b6...).

**Dropping the superseded entries.** Command: `PY -B C/sets/s1c-work/regen-w2/drop_entries.py C/sets/briefs <the 29
names>`. Result:
- HASHES: 43 entries, 29 dropped, 14 kept.
- SOURCES.json "seen": 43 -> 14 entries.
- Checked: each dropped name's seen file_sha256 equals its HASHES entry, and the kept entries are byte for byte in
  gen_briefs.py's format.
- After it, HASHES is f691fb97... and SOURCES.json is b1544940..., the values before S1c's wave-2 run (S1c-w1.md
  section 4 "Before"). PLAN.json was not touched.

**Wave 2.** Command: `cd S && PY -B C/tools/gen_briefs.py briefs --wave 2 --pos-rows-per-subject 16
--neg-rows-per-subject 16 --seen C/seen/seen.jsonl`. It exited 0 with empty stderr; stdout is in
C/sets/s1c-work/regen-w2/gen_briefs-wave2.out.
- The stdout is identical line for line to S1c's C/sets/s1c-work/gen_briefs-wave2.out apart from the 24 hash prefixes:
  - the same 8 marking subjects and kind plan (H1..H22, 16-28 rows planned, none raised);
  - per brief, 32 shingles shared with the prompt (item 2 19, item 3 13) and 0 prompt-only;
  - the same seen counts;
  - ruling R-10: the 54 and 12 Example cells withheld; 0 seen strings of 5 or more words outside items 2 and 3 in 24
    of 24 briefs; a subject-name exemption in 3;
  - corpus 239373e7abd4805d, revision 29571f2dd017.
- 24 briefs, P05-P16 and N05-N16, 32 rows each (P 384, N 384).
- Check: each new brief equals its superseded brief with only the parenthesis inserted in item 8 (one occurrence;
  item 8 == a6_text()), 24/24. File = HASHES = SOURCES.json seen file_sha256, with assertion "passed", 24/24.

**Top-ups.** The missing-item files are those of S1c, unchanged (C/sets/s1c-work/topup-missing/<slot>.json, counts and
quota items only). One command per slot, in the order N01, N02, N04, I1, I2: `cd S && PY -B C/tools/gen_briefs.py topup
--slot <slot> --missing C/sets/s1c-work/topup-missing/<slot>.json --seen C/seen/seen.jsonl`. Output is in
C/sets/s1c-work/regen-w2/gen_briefs-topups.out.
- Each run exited 0 and wrote topup-<slot>-1.txt, asking for 3, 5, 4, 1 and 1 rows.
- The prompt-shingle assertion and ruling R-10's seen-string assertion passed for each line (corpus 239373e7abd4805d,
  revision 29571f2dd017).
- Check: each line equals the superseded line with " " + TOPUP_FORMAT_NOTE before its newline (the items are unchanged)
  and equals topup_line(items), 5/5. File = HASHES = SOURCES.json seen, with assertion "passed", 5/5.

**After.**
- C/sets/briefs holds 46 files. HASHES has 43 entries (ec30c957...), SOURCES.json has 43 seen entries (08f5a216...),
  and PLAN.json is unchanged (055f80b6...).
- Unchanged, checked against BEFORE.sha256: the 12 wave-1 writer briefs, judge.txt and adjudicator.txt (14/14),
  seen.jsonl, manifest.json and batches/write-w1/b001.js.

New SHA-256 values (full list in C/sets/s1c-work/regen-w2/AFTER.sha256; old values in superseded-r15/BEFORE.sha256):

| File | SHA-256 |
| --- | --- |
| P05.txt | 46e6f8e58c2cf17bd0e56a53a51d11e1659380e7277e05e9e18c52e163aa42eb |
| P06.txt | 1a179728be5f499a3709654e7a4fc0382964cb79e042d1c031425cc49c25ce5f |
| P07.txt | b3cd7db776de6b9fdbf98cce421659a2f28c326bbee80f06841bc744150bc042 |
| P08.txt | 5e0b7c9e0a06ddfa2210fdc886246863c0664f993d353fda80ff3b12b768545c |
| P09.txt | 6d3076237b624402aa4f85230a11ed1ed1166cd2483221a52011d2fb99eec887 |
| P10.txt | 24168f2e95e6010540df0a15484ef515c5c92739e77f426a7474f014a8854660 |
| P11.txt | 07c5b8250cba2249a6c716d4fb7f06f6218cc8d74d7aab6eb7e571d70129ba80 |
| P12.txt | 3092d12fdf4607faf11bf8f7321bcf461ffd3f3574c23974259a647b13249577 |
| P13.txt | 43760d2c825514a9978c1cea520212224a8f193e6604e03e21346c8767660454 |
| P14.txt | 31e69779b025528b597d75963dc8229c73b48d154125bfe2fc62efb74657599e |
| P15.txt | c20607d68a5266daec1b3ce309fe0d452bac140fd3d6f3bed487bc312649b813 |
| P16.txt | 3be26527e56a4664420d076dca691366737889a459e1995f5a53a2fedfaa93dd |
| N05.txt | 93c3b433da0d4da5183b6ec659b3fdc54fb0f21cadaf650023c833def84eab6a |
| N06.txt | 912cf41be6149bd4ead2501c5c9a971fb4392947715e789576bf04615a07f719 |
| N07.txt | 1470d26e61efcc37622ec7fa013e5764ebe08ebb285858c7342f550997f21186 |
| N08.txt | 0aacc9b4d52e3e491282c035a2d5921bba988ebcca10ab2674bd3160ef2ffd8f |
| N09.txt | dd3203eba04611408e0a13e1a44ed7274310b0c0dc7f8a7b208bcd475f825352 |
| N10.txt | a50c03c9636e951373f7e3434396400fbd8c185acfa1e0d1a050330bbb906961 |
| N11.txt | 46421eac6e82af97bbead99ba52a4803c0b43fece736d1610f47e16ccfb89bd4 |
| N12.txt | 063d40034407d3462baa3c99ac45e736c6fa1d41d49ac7625a48317c37676414 |
| N13.txt | 9684e5ac1a871bdaae5ac91486d668c1c53fd63373257e10f84a09afc3ab51d0 |
| N14.txt | 69136e1e9fc1c3bfb5d064305b9a764d9188531a4dd2f706b9a8f415896bb5e4 |
| N15.txt | 2de2587429556950fd13b27e1f361e253080213078416d8af00f53c21f3a9ecc |
| N16.txt | 2d160c917e5c9d431b0c5300746b35065891a6cc04b80792c85d1989d903d7bc |
| topup-N01-1.txt | bab0d8b845b1eb75ed5e9e3dee2b7ec0cecca6a641759a0d2521b0fde13aefd2 |
| topup-N02-1.txt | 795f0f9fe39279b3e7448c270f05146f7eb92aae345c83ef4057276417461ae4 |
| topup-N04-1.txt | 90acf8f56efb57502caaabcce5e940f28d9ca85a7546fd279b183420610f07b1 |
| topup-I1-1.txt | a75a78bcbb0abd3c8e7cc93f945a5e0cf25fef09defbde9052e74e165db1e137 |
| topup-I2-1.txt | dbd1f48a1de68adeed8c4b209acee48f7117105097cc5dce5edecabdbdb9c418 |
| HASHES | ec30c9574e7994f47f989856a5ce032dcae25ecd93dc048d8b41f958e87b5d5a |
| SOURCES.json | 08f5a216fd4ac6f91db221b6400a7cba253bbcf779c42d6ac66957d588ca4a57 |
| PLAN.json (unchanged) | 055f80b61e7c586efe4895f2bc55c3454fdd0df553d9d18389a401207acaf031 |

## 3. Writer batch files (gen_writer_batch.py, custom type, ruling R-13)

The superseded files were moved to C/sets/s1c-work/superseded-r15/:
- batches/write-w2/b001.js (cb717df8...) and batches/write-topup1/b001.js (d56a32c4...);
- inputs/write-w2/ (24 files) and inputs/write-topup1/ (5 files);
- check/write-w2-b001.mjs and check/write-topup1-b001.mjs.

They are superseded: never launch them. The four output directories were empty before the runs.

Commands (each exit 0; output in C/sets/s1c-work/regen-w2/gen_writer_batch.out):
- `cd S && PY -B C/tools/gen_writer_batch.py writers --name w2 --wave 2 --out-dir C/sets/batches/write-w2 --inputs-dir C/sets/inputs/write-w2`
  - 24 calls (P 12, N 12); every brief's SHA-256 equals HASHES.
  - Items 4 and 5 withheld in 24 briefs; the R-10 record is present for every brief; custom type
    epinoic-blind-writer.
  - C/sets/batches/write-w2/b001.js: 24 calls, 391,511 bytes, SHA-256
    a9256014c01ef46caab9eb1b46d5863b5210c5fb83c003f9b49b40277eebc5bb, workflow name c3l-write-w2-b001.
  - 24 input files in C/sets/inputs/write-w2 (write.P05.txt ... write.N16.txt).
- `cd S && PY -B C/tools/gen_writer_batch.py topups --name w1 --slots N01,N02,N04,I1,I2 --out-dir C/sets/batches/write-topup1 --inputs-dir C/sets/inputs/write-topup1`
  - 5 calls (N 3, I 2), labelled write:<slot>:topup1.
  - C/sets/batches/write-topup1/b001.js: 5 calls, 84,476 bytes, SHA-256
    a26e1296c791f8f6f50499cc11ff37b5d47f5f369b0c55ba4d5d5f2c3599e2b0, workflow name c3l-topup-w1-b001.
  - 5 input files in C/sets/inputs/write-topup1 (write.<slot>.topup1.txt).

**Against the superseded batch files.** Each file has 7 lines, and its 6 lines other than REQ (meta, names, call
options) are identical; the REQ entries are in the same order.
- write-w2: each prompt equals the superseded prompt with only the parenthesis inserted, 24/24.
- write-topup1: each prompt equals the superseded prompt with only the closing sentence added, 5/5. Its brief part is
  the unchanged wave-1 brief (brief_sha256 equal), so the top-up agents still see the pre-ruling item 8, followed by a
  line that states the rule.

**Syntax check.** Same tools as S1c, in C/sets/s1c-work/check (output in C/sets/s1c-work/regen-w2/checks.out).
- `PY -B C/sets/s1c-work/check/make_mjs.py <batch.js> C/sets/s1c-work/check/<name>-b001.mjs`: write-w2-b001.mjs
  391,574 bytes (body 391,504 bytes, unchanged); write-topup1-b001.mjs 84,539 bytes (body 84,469 bytes, unchanged).
- `node --check C/sets/s1c-work/check/write-w2-b001.mjs`: exit 0. `node --check C/sets/s1c-work/check/write-topup1-b001.mjs`:
  exit 0 (node v22.23.4).
- Control: each raw .js copied to .mjs (with its top-level return) fails node --check, exit 1 for both. The copies were
  deleted.

**Stub run.** Command: `node C/sets/s1c-work/check/run_stub.mjs <kind> <batch.js> <batch.mjs> C/sets/briefs <inputs-dir> <slots>`.
- write-w2, kind writers, slots P05-P16 and N05-N16. REQ 24; agent() calls 24. Each of these held 24/24: prompt ==
  brief byte for byte; == input file; UTF-8 round trip; options (epinoic-blind-writer, opus, high, Write); SHA-256 =
  file = HASHES. Slots as expected; phases ["Write"]; return {calls: 24, returned: 24}; prompts 15,707-16,130 bytes;
  exit 0.
- write-topup1, kind topups, slots N01, N02, N04, I1, I2. REQ 5; calls 5. Each of these held 5/5: prompt == brief +
  "\n" + top-up line; == input file; round trip; options; SHA-256. Slots as expected; return {calls: 5, returned: 5};
  prompts 15,903-16,477 bytes; exit 0.
- Control: a temporary .mjs copy of each batch with one prompt changed by one character (the first "YOUR" -> "Y0UR").
  write-w2 gave 23/24 equal, FAIL, exit 1; write-topup1 gave 4/5 equal, FAIL, exit 1. The copies were deleted, and the
  real batch files are unchanged (a9256014..., a26e1296...).

## Final checks

- `cd S && PY -m pytest -q C/tools/tests -p no:cacheprovider`: 189 passed (56.9 s).
- No .pyc or __pycache__ in the repository's src/ or tests/ newer than 10:50 UTC (find -newermt on those two named
  directories): 0.
- AFTER.sha256 against BEFORE.sha256, 91 files.
  - Changed: the plan; s0b_briefs.py, gen_briefs.py (docstring) and the two test files; the 24 wave-2 briefs and the 5
    top-up lines; HASHES and SOURCES.json; the two batch files, their 29 input files and the two .mjs copies.
  - Unchanged: everything else, including the rulings, the seen corpus and its manifest, PLAN.json, the 14 wave-1,
    judge and adjudicator briefs, write-w1/b001.js, run_stub.mjs, gen_writer_batch.py and parse_rows.py.

## For the orchestrator (observations, no action taken)

1. Launch C/sets/batches/write-w2/b001.js (a9256014...) and C/sets/batches/write-topup1/b001.js (a26e1296...).
   parse_rows.py then needs `--inputs C/sets/inputs/write-w2` and `--inputs C/sets/inputs/write-topup1` respectively.
   The copies under C/sets/s1c-work/superseded-r15/ are superseded and must not be launched.
2. The top-up calls still carry their wave-1 brief with the pre-ruling category field ("when that applies"), as
   required: the wave-1 briefs keep their files and hashes. The line's closing sentence states the rule after the
   brief.
3. The seen corpus was not rebuilt, and nothing requires a rebuild. Item 8's quoted strings are the same 20 distinct
   strings as before; the amended field quotes "/other-language" a second time, and that string is already in
   seen.jsonl (1 record). build_seen.py deduplicates by text, so a rebuild would add no string. Only the manifest's
   per-tag string count for item 8 could read 21 instead of 20.
4. Plan 4.5 still describes a top-up line as "write N more rows: <what is missing>". The closing sentence comes from
   R-15.1, which supersedes the plan. Only Appendix A6 of the plan was edited, as the task named it.
