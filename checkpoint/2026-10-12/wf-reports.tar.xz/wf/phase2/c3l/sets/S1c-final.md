# S1c final (writing ended) and the preparation of S1d (stage 2b, plan 4.3-4.9, D17, D18; rulings R-10, R-13, R-14, R-15)

Written by the stage-2b set step agent, 28 Nov 2026, from 11:33 UTC. Shorthands as in S1c-w1.md and regen-w2.md:
S = /tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad, W = S/wf/phase2, C = W/c3l,
PY = S/z3venv/bin/python -I, T = /root/.claude/projects/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/subagents/workflows
(read only). Counts, ids and hashes only: no row text, no seen string and no brief text is quoted here.

Rules kept throughout: nothing under the repository was modified (it is read only: parse_rows.py's default instruction
files, gen_briefs.py's read-only git); the repository suite, run_arena, list_labels and run_sim were not run; no
recursive command was run (every command names its files or one directory); W/c3b/heldout and C/ho-sealed were neither
opened, listed nor counted (C was listed one level: it holds no ho-sealed directory); no workflow and no agent was
launched; nothing was written under /root/.claude/ (the three run directories under T were read only); no written row
was shown to any writer (nothing was sent to any agent).

## Baseline

- `cd S && PY -m pytest -q C/tools/tests -p no:cacheprovider`: 189 passed (55.6 s), before any change.
- SHA-256 of every file this step could touch (174 files: sets/written, sets/overlap, sets/briefs, the batch and input
  files, seed, sizing.json, the seen corpus and manifest, shape.json, tools and tests, the plan and the rulings):
  C/sets/s1c-work/final/BEFORE.sha256.
- The three writer runs, read from their journals (labels, toolsUsed and result sizes only): wave 1 wf_6c742328-665,
  12 agents (12 started, 12 results); wave 2 wf_febd0e80-4f6, 24 agents (24, 24); top-up 1 wf_9a82a33d-277, 5 agents
  (5, 5). Every journal row's toolsUsed is ["SubagentHandback"] (41 of 41).
- The wave-1 outputs this step replaces were copied first (cp -p, byte-equal checked) to
  C/sets/s1c-work/superseded-final/written-w1/ (13 files) and C/sets/s1c-work/superseded-final/overlap-w1/ (36 files).

## 1. parse_rows.py over the three writer runs (custom-type mode)

parse_rows.py takes one --inputs directory, and each run wrote its own (gen_writer_batch.py --inputs-dir). The 41 input
files of the three runs (write-w1 12, write-w2 24, write-topup1 5; no name in two of them) were copied (cp -p) into
C/sets/s1c-work/final/inputs-all/ and compared with cmp, 41/41 byte-equal, so every agent's de-indent check (D4) reads
exactly its own run's input file.

Command (11:35:59 UTC):
`cd S && PY -B C/tools/parse_rows.py writers --run-dir T/wf_6c742328-665 --run-dir T/wf_febd0e80-4f6 --run-dir T/wf_9a82a33d-277 --inputs C/sets/s1c-work/final/inputs-all --mode custom-type --out-dir C/sets/written`
(defaults: --shape C/probe/shape.json, --plan C/sets/briefs/PLAN.json 055f80b6..., the repository's instruction files;
stdout C/sets/s1c-work/final/parse_rows.out, stderr empty). Exit 0.

- Agents 41: used 41, superseded 0, discarded 0, unusable 0; reasons none; no_handback_with_plain_text 0.
- **Executed-tool events: 0** (no stop of plan 2.3). Every agent: agent_type epinoic-blind-writer, granted tools
  ["SubagentHandback"] only, one delivery call, de-indent "equal", labels without a used agent 0.
- Rows: 1,278 lines delivered, 1,266 kept, 12 dropped, all for 'language' (the wave-1 drops of S1c-w1: N01 3, N02 5,
  N04 4; R-15.1: the parse rule stands). Wave 2: 768 lines, 768 kept, 0 dropped. Top-up 1: 14 lines, 14 kept, 0 dropped.
- Per agent (lines = kept unless noted): P01-P16 32 each; N01 32 (29 kept), N02 32 (27 kept), N03 32, N04 32 (28 kept),
  N05-N16 32 each; I1 60, I2 60; A1 60, A2 60; top-ups N01 3, N02 5, N04 4, I1 1, I2 1. Top-up rows are re-identified
  <slot>-t1-<nn> (N01-t1-33..35, N02-t1-28..32, N04-t1-33..36, I1-t1-61, I2-t1-61).
- Per slot (kept; every planned slot's quota met at parse, 0 violations): P01-P16 32 each (512); N01-N16 32 each (512);
  I1 61, I2 61 (122); A1 60, A2 60 (120). 36 slot files + the report written to C/sets/written/ (mode 0600).
- Against the wave-1 copies: P01-P04, N03, A1, A2 byte-identical; N01, N02, N04, I1, I2 hold the wave-1 lines unchanged
  as a prefix, followed by exactly their top-up rows.
- Report C/sets/written/parse_rows-report.json (format c3l-parse-rows/1, exit 0, stop false, rewrite []).

## 2. Overlap rule of 4.7 per slot (overlap.py with ruling R-14), replacing the wave-1 outputs

The 36 wave-1 files of C/sets/overlap/ (copied first, section Baseline) were removed, and every slot was run again in plan
order P01-P16, N01-N16, I1, I2, A1, A2, each with every earlier slot's kept file as --prior, so that the prior chain is
the same for all 36 slots (wave-1 slots now see the earlier wave-2 P slots too, and N01, N02, N04, I1, I2 include their
top-up rows). Script C/sets/s1c-work/final/run_overlap.sh (11:36:46-11:37:29 UTC; stdout overlap.out, stderr empty), one
command per slot:
`cd S && PY -B C/tools/overlap.py --seen C/seen/seen.jsonl --rows C/sets/written/<slot>.jsonl [--prior C/sets/overlap/<earlier>.jsonl ...] --out C/sets/overlap/<slot>.jsonl --excluded C/sets/overlap/<slot>.excluded.jsonl --report C/sets/overlap/<slot>.report.json`
then `chmod 600` on the kept file. Every run exit 0; seen strings 11,993 (239373e7abd4805d, revision 29571f2dd017);
R-14: seen strings exempt as subject names 1, rows kept from (b) by R-14 0 in every slot; word_equal 0 in every slot.
The normalisation imports the repository's selfcert.visible_form read-only; `git status` (read only) shows
src/epinoic_logic/selfcert/ unmodified in the working tree (fix-c3l's edits are in selfcert_label/ and elsewhere), so it
is HEAD 29571f2d's.

| Slots | Rows in | Kept | Overlap (a) | Contained (b) | Duplicate | Excluded ids |
| --- | --- | --- | --- | --- | --- | --- |
| P01-P04, P06-P09, P11-P13, P16 | 32 each | 32 each | 0 | 0 | 0 | |
| P05, P10, P14, P15 | 32 each | 31 each | 0 | 1 each | 0 | P05-01, P10-04, P14-29, P15-15 |
| N01-N09, N11-N16 | 32 each | 32 each | 0 | 0 | 0 | |
| N10 | 32 | 31 | 0 | 1 | 0 | N10-21 |
| I1 | 61 | 60 | 0 | 1 (injection_targeted) | 0 | I1-49 (as at S1c-w1) |
| I2 | 61 | 60 | 0 | 1 (injection_targeted) | 0 | I2-31 (as at S1c-w1) |
| A1, A2 | 60 each | 60 each | 0 | 0 | 0 | |
| All | 1,266 | 1,259 | 0 | 7 | 0 | |

By set: fresh_positive 512 -> 508 (4 contained), hard_negative 512 -> 511 (1), injection 122 -> 120 (2, both
injection_targeted), prompt_aware 120 -> 120. Every wave-1 slot gives the same exclusions as at S1c-w1, and its top-up
rows were all kept.

## 3. Quotas and composition after writing (4.3, 4.5, 4.9)

All counts are on the 1,259 rows kept after the format check and the overlap exclusion, before judging (the judges can
only drop rows, so these are upper bounds of S1e's counts).

**Per-slot quotas** (`cd S && PY -B C/sets/s1c-work/post_overlap_quota.py <36 slots> C/sets/s1c-work/final/post_overlap_quota.json`,
S1c-w1's script, parse_rows.py's own quota functions and PLAN.json; exit 0; output post_overlap_quota.out): 31 slots
met, 0 violations in any slot; 5 slots short by one row each, all from the overlap exclusion:
- P05 31/32: Economics 15/16;  P10 31/32: Geography 15/16;  P14 31/32: Physics 15/16;  P15 31/32: Physics 15/16;
- N10 31/32: Physics 15/16 and kind H21 1/2.
No other item is short in these slots (Spanish per subject, obfuscated per subject, other-language, distinct kinds,
P16/P17 still met). N01, N02, N04, I1 and I2 (top-up 1) now meet their quotas.

**Per set** (`cd S && PY -B C/sets/s1c-work/final/composition.py C/sets/s1c-work/final/composition.json`, exit 0, output
composition.out; facts from parse_rows.validate_row; Spanish by the declared language field, plan 4.3):

| Set | Rows | Per subject | Kinds | Spanish | Obfuscated | Other |
| --- | --- | --- | --- | --- | --- | --- |
| fresh_positive | 508 | min 30 (Physics), Economics 31, Geography 31, the other 13 subjects 32 | P1-P17 all present: P1 44, P2 42, P3 34, P4 30, P5 33, P6 31, P7 29, P8 27, P9 25, P10 27, P11 33, P12 32, P13 31, P14 31, P15 27, P16 16, P17 16 | 124 = 24.41% | 64 = 12.60% | other-language 16; combinator 16; P16 with the marking context 16 |
| hard_negative | 511 | min 31 (Physics), the other 15 subjects 32 | H1 22, H2 19, H3 22, H4 20, H5 25, H6 30, H7 34, H8 34, H9 26, H10 22, H11 24, H12 30, H13 23, H14 27, H15 17, H16 20, H17 26, H18 21, H19 16, H20 20, H21 16, H22 17 (min 16) | 131 = 25.64% | 0 | other-language 16; combinator 20; H10 with supplied_texts 22, H16 with request_text 20, H7/H8 with the marking context 68, H20 combinator 20 |
| injection | 120 (I1 60, I2 60) | all 16, min 6 | wholesale 60 (30 + 30), targeted 60 (30 + 30), of which task-borne 19 (I1 9, I2 10) | 15 | 9 | not capped |
| prompt_aware | 120 (A1 60, A2 60) | all 16 | expected gated 95 (48 + 47), free 25 (12 + 13) | 7 | 0 | reported apart, not capped |

Blind rows (fresh positives, hard negatives, injection): 1,139; with the prompt-aware rows 1,259.

Spanish check beside (plan 4.3; read-only import of the repository's branches.spanish_lexicon, unmodified in the working
tree): no row declared other than "es" is read as Spanish by either reader. Of the declared-es rows,
`is_spanish` (at least 8 function-word hits) reads P 58/124 (4 of the 124 are obfuscated), N 109/131, I 10/15, A 4/7;
the paragraph reader `spanish_paragraphs` (a row is inserted as one paragraph; fewer hits suffice) reads P 107, N 121,
I 11, A 6; unobfuscated declared-es rows that neither reader reads as Spanish: P 15, N 10, I 4, A 1 (short passages;
a check figure only, the share is counted on the declared field as 4.3 says).

**Minimums of 4.3 (after drops) and the cap of 440, before judging:**
- Fresh positives: n >= 400 yes (508), n >= 407 (wanted) yes; every subject >= 25 yes (min 30); Spanish >= 15% yes
  (24.41%); obfuscated >= 10% yes (12.60%). Under a uniform judge drop: n >= 407 holds up to 19.88% dropped, n >= 400 up
  to 21.26%, every subject >= 25 up to 16.67% (Physics 30); the Spanish share survives 56.24 Spanish rows dropped on
  their own, the obfuscated share only 14.67 obfuscated rows dropped on their own (the thinnest margin of 2b's sets).
- Hard negatives: n >= 400 yes (511); every kind H1-H22 >= 10 yes (min 16: H19, H21); every subject >= 20 yes (min 31);
  Spanish >= 15% yes (25.64%). Uniform drop room: n >= 400 21.72%, kinds 37.50%, subjects 35.48%; Spanish survives 63.94
  Spanish rows dropped on their own.
- Injection: wholesale >= 50 yes (60), targeted >= 50 yes (60), task-borne >= 10 yes (19); uniform drop room 16.67%,
  16.67%, 47.37%.
- Prompt-aware: n >= 100 yes (120); drop room 16.67%.
- Cap 440 (fresh positives and hard negatives, applied at S1e by check_sets.py --cap 440 --seed-file C/sets/seed after
  judging, never now): fresh positives 508 = 68 over, hard negatives 511 = 71 over. Unless the judges drop more than 68
  (13.39%) and 71 (13.89%) rows, the cap removes rows at S1e.
- **Shortfall against 4.3's minimums: none.** The only shortfalls are the five one-row slot shortfalls above.

**Second top-up round: due under 4.5, written, not launched.** Plan 4.5: "A slot that falls short gets one top-up
call". P05, P10, P14, P15 and N10 fall short after the overlap exclusion and have had no top-up, so each gets its one
call; with top-up 1 (the wave-1 slots) this is the second top-up round, the last under "at most two". No minimum of 4.3
depends on these 5 rows (see above), and the keyed cap draws from the largest subjects first (4.9), so the three subjects
short by one row are among the last it would reduce; whether to launch is the orchestrator's (note: if 4.9's limit
of two rounds counts these 4.5 rounds, no top-up round is left for a shortfall that judging may cause at S1e). If it is
launched, its 5 rows need the format check, the overlap rule (re-run for every slot in plan order) and both panels'
judging in a chunk of their own (aliases from r1260), since they are not in the S1d chunks below.

Missing items (counts and quota items only), C/sets/s1c-work/final/topup2-missing/<slot>.json, each closing exactly its
slot's post-overlap shortfall (every short item met, none exceeded): P05 {1, Economics}; P10 {1, Geography}; P14 {1,
Physics}; P15 {1, Physics}; N10 {1, kind H21, Physics}.

Before: HASHES ec30c957..., SOURCES.json 08f5a216..., PLAN.json 055f80b6... (C/sets/briefs: 46 files).
Commands (11:41:11-11:41:18 UTC, in plan order; output gen_briefs-topup2.out, stderr empty), each exit 0:
`cd S && PY -B C/tools/gen_briefs.py topup --slot <slot> --missing C/sets/s1c-work/final/topup2-missing/<slot>.json --seen C/seen/seen.jsonl`
- topup-P05-1.txt 74f77d29d8e3238a, topup-P10-1.txt 01e094bf34fe7eaa, topup-P14-1.txt 9979fd05479e3dcf, topup-P15-1.txt
  9979fd05479e3dcf (the same line as P14: same item), topup-N10-1.txt dfb0261a59da5e6b; one line each (253-265 bytes),
  "write 1 more rows: ..." ending with R-15.1's TOPUP_FORMAT_NOTE; for each: prompt-only shingles 0 (asserted), R-10
  seen-string assertion passed (corpus 239373e7abd4805d, revision 29571f2dd017), recorded in SOURCES.json.
- After: C/sets/briefs 51 files; HASHES 48 entries (804531fd378737b1...), SOURCES.json 48 seen entries
  (09d80a555cefe75a...), PLAN.json unchanged (055f80b6...).

Batch file (11:41 UTC; output gen_writer_batch-topup2.out, stderr empty), exit 0:
`cd S && PY -B C/tools/gen_writer_batch.py topups --name w2 --slots P05,P10,P14,P15,N10 --out-dir C/sets/batches/write-topup2 --inputs-dir C/sets/inputs/write-topup2`
- 5 calls (P 4, N 1), labels write:<slot>:topup1 (each slot's first top-up), every brief's and top-up line's SHA-256
  equal to HASHES, R-10's form and the seen-string record present for every one, custom type epinoic-blind-writer.
- C/sets/batches/write-topup2/b001.js: 5 calls, 83,783 bytes, SHA-256
  8ee66ac622c7a397b07392baebc60f294ef8ae5681dbd02b6dbc2abf1fdd6d77, workflow name c3l-topup-w2-b001; 5 input files in
  C/sets/inputs/write-topup2 (write.<slot>.topup1.txt). The briefs are the R-15.1 wave-2 briefs.
- Syntax check: `PY -B C/sets/s1c-work/check/make_mjs.py C/sets/batches/write-topup2/b001.js C/sets/s1c-work/final/check/write-topup2-b001.mjs`
  (83,846 bytes, body 83,776 unchanged); `node --check` exit 0 (node v22.23.4); control: the raw .js as .mjs, exit 1.
- Stub run: `node C/sets/s1c-work/check/run_stub.mjs topups C/sets/batches/write-topup2/b001.js C/sets/s1c-work/final/check/write-topup2-b001.mjs C/sets/briefs C/sets/inputs/write-topup2 P05,P10,P14,P15,N10`:
  REQ 5; agent() calls 5; prompt == brief + "\n" + top-up line byte for byte 5/5; == input file 5/5; UTF-8 round trip
  5/5; options (epinoic-blind-writer, opus, high, Write) 5/5; SHA-256 = file = HASHES 5/5; slots as expected; phases
  ["Write"]; return {calls: 5, returned: 5}; prompts 16,093-16,330 bytes; exit 0. Control: a copy with one prompt
  changed by one character ("YOUR" -> "Y0UR"): 4/5 equal, FAIL, exit 1; the copy was deleted; the batch is unchanged
  (8ee66ac6...).
- Not launched. When launched, parse_rows.py needs its input files (C/sets/inputs/write-topup2) in --inputs, beside the
  41 of inputs-all.

## 4. The judge batch files of S1d (4.8, D17, D18): panels A and B, not launched

**Rows judged.** The 1,259 rows kept after S1c's overlap exclusion (C/sets/overlap/<slot>.jsonl, 36 files): 1,139 blind
rows (fresh_positive 508, hard_negative 511, injection 120 = wholesale 60 + targeted 60) and 120 prompt-aware rows. Each
panel judges every blind row once and every prompt-aware row once, the prompt-aware rows in calls of their own.

**The seeded order (key-free), recorded.** No tool of the plan makes the chunks, so two scratch scripts do it:
- `cd S && PY -B C/sets/s1c-work/final/draw_judge_seed.py C/sets/judge-chunks/seed`: 32 bytes from os.urandom, drawn at
  2026-11-28T11:46:56Z, written once with O_EXCL, mode 0600 (64 hex digits + newline; file SHA-256
  87b56ae13b5760458e1db1663984a44e6b4abd2c23862de7dbe4cc92519aba07). Key-free: not derived from or combined with K_meas
  or K_pub, and not the cap's seed (C/sets/seed is untouched). A second run refuses (checked: exit 2). It was drawn
  once, before any chunk existed, and never redrawn.
- `cd S && PY -B C/sets/s1c-work/final/make_chunks.py --seed C/sets/judge-chunks/seed --out C/sets/judge-chunks` (exit 0;
  output make_chunks.out). key(domain, id) = SHA-256(seed || 0 || domain || 0 || row id). Blind rows: each set in its
  own seeded order, the three concatenated and dealt round-robin into ceil(1139 / 40) = 29 chunks (row k to chunk
  k mod 29), then each chunk in a seeded order. This guarantees plan 4.8's "each blind batch mixes fresh positives, hard
  negatives and injection rows" (a plain shuffle into 29 chunks leaves some chunk without injection rows with probability
  about 0.29: 0.2885 under independence, 0.292 in 20,000 simulated shuffles). Prompt-aware rows: one seeded order, dealt into 3 chunks. Aliases r0001-r1259 are the positions in
  the resulting order (blind r0001-r1139, prompt-aware r1140-r1259), unique over both chunk directories.
- Result: blind chunks blind-01..blind-29, 39-40 passages each (8 of 40, 21 of 39), every chunk holding fresh positives
  17-18, hard negatives 17-18 and injection 4-5 (expected gated 21-23 of 39-40); prompt-aware chunks pa-01..pa-03, 40
  each (gated 29-33, free 7-11). A passage line is {"id": alias, "subject", "writer", "context" (only when the row has
  one), "text"}, json.dumps(ensure_ascii=False), exactly gen_writer_batch.py's passage form; never the row id, slot,
  set, category, language or expected value.
- Files: C/sets/judge-chunks/blind/ (29 chunks, mode 0600, and HASHES d8d89a7028c4307a...), C/sets/judge-chunks/pa/ (3
  chunks, mode 0600, and HASHES d0b8484b5ba0844a...), C/sets/judge-chunks/alias-map.jsonl (alias -> chunk, slot, row id,
  set, expected; 1,259 entries; mode 0600; never shown to an agent; S1e binds the verdicts with it; SHA-256
  11ee3e2731de4f83...), C/sets/judge-chunks/MANIFEST.json (procedure, seed file SHA-256, the 36 source files' SHA-256 and
  rows, per chunk passages, alias range, SHA-256, by set and by expected; no row text; db1ce647bf59d7f3...).

**Batch files.** Commands (11:47 UTC; output gen_writer_batch-judges.out, stderr empty), each exit 0, in this order:
`cd S && PY -B C/tools/gen_writer_batch.py judges --set A --chunks C/sets/judge-chunks/blind --out-dir C/sets/batches/judge-a --inputs-dir C/sets/inputs/judge`
`cd S && PY -B C/tools/gen_writer_batch.py judges --set A --chunks C/sets/judge-chunks/pa --out-dir C/sets/batches/judge-a --inputs-dir C/sets/inputs/judge`
and the same two with `--set B --out-dir C/sets/batches/judge-b`. Each run: the judge brief's (judge.txt 22e5852d...,
R-10: 66 Example cells withheld, seen-string assertion "passed" in SOURCES.json) and every chunk's SHA-256 equal their
HASHES; custom type epinoic-row-judge, model opus, effort high, phase Judge, label judge:<panel>:<chunk>; default
--max-bytes 520,000 (plan 6.3), so the 29 blind calls take two files and the 3 prompt-aware calls a third of their own
(no file mixes blind and prompt-aware calls):

| File | Workflow name | Calls | Bytes | SHA-256 |
| --- | --- | --- | --- | --- |
| C/sets/batches/judge-a/b001.js | c3l-judge-a-b001 | 20 blind (blind-01..20) | 496,905 | 317bd9f8b88d3a530fa4f0d1bc445908351713c0e80dab5981570a7541d032b6 |
| C/sets/batches/judge-a/b002.js | c3l-judge-a-b002 | 9 blind (blind-21..29) | 222,736 | 8ab1c94fcf54358fbeec267c20f4865e5b0dd20c983aaaecb51347737fd80ef1 |
| C/sets/batches/judge-a/b003.js | c3l-judge-a-b003 | 3 prompt-aware (pa-01..03) | 76,809 | 4c20064d8c430c0ad886bc3a7dd22f463936eaecc7934867318ea7ea8ff4f131 |
| C/sets/batches/judge-b/b001.js | c3l-judge-b-b001 | 20 blind | 496,905 | 2f63515f7ff882391d69b3901d6ede8d6db149281ca6d192266ada161958601c |
| C/sets/batches/judge-b/b002.js | c3l-judge-b-b002 | 9 blind | 222,736 | 70ea311e66f4fc456a37c4e26eb4dbab4878545240a81b728a028f8cce2f84ad |
| C/sets/batches/judge-b/b003.js | c3l-judge-b-b003 | 3 prompt-aware | 76,809 | 583a31d0b07c02705806fee6eb683919dec7d421ca4c106bf67ee53f953b284b |

64 calls in all (58 blind, 6 prompt-aware; plan 4.8 estimated about 58 before the third judge). Inputs: one directory for
both panels, C/sets/inputs/judge: 64 prompt files judge.<A|B>.<chunk>.txt and batch-ids.json (32 chunks, 1,259 aliases,
SHA-256 ebd0316e88216a17...; written by the first run, extended by the second, equal and left as it was by the third and
fourth). parse_rows.py judges reads it as is: load_batch_ids gives 32 batches and 1,259 ids, and every label
judge:<A|B>:<chunk> is in its grammar with its input file present (checked in process).

**Syntax check.** S1c's make_mjs.py refused the two prompt-aware files ("another export in the body"): it counts the
substring "export " anywhere, and one prompt-aware row holds the economics phrase "export demand" inside the REQ string
literal (line 3; no statement). C/sets/s1c-work/final/check/make_mjs_lines.py makes the same wrap with the assertion
per line (no line but the first starts with "export"); on the top-up 2 file its output is byte-equal to make_mjs.py's,
and a file with a second export statement is refused (control, exit 1). For each of the 6 files:
`PY -B C/sets/s1c-work/final/check/make_mjs_lines.py C/sets/batches/judge-<a|b>/b<NNN>.js C/sets/s1c-work/final/check/judge-<a|b>-b<NNN>.mjs`
(body unchanged; 496,968 / 222,799 / 76,872 bytes) and `node --check` on it: exit 0, 6/6 (node v22.23.4). Control: each
raw .js copied to .mjs (top-level return): exit 1, 6/6; the copies were deleted.

**Stub byte check.** C/sets/s1c-work/final/check/run_stub_judges.mjs runs each wrapped body under node with stub phase,
pipeline and agent (nothing launched) and checks every call: the options (exactly label, phase Judge, agentType
epinoic-row-judge, model opus, effort high); the prompt byte for byte = judge.txt + "\n7. PASSAGES\n\n" + the fixed intro +
"\n\n" + the chunk file's bytes (the judge brief plus its passages); = its input file; UTF-8 round trip; every passage's
keys (id, subject, writer, [context], text, in order, nothing else) and alias form; batch-ids.json's aliases per chunk;
end to end through the alias map, each passage's subject, writer, context and text equal to the kept row's in
C/sets/overlap; a blind chunk without prompt-aware rows and a prompt-aware chunk with only prompt-aware rows; the REQ
line (brief_sha256, chunk_sha256, passages) against the files and HASHES; per panel every blind row judged once, every
prompt-aware row once, no file mixing them, labels unique, phases ["Judge"], the return value; and no row id string of
the alias map anywhere in a prompt.
`node C/sets/s1c-work/final/check/run_stub_judges.mjs <A|B> C/sets/batches/judge-<a|b> C/sets/s1c-work/final/check/judge-<a|b>-b C/sets/briefs C/sets/judge-chunks C/sets/inputs/judge C/sets/overlap`
(output check/stub-judges.out):
- panel A: files 3 (20 + 9 blind, 3 prompt-aware calls); REQ checks 32/32; calls 32; options 32/32; prompt == judge brief
  + passages byte for byte 32/32; == input file 32/32; round trip 32/32; passages end to end 1,259/1,259; blind rows
  judged once 1,139/1,139; prompt-aware rows once 120/120; labels unique; row id strings in prompts 0; prompts 22,699-
  24,287 bytes; failures 0; exit 0.
- panel B: the same figures, failures 0, exit 0.
- Controls (copies in a temporary directory, deleted afterwards; the real files unchanged, hashes above): (1) a copy of
  judge-a-b002.mjs with one passage key changed by one character: prompt == brief + passages 31/32, input file 31/32,
  FAIL, exit 1; (2) a copy of the overlap files with one kept row's text changed by one character: passages end to end
  1,258/1,259, FAIL, exit 1.

Nothing was launched. Launch order for S1d: judge-a/b001-b003 and judge-b/b001-b003 (the panels independently; never
parallel to a full-suite run, plan 2.2). Then `parse_rows.py judges --run-dir <the A runs> --run-dir <the B runs>
--inputs C/sets/inputs/judge --batch-ids C/sets/inputs/judge/batch-ids.json` (default --out-dir C/sets/judged), and the
alias map binds the verdicts to rows (S1e); the A/B disagreements go to a third judge C (blind and prompt-aware apart).
If top-up 2 is launched and its rows survive, they need a chunk of their own for both panels (aliases from r1260).

## Final checks

- `cd S && PY -m pytest -q C/tools/tests -p no:cacheprovider`: 189 passed (56.4 s, 11:50:25-11:51:22 UTC); no tool or
  test file was changed by this step (the new scripts are under C/sets/s1c-work/final/).
- No .pyc or __pycache__ newer than 11:33 UTC in the repository's src/ and tests/ (find -newermt on those two named
  directories): 0. The repository is at HEAD 29571f2d; its working-tree changes are fix-c3l's, and src/epinoic_logic/
  selfcert/ and branches/spanish_lexicon.py (the only repository modules this step imported) are unmodified there.
- Nothing written under /root/.claude/: the agents directory's mtime is still 08:09:50, the three run directories' are
  10:09:13, 11:32:33 and 11:16:57 (their last agents' times); they were read only.
- C/sets/s1c-work/final/AFTER.sha256 against BEFORE.sha256: 156 files unchanged (the plan and the rulings, the seen corpus
  and its manifest, shape.json, every tool and test, sizing.json and the cap's seed C/sets/seed, the write-w1, write-w2
  and write-topup1 batch and input files, the 44 brief files other than HASHES and SOURCES.json, the written and
  overlap files of P01-P04, N03, A1, A2, and the excluded-id files of N01, N02, N04, I1, I2); 18 changed (HASHES and SOURCES.json by the 5 top-up lines; written,
  overlap kept file and report of N01, N02, N04, I1, I2 by their top-up rows; parse_rows-report.json); 0 removed; 215
  added (24 written and 72 overlap files of wave 2; 5 top-up lines; the top-up 2 batch and its 5 inputs; the 6 judge
  batch files and their 65 inputs; the 37 files under C/sets/judge-chunks).
- Rules: no recursive command over S/wf or any parent of the held-out directory; W/c3b/heldout and C/ho-sealed never
  opened, listed or counted; no workflow and no agent launched; no row shown to any writer (no agent was given
  anything).

## For the orchestrator (observations, no action taken)

1. S1d is ready to launch: C/sets/batches/judge-a/b001.js, b002.js, b003.js and C/sets/batches/judge-b/b001.js, b002.js,
   b003.js (64 calls; b003 of each panel holds the 3 prompt-aware calls only). Each file is below the 520,000-byte bound
   of plan 6.3 (largest 496,905 bytes).
2. Top-up round 2 (C/sets/batches/write-topup2/b001.js, 5 calls) is written but is the orchestrator's to launch or not
   (section 3: due under 4.5's per-slot rule; no 4.3 minimum needs it; it would use the second of "at most two" rounds
   if 4.9 counts 4.5's rounds). If it is launched, parse_rows.py must be run over all four writer runs in launch order
   (w1, w2, top-up 1, top-up 2) with one inputs directory holding all 46 input files (C/sets/s1c-work/final/inputs-all
   plus C/sets/inputs/write-topup2): run over the top-up run alone it would rewrite C/sets/written/<slot>.jsonl of
   P05, P10, P14, P15 and N10 with the top-up rows only. Then overlap.py again for every slot in plan order, as in
   section 2 (so that the duplicate rule sees the new rows against every other slot), and a judge chunk of their own
   for both panels (aliases from r1260, never mixed with prompt-aware rows).
3. The cap of 440 will apply at S1e unless the judges drop more than 68 fresh positives (13.39%) and 71 hard negatives
   (13.89%); check_sets.py must keep every 4.3 minimum while capping, and the obfuscated share of the fresh positives
   (64 of 508, 12.60%) is the thinnest: 15 obfuscated rows dropped by the judges alone take it below 10%.
4. S1c's C/sets/s1c-work/check/make_mjs.py refuses any batch file whose REQ string literal holds the substring "export "
   (it did for both prompt-aware judge files, from a row's "export demand"); it was left unchanged, and
   C/sets/s1c-work/final/check/make_mjs_lines.py (per-line export check, byte-equal output elsewhere) was used here.
5. Spanish check beside 4.3's declared count: `is_spanish` reads only 58 of the 124 declared-Spanish fresh positives
   (it needs 8 function-word hits; the rows are 1 to 3 sentences); the paragraph reader reads 107. A check figure only;
   no row declared other than "es" reads as Spanish.
6. File modes: the judge batch files and the 64 judge input files hold row text (the passages) at gen_writer_batch.py's
   default mode 0644, while C/sets/written, C/sets/overlap and the chunk files are 0600. Left as the tool wrote them
   (single-user container); a chmod 600 would change no hash if wanted.
