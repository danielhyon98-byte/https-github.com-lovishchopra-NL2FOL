# S1d, panels A and B: parse, join, and what D18 does next (stage 2b, plan 4.8, 4.9, D18; rulings R-13, R-15)

Written by the stage-2b S1d step agent, 28 Nov 2026, from 12:18 UTC. Shorthands as in S1c-final.md:
S = /tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad, W = S/wf/phase2, C = W/c3l,
PY = S/z3venv/bin/python -I, T = /root/.claude/projects/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/subagents/workflows
(read only). This step's scratch: C/sets/s1d-work/ab/ (written D = C/sets/s1d-work/ab below). Counts, ids and hashes only:
no row text, no verdict reason, no brief text and no row id is quoted here.

Rules kept throughout: nothing under the repository (/home/user/https-github.com-lovishchopra-NL2FOL) was modified (it is
read only: parse_rows.py reads its CLAUDE.md for D7's instructions check); the repository suite, run_arena, list_labels
and run_sim were not run; no recursive command was run (every command names its files or one directory; the run
directories under T were listed one level); W/c3b/heldout and C/ho-sealed were neither opened, listed nor counted; no
workflow and no agent was launched; nothing was written under /root/.claude/ (the six run directories were read only);
nothing was sent to any agent, so no judge saw a writer's expected value, a set name or another judge's verdict.

## Baseline

- `cd S && PY -m pytest -q C/tools/tests -p no:cacheprovider`: 189 passed (56.16 s, 12:19:05-12:20:02 UTC), before
  anything was written.
- SHA-256 of every file this step reads or could touch (354 files: the plan and the rulings, shape.json, the seen corpus
  and manifest, every tool and test file, sets/briefs, sets/overlap, sets/written, both seeds, sizing.json,
  sets/judge-chunks (seed, alias map, MANIFEST, blind/, pa/), sets/inputs/judge, sets/batches/judge-a and judge-b, the
  S1c-final scripts and checks, S1c-final.md): D/BEFORE.sha256 (stderr empty). The output paths sets/judged,
  sets/s1d-work, sets/batches/judge-c, sets/inputs/judge-c and this file did not exist (checked at 12:18:54).
- The six judge runs, read from their journals (types, labels and toolsUsed only):

| Run | Panel, file | Labels | started / result rows | toolsUsed |
| --- | --- | --- | --- | --- |
| T/wf_9dda354f-6db | A b001 (blind) | judge:A:blind-01..20 | 20 / 20 | ["SubagentHandback"] 20 of 20 |
| T/wf_fbc8babf-467 | A b002 (blind) | judge:A:blind-21..29 | 9 / 9 | ["SubagentHandback"] 9 of 9 |
| T/wf_fda05b23-537 | A b003 (prompt-aware) | judge:A:pa-01..03 | 3 / 3 | ["SubagentHandback"] 3 of 3 |
| T/wf_4190fb0f-4c7 | B b001 (blind) | judge:B:blind-01..20 | 20 / 20 | ["SubagentHandback"] 20 of 20 |
| T/wf_b707ffec-c3e | B b002 (blind) | judge:B:blind-21..29 | 9 / 9 | ["SubagentHandback"] 9 of 9 |
| T/wf_32940b5d-133 | B b003 (prompt-aware) | judge:B:pa-01..03 | 3 / 3 | ["SubagentHandback"] 3 of 3 |

  Each directory holds exactly its agents' three files (agent-<id>.jsonl, .meta.json, .prefix.json) and journal.jsonl;
  no failed row; each label once.

## 1. parse_rows.py judges over the six runs (custom-type mode)

Command (12:20:19 UTC; stdout D/parse_rows.out, stderr D/parse_rows.err empty):
`cd S && PY -B C/tools/parse_rows.py judges --run-dir T/wf_9dda354f-6db --run-dir T/wf_fbc8babf-467 --run-dir T/wf_fda05b23-537 --run-dir T/wf_4190fb0f-4c7 --run-dir T/wf_b707ffec-c3e --run-dir T/wf_32940b5d-133 --inputs C/sets/inputs/judge --batch-ids C/sets/inputs/judge/batch-ids.json --mode custom-type --out-dir C/sets/judged`
(defaults: --shape C/probe/shape.json, the repository's instruction files; batch-ids SHA-256 ebd0316e88216a17...).
**Exit 0.**

- Agents 64: used 64, superseded 0, discarded 0, unusable 0; reasons none; no_handback_with_plain_text 0; labels
  without a used agent (rewrite) 0. **Executed-tool events: 0** (no stop of plan 2.3); stop false.
- Per run (agents used / discarded / re-asked / executed tools): wf_9dda354f-6db 20 / 0 / 0 / 0; wf_fbc8babf-467
  9 / 0 / 0 / 0; wf_fda05b23-537 3 / 0 / 0 / 0; wf_4190fb0f-4c7 20 / 0 / 0 / 0; wf_b707ffec-c3e 9 / 0 / 0 / 0;
  wf_32940b5d-133 3 / 0 / 0 / 0. No discard and no re-ask, so no reason to report.
- Every agent: agent_type epinoic-row-judge; granted tools ["SubagentHandback"] only; one SubagentHandback call; one
  assistant message; de-indent "equal" (it received exactly its input file); one model digest, 005912bee6ee... (the
  shape's); instruction lines 0; additions findings 0; journal toolsUsed ["SubagentHandback"].
- Verdicts: 64 batch files, every one complete against batch-ids.json (missing 0); 2,518 verdicts = 2 x 1,259; lines
  dropped 0 (no not-json, fields, id, verdict, reason, id-unknown, id-repeat or id-conflict line); reasons of more than 20
  words 2 (B-blind-28 1, B-blind-29 1), kept and counted (the parse rule). Per chunk, A and B give the same gated/free
  counts (blind chunks gated 21-23, prompt-aware pa-01 33/7, pa-02 33/7, pa-03 29/11).
- **Every blind row has exactly one verdict per panel, every prompt-aware row likewise**: panel A 1,139 of 1,139 blind
  aliases, each verdict from a blind call, and 120 of 120 prompt-aware aliases, each from a prompt-aware call; panel B the
  same (checked by join_ab.py, section 2: one verdict per panel per alias, from the chunk the alias map names).
  **Missing verdicts: none**, so no chunk is re-asked.
- Written: C/sets/judged/<A|B>-<chunk>.jsonl (64 files, mode 0600: they hold the judges' reasons) and
  C/sets/judged/parse_rows-report.json (format c3l-parse-rows/1, exit 0, SHA-256 d441063cb44337f0...).

**Cross-check, independent of parse_rows.py** (12:23:09 UTC; D/verify_ab.py, output D/verify_ab.out, stderr empty, exit 0):
`cd S && PY -B D/verify_ab.py --runs-root T --run wf_9dda354f-6db --run wf_fbc8babf-467 --run wf_fda05b23-537 --run wf_4190fb0f-4c7 --run wf_b707ffec-c3e --run wf_32940b5d-133 --inputs C/sets/inputs/judge --alias-map C/sets/judge-chunks/alias-map.jsonl --judged C/sets/judged --briefs C/sets/briefs`
It reads the transcripts directly: tool_use blocks per run are SubagentHandback only (20, 9, 3, 20, 9, 3), each tool
result answers that call, executed tools 0 in every run; the verdicts re-read from each delivery call equal
parse_rows.py's file of the label (64 of 64) and cover exactly the chunk's aliases; each task row holds every line of its
input file. Leak check: every user and attachment row of the 64 transcripts (everything a judge received) and judge.txt
hold 0 occurrences of the five set names, of the JSON keys "expected", "set", "slot", "category" and "language", and of any
of the 1,259 row ids. Control (same scan function): 0 on a real prompt; a copy with one "expected" key, one row id and one
set name planted gives 1, 1 and 1.

## 2. The join through the alias map

Command (12:21:32 UTC; D/join_ab.py, output D/join_ab.out, stderr empty, exit 0):
`cd S && PY -B D/join_ab.py --alias-map C/sets/judge-chunks/alias-map.jsonl --judged C/sets/judged --overlap C/sets/overlap --out-join D/ab-join.jsonl --out-summary D/ab-summary.json`
It checks every verdict file against the report's SHA-256, every alias map entry against its kept row (slot, set,
expected), one verdict per panel per alias from the alias map's chunk, and no verdict outside the map; joined 1,259 rows.
D/ab-join.jsonl (mode 0600; per alias: chunk, row id, slot, set, subject, expected, A, B, class; no text, no reason; never
shown to an agent; SHA-256 7b94c828a6405af2...) and D/ab-summary.json (574c8d5cb65ab506...). The independent join of
verify_ab.py gives the same classes.

| Set | Rows | Both with the writer | Both against the writer (D18: rejected) | A and B split | A with writer | B with writer | Cohen's kappa A vs B |
| --- | --- | --- | --- | --- | --- | --- | --- |
| fresh_positive | 508 | 508 | 0 | 0 | 508 | 508 | undefined: both gave "gated" to all 508 (p_o = p_e = 1) |
| hard_negative | 511 | 511 | 0 | 0 | 511 | 511 | undefined: both gave "free" to all 511 (p_o = p_e = 1) |
| injection (wholesale 60, targeted 60) | 120 | 120 | 0 | 0 | 120 | 120 | undefined: both gave "gated" to all 120 (p_o = p_e = 1) |
| prompt_aware | 120 | 120 | 0 | 0 | 120 | 120 | 1.0 (p_o 1, p_e 0.670; gated/gated 95, free/free 25) |
| blind, pooled | 1,139 | 1,139 | 0 | 0 | 1,139 | 1,139 | 1.0 (p_o 1, p_e 0.505; 628 / 511) |
| all | 1,259 | 1,259 | 0 | 0 | 1,259 | 1,259 | 1.0 (p_o 1, p_e 0.511; 723 / 536) |

A/B agreement rate 100% in every set and every subject. Within a one-polarity set kappa is 0/0: both panels used one
category for every row, so chance agreement is 1 and kappa is undefined, not low.

Per subject (rows / both with the writer / both against / split):

| Subject | fresh_positive | hard_negative | injection | prompt_aware | all |
| --- | --- | --- | --- | --- | --- |
| Biology | 32/32/0/0 | 32/32/0/0 | 7/7/0/0 | 8/8/0/0 | 79/79/0/0 |
| Business Management | 32/32/0/0 | 32/32/0/0 | 8/8/0/0 | 4/4/0/0 | 76/76/0/0 |
| Chemistry | 32/32/0/0 | 32/32/0/0 | 8/8/0/0 | 11/11/0/0 | 83/83/0/0 |
| Computer Science | 32/32/0/0 | 32/32/0/0 | 8/8/0/0 | 7/7/0/0 | 79/79/0/0 |
| Economics | 31/31/0/0 | 32/32/0/0 | 8/8/0/0 | 10/10/0/0 | 81/81/0/0 |
| English | 32/32/0/0 | 32/32/0/0 | 7/7/0/0 | 3/3/0/0 | 74/74/0/0 |
| English A: Language and Literature | 32/32/0/0 | 32/32/0/0 | 8/8/0/0 | 4/4/0/0 | 76/76/0/0 |
| English A: Literature | 32/32/0/0 | 32/32/0/0 | 8/8/0/0 | 7/7/0/0 | 79/79/0/0 |
| Environmental Systems and Societies | 32/32/0/0 | 32/32/0/0 | 8/8/0/0 | 6/6/0/0 | 78/78/0/0 |
| Geography | 31/31/0/0 | 32/32/0/0 | 8/8/0/0 | 8/8/0/0 | 79/79/0/0 |
| History | 32/32/0/0 | 32/32/0/0 | 7/7/0/0 | 11/11/0/0 | 82/82/0/0 |
| Language B: Spanish | 32/32/0/0 | 32/32/0/0 | 7/7/0/0 | 7/7/0/0 | 78/78/0/0 |
| Mathematics: Analysis and Approaches | 32/32/0/0 | 32/32/0/0 | 7/7/0/0 | 11/11/0/0 | 82/82/0/0 |
| Mathematics: Applications and Interpretation | 32/32/0/0 | 32/32/0/0 | 6/6/0/0 | 7/7/0/0 | 77/77/0/0 |
| Physics | 30/30/0/0 | 31/31/0/0 | 7/7/0/0 | 10/10/0/0 | 78/78/0/0 |
| Psychology | 32/32/0/0 | 32/32/0/0 | 8/8/0/0 | 6/6/0/0 | 78/78/0/0 |

Plan 4.8's report items: rows judged 1,259 (blind 1,139, prompt-aware 120); A/B agreement 100% (kappa above);
third-judge calls 0; rows dropped: judges against the writer 0, three-way split 0.

## 3. The panel C batch file: none (no A/B disagreement)

Rows on which A and B disagree: **0** (blind 0, prompt-aware 0; both joins). D18.2's third judge decides only those rows
(plan 4.8: "Rows on which A and B disagree go, batched, to a third judge C"), so there is nothing to chunk and no C call
is due. No C chunk directory, no new aliases, no seed or order was made, and nothing was written under
C/sets/batches/judge-c or C/sets/inputs/judge-c: **0 calls, 0 files, 0 bytes**. A C batch cannot be made empty either:
gen_writer_batch.py judges needs a chunk directory whose HASHES lists at least one chunk of 1 to 40 passages
(read_chunks, load_chunk). The .mjs syntax check and the stub byte check have no file to check and were not run.

## 4. What D18 does once C has judged, and what A and B already settle

The rule (plan 4.8, D18), per row: the panel's verdict is A's and B's common verdict when A = B, else the majority of A,
B and C (with A different from B, C's verdict is the majority); the row is kept iff the panel's verdict equals the writer's
expected value, otherwise it is dropped (never flipped, never moved to another set), before any label of the sets exists.

From A and B alone: **settled 1,259 of 1,259** (A = B on every row); **rejected 0** (both against the writer: none, so
nothing is dropped); pending for C 0. D18 therefore keeps every row: fresh_positive 508, hard_negative 511, injection
120 (wholesale 60, targeted 60; task-borne 19), prompt_aware 120. No row waits for C, so the panel's verdicts are final
and S1e (check_sets.py: the authoritative overlap rule, 4.3's minimums, the cap) can bind them through the alias map.
Since the judges dropped 0 rows (fewer than 68 fresh positives and 71 hard negatives), S1e's cap of 440 applies to both
large sets, as S1c-final section 3 foresaw.

## Final checks

- `cd S && PY -m pytest -q C/tools/tests -p no:cacheprovider`: 189 passed (55.62 s, 12:25:35-12:26:31 UTC); no tool or
  test file was changed (this step's scripts are D/join_ab.py and D/verify_ab.py).
- D/AFTER.sha256 against D/BEFORE.sha256 (the same 354 paths re-hashed): byte-equal, 354 files unchanged, 0 missing.
  In particular the alias map (11ee3e27...), the chunks and their HASHES, the judge inputs and batch-ids.json, the six A/B
  batch files, the briefs, the overlap files and both seeds are unchanged. Added by this step: C/sets/judged/ (64 verdict
  files and parse_rows-report.json), C/sets/s1d-work/ab/ (the two scripts, their outputs, ab-join.jsonl, ab-summary.json,
  BEFORE/AFTER hashes) and this file. Not created: C/sets/batches/judge-c, C/sets/inputs/judge-c, any C chunk directory.
- Nothing written under /root/.claude/: the six run directories' mtimes are as at the start (12:14:04, 12:12:21,
  12:11:26, 12:16:10, 12:14:27, 12:12:16) and the agents directory's is still 08:09:50.
- Repository: 6 bytecode entries newer than 12:18 UTC in its tests/ (find -newermt on the named src/ and tests/): pytest
  9.2.0 assertion-rewrite caches of three repository test modules (tests/integration test_c3l_sim_labels and
  test_selfcert_label_service, tests/e2e test_arena_label_runs) at 12:21:40, 12:24:00 and 12:24:51. Not this step's: its
  only pytest runs (12:19:05-12:20:02 and 12:25:35-12:26:31) ran C/tools/tests alone (rootdir outside the repository;
  its conftest sets dont_write_bytecode), every other Python call ran with -I -B, and nothing here imports a repository
  test module. The names and times fit the concurrent fix-c3l round (wf_cb3b3251-0bc) running repository tests. 0 in src/.
- Rules: no recursive command over S/wf or any parent of the held-out directory; W/c3b/heldout and C/ho-sealed never
  opened, listed or counted; no workflow and no agent launched; nothing sent to any agent.

## For the orchestrator (observations, no action taken)

1. Both panels agree with every writer on every row (1,259 of 1,259; per chunk the panels' gated/free counts are equal to
   each other and to the expected counts). This was checked as a possible leak, not assumed: everything each judge
   received holds no set name, no "expected", "set", "slot", "category" or "language" key and no row id (the scan's
   control finds a planted one), every judge received exactly its input file (de-indent equal), and the verdicts re-read
   from the transcripts equal parse_rows.py's files. So D18 drops nothing and C has nothing to decide. 100% agreement shows
   that two strongest-tier judges reading the same brief find every row unambiguous; it says nothing about how hard the
   rows are for the label. Report kappa as "undefined (one verdict for every row)" in the three one-polarity sets, not 0
   or 1.
2. Judging used 64 calls (plan 4.8 estimated about 65 with the third judge); third-judge calls 0.
3. S1e can bind the verdicts now (every row kept by D18); the cap of 440 removes rows from both large sets (508 and 511).
4. Top-up 2 (unlaunched): if it is launched and its rows survive, they need a chunk of their own for A and B (aliases from
   r1260); a C chunk tool is needed only if A and B split on one of them (none was written now: nothing to chunk).
5. C/sets/judged/*.jsonl hold the judges' reasons and D/ab-join.jsonl holds each row's expected value beside both
   verdicts (both mode 0600); neither may be shown to an agent (plan 4.8: a judge never sees another judge's verdict or a
   writer's expected value).

## Addendum (orchestrator, 28 Nov 12:4x): corrections from the independent check

The text above stays as written. Corrections:

1. "The 6 runs in launch order": B b003 (wf_32940b5d-133, run directory born 12:11:30.64Z) was launched before B b001
   (12:12:47.63Z) and B b002 (12:12:47.69Z) but was passed last. Every label has exactly one agent, so the order decided
   nothing.
2. "Equal parse_rows.py's files in 64 of 64 runs" should read "in 64 of 64 calls" (there are 6 runs).
3. "Every other Python call ran with -B": five operator calls (12:18:44, 12:20:41, 12:22:25, 12:24:16, 12:25:30) ran with
   -I and without -B. All import only json, so the repository bytecode is still attributed to fix-c3l.
4. The "6 pytest cache files" are 4 files and 2 __pycache__ directories. One is a plain test_c3l_sim_labels.cpython-313.pyc
   (12:21:40), and the last is at 12:24:51. More repository .pyc files appeared from 12:28 to 12:34, consistent with
   fix-c3l's test runs.
5. Kappa per subject (plan 4.8), computed by the orchestrator from D/ab-join.jsonl, all sets pooled (n; A's gated/free):

| Subject | n | gated | free | kappa A vs B |
|---|---|---|---|---|
| Biology | 79 | 46 | 33 | 1.0 |
| Business Management | 76 | 44 | 32 | 1.0 |
| Chemistry | 83 | 48 | 35 | 1.0 |
| Computer Science | 79 | 46 | 33 | 1.0 |
| Economics | 81 | 47 | 34 | 1.0 |
| English | 74 | 42 | 32 | 1.0 |
| English A: Language and Literature | 76 | 44 | 32 | 1.0 |
| English A: Literature | 79 | 46 | 33 | 1.0 |
| Environmental Systems and Societies | 78 | 45 | 33 | 1.0 |
| Geography | 79 | 46 | 33 | 1.0 |
| History | 82 | 46 | 36 | 1.0 |
| Language B: Spanish | 78 | 44 | 34 | 1.0 |
| Mathematics: Analysis and Approaches | 82 | 47 | 35 | 1.0 |
| Mathematics: Applications and Interpretation | 77 | 44 | 33 | 1.0 |
| Physics | 78 | 44 | 34 | 1.0 |
| Psychology | 78 | 44 | 34 | 1.0 |

   Within each subject's fresh-positive, hard-negative and injection rows kappa is undefined (one verdict for every row).
   Within prompt-aware rows it is 1.0 in 13 subjects and undefined (one verdict for every row) in Business Management
   (4 rows), English (3) and English A: Language and Literature (4).
6. Independence (ruling R-17): A and B received byte-identical prompts for all 32 chunks (same brief, same passage order,
   same model and effort), and 78 of the 1,259 reasons are word-for-word the same in both panels. A and B received
   identical prompts, so this agreement measures how stable one judge setup is, not two independent readings.
