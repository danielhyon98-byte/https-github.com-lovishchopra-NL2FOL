# progress c3l r2
- started; read rulings, plan 3.1/3.2/R2; code read (render, inputs, labellers, record)
- in progress: I15 render/inputs; then I16 RecordedLabeller; I18 call cap + flights; record revalidate; tests
- done: I15 (render/inputs/__init__; golden 1,7,8 match), I16 RecordedLabeller, I18 cap + flights in labellers, record revalidate L3. next: run tests/selfcert_label, rewrites, new tests
- done: rewrites T15 (test_input), test_attack16 #9, T10 (test_validate); new test_c3l_keys.py, test_c3l_call_cap.py pass; label test_linear rewired to paired. next: README/docstrings, full tests/selfcert_label + tests/selfcert, outside label tests, timing
- done: tests/selfcert_label 306 pass + 2 T17 (KIT); tests/selfcert pass; faithful fake + overseer BM pass; outside label tests 177 pass, 1 fail e2e r1-adv baseline (530-sentences file oversized, R7a). next: timing under tests/branches load
- done: timing runs 1-2 under tests/branches load (r2/timing1.log, timing2.log): 451 passed each; max ratio 4.27 (reader letter-spaced), label anchoring 4.10; none under 25% headroom. next: hygiene grep, final review, StructuredOutput
- done: revalidate tightened (retry only where cap leaves a call; never after truncated/oversized) + test; reruns green except T17 (KIT) and e2e r1-adv (R7a). next: StructuredOutput (final)
