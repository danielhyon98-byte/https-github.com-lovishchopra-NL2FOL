# progress c3l r1

- done: paired helper in tests/selfcert/test_linear.py, family test rewired; tests/selfcert/test_c3l_paired.py (6 tests) written
- done: tests/selfcert 5555 passed
- done: timing run 1 (384 passed; logs r1/timing1.log probe1.log; parse with r1/parse.py)
- in progress: timing runs 2 and 3 (with --durations=0)
- next: StructuredOutput with measurements
