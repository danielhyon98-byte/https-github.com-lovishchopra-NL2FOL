# progress c3l r1

- done: paired helper in tests/selfcert/test_linear.py, family test rewired; tests/selfcert/test_c3l_paired.py (6 tests)
- done: tests/selfcert 5555 passed
- done: timing runs 1-3 under tests/branches load (logs r1/timing<k>.log, probe<k>.log; sweep_probe, shapes_probe)
- findings: tests/engine/test_stem_shapes.py median-per-shape failed in run 3 (rearrangement_root_pass 50.6 ms vs 50); test_c3d_holds misspelt words with no stop 5.10 in run 2
- next: StructuredOutput (final)
