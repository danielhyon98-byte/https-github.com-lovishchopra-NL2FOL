# progress c3l r7a
- started (fresh; no earlier progress file). Read rulings, plan 3.1/3.2/R7a, D-sections. Reading code.
- done (code, untested): arena_labels.py (R-1.2 format, recorded_under/served_under, describe flag + _ServedRecordings, read_key_file, key_from_options, labels_dir, names .a1/.mut-, labeller_line, provenance line); run_arena.py (labels_dir, write=, round_dir to delivery_pass/_feedback_replay, --labels-dir/--label-key-file/--require-recorded, unrecorded_labels, labeller line); relay_peer/revision_feedback/stress_arena I13; list_labels.py rewrite (RequestRecorder serving, --missing, --faults-out, --rows-out [r2 11/11 ok], --mutations/--variant, request_format); bind_labels.py rewrite (I17, closed tier/adapter, --out, --current-listing, stop_reason, byte-exact)
- next: label_freeze.py; measure_labels.py rewrite; tests (test_arena_labels rewrites + test_arena_label_runs new); README
- own rounds copy: fix/rounds-r7a; scratch under fix/r7a
