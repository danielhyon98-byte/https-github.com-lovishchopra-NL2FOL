# progress c3l r7b
- started fresh (no earlier progress file). reading rulings, plan.
