# progress-c3l-check (check fixer)
Started fresh (no earlier progress file). Probes under fix/check/.
## Items (lens findings), status
1 DONE (ClassPort refuses CORE-SELF receipts; row_state never allowed with reader codes)
2 DONE (reader_state, reader counts)
3 DONE (measure_labels is_composite/_row_span Refusal)
4 DONE
5 DONE
6 DONE (ML.row_problem; LR, gate_service_turn via ML; gate_paths own copy; tests adapted: R7a 2, R7b 1, R5 1 (ids), R6 1 (full I5 rows))
7 PARTIAL: validate.py canary whole-word + every span (40->21 of 6320 on probe misfile.py); residual NOT DONE (identical canary/template); tests test_c3l_canary_binding.py; LABEL_USERS pin updated
8 DONE (run_sim.label_measurement + line; 2a test made stricter)
9 DONE (served_under current pair; line says requests served)
10 DONE (deleted)
11 DONE (not run, counted apart)
12 DONE (as_writer request=row request)
13 plan values 208/213 (rejected positives, packs.py) - todo
14 DONE (bus _unquote_named_sentences)
15 DONE (same guard, every non-INT-SELF message)
16 DONE (answer_label_text structured: claims beyond response; prose unchanged)
17 DONE (_refused_before_label)
- own rounds copy: fix/rounds-check
- note: overseer tests need: python -I -m pytest -c pyproject.toml ... from repo root
- dev path7 faithful: pos 196 withheld, 2 refused KIT-DL-001, 10 English not run; neg 141 allowed, 62 refused, 1 withheld. unconfigured: neg 203 withheld 1 refused 9 not run
- next: targeted validation (channel/branches/integration/e2e label tests), then owner leftovers (test28 r1-adv parse note, sim T16 tests), timing, then left_undone
- leftover test28 r1-adv: DONE (bus _hub_parser_notes excludes exact English parser note; test_6 added); t28 3/3 pass on rounds-check
- in progress: validation channel+translate (check/val-ch.log)
- in progress: timing (check/timing1.log) || tests/branches (check/branches.log)
- done: val channel+translate 5979 passed; e2e: only KIT pin + 2a no-outcome test (fixed: refuse only no-text rows, CLI refuses no labeller); integration: only known NOT DONE/KIT pins (+ T1 real overseer flaky once under load, passes alone)
- done: timing1 (15 files || branches): 1429 passed; max growth 4.471 (25.5% headroom), measure max 6% of bound
- done: overseer T1 pinned refusals regression from structured claims (shadow replays prose answers via respond): respond(prose=) kwarg + shadow passes prose for response_text -> fixed; script_labellers test row adapted
- in progress: harness compare r7/r5 new vs old structured rule (check/harness-*.json); branches.log
- harness r7/r5 faithful: identical with/without structured-claims rule
- branches 13310 passed; overseer T1/script/journal 46 passed; running overseer suite (check/val-ovs-all.log) and selfcert
- selfcert+selfcert_label 5865 passed (T17 deselected); e2e label files 156 passed + KIT pin. waiting overseer suite; then StructuredOutput
