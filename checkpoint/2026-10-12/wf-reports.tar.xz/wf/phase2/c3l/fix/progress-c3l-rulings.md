# progress-c3l-rulings (rulings fixer, R-20)
Order: item 6, 2c, 3, 2a/2b/2d/2e, 4, 5. Items 1,7,8,9 carried. Probes in fix/rulings/.
- [x] item 6: NOTES tuples (english/history/stem parser, generic_structured, sources; inline notes hoisted to *_NOTE), pieces.PARSER_NOTE_MODULES + parser_notes() + undelimited shape, report_texts drops exact notes, bus._hub_parser_notes -> parser_notes(); test tests/selfcert/test_c3l_parser_notes.py (25 pass)
- [ ] item 2c packs.py context
- [x] item 2c: packs._self_certification(report, r, request_text) truth_item via selfcert.context_for; self_report.request_reading contextvar + task_context truth_item; markdown.in_quotation_task sets it when request_text kwarg given (channel, overseer re-parse, delivery policy all pass request_text to accepts_request_text parsers). 'Final answer: correct.' now allowed path 1, refused (INT-REQ-012) 2-6. TODO test for 2c.
- [x] item 3 code: SuppliedTextIn.author (max 200, hub bound), turn.py maps author; test _raw_for passes author. TODO run parity test; docs line in integration-contract 0.11 para.
- probes: fix/rulings/gp_probe.py (needs main guard; run from repo root), one_row.py
- item 6 extended: sources attribution notes + own-correction notes shapes in pieces; generic_parser NOTES (_UNBALANCED_NOTE hoisted), in PARSER_NOTE_MODULES; test AST covers returns/builders/uncredited whys (26 pass)
- item 3: parity test now differing [] but (56,55,[ch-t13]) vs plan (56,54,[ch,lit]): lit-t13 refused only under T16's short_answer task type; arena uses marking_feedback -> reader passes. Plan value wrong -> NOT DONE (keep failing)
- item 4: T16 beyond-prose now 0 (4 were sources attribution notes, now excluded by item 6); fifth unidentified -> NOT DONE (keep failing)
- item 2 faithful measured (after 2c): paths1-4,6 pos 206 withheld+2 refused(INT-REQ-009 bidi, heading); neg p1 212 allowed 1 refused ((A1) INT-REQ-009); p2-4,6 192 allowed 21 refused (20 INT-REQ-012 + (A1)); p5 4/4, 0/2
- item 2 tests: path 7 dev tests added in test_c3l_sim_labels (faithful 196/2/10, neg 141 allowed, refused DL-001 1, DL-002 20, DL-011 42, 9 not run; unconfigured neg 203/1/9; unmapped subject KIT-REQ-015) - pass. gate_service_turn: author mapping + refused (service) by code. R6 gate tests restated (REJECTED_*, NO_ANSWER_NEGATIVES) - running
- item 5 done: CLAIMING_VERSION input; new reader-refusal test (0 flights) - pass
- docs: channel README, integration-contract 0.11 para (author)
- next: gate tests result, then validation (selfcert_label, selfcert, contract, integration, e2e label runs/sets, gate paths), timing, left_undone
- gate path tests (R6 file) restated: 7 passed (152 s). selfcert_label+contract: only T17 KIT pins fail (822 passed). tests/selfcert running.
- next: tests/integration + tests/e2e/test_arena_label_runs.py + test_arena_label_sets.py (rounds-rulings), timing with branches load, hygiene, left_undone
- validation: selfcert 5579 pass, 2 fail (c3e_check import-form -> fixed pieces imports `from ..x.y import NOTES`; c3d_holds linear under concurrent integration load, passes alone). integration+e2e label runs/sets: only items 3,4 NOT DONE + KIT pins (test_generated, test_manifest x2).
- running: val_A (channel, adapters, adapters_history, stem, e2e, arena rules) and val_ovs (overseer suite). next: timing with branches load
