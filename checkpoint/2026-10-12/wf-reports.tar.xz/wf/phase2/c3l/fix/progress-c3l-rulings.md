# progress-c3l-rulings (rulings fixer, R-20)
Started. Order: item 6, 2c, 3, 2a/2b/2d/2e, 4, 5. Items 1,7,8,9 carried.
- [ ] item 6 parser notes
