# progress: push check c3f (08c4a36b) lens critical-fixes
- started; nothing done yet
- worktrees: /tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/wf/phase2/c3f/push-check/cfh (a9129c78), /tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/wf/phase2/c3f/push-check/cfn (08c4a36b); probes copied from c3e cf-probe into /tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/wf/phase2/c3f/push-check/cf
- DONE identity: rule0 call site + self_report now in policy_id (cfh unchanged on mutation, cfn changes); output in ident/
- RUNNING fresh3 probe (60 pos/20 neg) bg; carried2.json built (155 pos) to run next
- DONE ge-t15 rows (cf/out/ge_rows.txt): all 8 wrong figs ENTAILED->COUNTEREXAMPLE fixed; 'per-person' gas phrasing no check on both (major)
- DONE sp-t14 (cf/out/sp_rows.txt): catorce 1960 fixed; 'Un 25%..equivale a 30' fixed; 'Hoy... más de cien' no check both (major)
- DONE ownverdict lengths (cf/out/pad2.txt): cfh 13/45 delivered NC, cfn 0/45
