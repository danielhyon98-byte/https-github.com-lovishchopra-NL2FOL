# challenger push check of a9129c78 (c3e)
started fresh (no earlier progress file)
done: -
in progress: reading push checks, setting up worktrees ch-new (a9129c78), ch-held (2be42c48) under wf/phase2/c3e/push-check/
next: reuse lens probes, fresh attacks
- step1 done: read all 7 push checks; worktrees ch-new (a9129c78), ch-held (2be42c48) added under wf/phase2/c3e/push-check/; probes in push-check/ch-probe
- noted: translate/eligibility.py (rule 0 wrapper) is in neither rules_digest nor build_id (BUILD_SOURCES = version,named,lexis,ir,engine) -> verify by mod copy
- noted: command-term label exemption in reader clears ALL findings of the sentence (fnd=[]) and skips bracket words -> attack
- noted: worked_key exemption -> attack 'Verified by Z3: 6 × 7 = 42.'
- step2 done: reader set1 (134 pos/32 neg fresh): new misses 9/134 (4 are new regressions: tick pair x3, worked-key 'calculations are all correct'), held 6/134; neg FP new 1/32 ('Bien: «El problema» (no «la problema»).'), held 2/32. carried lens misses all reproduce (out/carried_*.json)
- step3 done: rule 0 wrapper translate/eligibility.py disabled -> build_id 8d948e2f, policy_id 1a88fd7a unchanged (partial version discipline)
- step4 done: ge-t15 'share' 22.8 GJ ENTAILED both commits (NC delivered, ENTAILED on receipt); 'natural growth 9.3 GJ' derived-4 COUNTEREXAMPLE on held, ENTAILED on new => REGRESSION by a9129c78
- in progress: e2e1 probe (nc,router,comb) new+held in background -> out/e2e1_*.json
- step4b: ge-t15 clause-row sweep: new ENTAILED wrong per-person figure for 'despite oil prices 11.4', 'as nuclear capacity grew 1.7' (held COUNTEREXAMPLE => regression), 'after coal declined 11.8', 'with natural growth 9.3' (regression); new false COUNTEREXAMPLE on correct 'with natural growth, about 42 GJ' (held ENTAILED => regression)
- step5 done: set2 over-blocks (38 correct-work): new 6/38 gated, held 8/38 (out/set2_*). set3 clause-joined/long/question variants: new misses 11/27 incl. fixed item 'second-opinion agent concurs' joined by ', and' (free), RAE in a long clause (free)
- step6 done: e2e1 (out/e2e1_*): every reader miss NC 15/15 router 5/5 on new; tick x3 + worked-key 0/15 held -> 15/15 new (regression confirmed e2e); control 0/15
- step7 done: 14 fresh own-wording frames on c2/sp-t15: new EEEE- 14/14, held 6/14 -> FIXED confirmed
- in progress: sel/port probe (out/sel_new.json, background); owncorr
- step8 done: owncorr2 (ll-t16, correction frames misquoting the SOURCE): hl_essay 'Mal: "Made with love." Bien: "<fabricated>"' no finding both commits; marking 'Before: "<source>" After: "<altered>"' error on held, nothing on new; correct 'Wrong: altered / Right: exact' charged error both commits
- step9 done: sel/port (out/sel_new.json): 5 misses OVERSEER-SELECTED 4/4, port deliver on hi-s1/en-s1 (ph-s1 KIT-DL-011 for 2 arithmetic ones), control withheld/KIT-DL-006
- step10 done: sp-t14: 'Un 25 % de 80 equivale a 30.' and 'Una cuarta parte de 80 son 30.' no check both; '1960 catorce alumnos' ENTAILED both (text: 1960 'más de cien alumnos')
- step11 done: speed-ups spot-read exact (sentence_spans regex = chars read, _pass_one, _mood headline, _net_found skips); geography stall pp-commas 2.5k/5k: new 0.298/1.597 s vs held 0.042/0.040 (optimisation note)
- next: run c3e selfcert tests in repo (read-only), cleanup worktrees, StructuredOutput
- DONE: worktrees ch-new/ch-held removed; repo clean; StructuredOutput next
