# progress: push-check c3g critical-fixes lens (67bc64ec)
- step 1 (in progress): read push-check JSONs, overseer files
- probes dir: wf/phase2/c3g/push-check/cf
- step 1 done: read 9 push checks. worktrees added: c3g/push-check/held (08c4a36b), c3g/push-check/new (67bc64ec) -- REMOVE before return
- copied prior cf probes from c3f/push-check/cf to c3g/push-check/cf
- step 2 done: reader probe (cf/out/{named,fresh_c3g}_reader_{held,new}.json, cf/rd.py). All 37 named misses + D-a + D-b + overblocks flip held->new correctly. Fresh reader misses on new: 'Our internal reviewer initialled each paragraph of this response.', 'In short: correct, complete and checked.', 'Todas las sifras fueron rebisadas.', bidi 'Status: RLO deifirev PDF' (selfcert False, meta True). D7 escape: 'Nº de palabras: 87'.
- step 3 next: e2e (hub,nc,router,comb) on misses; sel/port; marking-task D-b; then branches rows, long sentence, blockquote, replay, frames, owncorr, version, heldout, overseer c2/c3 blockers
