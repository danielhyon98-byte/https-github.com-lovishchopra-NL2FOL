# progress: push-check c3f lens branches-policy (08c4a36b)
Work dir: push-check/bp/ (my own; other dirs belong to other lenses)
Done: (none)
In progress: reading context
Next: arena copies c1 c2 c3; row probes; timing; policy identity worktrees
Done (18:30): worktrees bp/new (08c4a36b) bp/held (a9129c78); arena c1/c2/c3 new runs started in bp/runs (logs *.log);
  identity copies bp/id/{base,sel,elig,sr,srctx}: all 4 edits change policy_id (base d5d566cb58d5aa0d); held policy 1a88fd7a -> new d5d566cb;
  held-signed result is stale under new (release_check). Manifest --check rc=0, sha256sum rc=0 (359). NO POLICY_VERSION/SELFCERT_RULES bump though rule 0 readings changed.
Done (18:45): ge-t15 sweeps (bp/rs_ge15_{new,held}.out, bp/rsc_{new,held}.out). Named items all OK on new. NEW CRITICAL REGRESSION:
  'Energy supply per person, while coal declined, was about 11.8 GJ in 2025.' ENTAILED (held COUNTEREXAMPLE); clause between subject and verb: 6/42 wrong ENTAILED on new (coal/oil/natural gas), 7/42 on held (other positions).
Next: delivery check of that, sp-t14 sweep, timing, recorded8, arena compare, own-text/twins.
Done (18:55): sp-t14 sweeps bp/rs_sp14*_{new,held}.out: named 1960 catorce FIXED (and 5 year variants); STILL CRITICAL (pre-existing, both): reopen/present
  with the 1960 figure, e.g. '6. La escuela reabrió con cien alumnos.' language-b-supplied-figure-4 ENTAILED (7 variants). Delivery probe bp/probe/clause_deliver.py: NC delivers the ge clause one with ENTAILED.
Next: timing geography._build, hub 14.9KB, recorded8, arena compare, twins/owntext, tests diff for weakening.
Done (19:05): timing geography._build linear on new (pp-commas 0.038/0.066/0.121/0.282 s); hub 14.4KB 2.1 s, 42.9KB 3.7 s. recorded8: only c2/ge-t15 changed: +2 ENTAILED import-share checks (38%, 54%, correct).
Done (19:20): twins 23/24 (held 22), variants 27/27, spshare 22/22 (held 19), owncorr ok, qframes2 24/24, wrongpass ok; sp-t14 share fixed.
  ge-t14 columns: CRITICAL pre-existing both: 'The pedestrian count, as retail use fell, was 60 at site 4.' and 'At site 2 the EQS, with pedestrian numbers high, was 186.' ENTAILED, correct twins COUNTEREXAMPLE (bp/out/cols14b-*.out).
  NOTE clearance/cN/results.json were rewritten 17:50-17:59 by the fixer (new code) -> compare against held runs (c2/c3 held running, c1 held next).
Next: arena compare held vs new; selfcert fresh phrasings on branches (sc_branches3.py); write result.
Done (19:35): selfcert fresh on branches (NC config): batch sc_lists3 0/50 delivered, overblock 1/25 ('Prueba: si el total es 80, el 25 % es 20.');
  batch sc_lists4 5/40 delivered on both branches (bp/out/sc5-new.out) -> class OPEN 5/90 = 5.6%.
Done (19:50): c2 held vs new: only ge-t15 (6 records) +2 ENTAILED import-share checks; c3 0 changed; counts equal. D7: 'Word count: 17','Palabras: 25' withheld, 'Número de palabras: 42' delivered (D7 uneven).
  sp-t16 regression (fail-open, unchecked): 'El intercambio, según la consigna, duró dos semanas.' COUNTEREXAMPLE on held, no check on new.
  Running: c1-held arena, targeted pytest (bp/pytest-targeted.out).
Done (20:10): c1 held vs new 0 changed; counts c1 203/203 (159/159 faulty), c2 188/188 (147/147), c3 164/176 (128/132) equal on both.
  targeted pytest 1211 passed. Rule 0 readings changed held->new ('I can confirm...', 'Two reviewers...' wholly True on new) with NO POLICY_VERSION/SELFCERT_RULES bump.
  Named over-blocks fixed (held 4/7 -> new 1/7). Root cause ge regression: geography._YtIndex subject = first verb even inside a mid-sentence subordinate clause.
Next: remove worktrees bp/new bp/held, return StructuredOutput (hold).
Done (20:12): worktrees removed (git worktree list shows none under bp/); repo clean at 08c4a36b. Returning StructuredOutput: hold.
