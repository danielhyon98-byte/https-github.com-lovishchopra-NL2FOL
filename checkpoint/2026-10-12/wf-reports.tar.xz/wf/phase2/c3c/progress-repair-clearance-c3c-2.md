# repair-clearance-c3c-2 progress
- started: investigating test_linear 'repeated not' timing
- Profiled 'repeated not' (CPU, caches emptied): HEAD 8K..256K 0.048/0.095/0.205/0.421/0.822/1.18 (exp 0.91-0.96); tree 0.049-0.056/0.098/0.20/0.43/0.87/1.19-1.29 (exp 0.93-0.97). Tree = HEAD and linear. Alone: test 16 passed (ratio ~4); tests/selfcert 2099 passed (0.05 vs 0.21).
- In progress: replay shard-1 files 60..127 in one process (r2rep/) to see if the process state reproduces 0.36 s.
- (replay started in background, log r2rep/run.log; profiling of new encoded.py scanners: linear 0.002/0.01/0.027/0.13 s at 8K/32K/128K/512K)
- Replay of shard-1 files 60..127 (one process, 3749 passed): repeated not 0.049/0.198 s (ratio 4.0).
- All ten heavy families, HEAD vs tree, 8K..64K CPU: exponents 0.97-1.06 both; tree on par with HEAD. Under 3 parallel reader loads: same.
- Failing case alone x3: 1 passed each (one run showed a 0.363 s sample at 32K and 0.083 s at 8K: machine noise); file 16 passed; tests/selfcert 2099 passed.
- DONE: verdict load-induced; no repository file changed by this run. Report returned.
