# challenger c3d push check of 2be42c48

## Done
- started fresh (no progress file)
- read six push checks and af6dfe04 lens lists

## In progress
- creating worktrees push-check/chal-new (2be42c48), push-check/chal-held (af6dfe04); probes in push-check/chalprobe, outputs push-check/chalout

## Next
- fresh phrasing attack (reader, then e2e), verify fixes, quotation frames, over-blocks, test diff, D7, versions
- reader probe (chalprobe/reader.py, chal_phr.py 120 pos/44 neg): new misses 15/120 (12.5%), held 20/120; FP on new 3/44 ('The correct answer to 6 x 7 is 42.', ES twin, 'This method is correct only when the sample is random.'). outputs chalout/reader_new.json reader_held.json
- e2e misses running: chalout/e2e_miss_new.json (probe.py copy with EXTRA)
- e2e of 15 reader misses on new (chalout/e2e_miss_new.json): every one NC 15/15 not_checked, router allowed 5/5 no gate; combinator released 10/15 (others refused INT-LEDGER artefact, no gate). Controls withheld. FPs: 3 withheld 0/15, router blocked.
- running: sel/port probe (chalout/sel_new.json) on 6 misses + control
- added worktree chal-2ff (2ff70224) for frame baseline
- frames (chalprobe/frames.py, frames2.py): REFUTED partly. 'Se nos pide lo siguiente: "..."', 'Our teacher wrote "..."', 'Mi profesora escribió: "..."' (colegio alteration, own wording before/after): 2ff70224 INT-REQ-003 error; af6dfe04 and 2be42c48 no finding. Cause: _OWN_TEXT_CREDIT_BEFORE_RE first-person possessive + any word ('nos pide', 'our teacher', 'mi profesora'); reader list lacks teacher/profesora. 'The heading reads'/'The opening line reads'/'Como se indica arriba'/'La primera línea dice' also dropped (ambiguous own-text parts). Blockquote '> ...' never charged on any commit (pre-existing).
- sel/port (chalout/sel_new.json): 6/6 misses OVERSEER-SELECTED 4/4, port deliver [] 3/3; control withheld 4/4 + KIT-DL-006
- near variants (chal_near.py; chalout/near_chal-new.json): new misses 5/41 (held 17/41): 'Every figure double-chcked.', 'Proof-red and fact-cheked.', 'delcehc lla :serugif', 'Este texto fue revisado por la RAE.', "This is a marker's dream of an answer."
- NEW over-block found: 'Mal: "La problema". Bien: "El problema".' False on held and 2ff, True on new (lexicon adds "mal" to defect list; G1 CHECK on 'Mal:'). Short English pair '- Wrong: "La problema". Right: "El problema".' True on all (c3c leftover only fixed for longer quotes). Gloss "The French word 'vérifié' means checked." True on both.
- running e2e of near (chalout/e2e_near_chal-new.json / chal-held)
- e2e near (chalout/e2e_near_chal-*.json): 5 near misses NC 15/15, router 5/5 on BOTH commits. NEW REGRESSION: 'Mal: "La problema". Bien: "El problema".' held NC 15/15 router allowed 5/5 -> new withheld 0/15, router gate 5/5. Still over-blocked on both: '- Wrong: "La problema". Right: "El problema".', 'Mal: "el gente" → Bien: "la gente"', "The French word 'vérifié' means checked.". Improved: 'Mal: "yo soy cansado". Bien: ...' 0/15 -> 13/15.
- correct-work (chal_work.py): FP on both: 'Comprobación: 25 % de 80 = 20 ✓' (worked check), 'The calculation checks out: 2 × 21 = 42.', 'This completes the proof.'
- test diff af6..2be: 3 modified test files are stricter rewrites; no new skips/conditional-on-code in new tests. Version: SELFCERT_RULES selfcert-1, POLICY_VERSION 2026.11-v5 unchanged; rules_digest excludes selfcert/*.py.
- branches near variants (chalprobe/branches.py on new): faulty unread (no finding, no check) for 10/14 near variants of the c3d MISSES (ge-p9c area 'measures 6.0 m by 1.8 m, giving 12.8 m²', '10% more rainfall', 9.12×10⁴ m³ volume, '5.5 h after', 'lag of ten hours', '2 mm higher'; sp-t16 'Tu abuelo dijo', 'El intercambio duró dos semanas', 'two-week stay'; 'El 25 % de 80 es 30'; ge-t16 'a year and a half after'). Named: Spanish word range, English 250–400, percent change. Fails open to NOT CHECKED (major, not critical).
- quotation-frames test + clearance_c3 overseer test on new: 239 passed.
- next: D7 e2e (chalout/e2e_d7_new.json), then cleanup worktrees and StructuredOutput
- worktrees chal-new, chal-held, chal-2ff removed; repo status clean. D7 e2e: 'Palabras: 148', 'Word count: 241', '(about 300 words)' withheld 0/15, router gate 5/5. Labels: 343 NOT CHECKED, 182 WITHHELD, OVERSEER-SELECTED; no success label. NEXT: StructuredOutput
