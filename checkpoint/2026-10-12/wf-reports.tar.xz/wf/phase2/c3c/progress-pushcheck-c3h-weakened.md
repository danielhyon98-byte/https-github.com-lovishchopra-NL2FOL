# push-check c3h weakened lens (84aff95c)
Started. Worktrees held/new/w08 under push-check/ pre-existed (other lenses): do not remove.
Done: -
In progress: reading push checks, diff 67bc64ec..84aff95c
- Step 1 DONE: read all 10 push checks + 67bc64ec lenses (dumps in c3c/pc_mid.txt, pc_late.txt, lenses67.txt). Published base = c4f276ca (epinoic/verified-updates Source-Commit, unmoved).
- Step 2 IN PROGRESS: add my worktrees wkh-held (67bc64ec) and wkh-new (84aff95c) under c3h/push-check/; diff analysis.
- Step 2 DONE: diff read. Close range 67bc64ec..84aff95c: no deletes; removed asserts = version pins (exact) + FREE->GATED moves (possibility 3 EN lines, 'Our results match the 2019 survey.', 4 correction pairs, '2021 census' moved to gated, 'censo de 2021' to UNNAMED). No timing/conftest/pyproject change; new timing asserts only added in new files; 3 importorskip(ModuleNotFoundError) added in new tests. Source: cap removals (_credit_pieces 64 & 200k, _scope_variant 200k), head masking removed, pair_keys removed, possibility frame removed. New fail-closed 'no check' paths: geography attached()==[] and _table_cells_clause continue; language_b skips replaced half in _supplied_figures (NEW skip).
- Step 3 IN PROGRESS: probes (reader flips, rates for re-withheld lines, geography/langb checked->unchecked).
- Step 3 partial DONE (probe dir c3h/push-check/wkhprobe; worktrees wkh-08, wkh-held, wkh-new are MINE, remove at end):
  * reader named.txt: all named regressions 111 on new (000 held); boundary(b) controls 000.
  * nc_rew.out: re-withheld correct lines NC 15/15->0/15 (possibility 3, 2019 survey, he-do-not 13->0, adverts 10->0, kitchen-not 0->0, kitchen 2->0, 2021 census, censo de 2021); named regressions withheld 0/15.
  * Geography REGRESSION found: total-row head + insertion ('Energy supply per person, at about 11.8 GJ in 2025, was high.') COUNTEREXAMPLE+INT-SUBJ-004 on 08c4a36b and 67bc64ec -> no check on 84aff95c (12 wrong cells, 2 heads 'Energy supply per person'/'Average energy supply per person' x 6 forms). test_c3h_branches.py:99-100 pins the correct 42 twin as ([],[]); wrong twin unpinned.
  * Language B: corrected half checked correctly; replaced half skipped by design (one COUNTEREXAMPLE instead of two).
  * cap/kl/longs2: fixed on new (1/1 at all N/lengths); moderator clause 0 on all (pre-existing class miss).
- NEXT: fresh class set + D-a/D-e/possibility/pair variants; run targeted tests; worktree removal; StructuredOutput.
