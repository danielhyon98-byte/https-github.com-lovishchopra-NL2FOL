# progress: push check c3d branches-policy (2be42c48)
work dir: wf/phase2/c3d/push-check/bp
- [ ] read push checks / docs
- [ ] arena c1/c2/c3 copies
- [ ] branch/own-text fixes probes
- [ ] POLICY_VERSION bump
- worktrees bp/wt-2be (2be42c48), bp/wt-af6 (af6dfe04) added; copies under bp/runs/{c1,c2,c3}-{new,base}; probes copied to bp/probe
