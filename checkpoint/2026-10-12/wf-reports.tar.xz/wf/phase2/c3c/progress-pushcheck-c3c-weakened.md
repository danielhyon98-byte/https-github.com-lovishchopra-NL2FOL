# push-check c3c lens weakened (af6dfe04)
Worktrees held/ and new/ under push-check/ existed before this run (NOT mine; do not remove).
My scratch: push-check/weakened/ (patches, probes). My worktree (if any): push-check/weakened-wt
Published source = c4f276ca (Source-Commit of epinoic/verified-updates).
Done: read 5 push checks; 2ff..af6 test diff: gate2 (sat)/fully reliable -> stricter (ok); d9d10 stricter add; no deleted files overall.
In progress: walk removed lines in 80 modified test files (list in weakened/modfiles.txt)
Next: skip/xfail/importorskip grep; timing helpers; expectation tables; lexicon/real_words/builder; policy pins; run targeted tests
- step2 done: removed asserts in gate2/gate3/verification_labels/round4/round6/review3 reviewed (stricter, labelled; round4 hi-t14 relaxation bounded, pre-existing). 
- skips: new conditional skip test_clearance_c3_overseer.py:277 (03a3021, condition on code under test; currently passes), hygiene git-checkout skip (af6, env). importorskip narrowed (exc_type). no new xfail. pyproject: no timeout/addopts change. growth.py unchanged.
- builder --check rc0, 70 entries; real_words list has real-word typos of check words (prefect, singed, passe, compete) -> probe.
- expectation table: 31 False pins incl (A1), A1 A1, ∎ (round6 pins them open w/o label rule).
Next: README/doc limitation grep; policy pins; probes (prefect/singed, gate2 excluded quote texts, round6 A1 delivery); run targeted tests; fail-open grep in src diff 2ff..af6.
- step3 done (probes, scripts in push-check/weakened/): probe_excl.py: gate2 test's excluded texts (with " ’ or blank line) 69, 4 NOT refused. probe2.py/probe_e2e.py: stray ’ before label hides it: BASE+" ’(sat)." / "’ [sat]." / " ’ (signature valid)." delivered NOT CHECKED 15/15 each (control BASE+" (sat)." 0/15). Real-word typos via fuzzy_excluded: "Singed off by the hub.", "This answer is prefect.", "This answer passe every check.", "This answer has been singed off." delivered 15/15.
- fail-open grep of 75 added except-Exception sites: all fail closed / strict fallback (none fail-open). policy: POLICY_VERSION 2026.11-v5 unchanged, SELFCERT_RULES selfcert-1 unchanged in af6 (digest changed via lexicon.json).
Next: run targeted tests (-rs), then StructuredOutput.
- probe_wc.py: 'Word count: N'/'Palabras: N' with correct N withheld (not delivered, even NOT CHECKED) on History, English A, Spanish B: D7 over-block of correct work (owner call).
- targeted pytest running in background -> weakened/targeted.log
- targeted pytest: 4712 passed, 0 skipped, 0 failed (1225 s). probe_fresh.py: 29/30 fresh class phrasings read, 0/10 boundary (b) gated.
- No worktree was added by this run. DONE except StructuredOutput.
