# progress c3c branches fixer
- started; reading inputs
- probe tool: wf/phase2/c3c/branches/probe.py (all round-8 items + push-check partials; baseline BAD 62). Run with z3venv python -I probe.py [prefix...]
- PLAN (not started edits yet):
  A worked.py breakdown reader (shared, decided to fix: reader of the packs' worked checks): Spanish point groups, label numerals (Storm 1), per-N-unit, out of N; chain line bracketed '=' equation
  B geography.py: table_change relative %, change_by years, against-pair %, word fractions times, request figures (area/date), unit conversion h->min, per capita PJ/GJ, growth between (V0 to V1), year-table credited figure, spearman n, case comparisons a-e, word count, request word figure, doubling (grew by, 'double in', r = 2, take N years to double)
  C language_b.py: opens with, más que, EN number words / years vs Spanish text (gloss), dated swap, usted claim subject, 'says' quoted form, byline, proposals count, hace N semanas, enumerated count, speaker paraphrase, category counts, paragraphs, poem items, euro/number words pct, Wrong:/Right: list
  OUT (left_undone): INT-REQ-003 own model quote (channel/own_text), selfcert Wrong/Right gate, ARG-BARE-001
- DONE A: worked.py breakdown labels/denominators/Spanish point groups (_LABEL_NOUN,_NOT_A_RESULT_BEFORE_RE); quant.py worked_equations bracket working after a chain result (first=k). probes OK. (tests/branches run pending)
- DONE B1: table_change relative % (share rows either), change_by skips year pairs, _pair_comparison (bracket pairs diff/pct/fold/share, detached-pair guard), event depth consistency (_DEPTH_RE,_EVENT_PHRASE_RE)
- DONE B2: request facts (_request_facts/_request_figures, dates), _labelled_fold, _conversion, _n_formula wired in _build
- DONE B3: geo word counts (_geo_word_counts incl. request word figure), per capita energy/mass units, growth between (_PERIOD_PAIR_RE, annual rate), _year_table_credited, doubling widened (_GROWTH_RATE_RE any %/yr or r=, _DOUBLE_RE take..to double, 70/r=, rate from sentence before). Geography probes all OK. NEXT: Language B items (C)
- DONE C1: grounded_figures dated-noun (comparatives, year-bound), language_b _normalise_es_figures (euro, number words). case-run baseline now1 logs in branches/cases
- DONE C2: language_b new readers (structure, occurrence, enumerated, categories, byline, paraphrase speakers, unquoted speakers, quote durations, cross-language counts via es.concept gloss, line paraphrases), event years EN/uncredited, quoted forms opens/says, address subjects, Wrong:/Right: lines. probe.py: only 3 out-of-scope BAD (INT-REQ-003 x2 channel, ARG-BARE). NEXT: base receipts, case sets, tests/branches, hostile timing, regression tests
