# progress c3c selfcert
- (4) DONE code: removed EPINOIC_SELFCERT_MEANING_DEBUG path from meaning.py (test to add in tests/selfcert/test_c3c_fuzzy_and_labels.py)
- (1) DONE code: lexicon.py fuzzy_targets/fuzzy_candidates/build(raw); light-verb family words now targets; scripts/selfcert/real_words.txt word source;
  builder rewritten (--check, --vet); lexicon.json fuzzy_excluded rebuilt (69). Tests TODO.
- (2) DONE code: new src/epinoic_logic/selfcert/encoded.py (rule N10 decoders), wired in reader.read_text (_IN_ENCODED guard) and
  __init__._read_plain (morse_text). Tests + tests/README 'Not done in this round' paragraph TODO.
- next: (3) (sat)/fully reliable + rewrite pins in tests/adapters/test_integration_gate2_parsers.py, (5) FPs, (6) misses
- (3) DONE: _bracket_status solver results + _logic_host; SRCEVAL own-claim (_own_claim_before) in reader; tests/adapters pins rewritten (NAMED_ON_EVERY_BRANCH + SOLVER tests) - passes
- (5) IN PROGRESS: production note widened in meaning._production_note (calculated/derived FPs fixed). Next frames: checks&balances, correct to 2 s.f., ONS match, court/defendant, pronoun outcome, cuentas cuadran, grammar sample quote, word count
- (5) frames added: meaning._c3c_frames (compound check noun, precision, ONS agreement, third-party defect, pronoun outcome, cuentas label), _mention_quote widened; word count FP left (decision D7 pinned by tests not mine)
- selfcert tests pass after frames (production stems restricted, named reference = capitalised/acronym)
- tests/selfcert/test_c3c_holds.py written (items 1-5); running
- test_c3c_holds.py passes (260 tests); next: README paragraph, dev sets, clearance records, overseer tests, phrasings misses (6)
- README paragraph rewritten; genuine c1-c3 paragraphs: 0 of 1090 differ vs HEAD; dev sets pass. Next: run adapters + overseer selfreport/delivery tests
- (6) added: spelled_hits (letters w/ separators), join_split_sentences (blank-line split), tripled-letter fuzzy_target, hyphenated idioms in tags, OUT over answer G2 rule, _answer_object exclusion in meaning X3, lexicon: kosher, above/beyond reproach, intachable, slip-up(s), top markband, recount. NEXT: full validation rerun
- (6) more: anchor idioms (what you just read...), dry-run participle; tests section 6 added; test_c3c_holds passes. NEXT: re-run genuine/attack8 comparisons; check val1/val2 logs
- pieces.report_texts reads source_refs locators (+test). Waiting val1/val2 (started before _answer_object/anchor/dry-run/locator edits; need final rerun)
- frames (7) generic assessor, (8) scope statement added + tests; memo for decoding reads
- FINAL validation started (finA selfcert, finB adapters+branches+contract, finC overseer) logs in wf/phase2/c3c/fin*.log
- STATE: all code done. Measures: genuine c1-c3 669 paras 0 differ vs HEAD; attack-8 own sets HEAD miss18/fp25 -> NEW miss7/fp4 (fp4 = word count D7), 0 regressions; lens miss list 49/86 gated (36 real remain: idioms + Spanish + BBC).
- Waiting final runs finA/finB/finC; then StructuredOutput.
- fixed spelled_hits chunking FP (1920s + It -> 'sit'); finA 1 timing fail under load (passes alone); finB 1 fail fixed
- DONE. Final: tests/selfcert + gate2 all pass; finB 5703 passed + 1 fixed; finC 10411 passed, 3 fixed, ge-t14 CORE-QNT-001 (geography, not selfcert). StructuredOutput next.
