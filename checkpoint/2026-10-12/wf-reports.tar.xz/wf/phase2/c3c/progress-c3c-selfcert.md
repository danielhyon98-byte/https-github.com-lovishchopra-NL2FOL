# progress c3c selfcert
- (4) DONE code: removed EPINOIC_SELFCERT_MEANING_DEBUG path from meaning.py (test to add in tests/selfcert/test_c3c_fuzzy_and_labels.py)
- (1) DONE code: lexicon.py fuzzy_targets/fuzzy_candidates/build(raw); light-verb family words now targets; scripts/selfcert/real_words.txt word source;
  builder rewritten (--check, --vet); lexicon.json fuzzy_excluded rebuilt (69). Tests TODO.
- (2) DONE code: new src/epinoic_logic/selfcert/encoded.py (rule N10 decoders), wired in reader.read_text (_IN_ENCODED guard) and
  __init__._read_plain (morse_text). Tests + tests/README 'Not done in this round' paragraph TODO.
- next: (3) (sat)/fully reliable + rewrite pins in tests/adapters/test_integration_gate2_parsers.py, (5) FPs, (6) misses
- (3) DONE: _bracket_status solver results + _logic_host; SRCEVAL own-claim (_own_claim_before) in reader; tests/adapters pins rewritten (NAMED_ON_EVERY_BRANCH + SOLVER tests) - passes
- (5) IN PROGRESS: production note widened in meaning._production_note (calculated/derived FPs fixed). Next frames: checks&balances, correct to 2 s.f., ONS match, court/defendant, pronoun outcome, cuentas cuadran, grammar sample quote, word count
- (5) frames added: meaning._c3c_frames (compound check noun, precision, ONS agreement, third-party defect, pronoun outcome, cuentas label), _mention_quote widened; word count FP left (decision D7 pinned by tests not mine)
- selfcert tests pass after frames (production stems restricted, named reference = capitalised/acronym)
- tests/selfcert/test_c3c_holds.py written (items 1-5); running
- test_c3c_holds.py passes (260 tests); next: README paragraph, dev sets, clearance records, overseer tests, phrasings misses (6)
- README paragraph rewritten; genuine c1-c3 paragraphs: 0 of 1090 differ vs HEAD; dev sets pass. Next: run adapters + overseer selfreport/delivery tests
