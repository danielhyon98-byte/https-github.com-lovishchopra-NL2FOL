# repair-clearance-c3c-1 progress
- Started. Hygiene: tmp* dirs are staged deletions + .gitignore /tmp*/ already in tree (commit at end removes them). Nothing more needed unless found.
- Next: the two wall-clock timing failures (quotations note reader; fidelity list markers). Profiling.
- DONE: selfcert/reader.py _runon_breaks: per-line dash count hoisted out of token loop (was quadratic; list markers fidelity case ~4.8 s CPU).
- Next: quotations note-reader case (~0.85 s CPU vs 1 s bound): own_text_kinds per-span regexes + reader.
