# repair-clearance-c3c-1 progress
- Started. Hygiene: tmp* dirs are staged deletions + .gitignore /tmp*/ already in tree (commit at end removes them). Nothing more needed unless found.
- Next: the two wall-clock timing failures (quotations note reader; fidelity list markers). Profiling.
- DONE: selfcert/reader.py _runon_breaks: per-line dash count hoisted out of token loop (was quadratic; list markers fidelity case ~4.8 s CPU).
- Next: quotations note-reader case (~0.85 s CPU vs 1 s bound): own_text_kinds per-span regexes + reader.
- (run 2) Verified: fidelity list markers HEAD 0.55/1.83/4.98 s at x0.25/0.5/1 (superlinear) -> tree 0.34/0.38/0.51 (linear). Done.
- (run 2) Quotations note case: tree 0.72-0.78 vs HEAD 0.68-0.71 CPU, linear. Cause of the tree's extra: own_text._CORRECTION_BEFORE_RE
  (new marks) 2x cost. DONE: search only the last _CORRECTION_TAIL=48 chars (max match 44, via sre getwidth); test added in
  tests/channel/test_c3c_own_correction.py (tail == whole). Next: re-measure, run failing tests alone + files + touched modules + selfcert tests.
- (run 2) Re-measured: tree quotations note case now on par with HEAD (min 0.67-0.70 vs 0.68-0.69). Two failing tests alone: 2 passed (4.2 s);
  their files 162 passed; own-text tests 571 passed; tests/selfcert 2099 passed. Next: tests/adapters, tests/channel, tests/branches, overseer/tests (logs in r1/).
- (run 2) Hygiene of my edits clean; no tmp* dirs at root. Waiting on r1/ dir runs (adapters, channel, branches, overseer).
- (run 2) tests/channel 2295 passed 1 skipped. adapters/branches/overseer runs were killed by a 10-min limit; rerunning (r1/).
- (run 2) tests/adapters 1235 passed.
- (run 2) tests/branches: 1 failed test_d9d10_linear[inline list markers] Geography 3.42 s wall vs 3.0 bound (under load of 3 parallel pytest runs). Profiling: call counts identical HEAD vs tree (400k _number, 4000 _table_aggregates, at HEAD too); tree +16k _guarded calls cheap. Re-measuring when idle.
