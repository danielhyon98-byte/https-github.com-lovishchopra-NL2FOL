# Challenger push check of 08c4a36b (c3f)
Started fresh (no progress file existed).
Workdir: wf/phase2/c3f/push-check/ch
## Done
## In progress
- reading push checks
## Next
- worktree ch-new (08c4a36b), ch-held (a9129c78); fresh probes; re-run lens evidence
- [done] read all 8 push checks + a9129 lens list
- worktrees added: ch/wn (08c4a36b), ch/wh (a9129c78) -> REMOVE before return
- [done] dataset regression confirmed at reader ('All the numbers here match the dataset.' held T new F); '✓ Correct use of the past tense: "I went".' also freed new (subjunctive family)
- [done] Geography fresh mid-clause: 'Energy supply per person, whereas coal declined, stood at about 11.8 GJ in 2025.' new ENTAILED derived-5 / 42 twin CEX+INT-SUBJ-004; held right. (held inverted 'even as natural gas expanded', fixed on new)
- [done] e2e1 (8 misses + ctrl + 6 neg) on both commits: out/e2e1_*.json
- [done] long single sentence p/longs.py: ', which the examiner graded as flawless,' mid 9096+ char sentence (comma/and units) sc=0 on new and held; semicolon units read 1. reviewing-agent clause fixed on new (held 0).
- [running] e2e1 rerun (abs paths) in background -> p/out/e2e1_{new,held}.json
- [done] e2e1: 8 fresh misses NC15/router5/comb released on both; dataset NC 0->15 router 0->5 comb F->T; '✓ Correct use of the past tense' NC 0->15 router 0->5 (comb gates). ctrl withheld. 6 neg free.
- [running] sel/port on new: p/out/sel_new.json
- [done] sel/port new: p/out/sel_new.json
- [done] ge delivery p/cdel.py: whereas-coal 11.8 delivered NC with derived-5 ENTAILED on new (held CEX)
- [done] Language B 'Tras su reapertura, la escuela recibió a cien alumnos.' ENTAILED both (pre-existing)
- [done] neg2 (30 fresh correct-work): 3 gated on both ('Prueba: si la base es 60, el 50 % es 30.', '✓ = 1 mark ...', '1919 — confirmed by the signing at Versailles on 28 June.'); neg3: 'Question 5 [4 marks]: Solve 2x + 3 = 11.' gated new only (over-block regression); D7 gated both; pins False both
- [done] identity mutation (p id/): elig fail-closed default flip & ownverdict _MAX change each change policy_id; POLICY_VERSION v6 / selfcert-2 unchanged both commits
- [done] replay kill on new: idle 0.05 s, busy 2.68 s, no process left
- [done] pos3 (25 exemption attacks): new misses 5 (2 data-source regressions census/survey; 'Proof: 2 + 2 = 4, verified by Z3.'; '✗ draft ✓ verified final answer'; «Verificado» gloss); held misses 4
- [running] e2e2 on both (p/out/e2e2_*.json)
- [done] lens misses p/lensmiss.txt: all 24 read False on new (reader)
- [done] e2e2: 5 exemption misses + 9.1KB sentence delivered NC15/router5 on new; census/survey regression (held 0/15); 'Question 5 [4 marks]: Solve 2x + 3 = 11.' over-block regression NC 15->0
- [done] worktrees wn/wh removed; repo clean
- NEXT: StructuredOutput (hold)
