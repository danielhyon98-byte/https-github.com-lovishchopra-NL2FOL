# c3c hygiene progress

- started; nothing done yet
- DONE step 1: git rm -r of the five tmp* dirs (75 files); git ls-files shows nothing left under tmp*.
- DONE step 2 (finding): writer = untracked scratch path probes (c3b attack rounds, e.g. attack-*/paths/p14_two.py,
  p4_selected.py ...) calling tempfile.mkdtemp(dir=".") then export_pack(..., zip_archive=True) with cwd = repository.
  No tracked file writes temp dirs into the repo/cwd (tracked uses: TemporaryDirectory() default, combinator atomic mkstemp
  in destination, router test dir="/tmp" with rmtree).
- NEXT: .gitignore '/tmp*/' (checked: ignores no tracked path), tests/test_repository_hygiene.py, run it + test_no_raw_bidi_controls.py
- DONE step 3: .gitignore '/tmp*/' appended (git ls-files -ci showed 0 tracked matches); tests/test_repository_hygiene.py written;
  it + tests/test_no_raw_bidi_controls.py: 10 passed. Guards confirmed to fail against HEAD's tree (2ff70224 tmp dirs).
- ALL DONE; only the final StructuredOutput remains.
