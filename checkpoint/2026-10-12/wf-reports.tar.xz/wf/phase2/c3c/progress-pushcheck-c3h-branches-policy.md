# progress: push-check c3h branches-policy (84aff95c)
own worktrees: push-check/bp-new (84aff95c), bp-held (67bc64ec), bp-w08 (08c4a36b) [others' held/new/w08/cf/wkhprobe are NOT mine]
done: (none)
in progress: reading push checks
done: read all 10 push checks + 67bc64e lenses; worktrees bp-new/bp-held/bp-w08 added; probes copied to push-check/bp/probe
in progress: harness runs (push-check/bp/runall.sh -> bp/runs/*.out, ALLDONE marker)
next: Geography insertion grid, sp-t14 label pair, linear timing, version/policy identity, kit
done: named cases (bp/named-*.json) all fixed as required; sp14 label grid (bp/sp14label-*.json): new names wrong corrected half, correct twins clean; two-line/Forma-incorrecta pairs charge correct twin on all 3 commits (pre-existing)
in progress: ge15/ge14 grids background (bp/ge15-*.json, ge14-*.json, grids.done marker)
done: identity copies bp/id/{pristine,sc,elig,adapt}: policy_id a9cffbe5d74b06e5 -> 0ce42b23f3df438a / a91d925a0e95981a / 574c4748d36bae69 (build eda032b2 unchanged); versions v8/selfcert-4/0.9 checked in docs/COMPAT/compat.py/readiness; xsign: 67bc-signed (v7) refused stale at new, INTERNAL_ERROR; kit manifest/generate/vectors --check rc0, sha256sum 359 rc0
done: ge15 grid new (735 cells): 0 genuine wrong ENTAILED (21 'about 11.4' coal cells are the general ~5% about-tolerance, same on plain sentences and w08), 0 false flags, F24 '(in 2025, about X)' no check
done: targeted tests on bp-new 1079 passed
next: ge14 grid, ge15b nested grid, held comparisons, harness compare, timing (probe/tlin.py), bp_sc.py + bp_lang.py delivery probes
done: c1 harness new 203/203, 155/155 faults named, 0 records changed vs held and vs clearance/c1
done: sp14 fresh sweep (bp/sp14fresh-*.json, 35): all wrong named, correct clean on new & held; arrow line and English line no check (pre-existing, both)
done: ge14 grid new 360: 240/240 wrong CEX, 120/120 correct clean
FOUND (critical): bp/n2-*.json: ge-t15 bracket/dash modifier holding a nested comma insertion naming another row: 'Coal (which, unlike natural gas, supplied about 9.3 GJ per person in 2025) declined.' ENTAILED on new (CEX on held and w08); correct 11.8 twin charged on new and held, clean on w08. Comma form fine. Pre-existing on all three: no-comma 'which like natural gas supplied' and ge-t14 'Site 2, which, like site 4, had a pedestrian count of 97' wrong ENTAILED.
in progress: n3 grid (unlike/whereas, 130 cells) background bwkr2x1ys -> bp/n3-*.json
done: n3 grid (bp/n3-*.json): U-br/U-dash/U-br-ing (bracket or dash modifier with nested ', unlike <row>,'): w08 correct; held total-row wrong ENTAILED 18/18 + correct charged 18/18; new partner-row wrong ENTAILED 18/18 + correct charged 18/18. W-br-whereas new 6/6 wrong ENTAILED (w08 same). U-nocomma 6/6 and ge-t14 'Site n, which, unlike site m, had a pedestrian count of X' 20/20 wrong ENTAILED + correct charged on all three (pre-existing).
done: ge15 held vs new: held 173 wrong ENTAILED / 159 false flags -> new 0 genuine (19 tolerance cells)
done: bp_sc new (bp/sc-new.json): fresh pos delivered GE 1/40, SP 1/40 ('Un evaluador externo comprobó cada dato de este texto.'); neg withheld 0/20 both
done: bp_lang: unquoted Spanish prose correction pair withheld on new and w08 (7/8 delivered, all 3 task types), held 8/8 (accepted over-block of the revert)
done: recorded 8 ge/sp answers identical held vs new (bp/rec8-*.json); twins 23/24 both (sp-p10d quote-speaker miss pre-existing); variants 27/27 both; wrongpass all named both
done: c2 harness new 188/188, 144/144 faults named, 0 records changed vs held and clearance/c2
done: insertion_spans timing (cache cleared, best of 3): bracket/dash dense sentences super-linear (200k: 1.43-1.73 s, ratios 2.6-3.5), cause _referent_apposition rfind back over the prefix per bracket/dash; insertions.py unchanged since 67bc64ec (pre-existing); 50k 0.15-0.22 s. which/whose/nested ~linear.
done: c3 harness new 164/176, 128/128 faults named, 0 changed vs held and clearance/c3. Language B _build timing linear (ratios <=2.1 to 200k; 200k 0.76-3.4 s)
done: geo._build timing linear new & held (5k..80k); n2_deliver: 'Coal (which, unlike natural gas, supplied about 9.3 GJ ...) declined.' delivered NOT CHECKED with geography-table-derived-1 ENTAILED (NC config); default withheld; correct twin INT-SUBJ-004
done: reader named items new 1x12 gated, held 0; boundary controls free
next: remove worktrees bp-new/bp-held/bp-w08, return StructuredOutput
worktrees removed
