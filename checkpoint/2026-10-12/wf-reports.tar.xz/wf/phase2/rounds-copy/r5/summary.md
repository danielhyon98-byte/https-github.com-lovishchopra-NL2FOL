# Arena r5 (QUALIFIED: 3 of 20 recorded translations not served; 17 served by claim id only)

Transmissions: 46; functional: 46 (100.0%). This is the transport measure only: fixture coverage, translation fidelity and the claim counts are separate measures (below), never combined with it into one rate.

Genuine transmissions, peer relays and combinator syntheses: 12. With an error-level finding: 1 (hi-p4.json [synthesis syn-p4]: INT-LEDGER-002 ['p1-s08']), of which 1 counted functional. With warning-level findings only: 8, of which 8 counted functional. The rate does not judge whether a finding is true: a false error on a correct statement is counted functional like a true one, so read every finding in the genuine section below.

## Measures (each on its own denominator; none is combined with another into one rate)

- Transport (functional transmissions): 46 of 46 (100.0%). Genuine traffic delivered and decided: 12 of 12 (genuine replies 6, peer relays 1, syntheses 5); injected faults named: 34 of 34 mutation records. Transport says the hub delivered and decided every transmission; it does not judge whether a finding is true, whether a translation is faithful or whether an answer is better.
- Fixture coverage (recorded translations served in this run): 17 of 20 served; NOT SERVED: 3 (3 claim not eligible under the current policy). Of the 17 served, 0 were bound to a recorded claim-text digest and 17 by claim id only.
- Translation fidelity (faithful translations where adjudicated): not adjudicated; the round has no adjudications/translation_fidelity.json, so no fidelity figure applies to this run.
- Claims (genuine pass, each delivered claim once): extracted 90; eligible for translation 30; attempted 17; completed (a definitive verdict displayed) 6; faithful: not adjudicated; approved (displayed ENTAILED with no error-level finding on the claim; not a release decision) 6, of which 6 rest on at least one ungrounded premise and 6 on at least one unresolved dependency (ungrounded, or authority no check validated); release permitted by the release assessment (the application's rule, apart from the formal status) 0. Eligible claims with no translation attempted: 13.
- Latency (hub processing per transmission in this run, on this machine; not a stress measurement): genuine traffic median 115 ms, 95th percentile 337 ms, max 337 ms over 11; injected faults median 116 ms, 95th percentile 327 ms, max 327 ms over 34.
- Cost: no translation provider was called (recorded fixtures only).
- Replay configuration (what a recording cannot run as production does is named, never counted as run): the task record of each request is passed to the translator, as production passes it (17 of 17 genuine translations validated against it); 0 served translations bound to a recorded claim-text digest, 17 by claim id only; retries NOT exercised (a recorded translation is one output, so a retry is served the same output and the outcome is the first attempt's) on 3 genuine claim(s): hi-t10.json h1.2, hi-t10.json h1.4, hi-t9.json h1.2 (18 over every variant); syntheses stamped at relay time.
- QUALIFIED (TRANSLATIONS_LOST): 3 of 20 recorded translations were not served in this run (3 claim not eligible under the current policy); translation outcomes cover the 17 served, so this run is not a translation regression over the recorded round.
- QUALIFIED (FIXTURES_UNBOUND): 17 of the 17 served translations carry no recorded claim-text digest: each is bound to the text its claim id carries in this run, which may not be the sentence it was produced for (record the digests with the translations when they are recorded: scripts/arena/bind_translations.py).

| variant | functional | total |
| --- | --- | --- |
| genuine | 6 | 6 |
| synthesis | 5 | 5 |
| peer_relay | 1 | 1 |
| invented_quotation | 6 | 6 |
| invented_quotation_single | 6 | 6 |
| altered_quotation | 4 | 4 |
| self_certification | 6 | 6 |
| wrong_arithmetic | 6 | 6 |
| chronology_error | 6 | 6 |

## Translation outcomes (provider-dependent; genuine pass, one outcome per eligible claim with a fixture)

- AMBIGUOUS_TRANSLATION: 8 (8 distinct claims)
- ENTAILED: 6 (6 distinct claims)
- INVALID_FORMALIZATION: 3 (3 distinct claims)
- NOT_ELIGIBLE: 3 (3 distinct claims)
- ENTAILED verdicts resting only on ungrounded premises: 3 of 6: hi-t10.json h1.3, hi-t9.json h1.6, hi-t9.json h1.9
- encodings given no verdict on genuine claims (displayed INVALID_FORMALIZATION: a definitive engine status withheld, or the encoding rejected at translation): 3; E108 vacuous result: 0; E110 unasserted figure: 0; E111 unencoded reason: 0; E112 circular encoding: 3 (hi-t10.json h1.2 (rejected at translation), hi-t10.json h1.4 (rejected at translation), hi-t9.json h1.2 (rejected at translation)); stated precision: 0; exactness: 0
- advisory coverage warnings on genuine claims (the verdict on the encoding stands; the encoding leaves a figure or symbol open that no source asserts; a coverage measure, not a verdict): 5; W110 unasserted figure, advisory: 0; W111 unconstrained symbol, advisory: 5 (en-p4.json p1-point (AMBIGUOUS_TRANSLATION), hi-t10.json h1.1 (AMBIGUOUS_TRANSLATION), hi-t10.json h1.5 (AMBIGUOUS_TRANSLATION), hi-t10.json h1.6 (AMBIGUOUS_TRANSLATION), hi-t9.json h1.5 (AMBIGUOUS_TRANSLATION))
- definitive verdicts other than ENTAILED displayed on genuine claims (each is shown to the router as the engine's verdict on the claim's encoding: COUNTEREXAMPLE, the claim does not follow from its premises; INCONSISTENT_PREMISES, its premises conflict): 0
- all variants together (the same claims repeated): {'AMBIGUOUS_TRANSLATION': 50, 'ENTAILED': 39, 'INVALID_FORMALIZATION': 18, 'NOT_ELIGIBLE': 20}

## Genuine transmissions, peer relays and combinator syntheses carrying error- or warning-level findings (correct against a specialist's or the combinator's fault, or a false finding: read the message)

- en-p4.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-REQ-006']
  - warning INT-REQ-006 ['p1-point']: claim p1-point's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned COUNTEREXAMPLE, which the outcome does not show), so the router must not read the claim as checked
- en-t10.json [synthesis syn-en-t10] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-SYNTH-012']
  - warning INT-SYNTH-012 ['s1', 'p1-s02', 'p1-q01', 'p1-q02', 'p1-s03', 'p1-q03', 'p1-q04', 'p1-s04', 'p1-q05']: material claim produced by 'merged' from ['p1-s02', 'p1-q01', 'p1-q02', 'p1-s03', 'p1-q03', 'p1-q04', 'p1-s04', 'p1-q05']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'p1-s05', 'p1-q06', 'p1-s06', 'p1-q07', 'p1-s07', 'p1-q08', 'p1-q09', 'p1-q10']: material claim produced by 'merged' from ['p1-s05', 'p1-q06', 'p1-s06', 'p1-q07', 'p1-s07', 'p1-q08', 'p1-q09', 'p1-q10']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s3', 'p1-s08', 'p1-q11', 'p1-s09', 'p1-q12', 'p1-s10']: material claim produced by 'merged' from ['p1-s08', 'p1-q11', 'p1-s09', 'p1-q12', 'p1-s10']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- en-t9.json [synthesis syn-en-t9] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-SYNTH-012']
  - warning INT-SYNTH-012 ['s1', 'p1-q01', 'p1-s02', 'p1-s03', 'p1-q02', 'p1-s04']: material claim produced by 'paraphrased' from ['p1-q01', 'p1-s02', 'p1-s03', 'p1-q02', 'p1-s04']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'p1-q03', 'p1-q04', 'p1-s05', 'p1-q05', 'p1-s06']: material claim produced by 'merged' from ['p1-q03', 'p1-q04', 'p1-s05', 'p1-q05', 'p1-s06']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s3', 'p1-q06', 'p1-q07', 'p1-q08', 'p1-q09', 'p1-s09', 'p1-q10', 'p1-q11', 'p1-q12', 'p1-s10', 'p1-q13', 'p1-s11', 'p1-s12']: material claim produced by 'merged' from ['p1-q06', 'p1-q07', 'p1-q08', 'p1-q09', 'p1-s09', 'p1-q10', 'p1-q11', 'p1-q12', 'p1-s10', 'p1-q13', 'p1-s11', 'p1-s12']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- hi-t10.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['CORE-QNT-001', 'INT-REQ-006']
  - warning INT-REQ-006 ['h1.1']: claim h1.1's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned COUNTEREXAMPLE, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.2']: claim h1.2's verification gave no verdict: its outcome is displayed INVALID_FORMALIZATION (translation INVALID_FORMALIZATION; no engine result was produced), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.4']: claim h1.4's verification gave no verdict: its outcome is displayed INVALID_FORMALIZATION (translation INVALID_FORMALIZATION; no engine result was produced), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.5']: claim h1.5's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned COUNTEREXAMPLE, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.6']: claim h1.6's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned COUNTEREXAMPLE, which the outcome does not show), so the router must not read the claim as checked
  - warning CORE-QNT-001 ['h1.5']: paragraph 1, sentence 5 states a derived figure or a relation over dated figures ('more than any other decade') that could not be checked: no other decade of the period has figures at both its ends in the paragraph's dated series (the 1830s, the 1850s, the 1860s are not stated decade by decade); the stated arithmetic was not checked
- hi-t10.json [synthesis syn-hi-t10] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-LEDGER-024', 'INT-LEDGER-027', 'INT-SYNTH-012']
  - warning INT-LEDGER-024 ['s1', 'h1.4', 'h1.5']: figures or dates ['1848'] of the cited sources ['h1.4', 'h1.5'] do not appear in the 'merged' synthesized claim or in any other synthesized claim citing those sources; the dated or quantified content of those sources was left out of the combined claim
  - warning INT-LEDGER-027 ['s1', 'h1.4']: synthesized claim ('merged') states dated or quantified items ['1500', '1840', '1850', '6000'] of source claims ['h1.4'] that the specialist labelled from memory (["'from memory; check your notes'"]), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-SYNTH-012 ['s0', 'h1.1', 'h1.2', 'h1.3']: material claim produced by 'merged' from ['h1.1', 'h1.2', 'h1.3']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s1', 'h1.4', 'h1.5']: material claim produced by 'merged' from ['h1.4', 'h1.5']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s3', 'h1.1', 'h1.7', 'h1.8']: material claim produced by 'merged' from ['h1.1', 'h1.7', 'h1.8']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- hi-t9.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-REQ-006']
  - warning INT-REQ-006 ['h1.1']: claim h1.1's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.2']: claim h1.2's verification gave no verdict: its outcome is displayed INVALID_FORMALIZATION (translation INVALID_FORMALIZATION; no engine result was produced), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.5']: claim h1.5's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned COUNTEREXAMPLE, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.8']: claim h1.8's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
- hi-t9.json [synthesis syn-hi-t9] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-LEDGER-010', 'INT-LEDGER-027', 'INT-SYNTH-012']
  - warning INT-LEDGER-027 ['s0', 'h1.8']: synthesized claim ('merged') states dated or quantified items ['1941'] of source claims ['h1.8'] that the specialist labelled from memory (['a note of its report labels its dates and figures from memory']), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-LEDGER-027 ['s1', 'h1.2', 'h1.3']: synthesized claim ('merged') states dated or quantified items ['10', '35', '64', '3.3', '4.3', '5.9', '6.2', '1928', '1932'] of source claims ['h1.2', 'h1.3'] that the specialist labelled from memory (['a note of its report labels its dates and figures from memory']), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-LEDGER-027 ['s2', 'h1.5', 'h1.6']: synthesized claim ('merged') states dated or quantified items ['22', '128', '1932', '1933', '1937', '1941', 'june 1941'] of source claims ['h1.5', 'h1.6'] that the specialist labelled from memory (['a note of its report labels its dates and figures from memory']), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-LEDGER-010 ['s3', 'h1.7']: claim marked 'carried' but its text differs from the source; record it as 'paraphrased' or a new linked claim
  - warning INT-SYNTH-012 ['s0', 'h1.1', 'h1.8', 'h1.9']: material claim produced by 'merged' from ['h1.1', 'h1.8', 'h1.9']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s1', 'h1.2', 'h1.3']: material claim produced by 'merged' from ['h1.2', 'h1.3']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'h1.4', 'h1.5', 'h1.6']: material claim produced by 'merged' from ['h1.4', 'h1.5', 'h1.6']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- hi-p4.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['CORE-SRC-003', 'INT-REQ-006']
  - warning INT-REQ-006 ['h1.4']: claim h1.4's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning CORE-SRC-003 ['h1.7']: 1 quotation(s) cannot be verified: no supplied text holds them and their sentences credit them to none of the supplied texts [peer:en-p4] and the from-memory label concerns dates and figures, not quotations: 'quaint and curious war'
- hi-p4.json [synthesis syn-p4] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-002'], warnings ['INT-LEDGER-010', 'INT-LEDGER-024', 'INT-LEDGER-027', 'INT-SYNTH-012'] (cites a report whose recorded relay ['relayed/hi-p4.json'] differs from the current parse: see the recorded peer relays below)
  - warning INT-LEDGER-027 ['hi-p4-s0', 'h1.3']: synthesized claim ('carried') states dated or quantified items ['11', '31', '1899', '1902', 'may 1902', 'october 1899'] of source claims ['h1.3'] that the specialist labelled from memory (["'from memory; check your notes'"]), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-LEDGER-010 ['hi-p4-s0', 'h1.3']: claim marked 'carried' but its text differs from the source; record it as 'paraphrased' or a new linked claim
  - warning INT-LEDGER-024 ['hi-p4-s1', 'h1.4', 'h1.5']: figures or dates ['1900'] of the cited sources ['h1.4', 'h1.5'] do not appear in the 'merged' synthesized claim or in any other synthesized claim citing those sources; the dated or quantified content of those sources was left out of the combined claim
  - warning INT-LEDGER-027 ['hi-p4-s1', 'h1.4']: synthesized claim ('merged') states dated or quantified items ['11', '1899', 'december 1899'] of source claims ['h1.4'] that the specialist labelled from memory (["'from memory'"]), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-LEDGER-027 ['hi-p4-s3', 'h1.6']: synthesized claim ('merged') states dated or quantified items ['22000'] of source claims ['h1.6'] that the specialist labelled from memory (["'from memory; approximate, and sources differ'"]), without the label: the qualification was dropped, so the router reads those items as unqualified
  - error INT-LEDGER-002 ['p1-s08']: material source claim is neither carried, transformed nor recorded as dropped
  - warning INT-SYNTH-012 ['en-p4-s1', 'p1-s03', 'p1-q02', 'p1-q03', 'p1-q04', 'p1-q05']: material claim produced by 'paraphrased' from ['p1-s03', 'p1-q02', 'p1-q03', 'p1-q04', 'p1-q05']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['en-p4-s2', 'p1-s04', 'p1-q06', 'p1-q07', 'p1-s05', 'p1-q08']: material claim produced by 'merged' from ['p1-s04', 'p1-q06', 'p1-q07', 'p1-s05', 'p1-q08']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['en-p4-s3', 'p1-s06', 'p1-q09', 'p1-s07', 'p1-q10']: material claim produced by 'merged' from ['p1-s06', 'p1-q09', 'p1-s07', 'p1-q10']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['hi-p4-s1', 'h1.4', 'h1.5']: material claim produced by 'merged' from ['h1.4', 'h1.5']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['hi-p4-s2', 'h1.1']: material claim produced by 'paraphrased' from ['h1.1']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['hi-p4-s3', 'h1.6', 'h1.7']: material claim produced by 'merged' from ['h1.6', 'h1.7']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked

## Recorded peer relays (relayed/<task>.json) compared with the current parse of the peer's raw text (the genuine pass delivers the current parse; the recording is the dependent agent's document only)

- relayed/hi-p4.json (en-p4 relayed to hi-p4): DIFFERS from the current parse; the genuine pass delivered the current parse and used the recording only for the document the agent read
  - the recorded file also carries router-only fields the dependent agent could read beyond its peer's report: ['peer_receipt', 'plan', 'relay', 'request'] (relay_peer.py now writes them to router/<task>.json)
  - claims only in the current parse: ['p1-s08']
  - the shared claims come in another order
  - p1-point supporting_claim_ids: recorded ["p1-q01", "p1-s02", "p1-q02", "p1-q03", "p1-q04", "p1-q05", "p1-s03", "p1-q06", "p1-q07", "p1-s04", "p1-q08", "p1-s05", "p1-q09", "p1-s06", "p1-q10", "p1-s07"] -> current ["p1-q01", "p1-s02", "p1-q02", "p1-q03", "p1-s03", "p1-q04", "p1-q05", "p1-s04", "p1-q06", "p1-q07", "p1-s05", "p1-q08", "p1-s06", "p1-q09", "p1-s07", "p1-q10"]
  - p1-s03 claim_text: recorded "The clipped \"'list\" makes enlisting sound impulsive, while \"just as I\" implies that the speaker's own reason matches the enemy's. The key word \"traps\", which conventionally denotes snares but in colloquial use means a man's gear and belongings, suggests a man who has sold his belongings for want of work, so poverty becomes the motive, as the closing \"No other reason why\" confirms." -> current "The clipped \"'list\" makes enlisting sound impulsive, while \"just as I\" implies that the speaker's own reason matches the enemy's."
  - p1-s03 supporting_claim_ids: recorded ["p1-q02", "p1-q03", "p1-q04", "p1-q05"] -> current ["p1-q02", "p1-q03"]
  - p1-s04 claim_text: recorded "The view of the enemy is built through the repetition of \"foe\": \"I shot him dead because— / Because he was my foe, / Just so: my foe of course he was\"." -> current "The key word \"traps\", which conventionally denotes snares but in colloquial use means a man's gear and belongings, suggests a man who has sold his belongings for want of work, so poverty becomes the motive, as the closing \"No other reason why\" confirms."
  - p1-s04 supporting_claim_ids: recorded ["p1-q06", "p1-q07"] -> current ["p1-q04", "p1-q05"]
  - p1-s05 claim_text: recorded "Foe should supply a reason for killing, but it only restates the killing, so the justification becomes circular, and the unfinished \"although\" that ends the stanza shows a speaker who does not complete his argument." -> current "The view of the enemy is built through the repetition of \"foe\": \"I shot him dead because— / Because he was my foe, / Just so: my foe of course he was\"."
  - p1-s05 supporting_claim_ids: recorded ["p1-q08"] -> current ["p1-q06", "p1-q07"]
  - p1-s06 claim_text: recorded "The opening conditional, \"Had he and I but met\", imagines the man as a drinking companion, which suggests the speaker sees the enemy as a man like himself." -> current "Foe should supply a reason for killing, but it only restates the killing, so the justification becomes circular, and the unfinished \"although\" that ends the stanza shows a speaker who does not complete his argument."
  - p1-s06 supporting_claim_ids: recorded ["p1-q09"] -> current ["p1-q08"]
  - p1-s07 claim_text: recorded "The final stanza sets the killing beside a social courtesy, \"You shoot a fellow down / You'd treat if met where any bar is\", so the colloquial voice comfortably holds a contradiction." -> current "The opening conditional, \"Had he and I but met\", imagines the man as a drinking companion, which suggests the speaker sees the enemy as a man like himself."
  - p1-s07 supporting_claim_ids: recorded ["p1-q10"] -> current ["p1-q09"]

## Mutations: findings beyond the genuine record that do not name the injection (a consequence of the injected words, such as a word bound crossed, or a wrong receipt: read the message)

- en-p4.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['p1-q11', 'p1-s09']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 261 words; bound max_words 250; solver COUNTEREXAMPLE (genuine record: measured 244 words; bound max_words 250; solver ENTAILED; the mutation added 17 words)
- en-p4.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['p1-q11', 'p1-s09']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 261 words; bound max_words 250; solver COUNTEREXAMPLE (genuine record: measured 244 words; bound max_words 250; solver ENTAILED; the mutation added 17 words)
- en-p4.json [wrong_arithmetic] ACCEPTED_WITH_FINDINGS: injected claims ['p1-s09']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 257 words; bound max_words 250; solver COUNTEREXAMPLE (genuine record: measured 244 words; bound max_words 250; solver ENTAILED; the mutation added 13 words)
- en-p4.json [chronology_error] ACCEPTED_WITH_FINDINGS: injected claims ['p1-s09']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 260 words; bound max_words 250; solver COUNTEREXAMPLE (genuine record: measured 244 words; bound max_words 250; solver ENTAILED; the mutation added 16 words)

## Delivery decisions (delivery policy delivery-v1: 240 s translation budget, overseer-selected fallback above 0.9; docs/DELIVERY.md)

Each genuine answer is replayed on a hub of its own with the transfer auditor attached and decided by the delivery policy. Overseer agents: not configured (the harness calls no model): the fallback establishes no accuracy. A separate measure: it changes no transport count. Modes: formally_checked 0, overseer_selected 0, not_checked 0, withheld 6; receipts identical to the genuine records' (status and codes): 6 of 6; the pass took 6.311 s.

Overseer-selected fallback: NOT exercised in this pass: no overseer agent is configured (the harness calls no model): no accuracy was established, so neither the overseer-selected fallback above the threshold nor the below-threshold rule was exercised. Withheld by cause: no_accuracy 6.

| task | mode | time to decision (s) | translation (s) | overseer (s) | candidates (accuracy) | chosen | why |
| --- | --- | --- | --- | --- | --- | --- | --- |
| en-p4.json | withheld | 0.534 | 0.522 | - | english-specialist 0/2 | - | claim p1-point: unresolved (translation AMBIGUOUS_TRANSLATION; the translation carries ambiguity flags: unstated_link; display status AMBIGUOUS_TRANSLATION: no … |
| en-t10.json | withheld | 0.672 | 0.650 | - | english-specialist 0/2 | - | claim p1-point: unresolved (release rule release-v1: ungrounded dependencies (relied on, not established by the supplied material or the task): lk_hyperbole, lk… |
| en-t9.json | withheld | 0.697 | 0.651 | - | english-specialist 0/2 | - | claim p1-point: unresolved (release rule release-v1: ungrounded dependencies (relied on, not established by the supplied material or the task): lk_warning, lk_i… |
| hi-t10.json | withheld | 1.314 | 1.296 | - | history-specialist 0/4 | - | claim h1.1: unresolved (translation AMBIGUOUS_TRANSLATION; the translation carries ambiguity flags: undefined_phases; display status AMBIGUOUS_TRANSLATION: no d… |
| hi-t9.json | withheld | 1.979 | 1.938 | - | history-specialist 0/3 | - | claim h1.1: unresolved (translation AMBIGUOUS_TRANSLATION; the translation carries ambiguity flags: evaluative_terms; display status AMBIGUOUS_TRANSLATION: no d… |
| hi-p4.json | withheld | 1.081 | 1.063 | - | history-specialist 0/2 | - | claim h1.3: unresolved (release rule release-v1: ungrounded dependencies (relied on, not established by the supplied material or the task): f_war_end; release r… |

## Specialist revisions

(not run: the round has no feedback/ directory (scripts/arena/revision_feedback.py was not run))

## Failures

(none)