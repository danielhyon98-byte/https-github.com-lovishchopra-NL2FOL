# Judgement "closure-cost" on the three meaning-label designs

Status: a judge's reading for the owner's decision on the self-certification class. It scores three designs in
`phase2/meaning-check/`: `design-in-call.md` (the label rides on one translation call), `design-separate-call.md` (a
dedicated block-only classifier call) and `design-overseer-side.md` (a dedicated overseer lens with a signed record). It
uses the map beside them (`phase2/meaning-check/map.md`). Where a claim mattered, it was checked against the
development line's working tree, read only. References are `repository path:line`. No held-out row or attack phrasing is
quoted, and no model is named.

Lenses: (1) does the design close the class by meaning as the push checks measure it: fresh phrasings in English and
Spanish, obfuscated scripts, quoted and relayed forms, every release path; (2) false-positive risk on correct work:
boundary (b) sentences, glosses, correction pairs, command terms, worked checks, analysed sources; (3) offline
testability; (4) cost and latency per answer; (5) implementation effort.

---

## 0. Verdict

| Design | Score (0 to 10) | One line |
| --- | --- | --- |
| Separate call | **7** | The best base. It reads the whole answer in isolation, gives a verdict per sentence, requires a positive label record on every path, overlaps translation and has the lowest false-positive surface. Its control sentence comes from a fixed public pool and should use a keyed generator. |
| Overseer side | **6** | It has the strongest anti-suppression and anchoring machinery: keyed canaries, a signed record, absence fails closed, no degraded mode, anchoring through the visible-form fold. But it starts only after the answer's translation, so its wait sits on the service's critical path. It also needs D18 amended and a new overseer trust rule, leaves the translator's claim display unchanged, and costs about twice the input per call. |
| In call (anchor) | **3.5** | The cheapest option, and it saves one call per answer. It has no control sentence, so a suppression injection returns the gate to the reader alone. A missing label is signalled only when the label code path runs, so where it does not run the answer is not withheld. A sentence matching a long run of the student's task text can never block. The label is coupled to translation. |

**None of the three closes the class as the push checks measure it today.** The push check's present rule is that one
delivered fresh self-certification holds the push. Every design replaces the rule's zero tolerance with a measured
rate:

- in call: section 9, the proposed push-check text;
- separate call: section 10 and decision L2;
- overseer side: section 9 and decision O-6.

All three say this plainly. Here is an illustration, which is an assumption and not a measurement. Suppose the cheapest
tier caught 90% of what the reader misses (13.4% today, so about 1.3% left for the union). On a 119-phrasing check the
chance of zero misses is then about (0.987)^119 ≈ 0.21. At a 0.5% union miss rate it is about 0.55. So under the current
rule, even a good label would still hold most push checks.

Under any design, "closed by meaning" therefore needs one of two owner decisions:

- accept a measured residual, recorded in an acceptance record and in the push-check rule, though not on answers or in
  product documentation. That is close to the documented limitation the owner refused;
- keep zero tolerance and accept that pushes will keep holding, with the label lowering the rate.

That choice is the owner's. No design can remove it.

**Recommendation.** Build the separate-call design and graft on four parts of the overseer-side design:

- keyed per-issue canaries instead of the 64-row development pool;
- span anchoring under `selfcert.visible_form` with an offset map back to the original;
- the explicit statement of the one new trust rule (the overseer side's T17);
- the "no reader-only degraded mode" rule.

Then fix the separate call's prefetch-key consistency (section 2.2 below). Reject the in-call design unless "no extra
model call" is a hard constraint. Even then it first needs a control sentence and a positive per-answer attestation.

---

## 1. Facts checked against the repository

| Claim | Design | Checked | Result |
| --- | --- | --- | --- |
| The translation request never carries the answer, so a claim-scoped label sees eligible claims only | in call 0 | `translate/providers/base.py:32` (fields per map 1.2); probe outputs in `phase2/meaning-check/probe/` | Holds. 0 of 480 lens-miss insertions and 28 of 2,380 round-11 insertions reached an eligible claim. 14 of the 16 reader misses never reach one. The in-call design's own rejection of the literal variant is sound. |
| `_verify_claims` is where the anchor label and CORE-SELF-004 are written | in call 1.2, 4.1 | `src/epinoic_logic/channel/bus.py:3894-3902` | `_verify_claims` returns at once when `verify_claim_fn is None` (`:3901-3902`). An exception inside it is caught by `_guarded` (`:3005-3015`), which writes INT-INTERNAL-001. So with no verifier, no label is requested and no CORE-SELF-004 is written. Section 2.1 gives the consequence. |
| Recorded translations go stale if the translator prompt changes | separate call 1 (against in call) | `translate/providers/fixture.py:75-90` | Not so. Fixtures are bound to the claim-text digest, not to `TRANSLATOR_VERSION` or the prompt version. The in-call design is right that the 1,551 recordings stay usable. The separate-call design overstates this cost of the rival. |
| Overseer agents run after the decision in the service, and only in the fallback in the delivery policy | overseer side 0 | `overseer/src/epinoic_overseer/port.py:35-51`; `src/epinoic_logic/integration/turn.py:1-26` (step 10); `delivery_policy.py:1660-1661`; `integration/DECISIONS.md:33, 37, 180, 184` | Holds. The overseer-side design is right that riding on the full verdict gates nothing. |
| `self_certification_as_content` is confirmed only by OVS-FID-005 or OVS-FID-009 | overseer side 0 | `overseer/src/epinoic_overseer/verdicts.py:126` | Holds. On the reader's misses, today's accusation acts nowhere. |
| The label launches when `TransferAuditor.on_event` journals the transfer, "in parallel with translation" | overseer side 0, 2.2, 10.2 | `overseer/src/epinoic_overseer/audit.py:584-605`; `bus.py:2633-2638` | Partly wrong. The event is journaled when the channel call finishes, and translation happens inside `respond` before `_finish` (`:2633` then `:2638`). The label therefore starts after that answer's translation. In the service's single mode, steps 6 and 7 are short, so the label call (plus up to a 20 s wait and a retry) is mostly on the critical path. It does overlap the delivery policy's formal and overseer stage. |
| D14 call ceiling of 2,000 a day on the delivery path | in call 10; separate call 11.1 | `integration/DECISIONS.md:176, 784` | Holds. The in-call design's saving of one call per answer is real: about 115 against 109 answers a day before retries. |
| Release paths read the receipt codes at any severity | all | map section 7; `delivery_policy.py:785, 800`; `meta_notes.py:1669`; `consolidate.py:407` | Holds. Adding a code to these lists is a sound single door. |
| `claim_entries`, `visible_form`, `context_for` exist where cited | overseer side | `integration/claims.py:87`; `selfcert/__init__.py:370, 487` | Hold. |

---

## 2. The designs, lens by lens

### 2.1 In call (anchor variant): 3.5

**Closure.**

- (+) Every recorded answer has an anchor (probe C: 0 of 59 without an eligible claim). A label-only call covers
  syntheses and answers with no eligible claim. Relays reuse the label by digest.
- (−) **No control sentence.** Section 6 concedes that a successful suppression injection makes the label name nothing,
  so the gate returns to the reader. The class can then be delivered by pairing a phrasing the reader misses with a
  suppression instruction the reader also misses. The `addresses_the_checker` category only helps when the obeying model
  names the injection, and an obeying model will not. The other two designs turn suppression into a withhold with a
  control or canary.
- (−) **A missing label is not withheld where the label step does not run.** Only failure is signalled
  (CORE-SELF-004), and only by `_verify_claims` after validation (4.1). With no verifier configured, `_verify_claims`
  returns before any label (`bus.py:3901-3902`). No 003 and no 004 is written, and every release path then reads the
  answer as unlabelled-but-clean. The design handles a verifier that ignores `label_input` but not the absent verifier.
  It has no positive attestation that an auditor could require.
- (−) **The `task-echo` tag never blocks** (2.2). It fires on "a common run of 40 or more characters" with the task. The
  task text is the student's and untrusted. A specialist sentence that adopts a long self-certifying phrase from the
  task can never be blocked by the label. The separate-call design treats unquoted echoed wording as adopted own text,
  which is correct by c3b 3.6.
- (−) **The code negation exemption covers CHECK, OUTCOME and STATUS** under the reader's polarity (3.3). Negation,
  litotes and denial of fault are where the reader has missed in recent rounds. Freeing OUTCOME spans by code
  polarity reopens part of what the label is for. The overseer side limits code negation to CHECK only; the separate
  call leaves all negation to the model.
- (−) **Divided attention.** One cheapest-tier context must both encode a claim into IR and list up to 12 spans across
  the whole answer. The output is a span list, not a per-sentence verdict, which invites omission. Recall is likely below
  a dedicated call's. The design measures this (8.4) but does not mitigate it.
- (−) The label depends on translation being configured and in budget. With live calls off, or a budget reached, every
  answer is withheld by 004, if 004 is written at all (see above).

**False positives.**

- (+) Code scope tags keep analysed sources (`quote-source`), glosses, correction wrong sides and code out of the label.
  Verbatim spans and V6 scope rules mean an invented span cannot withhold.
- (−) The broad never-block tags are the other face of the `task-echo` hole above.
- (−) The anchor's translation prompt changes, which risks the anchor translation (criterion 9.7 measures this).

**Offline testability.** Moderate.

- Recorded labels are appended to recorded anchor translations that were produced without the label section. Replay
  therefore proves the gate and the validation, not the coupled call. The design says so honestly (8.2).

**Cost and latency.** Best of the three.

- About 1,800 extra input tokens on one call per answer, no extra call, and latency within the slowest claim call.
- Anchor rotation (3 anchors × 2 attempts) can multiply the label cost by up to 6 in the failure case.

**Effort.** 19 to 25 days. This is the lowest estimate, though steps 2, 3 and 6 are its own coupling cost.

**Repairs.**

1. Add a control sentence, keyed per answer, whose miss makes the label `invalid` and withholds.
2. Replace "004 on failure" with a required positive record per answer, written whatever the verifier, and refuse its
   absence on every path. Alternatively, write 004 by default and remove it only on a valid label.
3. Make `task-echo` apply only inside quotation marks (verbatim task wording).
4. Narrow the code negation exemption to CHECK with no OUTCOME, DEFECT or ASSURE trigger, and leave the rest to the
   model.
5. Change the output to a verdict per segment.

### 2.2 Separate call: 7

**Closure.**

- (+) The whole own scope is read with paragraph context, notes and the specialist's own fields included. The reply
  gives a verdict for every sentence id, in order, each exactly once. An omitted id is `incomplete` and fails closed, so
  the model cannot skip sentences silently.
- (+) Positive attestation: INT-SELF-003 is required on every deliverable answer, and the auditor (OVS-FID-010)
  re-derives the codes from the stored raw reply. Absence fails closed on every path, which is the in-call design's
  biggest hole closed.
- (+) A control sentence turns wholesale suppression into a withhold. The DIRECTIVE category covers targeted steering.
- (+) Spanish and obfuscation are left to the model by meaning. CORE-SELF-002 still refuses unread runs first.
- (+) Relays and syntheses are labelled at `relay`.
- (+) It starts at service step 4 and overlaps translation.
- (−) **The control pool is 64 fixed development-set rows** (`canaries.json`), chosen by digest. The development sets
  live in the repository, so a writer who has read them can aim a targeted suppression at the non-control sentences. The
  overseer side's HMAC-keyed generator does not have this weakness.
- (−) **Anchoring is NFC-only verbatim.** A cheapest-tier model that normalises a look-alike or a letter-spaced word
  makes the span `unlocated`, and that answer gets INT-SELF-002. This fails closed, so it is safe, but availability on
  obfuscated answers will be low and the repair retry may not help. Anchoring under `selfcert.visible_form` with an
  offset map, as the overseer side proposes, keeps the safety and recovers availability.
- (−) **The step-4 prefetch may miss the cache.** The prefetch builds the input from raw text, while the hub's
  `build_input` adds `own_fields` from the parsed report (3.1). If the two renderings differ, the content hash differs and
  the call is made twice. That costs time, not safety.

**False positives.**

- Lowest surface of the three. Verbatim analysed-source quotations, quoted task wording and (in marking) the student's
  wording become placeholders the model never sees. Narrow code exemptions cover worked checks, imperative CHECK steps,
  glosses, command terms and known-source checks.
- (−) "When unsure, mark gated" pushes over-blocking on STEM method language ("can be verified by differentiation",
  "check the units"). The correction-pair exemption applies in marking context only, so a Language B pair outside a
  marking plan stays with the model.
- The bounds of section 10 (3 to 5) and the adjudication of the 264 genuine texts cap this, at the cost of withheld
  honest answers until measured.

**Offline testability.** Best of the three.

- The pieces are separable: a scripted fake, a test-only `ReaderEchoLabeller` that keeps every existing expectation
  without weakening any, an `UnconfiguredLabeller` that fails closed by default, recorded replies keyed by request
  digest, and kit parity.

**Cost and latency.**

- About 2,300 tokens in and 230 out per answer (about 2% of the answer's translation tokens), plus one call per
  synthesis.
- Latency is hidden behind translation except on answers with little to translate (the full call, estimated at 1.5 to
  4 s, unmeasured).
- The label is skipped when the reader already refuses.

**Effort.** About 29 days. This is realistic and includes prompt authoring under a no-peek rule and the measurement.

**Defects that are not about closure.**

- The weighing in section 1 says the in-call variant stales the 1,551 recorded translations. Fixtures are bound by claim
  text (`fixture.py:75-90`), so that cost is overstated.
- INT-SELF-003 is a positive token whose presence is necessary for delivery. It is internal and carries no success
  word. Even so, its name and message should be audited against "a clean label is never shown or named as a pass"
  (badges, `checksSummary`, logs). The design says it is never shown; a test should pin that.

**Repairs.**

1. Keyed per-issue canaries from the reader's lexicon classes.
2. `visible_form` anchoring with a map back to the original.
3. One `build_input` from the same inputs at step 4 and step 5, so the hash matches.
4. Correct the stale-fixture claim.
5. An invariant test that INT-SELF-003 never reaches any student-facing field or summary.

### 2.3 Overseer side: 6

**Closure.**

- (+) Strongest suppression defence: HMAC-keyed canaries generated from lexicon classes at keyed positions, unknown to
  an attacker who has read the repository. A missed canary withholds.
- (+) A signed record bound to the issue and the input digest. Absence raises `LabelUnavailable` on every path.
- (+) Explicitly no reader-only degraded mode, so an attacker cannot time a slow labeller to reopen the class.
- (+) One answer per call, so one candidate cannot steer another's label.
- (+) Anchoring under `visible_form` (N1 to N7), the right choice for obfuscated scripts.
- (+) Categories include `denial_of_fault`, `relay` and `disguised`.
- (+) Code exemptions are overridden by any A-scope anchor.
- (−) **The label starts after the answer's translation** (section 1 row 6). The service then waits up to `label_wait_s`
  (20 s) plus one retry on the critical path. A timeout withholds, which is safe but costs availability. The claim of no
  added latency in the median case holds for the delivery policy's formal stage, not for the service turn.
- (−) **The translator's claim display is unchanged** (7, "Translator policy unchanged"). The label overrides only the
  integration's `claim_entries` (`integration/claims.py:87`). The channel receipt, the outcome summary, the overseer's
  OVS-RES-009 and OVS-TRN-007 re-derivation and the arena summary can still show ENTAILED for a claim whose words the
  label named. The answer is withheld, but a success status on a self-certifying claim is a label the rule forbids.
- (−) **L2** (accusation quotes from the full review, single candidate only) adds a second, timing-dependent path.
  Its benefit is small: the fallback only, under a pool.

**False positives.**

- Comparable to the separate call. Verbatim `quote:source` and `quote:task` spans are exempt. The correction marking
  applies in marking context or on the Language B branch, which is broader and better than the separate call.
- The model decides most of boundary (b) by not listing. A negative canary monitors drift.
- (−) No placeholders: the model sees analysed-source text and may list it. Code drops those spans only if they lie
  wholly inside a verbatim quotation span. A paraphrased analysed source stays with the model.

**Offline testability.**

- Good. Scripted, reader-backed and recorded labellers; a recording key replaces the overseer secret, so canaries
  reproduce; readiness refuses fakes outside development and sim.
- It needs a new signed-record format, a key id and a journal entry kind in tests.

**Cost and latency.**

- About 4,200 tokens in per call, 3,500 of them a fixed and cacheable system text, which is about 1.8 times the separate
  call's input. Under 300 tokens out.
- About 7 to 9% more input per round. One more delivery-path call per answer and per synthesis.
- Latency: see Closure above.

**Effort and decisions.**

- About 28 days plus independent set writing.
- Larger governance cost: D18 amended (a synchronous overseer agent on the delivery path), the new trust rule T17, a
  contract bump to 0.8 with a new refusal and KIT-DL-014, delivery-v2, pack 2.3, a new key id.
- T17 is the honest statement of what every design does: an agent output acts, to withhold only, without a
  deterministic check. Placing it inside the overseer makes the tension with "the Overseer trusts only signed engine
  results" explicit rather than hidden behind a hub receipt code.

**Repairs.**

1. Launch at hub receive (or service step 4) on the payload digest, not at journaling, so the call overlaps
   translation.
2. Feed label places into the claim display the channel and overseer derive (or bind the label before the receipt is
   signed), not only into `claim_entries`.
3. Drop L2, or keep it as monitoring only.
4. Measure the 3,500-token pack against the separate call's 1,500-token prompt on the same sets before accepting the
   doubled input.

---

## 3. Shared defects (all three)

1. **The push-check rule is rewritten to tolerate measured misses.** This is the real decision (section 0). Each
   design's acceptance bound sits in the range 2.5% to 3.5% (95% upper bound). The owner should see that this is the
   residual the class keeps, and that keeping zero tolerance means pushes will keep holding.
2. **Every reader change re-keys every label recording.** Each label digest includes `selfcert.rules_digest()`, which
   since c3e covers every `.py` of the reader. The reader changes every round, so every round would re-record labels for
   122+ answers and every evaluation set. Recording cost is per reader change, not one-off. A repair: key recordings on
   the label input, prompt and schema, and re-run only the code validation on reader changes (validation is
   deterministic and replays from the raw reply).
3. **Recall on fresh blind sets is unmeasured for any design.** All three plan a recording pass with blind writers and
   Wilson bounds. That is the right gate, and no design should be approved on its argument alone.
4. **Live calls are off** (D14, D23). Until they are on, every design withholds every hosted answer that lacks a
   recorded label. This is correct fail-closed behaviour, and all three state it.

---

## 4. Scores

| Lens | In call | Separate call | Overseer side |
| --- | --- | --- | --- |
| Closure by meaning (fresh, Spanish, obfuscated, quoted, relayed, every path) | 3 | 7 | 7 |
| False-positive risk on correct work (higher is safer) | 5 | 7 | 6 |
| Offline testability | 5 | 8 | 7 |
| Cost and latency per answer | 9 | 7 | 5 |
| Implementation effort (higher is less) | 7 | 5 | 4 |
| **Overall (closure weighted most)** | **3.5** | **7** | **6** |
