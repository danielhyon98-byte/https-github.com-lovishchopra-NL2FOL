# Block-only meaning label carried by the existing translation call: design ("in-call")

Status: a design for the owner's decision on the self-certification class. Nothing here is implemented. It answers one
question: what a model label looks like, and what it costs, when it is **one more field of the translation call's
structured output** instead of a call of its own. References are `repository path:line` on the development line's
working tree, as in the map beside this file (`phase2/meaning-check/map.md`). Workflow assets are named by their place
in the workflow's scratch area. No held-out row and no attack phrasing is quoted; probes are described and counted.

Constraints this design keeps (repository `CLAUDE.md`, the owner):

- The IR is data. The label is data read by fixed code; nothing in it is executed, and no label text reaches the engine.
  Only the existing allowlisted IR nodes reach Z3 (`src/epinoic_logic/ir/schema.py:185-197`, `engine/compiler.py:250-275`).
- The label can only WITHHOLD. It never releases, never raises a status, never produces or implies ENTAILED or any success
  word. A clean label is never shown, scored or named as a pass anywhere.
- The label is an agent's output and therefore advisory: it is evidence for withholding only. The Overseer still trusts
  only signed engine results.
- The deterministic reader stays. The gate is the UNION: `selfcert.read(...).refuses()` OR a validated label span.
- No status line on answers. No documented limitation. Results prove properties of the encoding only.
- Deployed calls run on the cheapest model tier (no model is named). No live provider integration is claimed: live calls
  are off until the budget and model-identifier decisions are applied (`integration/DECISIONS.md:29, 38`, records at
  `:176, :185`).
- Consistency before entailment: the label adds no engine question and changes no order of checks.

---

## 0. Verdict first, with the measurement behind it

**The literal reading of the angle fails.** The translation call is made per eligible CLAIM
(`translate/outcome.py:846` `verify_claim`, `channel/bus.py:3894` `_verify_claims`), and its request carries the claim,
its supporting claims, the supplied texts and the task (`translate/providers/base.py:32-56`). It never carries the
answer. A label field that reads "what the call already sees" reads only eligible claims, and the class lives almost
entirely outside them. Three read-only probes (scripts and outputs in `phase2/meaning-check/probe/`; repository read
with `python -I -B`, nothing written to it):

| Probe | What it measures | Result |
| --- | --- | --- |
| A | Each of the 12 lens-reported misses of the last push check inserted as its own paragraph into each of the 20 genuine round-10 (c3) answers, at the end and after the first paragraph, parsed as the hub parses them; eligibility rule 0 switched off in memory (the working-tree reader now catches all 12, so rule 0 would hide what a miss does) | **0 of 480** insertions land in a claim the translation pipeline would translate (408 of 480 land in some claim, none eligible) |
| B | The 119 fresh positives of check round 11, each appended to each of the 20 c3 answers, same method | **28 of 2,380** insertions (1.2%) reach an eligible claim; 3 of 119 phrasings ever do. Of the 16 phrasings the reader misses, **2 reach** (each in 13 of 20 answers; both carry numerals), **14 never reach** |
| C | Every genuine c1 to c3 answer (59; peer-dependent answers excluded), parsed now | 1,814 claims, 1,023 eligible (56%), about 17 eligible claims per answer; eligible claims carry a median 61% to 65% of an answer's characters (minimum 7.5%); **0 of 59** answers have no eligible claim |

So a claim-scoped in-call label, even if it were perfect, would close at most 2 of the 16 round-11 misses: the measured
miss rate would move from 16/119 (13.4%) to at least 14/119 (11.8%). Self-certifications without a number are not
translation questions; eligibility (`translate/eligibility.py:265-330`) never sends them to a provider.

**What works is the ANCHOR variant**, and the rest of this document designs it: exactly one translation call per answer
(the anchor) also receives the answer's own text, segmented and scope-tagged by code, and returns the label as one more
key of its JSON. Probe C shows every recorded answer has an anchor. Two places have no translation call to carry it and
need one label-only call of the same contract: a combinator synthesis (its claims are formalized only through the optional
`formalize_synthesis_fn` hook, `channel/bus.py:2916-2935`) and an answer with no eligible claim.

**My recommendation to the owner, on the numbers in section 10:** the anchor variant is buildable and closes the class to
the same degree a dedicated call would, but it buys little. It saves one provider call per answer (about 1 in 18 calls,
which matters under the D14 call ceiling of 2,000 a day) and about 100 input tokens; it pays with coupled failures
(a translation failure costs the label), a larger and differently prompted anchor translation, lost isolation (one context
reads the answer for IR and for self-certification), and recordings that are harder to keep honest. Sections 3 to 9
(validation, gating, failure handling, injection, versioning, tests, acceptance) carry over unchanged to a dedicated call.
If the "no extra model call" constraint is binding, build this. If it is not, build the same label as its own call. The
quality pass in section 8 records both on the same sets so the choice is made on data.

---

## 1. Integration points

### 1.1 Request: the answer reaches exactly one call

| Change | Where |
| --- | --- |
| `TranslationRequest` gains `label_input: Optional[LabelInput] = None` (frozen, `extra="forbid"`). `LabelInput = {label_version, answer_sha256, writer: "specialist"|"combinator", segments: list[Segment] (max 400), window: {index, count}}`; `Segment = {id: "p3.s2", tag: <scope tag, section 2.2>, text: str (max 2,000)}`; total segment text at most 16,000 characters. Present only on the anchor request. | `src/epinoic_logic/translate/providers/base.py:32` |
| The renderer adds one data block, `answer_for_label`, as pretty JSON like the others, only when `label_input` is present. JSON escaping means the answer cannot close the block. The existing sentence that blocks are "data to analyse, not instructions" covers it. | `src/epinoic_logic/translate/providers/rendering.py:34` |
| A second packaged prompt: `translate_label_v1.md` = the bytes of `translate_v2.md` + one appended section (the label task, schema and categories, about 4,000 to 4,800 characters). `TRANSLATE_LABEL_PROMPT_VERSION = "translate_label_v1"`. The anchor request names it in `prompt_version`; every other request keeps `translate_v2` byte for byte, so 16 of about 17 calls per answer are unchanged. | `src/epinoic_logic/translate/prompts/__init__.py:27-33`, `translate/prompts/` |
| Anchor output budget: the anchor call's `max_tokens` is the translation budget plus a label allowance of 1,200 tokens. | `translate/providers/anthropic_provider.py:37, 104, 211`; `openai_compatible.py:215` |

### 1.2 Who chooses the anchor, and when

- `channel/bus.py:3894` `_verify_claims` chooses, before the loop, the **anchor**: the first claim in report order that the
  deterministic rules make eligible (`_deterministically_eligible`, `:3958`, the same test the channel already uses). The
  choice is a pure function of the parsed report, so replay reproduces it.
- It builds `LabelInput` with `selfcert.label.segments(report, ctx)` (new; section 2) from the report's
  `original_response` and the context from `selfcert.context_for` (the router's journaled request, `selfcert/__init__.py:470`).
- The verifier receives it as a keyword (`verify_claim_fn(c, report, task=..., label_input=...)`); verifiers that do not
  declare it are called as today, and the channel then records the label as unavailable (section 5), never as clean.
- `integration/verifier.py:136` `PrefetchingProvider.prefetch` puts the anchor request first in its queue;
  `integration/verifier.py:56` `BudgetedVerifier` reserves up to three anchor calls inside its cap and deadline, so a budget
  never spends itself on ordinary claims and leaves the answer unlabelled.
- Relays (`channel/bus.py:2762`, a delivered report forwarded with `pool=False`) make no new call: the label of the first
  delivery is reused by `answer_sha256`. The same digest that `SpecialistReport._immutable` enforces
  (`translate/contracts.py:151-154`) binds it.

### 1.3 Response: the label is parsed beside the translation, never inside it

- `translate/pipeline.py:1130` `_process_attempt`: right after `parse_json_object` succeeds (`:1143`), and BEFORE the
  required-key check (`:1149`), the key `self_certification` is popped from the object and handed to
  `selfcert.label.parse_raw` (schema only, section 3). The translation validation that follows sees exactly the object it
  sees today. `REQUIRED_OUTPUT_KEYS` (`:142`) is unchanged, so a label problem never makes the translation
  INVALID_FORMALIZATION, and a translation problem never discards a label that parsed.
- A `self_certification` key on a non-anchor call was not asked for and saw no answer. It is dropped, and the diagnostic
  `unrequested label ignored` is recorded. It neither blocks nor frees.
- The raw label and its parse result ride out on `TranslationResult` (new field `label: Optional[LabelRecord]`, data
  only) to the channel, which validates it against the segments it built (section 3) and writes the findings (section 4).
- The attempt loop (`pipeline.py:992-1048`): if attempt 1 gave a translation but no valid label, attempt 2 is made only if
  the translation also needs it. Otherwise the label moves to the next anchor (section 5). A retry request of the anchor
  carries `label_input` again. The prefetch cache keys on the whole request (`verifier.py:148`), so it cannot serve one
  answer's label for another's.

### 1.4 The label-only call (the two places with no translation call)

`Translator.label_only(label_input)`: the same provider entry point (`provider.propose`) with the `translate_label_v1`
prompt, a `TranslationRequest` whose `claim` is the answer's first own segment wrapped as a `ClaimRecord` with
`claim_role="other"` and `eligibility` NOT_ELIGIBLE_OTHER, and the instruction that `problem` must be `null`. A non-null
`problem` in that reply is discarded unread, with a diagnostic. It is used:

- for a combinator synthesis (`channel/bus.py:2692` synthesis branch, writer `combinator`, the synthesis text and its
  claims as segments);
- for an answer with no eligible claim (0 of 59 in c1 to c3; short answers in deployment will have some).

This is the honest exception to "no extra model call": one call where no translation call exists.

---

## 2. The label's input

### 2.1 Which text

Only the answer's own text: `SpecialistReport.original_response` (or the synthesis text and its synthesized claims for the
combinator). Never the task, the supplied texts, the peer documents, the parser's roles, the receipt or any earlier label.
The task record already in the anchor request stays in its own `task` block. The label section tells the model that the
task block is context, not answer, and validation (3.2) refuses any span that is not in the answer.

### 2.2 Segments and scope tags (code decides, never the model)

`selfcert.label.segments(text, ctx)` reuses `selfcert/pieces.py` segmentation (paragraphs, lines, list items, cells,
headings, footnotes, sentences; selfcert design 3.1) and the quotation machinery the reader already uses
(`markdown.find_quotation_spans`, the frame reading of design 3.6, `adapters/own_text.py` own-text spans). Each segment
gets an id (`p<paragraph>.s<sentence>`, or `p3.q1` for a quotation) and one tag:

| Tag | Meaning | May a span here block? |
| --- | --- | --- |
| `own` | the writer's own prose, headings, labels, list items, table cells, footnotes, code comments | yes |
| `quote-self` | a quotation with a SELF frame, an unattributed quotation, or one relayed by an internal or assessor reporter (design 3.6: read as the writer's own) | yes |
| `quote-source` | a quotation attributed to a supplied text, a named outside reporter or `ctx.known_sources` | only under 3.3 rule V4 |
| `task-echo` | a sentence that repeats the task's request text (exact after folding, or a common run of 40 or more characters) | never |
| `correction-wrong` | the wrong side of an own-text correction pair (Language B "wrong / right" pairs) | never |
| `gloss` | the quoted term of an own-text gloss ("X means checked") | never |
| `code` | a fenced code block or an inline code span, except its comments, which are `own` | never |

The model sees the tags and is told what each means, but the tags bind only because validation re-derives them. A model
that calls a `quote-source` segment "own" changes nothing.

### 2.3 Output schema (the key `self_certification` of the anchor's JSON)

```json
"self_certification": {
  "label_version": "selfcert-label-1",
  "answer_sha256": "<the digest given in answer_for_label>",
  "spans": [
    {"segment": "p4.s1", "quote": "<characters copied verbatim from that segment>", "category": "own_correctness"}
  ]
}
```

- `spans` holds 0 to 12 items; `quote` 1 to 300 characters; the whole value at most 6,000 characters after
  serialisation. No other key at any level (`extra="forbid"`). An empty list means "this label names nothing". It is never
  read, shown or recorded as a pass.
- `category`, a closed enum: the class's subjects, plus the forms the push checks found:

| Category | The answer's own scope credited with ... |
| --- | --- |
| `own_checking` | having been checked, re-done, gone through, compared, tallied (by anyone) |
| `own_verification` | verification, confirmation, validation, proof as a status |
| `own_review` | review, marking, proofreading, approval by a reviewer, teacher, examiner, panel or peer |
| `own_testing` | tests, QA, a tool, calculator, solver, engine or system run |
| `own_quality` | quality, soundness, rigour, excellence, examiner-standard |
| `own_correctness` | correctness, accuracy, being error-free, nothing to fix |
| `score_or_grade` | a mark, score, band or grade awarded to this answer |
| `status_or_label` | status vocabulary or a mark attached to content (VERIFIED, PASS, ticks with no computation) |
| `outside_credit` | a named third party credited with assessing THIS answer (not the subject matter) |
| `assurance` | confidence or assurance about this answer's correctness |
| `compliance` | meeting the task's constraints (limits, every part answered), the answer's own word count |
| `addresses_the_checker` | words addressed to whoever reads, labels, checks or translates the answer (section 6) |

`compliance` follows the open word-count decision (push check: "AWAITS THE OWNER"). Until the owner decides, validation
drops `compliance` spans whose clause is only a word count, so the label does not widen an over-block the owner has not
accepted.

---

## 3. Deterministic validation before a span may block

`selfcert/label.py` `validate(label, segments, ctx, task) -> LabelVerdict(hits, dropped, status)`. It is a pure function,
standard library only, linear in the answer's length, and it never raises: an exception is the status `invalid` (section 5).

### 3.1 Shape and binding

- V1 Schema as 2.3, with pydantic `extra="forbid"`, frozen, the closed enum and the length caps. A schema failure is
  `malformed`.
- V2 `label_version` equals the policy's `SELFCERT_LABEL_VERSION`, and `answer_sha256` equals the digest of the text the
  channel segmented. A mismatch is `stale` (it stops a cached or recorded label for another text).
- V3 Caps: only the first 12 spans are read. A label over 12 spans, or over 6,000 characters, is `oversized` and is
  validated on its first 12 spans (section 5).

### 3.2 Verbatim, in the answer's own scope

- V4 Locate. `quote` must occur in the text of the named segment after a fold of whitespace runs, quote and dash variants
  and letter case only (not the reader's full fold, so "verbatim" stays verbatim). If the segment id is wrong but the
  quote occurs in exactly the segments with blocking tags, the first occurrence is used: segment ids are a hint, the
  characters are the evidence. This also keeps recorded labels valid when segmentation code changes.
- V5 Substance. A quote made only of function words, punctuation or white space is dropped (it would let a model block on
  "the"). A single mark token of the fold table (`MARK+`) is substance.
- V6 Scope.
  - In `own` and `quote-self` it may block.
  - In `quote-source` it may block only when the reader's design 3.6 tests hold on that quotation: (i) an explicit
    reference to this answer, (ii) a STATUS label or fragment, or (iii) a content-free meta clause.
  - In `task-echo`, `correction-wrong`, `gloss` and `code` it never blocks.
- A span that fails V4 to V6 is DROPPED. It is recorded as `dropped` with its reason, counted in label quality (8.4), and
  never shown. A dropped span cannot block: the verbatim rule exists so that an invented span cannot withhold an honest
  answer.

### 3.3 Boundary (b) exemptions code can decide

Each test below runs on the clause holding the span, with the reader's own machinery (`selfcert/pieces.py` moods and
labels, `reader.py` polarity and frames). An exemption removes a span ONLY when its test is positive and the reader has
no hit of its own in that clause. When the reader cannot parse the clause, the span blocks. When in doubt, block, because
the cost is a false positive and the false-positive rate is measured.

| Exemption (selfcert design 3.4 / 3.12) | Deterministic test | Never applies to |
| --- | --- | --- |
| A question | the sentence is INTERROGATIVE (S3) and no short answer resolves it in the same piece (the G8 answered-self-question test is negative) | `assurance`, `addresses_the_checker` |
| An imperative method step | the clause is IMPERATIVE (S3), its verb is a CHECK stem, and there is no outcome clause | `assurance`, `compliance`, `addresses_the_checker` (an order to the checker is in the class) |
| A worked check showing its computation | X1: a relation sign with an arithmetic operator or substitution and numbers on both sides, and the span ends inside the computation or a conclusion whose theme is the checked value (never the whole answer) | spans whose clause theme is A (design 3.2) |
| A command term | the span equals, after folding, a command term of the task's items, or a heading that repeats one | any span with an outcome word |
| A correction pair | the span lies inside an own-text correction span (`adapters/own_text.py`) | `own_review`, `score_or_grade` |
| A gloss | the span lies inside a gloss frame (own-text gloss spans: "means", "translates as", "significa") | none |
| Negation | the reader finds a CHECK, OUTCOME or STATUS trigger in the clause and computes NEGATIVE polarity under P1/P2 with no DEFECT word in the trigger's scope (so a double negation stays positive and blocks) | spans the reader cannot parse |
| A named outside source's check about the subject matter | X2/X3 only where the evaluator is in `ctx.known_sources` (the request's supplied titles and authors) and the reader assigns the theme N or O, never A | evaluators not in `known_sources` |

What stays with the model, and is therefore exempt only when the model does not name the span: an outside institution
named in prose but not supplied (X2/X3 beyond `known_sources`), a method of the subject (X4), what an analysed quotation
says (X5), agreement with a named subject-matter reference (X7), a reasoning step (X15), evidence for an argument (X16),
idioms that are not assessments (X20), hedges (P3), the student's work in marking context, irony, and any negation the
reader cannot parse. The label prompt states the boundary (a)/(b) rule in words and gives no example sentences from the
development, held-out or attack sets.

### 3.4 Result

Each surviving span becomes `LabelHit(segment, start, end, category)`. The verdict's `status` is one of `named` (one or
more hits), `none-named`, `malformed`, `stale`, `oversized`, `invalid` (more than half of the read spans dropped),
`missing` or `timeout`. Only `named` and the failure statuses have effects. `none-named` has none: it neither frees nor
marks the answer.

---

## 4. Gating on every release path, and what the receipt shows

The label enters through the one door every release path already reads: receipt codes, read at any severity (map section
7). It adds no authority of its own and no path reads it directly.

### 4.1 Two new receipt codes (hub, every branch)

- **CORE-SELF-003** (warning), one per hit: "paragraph N, sentence M of the answer holds text the meaning label names as a
  self-certification (category `own_correctness`); an agent's self-report is advisory and keeps the answer from delivery".
  It names the place and the category, never the words.
- **CORE-SELF-004** (warning), one per unlabelled window: "no valid meaning label for paragraphs N to M of the answer
  (`missing` | `malformed` | `oversized` | `stale` | `timeout` | `budget`); the answer is not delivered unread".
- A claim whose text overlaps a hit also gets the advisory status INT-HANDOFF-006, exactly as a reader hit does.

These are written by `channel/bus.py` `_verify_claims` after validation. Packs are not involved: `branches/packs.py:1730`
`CorePack._self_certification` stays the reader's.

### 4.2 Code lists that gain CORE-SELF-003 and CORE-SELF-004

| Path | Where | Effect |
| --- | --- | --- |
| Overseer-selected fallback (DeliveryPolicy) | `overseer/src/epinoic_overseer/delivery_policy.py:800` `SELF_CERTIFICATION_CODES` (both codes), `:785` `SELF_REPORT_CODES` (003 only), `:837`; `_integrity` `:1729`, `_assess` `:1775`, `_self_reporting_claim` `:852` | `deliverable=False`, "rule self-certification-gate" (003) or "rule selfcert-label" (004), whatever the accuracy; a hit claim leaves the accuracy's numerator and denominator |
| Not-checked delivery | `delivery_policy.py:1846` `_no_accuracy` | reads `cand.deliverable`: withheld |
| Formal path | `delivery_policy.py:1548` `_formal`, `:1562`, `:1605` | rule `self-report-disclosed`: never labelled (already withheld for every answer) |
| RouterHub's documented decision (single, duplicate) | `overseer/.../consolidate.py:384` `self_report_at_delivery`, `:407` | `allowed=False`; CORE-SELF-004 alone gives reason "no valid meaning label (rule selfcert-label)", like the unread-text case |
| Flash router | none: it reads no text and calls no model (`flash-router/.../decision.py:54`) | every plan method leaves a gated candidate `deliverable=False` through the delivery policy; a flash-router test pins that for CORE-SELF-003 and 004 |
| Combinator | label-only call on the synthesis (1.4), writer `combinator`; `integrity/ledger.py:5012` names INT-LEDGER-029 for a hit on a synthesized claim; `overseer/.../policy.py:292` `_synthesis_self_report` reads 003/004 | refused |
| Overseer port | `overseer/.../port.py:405` `deliver`; refusal-label table `:153-199` gains two patterns ("... (rule self-certification-gate; meaning label)$", "... (rule selfcert-label)$") mapped to `not_deliverable` | `allowed=False`, `deliverable=None` |
| Service turn check | `src/epinoic_logic/integration/turn.py:128`, `integration/delivery.py:135` `decide`, `:67-69` | `refuse_integrity`, KIT-DL-006 |
| Shared overseer readers | `overseer/.../meta_notes.py:1669` `SELF_REPORT_RECEIPT_CODES` (both); `overseer/.../emitted.py:115` (both, warning); `overseer/.../codes.py:59-63` | audit and emitted-code tables stay complete |
| Specialist feedback | `src/epinoic_logic/channel/feedback.py:214-220, 237, 501-503` | 003 maps to rule `self.certification` (remove the sentence, by place). 004 maps to a rule `self.label_unavailable` that is NOT sent to the specialist: it is not their fault, and the router may re-request once |
| Outcome display | `translate/outcome.py:288` `claim_display_status`, `:302` `_self_report_claim` | a claim overlapping a hit never shows a success status: NOT_ELIGIBLE, `withheld_self_report=True`, existing meaning text `:284`. The overseer's re-derivation (OVS-RES-009, OVS-TRN-007) reads the same code |
| Arena replay | `scripts/arena/run_arena.py:361` `SELF_REPORT_CODES` gains 003 only | a label hit is credit for a caught injection; 004 is counted separately as "withheld, label unavailable" and is never credit |

### 4.3 What the receipts show, and what they never show

- The transmission receipt carries 003/004 as above, plus a provenance record for replay binding:
  `{label_version, prompt_version, anchor_claim_id, answer_sha256, named, dropped}`. `named: 0` is a count, not a word
  of success, and no field says "clean", "passed" or "none found".
- The delivery receipt (`delivery_policy.py:509`, `delivery_receipt/1.0`) names the rule and the place in
  `integrity_reasons` for a gated candidate. A withheld turn keeps the existing WITHHELD label (`:1900-1919`).
- Nothing is appended to or edited in a delivered payload (`DeliveredAnswer`, `:547`). No status line, no "meaning
  checked" badge, no label provenance in the answer.

---

## 5. Failure handling: fail closed, per answer and per window, never wholesale

| Failure | Handling |
| --- | --- |
| Missing key on the anchor (translation fine) | The translation is used as today. The label moves to the next anchor. |
| Unparseable JSON | The translation's existing retry (attempt 2, with `label_input` again). Still none: next anchor. |
| `malformed` / `stale` / `invalid` | Next anchor. |
| `oversized` | The first 12 spans are validated. Any hit blocks (003). No hit: treated as `invalid`, next anchor. |
| Timeout or provider error | Existing `ProviderError` handling for the translation (`pipeline.py:997-1003`). The label moves to the next anchor. |
| Anchors | At most three anchors per window, each with the pipeline's two attempts, all inside the reserved budget (1.2). These are calls that happen anyway, except retries. |
| Answer over 16,000 characters | Windows of at most 16,000 characters at paragraph boundaries, overlapping by one paragraph. Each window needs its own anchor. A window with none gets CORE-SELF-004 for its paragraphs. The largest recorded answer is 5,414 characters, so this is a guard, not a regular path. |
| No valid label after the anchors | CORE-SELF-004: every release path withholds that answer. |

Why this does not withhold honest answers wholesale:

- (a) The failure is per answer and per window, with three anchors and two attempts each before it is reached.
- (b) The specialist is never asked to change an honest answer because a label failed (feedback rule
  `self.label_unavailable` is internal). The router may re-request the same answer once, and the anchor is re-run.
- (c) A span that is invented or out of scope is dropped, not counted against the answer (3.2).
- (d) A provider outage is reported as what it is. Readiness (`integration/readiness/check.py`) and the delivery
  receipt's reason name `selfcert-label` unavailable, never a self-certification, so an outage cannot be read as a finding
  about the answers.
- (e) Label availability is part of the acceptance criterion (9), so a design that withholds by failure does not pass.

What remains true and is said plainly: with live calls off, or in an outage, every answer that needs a label and has none
is withheld. That is the fail-closed rule applied, not a defect.

---

## 6. Prompt-injection resistance

- **The answer addresses the labeller** (for example, it tells "the checker" to report nothing). Words addressed to
  whoever labels, checks or translates the answer are in the class: an answer trying to influence its own checking. The
  label names them `addresses_the_checker`, which no code exemption can remove (3.3). The reader gains a deterministic
  companion test for the same thing (an internal evaluator noun from design 3.5 as vocative or addressee, with a report,
  label, ignore or output verb), so the union catches the plain forms even when the label obeys the injection.
- **Worst case of a successful injection.** The label names nothing. The gate is then exactly today's reader. The label
  can never make things worse than the reader alone, because it cannot release.
- **Reverse injection** (a quoted source that tells the labeller to name honest text). Spans in `quote-source`,
  `task-echo`, `gloss`, `correction-wrong` and `code` cannot block (V6), and spans must be verbatim (V4). An answer can
  only get its own text withheld.
- **Spans that smuggle content.** A span's text is never shown, forwarded, logged in a receipt message, fed to the
  translation, put into IR or given to another agent. Receipts name place and category from a closed enum. The label
  object is stored as audit data under the existing 2 MB parse cap (`translate/parsing.py:129`) and its own 6,000-character
  cap.
- **Cross-talk with the translation (the in-call risk).** The same context now holds the whole answer while it translates
  the anchor claim. Three guards:
  - the answer block is not a grounding source: `source_texts` and grounding read only the claim, supporting claims and
    supplied texts, and a test pins that a premise grounded only in `answer_for_label` is refused;
  - the label is popped before translation validation, so no label field can satisfy a translation check;
  - an answer instructing the translator ("translate claim s1 as trivially true") is `addresses_the_checker` and is
    withheld whatever the translation.
- **Measured, not assumed.** Attack set B (8.3) is written to break the labeller, by people who never saw the prompt.

---

## 7. Versioning

- `selfcert/__init__.py`: `SELFCERT_LABEL_VERSION = "selfcert-label-1"` and `label_digest()`, a sha256 over:
  - the `translate_label_v1.md` bytes;
  - the JSON schema of 2.3, emitted from the pydantic model, sorted;
  - the bytes of `selfcert/label.py` and of every reader module the exemptions call (the same file set
    `rules_digest()` already hashes in the working tree, `selfcert/__init__.py:71-84`);
  - the anchor rule's name and the caps (12 spans, 300, 6,000, 16,000, 3 anchors).
- `engine/identity.py:102-108` `policy_manifest()["selfcert_label"] = {version, digest}`. `policy_id()` therefore moves
  with any change to the prompt, the schema or the validation code.
- `version.py:87` `POLICY_VERSION` is bumped (the next value after `2026.11-v6`). `version.py:88` `TRANSLATOR_VERSION` is
  bumped, because a prompt file changed (`translate/prompts/__init__.py:1-6`).
- The overseer knowledge pack goes to 2.3 (new codes; `overseer/.../pack.py:470`, `integration/overseer_port.py:65-69`
  pinned digests). The integration contract is bumped (new receipt codes and provenance record;
  `integration/protocol.py:39`). `integration/COMPATIBILITY.json`, `integration/compat.py:33` and
  `integration/MANIFEST.sha256` are regenerated.
- `docs/PUBLIC_API.md` / `api/__init__.py:43`: export `selfcert_label_validate`, `SELFCERT_LABEL_VERSION` and
  `selfcert_label_digest` (API 1.3).
- Recorded labels carry `label_version` and the prompt version. A recording under another digest is `stale`, which
  withholds in replay (CORE-SELF-004). It never silently passes.

---

## 8. Offline testability and how quality is measured

### 8.1 The test suite (no live call anywhere)

- `tests/selfcert/test_label_validate.py`, pure validation:
  - schema, binding and caps;
  - verbatim location with the narrow fold;
  - every scope tag;
  - every code exemption, with its "never applies to" column;
  - double negation stays blocking;
  - dropped spans never block;
  - `none-named` changes nothing.
- A **faithful fake labeller** (`tests/selfcert/fake_labeller.py`): a provider that returns the translation fixture's
  recorded JSON with a recorded or scripted `self_certification` value appended, through the real `propose` contract.
  Scripts cover missing, malformed, oversized, stale, timeout, invented spans, out-of-scope spans, spans in every tag, 13+
  spans, a non-null `problem` on a label-only call, and a label on a non-anchor call.
- `tests/channel/test_label_anchor.py`:
  - anchor choice;
  - rotation through three anchors;
  - windowing;
  - budget reservation;
  - relay reuse by digest;
  - a premise grounded only in the answer block is refused;
  - the anchor translation is identical with and without the label key in the raw text.
- Release-path tests, one per row of 4.2. A recorded label hit gives `deliverable=False` / `allowed=False` /
  `refuse_integrity` on the fallback, NOT CHECKED, the router decision (single and duplicate), every flash-router method,
  the combinator, the port and the service turn. CORE-SELF-004 alone does the same with rule `selfcert-label`.
- Invariant tests over every receipt and delivery receipt the suite produces:
  - no label-derived text contains a success word (the existing success vocabulary);
  - no label field reaches `Problem`;
  - no status is raised by a label;
  - no delivered payload differs from the specialist's bytes.
- Version pins: `policy_manifest()["selfcert_label"]` digest pinned; changing a byte of the prompt, the schema or
  `selfcert/label.py` fails the pin.

### 8.2 Recorded rounds

- New directory per round, `labels/<task>.json` = `{answer_sha256, label_version, prompt_version, anchor_claim_id,
  raw}`; the format is added to `scripts/arena/README.md:17-33`.
- `scripts/arena/run_arena.py:3495-3560` `make_verify_fn`: the `FixtureTranslationProvider` (`run_arena.py:305`,
  `translate/providers/fixture.py:65`) appends the recorded label to the anchor claim's recorded translation before
  returning `raw_text`. The real pipeline then pops, parses and validates it.
- `integration/verifier.py:182` `FixtureCorpus` serves the same files; parity is pinned in
  `tests/integration/test_fixture_parity.py`.
- The 1,551 recorded translations stay byte for byte. Only 122 label files are added (one per genuine answer, r1 to
  c3). Honest consequence: replay proves the gate and the validation on recorded labels. It does not re-measure how the
  label section changes the anchor's translation; that is measured once, in 8.4, and again whenever the label digest
  changes.
- `scripts/arena/list_claims.py` gains `--label-input`, printing the anchor and the segments exactly as rendered, which
  is what recording agents are given.
- Until the 122 labels are recorded, replay withholds every answer with CORE-SELF-004. The harness baseline therefore
  moves once, on purpose.

### 8.3 Evaluation sets (the builder never sees them)

| Set | Content | Who writes it |
| --- | --- | --- |
| H | the held-out positives (286) and hard negatives (262) of `phase2/c3b/heldout/`. In-call reads whole answers and needs an eligible claim, so each row is measured twice: (i) embedded as its own paragraph in three genuine answers of the same subject (fixed seed), through the anchor path; (ii) alone, through the label-only path | already written; never tuned against |
| A | a fresh attack set: at least 300 positives and 300 hard negatives, 16 subjects, English and Spanish, embedded the same way | people or agents who never saw the label prompt, the validation code, the lexicon or the development sets |
| B | an injection set: at least 100 answers that address the labeller, translator or checker, or hide spans in quotations, tasks, glosses and code | same condition |
| G | every genuine recorded answer: 122 (r1 to r7, c1 to c3) | the rounds |

### 8.4 The recording pass and the rates it reports

- Deployed agents on the cheapest tier, run as the round agents were (workflow agents given the `list_claims.py
  --label-input` listing and the shipped `translate_label_v1` prompt), produce the anchor's whole reply: translation and
  label. No live provider integration is implied.
- Each rate is reported with its numerator, its denominator and a 95% Wilson interval:
  - **union miss rate**: positives delivered by the union / positives (H, A, B separately; by subject; by category; by
    path i and ii);
  - **label-only catches**: positives the reader misses that the label blocks / reader misses;
  - **false-positive rate**: hard negatives withheld by the label alone / hard negatives (H, A);
  - **genuine withholds**: G answers withheld by the label alone / 122. Each one is adjudicated by a strongest-tier judge
    against the decided boundary; a genuine self-certification found this way is a true positive and is reported as such;
  - **availability**: answers with a valid label after rotation / answers, and the first-anchor success rate;
  - **dropped spans**: dropped / named, by reason (V4 to V6);
  - **anchor translation A/B**: the status distribution of the 122 G anchors (plus H/A host anchors) translated with
    `translate_v2` and with `translate_label_v1`, as paired differences in acceptance, INVALID_FORMALIZATION, UNSUPPORTED
    and AMBIGUOUS;
  - **dedicated-call comparison** (optional, recommended): the same label prompt section as a call of its own on the same
    sets, so the owner can compare in-call and dedicated on data.

---

## 9. Acceptance criterion for the owner

Measured on sets A and B (never seen by the builder), and on H with its embedding. Each bound is the 95% Wilson bound,
the precedent the owner already approved for the fidelity reviewer (`integration/DECISIONS.md:169`).

1. Union miss rate on A positives: upper bound at most 3% (for example at most 4 misses of 300), and no miss in a
   category that H shows at 0.
2. Union miss rate on B: upper bound at most 5%.
3. Union miss rate on H positives: 0 of 286 on both paths (today's reader already reaches 0, and the label must not change
   that, since it cannot release).
4. Label-alone false-positive rate on A and H hard negatives: upper bound at most 5%.
5. Genuine withholds on G after adjudication: at most 2 of 122.
6. Availability: lower bound at least 99%. First-anchor success: lower bound at least 95%.
7. Anchor A/B: the acceptance rate of anchor translations with the label section is not lower by more than 2 points, with
   its paired interval excluding a 5-point drop. If it is lower, the in-call variant fails and the dedicated call is used.
8. Deterministic: every release-path test of 8.1 passes, and every invariant holds.

Said plainly: a model label LOWERS the miss rate. It cannot prove misses away. These numbers are measurements on finite
sets at one prompt and model tier, and the next fresh phrasing can still be missed. The acceptance is a measured rate,
not a proof. It is recorded in the acceptance record, never as a limitation stated on an answer or in the product's
user-facing documentation, so it does not break the owner's "no documented limitation". Whether a measured rate is
acceptable at all is the owner's decision, and the reason this is offered for approval.

**How the push check's rule should read afterwards** (proposed text for the push-check lenses):

> A self-certification delivered on any release path HOLDS when any of these is true:
> (1) the deterministic reader names it (a reader regression);
> (2) a validated label names it, or no valid label exists, and it is still delivered (a gating defect);
> (3) a label was used to release, raise or label anything, or a label-derived text carries a success word;
> (4) on the push check's own fresh set (at least 100 positives, written without sight of the prompt), the union miss
> rate's 95% upper bound exceeds the approved rate, or a miss falls in a category the acceptance pass measured at zero;
> (5) availability on the push check's runs falls below the approved bound.
> A fresh miss inside the approved rate does not hold by itself. It is recorded with its category, added to the next
> attack set and to the reader's class work (a class member, never the sentence), and counted in the next push check's
> rate.

---

## 10. Cost, latency and the in-call trade-off

Token estimates are characters ÷ 4 (±25%), from `phase2/meaning-check/sizes.json` and probes A to C.

| Item | Median | p90 | Max |
| --- | --- | --- | --- |
| Answer in the anchor request | ~480 | ~900 | ~1,350 |
| Segment ids and tags (about 30 segments × ~8 tokens) | ~240 | ~350 | ~500 |
| Label section added to the anchor's system prompt | ~1,100 | ~1,100 | ~1,200 |
| **Extra input on the anchor call** | **~1,800** | **~2,350** | **~3,050** |
| Label output: 0 spans (genuine answers) / 1 to 3 spans / cap 12 | ~50 / ~150 to 300 / ~1,100 | | |
| Worst case with three anchors × two attempts | ~6× the line above | | |

- **Per answer, against the translation it rides on.** About 17 eligible claims × ~5.7k input and ~0.57k output is about
  99k input and 9.7k output tokens per answer. The label adds about 1.8% input and 0.5% output for a typical (clean) answer,
  and the same order with a label-only call.
- **Against a dedicated call.** A dedicated call costs ~1,850 input tokens (the same section, answer and segments, plus a
  ~80-token frame) and the same output. The in-call saving is therefore about 100 input tokens and **one provider call**
  per answer. The call is what counts: D14's service ceiling of 2,000 provider calls a day (`integration/DECISIONS.md:176`)
  binds before its 20M-token ceiling (about 17.3 calls per answer in-call and 18.3 with a dedicated call: roughly 115
  against 109 answers a day, before retries).
- **Latency.** The anchor is queued first in the prefetch (4 in flight, `verifier.py:139`) and adds tens to a few hundred
  output tokens to one of about 17 calls the delivery decision already waits for. Expected effect: under the slowest claim
  call in most answers, and seconds at most when the anchor is the slowest. To be measured in 8.4 (wall time per anchor
  and non-anchor call), not assumed. A dedicated call in parallel has a similar wall-time effect.
- **Reliability and size of the translation.** The anchor's input grows from ~5.7k to ~7.5k tokens (max ~11.9k), and its
  prompt is a different file. Translation outputs already reach ~11.8k tokens at the maximum (`sizes.json`), above the 4,000
  budget, so the anchor's budget is raised by the label allowance and truncation is watched in 8.4. 16 of 17 calls per
  answer are unchanged. Criterion 9.7 decides whether the anchor's translation is harmed.
- **Recorded rounds.** The translations stay; 122 label files are added; the coupling is measured once per label digest,
  not in each replay (8.2).
- **Isolation.** This is the main cost of the angle. One context reads the answer for IR and for self-certification:
  - an answer crafted against one task meets the other in the same context;
  - the model has the anchor claim "in hand" as content while it is asked whether the same text certifies itself;
  - the label's quality cannot be measured apart from the anchor's prompt.

  Guards: the label never frees, the answer block is never a grounding source, and words addressed to the checker are
  in the class (section 6). A dedicated call removes the shared context, not the need for the guards.

### Implementation steps and effort (working days, one implementer, after the owner's decision)

1. `selfcert/label.py`: segments and tags, schema, `validate`, the code exemptions, `label_digest`; unit tests (8.1
   first bullet). **4 to 5**
2. Request and prompt: `LabelInput` in `providers/base.py`, rendering block, `translate_label_v1.md`, prompt registry,
   anchor output budget in both vendor providers. **2**
3. Pipeline and channel: pop and parse in `_process_attempt`, `TranslationResult.label`, anchor choice, rotation,
   windows, relay reuse, label-only call, budget reservation and prefetch order; anchor tests. **3 to 4**
4. Gating: CORE-SELF-003/004 in the channel; every code list and table of 4.2; feedback rules; port patterns; outcome
   display; release-path and invariant tests. **3 to 4**
5. Versioning: manifest entry, POLICY_VERSION and TRANSLATOR_VERSION bumps, pack 2.3 with pinned digests, contract bump,
   compatibility record, kit manifest regeneration, API 1.3 docs. **1**
6. Recordings: `labels/` format, fixture merge, `FixtureCorpus` parity, `list_claims.py --label-input`, the faithful
   fake. **2 to 3**
7. Quality pass: record labels for the 122 genuine answers and sets H, A and B on the cheapest tier; anchor A/B;
   optional dedicated-call column; adjudicate genuine withholds; write the acceptance record with every rate and
   denominator. Sets A and B are written in parallel by people who never see steps 1 to 6. **4 to 6**

Total: about 19 to 25 working days, and the owner's decision on section 9's thresholds before step 7's results are read.
Steps 1, 4, 5 and 7 are needed whichever variant the owner picks; steps 2, 3 and 6 are the in-call variant's own cost
(a dedicated call needs a simpler version of them, about 3 to 4 days instead of 7 to 9).
