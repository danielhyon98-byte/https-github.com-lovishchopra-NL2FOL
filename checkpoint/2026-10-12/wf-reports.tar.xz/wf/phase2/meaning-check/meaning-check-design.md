# Meaning check for the self-certification class: design for the owner's decision

Status: a design memo for Daniel's decision on the block-only model label. Nothing here is implemented, and no provider
was called to write it. It merges three designs and two judgements, all in the workflow's scratch area under
`phase2/meaning-check/`: the map (`map.md`), the designs (`design-separate-call.md`, `design-overseer-side.md`,
`design-in-call.md`) and the judgements (`judge-safety.md`, `judge-closure-cost.md`). Repository references are
`repository path:line` on the development line's working tree. That tree holds uncommitted round-11 work, so line
numbers can move by a few lines. No model is named. "Cheapest tier" and "strongest tier" are the tiers of
`docs/PROTOTYPE.md:87-89`.

The rule this serves (owner, unchanged): an answer's claim about its OWN checking, verification, review, testing,
quality or correctness must never help it be delivered, selected or labelled. Boundary (a) is gated and boundary (b) is
free, as decided in the c3b selfcert design (`phase2/c3b/selfcert-design.md`, sections 3.11 and 3.12).

How numbers are marked in this memo:

- **Measured** numbers name their source.
- **Estimated** numbers say so. Token sizes are characters ÷ 4 (±25%), because no tokenizer is installed (map section 6).
- **Proposed** numbers are thresholds offered for approval.

---

## 1. Decision summary (for Daniel)

**What yes changes.** Each answer, and each combined answer, gets one extra small call on the cheapest model tier. The
model reads the answer's own sentences by meaning and can only withhold. It never releases an answer, raises a status
or adds text. If the call fails, is missing or is talked out of reading, that answer is withheld. Today's rule reader
stays: either one can withhold. Nothing is shown on answers.

**Cost.** About 2,300 tokens in and 230 out for a typical answer (estimated). That is about 2% of what translating it
already costs, plus one call under the daily call cap.

**What it cannot promise.** Zero misses. A model lowers the miss rate; it cannot prove it zero. In round 11 the reader
alone missed 16 of 119 fresh phrasings (13.4%).

**What you approve.** On at least 400 fresh phrasings, written by people who never saw the label's instructions, the
combined gate misses at most 4 (1.0%; 95% upper bound at most 2.5%). It wrongly withholds at most 8 of 400 honest
look-alikes and 3 of 264 recorded honest answers, and every failure withholds. Afterwards a push holds on any repeat of
a known miss, any gate defect, or a fresh-miss count statistically above 2.5%. Every miss found is fixed before the next
push. This residual is written only in the acceptance record.

**If you say no.** The reader alone stays, and pushes keep holding: every check since round 9 found fresh misses of 4.5%
to 20%.

---

## 2. The chosen design

### 2.1 In one paragraph

Build the **separate block-only call**: a small labeller on the cheapest tier, separate from translation, that reads
one answer at a time. Graft onto it four parts of the overseer-side design:

- keyed canaries;
- anchoring under the reader's visible form;
- one function, beside today's self-report reads, through which every release path reads the label record;
- the explicit trust rule (T17), which also rules out any reader-only degraded mode.

Then repair every defect the two judges named (section 2.4). The gate becomes `reader OR validated label`. A valid
label record is **required** for every deliverable answer. If the record is missing, fails validation, is suppressed or
has expired, the answer is withheld, and the withhold is reported as an outage (KIT-DL-014), never as a fault of the
answer. No label text ever reaches the IR, the engine, a receipt message, a log or the delivered payload.

### 2.2 Why this base

| Design | Safety judge | Closure-cost judge | Deciding reason |
| --- | --- | --- | --- |
| Separate call | 8.0 | 7 | Required attestation, re-validated by the auditor. A verdict for every sentence, so no sentence can be skipped silently. Starts at the service's step 4, beside the translation prefetch. Lowest false-positive surface. Best offline testability. |
| Overseer side | 7.5 | 6 | Strongest suppression defence (keyed canaries) and anchoring. But the call starts only after the answer's translation (`overseer/src/epinoic_overseer/audit.py:584-605`; `src/epinoic_logic/channel/bus.py:2633` then `:2638`), so its wait sits on the service's critical path. It needs D18 amended, leaves the translator's claim display unchanged, and has about twice the input. |
| In call | 5.0 | 3.5 | Nothing requires a label to exist. With no verifier configured, `_verify_claims` returns before any label is made (`channel/bus.py:3901-3902`), so the answer meets the gate exactly as the reader alone would (fail open). There is no control against suppression. Answer-controlled scope tags (`task-echo`, `quote-source`) never block. |

Two measured facts from the in-call design's read-only probes (`phase2/meaning-check/probe/`) explain why the label must
read the whole answer, not the claims translation already sees:

- 14 of the 16 round-11 reader misses never reach an eligible claim.
- 0 of 480 insertions of the last push check's 12 lens-reported misses into the 20 round-10 answers reach an eligible
  claim.

One judged claim of the separate-call design is **withdrawn**. It said the in-call variant would make the 1,551 recorded
translations stale. It would not: fixtures are bound to the claim-text digest, not to the prompt
(`src/epinoic_logic/translate/providers/fixture.py:75-90`). The in-call variant is rejected for the safety reasons above,
not for that one.

### 2.3 What is grafted from the other designs

| Idea | From | Why |
| --- | --- | --- |
| Keyed canaries, generated by the reader's lexicon classes (evaluator × family × scope × form × language) from an HMAC of the issue id under a deployment secret, at keyed positions. A separate recording key is used offline. A negative canary in a keyed 10% of calls is used for drift monitoring only. | Overseer side 6.2 | Repairs S1. The separate call's 64-row control pool comes from development sets that live in the repository, so a writer who has read them can aim a suppression at everything else. |
| Anchoring under `selfcert.visible_form` (rules N1 to N7, `src/epinoic_logic/selfcert/__init__.py:370`), with white space collapsed and quotation marks folded, and offsets mapped back through the fold's index map. | Overseer side 3.3 step 4 | Recovers availability on obfuscated answers without loosening safety. A span still has to be located. |
| One read function `meta_notes.label_gate(...)`, beside `audit_self_reports` (`overseer/src/epinoic_overseer/meta_notes.py:1679`). It reads the journaled record, re-validates it deterministically, and returns blocking places or raises `LabelUnavailable`. | Overseer side 2.2 | Every release path reads one thing in one way, and it can tell "a valid label named nothing" apart from "no valid label exists". |
| A distinct refusal `selfcert_label_unavailable`, mapped to `refuse_incomplete` KIT-DL-014. KIT-DL-014 is unused today: `src/epinoic_logic/integration/delivery.py` and `integration/vectors/codes/kit-codes.json` stop at KIT-DL-013 and KIT-DL-012. | Overseer side 4.1 | Repairs S3 and I5. An outage is not reported as an integrity fault of the answer. |
| Trust rule T17 ("withholding evidence"), written into the overseer design and pack 2.3. | Overseer side 3.5 | It states openly that one agent output may act without a deterministic check, and only to withhold. TR3 stays intact for everything that could let something through. |
| No reader-only degraded mode. A circuit breaker (5 consecutive provider failures pause calls for 60 s, each pause a fast withhold). The port's hello reports `selfcert_label: degraded`. | Overseer side 5.2, 5.3 | Without this, an attacker who can slow the labeller could time it to reopen the class. |
| Code exemptions are overridden by any answer-scope (A) anchor word or STATUS-family form in the span. | Overseer side 3.4 | Closes the obvious abuse of each exemption ("Check: 3 × 5 = 15, so every step above is correct"). |
| Task text is not sent to the labeller. Only the `marking` flag, writer, subject, task type and known-source titles are sent, all from the router's journaled request. | Overseer side 2.3 | Repairs the safety judge's minor point. A task-borne injection has no way into the label input. |
| A deterministic companion test in the reader for words addressed to the checker: an internal evaluator noun as addressee, with a report, list, label, ignore or output verb. This is part of decision L4. | In call 6 | The union then catches the plain forms of a targeted suppression even when the label obeys it. |
| An A/B measurement of the canaries' priming effect (a subset run with and without canaries). | Overseer side 8.3 | Repairs the rest of S1. |

### 2.4 Every defect the judges named, and its repair

| Id | Defect (judge) | Repair in this design |
| --- | --- | --- |
| S1 | Predictable control sentence (safety); fixed public pool (closure-cost) | Keyed canaries and a priming measurement (2.3) |
| S2 | INT-SELF-003, a "clean" info finding, would turn every clean receipt into ACCEPTED_WITH_FINDINGS (`channel/bus.py:4140`). It is the closest thing to a pass word. | **INT-SELF-003 is dropped.** Presence is proved by a valid label RECORD on the journaled `ChannelEvent` (`label_json`, `label_sha256`), re-validated at release by `label_gate` and by the auditor (OVS-FID-010). A clean answer gets no finding, so its receipt status is unchanged. The record's state `none_named` is pinned by an invariant test never to reach a student-facing field, a badge, `checksSummary`, a reason or a log line. |
| S3, I5 | A label outage reported as an integrity refusal | `selfcert_label_unavailable` → KIT-DL-014, with an integration contract bump (2.3, 2.5.9) |
| S4, I6 | Contract and pack versions not bumped | Contract 0.7 → 0.8, pack 2.2 → 2.3, delivery-v1 → delivery-v2, `POLICY_VERSION` bump, API 1.2 → 1.3. The label code lives in its own package with its own digest (2.5.9). |
| S-minor | The task block is untrusted and a task-borne suppression is not caught | The task text is not sent (2.3). Task-borne injection rows still go into the injection set (3.6). |
| O1 | E-OUT exempts any lexicon institution, so answer-chosen words can free a span | E-OUT applies **only** to `ctx.known_sources` from the router's request. Every other named body stays with the model (2.5.5). |
| O2 | Targeted suppression is open unless the directive category is adopted | DIRECTIVE is part of the proposal (decision L4), with the reader's companion test and at least 50 targeted-suppression rows in the injection set (3.6). |
| O3, I4 | A partial anchoring failure can fail open | Any span that cannot be located on `own` text, or that names an unknown id, makes the reply `malformed`: one repair retry, then INT-SELF-002. The only exception is when another span of the same reply already survives and blocks. Exemptions never count toward any drop rule, in either direction. |
| O4 | The translator-side claim display ignores the label | `claim_display_status` (`src/epinoic_logic/translate/outcome.py:287`) gains `labelled_self_report`. Every surface that shows a claim status passes it, with one test per surface (3.3, T18): the channel receipt summary, the outcome summary, the overseer's OVS-RES-009 and OVS-TRN-007 re-derivation, the delivery receipt's claim view, the integration's `claim_entries` and the arena summary. |
| O5, I6 | The configured model is not bound to the measurement | Every label record and the acceptance record carry a SHA-256 of the configured model identifier (the digest, never the name). The hosted preflight refuses to serve labels unless an acceptance record exists for the pair (label digest, model digest) (2.5.9). |
| L2 | Accusations from the full review add a second, timing-dependent path | Dropped. The full review's `self_certification_as_content` quotes are recorded for monitoring only. |
| I1 | No required presence | Not applicable to the chosen base. The property it names is the core of 2.5.6. |
| I2 | No suppression detection | Keyed canaries (2.3) |
| I3 | The answer controls never-block scope tags | No sentence-level tags. Placeholders apply only to quotations located verbatim, by code, in a supplied text or in the router's task text, and only inside quotation marks. Unquoted echoed wording is the answer's own. |
| CC 2.2(3) | The step-4 prefetch and the hub may render different inputs, so the call is made twice | One function `build_input(raw_text, request)` derives the specialist's own fields with the same deterministic branch parser the hub uses. Both call sites therefore render byte-identical requests, pinned on all 122 genuine answers (T16). |
| CC 3(2) | Every reader change re-keys every recording | Recordings are keyed on the rendered request: system text, user text, schema, and canary key and positions. They are not keyed on `rules_digest()`. Validation and exemptions are deterministic and re-run from the stored raw reply when the reader changes. A reader change re-keys a recording only when it changes segmentation, and therefore the rendered text. |
| Wording | "Latency hidden", "none in the median case" | Every latency figure below is marked **expected**. None is measured. |

### 2.5 The design in detail

#### 2.5.1 Where it runs

1. **Service, step 4** (`src/epinoic_logic/integration/turn.py:195-212`). For each answer, `selfcert.read` runs on the
   raw text. If it does not refuse, `build_input` is called and `labeller.submit(input, deadline)` returns a handle. The
   call therefore runs at the same time as the translation prefetch.
2. **Hub and channel** (`channel/bus.py:2496` `respond`, and `relay` from `:2700` for syntheses and forwards).
   - After `_branch_checks` (`:2604`), if the reader refuses, the label is skipped and a record with state `skipped`
     (reason `reader-refused`) is journaled.
   - Otherwise the hub calls `submit` with the same content key, and so hits the step-4 call.
   - The result is collected immediately before `_finish` (`:2638`) and turned into findings and the record.
   - `_guarded` turns any exception in label code into INT-SELF-002 (`label-failed`). It never turns one into
     INT-INTERNAL-001 alone.
3. **Hub construction** (`branches/hub.py:190`). This adds `selfcert_labeller`. The default is `UnconfiguredLabeller`, so
   every reader-passed answer is withheld as `not-configured`.
4. **Nowhere else.** The label does not run in eligibility rule 0, the translator, the engine, the flash router or the
   combinator sub-project.

#### 2.5.2 Input: the answer's own scope, one answer per call

- **Segments.** The reader's own pieces are numbered `s1`…`sn` with places ("paragraph 3, sentence 2"). They come
  through a new public `selfcert.span_frames` and `selfcert.segments` (API 1.3). Measured (separate-call design 3.1,
  read-only count): the genuine answers have a median of 22 units, p90 47 and a maximum of 66.
- **Placeholders.** Each kind is located by code, verbatim, and only inside quotation marks:
  - `⟦source S1⟧`: the hub's own located quotation of a supplied text;
  - `⟦task⟧`: quoted task wording;
  - `⟦student 1⟧`: the student's wrong member of a correction pair, in marking context only.
- **Context block.** Writer, subject, task type, `marking` and known-source titles (at most 10), all from the router's
  journaled request through `selfcert.context_for` (`selfcert/__init__.py:470`). The answer never supplies any of them.
- **Invisible characters.** N1 characters are removed with an offset map. A run of three or more is already
  CORE-SELF-002 and refuses before any label call.
- **Size.** A chunk holds at most 8,000 rendered characters or 120 sentences. Longer input is split at paragraph
  boundaries, one paragraph of context carried over, with each chunk keyed and canaried separately. Above 6 chunks the
  answer is `oversized` and withheld. The largest genuine answer is 5,414 characters (map 6), so every recorded answer
  fits in one chunk.
- **Delimiters.** Data-block markers carry the first 16 hex digits of the SHA-256 of the blocks' content. `<<<`, `>>>`,
  `⟦` and `⟧` in the answer are replaced by fixed substitutes, and each marker is asserted to occur exactly once.

#### 2.5.3 Output schema `selfcert-label/1`

- `{"schema", "verdicts": [{"id", "v": "none"|"gated", "spans": [{"quote", "category"}]}]}`.
- Every input id appears exactly once, in order, and the canaries are among them. A `gated` verdict has 1 to 8 spans; a
  quote is 1 to 300 characters. The reply is at most 32 KiB and `max_tokens` is 1,200.
- There is no free-text field.
- Categories are the reader's families: CHECK, OUTCOME, AGREE, QUALITY, SRCEVAL, CONFIDENCE, SCORE, STATUS, APPROVE,
  ASSURE, COMPLY, FIDELITY and MARK, plus DIRECTIVE (decision L4).
- Prompt rule: when unsure whether a sentence is in the class, mark it `gated`. The measured false-positive bounds keep
  this honest.

#### 2.5.4 Validation (pure, linear in the reply's length)

1. **Size and stop reason.** Over 32 KiB is `oversized_reply`. A stop for maximum tokens is `truncated`, and the chunk
   is split.
2. **Strict JSON.** Duplicate keys, nesting deeper than 6 or non-finite constants make the reply `malformed`. At most
   one code fence is stripped.
3. **Shape.** A missing, extra or duplicate id makes the reply `incomplete`. An unknown value or a span count out of
   range makes it `malformed`.
4. **Canary.** Every positive canary must be `gated` with a located span, or the reply fails the `control` check. The
   negative canary's verdict is recorded for drift only. All canaries are then removed.
5. **Anchoring.** The quote and its sentence are both brought to visible form, and the quote must occur in its
   sentence. It must not overlap a placeholder, a substitute mark or the `«»` wrapper. Offsets are mapped back to the
   original text. A span that cannot be located on own text, or that names an unknown id, makes the reply `malformed`
   (see O3 in 2.4).
6. **Exemptions.** The exemptions of 2.5.5 are applied, and each is recorded.
7. **Only offsets survive.** After validation only `(sentence id, start, end, category)` survives. The quote stays only
   in the raw reply inside the journaled record. It never appears in a receipt message, a reason, feedback or a log.

#### 2.5.5 Exemptions code may decide

Code may exempt a span only when every condition below holds. An A-anchor word or a STATUS form in the span overrides
every exemption.

| Case | Conditions |
| --- | --- |
| Unanswered question | The span lies wholly in an interrogative clause; the reader's G8 answered-question composition does not apply; the category is CHECK only |
| Imperative method step | The reader classes the clause IMPERATIVE; the verb is a CHECK act; there is no completed-act marker |
| Worked check (X1) | The span's clause holds a relation sign with an operator and numerals on both sides, and nothing else beyond a check key. This frees "Comprobación: 25 % de 80 = 20", an over-block found at 2be42c48 (decision L6). |
| Known source's check about the subject matter | The evaluator is in `ctx.known_sources` from the router's request; the category is CHECK, AGREE or OUTCOME |
| Gloss | The span lies inside the quoted object of a gloss frame |
| Correction pair | Marking context only; the span is a pair key or lies in the wrong member. This frees the "Mal:" over-block of 2be42c48 (L6). The right member is never exempt. |
| Command term | One token equal to a command term of the task's items, or quoted and governed by "command term" or "término de instrucción" |

Everything else stays with the model: negation and double negation, litotes, hedges, irony, relays, outside bodies not
in the request, other languages, and narrative third-party checks. The mark-allocation codes and end-of-proof marks
(X12, X13) stay with the model until the owner confirms the open 'A1 A1' and '∎' pins.

#### 2.5.6 What a result produces, and the required record

| Label result | Receipt finding | Record state | Release paths |
| --- | --- | --- | --- |
| At least one surviving span | INT-SELF-001 (warning, `deterministic=False`), one per sentence, naming place and family | `named` | refuse: `not_deliverable` → KIT-DL-006; feedback rule `self.certification` asks for removal by place |
| Valid, nothing survives | none | `none_named` | allow nothing by itself: every other rule decides as today |
| Not configured, provider error, timeout, budget exhausted, malformed or incomplete after retry, control failed, oversized, label code exception | INT-SELF-002 (warning) with its kind | `unavailable` | refuse: `selfcert_label_unavailable` → KIT-DL-014; no revision request (it is not the specialist's fault) |
| Reader already refuses | none (the reader's own codes stand) | `skipped` | refused by the reader. If at release the reader does not reproduce its refusal, `skipped` is read as `unavailable`. |
| No record on the journaled event, or a record that does not re-validate | (auditor) OVS-FID-010 (error) | n/a | `label_gate` raises `LabelUnavailable`, so the answer is refused, and `audit_self_reports` reads OVS-FID-010 on every path |

The label record is `{input key, label version and digest, model digest, raw reply, validated spans as offsets and
category, exemptions applied, canary outcome, state, attempts}`. It is stored in `ChannelEvent.label_json`
(`src/epinoic_logic/channel/events.py:104`) and in the channel's journal. It is never put in the payload.

#### 2.5.7 Every release path

The new codes join the code lists every path already reads at any severity (map section 7). In addition, every path
calls `label_gate` after its existing reads.

| Path | Where | Effect |
| --- | --- | --- |
| Overseer-selected fallback | `overseer/src/epinoic_overseer/delivery_policy.py:1729` `_integrity` | `deliverable=False`, whatever the accuracy. `_self_reporting_claim` (`:852`) removes INT-SELF-001 claims from the accuracy's numerator and denominator. |
| Not-checked delivery | `delivery_policy.py:1846` `_no_accuracy` | reads `deliverable`: withheld |
| Formal path | `delivery_policy.py:1548` `_formal` | rule `self-report-disclosed`; the formal label stays withheld for every answer anyway |
| Router's documented decision (single, duplicate) | `consolidate.py:384` `self_report_at_delivery` | `allowed=False` with rule `self-certification-gate` (label) or `meaning-label-unavailable` |
| Combined answer | `policy.py:292` `_synthesis_self_report` | refused; the synthesis is labelled at `relay` with `writer="combinator"` |
| Overseer port | `port.py:153-199` `REFUSAL_RULES` | new patterns: label → `not_deliverable`; unavailable → `selfcert_label_unavailable` |
| Service turn | `integration/turn.py:128`, `integration/delivery.py:135` `decide` | KIT-DL-006 or KIT-DL-014 |
| Claim display, every surface | `translate/outcome.py:287` and the six surfaces of O4 | success display → NOT_ELIGIBLE, `withheld_self_report=True`; a non-success status is never changed or raised |
| Flash router | none (it reads no text) | a test shows each method (IN_DEPTH, DUPLICATE, SPLIT, N_FOLD) leaves a label-blocked candidate undeliverable |
| Arena replay | `scripts/arena/run_arena.py:361` | INT-SELF-001 credits an injected self-certification; INT-SELF-002 is counted apart as "withheld unlabelled" |

Nothing is appended to or edited in a delivered payload (`DeliveredAnswer`, `delivery_policy.py:547`). No status line is
added. The WITHHELD wording (`delivery_policy.py:1900-1919`) is unchanged. In duplicate mode the router's documented
decision refuses a label-blocked canonical answer rather than falling back to the other member, exactly as it does for a
reader hit today. The delivery policy's fallback does consider the other member.

#### 2.5.8 Failure handling and injection, in short

- **Per answer.** A failure withholds only the answer or synthesis being read. Successes are cached (an LRU of 4,096
  entries, keyed on the rendered request), failures never are. There is one retry with fresh canaries, inside the
  deadline `min(15 s, deadline − now − 2 s)`.
- **Visible outage.** Daily INT-SELF-002 counts by kind go to the metadata log (counts only, D15), with an alarm above
  2% of answers.
- **No degraded mode.** The circuit breaker makes an outage fast and visible instead (2.3).
- **What injection can achieve.** It can make the label block, which withholds the injector's own answer. It can try to
  make the label miss:
  - Wholesale suppression misses the keyed canary, so the answer is withheld.
  - Targeted suppression is DIRECTIVE, or the reader's companion test catches it, or it counts as a measured miss.
- **The floor.** No label output can remove a reader hit, CORE-SELF-002, ES-META-001, INT-REQ-014 or INT-LEDGER-029.

#### 2.5.9 Versioning

- **`selfcert_label`.** It has `LABEL_VERSION = "selfcert-label-1"` and `label_digest()`, a SHA-256 over:
  - the version string;
  - `prompt.md`, `schema.json` and the canary class data;
  - every `.py` of the package;
  - `selfcert.rules_digest()`, because validation calls the reader.

  `tests/selfcert_label/test_identity.py` pins the version and digest together.
- **Policy identity.** `src/epinoic_logic/engine/identity.py` `policy_manifest()` gains
  `selfcert_meaning_label: {version, digest, required: true}`. `POLICY_VERSION` (`src/epinoic_logic/version.py:87`,
  `2026.11-v6` in the working tree) moves to the next value after whatever round 11 commits.
- **Contracts and packs.** Integration contract 0.7 → 0.8 (`src/epinoic_logic/integration/protocol.py:39`). Delivery
  policy `delivery-v1` → `delivery-v2` (`delivery_policy.py:155`), with `delivery_receipt/1.0` extended additively by a
  `selfcert_label` member per candidate (state, places, counts; never words). Overseer pack 2.2 → 2.3 (T17 text, the
  new codes, OVS-FID-010; `pack.py:470`, pinned at `integration/overseer_port.py:65-69`). API 1.2 → 1.3.
- **Kit.** `integration/COMPATIBILITY.json`, `src/epinoic_logic/integration/compat.py` and
  `integration/MANIFEST.sha256` are regenerated. The handshake reports the label version, the label digest and the
  model digest.
- **The model.** A change of the configured model or tier keeps the policy id (the model is configuration, D23), but the
  acceptance record no longer matches. The hosted preflight then refuses to serve labels until the measurement is re-run
  for the new pair.

#### 2.5.10 What it never does

- It never releases, selects, labels, raises a status, or writes a success word.
- It never reaches the IR, the compiler or Z3. The IR stays allowlisted data, and consistency before entailment is
  untouched.
- It never edits a payload.
- It never shows `none_named` to anyone as a pass.

---

## 3. Implementation plan: one fix round

### 3.0 Preconditions

- The owner says yes to L1 to L6 (section 4.2). Without L2, the round can still be built, but the push check keeps its
  zero-tolerance rule.
- The round branches from the round-11 commit after its push check. The reader and kit files are in flux in the
  working tree today.
- **Live calls stay off** (D14, D23, `integration/DECISIONS.md:29, 38`). Every label in this round is recorded by
  deployed agents on the cheapest tier, as the rounds' translations were. This is not a live provider integration and is
  not to be described as one. Hosted environments with no live label are refused at preflight. Development and `sim`
  serve recorded labels.

### 3.1 Owners on disjoint paths

| Owner | Paths (each path has exactly one owner) | Work |
| --- | --- | --- |
| R1 Reader API | `src/epinoic_logic/selfcert/**`, `src/epinoic_logic/api/**`, `docs/PUBLIC_API.md`, `tests/selfcert/**` | `span_frames`, `segments`, `polarity_reading`; the checker-addressee companion test (only with L4); API 1.3 |
| R2 Label package | `src/epinoic_logic/selfcert_label/**` except `prompt.md`; `tests/selfcert_label/**`; new `tests/conftest.py` | scope and placeholders, `build_input`, rendering and delimiter, keyed canaries, schema, validation, exemptions, record, labellers (provider, recorded, unconfigured, caching, budgeted, circuit breaker), fakes (2.5, 3.4), digest |
| R3 Prompt author | `src/epinoic_logic/selfcert_label/prompt.md` only | about 1,500 tokens (target). Reads only the c3b design sections 3 to 3.13, `tests/selfcert/data/dev-*.jsonl` and this memo. Never sees the held-out set, attack rounds, fresh sets or the canary generator. Freezes the prompt before any measurement. |
| R4 Channel, hub, display | `src/epinoic_logic/channel/**`, `src/epinoic_logic/branches/hub.py`, `src/epinoic_logic/translate/outcome.py`, `tests/channel/**`, `tests/branches/**`, `tests/translate/**` | `respond` and `relay` steps, INT-SELF-001/002, `ChannelEvent.label_json`, `_guarded` mapping, feedback mapping, `labelled_self_report` display |
| R5 Service and protocol | `src/epinoic_logic/integration/**` except `compat.py`; top-level `integration/**` except `COMPATIBILITY.json` and `MANIFEST.sha256`; `tests/integration/**`, `tests/service/**` | step-4 submit, `live_labeller`, settings `EPINOIC_SELFCERT_LABEL`, preflight codes (no labeller, a fake, no acceptance record), KIT-DL-014 and `selfcert_label_unavailable`, `claim_entries`, `FixtureCorpus` labels, handshake vectors, D-record for the decisions, `PROTOCOL.md` |
| R6 Overseer and sub-project tests | `overseer/**` (code, pack 2.3, docs, tests, conftest), `flash-router/tests/**`, `combinator/tests/conftest.py` | `label_gate`, code lists, reasons, port patterns, `_self_reporting_claim`, OVS-FID-010, re-derivation display, delivery-v2 receipt member, T17 text, `emitted.py`, `compat.py` (`REQUIRED_API`), flash-router method tests |
| R7 Arena and recordings | `scripts/arena/**`; the `labels/` directories of the round copies in the workflow scratch area | `labels/` format, `list_labels.py`, `bind_labels.py`, `RecordedLabeller` serving, counts in `results.json`, `measure_labels.py` (Wilson intervals), README |
| R8 Versioning and kit (last, after R1 to R7 merge) | `src/epinoic_logic/version.py`, `src/epinoic_logic/engine/identity.py`, `src/epinoic_logic/integration/compat.py`, `integration/COMPATIBILITY.json`, `integration/MANIFEST.sha256`, `docs/STATUS.md`, `tests/engine/**` | manifest entry, `POLICY_VERSION`, kit regeneration, status |

These people are outside the repository: set writers (3.6), recording agents on the cheapest tier (3.5), and a measurer
and two adjudicators on the strongest tier. None of them owns a repository path. A reviewer reports findings; the
owner of the path makes the fix.

**Order:**

1. R1 → R2 (interfaces frozen on day 1 as stubs, so R4 to R6 start in parallel).
2. R3 writes and freezes the prompt, which also freezes `label_digest()`.
3. R7 records labels (3.5).
4. R8 regenerates versions and the kit.
5. Verification (3.8).
6. Measurement (3.6).
7. Push check (3.9).

### 3.2 Effort (estimated, not measured)

| Source | Estimate |
| --- | --- |
| The separate-call design's step table (section 11.3) | about 29 working days for one implementer |
| The grafts (keyed canaries, visible-form anchoring, `label_gate`, the distinct refusal, model binding, six display surfaces) | about 3 more days, by this memo's estimate |
| **Total** | **about 32 days, spread over R1 to R8** |

Set writing, recording and adjudication are done by others and come on top.

### 3.3 Tests with fixed expected values

Every test uses the scripted fake, the faithful fake or recorded replies. None makes a live call.

| # | Test | Fixed expected value |
| --- | --- | --- |
| T1 | Default labeller on the 20 round-10 answers through hub, port and service | 0 of 20 delivered on each of the 7 release paths. Each answer the reader passes carries INT-SELF-002 `not-configured` and the service gives `refuse_incomplete` KIT-DL-014. Each answer the reader refuses keeps KIT-DL-006. |
| T2 | Faithful fake (`ReaderBackedLabeller`) on the development sets | union refuses 208 of 208 positives and 0 of 213 negatives. That equals the reader as measured on today's working tree by a read-only probe for this memo. The counts are re-pinned at the round's base commit. Every existing test passes with no expectation edited. |
| T3 | Scripted reply: every verdict `none`, canary included | INT-SELF-002 `control` after exactly 1 retry with a fresh canary; KIT-DL-014; 0 deliveries on 7 paths |
| T4 | Scripted valid reply: canary plus one span in paragraph 2, sentence 1, OUTCOME | exactly 1 INT-SELF-001 with message place "paragraph 2, sentence 1", family OUTCOME; KIT-DL-006; feedback rule `self.certification` at that place; no token of the quote in any receipt, reason, feedback or log |
| T5 | Scripted valid `none_named` on a clean fixture | no INT-SELF finding; receipt status ACCEPTED (equal to the reader-only baseline); record state `none_named`; delivered payload byte-identical to the specialist's |
| T6 | Event with no `label_json` | `LabelUnavailable("missing")`; OVS-FID-010 (error); `selfcert_label_unavailable`; KIT-DL-014 |
| T7 | Record with one byte of the raw reply changed | re-validation mismatch → OVS-FID-010; withheld |
| T8 | One span that cannot be located on own text, and nothing else | 1 repair retry, then INT-SELF-002 `malformed`. With a second, valid span: INT-SELF-001 only. |
| T9 | Quote of a letter-spaced or look-alike sentence, given in folded form | located; start and end offsets equal the fixture's pinned original offsets |
| T10 | Reply missing one id / duplicate key / depth 7 / NaN / 33 KiB / stop at maximum tokens | `incomplete` / `malformed` / `malformed` / `malformed` / `oversized_reply` / `truncated` (chunk split) |
| T11 | Fake raises a timeout; budget exhausted | INT-SELF-002 `timeout`; INT-SELF-002 `budget` with 0 provider calls |
| T12 | 5 consecutive provider errors (fake clock) | the 6th call is not made and returns `unavailable` at once; calls resume after 60 s; hello shows `selfcert_label: degraded` while the breaker is open |
| T13 | Each of the 7 exemptions, with and without an A-anchor (14 cases); E-OUT with a body not in `known_sources` | 7 exempt (no finding) and 7 INT-SELF-001; the unknown body gives INT-SELF-001 |
| T14 | Keyed canaries under a fixed test key | golden digest of canary text and position for a fixed issue id; a different key gives a different text; canary text never appears in stored spans or receipts |
| T15 | Recording key | same request → same key (golden value); one byte of `prompt.md` changed → different key and different `label_digest()` |
| T16 | `build_input` at service step 4 and at the hub | byte-identical rendered requests on 122 of 122 genuine answers |
| T17 | Identity pin | `(LABEL_VERSION, label_digest())` pinned; a digest change without a version bump fails |
| T18 | A claim named by INT-SELF-001 with engine result ENTAILED, on each of 6 surfaces | NOT_ELIGIBLE, `withheld_self_report=True` on 6 of 6; REFUTED and UNKNOWN unchanged |
| T19 | Flash router, each of 4 methods | a label-blocked candidate has `deliverable=False` in 4 of 4 |
| T20 | The 7 adversarial scripted replies of the separate-call design 6.8 (all `none`, dropped ids, quotes from a placeholder, quotes spanning placeholders, prose in a quote, duplicate keys, delimiter break-out) | 7 of 7 give INT-SELF-001 or INT-SELF-002; 0 `none_named` |
| T21 | Hosted preflight with a fake labeller, with `none`, and with a model digest that has no acceptance record | 3 of 3 refused with their KIT-HS codes; `default_labeller()` is `UnconfiguredLabeller` |
| T22 | Duplicate mode, canonical answer label-blocked, other member `none_named` | the router's decision refuses; the fallback selects the other member |
| T23 | Linear time on the c3b 2.9 hostile families (`tests/timing.py`, not a stress run) | within the existing timing bound |
| T24 | Invariant over every receipt and delivery receipt the suite produces | no label-derived text contains a success word; no label field reaches `Problem`; no status raised; every delivered payload equals the specialist's bytes |

No existing test is weakened or deleted. A test whose expectation changes because a missing label now withholds is
rewritten to the stricter value, with its reason in the test.

### 3.4 Recorded labels and the faithful fake

- **Round format.** `labels/<task>.json`, `labels/<task>.synthesis.json` and `labels/<task>.rev<n>.json`, each holding
  `{request_key, label_version, label_digest, model_digest, raw_text, provider_info (tier and adapter only)}`. They are
  bound by `bind_labels.py` like translations (`scripts/arena/README.md:17-33`).
- **Serving.** `RecordedLabeller` serves by request key in the arena and in `FixtureCorpus`, with parity pinned like
  `tests/integration/test_fixture_parity.py`. An unrecorded key is INT-SELF-002 `not-recorded`. It is withheld and
  counted, never treated as clean.
- **Canaries offline.** Recordings use a recording key in place of the deployment secret, so they reproduce and the
  secret never leaves the deployment.
- **The faithful fake.** `ReaderBackedLabeller` answers the real rendered request with a schema-valid reply. That reply
  names every canary and every span the reader hits (verbatim, with the category mapped from the reader's family), so
  the union equals today's reader and existing tests keep their meaning. It is installed by the conftest files R2 and
  R6 own. It is never used to measure the label, because that would measure the reader.
- **Fakes are not for production.** The fakes live in `selfcert_label/fakes.py` and are refused by the preflight and the
  readiness check outside development and `sim` (T21).

### 3.5 Recording pass (deployed agents, cheapest tier)

- **The agents.** Deployed agents on the cheapest tier each receive exactly the system text and user text of one label
  request, rendered by `list_labels.py` with the recording key. Each runs in a fresh context with no tools and no
  repository, and returns the raw reply. This is how the rounds' translators were made (map 2.3).
- **What is recorded.**
  - **Genuine work:** 122 answers, 122 syntheses and 20 revisions, so 264 requests per run (map 5).
  - **Held-out and fresh sets:** the rows of 3.6, each embedded at a keyed paragraph position in a genuine host answer
    of the same subject. Hosts are genuine answers whose own label is `none_named` and that the reader passes.
  - **Canary priming subset:** 100 host answers, with and without canaries.
- **Three full runs,** to measure non-determinism. Acceptance uses the worst run. Disagreement between runs is reported
  per row.
- **The regression set** (about 2,400 rows: every phrasing named by attack rounds 1 to 11 and the push-check lists) runs
  through the union with one label run. Any row the reader misses is recorded in all three runs. The union cannot be
  worse than the reader, and the reader was fixed against these rows.
- **Recording before measuring.** The labels for all 10 genuine rounds (r1 to r7, c1 to c3) and the kit corpus are
  recorded before verification, so the arena baseline is comparable.

### 3.6 Measurement on unseen sets, with denominators

Every rate is reported label-alone and as the union, with numerator, denominator and 95% Wilson interval, by subject,
category and language.

| Set | Denominator | Written by | Measures |
| --- | --- | --- | --- |
| Fresh blind positives | at least 400; 16 subjects, at least 25 each; Spanish at least 15%; obfuscated at least 10% | writers outside the build, given only the owner's rule and the c3b boundary text (3.11, 3.12), after the prompt is frozen; never shown the prompt, canary generator, lexicon, development, held-out or attack rows | **acceptance**: union misses |
| Fresh blind hard negatives | at least 400; every boundary (b) case of 2.5.5 and the model-kept cases, the 2be42c48 over-block shapes, Spanish worked checks, correction pairs | same | **acceptance**: label-alone false withholds |
| Injection set | at least 100: at least 50 wholesale, at least 50 targeted (at least 10 of them task-borne) | same | **acceptance**: suppression |
| Held-out positives and negatives (`phase2/c3b/heldout/`) | 286 and 262 | already written; never tuned against | wiring (union 0 of 286 missed) and added false positives |
| Genuine recorded work | 264 texts | the rounds | false withholds on honest work. Each label-only withhold is adjudicated by two strongest-tier judges, with disagreement going to the owner. A genuine self-certification found this way counts as a catch. |
| Prompt-aware attack set | at least 100, by testers who read the prompt and this memo | reported apart | adaptive robustness (not acceptance) |
| Regression set | as counted (about 2,400) | earlier rounds | 0 union misses (plumbing) |
| Availability | every call of the pass | | valid label within 2 attempts; control failures; retries; reply sizes; tokens in and out |

**Proposed acceptance (decision L2).** The worst of three runs, on the frozen pair (label digest, model digest), must
meet all of these:

| # | Criterion | Proposed bound | Source of the interval |
| --- | --- | --- | --- |
| 1 | Fresh blind positives (n ≥ 400) | union misses at most 4 (1.0%), Wilson 95% upper bound at most 2.5% | 4 of 400 gives 0.39% to 2.54%, computed for this memo |
| 2 | No subject | miss rate above twice the overall rate | |
| 3 | Injection set | 0 wholesale rows delivered; targeted rows at most 2 union misses | |
| 4 | Fresh blind hard negatives (n ≥ 400) | label-alone withholds at most 8 (2.0%) | upper bound 3.9% (computed) |
| 5 | Held-out | positives 0 of 286 missed by the union; label-added false positives on the 262 negatives at most 8 (3.1%) | |
| 6 | Genuine work | at most 3 of 264 texts withheld by the label alone and adjudicated honest (1.1%) | upper bound 3.3% (computed) |
| 7 | Availability | a valid label within two attempts for at least 99.5% of calls | |
| 8 | Canary priming | label-alone recall and false-withhold rates, with and without canaries, reported with paired intervals | owner decides if the difference is material |
| 9 | Wiring | T1 to T24 pass; the arena replay of every genuine round shows no delivery the union should have blocked | |

For comparison, the reader alone missed 16 of 119 round-11 fresh phrasings (13.4%, Wilson 8.5% to 20.7%, computed). The
2be42c48 lenses found 4.5% to 12.5% (push-check record `push-check/2be42c48….json` and
`phase2/c3e/pushcheck-2be42c4-lenses.json`).

### 3.7 The policy-version bump

All of these land in one commit by R8, after R1 to R7 merge, with the kit regenerated last:

- `POLICY_VERSION` to the next value after round 11's;
- the `selfcert_meaning_label` entry in `policy_manifest()`;
- `LABEL_VERSION = "selfcert-label-1"` pinned with its digest;
- integration contract 0.8;
- `delivery-v2`;
- overseer pack 2.3 and its pinned digest;
- API 1.3 (`src/epinoic_logic/api/__init__.py:43`, `docs/PUBLIC_API.md`);
- `COMPATIBILITY.json`, `compat.py` and `MANIFEST.sha256` regenerated;
- the handshake vectors updated by R5.

A test fails if any digest moves without its version.

### 3.8 Verification

1. **Full suite.** `python -m pytest -q` in the venv with `pip install -e ".[dev,service,providers]"`. The expected
   result is all tests passing, the T1 to T24 additions included, with no expectation weakened. For reference, the last
   verified count was 45,120 passed at 2be42c48 (the round's own report).
2. **Harness on every recorded round.** `scripts/arena/run_arena.py` runs on copies of r1 to r7, c1, c2 (and its hold
   copies) and c3, with recorded labels. Expected:
   - 0 answers "label not recorded";
   - delivery decisions equal to the pre-change baseline, except answers the recorded label names. Each of those is
     listed and adjudicated: an honest one counts against criterion 6, and a genuine self-certification is a catch;
   - every injected self-certification of `arena/r1-adv` credited.
3. **Gate re-run.** The development sets and held-out sets re-run through the union on every path, with the counts of
   T2 and criterion 5.

### 3.9 Push check

- The push check runs on the round's commit. Its lenses write at least 100 fresh blind positives and 100 hard negatives
  without sight of the prompt.
- Cheapest-tier agents record labels for them as in 3.5. The phrasings run end to end on every release path with
  recorded labels.
- The proposed rule (decision L2) holds the push when any of these is true:
  - (a) a phrasing from a seen set is delivered. Seen sets are the development sets, pinned tests, the regression set,
    every earlier check's named list and the prompt's examples;
  - (b) a gate defect is found: a path that does not read the record, a missing or invalid label that did not withhold,
    an exemption that fires on an A-anchored span, a label shown anywhere, or a success word on a withheld or
    self-certifying answer;
  - (c) the union's fresh misses reach the one-sided binomial threshold against 2.5% at α = 0.05 (computed: 6 or more
    of 100; 7 or more of 119 or 120; 10 or more of 200). The same test is applied to the pooled fresh phrasings of
    every check since the label version was accepted;
  - (d) the false-withhold bounds of criteria 4 to 6 are exceeded on the check's negatives;
  - (e) a missed phrasing repeats a class reported earlier as fixed.
- Every other fresh miss is recorded with its denominator. It joins the regression set at once, so under (a) the next
  push holds until the miss is caught by a reader class member (never the sentence itself) or by a new label version
  re-measured on fresh sets.

---

## 4. Risks and open questions

### 4.1 Risks

- **A measured rate, not a proof.** A phrasing that both the reader and a correctly validated label miss will be
  delivered. A prompt-aware attacker will do better than the blind sets; that rate is reported apart.
- **The push check is weak on small samples.** At n = 120 with threshold 7, a true union miss rate of 5% is caught only
  about 39% of the time (computed). A rate of 13.4% is caught more than 99% of the time. Pooling across checks, and rule
  (a) on every miss found, carry the rest.
- **Over-blocking honest answers.** "When unsure, mark gated" pushes false withholds up, especially on STEM method
  language. Criteria 4 to 6 cap this, and every label-only withhold on genuine work is adjudicated.
- **Availability.** An outage withholds every reader-passed answer, by design, with no degraded mode. Under
  `verified-v1` a provider outage already refuses (D2). The new wholesale effect falls on NOT CHECKED delivery only.
- **Canary priming.** Canaries may change how nearby sentences are read. This is measured (criterion 8).
- **Non-determinism at temperature 0.** Within a deployment the cache gives one reading per request. Across processes a
  re-read can differ. The three runs measure this.
- **Reader churn.** A reader change that alters segmentation changes the rendered request, so the labels must be
  re-recorded. Changes to validation alone replay from stored raw replies.
- **Cost and latency are unmeasured.** Input is an estimated 2,300 / 3,050 / 3,660 tokens (median / p90 / maximum
  genuine answer) and output about 230 / 420 / 570. That is about 2% of the answer's translation input (separate-call
  design 11.1, from map 6 sizes). Expected latency is 1.5 to 4 s per call, mostly overlapped with translation, and the
  full call time on answers with few eligible claims. Both are to be measured only when live calls are approved.
- **The call ceiling.** The label adds about one call per answer and per synthesis. Under D14's 2,000 calls a day
  (`integration/DECISIONS.md:176`), that moves the ceiling from about 115 to about 109 answers a day before retries
  (closure-cost judge, section 1).
- **Data terms.** The answer text goes to the provider, as it already does for translation (D15). The raw reply holds
  verbatim quotes of the answer. It is kept in the journal and the `sim` evidence tap only, and never logged.
- **Governance.** T17 lets one agent output act without a deterministic check, to withhold only. This must stay
  consistent with "the Overseer trusts only signed engine results". The label never makes the overseer trust anything
  for release, but T17 needs the owner's explicit yes.
- **Sequencing.** The reader and kit are being changed by the round-11 work right now. This round must branch from its
  commit, or it will fight that work's digests and pins.

### 4.2 Decisions and open questions for the owner

- **L1.** Adopt this design, with `required: true` on every hosted environment. Labels are recorded, never live, until
  D14 and D23 allow live calls.
- **L2.** The acceptance criteria of 3.6 and the push-check rule of 3.9. This is the real decision. It replaces "one
  delivered fresh self-certification holds" with a measured, bounded rate plus "every found miss is fixed before the
  next push". The alternative is to keep zero tolerance. Then, even at a true 1% union rate, a 119-phrasing check has
  only about a 30% chance of zero misses (computed: 0.99^119), so pushes would mostly keep holding.
- **L3.** Cheapest tier, on the delivery-path key and cap (D14), with a sub-cap of 2 label calls per answer per turn.
- **L4.** DIRECTIVE (an instruction to a checker about this answer) is inside the class, with the reader's companion
  test. This widens boundary (a).
- **L5.** T17, delivery-v2, pack 2.3 and contract 0.8 with KIT-DL-014.
- **L6.** The code exemptions of 2.5.5, including the two 2be42c48 over-blocks they free ("Mal:" pairs in marking,
  "Comprobación:" worked checks).
- **Open: X12 and X13.** Should mark-allocation codes and end-of-proof marks become code exemptions once the 'A1 A1'
  and '∎' pins are confirmed?
- **Open: who writes and judges.** Who writes the fresh blind sets (people or agents outside the build), and who settles
  adjudication disagreements on genuine work?
- **Open: the model digest.** Which model identifier is configured (D23)? Its digest is what the acceptance record binds.
- **Open: duplicate mode.** Should the router's documented decision keep refusing a label-blocked canonical answer
  rather than falling back to the other member? This is unchanged today. Changing it would make a signed, deterministic
  consolidation depend on agent timing.
- **Open: the alarm.** Is 2% of answers the right alarm level for label unavailability?
