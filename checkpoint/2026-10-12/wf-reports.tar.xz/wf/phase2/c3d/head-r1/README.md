# Epinoic AI — Logic Translator and Z3 Verification Engine

Proprietary. See `LICENSE` and `THIRD_PARTY_NOTICES.md`. Status of every component
(planned / implemented / tested / deployed) is in `docs/STATUS.md`. Nothing in this
repository is deployed.

The integrated prototype as it stands after arena round 8 and its fixes (what it is, how to install, test, serve and
replay it, what round 8 measured lens by lens, and what is not yet shown) is described from measured results in
[`docs/PROTOTYPE.md`](docs/PROTOTYPE.md).

## What this program does, in plain language

Epinoic AI's tutor is a set of subject-specialist agents (English, Mathematics,
Physics, Economics, History and so on) that write structured answers for
International Baccalaureate students. Language models can state things confidently
that do not follow from the evidence, invent quotations, or contradict themselves.
This program makes those failures **visible and checkable** without pretending to
judge whether an interpretation is "true".

It does three separate things and never blurs them:

1. **Structural checks (deterministic code).** Is the specialist's report well
   formed, are its claim ids stable, is the original text unchanged (hash), and does
   every quotation it cites actually occur, word for word, in the text the student
   supplied? Invented quotations and invented line citations are flagged here.
2. **Translation (model-proposed, code-validated).** For claims that *can* be
   formalized, a model proposes a small typed logic problem: the atomic propositions
   the specialist relied on, where each one is grounded (a quotation, a task setting,
   an inference the specialist made, an outright assumption), the inferential links
   the specialist asserted, and the point being argued. The proposal is **data**: it
   is parsed strictly, validated against a closed schema, and never executed.
3. **Formal verification (Z3).** The engine checks whether the premises are
   consistent, and if so whether they entail the point. It reports exactly which
   premises the proof relied on and which of those are unverified inferences or
   assumptions. If the point does not follow, it shows a concrete counterexample. If
   the premises contradict each other, it names the conflicting ones.

A verified result therefore says: *given these encoded premises, under this
configuration, this conclusion does or does not follow*. It never says the premises
are factually true, that the translation captured the claim faithfully, or that a
literary or historical reading is correct. Every result carries that scope
statement. This is deliberate: the system is not a universal hallucination
detector; it is an auditable way to show what was checked, how, under which
assumptions, and what remains uncertain.

## The primary feature: every message between agents goes through the translator

The translator is a **branching infrastructure**: one hub that every specialist
(English, History, Psychology, Economics, Business Management, and any subject
added later) communicates with the primary router through, and one branch per
subject carrying an **integrity pack** of subject-specific checks. The hub integrity
(envelopes, hand-off, request fidelity, claim ledger, staleness, cross-agent
consistency, signing) is shared; the packs add what each subject's knowledge
documents demand, such as quotation integrity for literature, chronology and dated
figures for history, study attributions for psychology, elasticity arithmetic for
economics and margins for business. See `src/epinoic_logic/branches/README.md`.

STEM subjects (Physics, Chemistry, Biology, ESS, SEHS, Design Technology, Mathematics AA and AI,
Computer Science) are three more branches of the same hub: `sciences`, `mathematics` and
`computer_science` (`docs/STEM_DESIGN.md`). A deterministic front end (`src/epinoic_logic/stem/`)
reads answers that mix equations and prose in LaTeX, Unicode, ASCII and words, without evaluating
any text, and turns every relation it recognises into an IR problem the engine decides (written
arithmetic, substitutions, unit conversions, algebra steps, stated roots, balances, Boolean
identities, based numerals) under a documented tolerance rule, or names it undecided with the
reason. A wrong step such as `a = (20 - 0)/4.0 = 6.0 m s⁻²` reaches the router as an INT-SUBJ-001
error naming the claim, with the engine's computed and stated values; correct work is never an
error. A STEM check proves a property of its encoding only: that the written arithmetic, step or
balance holds or does not under the stated premises and readings, never that a law applies, that
data are true or that a model is physically valid.

Agents do not pass raw text to each other. The `channel` package
(`src/epinoic_logic/channel/`) sits on the communication path. When the router sends
a student's request to a specialist, the request is made explicit (what is asked,
word and paragraph limits, which texts may be used) and wrapped in a hashed envelope.
When the specialist answers, the response must reply to that exact request and is
checked before the router sees it: right task and agent, no replay or tampering,
quotations found in the supplied texts, numeric constraints decided by the engine as
signed results, eligible claims verified, items of the request covered, and
contradictions with claims already transmitted by other agents named. The router
receives the report together with a receipt, or a rejection and no report. The same
channel carries agent-to-agent transmissions, such as the English specialist's output
reaching the combinator, with the claim ledger checked on the way. See
`channel/README.md` and `integrity/README.md`.

Integrity properties the channel holds on every transmission and relay:

- The envelope's sender is bound to the payload's owner: a specialist cannot relay a colleague's report, or a copy of it, under its own name (INT-ENV-008).
- A report the router already holds is never overwritten: a report id re-delivered with a different payload is refused and the first delivery kept (INT-HANDOFF-015).
- A response that merely echoes the request is named as such and counts for no request item (INT-REQ-011).
- A quotation whose words occur in the supplied text but whose form differs (initial capital, a verse line break written " / ", a long elision, accents such as 'Román' for 'Roman') is a warning, never an invented quotation (INT-REQ-010).
- A quotation credited to one source but found only in another supplied text, a peer specialist's report included, is a wrong attribution and is named with both texts (CORE-SRC-005, ES-SRC-008).
- A synthesis carrying a value outside the synthesis contract's closed vocabularies, such as a transformation written as a description of the edit instead of one of `carried`, `paraphrased`, `merged`, `narrowed`, `generalized`, is REJECTED with INT-REQ-009 and INT-SYNTH-014 naming the claims, whether it arrives as JSON or as an object built around validation; it is never delivered with the ledger rules those values select skipped, and never an exception (`integrity.contracts.TRANSFORMATION_MEANINGS`).
- A report or synthesis object carrying None in a field that has a default but is not Optional (a transformation, a certainty, a ledger) is REJECTED with INT-REQ-009 (and INT-SYNTH-014 for a closed vocabulary), never delivered with the default the recipient would read; every check runs on the payload as delivered (integration gate 2); the payload as delivered is re-validated before any identity, party or id-reuse check reads it, so an object built around validation whose identity fields are missing, None or unhashable is REJECTED with INT-REQ-009 and nothing raises, and a subclass whose dump names another combinator is checked as delivered (INT-ENV-008, INT-HANDOFF-002; integration gate 3).

## STEM subjects: equations and prose (`src/epinoic_logic/stem/`)

STEM specialists write a mix of equations and prose: given values, a law, a substitution, a
result with its unit and a sentence of explanation, in LaTeX, Unicode, ASCII or words. The
STEM branches carry that mix across the hub the same way the English and History branches carry
prose. They are three more branches of the same hub, channel and integrity layer, not a
separate system. Design: `docs/STEM_DESIGN.md`. Measured results: `docs/STEM_RESULTS.md`.

What the STEM branches do:

- **Route.** Physics, Chemistry, Biology, ESS, SEHS, Design Technology and general science go to
  `sciences`; Mathematics AA, AI and an unspecified course to `mathematics`; Computer Science to
  `computer_science`. Geography goes to `geography`; Language B and ab initio courses to `language_b` (Spanish
  readers; decision D35). An unrecognised subject still goes to `generic`.
- **Read, never evaluate.** A deterministic front end (a single-pass lexer and a bounded Pratt
  parser over a closed grammar) reads the answer into one shared document: statements,
  formulas, symbol bindings with their source, and every relation stated. No agent text is
  evaluated: no `eval`, `exec`, `compile`, `sympify`, `parse_expr` or any library that evaluates
  strings, and three AST scans in the tests enforce it. Claims are offset substrings of the
  answer (`s1.2`; `m1.2` in Mathematics, `c1.2` in Computer Science; when another agent's report on the task
  already holds those ids, as a second specialist of the same branch would, the ids are qualified with the agent,
  `s1.2@ess-specialist`, so no two reports on one task share a claim id; the History and English parsers do the same
  since integration gate 3, `p1-point@english-a-lang-lit-specialist` beside an English A: Literature report, and the
  generic parser always qualifies), and the router receives the answer verbatim.
- **Decide what can be decided.** Every relation the front end recognises becomes an IR 1.0
  problem the Z3 engine decides, or is named undecided with the reason, or is recorded as a
  binding, a law or a premise-free context line. Nothing recognised is dropped silently. The
  checks:

  | Check | What the engine decides |
  | --- | --- |
  | `stem-eq` | written arithmetic, `E = S` |
  | `stem-sub` | substituted values against the bindings of their symbols; a symbol reused in a part with a value the request states that the part's question and working do not name (warning) |
  | `stem-alg` | an algebra step follows from the line before it; an identity (a derivative or an antiderivative of a polynomial, a definite integral's evaluation bracket, a Given function against the request's, a factorisation) holds for every value of its variable |
  | `stem-sol` | stated roots satisfy the equation, and the full set when it is claimed; a root may be a decimal the answer states in prose for the quantity it named by the symbol ("Let $M$ be the monthly payment" … "Her monthly payment is €352.19") |
  | `stem-mod` | an exponential model evaluated at an argument (`P(t + 4) = P₀e^(k(t + 1))` after the request's `P = P₀e^(kt)`): some value of the variables, and of the stated symbols within their values, must satisfy it; every power of an exponent in symbols is read through positive variables, so only "no value satisfies it" decides; no algebra step is read over an application of a letter the text defines as a function (`N(10) = 200`, then `N(15) = 100`) |
  | `stem-cnv` | an explicit unit conversion |
  | `stem-cmp` | a stated order or inequality, or an inequality step |
  | `stem-res` | a result restated in prose against the chain's final value (with a rounding the prose states, or after ", so", an approximation word or a rounding verb on its line); the value a named change starts from against the value stated for that quantity (warning) |
  | `stem-giv` | a Given value, written with "=" or in a Given statement's prose ("Data: emf 15 V, …"), against the request, a quantity it names in words included; a value the prose takes from a supplied table against the table's cells (warning) |
  | `stem-tgt` | a show-that answer's final value against the request's target (warning) |
  | `stem-chem` | element and charge balance of a chemical equation |
  | `stem-bool` | a Boolean identity, or an expression evaluated under the values the answer gives (AND, OR, NOT, XOR and the gates NAND, NOR, XNOR) |
  | `stem-tt` | the stated rows of a truth table |
  | `stem-base` | a conversion between number bases, a numeral with letter digits read in base 16 where the words beside it name that base |

  A stated value passes when it lies within `h + τ·|C|` of the value `C` computed from the
  written expression: `h` is half a unit in the stated value's last digit (the trailing zeros of
  a whole number count only up to the operands' significant figures), plus `C`'s own half-width
  when `C` is itself a stated value (a conversion, a substitution, a restatement); `τ` is 1/20
  for `≈` or "about" whatever the check but a restated result (no τ), else 1/100 for `=` in written arithmetic and 0 for
  conversions, comparisons, substitutions, restatements and exact work; rounded intermediates,
  data-booklet constants, function values and irrational powers of written figures
  (`10^(−8.2)`; a rational one such as `16^(3/4) = 8` is exact, and so is an integer power beyond 12
  whose value fits one literal, such as `2^{20}`, while `(1 + 0.065/12)^{-60}` is enclosed) range
  over their rounding or enclosure intervals. The band is computed inside the IR, so the engine, not
  Python, decides whether a value lies in it. A calculation with no unit stated in a unit is read
  as written and in SI (`20 × 25 = 0.5 km` holds), except a lone power of ten stated as a
  concentration (`[H⁺] = 10^(−8.2) = 6.31 × 10⁻⁹ mol dm⁻³`), which is the concentration in mol dm⁻³
  the pH scale is defined in: read as a bare number in SI it would accept an exponent 3 too small.
  Units may be written with Unicode or caret exponents or in ASCII glued to the atom (`m s-1`,
  `mol dm-3`, `cm3`, `m/s2`). Since round 8's clearance (`docs/STEM_DESIGN.md` section 39) a decimal cut by an ellipsis
  (`0.309017…`, `16 379.41\ldots`) is one value whose half-width is a whole unit in its last written digit, a symbolic step
  reads the answer's own definitions with a cancelled factor non-zero, a wrong value stated for a booklet constant and a
  wrong mole ratio are named (warnings), and a relation a bidirectional control reaches is decided in neither order; the
  channel refuses any specialist response that holds such a control (INT-REQ-009, rule bidi-text).
- **Name every fault it can see, and never flag correct work as an error.** An error comes only
  from an engine result about a relation that rests on what the answer and the request state.
  Anything that depends on a reading the answer did not state (a booklet value for an unstated
  symbol, a symbol's identity across request and answer, a show-that target, an unknown unit)
  can only be a warning. Ambiguous notation becomes alternative readings or a warning, never an
  error.

**A worked step translated into an engine problem.** Before STEM support this answer crossed the
hub ACCEPTED with no finding and no check (the true acceleration is 5.0 m s⁻²):

```
request  A trolley accelerates uniformly from rest to 20 m s⁻¹ in 4.0 s. Calculate its acceleration.
answer   The trolley starts from rest, so u = 0. Using a = Δv/Δt, a = (20 - 0)/4.0 = 6.0 m s⁻².
         The acceleration is therefore 6.0 m s⁻².

claims   s1.1  evidence      "The trolley starts from rest, so u = 0."          u = 0: a binding
         s1.2  quantitative  "Using a = Δv/Δt, a = (20 - 0)/4.0 = 6.0 m s⁻²."   a = Δv/Δt: a law, recorded
                                                                           (20 - 0)/4.0 = 6.0: check stem-eq-1
         s1.3  quantitative  "The acceleration is therefore 6.0 m s⁻²."      restatement: check stem-res-1
```

`stem-eq-1` is this IR problem (shown in a compact notation; the problem itself is JSON data,
validated against the closed IR schema):

```
problem  stem-eq-r1-1   query: entailment   policy: linear   expected: ENTAILED
symbols  c : Real    the computed value (as written)
         r : Real    the stated value (as written)
premise  C_DEF   c = 20 / 4        grounding: supplied_text, verified ("figure stated in the report itself")
premise  R       r = 6             grounding: supplied_text, verified
goal     STATED  ite(c − r ≥ 0, c − r, −(c − r)) ≤ 0.05 + 1/100 · ite(c ≥ 0, c, −c)
                 (|c − r| ≤ h + τ·|c|, with h = 0.05 for "6.0" and τ = 1/100 for "=")
notes    STEM check: proves a property of its encoding only. ... readings: as written
```

The written zero term is dropped as an exact identity (`20 − 0` is `20`) and `4.0` is written as
its exact value; the division itself is left to the engine. Z3 answers COUNTEREXAMPLE with
`c = 5`, `r = 6`, and the receipt says:

```
Transmission ACCEPTED_WITH_FINDINGS via branch sciences. ... Report's own formal checks: 2 (1 ok, 1 FAILED,
0 undecided); FAILED: stem-eq-1. ... Findings: INT-SUBJ-001.
INT-SUBJ-001 (error) on claim s1.2: the report's own stem_arithmetic statement does not hold (engine
counterexample: c = 5, r = 6; c is the value computed from the written expression, r the stated value) ...
```

`stem-res-1` holds (the restatement agrees with the chain), so only the faulty step is named.
The result is signed and bound to the exact problem, and the report is still delivered. With
`= 5.0 m s⁻²` the same answer is ACCEPTED with both checks ENTAILED.

**Finding codes.** Errors about the answer come only from the engine; the STEM pack itself emits no error, except the hub's
PACK-INTERNAL-001 when an internal failure leaves a report with no STEM check at all (the receipt then carries an error, so
the missing checks are never read as passed).

| Code | Severity | Meaning |
| --- | --- | --- |
| INT-SUBJ-001 | error | an engine check of the answer's own statement does not hold (with the computed and stated values) |
| INT-SUBJ-002 | warning | such a check is undecided (unknown, timeout, unsupported, vacuous, inconsistent premises, the 8 s check budget spent) |
| INT-SUBJ-004 | warning | a check that relied on a reading the answer did not state does not hold |
| ST-PARSE-001 | warning | notation outside the grammar, a relation withheld because its operands may be cut, a relation written partly in words ("17 is divided by 5 = 2"), a relation sign between maths no span reads ("17 % 5 = 2" outside Computer Science), or a Given that may be written with a thousands space ("4 000"); not checked |
| ST-PARSE-002 | warning | too many readings (implicit multiplication, unit or symbol ambiguity); not checked |
| ST-UNDEC-001 | warning | a relation outside the encodings (calculus, limits, Σ with symbolic bounds, vectors, matrices, complex numbers, `!`, a combination or permutation count such as `⁵C₂` or `C(5, 2)`, asymptotic notation, a function of an unknown, an integer remainder or quotient of a negative or non-whole number or by a divisor that is not a positive whole number), with the reason |
| ST-UNDEC-002 | warning | a numeric relation depends on a symbol with no stated value and no admissible booklet value |
| ST-UNDEC-003 | warning | a Given value could not be set against the request (the request states no value of its kind and no supplied table names it, or a bare number the request does not state); one finding per statement, naming each such Given |
| ST-UNDEF-001 | warning | an undefined expression (division by zero, even root of a negative, log of a non-positive value, 0⁰); no check built |
| ST-UNIT-001 | warning | an unrecognised unit; the relation is checked as written, at warning severity |
| ST-UNIT-002 | info | an ambiguous unit symbol (`M`: molar or mega) checked under both readings |
| ST-DIM-001 / ST-DIM-002 | warning | the two sides of a relation, or the terms of a sum, have different dimensions (a bare number counts as a pure factor unless the answer or the request gives it a unit, or it matches a booklet constant) |
| ST-ALG-001 | warning | a mathematics step takes only the non-negative root with no stated domain restriction |
| ST-CHEM-001 | warning | a chemical equation that cannot be read; its balance is not checked |
| ST-CODE-001 | info | a code block: never run, never checked |
| ST-SCOPE-001 | info | a symbol rebound to a different value; substitutions match any binding |
| ST-LIM-001 / ST-LIM-002 | warning | a bound exceeded (expression, literal, IR size; more than 128 checks or 1,024 math spans per answer) |
| ST-INTERNAL-001 | warning | the STEM pack failed internally; its checks are missing and must not be read as passed (when the failure leaves the report with no STEM check, the hub's PACK-INTERNAL-001, error, stands beside it) |
| BR-INTERNAL-001 | warning | a pack of any branch raised; its findings are missing and must not be read as passed |

**Scope statement** (in every STEM problem's `notes`): a STEM check proves a property of its
encoding only. It proves that the written arithmetic, substitution, conversion, algebraic step,
balance or Boolean identity holds, or does not hold, under the stated premises, the documented
readings and the STEM tolerance rule. It does not establish that a law applies, that data are
true, that a model is physically valid, that a unit is the right one beyond the dimension and
conversion checks, or that the answer is what the question wanted.

**Measured here** (`docs/STEM_RESULTS.md`): on the 84 labelled answers written before
implementation, 38 of 38 injected faults are named with the right code and none of the 46
correct answers gets an error; on the 558-item corpus, 293 of 293 faults are named with no error
on correct work. These answers were written for the tests. The STEM arena with live
specialists (cheapest model tier, each configured only from its own v4 knowledge base, no
textbook library) and the review rounds were not run in this build; they run in the integrated
arena that merges this branch.

## The Overseer: checks of every transfer between agents (`overseer/`, a sub-project of its own)

The Overseer is a separate, separately installable sub-project, [`overseer/`](overseer/README.md) (package
`epinoic_overseer`, its own `pyproject.toml`, version, README, docs, tests, harness and knowledge pack with its
exporter), usable as a sub-agent of any system that speaks the integration protocol. It reaches the translator only
through the integration protocol (`epinoic_logic.integration`) and the translator's documented public API
(`epinoic_logic.api`, listed in [`docs/PUBLIC_API.md`](docs/PUBLIC_API.md)); the translator never imports it. It is
attached through the hub, `RouterHub(auditor=TransferAuditor(...))`, and through the overseer port the checks service
loads by name (`EPINOIC_OVERSEER_PORT`, default `epinoic_overseer.port`).

Every request, report, relay, router forward and synthesis crosses the channel; the Overseer checks those transfers so
the router never acts on a miscommunicated or tampered one. It is optional and attached through the hub:
`RouterHub(auditor=TransferAuditor(...))`. Without it the hub and the channel behave exactly as before.

- **The transfer auditor** (deterministic code) journals every transfer as it is issued (a hash-chained, HMAC'd journal
  per channel), keeps every signed engine result the transfer produced, and checks that the transfer the router is about
  to act on is the one issued, that every receipt is the exact image of what was checked, that every result a receipt
  cites is a signed engine run of the problem it names inside this task (re-run on a fresh engine), that delivered
  claims, quotations and figures are what the specialist actually wrote, that forwards and peer documents are the
  delivered text, and that a synthesis accounts for the delivered reports and names every contradiction; a STEM receipt
  carries exactly the ST codes the STEM branches re-derive from the journaled report, and states each STEM check as its
  signed run decided it. What it finds is a signed audit of `OVS-*` findings with identifiers.
- **The translator is overseen too.** Every IR problem a translation provider proposed for a claim is re-checked as
  untrusted data (`OVS-TRN-*`: re-validated by the engine's validator, its status and eligibility re-derived, its
  quotation groundings re-checked against the named supplied texts, every quotation and number traced to what the
  specialist said, a conclusion restated by the writer's own premises flagged as circular, by a rule never looser than
  the translator's own E112 and that takes no grounding kind label and no number match as evidence (a premise is a
  transcription only when the grounding check verifies its located excerpt; content only a label presents as data,
  a Boolean statement among it, is the claim assumed, and so is a number the request states only in a question, under
  a negation, as one of alternatives, in a claim the answer must examine or as a requirement on the answer; a result
  resting only on values of quantities a check reads in the request, as its statements, for the quantity each premise
  names, which no check verifies or refutes, is a warning, OVS-TRN-011, which leaves the meaning question to the
  agents), its summary
  regenerated from the signed result), and the signed audit records
  each translation: the claim text, the proposed IR, its validation outcome and the signed engine result. Overseer
  agents receive each translation with its claim and may accuse it, including of meaning faults (a dropped condition, a
  flipped comparison, an invented premise); those stay advisory and go to human review.
- **Before acting** the router calls `hub.clearance(task, message_id, receipt=...)` with the receipt it holds and acts
  only when `epinoic_overseer.policy.may_act(receipt, clearance)`: an edited receipt, a forged or misattached result or an
  altered payload is never acted on, and a pending audit is never shown as passed. `hub.close_task` issues the FINAL
  audit; `policy.may_release` gates the student-facing synthesis on it.
- **Overseer agents** are model-based reviewers built only from exportable parts: the package's code and a versioned
  knowledge pack shipped as package data (`overseer/src/epinoic_overseer/knowledge/overseer-knowledge-docs-1.5/`, with 1.0 to 1.4 kept beside it: `master_prompt.txt` and
  numbered documents, generated schemas, a manifest of digests; 1.5, installed by the round-8 clearance, differs from 1.4,
  the pack round 8 ran with, only in D32 and the cut-decimal reading, a decimal cut by an ellipsis inside an expression being
  decided, and in the code table's row of CORE-SRC-008, the core pack's warning on a near miss of a name the supplied case
  states). `python -m epinoic_overseer.export --out DIR`
  writes the pack out with a README for whoever deploys it with any model. `hub.review(task, runners)` issues each agent
  a dossier, runs it once, and validates its verdict against the journal and the signed results. A verdict is advisory
  and decides nothing: only an accusation a deterministic check confirms reaches the router, through that check's own
  finding, and no agent ever changes a clearance. No live model provider is claimed; the tests use fake providers.
- **Several agents, one input.** When the router sends one input to several agents (duplicated instances of one
  specialist, or several specialists), `hub.consolidate(task)` returns ONE signed consolidated response: equivalent
  answers grouped deterministically (identical normalised text, or the same material claims, figures, dates and
  quotations that the engine finds mutually consistent), a representative per group, every answer with an error-level
  finding or a repeated fault excluded with its codes and signed results, and conflicts between groups disclosed instead
  of resolved by choosing. A fault that comes back in the same task (another agent, a duplicated instance, a resubmission
  after rejection, reworded or not) is a repeated fault (`OVS-REP-001`), never delivered, counted per agent.
  `hub.review_pool(tasks, OverseerPool(pack, ..., router=...))` sizes the overseer agents deterministically. Which
  instances review which dossiers is the flash router's decision (a separate agent, `flash-router/`, attached through the
  router port by capability; architecture step 2c), and the overseer keeps a minimum-oversight floor computed from the
  same risk signals (`epinoic_overseer.floor`): every dossier reviewed, each dossier with a repeated fault or a risk signal
  by two independent instances, never past a maximum (four by default), every instance from the same exported pack on the
  cheapest tier and advisory. A router's plan below the floor is refused (`KIT-RT-020`, recorded in the signed audit) and
  the floor plan runs; with no router attached the floor plan runs; every plan records who planned it.

Results prove properties of the encoding only; an audit shows whether the recorded transfers, receipts and signed
results agree with each other and with the repository's rules, never that a claim is true. See
[`overseer/README.md`](overseer/README.md) and [`overseer/docs/OVERSEER_DESIGN.md`](overseer/docs/OVERSEER_DESIGN.md).

## Delivery policy: four minutes for the formal path, then an overseer-selected fallback above 90%

What the router may hand on for one deliverable (a specialist's answer, or the consolidated response when several agents
answered one input) is decided by `epinoic_overseer.delivery_policy.DeliveryPolicy` and recorded in a signed delivery receipt
(`delivery_receipt/1.0`, key id `overseer-delivery`). Full rules: [`overseer/docs/DELIVERY.md`](overseer/docs/DELIVERY.md).

- **Formally checked**: withheld for every answer in this release (rule `formal-label-withheld`, `docs/DELIVERY.md`
  condition 6d), so every answer takes the fallback below until a label policy holds under adversarial attack. The
  conditions the label will need: within the translation budget (240 s by default, on an injectable monotonic clock),
  every material eligible claim was translated, decided positively by the engine as encoded and passed the release rule
  (premises established, grounding checks passed, a current faithful fidelity review), and the transfer audit cleared
  the answer, and the receipt names no working left unchecked (a STEM relation outside the grammar or the encodings, a
  value not stated, a pack that failed, a check undecided) and no agent self-report, and every claim of the answer,
  whatever its materiality, carries a positive outcome of a signed engine result (rule `unverified-claims`, condition
  6c). A claim the deadline reaches
  unstarted is never started; one that finishes after it is late.
- **Otherwise the fallback.** Overseer agents built from the exported knowledge pack review every candidate (every
  answer to the input; a single answer is one candidate) through the package's runner and the self-duplicating pool,
  every verdict validated as in production. A candidate's accuracy is the share of its material claims the counted
  verdicts confirm accurate; a verdict contradicting a signed engine result is rejected; a claim a signed result refutes
  is inaccurate and an unassessed claim is never accurate. The most accurate acceptable candidate (ties to the
  consolidation's canonical choice) is delivered OVERSEER-SELECTED only when its accuracy is strictly above 0.90; a
  candidate with a refuted material claim is never chosen while another has none.
- **Otherwise withheld**, with every score and reason on the receipt. The overseer stage has its own deadline; when it
  runs out the answer is withheld (or, only if an operator configures it, delivered NOT CHECKED).
- Only FORMALLY CHECKED claims a check: every other label says "not formally checked, not verified". The delivered
  payload is the journaled one byte for byte; the fallback never edits, widens, adds or drops a claim. The receipt
  records the time to decision, the translation time and the overseer time; the arena harness reports each task's mode,
  time to decision, candidates and choice in `results.json` and `summary.md`, and says whether its delivery pass
  exercised the overseer-selected fallback. On the command line it calls no model, so it exercises none. With
  `run_arena.py --overseer-provider MODULE:FACTORY`, the fallback's overseer agents run through the package's runner,
  and the decisions are reported beside the withheld baseline (`scripts/arena/README.md`).

## Features of the logic translator (`src/epinoic_logic/translate/`)

| Feature | What it does | Where |
| --- | --- | --- |
| Claim-record input | Works on structured claims from a specialist report (ids, role, subject, source refs, assumptions), not on raw student text. | `contracts.py` |
| Deterministic eligibility | Code, not the model, decides whether a claim may be formalized: argument structure (point + supporting claims), structural counts, exact numeric claims. Interpretive, factual and rubric judgements are routed elsewhere. | `eligibility.py` |
| IB subject policy | Per-subject profiles say which claim classes are allowed (quantitative claims in Mathematics, Sciences, Economics, Business; argument structure only in Literature, History, Arts, TOK). The profile text is injected into the prompt so the model knows what cannot be established in that subject. | `subjects.py` |
| Staged decomposition | The prompt asks the model to list grounded atomic propositions first, then the specialist's inferential links, then assemble the problem. Inspired by the NL2FOL method; no code or prompt text copied. The prompt in use is `translate_v2` (exactness, task authority, definitions); `translate_v1` stays packaged unchanged. | `prompts/translate_v2.md` |
| Grounding checks | Quotations cited as grounding are matched verbatim (then with typographic normalization, and through stated form-difference tiers such as a long elision or different accents) against the supplied text; `verified` is set only by this code. Every reference of a grounding is checked and keeps its own outcome; only complete support verifies it, so a matching excerpt beside an unknown document is `partial`, never verified. Each text's normalised forms and each located excerpt are cached in bounded caches keyed by the text's digest, so an answer never depends on the cache. | `grounding.py` |
| Task authority | `arithmetic_fact`, `task_setting` and `rubric_rule` are the translator's proposal, never a validation: a premise of such a kind is validated, refuted (an invented 160 km where the source says 120 km is an evidence failure) or left unvalidated against the supplied texts and the task record as the router issued it (`TaskRecord`). The engine lists every unvalidated or refuted premise the proof relies on. | `grounding.py`, `contracts.py` |
| Typed quantities | Figures are exact values with unit, scale and written precision; `20%` states `0.2` and `1/5` alike through one recorded derivation, and a symbol's declared reading is respected. A figure stated as rounded ("x is 0.33 to 2 decimal places") states the interval of its tolerance, so its exact transcription and the interval at exactly that tolerance both ground, and no wider or narrower interval does. | `quantities.py` |
| Exactness from the wording | A figure stated exactly or given by the task is never widened (an interval in its place is rejected as a weakening); a rounded figure uses exactly its stated tolerance; an unstated decimal whose reading decides the verdict is AMBIGUOUS_TRANSLATION. A figure is the result of a written calculation only when the calculation ends at its '=' ("If x = 1/3 then x = 0.33" states 0.33 as the value of x, unstated), and an approximation cue governs only the figure it is written against. The solver never decides that a figure was rounded, and every accepted retry is recorded, a semantic change apart from a syntax repair: a retry that weakens the claim cannot inherit its approval. | `precision.py`, `pipeline.py` |
| Coverage | A definition that asserts nothing, or a conclusion symbol no premise mentions, leaves a figure open. The counterexample is withheld (E110/E111) only when a source clause asserts the figure (the claim, its supporting claims, the supplied texts or the task record; a record's figure only in a clause about the symbol): read from the source's grammar, a figure in a question, a condition ("if n equals 17", "when n is 17"), a supposition, a definition ("exactly when"), a possibility ("could"), an attribution, a negation, a quantification ("for any y") or a disjunction is not asserted, a bound ("more than 17") establishes no equality, and a figure that counts something else ("I checked 3 values") is about no symbol. Otherwise the counterexample stands with the advisory W110/W111. The translation layer hands that decision to the engine as an application record, so the signed result and the display agree; the retry an E110 asks for may add only what the source asserts, or the translation is AMBIGUOUS_TRANSLATION. | `assertion.py`, `coverage.py` |
| Strict parsing | Model output is parsed with a plain JSON parser only (a reply that is one JSON object is taken as it is; otherwise code fences stripped); anything else is a failed attempt. The overseer's verdict intake is stricter: the bare object or exactly one fence around the whole reply. | `parsing.py` |
| Bounded retries | Validation diagnostics are fed back for at most one retry; the status then becomes INVALID_FORMALIZATION rather than looping. | `pipeline.py` |
| Ambiguity flags | The model must declare materially different readings; the result becomes AMBIGUOUS_TRANSLATION and is never shown as verified. | `pipeline.py` |
| Replaceable providers | Fixture provider for tests; Anthropic and OpenAI-compatible adapters behind one interface (untested live here). | `providers/` |
| Advisory semantic review | An independent reviewer rates translation fidelity with the evidence: the original task, the supporting claims, the supplied texts, their identities and the premise-to-source mapping. The review is bound to those inputs, so a changed source or supporting claim makes it stale; the verdict is labelled advisory and never changes the formal status. | `review.py` |
| Outcome for the Overseer | One record per claim: translation, signed engine result, structural findings, review, a derived display status, a release assessment kept apart from the formal status (release needs the engine's release check, established premises and a current, faithful review made with the evidence), and a plain-language summary ending with the scope statement. A result of an earlier release is displayed INTERNAL_ERROR until verified again. | `outcome.py` |

## Communication between agents (`src/epinoic_logic/integrity/`)

Miscommunication between the router, specialists, combinator and Overseer is
checked as well as hallucination inside one answer. Deterministic code checks
message envelopes (replay, tampering, mis-threaded replies), router hand-offs
(wrong task, unselected agent, off-subject, citations outside the retrieval scope),
result staleness (a verification result reused after the claim's representation
changed, or unsigned), and the combinator's claim ledger (material claims dropped
without record, claims with no source, certainty inflated above the weakest source,
evidence references lost, conflicts "resolved" without a basis). Z3 then checks
whether specialists' formalized claims contradict each other under a shared glossary,
naming the conflicting claims, and whether each synthesized claim is actually
entailed by the source claims it cites, producing a counterexample when the
combinator stated more than its sources support. See `integrity/README.md`.

## The verification engine (`src/epinoic_logic/engine/`)

Restricted IR 1.0 (Bool, Int, Real; 24 allowlisted operators; exact numerals as
text) → validator (sorts, identifiers, limits, policy; collects all diagnostics) →
compiler (one Z3 call per node, fresh context) → procedures (consistency first,
then entailment with tracked unsat cores, always computed; exact models) → result bound
to a digest of the exact problem, solver configuration, component versions, the immutable
identity of the build (engine and IR source, schemas, decision policy) and any non-default
validation limits, and HMAC-signed so the Overseer can reject anything an agent fabricates.
Statuses form a closed set; only six are definitive and none means "the claim is true".
Only a check run in this process confers a premise's authority: an unchecked task or source
kind is an unverified dependency, never hidden. Formal entailment is not permission to
release: `engine.release.release_check` (HTTP `POST /v1/results/release-check`) also requires
an authentic, current result resting on established premises only, and a result of an
earlier release stays inspectable but is never current.

## Integration kit: required Z3 and STEM checks for the website and the specialist APIs

`integration/` holds the integration protocol `epinoic.integration.v1` and the kit that applies it: the website's
adapter and patch material (with the W0 docs drafter for the website's owner), the agents material (the checks port A2
and the changes A3 and A5, tested on an archive copy), the golden vectors, the simulation (its website and agents
drivers; the checks service starts with the overseer sub-project's port adapter, and the drivers' wiring is also
checked with a test double of the overseer port, under which every gate is NOT RUN), the readiness checks and the playbook a fresh session follows. Every decision of the kit is decided and recorded
in [`integration/DECISIONS.md`](integration/DECISIONS.md), with the kit changes those decisions require (not made yet;
the fail-closed defaults stay until they are). Start with [`integration/README.md`](integration/README.md) and
[`docs/INTEGRATION_PROTOCOL.md`](docs/INTEGRATION_PROTOCOL.md). Z3 and STEM checks are required: a missing part fails
with a named `KIT-HS` code. The service side lives in `src/epinoic_logic/integration/`; the default `engine` profile is
unchanged. The flash router, which plans how the overseer reviews each answer and each overseer-pool batch, is a
separate sub-project, [`flash-router/`](flash-router/README.md) (not the translator's `RouterHub`), edited, re-tuned and
released apart from the Z3 infrastructure, the STEM support and the overseer (its rules and cost data are versioned data
files with digests), and run by the service and by the overseer pool in its own process; its plans are advice that each
caller holds to its own minimum-oversight floor. The combinator, which combines the specialists' answers to one request into one synthesis, is a
separate agent in a sub-project of its own, [`combinator/`](combinator/README.md): its instructions (exported with
`python -m epinoic_combinator.export --out <dir>`), a runner on the cheapest tier that lets out only what is in the
published synthesis contract, and its own tests; the translator never imports it, and its hub checks every synthesis
on its own.

## Repository layout

- `src/epinoic_logic/ir/` — IR schema and canonical digests (`README.md` inside)
- `src/epinoic_logic/engine/` — validator, compiler, procedures, provenance, runner
- `src/epinoic_logic/translate/` — contracts, eligibility, subjects, grounding, pipeline, providers, review, outcome
- `src/epinoic_logic/branches/` — the router hub, subject branches and integrity packs (primary infrastructure)
- `src/epinoic_logic/channel/` — the translator channel every inter-agent message passes through
- `src/epinoic_logic/integrity/` — inter-agent envelope, hand-off, ledger, staleness and formal cross-checks
- `src/epinoic_logic/api/` — the translator's documented public API, the only translator modules the overseer imports besides the integration protocol (`docs/PUBLIC_API.md`, generated: `python -m epinoic_logic.api`)
- `src/epinoic_logic/adapters/` — specialist adapters (generic structured; English specialist as worked example; History; the STEM parser; multi-subject fixtures)
- `src/epinoic_logic/stem/` — the STEM front end, checks, SI reading and hub hooks (`README.md` and `ENCODINGS.md` inside)
- `src/epinoic_logic/service/` and `cli.py` — authenticated HTTP boundary and command line
- `src/epinoic_logic/integration/` and `integration/` — the integration protocol's service side and the integration kit
- `flash-router/` — the flash router, a sub-project of its own (`pyproject.toml`, package `epinoic_flash_router` with its versioned rules and cost data in `data/`, the runner `epinoic_flash_router_cli`, `docs/`, `tests/`); the oversight planner's decision for the checks service and the overseer pool, not the translator's `RouterHub`
- `combinator/` — the combinator agent, a sub-project of its own (`pyproject.toml`, package `epinoic_combinator`, instructions, tests)
- `overseer/` — the Overseer, a sub-project of its own (`pyproject.toml`, package `epinoic_overseer`: the transfer auditor, router policy, the overseer-agent verdict protocol, the knowledge pack, its loader, exporter and agent runner, consolidation, the overseer pool, the delivery policy and the overseer port adapter; `docs/`, `tests/`, `scripts/` with the contained run and the harness)
- `tests/` — unit, end-to-end, service and `stress/` suites
- `docs/` — audit, plan, design, status, stress results, STEM design and results (`STEM_DESIGN.md`, `STEM_RESULTS.md`), evidence, context pack

## Running

```
python -m venv .venv && .venv/bin/pip install -e ".[dev,service,providers]"
.venv/bin/pip install -e ./overseer --no-deps   # the overseer sub-project (the checks service loads its port adapter)
.venv/bin/pip install -e ./flash-router --no-deps   # the flash router (attached only when named: EPINOIC_FLASH_ROUTER, OverseerPool(router=...))
.venv/bin/python -m pytest -q        # three suites: the translator's (tests/), the overseer's (overseer/tests) and the
                                     # flash router's (flash-router/tests); the combinator/ suite runs inside tests/
.venv/bin/pytest -m stress tests/stress   # load, concurrency, adversarial volume, soak
epinoic-logic verify problem.json     # one verification from the command line
```

## What it does not do

It does not decide literary, historical or rubric judgements; it does not check
quantifiers or symbolic calculus (these are reported as UNSUPPORTED or, for STEM answers,
named undecided); units are checked only by the STEM branches' dimension warnings and explicit
conversion checks, and nonlinear algebra only under the named `nonlinear` engine policy the STEM
checks use (a caller of `POST /v1/verify` or `epinoic-logic verify` names the same policy, never
limits of its own, so a problem decides over HTTP as it did in the pipeline); it does not run inside a Cloudflare Worker (see `docs/AUDIT.md` for
the runtime evidence); and it does not call any model provider in its tests.

## Arena: real agents, contained environment

Isolated specialist agents configured only from their subjects' knowledge documents answer
router tasks; every output crosses the hub as in production, independent overseer lenses judge
fidelity and fault naming, and fixes are regression-tested before the next round. Rounds 1 to 6
used the English and History specialists; round 7 used sixteen specialists across fifteen IB
subjects, added a fourth lens on translation fidelity, and attached overseer agents that judged
blind dossiers. No round reached the target of 0.98 from every lens: round 7's four lenses gave
0.532, 0.4246, 0.7477 and 0.6384. Each round's material, verdicts, findings, fixes, harness
figures and what remains open are in `docs/ARENA_RESULTS.md`. Rounds 8 to 10 run after the STEM
and overseer builds merge, and the optimisation checks run last, after every bug-testing round.
Stress figures for the engine, channel and hub are in `docs/STRESS_RESULTS.md`; no stress iteration
was run after the bug-fix rounds. The harness's functional rate checks that the hub delivered and
decided every transmission and named every injected fault; it does not judge whether a
finding is true. Every injected fault no finding names is a miss, counted as a failure whatever its
cause (when the receipt itself names the injected claim undecided, the failure reason quotes it). Its
summary therefore states, under the headline, how many genuine receipts
carry error-level findings and are still counted functional, and names every definitive
verdict other than ENTAILED shown on a genuine claim with what it rests on, beside the
number of genuine claims whose encoding got no verdict (vacuous, circular, an unasserted
figure or an unencoded reason a source states, a figure encoded at another precision than the
source states, an exact figure widened) and, apart, the verdicts that stand with an advisory
coverage warning. The harness reports transport (the functional count), fixture coverage,
translation fidelity (only where adjudicated) and claim counts (extracted, eligible,
attempted, completed, faithful, approved, and apart from them the claims whose release
assessment permits releasing the answer) as separate measures, never combined into one rate,
and qualifies a replay that loses recorded translations (`scripts/arena/README.md`). A replay runs what production runs
wherever a recording allows it and names what it cannot ("Replay configuration" in `summary.md`): the translator gets the
task record of each request, as production's verifier does; a recorded translation is bound to the claim text it was
produced for by the digest recorded with it (`scripts/arena/bind_translations.py`, a step of recording a round), else
the run is qualified; a retry, served the same recorded output, is reported as not exercised; and a synthesis is stamped
when it is relayed. Every group of a round
that carries syntheses has exactly one synthesis record, whatever happened to its members,
so the number of transmissions never depends on what crashed. The listing that briefs the agents and the translation
agent (`scripts/arena/list_claims.py`) prints the claim ids the hub delivers, the agent-qualified ids of a group's second
STEM, History or English report of one branch included, and a recorded translation keyed by either form of one agent's
STEM, History or English claim id is served to that claim and named on the record. The combinator's synthesis reaches the hub as
written, its citations included, and a syntheses file outside the combinator's published contract (a control or
bidirectional character, a blank text, a repeated citation) is a failure named with its `KIT-CB` code, as the
deployed combinator would refuse it. A peer-dependent agent reads of
its peer only the delivered report, its document id and the relay status (`relayed/<task>.json`);
the hub's receipts of the peer's delivery and of the relay stay with the router
(`router/<task>.json`), so no finding reaches an agent as content. Whether the receipts are
right is judged by the overseers. A round is read with its plan (`tasks.json`): a planned task that never answered is
a genuine reply not delivered, its peer relay, when the round never recorded one, a relay not run, and its group's
synthesis fails naming it, so a round that lost its peer exchanges says so (round c3 had four, and its headline read 40
of 40); a specialist file that is not one JSON object of the round format is refused by name and the rest of the round
runs. The claims a mutation changes are listed for the translation agents (`list_claims.py --mutations`) and served the
translations recorded for the mutated texts (`mutation_translations/`); every changed claim no recorded translation
reached is named on the replay configuration line, since without one only the deterministic checks can name its
injection.

The test layers and a running log of bug and stress testing are in `tests/README.md`; the per-round arena record is `docs/ARENA_RESULTS.md`.

What the engine accepts and returns, and what a result establishes, is the integration contract in `docs/integration-contract.md`. The baseline review in `docs/BASELINE_REVIEW.md` records the checks run on the baseline commit, its known limits and the next milestone.
