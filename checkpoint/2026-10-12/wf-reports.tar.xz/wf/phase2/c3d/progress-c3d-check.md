# progress c3d-check (check fixer)
Probe dir: S/wf/phase2/c3d/check (rd.py, rdm.py marking ctx, dbg.py review, dbgg.py gate, evalset.py base.json/afterN.json).
## Done (code, reader level; no tests yet)
- reader._stray_quotes_blanked: possessive-like mark closes an open quote (headline regression)
- encoded._spelled_label: Spanish 'O, K y P' list tail
- meaning._review: invention 'not yet invented' frame; claim-noun content frame (Orwell); letter sign-off frame; _mark_allocation
- lexicon: magazine(s) analysed_text/src_noun
- reader._gate SRCEVAL: demonstrative+repeated noun, Spanish elided subject after y
- meaning._nonsuccess: negator across article ('ni un error')
- encoded: whole-line transforms accept digits/brackets/%, comma parts; chunked/periodic status values; Pig Latin
## Next
- remaining reader misses: Revued, (proven)/(sat) after quote, multiple (sat), class phrasings
- path items: agent_version, combinator tick/sat, channel INT-REQ-003 case, geography rain sum FP, branch misses
- tests file tests/selfcert/test_c3d_check.py etc.
## Done (step 2)
- misspelt: sound index (iew/ew->u) + frame (5) coordinated participle: 'Revued and approved.'
- reader: _logic_host blanks other solver labels (multiple (sat)); _quoted_then_label alt reading ((proven)/(sat) after quote; one-word gloss excluded)
- reader._bracket_status: host_logic for combinator too ((sat) CS consistent)
- reader.plain_tick_bullets + ledger._self_report_sentences/_self_report_findings use it (combinator tick bullets)
- pieces.report_texts: agent_version (report + claim)
- own_text.quotes_own_wording: casefold match
- geography _FACT_DERIVED_AFTER_RE: total words + later worked bracket (rain sum FP)
- verified: evalset dev sets OK; score.py no BROKE
## Next
- write tests (tests/selfcert/test_c3d_check.py, tests/branches..., overseer test for agent_version, ledger tick test)
- run targeted dirs; then branch misses if budget
## Done (step 3)
- tests: tests/selfcert/test_c3d_check.py (683 pass), overseer/tests/overseer_tests/test_c3d_check_agent_version.py (28 pass), tests/branches/test_c3d_check_branches.py (9 pass)
- class frames meaning._own_verdict_c3d (grades, unfound defects, amazed-wrong, point off, hard to improve, answered right, recomputed same, reviewer nothing, nothing-to-correct label), _reference_agreement own comparand, _lead_strip hedged 'safe to say', lexicon solucionador/all-clear/revisores
- bg run selfcert dir 3091 passed (before class frames); integ_adapters running (logs in check/logs)
## Next
- branch misses (geography breakdown possessive, word bounds), re-run targeted dirs, docs (selfcert README/tests README?)
## Done (step 4)
- branches: geography REQ_WORDS_CREDIT (word figure credited to request), language_b _task_word_bounds, worked._LABEL_FIG possessive
- tests/branches/test_c3d_check_branches.py 17 pass; tests/README.md entry added
- bg runs: integ_adapters (started before class frames), branches + channel started after branch fixes (logs check/logs)
## Next
- wait logs; rerun selfcert dir + overseer selfcert-related; fix failures; StructuredOutput
## Done (step 5)
- language_b _ES_FROM_TO_RE bracketed pair; genuine c1-c3 delivery unchanged (gen_cur.json: bi-p9b, sp-t15 only)
- waiting on bg logs (bdr5euatk waiter)
## Left undone (draft)
- TPNQRPXRQ (no valid transform), sp-t14 Spanish exact own-wording (INV-Q1 pinned), sp-t15 closing question altered, service display (owner call),
  idiom misses (face value, as read, no arguing, red pen, nailed, study group, clavado, bordado, dejado nada), 75% (21/30), Spanish shares,
  Spanish number words years/counts/percent, misattributions, item 56 740,000, rain rate % lower (from-to bracket)
## Done (step 6, final)
- fixes after runs: _logic_host ignores bare sat/unsat (gate2 synthesis test); claim-noun frame limited to content clause (c3 clearance ENTAILED pins)
- runs: selfcert 3338 passed; integrity+adapters 2778 passed + 2 fixed (rerun pass, linear test 111s under load); branches 9772 passed + 3 fixed (rerun 472 pass); channel 2393 passed; overseer selfcert files 7506 passed; check tests 873 pass; hygiene ok
- DONE: returning StructuredOutput
