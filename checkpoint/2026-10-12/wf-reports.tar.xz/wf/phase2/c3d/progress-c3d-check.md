# progress c3d-check (check fixer)
Probe dir: S/wf/phase2/c3d/check (rd.py, rdm.py marking ctx, dbg.py review, dbgg.py gate, evalset.py base.json/afterN.json).
## Done (code, reader level; no tests yet)
- reader._stray_quotes_blanked: possessive-like mark closes an open quote (headline regression)
- encoded._spelled_label: Spanish 'O, K y P' list tail
- meaning._review: invention 'not yet invented' frame; claim-noun content frame (Orwell); letter sign-off frame; _mark_allocation
- lexicon: magazine(s) analysed_text/src_noun
- reader._gate SRCEVAL: demonstrative+repeated noun, Spanish elided subject after y
- meaning._nonsuccess: negator across article ('ni un error')
- encoded: whole-line transforms accept digits/brackets/%, comma parts; chunked/periodic status values; Pig Latin
## Next
- remaining reader misses: Revued, (proven)/(sat) after quote, multiple (sat), class phrasings
- path items: agent_version, combinator tick/sat, channel INT-REQ-003 case, geography rain sum FP, branch misses
- tests file tests/selfcert/test_c3d_check.py etc.
