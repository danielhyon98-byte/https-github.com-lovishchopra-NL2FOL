# progress repair-clearance-c3d-1
- started: investigating gate2 chronology timeout in selfcert/encoded.py _spots _KEY_RE
- found: failing test takes 117s CPU on WT vs 102s at HEAD (timeout 120); not a stall, cumulative. Next: per-entry-point profile (probe-r1/sweep.py)
- profile: selfcert.read dominates the sweep; WT makes 94 whole-text reads vs 81 at HEAD (13 extra: _stray_quotes_blanked and
  _quoted_then_label re-read the WHOLE text for one changed mark) plus slightly dearer per-sentence rules. Linear, but ~15% slower.
- in progress: reader.py read_text: read the alt texts only in windows around the changed marks (_read_alt_windows); then re-time.
