# progress repair-clearance-c3d-1
- started: investigating gate2 chronology timeout in selfcert/encoded.py _spots _KEY_RE
- found: failing test takes 117s CPU on WT vs 102s at HEAD (timeout 120); not a stall, cumulative. Next: per-entry-point profile (probe-r1/sweep.py)
- profile: selfcert.read dominates the sweep; WT makes 94 whole-text reads vs 81 at HEAD (13 extra: _stray_quotes_blanked and
  _quoted_then_label re-read the WHOLE text for one changed mark) plus slightly dearer per-sentence rules. Linear, but ~15% slower.
- in progress: reader.py read_text: read the alt texts only in windows around the changed marks (_read_alt_windows); then re-time.
- done: _read_alt_windows (windows, content-only, margin), meaning._own_verdict_c3d cue prefilter, _verdict_on_this_answer verb-first exit, _merge one word-set check. Next: paired timing HEAD vs WT, then tests
- also: own-verdict cue looked for in folded sentence before original_span (meaning._review). Next: paired run of the failing test
- measured: failing test alone WT 106 s vs HEAD 100 s (was 117 vs 102); growth 20k->80k linear (ratios ~4) on 8 shapes, HEAD and WT.
- next: run test file, selfcert tests, tests importing selfcert (in background, logs in probe-r1/)
- added tests/selfcert/test_c3d_alt_windows.py (new regression tests); runs A/B in background (probe-r1/run-A.txt, run-B.txt)
- run A (chronology file + tests/selfcert): 3371 passed. next: harness c3 on a copy (probe-r1/h-c3), wait run B
- harness c3 on copy: 164/176, output identical to the clearance run except wall time. next: c1, c2 copies; wait run B
- harness c1 203/203, c2 188/188 on copies, identical to clearance outputs except timing. waiting run B
- tests/README.md: entry for test_c3d_alt_windows.py added. waiting run B (probe-r1/run-B.txt)
- run B (55 other files using selfcert): 9606 passed, 1 skipped (recorded round r5 not present). hygiene test 8 passed.
- DONE. Nothing committed (the workflow commits).
