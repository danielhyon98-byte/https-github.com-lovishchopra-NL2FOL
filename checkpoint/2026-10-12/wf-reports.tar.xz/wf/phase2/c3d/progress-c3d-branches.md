# progress c3d branches fixer
Started. No work done yet. Plan: geography items (c3c-left check_open 43-57), Language B (58-71), packs CORE-SRC-003 (left_undone 20).
