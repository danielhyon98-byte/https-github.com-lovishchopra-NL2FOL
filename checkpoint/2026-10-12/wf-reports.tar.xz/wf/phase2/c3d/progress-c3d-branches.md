# progress c3d branches fixer
Probe scripts: S/wf/phase2/c3d/branches/ (probe.py <tsv>, g*.tsv, l*.tsv, probe_src3b.py). Baseline arena: S/wf/phase2/c3d/branches/arena-base (c1 203/203, c2 188/188 seen).
DONE (code + tests/branches/test_c3d_branches.py, 79 passed):
- packs.py: _not_own_wording (own-wording quotation no CORE-SRC-003)
- geography.py: _fact_key post noun; _dimension_area; _labelled_relative; _depth_volume; _request_clocks/_clock_interval; _year_table_derived (+_YtDoc);
  _word_limits; _table_spacing; _answer_events/_event_relations; _answer_parts/_part_complement; docstring table
- language_b.py: _MODEL_REF_RE verbs; byline group d; _task_word_claims; _paraphrase_speakers named+_cognates; _request_task_text (writing/marking only);
  _text_speaker/_appositions; _PROD notes + _WORD_CAP_RE; docstring. spanish_lexicon.py: exchange/trip/visit/holiday/course gloss
- branches/README.md updated (geography, language B, CORE-SRC-003 own wording)
IN PROGRESS: full tests/branches run (pytest-branches-1.log: OLD code state; rerun needed -> pytest-branches-2.log); arena-after (c1 started before _part_complement)
LEFT: item 56 (two lower bounds, no contradiction in encoding); not-mine items (channel/overseer/selfcert/argument diagnostics)
arena-after c1 203/203 c2 188/188 c3 164/176 (=baseline); c1 rerun on final code in arena-after2
tests/branches full run (pytest-branches-2.log): 4 failed -> fixed: _APPOSITION_RE name clash in language_b (renamed mine _NAMED_DESCRIPTION_RE); test_d9d10_recorded pins for ge-p9c/ge-t15 rewritten stricter (new ENTAILED checks). Other dirs touching CORE-SRC-003 (790 passed) and Geography/Language B (6763 passed, 1 skipped). c1 rerun final 203/203.
NEXT: rerun failing files + StructuredOutput.
