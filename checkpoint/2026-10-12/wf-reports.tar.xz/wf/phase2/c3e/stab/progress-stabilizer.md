# Stabilizer progress (fix-c3e)
- [x] snapshot before-src + before.patch (20:01 22 Nov)
## Baselines ALONE (before my changes, 22 Nov ~20:05)
- (1) sweep script total 98.7 s (is_note_sentence 15.7, parse 15.7, is_self_report 13.9, opens_with_fact 13.8, classify 13.7, is_note_paragraph 12.3, classify_paragraphs 10.0); ~94% in selfcert read_text, one full reading per input, per-sentence pipeline
- (2) receive_s 16.66 (script tools/prof2.py), test 18.1 s call; 1/3 in encoded._line_transforms (53 transforms/line on "ab cd"), stem lexer _spanish_text
- (3) pass alone (2.26 s call), (4) pass alone after warm tests (2.97 s), (5) 8KiB 0.052 / 32KiB 0.200 ratio 3.85, (6) 3.6 s call total
## Changes (all exact; equivalence harness tools/readings.py + corpus.json, before-src vs src)
- C1 selfcert/reader.py _net_found: lru_cache(4096); ASCII words skipped in script count; Latin net skipped when ws has no positive/defect word
- C2 selfcert/encoded.py _caesar_text/_atbash_text via str.translate tables; _line_transforms: letter transforms only when a word has >=4 letters
- C3 stem/lexer.py _spanish_text: English count only when es>=3
- after C1-C3: (2) receive_s 8.62
- equivalence C1-C3: corpus 35430 texts (dev sets, test string constants, hostile shapes), 0 differing records (eq/before vs eq/after1)
- C4 selfcert/normalise.py: _pass_one emits an ASCII run in one step (_ASCII_RUN_RE); letter_like returns False below the lowest block (_BLOCKS_LOW)
- after C1-C4: (1) sweep total 80.2 s alone (parse 14.5, is_note_sentence 12.0)
- C5 adapters/markdown.py _label_shaped: _LABEL_PHRASE_HINT_RE pre-filter (verified: re.I literal vs charset fold sets equal for all code points)
- C6-C9 (reader _mood lazy headline, _spanish order; normalise _reordered_runs regex; pieces sentence_spans plain-run skip): eq 0 diffs (read + adapter-level readings2); tests/selfcert+tests/adapters 5461 passed
- C10 overseer/src/epinoic_overseer/replay.py _worker_main: _warm_reader() reads 8 fixed sentences with api selfcert_read before the first job. Cause of (4): cold worker paid ~0.23 s (lexicon load, misspelt index, ownverdict sets, regex compiles) inside replay of hi-s1-h1.1 (254 ms cold vs 24 ms warm). First clearance after connect 322-335 ms (waited 250, cap) -> 116 ms (waited 111); later clearances 75-125 ms
- (3) per-shape medians alone (tools/t3.py): rearrangement_root_pass 35-38 ms, surd_exact_pass 29-36, others <=31 (decimal_root_quadratic_pass is KNOWN_SLOW 600 ms bound, 145 ms); Z3-bound: 8 solver checks per verify (~18 ms C time) + 3 ms context creation; diagnose (R0 minimisation) 14 ms; no exact cut found yet
- (1)-(6) under 2-process load (tests/branches loop), 3 rounds fresh processes: all passed; (1) 74.9/75.0/76.2 s, (2) call 9.1/8.9/9.3 s, (3) call 2.8-3.0 s, (4) first clearance 103-128 ms AUDIT_PASSED, (5) 32KiB median 0.138-0.161 s (ratio <=3.2 with 0.05 floor), (6) 2.9-3.15 s total call. Alone: (1) 76.45 s call, (2) receive_s 7.5, (5) 0.037/0.141 ratio 2.8, (6) max text 1.276 s. (3) alone varies with machine state: 25-38 ms for rearrangement_root_pass (24-25 under load)
- NEW tests: tests/selfcert/test_c3e_stabilizer.py (5 tests: transforms vs per-char reference, short-word lines, label hint never misses, sentence_spans vs old per-char form copied from base, net memo) PASS; overseer/tests/overseer_tests/test_c3e_stabilizer_overseer.py (2 tests) PASS (run overseer tests with -c pyproject.toml --rootdir=.)
- validation shards running (22 Nov ~21:20): A = adapters_history+stem+engine, B = integration+channel+overseer/tests -> logs/val-A.txt, val-B.txt
- NEXT: wall-clock sweep of the 88 timed files (--durations=0), list <25% headroom
- shard A (adapters_history+stem+engine): 7034 passed, 29 deselected (18:45)
