# Stabilizer progress (fix-c3e)
- [x] snapshot before-src + before.patch (20:01 22 Nov)
## Baselines ALONE (before my changes, 22 Nov ~20:05)
- (1) sweep script total 98.7 s (is_note_sentence 15.7, parse 15.7, is_self_report 13.9, opens_with_fact 13.8, classify 13.7, is_note_paragraph 12.3, classify_paragraphs 10.0); ~94% in selfcert read_text, one full reading per input, per-sentence pipeline
- (2) receive_s 16.66 (script tools/prof2.py), test 18.1 s call; 1/3 in encoded._line_transforms (53 transforms/line on "ab cd"), stem lexer _spanish_text
- (3) pass alone (2.26 s call), (4) pass alone after warm tests (2.97 s), (5) 8KiB 0.052 / 32KiB 0.200 ratio 3.85, (6) 3.6 s call total
## Changes (all exact; equivalence harness tools/readings.py + corpus.json, before-src vs src)
- C1 selfcert/reader.py _net_found: lru_cache(4096); ASCII words skipped in script count; Latin net skipped when ws has no positive/defect word
- C2 selfcert/encoded.py _caesar_text/_atbash_text via str.translate tables; _line_transforms: letter transforms only when a word has >=4 letters
- C3 stem/lexer.py _spanish_text: English count only when es>=3
- after C1-C3: (2) receive_s 8.62
- equivalence C1-C3: corpus 35430 texts (dev sets, test string constants, hostile shapes), 0 differing records (eq/before vs eq/after1)
- C4 selfcert/normalise.py: _pass_one emits an ASCII run in one step (_ASCII_RUN_RE); letter_like returns False below the lowest block (_BLOCKS_LOW)
- after C1-C4: (1) sweep total 80.2 s alone (parse 14.5, is_note_sentence 12.0)
- C5 adapters/markdown.py _label_shaped: _LABEL_PHRASE_HINT_RE pre-filter (verified: re.I literal vs charset fold sets equal for all code points)
- C6-C9 (reader _mood lazy headline, _spanish order; normalise _reordered_runs regex; pieces sentence_spans plain-run skip): eq 0 diffs (read + adapter-level readings2); tests/selfcert+tests/adapters 5461 passed
