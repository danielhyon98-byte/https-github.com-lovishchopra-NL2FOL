# progress c3e branches fixer
Probe dir: wf/phase2/c3e/branches (common.py, androw.py, mk_c3e.py -> cases_c3e.json, runner/v4.py; cases_r10.json copy)
## Done
- (1) REPRODUCED the and-row lead on the working tree (38/5.5 GJ -> derived-4 ENTAILED, no finding; correct 42 GJ -> COUNTEREXAMPLE + INT-SUBJ-004).
  FIXED: grounded_figures.FUNCTION_WORDS (added to _STOP), geography imports it: _row_words() for _yt_named_row, complement own words,
  _STOPWORDS of attribute-table columns. After: 5.5 GJ -> COUNTEREXAMPLE INT-SUBJ-004; 42 GJ -> ENTAILED. language_b has no table row lookups.
  Tests NOT yet written.
- (2) Geography branch misses FIXED in geography.py (probes q1..q5.tsv): area by result verb/cross-section (_AREA_RESULT, digit-free gate on area
  units); from-to bracket pair '(from 38 mm to 36 mm)'; fact noun synonyms rainfall->rain (_fact_noun); _LABEL_REL_RE widened ('the N of L1',
  absolute amounts with unit, n3); possessive label figure 'Storm 1's 36 mm' in _request_figures (+ _SPREAD_OVER_RE, 's not a noun);
  powers of ten in depth-volume; word-number durations (_DUR_RE hw) and label-subject clock interval; event intervals in words
  (_EVENT_INTERVAL_RE w/hf/h1/h2) + _WORD_DURATION_RE sentence gate.
- (2) Language B FIXED in language_b.py: _shares reader (lb_share: 'El 25 % de 80 es 30', part-first, '(21/30)' fraction form);
  'desde YEAR' + present perfect as period to today (_PERIOD_RE s1, _period_points); present-perfect change verbs (_CHANGE_VERB_RE,
  _PERIOD_SIZE_RE, _LOSS_RE, _FALL_ES) (probes q6..q10).
- (2/3) more Language B FIXED: Spanish + cleft paraphrase speakers (_ES_PARAPHRASE_RE, cleft in _PARAPHRASE_RE); task scenario compared in
  the same language + hyphenated counts (_cross_counts, _COUNT_NOUN_RE); bracketed-years durations (_YEARS_PAIR_RE in _durations_since);
  Paper 1 course convention for a task range claim when the request sets none (_task_word_claims); Spanish year words in _event_years;
  'el texto modelo' + elliptic model count (_PROD, _PROD_COUNT_ELLIPTIC_RE). Probes q11..q13.
- Left (reasons): r10 andale-who (pronoun 'it', several speakers), empanadas (agent of an action, not speech), p10 'tres palabras'
  (cross-language count needs verb concept learn/teach), ge-t16 740,000 lower bounds (outside knowledge), c3d-left 12 (channel coordination).
- tests/branches/test_c3e_branches.py written: 86 passed.
## In progress
- tests/branches full run (log wf/phase2/c3e/branches/pytest-branches.log); arena copies under wf/phase2/c3e/branches/arena/
- (2) branch misses (cases_c3e.log / cases_r10.log list of misses)
## Next
- tests file tests/branches/test_c3e_branches.py; arena on copies c1/c2/c3

- README (src/epinoic_logic/branches/README.md) c3e notes added.
- Known failures NOT from branches changes: test_quant_si_reading::test_general_reading_is_byte_identical and
  test_c1_clearance_parsers::test_the_re_referenced_corpus... (History reference item digest; reverting grounded _STOP does not restore it;
  CorePack/parser output, another fixer's paths). Evidence script wf/phase2/c3e/branches/dig.py.
- targeted tests/branches set (15 files): 958 passed. arena c1 done.
- arena on copies: c1 203/203 (155/155), c2 188/188 (144/144), c3 164/176 (128/128; never answered ec-p10b en-p10d ge-p10c mai-p10a) = baseline.
- tests/branches full run: 36 failed, 9827 passed. Failures are NOT from branches paths: 34 in test_c2_hold_remedy2_round2/round3
  (correct-work sentences 'This essay has assessed ...', 'In this essay I have examined ...' now read as self-reports: the selfcert
  fixer's in-progress reader), and 2 reference-digest tests (quant_si_reading, c1_clearance) on a History corpus item (not restored by
  reverting the grounded _STOP change). Handed off in left_undone.
## DONE (task complete; StructuredOutput returned)
