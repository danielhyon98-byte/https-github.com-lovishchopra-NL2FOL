# progress c3e branches fixer
Probe dir: wf/phase2/c3e/branches (common.py, androw.py, mk_c3e.py -> cases_c3e.json, runner/v4.py; cases_r10.json copy)
## Done
- (1) REPRODUCED the and-row lead on the working tree (38/5.5 GJ -> derived-4 ENTAILED, no finding; correct 42 GJ -> COUNTEREXAMPLE + INT-SUBJ-004).
  FIXED: grounded_figures.FUNCTION_WORDS (added to _STOP), geography imports it: _row_words() for _yt_named_row, complement own words,
  _STOPWORDS of attribute-table columns. After: 5.5 GJ -> COUNTEREXAMPLE INT-SUBJ-004; 42 GJ -> ENTAILED. language_b has no table row lookups.
  Tests NOT yet written.
- (2) Geography branch misses FIXED in geography.py (probes q1..q5.tsv): area by result verb/cross-section (_AREA_RESULT, digit-free gate on area
  units); from-to bracket pair '(from 38 mm to 36 mm)'; fact noun synonyms rainfall->rain (_fact_noun); _LABEL_REL_RE widened ('the N of L1',
  absolute amounts with unit, n3); possessive label figure 'Storm 1's 36 mm' in _request_figures (+ _SPREAD_OVER_RE, 's not a noun);
  powers of ten in depth-volume; word-number durations (_DUR_RE hw) and label-subject clock interval; event intervals in words
  (_EVENT_INTERVAL_RE w/hf/h1/h2) + _WORD_DURATION_RE sentence gate.
## In progress
- (2) branch misses (cases_c3e.log / cases_r10.log list of misses)
## Next
- tests file tests/branches/test_c3e_branches.py; arena on copies c1/c2/c3
