# repair clearance-c3e-2 progress
- started; no edits yet
- next: encoded.py _spots superlinear (history parser timeout)
- DONE history linear-time test: tree==HEAD (alone 117.71 s tree vs 117.46 s HEAD; per entry point CPU equal; is_self_report linear 5k..40k) -> load-induced, no change
- DONE round3 turn check KIT-DL-004: cold first clearance ~300 ms wall at HEAD and tree (CPU ~140 ms, warm ~120 ms both) vs 250 ms window -> order/load-induced, no change
- next: gate2 soft-wrapped physics receive_s, stem shapes median
