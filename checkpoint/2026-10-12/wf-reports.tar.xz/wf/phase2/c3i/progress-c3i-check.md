# progress c3i check fixer
- started fresh (no earlier check run). Working tree = fixer's diff (geography.py, insertions.py, README, test_c3h, test_c3i new).
- next: read diff, probe tool br/rc.py, reproduce lens items
