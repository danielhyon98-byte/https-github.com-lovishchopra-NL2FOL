# Handoff from the cross-owner and open-items fixer (round-10 hold remedy c3b)

Progress log: progress-fix-leftovers.md (same directory). Test logs: fixlog/.

## Done in the working tree (not committed; the workflow commits once)

- Kit: COMPATIBILITY.json subject_map pin -> 2026-11-16.1 / c4eeaae4...; generate.py (32), vectors.py (49 written), manifest.py last
  (359 kit files); generate/vectors/manifest --check clean; sha256sum -c clean. Website patch set M: --write-result on a fresh
  disposable export, patched tests 364/361 (the 3 Playwright tests), --verify exact on another export; TESTED.json note records
  what was and was not re-run. If anything under integration/ or src/epinoic_logic/integration/ changes again, re-run
  integration/tools/manifest.py last.
- Public API: api.adapters.selfcert_fold_table (overseer meta_notes no longer imports a translator internal); docs/PUBLIC_API.md
  regenerated (python -m epinoic_logic.api --markdown); overseer compat REQUIRED_API lists it.
- tests/integration/test_readiness.py: the G1 row key follows the contract line 0.6 (rewritten from 0.5).
- Leftovers fixed: R10-K2-LOCAL-GLOSS, R10-OWN-TEXT-ONE-READER, R10-COMB-H3-SET-QUESTIONS, R10-PARSERS-7-SCENARIO-ITEM,
  R10-STEM-H5-REQUEST-IDS, R10-ARG-CIRC-002-EARLIER-LINE, R10-ARG-BARE-PATTERN-SUMMARY, R10-CORE-MAA-T15-M5.3,
  R10-CORE-INTRODUCED-FIGURES, R9-W110-FORMAL-PATH, R10-HARNESS-FIXTURE-SUPPORTING; in part: R10-STEM-H1-ROLES (headings, colon
  labels, Option N), R10-STEM-H4 (wording), R10-CORE-BUG1-EVIDENCE (supporting points), R9-STEM-NAMED-UNDECIDED (G restated,
  k = 2.0 x 40^-1), R10-STEM-REC6-14-SILENT (prose fold 'a fall to about one third').

## For the stabilisation phase (self-certification reader), observed while validating

- selfcert reader false positives that now break non-self-report tests:
  - is_self_certification is True on a LaTeX working line '$d = \sqrt{...}$ M1' (c2 mai-t15 m14.1 becomes NOT_ELIGIBLE role other):
    tests/translate/test_c2_clearance_core_translate.py::test_an_anchor_one_equals_one_is_no_task_fact_and_the_claim_is_withheld[mai-t15-m14.1].
  - 'Reply "approve" and I will write the full evaluation of your design.' read as a verification status (INT-LEDGER-029):
    combinator/tests/test_withheld_work.py::test_through_the_hub_a_deferral_carried_word_for_word_draws_no_finding (and so
    tests/integration/test_combinator_subproject.py).
  - tests/branches/test_quant_si_reading.py::test_general_reading_is_byte_identical_on_the_reference_corpus: 5 corpus texts differ
    ('Wordsworth presents the City ... an exception', 'Expected: ENTAILED ...', elision-mark docstring, Example 1 fixtures doc).
- Input stall: tests/adapters/test_integration_gate2_parsers.py::test_an_english_sentence_of_many_quotations_and_names_is_credited_in_linear_time
  (profile: selfcert/reader.py read_text -> _quote_processing, _tokens), as well as the gate4 mark-labels sweeps.

## Not done (owner or lens decisions; reasons in the run's report)

- R10-STEM-H1-ROLES: each requested result of a part material (needs the request's requested quantities; _part_answers is pinned by
  tests/branches/test_integration_gate2_handoff.py's equivalence oracle, and a paragraph's last working line may be a check line).
- R10-STEM-H4: reading the subscript counts of a formula the task states (a task-formula evaluator).
- R10-CORE-BUG1-EVIDENCE: EVD-SRC-001/005 on label-only premises (pinned at warning by test_unchecked_sources.py and
  test_repair_round2_evidence.py).
- R10-CORE-BUG3-LINKS, R10-CORE-GLOSS-ESTIMATE: semantic judgements no closed rule decides without false positives.
- R10-CORE-PRECISION-EXACTNESS, R10-CORE-PRECISION-FLAGS, R10-CORE-E108-IDENTITY: release-gate semantics (engine E108, model flag
  text deciding release, exactness narrowing); safety review needed.
- R10-STEM-REC6-14-SILENT rest (request-data figure 52->21, share 54%->45%, ess-t16 timber, mai-t16 LaTeX conversion),
  R10-STEM-UNDECIDED-RELATIONS, R9-STEM-FALSE-SUBJ004, R9-STEM-NAMED-UNDECIDED rest (ess-t14 70% share, floor brackets).
- docs/handoff: round 10's finding #18 (Geography and Language B routed to generic) is resolved by D35; the workflow's handoff
  refresh should say so.
