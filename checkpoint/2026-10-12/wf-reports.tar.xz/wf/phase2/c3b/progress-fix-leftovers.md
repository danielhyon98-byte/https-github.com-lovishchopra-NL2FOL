# Progress of fix:leftovers (cross-owner and open-items fixer)
Run 1 started. No earlier progress file.
- [ ] (0) kit regeneration
- [ ] (1) version request / handoffs applied
- [ ] (2) leftovers

## Run 2 (started 00:01 17 Nov; run 1 left no recorded work). Plan: (0) kit regen, (1) version history line + patch M record + docs, (2) leftovers majors first.
- (0) DONE except manifest: COMPATIBILITY subject_map pin -> 2026-11-16.1/c4eeaae4...; generate.py (32), vectors.py (49 written). Patch M: --write-result done (compat.js, subject-map.js, handshake/verdict-binding fixture lines changed); website tests + --verify running in scratch patchM/. TODO: TESTED.json note, then manifest.py LAST (after all integration/ edits), then generate --check, vectors --check, tests/integration.
- (1) version.py history line D35 already present (by selfcert implementer). handoff-selfcert.md does not exist.
- R10-K2-LOCAL-GLOSS DONE (joint.py each-side rule; 2 tests in test_clearance_c3_overseer.py; Decision 177).
