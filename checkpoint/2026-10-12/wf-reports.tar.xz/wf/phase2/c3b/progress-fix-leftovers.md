# Progress of fix:leftovers (cross-owner and open-items fixer)
Run 1 started. No earlier progress file.
- [ ] (0) kit regeneration
- [ ] (1) version request / handoffs applied
- [ ] (2) leftovers

## Run 2 (started 00:01 17 Nov; run 1 left no recorded work). Plan: (0) kit regen, (1) version history line + patch M record + docs, (2) leftovers majors first.
- (0) DONE except manifest: COMPATIBILITY subject_map pin -> 2026-11-16.1/c4eeaae4...; generate.py (32), vectors.py (49 written). Patch M: --write-result done (compat.js, subject-map.js, handshake/verdict-binding fixture lines changed); website tests + --verify running in scratch patchM/. TODO: TESTED.json note, then manifest.py LAST (after all integration/ edits), then generate --check, vectors --check, tests/integration.
- (1) version.py history line D35 already present (by selfcert implementer). handoff-selfcert.md does not exist.
- R10-K2-LOCAL-GLOSS DONE (joint.py each-side rule; 2 tests in test_clearance_c3_overseer.py; Decision 177).
- R9-W110-FORMAL-PATH DONE (delivery_policy._claim_formal unresolved; test in test_clearance_c2b_handoff.py; DELIVERY.md row).
- R10-HARNESS-FIXTURE-SUPPORTING DONE (run_arena stale_support_reason/support_sha256; test in scripts/arena/test_arena_rules.py; README+docstring). Harness check on c2 ll-t15 pending (validation step).
- R10-PARSERS-7-SCENARIO-ITEM DONE (request_parser.is_scenario_sentence; test in tests/channel/test_c3_handoff_channel.py; channel README). Channel baseline before edits: fixlog/ot_before_b.txt (54 failed).
- R10-OWN-TEXT-ONE-READER implemented (own_text.own_text_kinds FORM/FRAME; markdown.own_form_flags thin; sources.own_model_words frames + run guard; tests/channel/test_c3b_own_text_one_reader.py 28 pass; adapters README). Verifying suites: fixlog/ot_after_*.txt vs ot_before_*.txt
- R10-COMB-H3-SET-QUESTIONS DONE (markdown.ANSWER_THESE_LEAD_RE/opens_set_questions shared; generic assign_roles set_question; tests/branches/test_c3b_set_questions.py 17 pass; branches README). combinator test_withheld_work: 1 fail = INT-LEDGER-029 selfcert FP on 'Reply approve' (stabilisation phase).
- R10-STEM-H1-ROLES PARTIAL: section titles (stem parser _section_title), colon label lines (generic _line_heading), each paragraph's result of a multi-paragraph run material (_part_answers), Option N label (pipeline _OPTION_LABEL_RE); tests/stem/test_c3b_stem_roles.py 3 pass. NOT done: results that need the request read (cs-t16 completion times, bi-t16 s1.2, ch-t16 s3.1/s4.2, ch-p10c s4.9, mai-t16 m10.1, maa-t16 m2.2). Suites running: fixlog/r1_*.txt
- R10-STEM-H5-REQUEST-IDS DONE (stem_pack._ClaimMap.relabel claim lists; test in tests/stem/test_c3b_stem_roles.py). gate2 'many quotations' linear failures = selfcert reader (profiled), not own_text.
- R10-STEM-H4 wording DONE (EVD-LACK-001 message); subscript-count part NOT done (needs a task-formula evaluator). R10-CORE-BUG1: EVD-LACK-001 supporting-points part DONE (_restates_supporting, role point/judgement only: e01 pins evidence-role facts); EVD-SRC-001/005 label-only part NOT done (contradicts pinned tests test_unchecked_sources / test_repair_round2_evidence: owner decision). tests/translate/test_c3b_evidence.py.
- R10-ARG-CIRC-002-EARLIER-LINE DONE (argument._cites_earlier_line, non-restatement only; test in tests/engine/test_argument_rerun_repairs.py).
- R10-ARG-BARE-PATTERN-SUMMARY DONE (diag_argument._closing_summary_paragraphs; tests in tests/translate/test_repair_round5_translate.py, verified failing without fix).
- R10-CORE-BUG3-LINKS NOT DONE (semantic leap; no closed rule; see report).
- R10-CORE-GLOSS-ESTIMATE NOT DONE (undecidable 'rewetted' = 'after ditches blocked'; see report).
- R10-CORE-MAA-T15-M5.3 DONE (fidelity.supposition_as_fact flag -> AMBIGUOUS_TRANSLATION; tests/translate/test_c3b_supposition.py).
- harness runs started on left-rounds/c1,c2 (00:34); c3 next
- R10-CORE-INTRODUCED-FIGURES DONE (pipeline.introduced_figures names figures inside premise expressions, note-only; tests/translate/test_c3b_introduced.py). test_c2_clearance_core_translate mai-t15 m14.1 failure = selfcert FP (is_self_certification True on LaTeX 'd = sqrt(...) M1'), stabilisation phase.
- reverted multi-paragraph run rule (gate2 equivalence + check line); killed harness runs (to rerun at end). r1_branches non-selfcert failures examined: quant_si byte-identical (selfcert idioms), c2b handoff check-line & gate2 equivalence fixed by revert.
- docs: tests/README.md c3b section, docs/ARGUMENT_DIAGNOSTICS.md section 21.
- (0) manifest regenerated (359 kit files); generate/vectors/manifest --check clean; sha256sum -c ok
- R9-STEM-NAMED-UNDECIDED partial DONE: restated constant differing from request -> ST-SCOPE-002 warning (relations._leaf_nodes + restated branch); test in tests/stem/test_c3b_stem_roles.py. Other sub-cases (ess-t14 70%, k=2.0x40^-1 undecided, floor) not done. NOTE: f_stem_translate_engine run started before this edit -> rerun tests/stem after.
- R9-STEM-NAMED-UNDECIDED k-40 DONE (checks._written_expression_domain; test). Remaining R9 sub-cases: ess-t14 70% share, floor brackets.
- R10-STEM-REC6-14 partial: prose fold 'a fall to (about) one third' (quant._FRACTION_LEVEL_RE as fold_change); bi-fold slip now INT-SUBJ-001; tests/branches/test_c3b_prose_fold.py. Other slips (request data figure, share, ess timber, mai LaTeX conversion) not done.
- cross-owner: overseer meta_notes imported translator internal selfcert.normalise -> exported api.adapters.selfcert_fold_table, compat REQUIRED_API, docs/PUBLIC_API.md regenerated (python -m epinoic_logic.api --markdown)
- test_readiness G1 row key rewritten 0.5->0.6 (contract bump; stricter to current line); integration: overseer_subproject + readiness now pass.
- 00:46 waiting on f_stem/f_channel/f_overseer; next: rerun tests/stem+tests/branches (quant/stem edits after collection), harness c1-c3, then StructuredOutput. handoff-fix-leftovers.md written.
- scripts/arena/test_arena_rules.py: 114 run, 1 failure from my support binding (s1.3 rests on mutated s1.2) -> assertion rewritten stricter ['s1.2','s1.3']; now passes.
- harness c3: 163/176; only new failure vs baseline en-t16 altered_quotation = selfcert FP (p2-s02 'honest borrows the language of trust' CORE-SELF-001 -> role other). c1,c2 harness started.
- section title refined: needs a table soon after + no operator/arrow/subscript + no leading figure (ch-p10c equations had become other in the first c3 harness). harness c1/c2 killed (stale code); rerun all three at the end. f_stem/f_channel runs also predate these edits -> rerun tests/stem tests/branches tests/channel.
- 00:57 final runs: g_* suites + harness c1,c2,c3 started on final code
- 01:00 colon-heading rule restricted to STEM (stem=True); restarted g_stem/g_branches/g_channel + harness c1-c3 (g_translate and f_overseer kept: unaffected by this edit).
