# progress fix-attack-7
started; reading design + attack-6 kit. Kit dir: scratchpad wf/phase2/c3b/fa7/
- DONE 1: spaced-minus worked check (reader._runon_breaks + _operand_like)
- DONE 2: 'without'/'sin' scoped to own complement: meaning.inert_complement used in meaning._polarity and reader._neg_count (11 misses fixed)
  probe kit: scratchpad fa7/ (cases7.py, probe.py via p.sh, d.sh debug)
- NEXT: split words (N6 normalise), lexicon paraphrases, FPs, Braille, leet 1->l, art cap fail-closed, encodings, then branches
- DONE 3: split words (normalise._pass_split_words); lexicon widened (lexicon.before7.json = baseline copy in fa7): DEFECT crack/buckle/give way...,
  null_result class + meaning readings flip for 'came up empty when ... hunted', OUTCOME hold firm/stacks up, CHECK put to the test, AGREE foot/cross-foot,
  APPROVE greenlight/nod/avalar, anchor 'what precedes', FIDELITY es decimals, m_pos resiste. fresh.json 0 bad. fpscan7.py (base copy in fa7/base) for FP diff.
- DONE 4: paraphrases: stake idiom tokens + stake nouns (reader._stake_frames), awarded score ':'/maximum/full, comply passive (meaning._comply_passive),
  consider/treat imperative = assertion, 'you could ... ASSURE', _subject_constraints 'of the question', eval_asr+modal, lexicon (profe, nativo, columns, command term,
  quality-controlled, a second look, exemplar, gospel, cuentas salen, corregir CHECK, lo firmo, light verbs dar/consider). MISS left: skip-checking, census, case-study stats,
  Spanish grammar ones (left_undone: student-text ambiguity), Braille, leet, encodings.
- NEXT: Braille fold, leet a11, art cap; then FPs (23); then tests; then branches.
- DONE 5: FPs: quoted-word lists as mentions (meaning._raw_mentions groups), _round7_frames (hypothesis object, avoid+defect, third-party possessive object),
  generic assessment statements + case-study report in _not_a_statement, parenthetical subject (_subject_for with/which, _comma_split relative),
  _frame_reporter 'that is' across quote bug, _relay_has_no_reporter_theme source label w/o explicit answer ref. probe: FP 0/56, MISS 10 (deferred), fresh 0.
- NEXT: dev sets + fpscan7, Braille, leet, art cap, tests file
- DONE 6: Braille Grade-1 fold (normalise._BRAILLE, other cells unread), leet lower+digits (a11), art cap removed (selfcert._art_runs reads all lines).
  removed collapse/crumble (FP in ge-t16), removed 'a model answer' idiom (dev FP). generic-statement precedence fixed.
- RUNNING: tests/selfcert full (t_selfcert2.log). NEXT: write tests/selfcert/test_attack_round7.py; overseer/hub path checks; branches.
- DONE 7: tests/selfcert/test_attack_round7.py (140 pass), tests/branches/test_c3b_attack7_selfcert_hub.py (165 pass). repro.py all paths correct.
- RUNNING bg: fa7/runs/a_adapters.log, a_overseer.log. NEXT: geography _anchor stall, then branch misses (geography/language_b) as time permits.
- DONE 8: geography._anchor linear (bounds once per sentence, index range); worked._EXPR_RE + _balanced (general bracketed working),
  bracket-on-next-line / operand-bracket guard (pre-existing bi-t15 FP '100\n(51.2 − 7.0)'), year never a result.
  tests/branches/test_c3b_attack7_branches.py (10 pass).
- RUNNING bg: a_adapters, a_overseer (fa7/runs). NEXT: a_branches run; language_b items if time; docs note; final StructuredOutput.
- DONE 9: language_b _CONNECTOR_LIST_RE words before list (+test); tests/README.md section 'attack round 7'.
- WAITING: fa7/runs a_adapters, a_overseer, a_branches. Then run channel/integrity/stem/translate/contract/e2e/engine (a_rest). Then StructuredOutput.
- DONE 10: APPROVE idioms skip the checking/no need to check (+tests). a_overseer restarted with -c pyproject.toml --rootdir .
- DONE 11: 'These census figures' modifier of own parts (meaning._content_at) + tests
- a_adapters 1226 passed; tests/selfcert 1640 passed (latest code)
- WAITING final runs: a_branches, a_overseer, a_rest (fa7/runs). Then StructuredOutput.
- a_branches 9568 passed
- FINAL: a_rest 14247 passed 1 skipped; a_overseer 13746 passed, 1 failed (compat REQUIRED_API lacked payload_self_certification_spots, imported by meta_notes) -> fixed in overseer compat.py, test_subproject_layout 32 passed.
- Writing StructuredOutput.
