# progress fix-attack-7
started; reading design + attack-6 kit. Kit dir: scratchpad wf/phase2/c3b/fa7/
- DONE 1: spaced-minus worked check (reader._runon_breaks + _operand_like)
- DONE 2: 'without'/'sin' scoped to own complement: meaning.inert_complement used in meaning._polarity and reader._neg_count (11 misses fixed)
  probe kit: scratchpad fa7/ (cases7.py, probe.py via p.sh, d.sh debug)
- NEXT: split words (N6 normalise), lexicon paraphrases, FPs, Braille, leet 1->l, art cap fail-closed, encodings, then branches
- DONE 3: split words (normalise._pass_split_words); lexicon widened (lexicon.before7.json = baseline copy in fa7): DEFECT crack/buckle/give way...,
  null_result class + meaning readings flip for 'came up empty when ... hunted', OUTCOME hold firm/stacks up, CHECK put to the test, AGREE foot/cross-foot,
  APPROVE greenlight/nod/avalar, anchor 'what precedes', FIDELITY es decimals, m_pos resiste. fresh.json 0 bad. fpscan7.py (base copy in fa7/base) for FP diff.
- DONE 4: paraphrases: stake idiom tokens + stake nouns (reader._stake_frames), awarded score ':'/maximum/full, comply passive (meaning._comply_passive),
  consider/treat imperative = assertion, 'you could ... ASSURE', _subject_constraints 'of the question', eval_asr+modal, lexicon (profe, nativo, columns, command term,
  quality-controlled, a second look, exemplar, gospel, cuentas salen, corregir CHECK, lo firmo, light verbs dar/consider). MISS left: skip-checking, census, case-study stats,
  Spanish grammar ones (left_undone: student-text ambiguity), Braille, leet, encodings.
- NEXT: Braille fold, leet a11, art cap; then FPs (23); then tests; then branches.
- DONE 5: FPs: quoted-word lists as mentions (meaning._raw_mentions groups), _round7_frames (hypothesis object, avoid+defect, third-party possessive object),
  generic assessment statements + case-study report in _not_a_statement, parenthetical subject (_subject_for with/which, _comma_split relative),
  _frame_reporter 'that is' across quote bug, _relay_has_no_reporter_theme source label w/o explicit answer ref. probe: FP 0/56, MISS 10 (deferred), fresh 0.
- NEXT: dev sets + fpscan7, Braille, leet, art cap, tests file
