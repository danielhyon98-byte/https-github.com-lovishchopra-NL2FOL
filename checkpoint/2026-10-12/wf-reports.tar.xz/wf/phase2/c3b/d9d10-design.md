> ORCHESTRATOR DECISION (16 Nov, before the build): OPTION A of the subject-map question is approved. Change only the
> branch value of the three service-only rows (Geography and the two Spanish rows) and the map version; website routes,
> environments, provisional flags and kit tags stay unchanged. The kit is regenerated ONCE, with its own tooling, by the
> cross-owner fixer after both implementers (for this change and the policy bump together).

# D9/D10: translator branches for Geography and Language B (Spanish). Design

Designer's output for this run. Nothing in the repository was edited. The baseline numbers below were measured on the shared
working tree as it stood (branch `claude/z3-verification-engine-plan-nk3luq`, HEAD `9c891210`). Measurements:

- the harness, run on copies of rounds c1, c2 and c3 (`scripts/arena/run_arena.py`);
- a direct probe of today's generic branch on every recorded `ge-*` and `sp-*` answer.

The per-record baseline is in `d9d10-baseline.json` beside this file.

Scope: this design adds translator branches only. It changes no website route, no environment of a subject-map row and no kit
tag. Section 1 names one unavoidable change to the subject map's `branch` column, which needs the orchestrator's yes.

---

## 0. Summary

| | Geography | Language B (Spanish readers) |
| --- | --- | --- |
| Branch key | `geography` | `language_b` |
| Display name | `Geography` | `Language B and ab initio (Spanish readers)` |
| Profile keys | `("geography",)` (unchanged profile) | `("language_b",)` (unchanged profile) |
| Parser | `GenericTextParser(agent_id="geography-specialist")`: today's parser, byte for byte | `GenericTextParser(agent_id="language-b-spanish-specialist")`: today's parser, byte for byte |
| Packs | `(CORE, GeographyPack())` | `(CORE, LanguageBPack())` |
| Hub hooks | none | none |
| New modules | `branches/geography.py` | `branches/language_b.py`, `branches/spanish_lexicon.py` |
| Shared gate | the core pack's CORE-SELF-001 reader (`adapters.self_report`), first pack of the branch, never bypassed | the same |

Principles:

- **The parser does not change.** Claim ids, texts, roles, materiality, supports and source references stay exactly what the
  generic branch delivers today. So every recorded translation fixture (keyed by claim id) still binds, and no harness count can
  drop because of a re-parse.
- **The subject knowledge lives in the packs.** Each pack adds deterministic readers and engine problems. Every new determination
  reaches the receipt through codes that already exist:
  - INT-SUBJ-001 (error) or INT-SUBJ-004 (warning), on a failed branch formal check;
  - CORE-QNT-001 (warning), for a Geography rate that was read but could not be built;
  - CORE-SRC-002 (info), for a figure credited to an unsupplied map or graph.
- **No new receipt code family is introduced.** The overseer's code tables, its knowledge pack 2.1 and `PINNED_PACK_DIGESTS`
  therefore stay untouched (section 8.4).

What changes in existing code:

- `registry.py`: two branch entries.
- `packs.py`: `_worked_branch` and `pack_decided_equations` learn the two new keys, so worked equations stay decided and are never
  named undecided twice.
- The subject map's `branch` column for the three service-only rows (section 1).
- Test rewrites, all equivalent or stricter (section 10.3).

Version impact: no component version must change for D9/D10 (section 13; request file `d9d10-version-request.md`).

---

## 1. Decision needed from the orchestrator: the subject map's `branch` column

The subject map pins, per row, the branch the hub routes the subject to:

```
geography          "Geography"            branch "generic"
spanish-b          "Language B: Spanish"  branch "generic"
language-b-spanish "Language B: Spanish"  branch "generic"
```

That pin is enforced twice, and both checks fail as soon as Geography or Language B routes to its own branch:

- `src/epinoic_logic/integration/preflight.py`, `subject_map()`: `hub.branch_for(e["subject"]) != e["branch"]` raises
  `KIT-HS-010` ("the subject ... routes to another branch than the map says"). The service then refuses to start.
- `tests/integration/test_generated.py::test_the_subject_map_digest_is_pinned_and_every_branch_is_the_hubs` asserts the same.

These checks must not be weakened. So "proper branches" and "no subject-map change at all" cannot both hold. The options:

- **A (recommended).** Change only the `branch` field of those three rows (`geography`, `language_b`, `language_b`). Leave
  `route` (null), `environments` (`["service"]`), `provisional` (true) and the slugs as they are, and bump the map version
  (`2026-10-17.2` → `2026-11-16.1`).
  - Then regenerate the kit copies once with `python integration/tools/generate.py`:
    - `src/epinoic_logic/integration/compat.py`;
    - `integration/website/src/verify/compat.js` and `integration/website/src/verify/subject-map.js`;
    - the `subject_map` pin in `integration/COMPATIBILITY.json`;
    - the handshake vectors (`integration/tools/vectors.py`; 24 files under `integration/vectors/handshake/` embed the map's
      digest);
    - `integration/MANIFEST.sha256`.
  - **No website route changes, and no kit tag is created or moved.** The tag `integration-kit-v1` has not been published
    (`docs/handoff/NEW-SESSION-Z3-WEBSITE-LAUNCH.md`: "the kit tag integration-kit-v1 does not exist yet"), so the first
    published tag simply carries the new map. The D9/D10 record's sentence "Both stay service-only rows of the subject map,
    which is unchanged" is amended by the new record D35 (section 12).
  - The website patch set M records the hash of `src/verify/compat.js` and `src/verify/subject-map.js` in its `RESULT.sha256`.
    Changing data-only copies has a precedent (`integration/website/patches/M/TESTED.json`, "re-run after COMPATIBILITY.json's
    ... changed src/verify/compat.js (data only ...): only the src/verify/compat.js line of RESULT.sha256 changed").
  - **Coordination.** The self-certification implementer's `POLICY_VERSION` bump already forces a change to
    `COMPATIBILITY.json` `components.policy` (preflight `KIT-HS-002`). That means the same regeneration and the same `compat.js`
    line in any case. Do both changes in one regeneration at the end. Then either re-run the patch set M record, or record it
    as not re-run.
- **B (fallback if the map must not change).** Keep the branch key `generic` for these subjects and let `GenericPack` dispatch
  internally to the Geography and Language B readers by profile key. This needs no kit change, but it is not a proper branch: the
  receipt still says `generic`, and round 10's finding #18 ("route to the generic branch") stays formally open. Not recommended.

The rest of this design assumes A.

---

## 2. What the generic branch does today (the baseline to keep)

### 2.1 Harness, rounds c1 to c3 (copies, current tree)

Source: `d9d10-baseline.json`.

| Round | Transport (all) | Geography/Language B records | Of them functional |
| --- | --- | --- | --- |
| c1 | 203/203 | 15 | 15 |
| c2 | 188/188 | 20 | 20 |
| c3 | 164/176 | 25 | 22 |

The three non-functional c3 records are `ge-p10c`: it was planned and never answered, and its relay never ran. That is unrelated
to routing.

Genuine records (status `ACCEPTED_WITH_FINDINGS` on every one):

| Answer | Error/warning codes | Formal checks (all ENTAILED) | Claims | Fixtures served | Translation outcomes |
| --- | --- | --- | --- | --- | --- |
| c1 `ge-t14` | INT-REQ-004, INT-REQ-006 | generic-worked-1..3 | 54 | 24 | ENTAILED 10, UNSUPPORTED 13, NOT_ELIGIBLE 4, AMBIGUOUS 1 |
| c1 `sp-t14` | INT-REQ-006, INT-REQ-010 | none | 25 | 11 | ENTAILED 5, UNSUPPORTED 6 |
| c2 `ge-p9c` | INT-ARG-001, INT-REQ-006 | core-quant-1,2; generic-worked-1..6 | 25 | 19 | ENTAILED 7, INVALID 6, AMBIGUOUS 6, NOT_ELIGIBLE 1 |
| c2 `ge-t15` | INT-REQ-006 | core-quant-1..5; core-figure-1..4; generic-worked-1..4 | 26 | 18 | ENTAILED 10, AMBIGUOUS 5, UNSUPPORTED 2, INVALID 1 |
| c2 `sp-t15` | INT-REQ-006 | none (constraints c1, c2 true) | 32 | 7 | UNSUPPORTED 7, NOT_ELIGIBLE 1 |
| c3 `ge-t16` | INT-REQ-004, INT-REQ-006 | none (constraints c1, c2 true) | 24 | 18 | UNSUPPORTED 10, ENTAILED 6, AMBIGUOUS 2 |
| c3 `sp-p10d` | INT-REQ-006 | none (constraints c1, c2 true) | 27 | 3 | INVALID 2, UNSUPPORTED 1 |
| c3 `sp-t16` | INT-REQ-006, INT-REQ-010 | core-marks-1..4 | 30 | 3 | INVALID 1, ENTAILED 1, AMBIGUOUS 1 |

Every mutation variant of these answers is functional:

- invented quotation (single and double), altered quotation, self-certification, wrong arithmetic and chronology error;
- the wrong-arithmetic and chronology variants by INT-SUBJ-001 from the core pack.

### 2.2 What produces those results today, and must be kept

1. **`GenericTextParser`** with the hub-stated agent id: ids `g{paragraph}.{unit}@{agent}`, roles, materiality, supports, notes
   read as `other`, part labels and mark annotations dropped.
2. **`CorePack()` in the general reading.** Every check of it runs unchanged: the shared self-certification gate (CORE-SELF-001),
   quotation grounding, misattributed quotations, unverifiable quotations, unsourced world figures (CORE-SRC-002), undecided
   arithmetic and chronology (CORE-QNT-001, CORE-CHR-001), quant problems (`core-quant-N`), chronology problems, marks
   (`core-marks-N`), supplied-table and supplied-text figures (`core-figure-N`), prose arithmetic (`core-prose-N`), support
   cycles (CORE-STR-001) and request-model extrapolation (ST-RANGE-001).
3. **`GenericPack`.** GEN-STR-001 (a claim citing unknown supporting claims), and every worked equation `worked.py` reads, as
   `generic-worked-N`:
   - lines (`worked_problems`);
   - parts in brackets (`breakdown_problems`);
   - clock times (`clock_problems`);
   - payback periods (`payback_problems`).

   The c2 `ge-p9c` lag times, the cross-sectional area and the discharge, and the c2 `ge-t15` coal supplies and percentage change,
   are decided only here.
4. **`pack_decided_equations`** returns the decided chains for the generic branch (via `_worked_branch(report) == "generic"`), so
   the core pack's undecided reader does not also name those lines CORE-QNT-001.
5. **The channel**, which is shared and unchanged:
   - request items, word bounds read in Spanish ("Escribe entre 450 y 600 palabras", `request_parser._RANGE_LB_RE`) and declines;
   - INT-REQ-003, -005, -006 and -010;
   - cross-agent checks.

   It has no hub hooks for these subjects.

### 2.3 What the generic branch misses (probe on the current tree)

Each of these lines crosses the hub today with **no finding and no check**, not even CORE-QNT-001:

- `With 2.4 million people on 1,200 km², the density is 2,000 people per km².`
- `... a population of 48,000 and an area of 12 km², a density of 4,000 people per square kilometre.`
- `The crude birth rate is 24 per 1,000 and the crude death rate 9 per 1,000, so the natural increase rate is 1.5%.`
- `Births: 4,800 in a population of 200,000, a crude birth rate of 24 per 1,000.`
- `At a growth rate of 2% a year, the population will double in about 35 years.`
- `The country's GDP of $1.2 trillion and its 60 million people give a GDP per capita of $20,000.`
- `The mean of the three counts (210, 218 and 214) is 214.`
- `Site 4 had a mean pedestrian count of 79 per 10 minutes.` (the supplied Kellsbridge table: 97). The table has no year column,
  and `grounded_figures` reads only tables keyed by year.
- `According to the table, Site 4 had a mean pedestrian count of 79 ...` (same).
- `The table shows twelve sites.` (ten rows).
- Spanish: `Según el texto, en 2015 quedaban 221 vecinos.` (text: 212) and `La escuela volvió a abrir con quince alumnos.` (text:
  catorce). Today a Spanish restatement is read only when its exact words surround the figure (`1.520 habitantes en 1960` is
  read, as `core-figure`), and Spanish number words are never read as figures there.

The written equivalents (`Population density = 2,400,000 ÷ 1,200 km² = 2,000 people per km²`, `Natural increase = (24 − 9) ÷ 10
= 1.5%`, `Doubling time = 70 ÷ 2 = 35 years`, `GDP per capita = $1.2 trillion ÷ 60 million = $20,000`) are already decided by the
worked reader. They must stay decided on the new branch.

---

## 3. The SubjectBranch entries (`branches/registry.py`)

```python
from .geography import GeographyPack
from .language_b import LanguageBPack

BRANCHES = [
    ...,  # english, history, psychology, economics, business_management unchanged
    SubjectBranch(key="geography", display_name="Geography", profile_keys=("geography",),
                  parser_factory=_generic_parser("geography-specialist"), packs=(CORE, GeographyPack()),
                  notes="Data-Calculation-Explanation-Case study; population, density, rates per 1,000, change, growth and doubling "
                        "time, per-capita figures, fieldwork means and samples, and figures read from supplied tables decided by the "
                        "engine; worked equations as on the generic branch."),
    SubjectBranch(key="language_b", display_name="Language B and ab initio (Spanish readers)", profile_keys=("language_b",),
                  parser_factory=_generic_parser("language-b-spanish-specialist"), packs=(CORE, LanguageBPack()),
                  notes="Text type-Register-Message; the specialist's claims about a production (its word count, its range, the forms "
                        "and connectors it quotes, the address forms it names, the items it lists) checked against that production; "
                        "Spanish numerals, number words and credits read; worked equations as on the generic branch."),
    ...,  # sciences, mathematics, computer_science unchanged
    SubjectBranch(key="generic", ...),  # unchanged entry; by default it now serves Philosophy, Anthropology, World Religions,
                                        # the arts, TOK, the Extended Essay and unrecognised subjects
]
```

- **Profile keys.** `geography` and `language_b` leave the generic branch's reach. The generic branch keeps `("unknown",)`, plus
  every profile no other branch serves (it is the registry default). The profile set reaching `generic` is then:
  - philosophy, social_anthropology, world_religions;
  - visual_arts, music, theatre, film, dance;
  - tok, extended_essay;
  - unknown.
- **Agent ids.** The parser's default agent id is a fallback only. The hub passes the stated sender, so claim ids keep the
  sender's agent (`g4.2@geography-specialist`, `g1.3@language-b-spanish-specialist`). A report sent as `spanish-b-specialist` (the
  harness roster's slug) is qualified with that id, exactly as today.
- **One branch for all Language B courses.** French B, German B, Mandarin B and ab initio share the `language_b` branch. The
  Spanish readers act only on Spanish text (section 6.1). Other Language B courses get the language-neutral checks: word
  counts, ranges, quoted forms, listed counts and worked equations. Nothing Spanish fires on them.
- **No hub hooks.** The channel's word measure (`request_parser.measure_answer_words`) already sets notes aside and reads Spanish
  and French bounds. A `word_count_view` hook would change INT-REQ-005 on recorded answers, and nothing requires it. The packs
  measure productions themselves with the channel's own counter (`request_parser.count_words`), so pack and channel never count
  words differently.

---

## 4. The parser

`GenericTextParser`, unchanged (sections 0 and 3). The model text's sentences keep the roles the generic parser gives them today
(the c2 `sp-t15` body paragraphs: `point`/`analysis`).

Why not re-role a model text as a performance rather than assertions: changing roles changes materiality and translation
eligibility. Recorded fixtures would no longer be served (`TRANSLATIONS_LOST` would grow), outcome counts would move, and the
owner asked that no recorded answer lose a functional transmission.

The **roles of a model text** are therefore read by the Language B pack, as regions (section 6.3), and used only by its checks.
A later re-roling, with its harness impact measured, is recorded as a follow-up (section 15).

---

## 5. The shared gates the new branches consult

- **The self-certification gate.** `CORE` (`CorePack()` in the general reading) is the first pack of both branches. Its
  `_self_certification` is the one shared reader (`adapters.self_report`: the answer as written, line by line and cell by cell,
  and the report's fields). Neither new pack reads or exempts self-reports:
  - no pack filters, demotes or re-words a CORE-SELF-001 finding;
  - no model-text region exempts a sentence from it. A sentence inside a model article that the gate names stays named.
  - The channel's and the overseer's gates (INT-HANDOFF-006, `meta_notes`, delivery policy) read the answer independently of the
    branch and are untouched.

  The self-certification implementer's reader change ("read by meaning") reaches these branches the moment it lands, because they
  call it through the core pack.
- **Pack isolation.** `SubjectBranch.run_packs` guards both packs (PACK-INTERNAL-001 plus BR-INTERNAL-001). Each reader inside a
  pack is also guarded on its own (the core pack's `_guarded` pattern): a failing reader adds BR-INTERNAL-001 naming the pack and
  stage, and the other readers still run.
- **The channel's request reading** (items, bounds, declines) and INT-REQ-003/-010 quotation checks (« » included) are unchanged.

Test (section 10.1, `test_every_branch_runs_the_shared_core_pack_first`): in `default_registry()`, every branch's `packs[0]` is a
`CorePack`. No pack class other than `CorePack` defines a method whose name contains `self_cert`. For every phrasing set in
`tests/branches/c2_hold_texts.py`, the CORE-SELF-001 findings on Geography and Spanish B equal those the core pack gives the same
report.

---

## 6. The Language B pack

### 6.1 Spanish detection and the lexicon module (`branches/spanish_lexicon.py`)

The module holds pure data plus bounded, linear readers. Nothing in it evaluates agent text.

- **`is_spanish(text) -> bool`.** One pass over the first 20,000 characters. A text is Spanish when:
  - at least 8 tokens fall in a closed set of Spanish function words (de, la, que, el, en, los, las, del, por, una, con, para, es,
    se, su, al, lo, como, más, pero, muy, también, porque, está, son), and those make up at least 12 % of the tokens; or
  - it holds `¿` or `¡`, at least 3 times in all, with at least 4 function-word hits.

  The paragraph-level version, `spanish_paragraphs(text)`, returns the indices of Spanish paragraphs. The Spanish readers act
  only when `is_spanish` holds for the region they read, or when the subject label names Spanish (`spanish` or `español`; the
  agent id `language-b-spanish-specialist` or `spanish-b-specialist`).
- **Numerals, `spanish_numeral_readings(token) -> frozenset[Fraction]`.** Each token gives every reading it can have:
  - `1.250` gives {1250} in Spanish text and {1.25} in English text; in text of unknown language it gives both;
  - `2,5` gives {2.5};
  - `1,250` is ambiguous in Spanish, so {1.25, 1250};
  - a thin space or a no-break space groups thousands (`1 250`).

  A check holds when **any** reading holds and fails only when **none** does. This is the worked reader's "every reading" rule.
- **Number words, `spanish_number_figures(text)`.** The one reader already in the tree:
  `from ..integrity.ledger import _spanish_word_figures` (round 9/10 ledger: `dos mil trescientos cuarenta y cinco` = 2345, a
  small count before a count noun). It is re-exported under a public name. The ledger file is not edited. Promoting the reader
  into this module is a follow-up for the core owner.
- **Credits, `SPANISH_CREDIT_RE`.** "según el texto / el artículo / el autor / la autora / el primer párrafo", "el texto dice /
  indica / afirma", "como dice el texto", "en el texto", "(línea N)", "(párrafo N)". These are read like grounded_figures'
  English `_TEXT_CREDIT_RE`.
- **Connectors.** A closed tuple of about 60 Spanish connectors with their function: addition (además, asimismo, también),
  contrast (sin embargo, no obstante, en cambio, aunque, mientras que, por el contrario), cause (porque, ya que, puesto que,
  debido a), consequence (por lo tanto, por eso, así que, por consiguiente, de este modo, así), sequence (en primer lugar,
  primero, luego, después, por último, finalmente), example (por ejemplo, es decir), conclusion (en conclusión, en resumen,
  para concluir).
- **Text types.** A closed table: Spanish name and aliases, register expected, and layout parts. It covers the following, each
  with the Spanish name a request uses:
  - formal letter (carta formal), informal letter (carta informal), letter to the editor (carta al director);
  - formal and informal email (correo electrónico);
  - article (artículo, artículo de opinión), blog post (entrada de blog), diary entry (diario);
  - speech (discurso), leaflet (folleto), report (informe), interview (entrevista), review (reseña), proposal (propuesta).

  Layout parts:
  - greeting: `Estimado/a ...:`, `Querido/a ...:`, `¡Hola ...!`;
  - closing formula: `Atentamente`, `Un cordial saludo`, `Un abrazo`, `Besos`, `Hasta pronto`, `Saludos cordiales`;
  - headline: a first short line with no final full stop;
  - byline: `Por ...`;
  - date line: `<Lugar>, <día> de <mes> de <año>`;
  - email header: `Asunto:`, `Para:`;
  - audience address: `Queridos compañeros`, `Señoras y señores`;
  - thanks: `Gracias por su atención`.

  The founder's knowledge base describes these conventions. The table is written in this module's own words and records only
  the forms, never copied text.
- **Address forms.** Unambiguous markers only:

  | Address | Markers |
  | --- | --- |
  | tú | tú, contigo, the clitic `te` (word-bounded), the possessives `tu` and `tus` before a noun |
  | vos | vos |
  | usted | usted, Ud., Vd. |
  | vosotros | vosotros, vosotras, os (word-bounded), vuestro/a/os/as; the verb endings -áis, -éis, -ís on a word of at least four letters that is not in a small stop list (país, maíz, raíz, ...) |
  | ustedes | ustedes, Uds. |

  `su`, `sus`, `le`, `les` and third-person verb forms are ambiguous, so they are never markers.
- **Inverted marks.** `inverted_mark_spans(text)` pairs each `¿`/`¡` with the next `?`/`!` in one pass. The readers use it to skip
  questions and exclamations, so a question is never read as a claim about a production.

### 6.2 Which answers the pack reads

`LanguageBPack.checks(report, request_text)` and `formal_checks_for(report, request_text)` classify the task once (memoised per
report digest):

- `writing`: task type `writing_task`; or the request asks for a text type ("Escribe un/una <tipo>", "write a/an <text type>",
  "Paper 1" with a writing verb); or the answer holds a model region (6.3).
- `marking`: task type `marking_feedback`/`feedback`, or the request asks to mark or correct a supplied text the student wrote.
- `reading`: task type `reading_comprehension`, or the request supplies a text and asks numbered questions about it ("Read the
  article and answer", "Según el texto ...", "Indica", "¿Verdadero o falso?").
- `notes`: anything else (e.g. c3 `sp-p10d` language notes).

### 6.3 The roles of a model text (regions)

`model_regions(text) -> Regions`, one pass over the paragraphs of the answer as written:

- **`disclaimer`**: a paragraph (often in italics) that says the text is practice or fictional. Example: `*Texto escrito para
  practicar ...*`.
- **`model`**: the longest run of consecutive Spanish paragraphs in a writing task. Within it:
  - `headline`: first line, up to 14 words, with no final full stop;
  - `byline`: `Por ...`;
  - `greeting` and `closing`/`signature`: from the text-type table;
  - `body`: the rest.
- **`inline_model`**: a sentence led by `Model:`, `Modelo:` or `Model (... ):` with a quoted Spanish sentence (c3 `sp-t16` g1.28),
  or a "level-up" example.
- **`meta`**: English paragraphs before or after the model: word-count statements, assumptions, next step, sources. These are read
  with `markdown.is_answer_note` and `opens_note_paragraph` where those apply.
- **`feedback`**: in a marking task, the English feedback with its quoted student forms.
- **`student_text`**: in a marking task, the supplied document the student wrote, when exactly one supplied document is the
  student's (author `Student`, or title `My ...`, or the request's "my email / my text / pasted below").

The regions are used by the pack's checks only (6.4). They never change a claim's role, materiality or support. They never
exempt anything from a core check.

c2 `sp-t15` reads as follows. Paragraph 0 is the disclaimer. Paragraphs 1–9 are the model: headline `Turismo y vecindad: ¿un
negocio para todos?`, byline `Por Marta Ruiz Salas, 2.º de Bachillerato`, then the body paragraphs. Paragraph 10 is meta.

### 6.4 The Language B checks

All are engine problems on the branch's formal-check path, kind as named, policy `linear`. The measured counts are premises
grounded `supplied_text` and verified: deterministic measurements, exactly as the channel's word-bound problems
(`bus._formal_bound`) ground theirs. The stated figures are the conclusion's terms. Check ids are `language-b-<kind>-N`.

| Kind | Reads | Problem (conclusion) | Failure |
| --- | --- | --- | --- |
| `lb_word_count` | A word count the answer states about a production: "Word count: about 513 including headline and byline (about 499 in the body)", "Your email is about 300 words", "The text is 498 words long", "Recuento: 498 palabras", "(498 palabras)". The production is the one the clause names: "your email/text/draft/composition/redacción" is the student text; "including headline and byline" is the whole model; "in the body" is the model's body; otherwise the model (writing task) or the whole answer minus meta. | `measured` (`count_words` of the region) within the tolerance of the stated N: exact N, `\|m − N\| ≤ max(5, 0.02·N)`; "about/approximately/around/roughly/unos/alrededor de/aproximadamente", `\|m − N\| ≤ 0.10·N`. When the region is ambiguous (two candidate regions), the conclusion is the disjunction over the candidates. | INT-SUBJ-001 (error) when the region is unique; INT-SUBJ-004 (warning) when only a disjunction could be built |
| `lb_word_range_claim` | A claim that a production lies inside (or outside) a range: "inside the 450–600 range", "within 250–400 words", "so the length is right", "está dentro del límite". The range is the one the claim states, else the request's bound (`extract_constraints`), else the course range below. "the length is right" reads the range the answer states nearest before it (c3 `sp-t16`: "within 250–400 words"). | `lo ≤ measured ≤ hi` (or its negation for "outside / too long / too short") | INT-SUBJ-001 |
| `lb_course_word_range` | A **convention**, built only when (a) the task is `writing`, (b) the request states the course level (SL/HL, NM/NS, "nivel medio/superior") and Paper 1 (or a writing task), and (c) the channel extracted **no** word bound from the request. The working rule is SL 250–400 and HL 450–600 for the model region. In a `marking` task it is built only for a specialist's own claim about length, through `lb_word_range_claim`. | `lo ≤ measured ≤ hi`; the description says "a course convention (working rule), not a bound the request set" | INT-SUBJ-004 (warning) |
| `lb_quoted_form` | A claim that a production contains a form: "the model uses «sería necesario que ... limitara»", "connectors such as «sin embargo» and «además»", "you used «es preciosos»", "en tu texto aparece «...»". The production is the one the clause names (model, inline model or student text). Each quoted form, read with `markdown.find_quotation_spans` (« », “ ”, " ", ‘ ’), and each connector named in italics or quotation marks. | `occurrences(form, production) ≥ 1` (a measured premise per form; forms compared after `adapters.markdown` form normalisation: case of the first letter, typographic quotes, diacritics kept) | INT-SUBJ-004 (warning). A quoted form of a **supplied** text that the text lacks is already INT-REQ-003 at the channel; the pack does not repeat it for supplied texts, only for the model and inline model, which no channel check covers. |
| `lb_address_form` | A claim naming the address form a production uses: "you write to the family with vosotros forms («¿Cómo estáis?», «vuestra casa»)", "the email uses usted throughout", "keeps tú consistently", "mezcla tú y usted". | (a) For each example the claim quotes: `markers(example, named form) ≥ 1`. (b) For "throughout/consistently/en todo el texto": `unambiguous markers of any other singular-reader form = 0` in the production. Only unambiguous markers count (6.1), so an ambiguous form never makes the check fail. | INT-SUBJ-004 |
| `lb_listed_count` | A count the answer states for items it lists itself: "fix the six points" or "six corrections" against the arrow-correction lines (`«x» → «y»` / `"x" → "y"`) of the answer; "three connectors" against the connectors it names in that sentence; "two measures" in a model text against nothing (a model's own content is never counted). English and Spanish number words. | `listed = N` | INT-SUBJ-004 |
| `lb_percent_change` | Spanish change phrases with their from-to pair in one clause: "pasó de 1.250 a 212 habitantes, una caída del 83 %", "aumentó un 20 %", "se redujo a la mitad", "el doble", "el triple". The pair is read with `spanish_numeral_readings` and number words. | As `quant`'s `percent_change` / `fold_change` (the same `_within` tolerance and precision rule, `PRECISION_RULE`) | INT-SUBJ-001 |
| `supplied_figure` (Spanish) | In a `reading` task, a figure in a numbered answer is credited to the supplied text (the course's convention: "answer from the text"). In any task, a figure after a Spanish credit (`SPANISH_CREDIT_RE`). The figure (a numeral or number words) with its noun (`habitantes`, `vecinos`, `alumnos`, `puestos`, ...) is read against the one figure the text states beside the same noun stem, and the year when the clause states one. Figures inside quotation spans are skipped, because quotations are already checked verbatim (INT-REQ-003). | `figure = cell` under grounded_figures' match rule (half a unit of the last digit written), every numeral reading | INT-SUBJ-001 when credited (or a reading-task answer); INT-SUBJ-004 when uncredited, as grounded_figures does |
| `worked_arithmetic` | Every worked equation, as on the generic branch (`_worked_checks(report, "language-b-worked", ...)`) | unchanged | unchanged |

Structural finding:

- **GEN-STR-001** (error): a claim citing unknown supporting claims. The generic branch's check is kept verbatim. Factor
  `GenericPack.checks` into a module function `unknown_supports(report)` that all three packs call.

What the pack does **not** do:

- It does not judge register, accuracy or text-type fit. The profile's `cannot_check` names "linguistic accuracy or register",
  and those judgements belong to the subject evaluator and the overseer.
- The text-type table and the ¿/¡ pairing are readers only. They find the model's parts and skip questions. They are never
  findings about the quality of the Spanish.
- It reads only the closed set of grammar claims above. Claims such as "quema is the present indicative" or "the subjunctive after
  espero que" are not read: no deterministic morphology is attempted. They stay with the translator and the evaluator as before.

### 6.5 Expected outcomes on the recorded Spanish answers (to be pinned in the tests)

Measured with `request_parser.count_words`:

- **c2 `sp-t15`.** The model, with headline and byline, measures 514 (`2.º` counts as two tokens; 513 by whitespace). The body
  measures 499.
  - `lb_word_count` × 2, ENTAILED: about 513 against 514; about 499 against 499.
  - `lb_word_range_claim` "inside the 450–600 range", ENTAILED.
  - No `lb_course_word_range`: the request states 450–600, which the channel checks (c1, c2 true).
  - Nothing else.
- **c3 `sp-t16`.** The student text measures 296.
  - `lb_word_count` "about 300 words", ENTAILED.
  - `lb_word_range_claim` "so the length is right" in 250–400 (the range stated in g1.2), ENTAILED.
  - `lb_listed_count` "the six points" against 6 correction lines, ENTAILED.
  - `lb_address_form`, ENTAILED: (a) «¿Cómo estáis?» (-áis) and «vuestra casa» (vuestra) carry vosotros markers; (b) "you use it
    consistently": no unambiguous usted/ustedes/tú marker addressed to the family.
  - `core-marks-1..4` unchanged.
- **c1 `sp-t14`.** Reading task. `supplied_figure` (Spanish), ENTAILED, for `1.250 habitantes` (1960), `212 vecinos` (2015) and
  `doce puestos`. The quoted «con catorce alumnos» is skipped (inside a quotation). The English "Why:" lines are read with the
  English credit rules only.
- **c3 `sp-p10d`.** Language notes. No new check: no word-count statement, and the address claim «échale» "(tú) imperative" carries
  no unambiguous marker, so nothing is built.

No new error or warning finding on any recorded Spanish answer. The INT codes, statuses and constraint results are exactly those
of section 2.1.

---

## 7. The Geography pack (`branches/geography.py`)

### 7.1 Readers (closed grammar, units and scale words)

- **Figures.** As `worked.py`/`quant.py` read them:
  - thousands groups, decimals, scientific notation;
  - scale words: thousand, million, billion, trillion, and m, bn, k after a currency;
  - currency signs;
  - signs, per cent, `per 1,000`/`per 1000`/`per thousand`/`‰`.
- **Areas.** `km²`, `km2`, `sq km`, `square kilometre(s)/kilometer(s)`, `ha`, `hectare(s)`, `m²`, `square metre(s)`. Conversions
  are carried into the IR as exact factors: 1 km² = 100 ha = 10⁶ m².
- **Population nouns.** people, persons, inhabitants, residents, population. **Event nouns**: births, deaths, live births, infant
  deaths, migrants, arrivals, departures.
- **Approximation words.** about, around, roughly, approximately, approx., nearly, almost, some, c., ca., circa, ~. They widen the
  tolerance to 5 %, as `grounded_figures.RATIO_APPROX` does.
- **Comparative bounds.** more than, over, at least, fewer than, less than, under, up to. They turn a value into a one-sided bound
  under interval semantics.

### 7.2 Engine checks (kind, problem, failure)

All are linear (the denominators are stated constants), with check ids `geography-<kind>-N` and defect `stem_arithmetic_slip` for
arithmetic kinds and `source_mismatch` for figures read from supplied data. Tolerance is the worked rule
`|C − S| ≤ h + τ·|C|`: h is half a unit of the last digit written of the stated figure, τ = 1 % (5 % with an approximation word).

| Kind | Statement read (one sentence, or its clause and the clause before it in the same paragraph) | Problem | Failure |
| --- | --- | --- | --- |
| `geo_density` | A density with a population P and an area A: "with 2.4 million people on 1,200 km², the density is 2,000 people per km²", "a population of 48,000 and an area of 12 km², a density of 4,000 people per square kilometre". The density's area unit is converted to A's unit. | `D = P / A` (scaled) | INT-SUBJ-001 |
| `geo_rate_per_thousand` | A crude rate with its count and population: "4,800 births in a population of 200,000, a crude birth rate of 24 per 1,000"; infant mortality per 1,000 live births. | `R = 1000 · N / P` | INT-SUBJ-001 |
| `geo_natural_increase` | A birth rate B and death rate D per 1,000 and a natural increase stated per 1,000 (K) or in per cent (N %). Also: natural increase plus net migration rate against a stated growth rate, when all three are stated per 1,000 or in per cent. | `K = B − D` or `N = (B − D) / 10` (or the sum) | INT-SUBJ-001 |
| `geo_doubling_time` | A growth rate r % per year with a doubling time T: "growing at 2 % a year, the population doubles in about 35 years", or the reverse. Built for 0 < r ≤ 10; above 10 the statement is named undecided (CORE-QNT-001, "outside the rule's band"). | `69/r − h ≤ T ≤ 73/r + h` (the band of the rule of 70, the rule of 72 and exact compounding for r ≤ 10; r is a constant, so the problem is linear). The description says so. | INT-SUBJ-001 |
| `geo_per_capita` | A total T and a population P with a figure per capita, per person or per head: "GDP of $1.2 trillion and 60 million people give a GDP per capita of $20,000" (scale words and currency carried). | `X = T / P` | INT-SUBJ-001 |
| `geo_growth_rate` | A population (or any quantity) from V0 in year Y0 to V1 in year Y1 with an "average annual growth rate" g %. Both conventions are accepted: simple `(V1 − V0)/V0/n`, and compound `V0·(1+g)ⁿ` against V1. The compound reading is built only when n = Y1 − Y0 ≤ 12 (the IR's whole-power limit); otherwise only the simple reading is built and the description says the compound reading was not built. If neither can be built, CORE-QNT-001. | disjunction of the readings | INT-SUBJ-001 only when no reading holds |
| `geo_mean` | A mean or average of listed values: "the mean of the three counts (210, 218 and 214) is 214", "an average of 12, 15 and 18 people, 15". A stated n ("three counts") must equal the number of values listed, else the statement is undecided (CORE-QNT-001). | `M = (Σ v) / n` | INT-SUBJ-001 |
| `geo_sampling` | Systematic sampling: "ten sites at 100 m intervals from 0 m to 900 m", "a 1 km transect sampled every 100 m gives 11 sites". | `N = (end − start) / interval + 1` or `N = length / interval` (both conventions; fails only if neither holds) | INT-SUBJ-004 (warning: conventions vary) |
| `geo_table_count` | A count of the rows of a supplied attribute table: "the table shows twelve sites", "my ten sites", "data from ten sites". Built when the clause names the table's row noun (its first header word, e.g. "Site") or credits the table. Questions and imperatives are skipped (c1 `ge-t14`: "Why did you choose ten sites ...?", "rank your ten sites" are not claims). | `N = rows` | INT-SUBJ-004 |
| `supplied_figure` (attribute tables) | Supplied pipe tables **without** a year axis (grounded_figures reads only year-keyed tables). Rows are keyed by their first cell ("1", "Site 4", "Site A", a place name); columns by the content words of their header, with the unit in brackets (`EQS (out of 30)`, `Mean pedestrian count (per 10 min)`). A figure in a clause that names one row label ("site 4", "at site 7", "Site A") and one column's content word ("pedestrian", "EQS", "retail") is read against that cell. A figure as the result after `=`/`≈` is skipped (the worked reader decides results). | `figure = cell` (half a unit of the last digit written of either) | INT-SUBJ-001 when the clause credits the table ("the table shows", "according to the data", "my data", "your table") or names exactly one cell; INT-SUBJ-004 otherwise. This mirrors grounded_figures. |
| `geo_case_consistency` | One case quantity stated twice in the report with different values: same case anchor (the nearest proper-noun place or event name in the sentence, with its year when one is stated), same head noun (deaths, killed, people killed, injured, displaced, homes, buildings, claims) and same unit. Pairs where either value is a comparative bound ("more than 130", "of them") are compared under interval semantics and built only when the intervals are disjoint. | `v1 = v2` (5 % when either is approximate) | INT-SUBJ-004 |
| `geo_significance` | A Spearman or other coefficient stated with a critical value and a verdict: "rs = −0.89 exceeds the critical value of 0.648, so the correlation is significant at 0.05". The comparison `\|rs\| > cv` (or `<`) against the stated verdict is decided. The critical value's lookup (tails, tables) is **not** decided, and the description says so. | `\|rs\| ≥ cv` against the verdict | INT-SUBJ-001 |
| `worked_arithmetic` | Every worked equation, as on the generic branch (`_worked_checks(report, "geography-worked", ...)`): Spearman chains, lag times (clock), Q = A × v, coal supply. | unchanged | unchanged |

Undecided readings:

- **CORE-QNT-001 (warning).** A Geography statement the readers recognise but cannot build: a density whose area unit is not in
  the table, n above 12 with no simple reading, mismatched counts in a mean, a rate above the doubling band.
- It is raised by the Geography pack, with the core's code, severity and message shape ("... states a derived figure ... that
  could not be checked: <reason>"), and `rule_source` "Geography pack: a Geography rate read but not built is named undecided".
- `pack_decided_equations` is extended (section 8.1) with the phrases the Geography pack decided, so the core pack never names the
  same statement undecided beside a verdict.

Deterministic findings:

- **CORE-SRC-002 (info, per claim).** A figure credited to a map, graph, photograph, population pyramid, hydrograph, choropleth or
  "Figure N"/"Fig. N" that no supplied text is titled or labelled as. The message: "the figure's source was not supplied; a value
  read from an unsupplied figure cannot be checked". The specialist cannot see figures (the subject's own convention), so such
  a value is unverifiable. Claims the core pack's `_unsourced_world_figures` already names are skipped (one finding per claim).
- **CORE-SRC-002 (info, per claim).** A case-study figure (a named place, a year and a figure) with no supplied source, no credit
  and no from-memory label (`_labels_figures_from_memory`). Claims the core pack names are skipped.
- **GEN-STR-001 (error).** Kept, via `unknown_supports(report)`.

### 7.3 Expected outcomes on the recorded Geography answers (to be pinned in the tests)

- c1 `ge-t14`: geography-worked-1..3, ENTAILED. No new check:
  - the "ten sites" sentences are questions or imperatives;
  - the Spearman example table is the answer's own invented data, and the attribute reader reads supplied tables only;
  - no clause names a supplied site row with a column word.
- c2 `ge-p9c`: geography-worked-1..6 and core-quant-1,2, ENTAILED. The CORE-QNT-001 on "200 % higher than Storm 1" is unchanged
  (core). No new check.
- c2 `ge-t15`: geography-worked-1..4, core-quant-1..5 and core-figure-1..4, ENTAILED. No new check.
- c3 `ge-t16`: no check. Both "more than 130" statements are bounds that overlap, so no `geo_case_consistency` pair is built. The
  case figures (Haiti 2010, Darfield 2010, Christchurch 2011) come with "Sources: course notes ..." credited. The core pack's
  CORE-SRC-002 behaviour is unchanged; the Geography pack adds no CORE-SRC-002 where the answer credits course notes.

No new error or warning finding on any recorded Geography answer. INT codes, statuses, constraints and coverage are exactly those
of section 2.1.

---

## 8. Changes to existing modules

### 8.1 `branches/packs.py`

`_worked_branch`:

```python
def _worked_branch(report):
    key = resolve_profile(report.subject).key
    if key in ("economics", "business_management", "psychology"):
        return key
    if key in ("geography", "language_b"):
        return key  # D9/D10 (D35): the worked equations of these branches are decided by their packs
    if any(key in b.profile_keys for b in BRANCHES if b.key != "generic"):
        return None
    return "generic"
```

`pack_decided_equations`:

- for `geography` and `language_b`, `decided_worked_chains(text)` as for `generic`;
- for `geography`, also the statements its readers decided (`geography.decided_statements(report)`), so the core's undecided
  reader skips them.

`GenericPack.checks`: factored into `unknown_supports(report)` (the same findings). `GenericPack` calls it, and so do the two new
packs.

The module docstring and the `_worked_branch` docstring name Geography and Language B as their own branches.

### 8.2 `branches/registry.py`

The two entries (section 3) and the module docstring.

### 8.3 Nothing else in `src/`

These stay untouched:

- `grounded_figures.py`: the attribute-table reader lives in `geography.py`, reusing `grounded_figures._cells`, `_number` and
  `_half`;
- `quant.py`, `worked.py`, `ledger.py`, `markdown.py`, `self_report.py`, `subjects.py`, `named.py`, `version.py`;
- the channel, overseer, combinator and flash router.

The core owner is free to promote the Spanish number-word reader later.

### 8.4 What deliberately does not change, and why

- **No new receipt code family (GE-, LB-).** Every code needs:
  - a row in `overseer/src/epinoic_overseer/emitted.py`;
  - an entry in the families tuples of `overseer/tests/overseer_tests/test_integration_codes.py`;
  - rows in the overseer knowledge pack 2.1 (`06-kinds-and-codes.md`, the completeness test).

  That changes the pack digest, `integration/overseer_port.PINNED_PACK_DIGESTS` and the preflight's `KIT-HS-007` pin. The new
  determinations ride on INT-SUBJ-001/-004 (formal checks with new kinds), CORE-QNT-001 and CORE-SRC-002, which every table
  already lists with these severities. New pack-specific codes are a follow-up with that ripple measured (section 15).
- **No subject-profile change** (aliases, eligible classes, `can_check`/`cannot_check` text). The profile text is model-facing
  (`prompt_profile_text`), and aliases and eligibility are policy (section 13). The recorded subjects already resolve:
  "Geography" resolves to `geography`; "Language B: Spanish", "Spanish B" and "language-b-spanish" resolve to `language_b`.
- **No hub hook** (section 3), and **no change to `named.py`**: the defect labels are carried on `FormalCheck.defect`.
- **No public API change.** `epinoic_logic.api.branches` exports what the overseer re-derives. The overseer re-derives the new
  branches through `default_registry()` (R2) with no new name.

---

## 9. Readers that must stay linear in input length

Every new reader is bounded and linear. The round-10 stall class (a name or word read again from each letter of a joined token,
`A-A-A...`) is excluded by construction:

| Reader | Bound and method |
| --- | --- |
| `spanish_lexicon.is_spanish`, `spanish_paragraphs` | First 20,000 characters (per paragraph: 4,000); one token pass |
| `spanish_numeral_readings` | Per token; tokens at most 24 characters; regex anchored, possessive |
| `spanish_number_figures` | The ledger's reader (already swept in round 10: `_ES_HINT_RE` gate, one pass) |
| `SPANISH_CREDIT_RE`, connectors, text-type and address markers | One alternation pattern each, word-bounded, possessive (`(?<![\w-])...(?![\w-])`), no nested unbounded quantifiers, matched with `finditer` once per region |
| `inverted_mark_spans` | One left-to-right pass with a stack of depth at most 8; unmatched marks are dropped, never rescanned |
| `model_regions` | One pass over paragraphs (`_PARA_RE` split); a headline or byline test reads the first line only, at most 200 characters |
| `lb_quoted_form` occurrence counts | At most 32 forms per report, each up to 200 characters; `str.find` loop per form over a region of at most 60,000 characters. That is k·n with k bounded. Forms are read with `markdown.find_quotation_spans`, already linear (gate 1). |
| `lb_word_count` / ranges | `request_parser.count_words` (one regex pass) per region, memoised per (report digest, region) |
| Geography sentence readers | Per sentence from the shared splitter (`_sentences_with_paragraph_cached`); every pattern possessive; name and anchor words at most 41 characters (`_NAME` like `quant._ALONE_RE`); at most 64 statements per kind and 200 per report; `MAX_FORMAL_CHECKS` (500) is respected across core plus pack |
| Attribute tables | `grounded_figures` caps (8 tables, 60 rows, 8 columns, 80-character cells, 400 claims, 40 figures per claim); cells indexed once per table, a clause's row and column looked up by dictionary, never by rescanning |
| `geo_case_consistency` | One index by (anchor, noun, unit) with at most 16 values per key and 64 keys; pairs only within a key |
| Classification of the task | Once per report (memoised by digest); request text cut at 20,000 characters, as `request_model_extrapolation` does |

Test: `tests/branches/test_d9d10_linear.py` (section 10.1). Every new entry point, and the full
`parse → run_packs` of both branches, runs over `hostile_inputs.all_inputs()` and `hostile_inputs.word_runs()`, plus long Spanish
shapes:

- `¿¿¿...`, `¡a¡a¡a...`;
- `1.250.250.250...`;
- `dos mil dos mil ...`;
- `«a «a «a ...`;
- `Estimado: Estimado: ...`;
- `km² km² ...`;
- `per 1,000 per 1,000 ...`;
- `site 1 site 1 ...`;
- a 60-row table whose cells are joined word runs.

Each call must finish under 3 s (pack entry points) or 10 s (parse plus packs), with no exception other than `AdapterError`. A
growth check at 20,000 and 80,000 characters requires `t(80k) / t(20k) < 8`. Performance findings that change no result are
recorded for the optimisation phase, never fixed now (founder's order).

---

## 10. Tests

### 10.1 New test files

- **`tests/branches/d9d10_texts.py`.** The recorded answers, questions and supplied texts as fixtures:
  - reused from existing fixtures: `GE_T14`, `GE_T15`, `GE_T15_DOC`, `GE_P9C` and `SP_T15` (`c1_texts`, `c2_texts`);
  - added: `GE_T16`, `SP_T14` (with `SP_T14_DOC`), `SP_T16` (with `SP_T16_DOC`), `SP_P10D` (with `SP_P10D_DOC`).

  These are specialist outputs recorded in the rounds, as earlier rounds stored them. No text from the knowledge bases or the
  connector's instruction blocks enters the repository. The `sp-t14` article contains a bracketed instruction aimed at AI
  assistants. Keep it verbatim: it is part of the recorded case, the specialist correctly ignored it, and it serves as a test of
  the gate (section 10.2).
- **`tests/branches/test_d9d10_routing.py`.**
  - Each of these labels resolves to its branch: `Geography`, `Geography HL`, `IB Geography: Paper 1`, `Language B: Spanish`,
    `Spanish B HL`, `language-b-spanish`, `French B`, `Spanish ab initio`, `Mandarin B`.
  - `Philosophy`, `Visual Arts`, `TOK`, `Underwater Basket Weaving` and `None` go to `generic`.
  - The packs are `(CorePack, GeographyPack)` and `(CorePack, LanguageBPack)`; `hub_hooks is None`.
  - `test_every_branch_runs_the_shared_core_pack_first` (section 5).
  - `hub.branch_for("Geography") == "geography"` and `hub.branch_for("Language B: Spanish") == "language_b"`.
- **`tests/branches/test_d9d10_parity.py`**, the generic branch's behaviour kept:
  - For every recorded answer, `branch.parser().parse_response(...)` equals the generic branch's parse in every claim field:
    `model_dump()` equality, ids included.
  - The core pack's findings are identical.
  - The generic branch's formal checks, renamed (`generic-worked-N` to `geography-worked-N` / `language-b-worked-N`, same
    problem digest), are a subset of the new branch's.
  - GEN-STR-001 fires on a report whose claim cites an unknown support, on both branches.
  - The CORE-SELF-001 parity over `c2_hold_texts` (section 5).
- **`tests/branches/test_d9d10_geography.py`.** Unit cases per kind: correct and faulty, approximation words, comparative bounds,
  unit conversions (ha, m², km²), scale words and currency, questions skipped, undecided naming (CORE-QNT-001) and no double naming
  with the core pack. Section 11 lists the faulty variants. Engine statuses are asserted on the hub receipt, through `RouterHub`,
  as `test_r7_quant_packs.through_hub` does.
- **`tests/branches/test_d9d10_language_b.py`.** Unit cases per kind: Spanish detection (Spanish, English, French and mixed
  texts), numeral readings, number words, credits, model regions on the recorded answers, ¿/¡ pairing, address markers, quoted
  forms in the model and inline model, listed counts, and Spanish percent change. Also: no Spanish reader acts on a French B
  answer.
- **`tests/branches/test_d9d10_recorded.py`.** The eight recorded answers through `RouterHub` with their questions, subjects,
  agents, task types and supplied texts:
  - the receipt status;
  - the error/warning INT codes;
  - constraint results;
  - item coverage;
  - every formal check id with its status (sections 6.5 and 7.3, fixed exactly);
  - no INT-SUBJ-001/-003/-004 on any of them.
- **`tests/branches/test_d9d10_linear.py`** (section 9).

### 10.2 Gate and safety tests on the new branches

- The existing self-report suites already parametrize over `c2_hold_texts.SUBJECTS`, which include Geography and Spanish B:
  - `test_c2_hold_self_reports.py`;
  - `test_c2_hold_round2_self_reports.py` and `test_c2_hold_round3_self_reports.py`;
  - `test_c2_hold_remedy2_*`;
  - `test_c3_clearance_self_reports.py` and `test_c3_handoff_self_reports.py`.

  They now run through the new branches, with no edit beyond `BRANCH_OF` (section 10.3).
- A Spanish self-certification appended to `sp-t15` is named CORE-SELF-001 and INT-HANDOFF-006 on `language_b`, exactly as on the
  generic branch for the same text. Three positions: in the meta paragraph, inside the model article, and in the report's
  assumptions field.
- `sp-t14` with the supplied text's embedded instruction: an answer that complies with it gets the same self-report and outside-
  party findings on `language_b` as on `generic`. The branch neither adds nor removes any.
- AST scan (as the STEM suites do): the three new modules contain no `eval`, `exec`, `compile`, `__import__` or `importlib`, and no
  library that evaluates strings.

### 10.3 Test rewrites (stricter or equivalent; none weakened)

| Test | Today | Rewrite | Why |
| --- | --- | --- | --- |
| `tests/branches/c2_hold_texts.py` `BRANCH_OF` | `"Geography": "generic", "Spanish B": "generic"` | `"Geography": "geography", "Spanish B": "language_b"` | The routing the run makes; `test_c2_hold_self_reports.py:40` still asserts `set(BRANCH_OF.values()) == set(reg.keys())`, now over 11 branches (stricter) |
| `tests/branches/test_r7_quant_packs.py:208-209` | `constraint_id.startswith("generic-worked")` | `startswith("geography-worked")`, plus an assertion that no `generic-worked` id remains on a Geography receipt | Same rule, renamed id prefix; stricter |
| `tests/branches/test_c2b_clearance_parsers.py:137` | ids `"generic-spanish", "generic"` | ids `"language_b", "geography"` | Labels only |
| `tests/integration/test_generated.py` | unchanged | unchanged | Still asserts map equals routing; passes once the map's branch column follows option A |
| `tests/integration/test_preflight_handshake.py` | unchanged | unchanged | `subject_map()` passes after option A |

Search before finishing: `grep -rn "generic" tests overseer/tests` for any other assertion that pins Geography or Language B to
`generic`. None found besides those above. Run the full suite once at the end (the founder's rule: never `-m stress`).

### 10.4 Harness validation (rounds c1, c2, c3, on copies)

The bar ("no recorded Geography or Spanish answer may lose a functional transmission"), as measured by
`d9d10-baseline.json`:

- transport 203/203, 188/188 and 164/176;
- per Geography and Language B record: status, functional, error/warning codes, constraints, coverage, translation outcomes and
  fixtures served all unchanged;
- formal-check statuses unchanged, modulo the renamed ids;
- new formal checks only as in sections 6.5 and 7.3, all ENTAILED;
- `branch` field `geography` or `language_b`;
- mutation records: every variant still functional.

A drop on any of these is a defect of the branch, never a reason to relax the bar.

---

## 11. Faulty variants each branch must name

Each is a test in `test_d9d10_geography.py` / `test_d9d10_language_b.py`, through the hub, with the expected receipt.

### Geography

| Variant (from a recorded answer) | Expected |
| --- | --- |
| Wrong arithmetic on Geography data, written: `ge-t15` "Coal supply in 2005: 46% × 820 PJ = 0.46 × 820 = 377.2 PJ" changed to "= 372.2 PJ" | INT-SUBJ-001, `geography-worked-N`, claim g2.2 |
| Wrong arithmetic, written: `ge-p9c` "(16.2 − 5.4) ÷ 5.4 × 100 = 10.8 ÷ 5.4 × 100 = 200%" changed to "= 300%" | INT-SUBJ-001 (`geography-worked`) |
| Wrong arithmetic, prose: "With 2.4 million people on 1,200 km², the density is 3,000 people per km²." | INT-SUBJ-001, `geo_density`; the correct 2,000 is ENTAILED |
| Wrong rate: "4,800 births in a population of 200,000, a crude birth rate of 42 per 1,000" | INT-SUBJ-001, `geo_rate_per_thousand` |
| Wrong natural increase: "birth rate 24 per 1,000, death rate 9 per 1,000, natural increase 2.5%" | INT-SUBJ-001, `geo_natural_increase` |
| Wrong doubling time: "growing at 2% a year, the population doubles in about 50 years" | INT-SUBJ-001, `geo_doubling_time`; 35 and 36 years are ENTAILED |
| Wrong per capita: "$1.2 trillion and 60 million people, a GDP per capita of $2,000" | INT-SUBJ-001, `geo_per_capita` |
| Wrong mean: "the mean of the three counts (210, 218 and 214) is 218" | INT-SUBJ-001, `geo_mean` |
| Misread figure from a supplied table: `ge-t14` supplied table plus "According to the table, Site 4 had a mean pedestrian count of 79 per 10 minutes." | INT-SUBJ-001, `supplied_figure`, defect source_mismatch; uncredited "Site 4 had 79 pedestrians" is INT-SUBJ-004; 97 is ENTAILED |
| Misread figure, year table: `ge-t15` "Coal supply in 2005: 64% × 820 PJ" | INT-SUBJ-001 (`core-figure`, unchanged) |
| Table count: "The table shows twelve sites." | INT-SUBJ-004, `geo_table_count`; "ten sites" ENTAILED |
| Word count outside the task's bound: `ge-t16` padded to 900 words ("about 500 words") | INT-REQ-005 from the channel, unchanged under the new branch |
| Case inconsistency: "It killed 185 people ..." and later "the 158 deaths in Christchurch" | INT-SUBJ-004, `geo_case_consistency` |
| Unsupplied figure: "Figure 2 shows 64% of households ..." with no supplied Figure 2 | CORE-SRC-002 (info) on the claim |
| Mutations of the harness (invented and altered quotation, self-certification, wrong arithmetic, chronology) | Unchanged (core pack and channel) |

### Language B

| Variant | Expected |
| --- | --- |
| Word count outside the task's bound: `sp-t15` with the body padded to about 700 words, "Escribe entre 450 y 600 palabras" | INT-REQ-005 (channel), plus INT-SUBJ-001 on `lb_word_count` ("about 513": measured over 700) and on `lb_word_range_claim` ("inside the 450–600 range") |
| No bound stated, HL Paper 1 writing task, model of 700 words | INT-SUBJ-004, `lb_course_word_range` (convention) |
| Stated count wrong: `sp-t16` "Your email is about 450 words" | INT-SUBJ-001, `lb_word_count` (student text 296) |
| "so the length is right" with a 180-word student text | INT-SUBJ-001, `lb_word_range_claim` |
| Wrong arithmetic in Spanish: "pasó de 1.250 a 212 habitantes, una caída del 73 %" | INT-SUBJ-001, `lb_percent_change` (83 % holds) |
| Misread figure from the supplied text, credited: `sp-t14` "Según el texto, en 2015 quedaban 221 vecinos." | INT-SUBJ-001, `supplied_figure` |
| Misread in a reading-task answer: "1. 1.250 habitantes en 1960 y 221 vecinos en 2015." | INT-SUBJ-001 (`core-figure` today: INT-SUBJ-004 when uncredited; on `language_b` the reading-task convention makes it credited) |
| Number word misread: "La escuela volvió a abrir con quince alumnos." (text: catorce) | INT-SUBJ-004 (uncredited) |
| Own-model quotation absent: `sp-t15` meta "the model uses «por lo tanto»" (the model never writes it) | INT-SUBJ-004, `lb_quoted_form` |
| Address claim false: `sp-t16` "you write with usted forms («¿Cómo estáis?»)" | INT-SUBJ-004, `lb_address_form` |
| Listed count wrong: `sp-t16` "fix the eight points" (six listed) | INT-SUBJ-004, `lb_listed_count` |
| A quoted student form that is not in the student text | INT-REQ-003 (channel), unchanged; no duplicate from the pack |
| French B answer with the same English meta statements | Language-neutral checks only (word count, ranges); no Spanish reader runs |

---

## 12. Documentation and the decision record

### 12.1 Documents to update

- `src/epinoic_logic/branches/README.md`:
  - the branch diagram (two rows);
  - the module table: `geography.py`, `language_b.py`, `spanish_lexicon.py`, and the `_worked_branch` note under `packs.py`;
  - a new section "Geography and Language B branches (D9/D10, D35)", in the style of the round sections: readers, kinds,
    severities, what is undecided, what is not judged (register, accuracy), and the linear-time bounds.
- `README.md` (top-level), the "Route" bullet: "Geography goes to `geography`; Language B and ab initio courses to `language_b`
  (Spanish readers); an unrecognised subject still goes to `generic`."
- `tests/README.md`: the new test files under the branches section, and the harness bar of section 10.4 recorded with the
  round's results.
- `integration/README.md` (the subject-map line) and `integration/subject-map.json` `note`, unchanged in substance:
  - routes stay null;
  - "Provisional rows wait on decisions D9 and D10" stays (the rows remain provisional);
  - the row branches change under option A.
- `integration/DECISIONS.md`:
  - the new D35 record below;
  - one sentence in the D9/D10 record's "What the kit changes", pointing to D35 for the branch column;
  - the "Documentation only, or nothing" list is unaffected.
- After `DECISIONS.md`, the subject map and the generated copies change: `integration/MANIFEST.sha256` regenerated.
- `docs/handoff`: the run's handoff notes name round 10 finding #18 resolved, with this design's follow-ups (section 15).

### 12.2 Decision record to append to `integration/DECISIONS.md`

```markdown
## Appendix: D35, translator branches for Geography and Language B (decided 16 November 2026)

D35 follows D9/D10. It decides how the translator serves two subjects the subject map already carries as service-only
rows; it decides nothing about the website.

### D35. Translator branches for Geography and Language B

- **Decision:**
  - **Branches:** the translator routes Geography to its own branch, `geography`, and every Language B and ab initio
    course to `language_b`, instead of `generic`. Each branch runs the shared core pack first (with the shared
    self-certification gate) and its own subject pack; both keep the generic parser, so claim ids and roles are
    unchanged.
  - **Subject map:** the `branch` field of the rows `geography`, `spanish-b` and `language-b-spanish` follows the
    routing (`geography`, `language_b`, `language_b`); map version 2026-11-16.1. Routes stay null, environments stay
    `["service"]`, the rows stay provisional. No website route is added.
  - **Kit tag:** none created or moved; the first published tag carries this map.
  - **What the branches check:** the engine decides the subjects' own arithmetic (Geography: population, density,
    rates per 1,000, natural increase, growth and doubling time, per-capita figures, fieldwork means and samples,
    figures read from supplied tables; Language B: the word counts, ranges, quoted forms, address forms and listed
    items an answer states about a production, figures read from the supplied text). Register, linguistic accuracy
    and text-type fit are not judged by the translator.
- **Why:** D9/D10 kept the two subjects service-only; their answers crossed the hub on the generic branch, where a
  stated density, rate or doubling time, a misread site figure and a wrong word-count claim passed with no finding
  (round 10, finding #18). The website route question is unchanged.
- **What the kit changes:** `integration/subject-map.json` (three `branch` values and the version), the generated
  copies (`compat.py`, `compat.js`, `subject-map.js`), the `subject_map` pin in `COMPATIBILITY.json`, the handshake
  vectors and the MANIFEST; the website patch set M's `RESULT.sha256` lines for the two data copies (re-run, or recorded
  as not re-run).
- **Who acts, when:** nobody beyond this change; Bruno's W7 decides any website route later, as D9/D10 says.
- **How to reverse:** route the two profiles back to `generic` and restore the three `branch` values under a new map
  version.
- **Authority:** Daniel's instruction of 16 November 2026 to do D9 and D10.
```

---

## 13. Versions (`src/epinoic_logic/version.py` rules)

| Component | Rule | This change | Bump? |
| --- | --- | --- | --- |
| IR_VERSION | Any schema change | None | No |
| ENGINE_VERSION | Compilation or procedures | None (the new checks are IR problems under the existing `linear` policy) | No |
| POLICY_VERSION | Limits, allowlist or eligibility rules | None: profiles, aliases, eligible classes, `MAX_FORMAL_CHECKS` and policies all unchanged. (The self-certification implementer bumps it for eligibility rule 0; D9/D10 adds nothing to that bump.) | Not for D9/D10 |
| TRANSLATOR_VERSION | Translation pipeline or prompts | The model-facing inputs are unchanged: profile text (`prompt_profile_text`), prompts `translate_v2`/`review_v2`, and the claims handed to the translator (the same parser, so identical claim text, roles and materiality). Branch packs are deterministic integrity checks on the receipt. Every pack and parser change of rounds 8 to 10 shipped under 0.4.0, and the build identity (`engine.identity`) separates builds. | No |
| ARG_RULES_VERSION | Argument-diagnosis rules | `named.py` untouched | No |

The conditions under which a bump would become due are listed in `d9d10-version-request.md`. A note for the version owner on the
`version.py` history is optional.

---

## 14. Risks

1. **Subject map (section 1).** The instruction says "changes no subject map", while the preflight and a kit test enforce
   map = routing. Option A changes three `branch` values and the map version. If the orchestrator rejects it, fall back to option
   B and record finding #18 as only partly resolved.
2. **Kit regeneration coupling.** `compat.js` and `subject-map.js` change, so the website patch set M's `RESULT.sha256` lines and
   `TESTED.json` need a re-run on a disposable export, or a recorded "not re-run". The `POLICY_VERSION` bump causes the same
   coupling, so do one regeneration.
3. **False positives on model texts and invented data.** A model text or an invented practice table holds figures the readers
   could misread as claims:
   - The Geography attribute reader reads supplied tables only, and needs a row label plus a column word.
   - `lb_quoted_form` and `lb_listed_count` read only the specialist's meta statements about a production, never the model's own
     content.
   - Questions and imperatives are skipped.
   - The recorded answers are pinned to zero new errors or warnings.
4. **Word measures.** `count_words` and a reader's whitespace count differ: `2.º` is two tokens, and hyphenation and figures are
   counted differently. Tolerances (5 words / 2 % exact, 10 % "about") absorb these. A region the pack cannot pin down yields a
   disjunction and a warning, never an error.
5. **Spanish detection on mixed answers.** Answers mix English meta with Spanish models, so detection works per region. A French
   or Portuguese text with many cognate function words could pass the Spanish test; the thresholds and the ¿/¡ rule keep that rare.
   The worst case is a Spanish reader that finds nothing.
6. **Unambiguous markers only.** "hicieron" (third person plural) in c3 `sp-t16` could be ustedes or ellos, so it is never a
   marker. A real register mix that uses only ambiguous forms goes unnoticed. That is by design (fail quiet on ambiguity), and
   register judgement is not the translator's.
7. **Reused codes.** CORE-QNT-001 and CORE-SRC-002 are raised by the Geography pack under the core's code, so a reader keyed on
   "CORE- = core pack" sees a subject pack's finding. The `rule_source` names the Geography pack. Own codes are the follow-up.
8. **Doubling-time band.** [69/r, 73/r] covers the rules of 70 and 72 and exact compounding up to r = 10 %. A stated time from a
   different model (continuous growth with r in decimal) inside the band passes. Outside the band it is an error, which is the
   intent.
9. **Overseer R2.** The overseer re-derives branch checks with `default_registry()`, so it sees the new branches with no change.
   The overseer's own tests that build registries (`test_corrections_stem_ready.py`: `BranchRegistry([*BRANCHES, phys])`) still
   work, because BRANCHES only grows.
10. **Shared working tree.** The self-certification implementer edits `adapters/self_report.py`, `markdown.py` and maybe
    `packs.py` (CORE-SELF-001). This design's edit to `packs.py` is confined to `_worked_branch`, `pack_decided_equations` and
    `GenericPack.checks`. Coordinate the merge order: the gate change first, then the branches, then one parity run.
11. **Unrecognised labels.** "Spanish" or "Español" alone still route to `generic`. An alias addition is a policy change
    (section 13) and is not part of this run.

---

## 15. Follow-ups recorded, not done in this run

- Own code families (GE-, LB-) with the overseer's tables, knowledge pack 2.2, the pinned digest and the drift tests, for
  deterministic subject findings that are not engine checks.
- Re-roling a model text's sentences as a performance (non-assertive), with its fixture and harness impact measured first.
- Promoting the Spanish number-word reader from `integrity/ledger.py` into `spanish_lexicon.py` (core owner).
- A `word_count_view` hub hook for Language B, if the channel's measure ever needs to read only the Spanish production.
- Subject aliases ("Spanish", "Español", "Spanish ab initio SL") under the next `POLICY_VERSION`.
- The `ge-p10c` peer exchange with Chemistry (planned in c3, never answered): run it in the next round to exercise a sciences
  plus geography group.

---

## 16. Implementation order

1. `spanish_lexicon.py` and its unit tests.
2. `geography.py` and `language_b.py` with their unit tests.
3. The `packs.py` edits and `registry.py`.
4. Parity, recorded and linear tests; the test rewrites.
5. Subject map (option A) and generated copies, in the same regeneration as the self-certification implementer's
   `COMPATIBILITY.json` change.
6. Docs and D35.
7. The full suite, then the harness on copies of c1, c2 and c3 against `d9d10-baseline.json`.
