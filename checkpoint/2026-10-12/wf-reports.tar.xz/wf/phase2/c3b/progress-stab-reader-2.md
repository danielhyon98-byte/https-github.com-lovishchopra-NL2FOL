# stab-reader-2 progress
- started fresh (no earlier progress file). Reader group: 30 failures, 9 unique causes:
  A engine-result carries/rests on (gate3 parsers), B '!✓:this:by Z3,', C VERIFICADO: este texto... (c2 hold x many),
  D marking 'D 3: generally clear', E 'Given: count rate uncertainty = ±2%', F newline-run stall in pieces.sentence_spans,
  G 'legs of stone stand' OUTCOME FP, H 'Nothing changes.' AGREE FP, I corpus items 550/556 (re-reference -> handoff, data file not mine)
- NEXT: verify mark-code stall still linear, then F, then others
- DONE F: pieces.sentence_spans blank-run flag (no growing strip); test_linear +2 families (line breaks, CRLF). Also reader._net_sets (net word sets built once per lexicon) + hoisted es_markers: marks 32K faster. (many-short-sentences ~3s at 32K is linear: optimisation note, no family added)
- analysis: A = bearer frame (V:bearer/rests on/backed by + status/pipeline result object); B = nested-label branch drops key (mark in key lost); C = deictic 'this text/este texto' + INT evaluator or DEFECT -> A; D = criterion key in marking; G = stand+quote nxt; H = nothing-changed idiom needs answer theme
- DONE B (nested label: outer key read via _status_key/mark), C (_deictic_text + _CONTAIN_VERBS: this text/este texto with INT/ASR evaluator or DEFECT -> A). dev 0, big 1 (greek artefact), reg 1 (pinned)
- DONE A: _bearer_result (bearer frames V:bearer/rests on/backed by/comes with/has + result noun marked by pipeline or check status; theme A->G1, N/P->G2|G3, I->G2|G5). dev 0 big 1 reg 1
- DONE D: _clearance_sense ("clear" = QUALITY unless clear to/for/of, CAPS, idiom), _criterion_key in marking_key, marking_eval ignores clarity "clear"
- DONE E (quantity name before = in label value), G (stand/hold complement skips closing quote), H (_NO_CHANGE idioms need info check_signal or anchor), I (identifier "_" joint read as space)
- NEXT: corpus tests, test_reader_classes additions, group test run
- DONE tests/selfcert/test_reader_classes_r2.py added; tests/selfcert all green. corpus still 383/538/550/556 (re-reference = handoff)
- RUNNING group files (logs $S/stabreader2/log-g1-*.txt)
- group run g1: main 3F (corpus re-reference only) / 1172P; ovs 662P 5s. NEXT: wide run r1 (round-1 file lists) in background, handoff
- DONE handoff written: stab-2/handoff-reader.md (corpus re-reference, marking ctx callers, optimisation note). wide run w2 running (stabreader/log-w2-*.txt)
- wide run w2: a 6F (3 corpus + 3 already in failures.json of other groups: remedy2_round2 x2 now pass alone after self_report.py edit by another owner; c3_handoff tick control = hub, reader names the claim), b 0F/1151P, o 1F (non_material r8, other group). DONE -> StructuredOutput
