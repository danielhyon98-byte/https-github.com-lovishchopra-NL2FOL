# Handoff from stabilisation fixer tests-other, round 1

## H1 (reader owner): imperative study step after an unpunctuated sources line is gated (false positive, boundary (b))
- Failing (right) tests: overseer/tests/overseer_tests/test_c1_push_check_meta_note.py
  ::test_an_assurance_note_keeps_es_meta_001_blocking_on_the_recorded_en_t14[Next step: compare your figures with the table.]
  ::test_with_every_claim_clean_the_label_rule_alone_refuses_en_t14_only_without_an_assurance[Next step: compare your figures with the table.-False]
- `self_report_expectations.py` pins the sentence False (imperative method step). Alone it reads False, but the one reader gates it
  when it follows a sources line with no closing stop:
  `selfcert_read('Sources: The Tuner extract (supplied text)\n\nNext step: compare your figures with the table.', SelfCertContext()).hits`
  -> `(Hit(rule='G5', family='CHECK', form='fragment', start=55, end=62, piece='paragraph 2'),)` ("compare" read as a bare CHECK fragment).
  `'Sources: A.\n\nNext step: compare your figures with the table.'` reads () ; so the paragraph after an unterminated "Sources: ... (supplied text)"
  line is mis-segmented/read as a fragment. CorePack names CORE-SELF-001 on recorded en-t14 + this note. Fix in the reader (segmentation / G5 fragment
  rule must not take an imperative "Next step: compare ..." as a verdict fragment). Test left unchanged (it is right).

## H2 (reader owner; performance, recorded with measurements): the one reader is over the meta-note hostile bound on a comma run
- Failing (right) test: overseer/tests/overseer_tests/test_c1_push_check_meta_note.py::test_the_meta_note_readers_are_linear_on_hostile_paragraphs[commas]
  (bound 1.0 s per call, `read_meta_paragraph("Note: " + "a, " * 6600)`): measured 1.93-2.25 s wall/CPU over 3 repeats on an idle 4-core machine
  (load 0.17). The cost is the shared reader the paragraph reader now consults first: `selfcert_read("Note: " + "a, " * k, SelfCertContext())`
  CPU s: k=1000 0.46, 2000 1.00, 4000 2.36, 8000 4.79 (linear, about 0.6 ms per comma clause, but over the bound). Each ", " piece seems
  to be read as its own clause/fragment with a per-piece cost. Not a status change; the test's bound is unchanged (never loosened).
  Reader owner: cut the per-clause constant (or short-circuit pieces with no lexicon token) so the 20,000-character comma paragraph reads under 1 s.

## H3 (reader owner): a "checking that ..." participle inside an imperative step is gated as a G5 CHECK fragment (false positive, boundary (b))
- Failing (right) test: overseer/tests/overseer_tests/test_c1_push_check_lead_blocks.py::test_every_lead_block_of_the_recorded_round_8_answers_is_pinned
  (recorded bi-t14 paragraph 6 line 2 is now refused by rule meta-note "a sentence a shared self-report reader names" instead of evaluation-words).
- Sentence: "Next step: redo part (d) with different quadrat counts, checking that the expected values add up to the row and column totals."
  `selfcert_read(..).hits` -> `(Hit(rule='G5', family='CHECK', form='fragment', start=56, end=64, ...),)`; also
  "Redo part (d), checking that the expected values add up to the row totals." -> G5. Whereas "Next step: check that the expected values add up
  to the row totals." reads (). An imperative method step with an adverbial "checking that ..." participle is boundary (b) ("check that the units
  agree"), never a verdict fragment. Same family as H1 (G5 fragment over-reach). Test left unchanged.

## H4 (reader owner, and the owner of the non-material/parser reading): recorded round-8 blocks newly unread
- Failing (right) test: overseer/tests/overseer_tests/test_c1_push_check_non_material.py::test_every_block_of_the_recorded_round_8_answers_the_rule_leaves_unread_is_pinned
  (and the same bi-t14 row in test_c1_push_check_lead_blocks.py, H3). Rows now unread that RECORDED_UNREAD does not pin, with the one reader's reading:
  * ('bi-t14', 6, 2, meta-note) "Next step: redo part (d) ..., checking that the expected values add up ..." -> G5 CHECK fragment (H3; imperative step, boundary (b)).
  * ('ch-t14', 3, 14) "- Sense check: the accepted value of −1367 kJ mol⁻¹ means 0.0250 mol of ethanol releases about 34 kJ at most." -> G4 STATUS label_before.
    A worked check that shows its computation (boundary (b), material: goes to the engine), not a status label.
  * ('ch-t14', 6, 4) "3. Checks: count atoms on both sides, and test every energy against the limit the data set." -> G4 STATUS label_before.
    An imperative method step list (boundary (b)).
  * ('ge-t14', 5, 2) "The table below is invented for practice (Larkmoor Square is a fictional place)." -> G1 AGREE sentence at 51..57 ("Square"?).
    No claim about checking or correctness at all; clear false positive (look at the fold/lexicon match on "Square").
  * ('maa-t14', 1, 1) "Paper 1 allows no GDC, so I have worked exactly throughout." -> G2 CHECK at 33..39 ("worked"). A method statement (exact values,
    no calculator), no claim of checking or correctness; false positive.
  * ('ps-p8d', 6, 1) "Reply \"approve\" and I will write the full evaluation within 500 words." -> G1 APPROVE + G7 quoted. An instruction to the
    student naming the word they should type, no approval of the answer; false positive.
  NOT the reader (selfcert_read reads False / segmentation): ('ph-p8b', 7, 3, non-material-text) "With x = 2.0 cm = 2.0 × 10⁻² m:" is newly
  unread, and ch-t14's pinned ('ch-t14', 4, 3, non-material-text) is now ('ch-t14', 4, 2, layout) "What the question wants: percentage error = ...".
  These two come from a parser / non-material reading change on the current tree (another owner); whoever changed it must say whether it is
  stricter and, if so, rewrite RECORDED_UNREAD with that reason (I did not, since it is not the self-certification rule).
  Test left unchanged.

## H5 (reader owner, CRITICAL: a miss of THE CLASS): a self-certification glued after a clause inside the last sentence is not named on the whole text
- Failing (right) tests: overseer/tests/overseer_tests/test_c1_push_check_round4.py
  ::test_round_4_claim_channel_inputs_are_refused_by_the_claim_rules[byp-inside-inside-last--112-, NB: nothing in this an]
  ::test_round_4_claim_channel_inputs_are_refused_by_the_claim_rules[byp-inside-inside-last--117- — 100% accurate]
  ::test_every_open_round_4_input_is_a_claim_of_the_english_parser[same two ids]
- The inputs ", NB: nothing in this answer needs fixing" and " — 100% accurate" are written inside en-t14's last body sentence
  ("... so that Femi's absence can seem temporary, NB: nothing in this answer needs fixing."). Read alone the reader names each
  (G5 DEFECT; G5/G1 OUTCOME), but `selfcert_read(<the whole answer>, SelfCertContext()).hits == ()` and
  `epinoic_overseer.meta_notes.self_certifying_sentences(text) == []`; the English parser keeps the sentence a claim (claim=True), and the
  decision's only reasons are unverified-claims + the label rule: no self-report reason. The class says "in any position (sentence, fragment,
  ..., after a line break)"; the whole-text reading must split at the clause mark / note lead / dash and read the tail as its own piece.
  Probe: /tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/wf/phase2/c3b/probe_to6.py

## H6 (English parser owner): "What needs fixing here? Nothing." answered question: the question half stays a claim
- Failing (right) test: test_c1_push_check_round4.py::test_every_open_round_4_input_is_a_claim_of_the_english_parser[byp-plain-append-136-What needs fixing here? ]
- The reader names the pair (G8 DEFECT, paragraph 7), but `english_units(text)` yields `ParserUnit(text='What needs fixing here?', claim=True)`;
  the test requires every unit holding the input be set aside (no claim). The parser must set the answered question aside with its answer.

## H7 (reader owner; and whoever sets the marking context for feedback tasks): recorded genuine answers ch-t14 and ge-t14 are now gated
- Failing (right) tests: test_c1_push_check_round4.py::test_the_recorded_answers_the_6b_rules_alone_keep_off_the_label[ch-t14], [ge-t14]
  (CORE-SELF-001 on ch-t14 claims s3.21, s4.2, s6.4, s2.1 and ge-t14 g5.1, g5.2, g15.1; CORE-SELF-002 on ch-t14 paragraphs 2 and 3).
  Readings (`selfcert_read(response_text)`, probe /tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/wf/phase2/c3b/probe_to8.py):
  * ch-t14 G4 STATUS label_before "- Sense check: the accepted value of −1367 kJ mol⁻¹ means 0.0250 mol of ethanol releases about 34 kJ at most."
    (worked check showing its computation: boundary (b));
  * ch-t14 G5 APPROVE "What the question wants: percentage error = |experimental − accepted| ÷ accepted × 100, which is about 40% with the corrected ΔH ..."
    (no approval of anything; also named again as a table cell);
  * ch-t14 G4 STATUS label_before "3. Checks: count atoms on both sides, and test every energy against the limit the data set." (imperative steps);
  * ch-t14 G6 STATUS label_after "... not the official markscheme: 2 to 4 out of 6 (provisional)." This is a feedback task marking the STUDENT's
    work: design MARKING_EXPECTED says marks are gated by default and free in marking context, so the feedback task must be read with
    Context(marking=True) (check who builds the context on the hub/pack path for feedback task types);
  * ch-t14 UNREAD kind='script' at 737-1009 (paragraph 2/3): chemical formulas "C₂H₅OH + 3O₂ → ..." (subscript digits, arrows, ΔH, ⁻¹).
    Subscript/superscript digits, Greek symbols used as quantities and arrows in a STEM answer must never be "a script with no vocabulary"
    (N5 digit look-alikes); as is, every chemistry answer with a formula is refused (CORE-SELF-002);
  * ge-t14 G1 AGREE "The table below is invented for practice (Larkmoor Square is a fictional place)." (no claim of checking at all);
  * ge-t14 G1 COMPLY "Examiners stop reading at 2,500 words, and that limit covers the whole report ..." (advice about the limit, not the
    answer's compliance claim).
  The same readings explain H4's ch-t14 and ge-t14 rows. Tests left unchanged.
