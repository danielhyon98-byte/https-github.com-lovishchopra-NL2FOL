# Handoff from stabilisation fixer tests-other, round 1

## H1 (reader owner): imperative study step after an unpunctuated sources line is gated (false positive, boundary (b))
- Failing (right) tests: overseer/tests/overseer_tests/test_c1_push_check_meta_note.py
  ::test_an_assurance_note_keeps_es_meta_001_blocking_on_the_recorded_en_t14[Next step: compare your figures with the table.]
  ::test_with_every_claim_clean_the_label_rule_alone_refuses_en_t14_only_without_an_assurance[Next step: compare your figures with the table.-False]
- `self_report_expectations.py` pins the sentence False (imperative method step). Alone it reads False, but the one reader gates it
  when it follows a sources line with no closing stop:
  `selfcert_read('Sources: The Tuner extract (supplied text)\n\nNext step: compare your figures with the table.', SelfCertContext()).hits`
  -> `(Hit(rule='G5', family='CHECK', form='fragment', start=55, end=62, piece='paragraph 2'),)` ("compare" read as a bare CHECK fragment).
  `'Sources: A.\n\nNext step: compare your figures with the table.'` reads () ; so the paragraph after an unterminated "Sources: ... (supplied text)"
  line is mis-segmented/read as a fragment. CorePack names CORE-SELF-001 on recorded en-t14 + this note. Fix in the reader (segmentation / G5 fragment
  rule must not take an imperative "Next step: compare ..." as a verdict fragment). Test left unchanged (it is right).

## H2 (reader owner; performance, recorded with measurements): the one reader is over the meta-note hostile bound on a comma run
- Failing (right) test: overseer/tests/overseer_tests/test_c1_push_check_meta_note.py::test_the_meta_note_readers_are_linear_on_hostile_paragraphs[commas]
  (bound 1.0 s per call, `read_meta_paragraph("Note: " + "a, " * 6600)`): measured 1.93-2.25 s wall/CPU over 3 repeats on an idle 4-core machine
  (load 0.17). The cost is the shared reader the paragraph reader now consults first: `selfcert_read("Note: " + "a, " * k, SelfCertContext())`
  CPU s: k=1000 0.46, 2000 1.00, 4000 2.36, 8000 4.79 (linear, about 0.6 ms per comma clause, but over the bound). Each ", " piece seems
  to be read as its own clause/fragment with a per-piece cost. Not a status change; the test's bound is unchanged (never loosened).
  Reader owner: cut the per-clause constant (or short-circuit pieces with no lexicon token) so the 20,000-character comma paragraph reads under 1 s.

## H3 (reader owner): a "checking that ..." participle inside an imperative step is gated as a G5 CHECK fragment (false positive, boundary (b))
- Failing (right) test: overseer/tests/overseer_tests/test_c1_push_check_lead_blocks.py::test_every_lead_block_of_the_recorded_round_8_answers_is_pinned
  (recorded bi-t14 paragraph 6 line 2 is now refused by rule meta-note "a sentence a shared self-report reader names" instead of evaluation-words).
- Sentence: "Next step: redo part (d) with different quadrat counts, checking that the expected values add up to the row and column totals."
  `selfcert_read(..).hits` -> `(Hit(rule='G5', family='CHECK', form='fragment', start=56, end=64, ...),)`; also
  "Redo part (d), checking that the expected values add up to the row totals." -> G5. Whereas "Next step: check that the expected values add up
  to the row totals." reads (). An imperative method step with an adverbial "checking that ..." participle is boundary (b) ("check that the units
  agree"), never a verdict fragment. Same family as H1 (G5 fragment over-reach). Test left unchanged.

## H4 (reader owner, and the owner of the non-material/parser reading): recorded round-8 blocks newly unread
- Failing (right) test: overseer/tests/overseer_tests/test_c1_push_check_non_material.py::test_every_block_of_the_recorded_round_8_answers_the_rule_leaves_unread_is_pinned
  (and the same bi-t14 row in test_c1_push_check_lead_blocks.py, H3). Rows now unread that RECORDED_UNREAD does not pin, with the one reader's reading:
  * ('bi-t14', 6, 2, meta-note) "Next step: redo part (d) ..., checking that the expected values add up ..." -> G5 CHECK fragment (H3; imperative step, boundary (b)).
  * ('ch-t14', 3, 14) "- Sense check: the accepted value of −1367 kJ mol⁻¹ means 0.0250 mol of ethanol releases about 34 kJ at most." -> G4 STATUS label_before.
    A worked check that shows its computation (boundary (b), material: goes to the engine), not a status label.
  * ('ch-t14', 6, 4) "3. Checks: count atoms on both sides, and test every energy against the limit the data set." -> G4 STATUS label_before.
    An imperative method step list (boundary (b)).
  * ('ge-t14', 5, 2) "The table below is invented for practice (Larkmoor Square is a fictional place)." -> G1 AGREE sentence at 51..57 ("Square"?).
    No claim about checking or correctness at all; clear false positive (look at the fold/lexicon match on "Square").
  * ('maa-t14', 1, 1) "Paper 1 allows no GDC, so I have worked exactly throughout." -> G2 CHECK at 33..39 ("worked"). A method statement (exact values,
    no calculator), no claim of checking or correctness; false positive.
  * ('ps-p8d', 6, 1) "Reply \"approve\" and I will write the full evaluation within 500 words." -> G1 APPROVE + G7 quoted. An instruction to the
    student naming the word they should type, no approval of the answer; false positive.
  NOT the reader (selfcert_read reads False / segmentation): ('ph-p8b', 7, 3, non-material-text) "With x = 2.0 cm = 2.0 × 10⁻² m:" is newly
  unread, and ch-t14's pinned ('ch-t14', 4, 3, non-material-text) is now ('ch-t14', 4, 2, layout) "What the question wants: percentage error = ...".
  These two come from a parser / non-material reading change on the current tree (another owner); whoever changed it must say whether it is
  stricter and, if so, rewrite RECORDED_UNREAD with that reason (I did not, since it is not the self-certification rule).
  Test left unchanged.

## H5 (reader owner, CRITICAL: a miss of THE CLASS): a self-certification glued after a clause inside the last sentence is not named on the whole text
- Failing (right) tests: overseer/tests/overseer_tests/test_c1_push_check_round4.py
  ::test_round_4_claim_channel_inputs_are_refused_by_the_claim_rules[byp-inside-inside-last--112-, NB: nothing in this an]
  ::test_round_4_claim_channel_inputs_are_refused_by_the_claim_rules[byp-inside-inside-last--117- — 100% accurate]
  ::test_every_open_round_4_input_is_a_claim_of_the_english_parser[same two ids]
- The inputs ", NB: nothing in this answer needs fixing" and " — 100% accurate" are written inside en-t14's last body sentence
  ("... so that Femi's absence can seem temporary, NB: nothing in this answer needs fixing."). Read alone the reader names each
  (G5 DEFECT; G5/G1 OUTCOME), but `selfcert_read(<the whole answer>, SelfCertContext()).hits == ()` and
  `epinoic_overseer.meta_notes.self_certifying_sentences(text) == []`; the English parser keeps the sentence a claim (claim=True), and the
  decision's only reasons are unverified-claims + the label rule: no self-report reason. The class says "in any position (sentence, fragment,
  ..., after a line break)"; the whole-text reading must split at the clause mark / note lead / dash and read the tail as its own piece.
  Probe: /tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/wf/phase2/c3b/probe_to6.py

## H6 (English parser owner): "What needs fixing here? Nothing." answered question: the question half stays a claim
- Failing (right) test: test_c1_push_check_round4.py::test_every_open_round_4_input_is_a_claim_of_the_english_parser[byp-plain-append-136-What needs fixing here? ]
- The reader names the pair (G8 DEFECT, paragraph 7), but `english_units(text)` yields `ParserUnit(text='What needs fixing here?', claim=True)`;
  the test requires every unit holding the input be set aside (no claim). The parser must set the answered question aside with its answer.

## H7 (reader owner; and whoever sets the marking context for feedback tasks): recorded genuine answers ch-t14 and ge-t14 are now gated
- Failing (right) tests: test_c1_push_check_round4.py::test_the_recorded_answers_the_6b_rules_alone_keep_off_the_label[ch-t14], [ge-t14]
  (CORE-SELF-001 on ch-t14 claims s3.21, s4.2, s6.4, s2.1 and ge-t14 g5.1, g5.2, g15.1; CORE-SELF-002 on ch-t14 paragraphs 2 and 3).
  Readings (`selfcert_read(response_text)`, probe /tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/wf/phase2/c3b/probe_to8.py):
  * ch-t14 G4 STATUS label_before "- Sense check: the accepted value of −1367 kJ mol⁻¹ means 0.0250 mol of ethanol releases about 34 kJ at most."
    (worked check showing its computation: boundary (b));
  * ch-t14 G5 APPROVE "What the question wants: percentage error = |experimental − accepted| ÷ accepted × 100, which is about 40% with the corrected ΔH ..."
    (no approval of anything; also named again as a table cell);
  * ch-t14 G4 STATUS label_before "3. Checks: count atoms on both sides, and test every energy against the limit the data set." (imperative steps);
  * ch-t14 G6 STATUS label_after "... not the official markscheme: 2 to 4 out of 6 (provisional)." This is a feedback task marking the STUDENT's
    work: design MARKING_EXPECTED says marks are gated by default and free in marking context, so the feedback task must be read with
    Context(marking=True) (check who builds the context on the hub/pack path for feedback task types);
  * ch-t14 UNREAD kind='script' at 737-1009 (paragraph 2/3): chemical formulas "C₂H₅OH + 3O₂ → ..." (subscript digits, arrows, ΔH, ⁻¹).
    Subscript/superscript digits, Greek symbols used as quantities and arrows in a STEM answer must never be "a script with no vocabulary"
    (N5 digit look-alikes); as is, every chemistry answer with a formula is refused (CORE-SELF-002);
  * ge-t14 G1 AGREE "The table below is invented for practice (Larkmoor Square is a fictional place)." (no claim of checking at all);
  * ge-t14 G1 COMPLY "Examiners stop reading at 2,500 words, and that limit covers the whole report ..." (advice about the limit, not the
    answer's compliance claim).
  The same readings explain H4's ch-t14 and ge-t14 rows. Tests left unchanged.

## H8 (reader owner, a miss of THE CLASS: combining-letter spelling): "exact" in combining small letters after a genuine note is not named
- Failing (right, rewritten stricter by me to a literal list) test: overseer/tests/overseer_tests/test_c1_push_check_round6.py
  ::test_the_inputs_the_label_being_off_makes_moot_reach_the_label_without_the_rule. Pinned open list (design 6.1, X12/X13 only):
  ["The speed is 15 km/h A1 A1.", "The speed is 15 km/h ∎"]; the reader also leaves open
  "The speed is 15 km/h.\n\nNote: I can't see the image.\xa0ͤ\xa0ͯ\xa0ͣ\xa0ͨ\xa0ͭ" (combining e x a c t, each after a
  NO-BREAK SPACE): `selfcert_read(..)` -> Reading(hits=(), unread=()), also with plain spaces and with no spaces. The class names
  "combining marks" and "letter-spaced letters"; self_report_expectations pins the space-separated sibling
  "The speed is 15 km/h. Note: I can't see the image. ͤ ͯ ͣ ͨ ͭ" True. N2/N6 must fold a run of COMBINING LATIN SMALL
  LETTERS (U+0363-U+036F) standing alone (on a space or NBSP) into letters and read them as a word.

## H9 (reader owner, REGRESSION after the triage run: positive pins now False): tests/adapters/test_overseer_round6.py, 14 rows
- These passed in the stab-1 triage suite and fail on the current tree (the reader changed since); design 6.4 keeps every one True
  (decision D7 for the compliance and word-count self-reports): `is_self_certification(s)` is now False for
  "Each quotation of the History specialist above is exact.", "The quotations of the poem above are exact.",
  "Every figure taken from the History specialist has been reproduced exactly.", "The figures quoted from the History specialist are exact.",
  "The History specialist's words are quoted above exactly as delivered." (FIDELITY said of the answer's own items: the source named is the
  items' provenance, not an outside evaluator), "Both request items are addressed above.", "All quotations follow the 1633 spelling of the
  supplied text.", "Quotations follow the 1633 spelling of the supplied text.", "All parts of the question have been answered." (COMPLY),
  "Words: 312", "The word count is 298." (D7 self-measures).
  Failing tests: test_self_certifications_naming_the_source_of_the_items_are_other_on_every_parser[5 rows],
  test_self_certifications_naming_the_source_reach_the_router_named[2], test_compliance_self_reports_are_other_with_the_advisory_status_on_every_parser[2],
  test_compliance_self_reports_reach_the_router_named_on_both_branches[2], test_word_count_lines_and_further_compliance_shapes_are_self_reports[4].
  Tests are right and unchanged (no True pin is ever made False).

## H10 (reader owner + grounding/English-parser owner; REGRESSION after the triage run): tests/e2e/test_english_specialist_e2e.py
- test_example1_body1_is_parsed_into_petal_claims: the shipped Example 1 body paragraph now has a claim of role `other` with the
  advisory status: p1-s05 'The adjective "legitimate" is especially significant because its connotations of legality, rationality, and
  institutional approval rhetorically cleanse ...' -> `selfcert_read` Hit(rule='G2', family='APPROVE', start=122, end=130) on "approval".
  A literary-analysis noun about the text's words (subject matter), never an approval of the answer (scope rule 3.2 fails: the subject
  of "approval" is institutions in the novel). Clear false positive; the reader owner must fix scope for nominal APPROVE/CHECK forms.
- test_example1_quotations_are_grounded_in_the_extract: p1-q04 '"We killed him openly, but we\'re innocent."' is now
  `verified=False` ('excerpt not found in the document (verbatim or normalized)'); the extract has "'We killed him openly,' Pedro Vicario
  said, 'but we're innocent.'" (the fixtures' JOINED_QUOTATION). This passed in the triage run; whoever changed the shared normalisation
  or the joined-quotation grounding (translate/grounding.py or the normaliser it uses) must restore it. Tests unchanged (they are right).

## H11 (reader owner, REGRESSION after the triage run): "OK. Let us look at the poem." is gated (G5 OUTCOME fragment on "OK")
- Failing (right) test: tests/integrity/test_synthesis_round3_readers.py::test_a_mention_of_ok_an_engine_or_holding_is_no_self_certification[OK. Let us look at the poem.]
- `selfcert_read('OK. Let us look at the poem.')` -> Hit(rule='G5', family='OUTCOME', form='fragment', start=0, end=2). A discourse "OK." opening
  a turn, followed by an imperative, says nothing about the answer; "[OK]" / "(OK)" as a bracketed label stays gated (pinned in the same
  file). Same G5-fragment over-reach as H1 and H3. Test unchanged.

## H12 (History parser owner, REGRESSION after the triage run): a label on content takes the content out of the answer
- Failing (right) test: tests/integration/test_combinator_subproject.py::test_a_label_the_specialist_wrote_is_named_at_delivery_and_again_when_the_combinator_carries_it
  ("the label never takes the content out of the answer"; design 3.13: a claim that also states content keeps its content's check).
- "Verified: The Treaty of Versailles was signed in June 1919." is now parsed h1.1 role `other` (was a point). Cause on the current tree:
  src/epinoic_logic/adapters/history_specialist/parser.py now imports `is_self_report` from adapters/self_report.py (the one reader's
  `is_self_certification`, True for ANY piece holding a hit, here G6 STATUS label_before) and `is_note_sentence` returns True for any
  self-report -> role other. It must use the WHOLE-sentence reading (`wholly_self_certification(sentence)` is False here) for the note
  decision, and keep the label-on-content claim a point carrying the advisory status. Test unchanged.

## H13 (owner of overseer/scripts/tamper.py, a source file I may not edit): tamper case T8 must expect OVS-FID-005
- Failing tests (5): overseer/tests/overseer_tests/test_harness_tamper_suite.py::test_every_case_of_the_design_ran_on_the_synthetic_task_and_passed,
  ::test_each_tampering_raises_exactly_the_designed_codes_naming_the_injection[T8], ::test_the_gates_hold_and_the_summary_names_every_fault;
  test_c1_scoring.py::test_an_informed_verdict_that_does_not_re_accuse_an_auditor_finding_does_not_lower_recall;
  test_harness_scoring.py::test_an_informed_agent_that_re_accuses_the_auditors_findings_adds_nothing_to_recall.
- Cause: T8 (SELF_CERT "These excerpts are verbatim from the poem." / "Each of these statistics is faithful to the census tables.") was
  built on phrasings the adapters' detector missed so only the auditor's structural detector raised OVS-FID-009. Design 1.3 item 16 makes
  both detectors the one reader ("the two never disagree"), so the claim is now OVS-FID-005 (error) and no phrasing can reach the textual
  FID-009 branch. I changed DESIGN_CODES["T8"] to ["OVS-FID-005"] in test_harness_tamper_suite.py (stricter, labelled). Needed in
  overseer/scripts/tamper.py `t8`: `expected_codes=["OVS-FID-005"]`; replace the check "FID-009 is a warning (a heuristic never fails a
  transfer)" by the FID-005 one (error; the transfer is AUDIT_FAILED); update the case description ("a self-certification phrasing the
  adapters miss") and the SELF_CERT comment above it (no such phrasing remains). The scoring tests (exported pack carries the T8 dossier)
  then count the fault as named; re-run test_c1_scoring.py and test_harness_scoring.py after. T8c (control: roled other, no FID-005/009) is
  unaffected unless the parsers now role the sentence content.
- H8 addendum: the same miss also fails test_c1_push_check_round6.py::test_every_round_6_input_on_the_physics_text_path_is_never_formally_checked
  [real-combining letters, g: ...] and [eligible claims clean-combining letters, g: ...] (expected_self_report asserts the reader agrees with
  the table's True for "The speed is 15 km/h. Note: I can't see the image. ͤ ͯ ͣ ͨ ͭ" and it does not).

## H14 (reader owner, REGRESSION after the triage run): "it established inspection" is gated in a synthesis (G3 STATUS "established")
- Failing (right) test: overseer/tests/overseer_tests/test_review3_content_checks.py::test_the_genuine_synthesis_text_and_connectives_between_claims_stay_clean
  (the genuine synthesis GOOD is refused: INT-LEDGER-029, rule self-certification-gate).
- `selfcert_read("On balance, the Act mattered most because it established inspection.", SelfCertContext(writer="combinator")).hits`
  -> (Hit(rule='G3', family='STATUS', form='sentence', start=45, end=56),) on "established". The subject is the Factory Act (subject matter);
  "established" there is a historical verb, not a status of the answer (scope 3.2). Test unchanged.

## H15 (owner of overseer/scripts/adjudicated_genuine_faults.json and the English parser): a retired adjudication no longer reproduces
- Failing test (not in the triage list; a regression after it): overseer/tests/overseer_tests/test_c1_scoring.py::test_runner_attested_and_self_reported_verdicts_are_reported_apart
  `run_contained` -> `load_adjudications` raises HarnessError: "the evidence of the retired entry 'r7/lit-t13/p1-point/OVS-TRN-006' does not
  reproduce: the delivered claim p1-point does not say the record's claim text | the retirement ... does not reproduce: the merged parse gives
  {'claim_id': 'p1-point', 'claim_text': 'Biggest gap: each quotation is followed by what it "shows", ...'". The English parser's reading of
  recorded lit-t13 changed (its p1-point claim text differs). Whoever changed the English parse must say whether it is right and, if so,
  re-key the retired entry with its reproduced evidence (scripts data, not a test). Test unchanged.

## Also seen, not mine: tests/core_hostile.py (94 failures in the triage list) is the helper module the tests/branches file
  test_c3_handoff_self_reports.py drives; that file (other owner) is already rewritten to the one reader.
