# Handoff from stabilisation fixer "tests-branches", round 1

Tests under tests/branches rewritten to the selfcert public API or to the stricter rule (see the fixer's report). The asserts
below are RIGHT and still fail on the current tree: they are reader (selfcert) defects, not test defects. Do not move the pins.

## Reader (selfcert) defects

1. MISS: "The speed, verified." reads no hit (selfcert.is_self_certification False). A check label after the answer's own item
   is THE CLASS (label/fragment), with or without a figure before it. Pinned True in
   tests/branches/test_c3_clearance_self_reports.py::test_a_trailing_check_label_is_read_at_its_comma_only
   (stricter: the older private trailing-label pattern needed a figure). Control that must stay False there:
   "The results were 15, confirmed by the ONS." (named outside source, boundary (b)); and the 20,000-character
   "The crisis followed (A1) (A1) ... z" stays False under 1 s.
2. FALSE POSITIVE: '"I have checked everything," says Macbeth.' and "'All is checked', Hamlet says." read G7 CHECK relayed
   (True). A character's quoted words credited by an inverted reporting frame are the analysed text's (boundary (b)).
   Pinned False in test_c3_clearance_self_reports.py::test_the_reporting_frame_and_the_pipeline_readers_read_a_joined_word_run_once
   (Macbeth was already pinned False there; Hamlet is the same frame postposed, newly asserted in place of the deleted
   regex-group assert). Control kept True: "“The solver certified each step,” Kershaw wrote."
   (Same defect as the reader-group rows on C3_CORRECT_WORK's Macbeth/Hamlet/narrator/Ophelia entries.)
3. FALSE POSITIVE on c2/sp-t15 (recorded Language B answer): g7.2 "Es cierto, pero el problema no es el turismo en sí, sino
   el modo en que se gestiona." is gated (G5 OUTCOME 'cierto'): a concession in an argument, not an assessment of the answer.
   tests/branches/test_d9d10_recorded.py now pins status ACCEPTED_WITH_FINDINGS (word-count note g11.1 gated, decision D7) AND
   that the self-certification findings name exactly ['g11.1@language-b-spanish-specialist'] (SELF_NAMED); it fails only on g7.2.

## Test-support owner (tests/timing.py, not a tests/branches file)

4. tests.timing.empty_caches() does not empty selfcert's one-entry last-long-text slot (epinoic_logic.selfcert._LAST_LONG is a
   plain list, not a functools cache or BoundedLRU), so two calls on the same text over 16 KiB after empty_caches() are not
   both first readings (the second is served from the slot). tests/branches/test_c3_clearance_self_reports.py works around it by
   reading another long text (_clear_reader_caches). Suggest: empty_caches() also clears it (or selfcert exposes a cache_clear).

## Triage note

5. failures.json did not list tests/branches/test_c3_handoff_self_reports.py::test_the_new_readers_are_linear_on_hostile_input
   (94 shapes), which failed in suite2.log on the deleted privates SR._c3_internal_decision / SR._double_negated_check. Fixed in
   this round (same cause as the listed control rows): the one reader now reads the same uncut inputs; all 94 pass.
