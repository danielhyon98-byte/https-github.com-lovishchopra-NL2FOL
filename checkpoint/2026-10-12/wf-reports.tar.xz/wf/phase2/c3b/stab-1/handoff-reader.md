# Handoff from the stabilisation fixer "reader", round 1

Owner of this run: `src/epinoic_logic/selfcert/**` and `tests/selfcert/**` only. Everything below needs another owner.

## 1. Behaviour changes of the one reader that callers and pinned values may see

- `selfcert.is_self_certification(text)` now fails closed on an unread run of kind "script" (a sentence of three or more words in a
  script the reader has no vocabulary for; Thai, Lao, Khmer and Myanmar are counted by letters, as they are written without spaces).
  `read(text).hits` is unchanged in meaning (an unread run is never a hit); `Reading.refuses()` was already true for such text.
  Pinned by `tests/branches/test_c3_clearance_self_reports.py::test_a_script_with_no_checking_vocabulary_still_fails_closed`.
  Callers that branch on `is_self_certification` for roles now role such a sentence as a self-report (fail closed).
- `selfcert.wholly_self_certification("Answer (verified): 15 km/h.")` is True: a label beside a bare value (no relation, no clause)
  is the whole claim. Content with a verb or a relation beside a label stays a claim (`"Answer (verified): x = 4."` is False).
- A status label's value is read too: `"VERIFIED: all claims checked and confirmed."` now carries a G6 label hit and a G1 hit on the
  value (it was the label alone). `adapters/markdown._self_certification_not_label` then sees a non-label hit, so the piece is a
  self-report as a whole (fixes count_paragraphs / count_answer_words pins in tests/channel round2/round3/robustness).
- `pieces.report_texts` keeps a field whose words appear in the response only inside quotation marks (an outside party's masked
  quotation); `report_field_self_reports` then names it (tests/branches/test_c2_hold_remedy2_round2.py field-copy cases).
- `pieces.sentence_spans` now ends a sentence at a blank line and after a closing `"}` / `]`, and never inside a straight-quoted span
  of at most 600 characters. Pieces that relied on a sentence running across a blank line now read two sentences.
- `selfcert` long-text cache: texts over 16 KiB are cached 8 deep (functools, emptied by `tests/timing.empty_caches`); the earlier
  hand-kept one-entry cache outlived `empty_caches` and served timing samples from memory.

## 2. Pins that may need a re-reference by their owners (tests_other / tests_branches)

- Corpus digests re-referenced at c3b (`tests/branches/test_quant_si_reading.py::test_general_reading_is_byte_identical_on_the_reference_corpus`,
  `tests/branches/test_c1_clearance_parsers.py::test_the_re_referenced_corpus_text_differs_by_the_fell_x_per_cent_rule_alone`,
  `tests/branches/test_integration_gate3_quant.py::test_the_re_referenced_corpus_texts_differ_by_the_self_certification_rule_alone`):
  the triage found item 538's recorded digest pinned a false positive (now freed) and items 0/393 ('as clear and still', now
  freed), 554 ('Expected: ENTAILED ...', now gated again as a status label) and 550 changed. If the r3 run of this fixer still shows
  these three failing, the recorded digests need a re-reference from the corrected reading (a test owner's change, never mine).
- `overseer/tests/overseer_tests/self_report_expectations.py` EXPECTED: unchanged by this fixer; every sentence of the table was
  probed (1,439 sentences of the test text modules and expectation tables; 1 apparent mismatch is the Greek unread-script entry,
  which the tests assert as an unread run, not a hit).

## 3. Not done here (other owners)

- `adapters/self_report.quotation_in_scope` reads only `C:anchor_idioms`; it passed the round-2 cases in a targeted run, but it
  still differs from the reader's own answer-reference test (`reader._relay_has_no_reporter_theme`, `_ANSWER_SELF_NOUNS`). A thin
  call into a public selfcert function would remove the duplicate (owner of adapters/self_report.py).
- The design's `context_for` peer documents: the reader now treats a peer agent's items ("taken from the History specialist", "the
  History specialist's words") as the answer's items on every branch. If the combinator wants a narrower reading it should pass
  `Context(peer_documents=...)`; no caller does today.

## 4. Optimisation records (not fixed: they change no receipt)

- `read_text` on 32 KB of '{"a": 1, "b": [' x 2000 takes about 0.45 s (linear: 0.40 s at 20 KB, 2.15 s at 80 KB of "(a " x n). The
  History branch reads the same 32 KB text twice under two contexts (Context() and the plan's); a shared context key would halve it.
- A line of 20,000 characters of mark codes now reads in about 0.55 s (it took tens of seconds); 80,000 characters in about 2.4 s.

## 5. Found while validating (owner: branches/packs.py)

- `tests/branches/test_c3_handoff_self_reports.py::test_control_a_tick_on_a_claim_about_checking_in_a_model_line_is_still_named`:
  the one reader names the tick on "Model: I checked that a higher temperature means faster molecules, ... rises ✔." (G6 MARK,
  `selfcert.read` of the sentence and `selfcert.text_spots` of the whole ph-t16 answer both hold it; rule model-marks keeps the tick
  because the marking point holds "checked"). `packs._self_certification` drops it: for a sentence with an SI statement it replaces
  the sentence's hits by the hits of the statement as written (`written[(pi, si)]`), and that statement does not carry the tick, so
  the `continue` ("the SI view masks quantities") discards a MARK hit that is no quantity. Keep the sentence's own non-quantity hits
  (a MARK, a label) when the as-written statement has none.

## 6. Found after the r3 group run (owners named; the reader's side is fixed)

- Same root as section 5, Economics branch (owner: branches/packs.py): `overseer/tests/overseer_tests/test_c2_hold_remedy2_round3_gate.py::
  test_the_routers_decision_never_allows_a_round3_self_report[Economics-x = 4 ✓]`. The one reader names the tick (`selfcert.read("x = 4 ✓")`:
  G6 MARK symbol) and the auditor's own reading does too, but the Economics receipt carries no CORE-SELF-001: the SI view of "x = 4"
  replaces the sentence's hits and drops the MARK, so the audit fails (OVS-FID-005, AUDIT_FAILED) and the router reports
  NO_DELIVERABLE_OUTPUT instead of the self-certification gate. The fix of section 5 (keep a sentence's non-quantity hits when the
  as-written statement has none) covers both.
- Pin conflict (owner: tests/branches/test_c1_clearance_parsers.py, a test rewrite): `test_a_self_certification_is_named_on_every_branch_
  and_is_never_material["Todas las cifras han sido comprobadas por el Instituto Regional de Estadística." x 6 branches]` pins a named
  outside institute's check of the figures as a self-certification, while `tests/branches/c2_hold_texts.py::CORRECT_WORK` pins the same
  class free in English ("All the figures below were verified by the National Audit Office.", "All of the figures in Source B were
  checked by the statistics office before publication.", "The World Bank has verified every figure above.") and the stabilisation
  boundary (b) says a named outside source's check reported as evidence is never gated. The reader reads both languages alike (free);
  the c1 row needs the test owner's re-pin (e.g. a credited check of "this answer"'s figures, "Todas las cifras de esta respuesta han
  sido comprobadas por ...", which the reader gates as an explicit reference to the answer, like the English "The values in this answer
  were verified by the National Audit Office.").
- Not the reader (owner: the Physics parser or the pin's owner): `overseer/tests/overseer_tests/test_c1_push_check_non_material.py::
  test_every_block_of_the_recorded_round_8_answers_the_rule_leaves_unread_is_pinned` now differs by ('ph-p8b', 7, 3, False,
  'non-material-text') alone: the Physics parser roles "With x = 2.0 cm = 2.0 × 10⁻² m:" `other`; the reader reads nothing in that
  paragraph, and the result is the same with the reader as it was before this round (checked on a copy with the earlier package).
  The two other extra blocks of that test (ch-t14 4.7 "Provisional mark: 1 to 2 out of 2", ec-p8a 1.1 "... the tariff passes into
  the price ...") were the reader's and are fixed.
- `adapters/self_report.quotation_in_scope` (section 3) still fails `tests/branches/test_c2_hold_remedy2_round2.py::test_a_quotation_in_
  the_answers_scope_refers_to_this_answer["every figure here has been verified."/"every figure in it has been verified."]`; the
  reader's own reading of both quotations is a hit (an item of the answer with an anchor), so the thin call of section 3 fixes them.
- Corpus digests (section 2) and `tests/channel/test_c2b_handoff_channel.py::test_sp_t15_genuine_meets_its_bound_and_addresses_both_tasks`
  (a word-count bound of the channel; the reader names no sentence of sp-t15) remain for their owners.

## 7. Timing (bracket-heavy branch tests)

- `test_bracket_heavy_answers_cross_the_english_branch_quickly[2000-unclosed-fragments]` and the History twin failed in the r3 run at
  about 5 s: a label inside a label's value was read once per key on the remainder (quadratic on '{"a": 1, "b": [' x 2000). Fixed
  (two levels of nested labels at most); `tests/selfcert/test_linear.py` family "a run of label keys". The reader's share of that
  answer is now about 0.5 s (both bracket-heavy branch tests pass when run alone after the fix); the branches still read the same long text two to three times under different contexts (section 4).
