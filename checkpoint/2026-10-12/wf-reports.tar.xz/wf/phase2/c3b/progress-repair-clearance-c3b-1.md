Done: replaced the 6 raw U+202E/U+202C controls on lines 31-33 of tests/branches/test_c3b_attack2_branches.py with \u escapes (same runtime strings).
Done: ran tests/test_no_raw_bidi_controls.py, tests/branches/test_c3b_attack2_branches.py and tests/selfcert: 1680 passed.
Next: nothing; return result (no commit).
