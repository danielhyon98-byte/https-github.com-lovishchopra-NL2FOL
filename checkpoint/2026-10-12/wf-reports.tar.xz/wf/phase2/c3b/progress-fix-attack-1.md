# progress fix-attack-1
- run 1 started 11:56 17 Nov. No earlier progress file.
- probe kit: scratchpad fa1/ (cases.py POS/NEG from the attack list, probe.py, r.py one-off reader, genuine.py = c1-c3 genuine answers; genuine_before.txt 21 hits all FP)
- DONE: build_fold_table.py marks by Unicode name (check marks / ballot X) -> fold_table regenerated (1F5F9 etc.); normalise._reordered_runs (bidi override/isolate run = hidden unread)
- PLAN: new selfcert/meaning.py (sentence meaning layer: content-free assessment HIT + boundary CLEAR frames), lexicon classes, then branch/quant items, stall in text_spots
- 13:10 meaning.py + read_text integration; probe pos miss 25/120, neg fp 12/44; dev 1 miss/1 fp; genuine 10 hits (from 21)
- 13:35 FP 1/44 (word count, pinned D7), dev 0/0, misses 25
- 14:00 probe pos miss 0/120, FP 1/44 (word count pinned), dev 0/0, genuine 6. NEXT: genuine leftovers, broaden corpus (r1-r7, held c2 rounds), then tests, then branches/quant
- 14:35 probe 0 miss/1 FP(pinned), dev 0/0, genuine c1-c3 3 (bi-p9b baseline, word count pinned), r1-r7 0. NEXT: tests/selfcert run, marking items, generalisation probe, then tests + branches
- 14:55 marking own-marking themes; text_spots windowed (20k marks 2.0s/90MB, 40k 3.0s, 200k verified 3.8s). NEXT: self_report_spots/wholly check, quant FPs (log2, PED, es thousands, es question), geography, tests
- 15:10 (wall ~12:50 UTC) DONE quant: lexer log2 base, elasticity following-word order, Spanish point thousands (lexer + worked.py contextvar), ¿ sentence split (stem segment, layout, generic, request_parser); wholly bisect. NEXT geography items, then tests
- 15:35 geography: MAX_COMPOUND_YEARS 200, _CRITICAL_RE bracket, _row_named lists, _anchor bisect, _table_count once; geo probes cases_fix all OK (fa1/geo). NEXT: stall timing, then tests
- 15:55 tests written: tests/selfcert/test_attack_round1.py (172 pass), tests/branches/test_c3b_attack1_branches.py (22 pass); tests/README.md section. Background runs A (selfcert+branches) B (adapters) C (channel+integrity+service) logs in fa1/runs/. NEXT: triage failures
- 16:40 fixes after runs: 'I' not a list marker, M2 dist-part/X18 colon, mention needs det/no colon, according-to/hence frames, superlative most, generic present passive procedure, descriptive active check. Rerunning failing files
- 17:20 more reader frames (SCORE verbs/SRCEVAL alone, deontic, evaluator words relay, explicit-answer quotes, masked quote groups, src noun last word, Spanish defect nouns, label key verb). branch/selfcert sets green except quant reference digest
- 17:35 re-referenced quant corpus text (sha256_before_attack1) + gate3 test list (stricter, names it); relaunched A2 (branches) B2 (adapters) C2 (channel/integrity/service)
- 18:05 adapters fixes (need-to idiom, synthesis words content on specialist branch, X7 blanket over parts, X16 reading confirmed by evidence, ASSURE permission, Proved. structural, to-be-checked purpose, worked-check label). A2/B2/C2 running
- 18:30 synthesis-claim corpus 4->0 FP (whole quotation claim, 'for comparison' label, relay fidelity X8). waiting A2/B2/C2
- 18:45 waiting: A2/C2 (bg bikvg6f9b), B2 running, gate3+round6 adapters (b3g3fmr37). Remaining plan: fix failures, rerun test_linear alone, StructuredOutput. left_undone: geography misses (new reader kinds), word count D7 pin, truncated attack list tail
- 19:40 more boundary/positive fixes from A2/B2 failures; next: rerun targeted files
- 20:30 fixed remaining D1/D2 failures (took-care implicatives, generic bare plural guard, imperative adjective guard). Final runs F1 (selfcert+branches) F2 (adapters integrity service channel) F3 (stem + overseer selfcert gates)
- 21:20 F1 16 fails fixed (used-to implicative). waiting F2/F3

## Step: final validation fixes (stem regressions)
- chem-eqn-6 ("The balanced equation is Fe3+ + e- -> Fe2+.") was gated: "balanced" removed from m_pos/meta (attributive chemistry word); a
  token with digits and letters (formula/unit, <=8 chars, not a hexadecimal identifier, no hyphenated allocation) is content.
- "The textbook says \"...\"": a masked quotation token counts as content (an outside party's quoted words are subject matter).
- Fuzz test test_the_rewritten_patterns_read_what_the_old_ones_read caught a glued 42-char token read as content: length bound 8.
- Regressions: tests/selfcert/test_attack_round1.py FREE + GLUED.
- probe 0/120 miss, 1/44 FP (word count, pinned D7); dev 0/207 miss, 0/213 FP; genuine 2 (bi-p9b self-recalculation, sp-t15 word count).
- Running: tests/stem tests/selfcert tests/adapters + branches self-report/attack files.
- FINAL: tests/stem tests/selfcert tests/adapters + branches self-report/attack files: 8834 passed. tests/branches tests/channel
  tests/integrity tests/service: 11832 passed, 1 skipped. overseer test_c3b_selfcert_paths: 155 passed. fold table --check: no drift.
  DONE; StructuredOutput next.
