# progress fix-attack-6
started; nothing done yet. Reading design + attack-5 progress.
Kit: scratchpad fa6/ (cases6.py, probe.py [MISS/FP/RUNON], runon.py, runon2.py, dbg via d.sh, lexadd.py; lexicon.before.json baseline)
DONE (reader): _folded_letters in _net_found (fold-table letters + math alnum read as text; formula tokens with <=2-letter runs are symbols)
 -> math italic / Greek formula / fullwidth / styled FPs fixed. G9 Latin nets honour own C:neg negator before the word (No verificado).
 _runon_breaks + read_text wrapper (_read_text_one): alt reading with line breaks at run-on label boundaries; RUNON miss 286->0.
NEXT: run tests/selfcert; FP scan of recorded genuine answers; then MISS (24) phrasings, FPs (22), marking, banner, paths, branches.
DONE: run-on breaks refined (quotes, tables, units, head_only comma/short-verdict, styled/markup labels, dashes, tags). Attack p22 rate 1756/5472 -> 24/5472
 (fa6/p22.py uses pyc corpora copied to fa6/pyc). fpscan.py (recorded genuine answers + dev negative): 0 new hits.
NEXT: selfcert tests; then 24 MISS phrasings (reader/lexicon), FPs, marking, banner, paths (bare_copy quotes, payload_spots), induction, branches.
DONE (reader, step 3): lexicon widened (DEFECT contradiction/conflict/comment..., raised an eyebrow, say against, ponerle pega, flag, marcar, restar;
 OUTCOME satisfiable; ASSURE as gospel, respondo de, con mi firma; QUALITY gold standard, nothing to be desired; APPROVE waved through;
 SCORE pass mark, nivel 7; CHECK con lupa, controles de calidad; weak premature/hasty/too early; report_back finish/end...).
 Code: coordinated predicate after unknown verb (_subject_for), stake frame sign/under, Spanish free relative 'lo que he escrito' (subject walk+eval_class),
 haste words after trigger (_weak_before), sentential relative after gerund (without checking it, which...), relative before aux w/ named-source context (FSC),
 generic definitional subject (_generic_subject; trace table / unit tests), 'lo que confirma' sentential relative, paradigm mention (meaning._paradigm_span),
 mention verbs (se conjuga), lab evaluation frame (_LAB_*), styled rule fix. Probe: MISS 3/24, FP 7/60 (hub-level ones + Source B), RUNON 0, p22 24/5600.
NEXT: run selfcert tests+fpscan; marking stand-by; banner fail-open; paths; hub-level; induction; branches; tests file.
DONE (step 4): all 24 MISS + marking pass (relay your->my for INT reporters, llegar plain verb, coordinated subject cut, meaning own_rel, ASSURE marker pledge internal);
 ASCII-art banner unread 'art' (selfcert/__init__ _art_runs, read() now art-aware via _read_plain); _bare_copy any quote mark (pieces._opening_mark);
 payload_spots _shape_faults (fail closed) + overseer meta_notes.payload_self_reports prepends '(unreadable)' spots. selfcert tests green (sc4), fpscan 0.
 Removed DEFECT 'comment(s)' (broke a positive pin) -> APPROVE idioms 'no comments/zero comments'.
NEXT: hub-level (Verification heading, Source B claim, induction INT-SUBJ-001), path probes (p21*), branches, then regression test files.
DONE (step 5, hub): packs._self_certification confirms sentence hits with the paragraph as written; selfcert.certifies_where_written (STEM parser
 self_report); overseer meta_notes: self_reporting_notes/_certifies_where_written, _status_holds (parser status confirmed where written) in
 self_reported_statuses + payload_self_reports. Hub probe fa6/hub/hubcw.py: Verification heading x5 + Source B now delivered.
 STEM parser: glued Greek divisor (10/2π = 10/(2π)) in stem/parser.py term() (+ _greek_ident at module end).
NOT DONE: induction 'n = k'/'n = k + 1' stem_algebra FP (relations.py, large) -> left_undone unless time.
NEXT: path probes p21*, then tests files, then targeted test dirs, then branches.
DONE (step 6): article 'A' after label value; tests written: tests/selfcert/test_attack_round6.py (pass),
 overseer/tests/overseer_tests/test_c3b_attack6_paths.py (pass; run with -c pyproject.toml --rootdir .). Path probes: p21 6->fixed, p21b/c/d/e clean,
 p24 banner refused, p17 fields withheld, p5 no success shown.
NEXT: background targeted runs fa6/runs/t_*.log; then branches items.
DONE (step 7, branches FPs): geography _NOT_A_CELL_AFTER_RE comparison/ratio figures + _DERIVED_BEFORE_RE verb forms; grounded_figures
 _DERIVED_FIG_BEFORE_RE; language_b _BOUND_BEFORE_RE range bounds + digit backtracking fix in _WC_NUMBER_RE.
NEXT: tests/branches/test_c3b_attack6_branches.py; check t_core/t_overseer logs; branch misses as time permits.
DONE: tests/branches/test_c3b_attack6_branches.py (FPs, compound unit, transect cover); worked.py _compound_key; geography _COVER_LEN_RE.
NEXT: check t_core/t_overseer, run tests/branches (bg), then maybe more branch misses; then StructuredOutput.
DONE: geography _AT_POINT before/after/by (+test). Running t_adapters, t_overseer_sel in bg. NEXT: tests/branches + other dirs.
DONE: adapters dir green after fix (no run-on break after '=' etc.: 'checked: bool = False'). p22 24/5600.
RUNNING: t_overseer_sel, t_branches, t_rest (fa6/runs). Induction FP -> left_undone. Many branch misses -> left_undone.
DONE (step 8, regressions from targeted runs): run-on fixes: no break after operators/pure punctuation/closing quote; _assessment_end copula only;
 aligned rows (2+ wide gaps or backticks) no gap breaks; tail-only restriction for short tails after long heads; short-verdict head needs a verb;
 second reading only of changed paragraphs (cost). test_c1_push_check_round5 MID_SELF_REPORTS rewritten STRICTER (+'mid sq all good').
NEXT: rerun previously failing tests; t_rest result; final StructuredOutput.
DONE (step 9): reader window: a cut window takes the local subject before the cut (not the opening 'I can't'); own-subject check.
 All previously failing targeted tests pass individually. FINAL RUNS started: fa6/runs/f1..f4.log
FINAL RUNS (code frozen): f1 selfcert+adapters 100% 0 failures; f2 overseer selected, f3 branches, f4 channel/integrity/stem/translate/contract/e2e/engine running.
NEXT: when f2-f4 done -> StructuredOutput (fixed list + left_undone: induction, run-on lowercase tails, most geography/LB misses).
