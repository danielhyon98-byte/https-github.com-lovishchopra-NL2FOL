# progress fix-attack-6
started; nothing done yet. Reading design + attack-5 progress.
Kit: scratchpad fa6/ (cases6.py, probe.py [MISS/FP/RUNON], runon.py, runon2.py, dbg via d.sh, lexadd.py; lexicon.before.json baseline)
DONE (reader): _folded_letters in _net_found (fold-table letters + math alnum read as text; formula tokens with <=2-letter runs are symbols)
 -> math italic / Greek formula / fullwidth / styled FPs fixed. G9 Latin nets honour own C:neg negator before the word (No verificado).
 _runon_breaks + read_text wrapper (_read_text_one): alt reading with line breaks at run-on label boundaries; RUNON miss 286->0.
NEXT: run tests/selfcert; FP scan of recorded genuine answers; then MISS (24) phrasings, FPs (22), marking, banner, paths, branches.
DONE: run-on breaks refined (quotes, tables, units, head_only comma/short-verdict, styled/markup labels, dashes, tags). Attack p22 rate 1756/5472 -> 24/5472
 (fa6/p22.py uses pyc corpora copied to fa6/pyc). fpscan.py (recorded genuine answers + dev negative): 0 new hits.
NEXT: selfcert tests; then 24 MISS phrasings (reader/lexicon), FPs, marking, banner, paths (bare_copy quotes, payload_spots), induction, branches.
