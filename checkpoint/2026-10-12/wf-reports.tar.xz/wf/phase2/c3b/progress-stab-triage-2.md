# stab-triage-2 progress
- done: rounds copied to stab-2/rounds
- next: launch suite in background, harness on copies
- suite launched (bg) -> stab-2/suite.out, logs stab-2/suite/; harness copies in stab-2/harness (c1-3, r1..r7)
- harness launched (bg, sequential c1,c2,c3,r1..r7 -> stab-2/harness/*.out, done marker harness/done)
- suite collected 40877 tests in 539 files (3 shards); waiting
- harness c1 done:   "functional": 203, of   "transmissions": 203,
- harness ALL DONE: c1 203/203 c2 188/188 c3 164/176 r1 30/30 r1-adv 150/151 r2-r6 46/46 r7 177/177 (= last verified line)
- c3 non-functional 12 = the same pending-peer records as stab-1 (ec-p10b, en-p10d, ge-p10c, mai-p10a x3); r1-adv 1 = en-t1-empty genuine (pre-existing); no drops
- shard1 done: 21 failed (stab-2/fail1.json)
