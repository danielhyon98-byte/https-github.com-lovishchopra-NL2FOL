# progress stab tests-other round 3
- [x] A: test_c1_push_check_round5.py: assert_excluded_for_a_self_certification replaced by assert_refused_as_a_self_certification (hub path), callers updated, _physics_text_audited returns rc first
- [x] B: test_subproject_layout.py:64 pack 2.2 digest pin -> ef3bed4f... with comment
- [x] validated: both files 1005 passed
DONE; no handoff needed
