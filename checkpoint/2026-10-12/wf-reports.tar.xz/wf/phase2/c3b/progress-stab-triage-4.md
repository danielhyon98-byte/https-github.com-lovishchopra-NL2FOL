# stab-triage-4 progress
- step 1: rounds copied; suite to start in background (suite.out)
- next: harness copies of clearance c1,c2,c3
- suite launched bg -> stab-4/suite.out (shards in stab-4/suite); harness copies c1-3 + r1..r7 in stab-4/harness, runner harness/run.sh launched bg (harness/done marker)
- suite collected 40959 tests in 541 files (3 shards)
- harness c1 203/203
