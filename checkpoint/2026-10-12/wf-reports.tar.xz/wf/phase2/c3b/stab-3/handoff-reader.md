# Handoff from stabilisation fixer "reader", round 3

Writer's paths: `src/epinoic_logic/selfcert/**` and `tests/selfcert/**` only. Items below need another owner (or are notes for
the optimisation checks). Nothing here changes a receipt, finding or status on the current tree.

## 1. For the optimisation checks (code owner of packs / markdown / english parser; no bug)

`tests/branches/test_r5_quant_packs.py::test_bracket_heavy_answers_cross_the_english_branch_quickly[2000-unclosed-fragments]`
now measures 1.0-1.5 s against its 2 s bound (it measured 1.6-2.2 s in the stab-3 suite). The reader's share fell from about
0.93 s to about 0.5 s (two readings of the 32,027-character text: `packs._self_certification` with the supplied texts as known
sources, and `markdown._self_certification_not_label` via `request_parser.count_answer_words` on the quotation-masked text
"{xxx: 1, xxx: [ ..."; the two texts differ, so the reader's cache cannot serve the second). The rest of the crossing is outside
the reader: `english_specialist.parser.split_sentences` / `_iter_quotes` (about 0.6 s profiled), `markdown.own_form_flags` /
`parser_quotation_spans` (about 0.5 s profiled), `english_specialist.parser.is_meta_block` (about 0.55 s profiled). Measured
with cProfile on an idle machine (load average under 1), caches emptied. Suggested (optimisation phase only): one reading of the
same answer per delivery.

## 2. Callers in a marking task (reminder of stab-2 item 2, now also for ticks)

A tick that closes the WRITER's own claim of checking ("Model: I checked that ..., so ... ✔.") is now kept gated in a marking
context (`Context(marking=True)` / `context_for({"task_type": "marking_feedback"})`), as `tests/branches/test_c3_handoff_self_reports.py`
requires; ticks on the student's work stay free. Callers that read a marking task's lines must still pass the marking context.
