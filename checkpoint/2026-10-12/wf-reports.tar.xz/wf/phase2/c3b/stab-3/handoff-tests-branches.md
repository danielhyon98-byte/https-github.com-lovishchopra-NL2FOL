# Handoff from stabilisation fixer "tests-branches", round 3

Done in my paths: tests/branches/data/quant_general_reference.json items 383, 538, 550, 556 (0-based) re-referenced against the
tree as it stood during round 3 (earlier digest kept as `sha256_before_stab2`, `_note` extended); the c3b corpus assertion in
tests/branches/test_integration_gate3_quant.py rewritten exactly (383, 538, 550 now equal `sha256_before_c3b` again).

For the next triage only (no action unless it fails): the reader fixer of round 3 works in parallel on src/epinoic_logic/selfcert.
If its changes alter the CORE-SELF reading of any corpus text, test_general_reading_is_byte_identical_on_the_reference_corpus will
name it; `_digest_without_self_certification` must still reproduce `sha256_c3b_without_self_certification` (only CORE-SELF may
differ), and the re-reference then belongs to the tests-branches owner again.
