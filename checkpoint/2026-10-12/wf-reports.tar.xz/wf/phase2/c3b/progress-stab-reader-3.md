# stab-reader-3 progress
- started fresh (no earlier progress file). Reader group: 6 failures:
  K2 marking tick on writer's own check; T1 bracket-heavy 2000 fragments timing; T2 label-key run 32KiB; T3 mark codes ratio; H1 sources line trailing participle (combining letters); T4 note reader quotations timing
- NEXT: measure 8.1 mark-code stall (x = 5 (A1)... 20k) first
- 8.1 integration mark-label sweep passes alone now (40 passed 11 s). Snapshot tool: scratchpad/stabreader3/snap.py base.json (pre-change baseline), cmp.py
- DONE perf 1: read_text skips the text piece when it equals its one paragraph (outer blanks) ; perf 2: reader._tok_fields lru (Tok fields per spelling); perf 3: _merge compares words list. Snapshot diffs 0.
- NEXT: more perf (marks brackets, shortsent), then K2, H1, tests
- DONE perf 4: reader._inert prefilter in _clause_found_bounded token loop; perf 5: _finite fast reject (_FINITE_TAGS). Snapshot diffs 0. 32K: marks 1.02->0.45s, labelkeys 1.61->0.27, quotes 1.37->0.21; hub 2000-fragments readings 0.93->0.41 s
- NEXT: K2 (marking tick after writer's own check), H1 (Sources line trailing participle), then tests in tests/selfcert/test_reader_classes_r3.py
- DONE K2 code: reader._writer_check (info writer_check, marking only, sentences with a mark); own tick kept. NEXT: run K2 test, H1
- DONE H1 code: reader._apparatus_key/_trailing_status (Sources/References/Notes line closed by a status participle -> G6 label_after). NEXT: tests/selfcert run, H1 overseer test, new test file r3
- DONE tests/selfcert/test_reader_classes_r3.py (31 pass). NEXT: snapshot diff after K2/H1, group test files run
- DONE handoff stab-3/handoff-reader.md; group run g1: main 983 passed, overseer 363 passed. NEXT: StructuredOutput
