# progress fix-attack-2
- started; nothing done yet
- kit: scratchpad fa2/ (cases2.py POS/NEG from attack-2 list, probe2.py [cases2|cases], dbg.py, lexadd.py; selfcert.before = snapshot before this run)
- reader work in progress: lexicon additions + meaning.py polarity (without+gerund, couldn't be more, es concord in idioms, could be found), footnote superscript blanking (reader._blank_footnote_marks), es superlative -isimo (lexicon.tags). probe2 misses 82 -> 30; fa1 cases and dev unchanged (0 miss / 0 FP)
- 'misses' 83->0 (probe2), cases/dev clean; next: genuine corpus, then FPs
- 13:xx reader: misses 0/83 (cases2), FPs 10/56 left = word-count/length labels only (D7 pin; left_undone), fresh variants cases3 0/30 miss 0/20 FP; fa1 cases + dev clean; genuine 3 (baseline)
- NEXT: reader regression tests (tests/selfcert/test_attack_round2.py), then paths (outcome _self_report_claim fail-open, payload_spots claim_text, label_on_content stall), then branches (cache keys, LB address example, LB stalls, English B routing, Spanish capitalised numbers), correct-work (binary 8+2+1=11, 'So the correct answer is x = 4' meta)
