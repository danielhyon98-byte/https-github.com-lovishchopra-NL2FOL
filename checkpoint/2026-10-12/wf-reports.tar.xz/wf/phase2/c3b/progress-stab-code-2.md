# progress stab-code-2
Started. 8 failures in group code (failures.json). Nothing edited yet.
- Economics 'x = 4 ✓' real cause: receipt DOES carry CORE-SELF-001 (label on content keeps role, design 3.13), but FID-005 (error) excludes the answer.
- DONE (untested): fidelity.py FID-005/009 read in selfcert_context_for(journaled request) (sp-t16 fix) + rule label-on-content exempts a label/mark on content the receipt names (CORE-SELF-001/INT-HANDOFF-006); checks/selfcert.flags_self_certification(sentence, ctx=None); api adapters exports label_on_content; compat REQUIRED_API updated (is_self_report, label_on_content; is_self_certification removed); PUBLIC_API.md regenerated
- VERIFIED: Economics x=4 tick + sp-t16 + layout/API tests pass (72 passed)
- ph-t16 tick test: NOT packs; reader frees tick in marking ctx (ph-t16 is marking_feedback) -> handoff to reader (TODO write)
- DONE packs._self_certification: one decision per distinct piece (word counts 18.7s -> pass). test_d9d10_linear bounded: 46 passed
- NEXT: quotation_in_scope thin call; ph-p8b Physics parser role; overseer knowledge README input budget
- DONE quotation_in_scope: reader gates the words AND reader classes anchor (anchor_idioms / C:anchor / anaphoric place after prep). remedy2_round2 + remedy2_self_reports all pass
- NEXT: ph-p8b Physics parser role 'With x = 2.0 cm = 2.0 × 10⁻² m:'; overseer knowledge README input budget; handoff (ph-t16 tick in marking ctx -> reader)
- DONE generic_parser.stem_colon_label: not a label when a relation relates two written values (_relates_two_values); non_material test 632 passed
- NEXT: run tests/stem/test_c3b_stem_roles.py + tests/adapters stem; overseer knowledge README input budget; handoff
- DONE pack 2.2 README input budget figures (+194 chars, sentence for 2.2), manifest refreshed (export.refresh_source), digest 7a7cdbb3.. -> ef3bed4f..; pins updated in pack.py, overseer_port.py, docs/PROTOTYPE.md; kit MANIFEST regenerated (only overseer_port line)
- TODO handoff: test_subproject_layout.py line 64 pin 2.2 -> ef3bed4f (tests owner); ph-t16 tick in marking ctx (reader)
- DONE handoff-code.md written (K1 test pin 2.2 digest, K2 reader tick marking ctx, K3 note, K4 STEM role note); docs adapters/README + OVERSEER_DESIGN FID-005 updated
- RUNNING validation: overseer group files (bg), tests/stem roles + tests/adapters (bg). Then: tests/branches/test_c3_handoff_self_reports.py, test_d9d10_linear.py, test_c2_hold_remedy2_round2.py
