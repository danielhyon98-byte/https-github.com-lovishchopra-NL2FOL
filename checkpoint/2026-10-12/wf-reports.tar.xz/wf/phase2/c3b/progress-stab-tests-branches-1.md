# progress stab tests-branches round 1
- [done] c3_handoff: controls -> is_self_certification/claims_a_check False; hostile sweep -> is_self_certification on same inputs (97 pass)
- [done] c3_texts: C3_STRICTER_SPANISH (Todo está bien / ¡Todo correcto! / Todo está correcto) into C3_SELF_REPORTS; C3_UNREAD_SCRIPT (Greek)
- [done] c3_clearance: Greek -> refusal as unread script (+ new every-branch CORE-SELF-002 test); 'Todo está bien.' -> _HUB_SAMPLE;
  _PIECE_MAX -> 4000; markup -> selfcert.reading_form; caches -> empty_caches + evict; trailing label + joined word run -> public API
- [done] c2_hold_remedy2_round3: 'The treaty was signed in 1919. OK.' -> True
- [done] d9d10_recorded: sp-t15 ACCEPTED_WITH_FINDINGS + SELF_NAMED g11.1 only (fails on reader FP g7.2 -> handoff)
- [done] handoff written
- [done] final validation: 37 of 40 listed rows pass; 3 fail on reader defects (handoff 1-3); 94 unlisted hostile shapes pass. Task complete.
