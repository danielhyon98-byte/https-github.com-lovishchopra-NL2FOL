# progress fix-attack-5
Kit: scratchpad fa5/ (cases5.py all reader inputs, probe.py, dbg.py tokens+hits, dbg2.py gate trace, d.sh, lexadd.py lexicon editor;
lexicon.before.json = baseline copy). Baseline probe: MISS 62/66, FP 47/47.
## Done (reader)
- reader _gate pronoun antecedent: -ly adverb is no subject noun (progressive passive regression)
- meaning _answer_subject: family verb idioms count as verb (ties back)
- reader _comma_split: leading verbless time phrase (Before posting,) split
- meaning _content_at: agent_quant + reader/look/eyes not content
- lexicon: assessor_extra pair of eyes; OUTCOME money in the bank, nail on the head, nailed it, dio en el clavo; AGREE unanimous, ties back/out;
  DEFECT mismatch, red mark, objeciones; APPROVE aceptar, vo bo, por bueno(s); CONFIDENCE sin lugar a dudas; part subtotal; COMPLY hits every;
  meta posting/handed/returned...
## Next: remaining misses (stake frame, number-word score, lose a mark, alive, reduced relative, sign-off obtained, ...), then FPs, then paths, branches
- DONE (run 1, ~step 2): all 66 reader MISS cases pass (probe): stake frame (_stake_frames), number-word scores (_number_value), hypothetical
  verdict (_hypothetical_assessment G8), rhetorical/neg-comparative/hedge-cancel (meaning._rhetorical_verdict), Spanish pass frame
  (_pass_frames), tag-run/comment word joins (normalise), turned letters (_turned_words), bare radical tick, INVERSE CHECK MARK (fold
  table rebuilt via scripts/selfcert/build_fold_table.py, range to 1FC00), short unread lines (_net_found short_line), nets sv/da/id,
  pipeline lines (defect_key diagnosis/reasons, assess_key release/decision, value permitted/deliver, key before bracket, zero-counted
  nonsuccess), modelo genre, error nouns fault/flaw, podria in finding.
- NEXT: marking-context credits (4), then FPs (46), then hub segmentation of inline fragment, paths (lift/_self_reporting_claim,
  named.model_text summary), branches, then tests file tests/selfcert/test_attack_round5.py
- DONE: marking internal credits (_credits_internal -> strict ctx per sentence); FPs fixed: deny_matrix wrong-to-claim, reference attributive
  participle, initial attributive participle (meaning), adverb in aux chain (_verb_group), leading participle clause (meaning), non-restrictive
  relative subject (_subject_for + _sentence_found rel_prev), CS each-correct-answer + prints 'Correct!', base=part imperative (_mood),
  check headings over working (_check_headings), pronoun reporter (_pronoun_reporter/_source_before), common-noun reporter, ES report
  verbs, quoted label must be label. Probe: MISS 0/66, FP 11/47 left (participant quotes, fact-check quotes, passive mentions, LB word count).
- DONE: quotes (participant own answers, analysed-text 'reads' quotes, quote spans with !, single quotes opening with a mark), grammar
  noun mentions, according-to/segun outside source. tests/selfcert all pass (after these). FP left: LB word count (2) -> conflicts D7 pin.
- NEXT: claim segmentation of inline '✅✅ all steps' fragment; paths (lift, model_text summary); branches; tests file
- DONE: sentence-start lookahead incl marks/# (stem/layout SENT_RE, generic_parser _SENT_RE, english _BOUNDARY_RE, history _STARTS_SENTENCE_RE);
  english meta paragraph only when every sentence meta (self-report beside content stays its own piece). Repro fa5/paths/seg.py.
- NEXT: _self_reporting_claim (lift), named.model_text summary, run tests adapters/english + branches, then branch items
- DONE: model_text masks reader-refused text ("[model text withheld]"); geography: _DERIVED_BEFORE_RE, share-of-maximum after, _AT_ROW_RE
  (unit between figure and row), single-row path exclusions; _OWN_EVENT_RE clause anchor (aftershock); grounded_figures _group_figure +
  _clauses ignore commas in brackets. Kit: fa5/one.py <rec> "appended" | "rep:old|||new". Background test logs fa5/runs/*.log
- NEXT: LB derived figure FPs (sp-t14), then branch misses as time permits; then tests file + run tests
