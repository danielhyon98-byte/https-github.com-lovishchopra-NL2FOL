# progress stab-code-1
- started; failures: code group 20 items (compat REQUIRED_API; CORE-SELF-002 code rows; parser roles for label-on-content)
- DONE compat REQUIRED_API adapters = imported names (test_subproject_layout green)
- DONE emitted.py CORE-SELF-002 row; NOW pack completeness needs pack 2.2 (2.1 pinned+published) -> TODO
- DONE self_report.label_on_content/self_report_note; History is_note_sentence/classify, English is_meta_sentence/is_meta_block + add() advisory,
  markdown._note_clause, generic reports, packs CORE-SELF-001 message from as-written reading. test_verification_labels: 34/35 (Math as-formally: reader, handoff C1)
- handoff-code.md written (C1-C3)
- DONE STEM _self_report_notes lists only role other; harness r1-adv copy now 150/151 (was 148/151; 1 genuine pre-existing)
- IN PROGRESS: pack 2.2 (copy 2.1 dir -> 2.2, add CORE-SELF-002 row §8, footers/examples version, refresh manifest, pin digest, PACK_VERSION, overseer_port PINNED_PACK_DIGESTS, tests pinning installed 2.1 -> 2.2 keeping 2.1 pinned)
- pack 2.2 created, pinned 85ced646..., PACK_VERSION 2.2, overseer_port PINNED updated; next: run knowledge tests, rewrite 2.1-installed pins
- DONE parsers read in task_context (marking from channel task) via self_report.task_context; markdown.is_self_certification -> is_self_report. pack tests rewritten 2.1->2.2 (drift/examples/layout/runner/pack/integration_codes)
- DONE tamper.py T8 -> OVS-FID-005 (H13 of tests-other handoff); running tamper/scoring tests
- DONE English parser answered self-question (H6): self_report.answered_self_question, both sentences role other
- pack 2.2 needs flash-router cost data release (sizes changed); working on flash-router 0.5.0 cost-data-5
- flash-router 0.5.0: cost-data-5 (54a4d682), rules-5 (0afaa2be) = rules-4 renamed; MANIFEST current; version bumps; test_data rewritten (0.4.0 kept on its files)
- docs: overseer README, PROTOTYPE, flash-router README/DESIGN, rules.py docstring, integration/README; kit MANIFEST regenerated (README + overseer_port only)
- tests/README flash router 0.5.0 line; waiting adapters/channel runs; tamper/scoring 135 passed
- adapters run: 13 failed (12 not in triage list) - investigating
- DONE: classified new adapters failures as reader (handoff C6). Ready to report.
