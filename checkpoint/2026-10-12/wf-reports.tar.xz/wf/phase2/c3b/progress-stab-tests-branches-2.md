# progress stab tests-branches round 2
- DONE: re-pinned SELF_CERTS row in tests/branches/test_c1_clearance_parsers.py to "Todas las cifras de esta respuesta han sido comprobadas por el Instituto Regional de Estadística." (gated, G1); original sentence added to free controls. Validated: 140 passed.
- Remaining failure in that file (test_the_re_referenced_corpus_text_differs_by_the_fell_x_per_cent_rule_alone) belongs to the reader group (corpus re-reference after the reader settles items 550/556); not touched.
- Task complete; no handoff needed.
