# progress stab tests-other round 2
- started; 24 failures in 4 groups: (A) round5/region/physics-text consolidation exclusion (22), (B) round6 open_en (1), (C) sp-t15 word count (1)
- done: none yet
- done: (C) sp-t15 re-pinned 534 in tests/channel/test_c2b_handoff_channel.py (passes)
- done: (B) round6 open_en re-pinned stricter (== [], len(hidden)==14); stays red on 1 reader miss -> handoff H1 written in stab-2/handoff-tests-other.md
- next: (A) 22 consolidation-exclusion tests in test_c1_push_check_round5.py and delivery_support.py (line 335)
- in progress: (A) round5 edits written (helpers + 4 tests); validating
- done: (A) round5 rewrites; 247 targeted pass. next: full round5+round6 file validation
- done: validation round5+round6: 1248 passed, 1 failed (round6 moot test, intentional stricter pin awaiting reader fix H1). channel file 61 passed. TASK COMPLETE
