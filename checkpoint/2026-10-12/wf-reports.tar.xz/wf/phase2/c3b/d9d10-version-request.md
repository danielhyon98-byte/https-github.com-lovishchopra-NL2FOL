# Version request from the D9/D10 designer (Geography and Language B branches)

To the owner of `src/epinoic_logic/version.py`, the self-certification implementer. Read with `d9d10-design.md` (section 13).

## Request: no version change for D9/D10

| Constant | Current | D9/D10 needs | Reason under the rules in `version.py` |
| --- | --- | --- | --- |
| `IR_VERSION` | 1.0 | no change | No schema change. The new checks are ordinary IR 1.0 problems built from existing ops (`eq`, `le`, `ge`, `and`, `or`, `mul`, `div`, `add`, `sub`, `neg`, whole powers up to 12). |
| `ENGINE_VERSION` | 0.4.0 | no change | No change to compilation or procedures. Every new check runs under the existing named policy `linear`. |
| `POLICY_VERSION` | 2026.10-v4 (your bump for eligibility rule 0 stands) | nothing added | D9/D10 changes no limit, no allowlist entry and no eligibility rule. The `geography` and `language_b` profiles keep their eligible classes, numeric sorts, aliases, `can_check` and `cannot_check`. `MAX_FORMAL_CHECKS` and the pack policies are unchanged. Which branch runs which deterministic integrity checks is not an eligibility rule. |
| `TRANSLATOR_VERSION` | 0.4.0 | no change | No change to the translation pipeline or prompts. The model sees what it sees today: `prompt_profile_text` is unchanged because the profiles are unchanged, the prompts `translate_v2`/`review_v2` are unchanged, and claims come from the same `GenericTextParser`, so claim text, roles and materiality are identical. The branch packs are deterministic receipt checks. Precedent: every parser and pack change of rounds 8 to 10 shipped under 0.4.0, and the build identity (`engine.identity`) distinguishes builds. |
| `ARG_RULES_VERSION` | argdiag-2 | no change | `named.py`, `lexis.py` and the claim and report rule modules are untouched. Defect labels travel on `FormalCheck.defect`. |

## Optional history note for `version.py`

If you want the decision on record in the module docstring, add one line under your own history entry, in this sense:

> D9/D10 (decision D35): the Geography and Language B branches ship under the same component versions. They add
> deterministic packs only. Profiles, aliases, eligibility, prompts and the parser are unchanged.

## When a bump would become due

If the implementation deviates from the design, these become due:

- **`POLICY_VERSION`**, if any of these is added: a subject alias ("Spanish", "Español", "Spanish ab initio SL"), a change to the
  `geography` or `language_b` profile's `eligible_classes` or `numeric_sorts`, a new named engine policy, or a change to
  `MAX_FORMAL_CHECKS`. A second bump in the same run is not needed if it lands before your bump is committed: name both reasons
  in the one history entry.
- **`TRANSLATOR_VERSION`**, if the `can_check`/`cannot_check` text of either profile changes (it reaches the model through
  `prompt_profile_text`), if a profile key joins `STEM_PROFILE_KEYS`, or if the branches stop using `GenericTextParser`, so that
  claim text, roles or materiality differ from today.
- **`ARG_RULES_VERSION`**, if `named.py` gains rows for new pack codes (the GE-/LB- code families are a follow-up, not this
  run).

## Coupling you already own

`integration/COMPATIBILITY.json` `components.policy` must list the `POLICY_VERSION` you set, or the preflight raises
`KIT-HS-002`. Changing `COMPATIBILITY.json` means regenerating the kit copies (`python integration/tools/generate.py`), the
handshake vectors and `integration/MANIFEST.sha256`.

D9/D10 needs the same regeneration for the subject map's `branch` column (design section 1, option A: map version
`2026-11-16.1`). Please run it once, after both changes are in. That keeps `compat.py`, `compat.js`, `subject-map.js`, the
vectors and the manifest consistent in one step. The website patch set M's `RESULT.sha256` lines for `src/verify/compat.js` and
`src/verify/subject-map.js` then need a re-run on a disposable export, or a record that it was not re-run.
