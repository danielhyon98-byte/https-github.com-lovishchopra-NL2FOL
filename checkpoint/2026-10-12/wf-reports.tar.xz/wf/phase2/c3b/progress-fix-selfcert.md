# Progress of fix:selfcert (written by the orchestrator after the interruption)

An earlier run of this same task was stopped by a CONTAINER RESTART at 22:38 UTC on 16 Nov, after about 80 minutes.
Its work is in the working tree; continue from it (git status, git diff); never start over and never revert it.

What its own task list and last messages show:
- DONE: the selfcert package src/epinoic_logic/selfcert/ (fold table, lexicon, reader) at 100% on the development sets;
  the new tests/selfcert/ package (development sets as regression data, rule pairs, lexicon shape, fold-table check,
  linearity test); scripts/selfcert/.
- IN PROGRESS: switching the call sites to thin calls and deleting the duplicate readers (overseer meta_notes,
  delivery_policy, consolidate, port, checks/selfcert; adapters self_report, markdown, the English and History parsers;
  channel feedback; integrity ledger's check-claim reader). Its last steps: an adapters run showed 112 failures that it
  was categorising and fixing (French clause after a comma, "accepted a diktat", "promised", "stands out as an
  exception": neutral idiom class idiom_x20), the gate2/gate3 parsers tests, the ledger thinning, an allowlist with
  reasons, and a registry invariant in src/epinoic_logic/branches/base.py.
- Files already touched include version.py, engine/identity.py, integration/COMPATIBILITY.json, integration/tools/vectors.py,
  docs/integration-contract.md, integration/PROTOCOL.md, integration/readiness/check.py, the overseer's compat.py and the
  expectation table: check how far the POLICY_VERSION and contract bump got before you continue it.
- NOT YET DONE (from its plan): CORE-SELF-002 (unread text), the rest of the section 6 test rewrites, new tests, the
  rest of the POLICY_VERSION bump and docs, validation of the targeted test directories and the dev metrics report.

The Geography and Language B implementer has FINISHED (src/epinoic_logic/branches/geography.py, language_b.py,
spanish_lexicon.py, registry.py, packs.py edits, integration/subject-map.json, D35, tests/branches/test_d9d10_*): its
changes are in the tree too; never revert them.

Keep this file current (append what you finish and what is next) after each step: the container can restart again.

## Run 2 (started after the restart)
- Checked: tests/selfcert 447 passed. Adapters run started; fixing remaining adapters failures first.
- Run 2: reader: combinator status key class (lexicon combinator_status_key, "Fact: ...") and SRCEVAL on an own pronoun in the
  synthesis (G3); test_integration_gate2_parsers.py verdict/clean forms rewritten stricter (NAMED_ON_EVERY_BRANCH +3,
  STRICTER_SYNTHESIS_FORMS, agent approval of a synthesized claim named). Full adapters runs logged under scratchpad wf/phase2/c3b/run2/.
- Run 2 reader fixes (all general rules, no sentence lists): combinator synthesis scope (restrictor/subject modifier => subject's
  synthesis), noun before aux not finite ("synthesized claims are"), AGREE over CHECK for an answer subject ("matches"), manner
  adverb ("accurately reflects"), net label of 1-2 words ("(geprüft)"), bearer verbs list (carry/bear/earn...), pipeline-modified
  check nouns stay P, ambiguous pipeline names (overseer/hub/...) over subject nouns/relative objects/"it" (overseer only) => O,
  mention frame ("the word X means"). markdown.self_cert_vocabulary reads status hits (STATUS/APPROVE/MARK or G2/G4-G6).
- Tests rewritten stricter: gate3 (bare verdict fragment, STRICTER_ON_A_SYNTHESIS, hub names agent check), synthesis test
  (STRICTER_IN_A_SYNTHESIS), gate2 (above).
- Run 2 (23:08): test_verification_labels.py green (labels on content are self-certs, stricter; STRICTER_LABELS; long-run test on thin
  names); markdown: label position words, whole label for all-assessment sentence, _self_certification_not_label in split_note_clauses;
  reader: as-phrase (later/idiom/named outside), bracket after content cites outside party, outside evaluator in fragment frees,
  dangling aux, X3 "at", imperative in bracket, raising copulas, specialists' reports internal; selfcert.read one-entry long cache.
- Run 2 (23:20): gate2/gate3/synthesis/round2/labels adapters tests near green. More reader rules: idiom_x20 lost bare
  "self-certified"; X6 not for the pipeline engine over the answer's claims; P theme + prefixed check; late protasis (if/when after
  main verb); inverted counterfactual; permission "may rely on" is ASSURE; markdown.self_cert_vocabulary = first hit of any family.
  NEXT: adapters round1/5/6, structural; then branches, channel, integrity, overseer, integration, service, combinator, flash-router.
- Run 2 (23:40): NEW overseer/tests/overseer_tests/test_c3b_selfcert_paths.py (155 pass; run overseer tests from repo root WITH
  -c pyproject.toml --rootdir=. or overseer/pyproject.toml is picked and epinoic_overseer is not importable); every-branch test gained
  dev-sample positives/negatives (255 pass). More reader rules: need-object, negated need, X16 CHECK/colon, X18 precision+source,
  A-only exact, COMPLY composition (classes comply_verb/request_noun). NEXT: section 6.2-6.5 rewrites, docs, background dir runs.
- Run 2 (00:05): 6.2.1 done (literal NAMED_ON_THE_RECORDED_TEXTS in test_c2_hold_self_certification_gate). Reader: evaluator
  coordination, pipeline-role agents INT, X15 for non-writer INT, pass of an internal evaluator, internal agent over part nouns, A-only
  general, X3 dated O/M, proper-name triggers, clarity "clear", short status values, purpose key, lesser comparative. c3 clearance list
  still has ~20 misses (overseer/agent forms, Spanish label, Greek, etc.). NEXT: 6.2.2, 6.3, 6.4, 6.5, docs, logs.
- Run 2 (00:20): 6.2.2 literal C3_WHOLLY (12 red pins = reader misses), 6.3 Spanish stricter, 6.4 SELF_MEASURES, 6.5 contract tests
  (policy identity binds rules_digest; old policy version stale) DONE. Docs: overseer/docs/DELIVERY.md gate paragraph, DECISIONS.md
  D34 "Changed since (c3b)", OVERSEER_DESIGN Decision 176 DONE. Dev metrics: 207/207 positives, 0/213 FP. Background runs: branches,
  chan_integ, overseer logs in run2/. NEXT: collect logs, final report.
- Run 2 (00:45): eligibility/outcome call selfcert directly; word-count COMPLY not wholly (stays eligible); X1 neutral outcome after a
  computation; fraction tokens count as operations. Background runs (mid-session code) show many remaining failures in tests/branches
  (c2-hold/c3 phrase lists x every branch), tests/channel (labels at delivery, branch_check_mapping), tests/integrity, overseer.
  Report written (StructuredOutput). NEXT for a later run: work through run2/*.log failure lists; bus.py check_result_statement thin.
