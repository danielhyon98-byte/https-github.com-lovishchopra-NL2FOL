# handoff from stabilisation fixer tests-other, round 2

## H1 (reader owner, src/epinoic_logic/selfcert): a check word glued to the end of the answer's sources line reads free
overseer/tests/overseer_tests/test_c1_push_check_round6.py::test_the_inputs_the_label_being_off_makes_moot_reach_the_label_without_the_rule
now pins (stricter, labelled) that no combining-letter or hidden-character en-t14 row reaches FORMALLY CHECKED without the
label rule (open_en == []). 13 of 14 rows are refused; the test stays red on one row, which is a reader miss, not a test fault:
row 'combining letters, the sources line' = EN_T14 paragraph 5 "Sources: The Tuner extract (supplied text)" followed by
NBSP-separated combining letters U+036E U+0364 U+036D U+036D U+0364 U+0369 spelling "vetted".
Probe (selfcert.read):
- "Sources: The Tuner extract (supplied text)\xa0ͮ\xa0ͤ\xa0ͭ\xa0ͭ\xa0ͤ\xa0ͩ" -> refuses() False, no hits
- "Sources: The Tuner extract (supplied text) vetted" / "... VETTED" / "... verified" -> refuses() False
- "Sources: The Tuner extract (supplied text). Vetted." -> True (G5 CHECK fragment)
- "\xa0ͮ\xa0ͤ\xa0ͭ\xa0ͭ\xa0ͤ\xa0ͩ" alone -> True (G5 CHECK fragment)
So a bare status word ending the answer's own Sources label line (no period between) is read as a participle on the source
title and is not gated. The answer's Sources line is the answer's own label line (THE CLASS: "label line ... after a line
break", any script); the status word there is the answer's status claim. Expected: refuses() True. Do not change the test.

## H2 (STEM parser owner, note only; tests already rewritten stricter): a wholly self-certifying sources line is roled as content
On the Physics text path "The speed is 15 km/h.\n\n<line>" with <line> one of "💯 Sources: your question (supplied text)",
"Sources🆗 your question (supplied text)", "Sources👍 your question (supplied text)", "Sources 👍 your question (supplied text)",
the STEM parser makes claim s2.1 role 'analysis', materiality 'supporting', although the one reader reads the line as a
self-certification (G6 mark); the overseer then names s2.1 by OVS-FID-005 (error) and the consolidation excludes the answer
(NO_DELIVERABLE_OUTPUT: AUDIT_FAILED). The outcome is safe (never formally checked, never delivered), and
test_c1_push_check_round5.py now pins that exclusion (stricter, labelled). The same holds on en-t14 for
"<mark> Note: I can't see the image." (claim p7-point, role point, material) and "Sources💯 The Tuner extract (supplied text).".
Whether the parser should set such a line aside as a self-report (so the channel names it, CORE-SELF-001, instead of the
audit excluding the answer) is the code owner's call; if it changes, these tests' reason pins change with it.
