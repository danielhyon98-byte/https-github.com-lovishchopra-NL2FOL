# Handoff from stabilisation fixer "code", round 2

Owner of this run: every source file outside `src/epinoic_logic/selfcert/` and the documentation. Items below need another owner.

## K1 (tests owner, test_subproject_layout.py): the pinned digest of pack 2.2 follows the pack (re-pin)

`overseer/tests/overseer_tests/test_subproject_layout.py` line 64 pins pack 2.2 at
`7a7cdbb3946625609a9e023fb5e14ebb47211508ce85803239f730ae86e3187b`. Pack 2.2's README (audience deployer, digested in the
manifest) stated the 2.1 composition sizes in its "Input budget" (`test_stem_repair11.py::test_the_readme_s_input_budget_is_the_
compositions_measured` failed: core 249,248 characters measured, 249,054 stated). This run corrected the README's figures (all four
compositions, +194 characters each: the CORE-SELF-002 row), added the 2.2 sentence, and refreshed the manifest with
`epinoic_overseer.export.refresh_source(version="2.2")` (only manifest.json changed besides the README). New pack digest:
`ef3bed4fca02551f01dea7b1085829d5c6a723fed7222920761c819470771a28`, pinned in `overseer/src/epinoic_overseer/pack.py`
(PACK_DIGESTS), `src/epinoic_logic/integration/overseer_port.py` (PINNED_PACK_DIGESTS) and `docs/PROTOTYPE.md`; the kit
manifest `integration/MANIFEST.sha256` regenerated (only the overseer_port.py line changed). Pack 2.2 is unreleased (2.1 stays
pinned and published). Action: replace the 2.2 value on line 64 with the new digest (a pinned value that tracks the pack as built,
not a loosening; 2.1's pin is unchanged).

## K2 (reader owner, src/epinoic_logic/selfcert): a tick after the writer's claim of checking is freed in a marking task

`tests/branches/test_c3_handoff_self_reports.py::test_control_a_tick_on_a_claim_about_checking_in_a_model_line_is_still_named`
is NOT the packs.py `continue` the triage named (probed on the hub path): ph-t16 is a `marking_feedback` task, so the core pack
reads in `Context(marking=True)`, and there the one reader reads nothing on
"Model: I checked that a higher temperature means faster molecules, so their mean kinetic energy rises ✔." (the SI view's
sentence and the statement as written both give `()`; in the default context both give the G6 MARK symbol hit). The model-marks
rule (`self_report.model_mark_ranges`) already keeps the tick (it follows a point about checking), so the response the pack reads
holds it. Expected (the test, design rule model-marks): a tick after a point about checking stays a label in a marking task too
(the marking context frees the marks of the STUDENT's work, not the writer's own tick on its own claim of checking). Probe:
`selfcert.read(<that sentence>, selfcert.Context(marking=True)).hits` -> () ; expected a hit. Do not change the test.

## K3 (note for the triage): the Economics "x = 4 ✓" row was not packs.py either

`test_c2_hold_remedy2_round3_gate.py::test_the_routers_decision_never_allows_a_round3_self_report[Economics-x = 4 ✓]`: the
Economics receipt DOES carry CORE-SELF-001 (the generic parser keeps "x = 4 ✓" as content with its label, design 3.13), and the
auditor's FID-005 (error) excluded the answer (AUDIT_FAILED), so the router said NO_DELIVERABLE_OUTPUT. Fixed in
`overseer/src/epinoic_overseer/checks/fidelity.py` (rule label-on-content: a label or mark on content that the receipt names is
no FID-005/FID-009; the gate refuses by the receipt's code), with FID-005/FID-009 now read in the journaled request's context
(`selfcert_context_for`), which also fixed sp-t16's audit. The secondary reader item of the sp-t16 row (g1.24 "(a choice, not an
error)" gated in the DEFAULT context, a negated assessment of the student's writing, boundary (b)) is still the reader owner's.

## K4 (STEM role change, for pins that read it)

`generic_parser.stem_colon_label` no longer reads a colon-closing STEM line as a label when one of its relations holds a written
value on both sides ("With x = 2.0 cm = 2.0 × 10⁻² m:", a conversion the engine checks; `_relates_two_values`): such a line is
now a claim (ph-p8b s7.2 role quantitative, was other). "For the current cans, r = 3.2 cm:" and "Sign of f′(x) = 3(x − 3)(x + 1):"
stay labels. Any pin of a role/claim list of a STEM answer with such a line may move; the round-8 non-material pin is green again.
