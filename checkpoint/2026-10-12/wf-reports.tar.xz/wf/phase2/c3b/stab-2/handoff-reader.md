# Handoff from stabilisation fixer "reader", round 2

Owner of this file's writer: `src/epinoic_logic/selfcert/**` and `tests/selfcert/**` only. Items below need another owner.

## 1. Re-reference four digests of `tests/branches/data/quant_general_reference.json` (owner of tests/branches data)

Fails: `tests/branches/test_quant_si_reading.py::test_general_reading_is_byte_identical_on_the_reference_corpus`,
`tests/branches/test_integration_gate3_quant.py::test_the_re_referenced_corpus_texts_differ_by_the_self_certification_rule_alone`,
`tests/branches/test_c1_clearance_parsers.py::test_the_re_referenced_corpus_text_differs_by_the_fell_x_per_cent_rule_alone`
(one data file). Only items 383, 538, 550 and 556 (0-based index in `items`) mismatch; `_digest_without_self_certification`
still reproduces `sha256_c3b_without_self_certification` for all of them, so only the CORE-SELF findings differ. The reader's
reading is now settled (round 2):

- 383 ("Channel behaviour found wanting ... a faithful synthesis ...") and 538 ("... a correct quotation written with an academic
  elision mark ..."): no hit. Both are descriptions of channel behaviour, not self-certifications (the finding's own verdict:
  the freeing is correct).
- 550 (fixture docstring): a status word inside an identifier is read with the identifier's words as a phrase (rule: an
  underscore between two letter runs is a word joint), so ``FAITHFUL_CHAIN`` is an attributive word before its head noun and
  draws no hit. Remaining: G5 STATUS on each of the three bare "ENTAILED" engine statuses (sentence, sentence, fragment).
- 556 ("... Expected: INCONSISTENT_PREMISES with core S1, S2."): G6 STATUS label_after on "Expected: INCONSISTENT", the same
  form as "Expected: ENTAILED" (a pipeline status value in capitals under any key; a status word in an identifier keeps its
  reading, so "Status: ALL_CHECKS_PASSED" stays gated).

Action: recompute `sha256` of these four items with the current tree (keep the earlier value in a `sha256_before_stab2` field,
as the earlier re-references did) and extend the `_note`. Do not touch the other items.

## 2. Callers in a marking task must pass the marking context (code owner: overseer fidelity / any FID-005 caller)

`selfcert.read(line, context_for(task))` now leaves a criterion and its mark band free in a marking task ("D 3: generally
clear and accurate", "A 3: the thesis is clear.", "Criterion B: 4/6, clear and accurate."), and "clear" of a text is read
as clarity (a quality), not a clearance, unless it is "clear to/for/of" something or a status in capitals. With the DEFAULT
context (`Context()`, not a marking task) the reader still gates "D 3: generally clear and accurate" as a status label
(pinned in `tests/selfcert/test_reader_classes_r2.py`). The r7 overseer tests pass on the current tree; any caller that reads
a marking task's lines must pass `context_for({"task_type": ...})`, never the default context (the code item for
`test_the_spanish_and_ll_answers_pass_their_audits_with_no_quotation_charge` in the triage).

## 3. For the optimisation checks (no bug: changes no receipt, finding or status)

Measured on the current tree (one process, caches emptied): a text of many very short sentences ("a. a. a. ...", "a\n\na\n\n...",
"a\na\n...") reads in about 0.6-0.7 s at 8 KiB and 2.6-3.0 s at 32 KiB, linear (ratio about 4.3 for 4x the input) but about
0.09 ms per character, above the 1.5 s bound `tests/selfcert/test_linear.py` uses for its hostile families. Most of the time is
the per-sentence tokenising and the clause reading (`reader._clause_found_bounded`, `Tok.has`). Not added as a linear family
(it would fail the 1.5 s bound, not the linearity). The mark-code family at 32 KiB measured 1.16 to 1.50 s under parallel load
before round 2's net-set caching (`reader._net_sets`, the per-language net word sets were rebuilt for every sentence).
