# Handoff from the D9/D10 implementer (Geography and Language B branches, decision D35)

Every item below is outside the files this implementer owns. Nothing here was done by the D9/D10 build.

## 1. Kit regeneration (the cross-owner fixer, once, together with the POLICY_VERSION bump)

`integration/subject-map.json` changed under option A (approved): the `branch` of the rows `geography`, `spanish-b` and
`language-b-spanish` is now `geography`, `language_b`, `language_b`, and the map version is `2026-11-16.1`. Nothing else in the
file changed (routes null, environments `["service"]`, provisional true, note and slugs as before).

Regenerate with the kit's own tooling, once, after the self-certification implementer's `COMPATIBILITY.json` change:

- `python integration/tools/generate.py` (`src/epinoic_logic/integration/compat.py`, `integration/website/src/verify/compat.js`,
  `integration/website/src/verify/subject-map.js`, the `subject_map` pin in `integration/COMPATIBILITY.json`, `schemas/`);
- the handshake vectors (`integration/tools/vectors.py`; the files under `integration/vectors/handshake/` embed the map digest);
- `integration/MANIFEST.sha256` (also covers the edited `integration/DECISIONS.md`).

Until then the integration tests that compare generated copies, the map digest pin and the manifest fail (expected; listed in the
D9/D10 report). `preflight.subject_map()` (KIT-HS-010) passes only when the map's branch column and the hub's routing agree, which
they now do in the source map.

## 2. Website patch set M

`integration/website/patches/M/RESULT.sha256` records `src/verify/compat.js` and `src/verify/subject-map.js`; both data copies change
with the regeneration. Re-run the patch set's record on a disposable export, or record it as not re-run (precedent in
`integration/website/patches/M/TESTED.json`).

## 3. docs/handoff (round 10 finding #18)

Round 10's finding #18 ("Geography and Language B route to the generic branch") is resolved by D35 on this tree. The run's handoff
notes should name it resolved, with the follow-ups below.

## 4. Follow-ups recorded, not done (design section 15)

- Own code families (GE-, LB-) for deterministic subject findings that are not engine checks: rows in
  `overseer/src/epinoic_overseer/emitted.py`, the families tuples of `overseer/tests/overseer_tests/test_integration_codes.py`,
  the overseer knowledge pack (completeness test), `PINNED_PACK_DIGESTS` and the preflight's KIT-HS-007 pin.
- Re-roling a model text's sentences as a performance (non-assertive), with its fixture and harness impact measured first.
- Promoting the Spanish number-word reader from `integrity/ledger.py` (`_spanish_word_figures`, re-exported today as
  `branches.spanish_lexicon.spanish_number_figures`) into the lexicon module (core owner).
- A `word_count_view` hub hook for Language B, if the channel's measure ever needs to read only the Spanish production.
- Subject aliases ("Spanish", "Español", "Spanish ab initio SL") under the next POLICY_VERSION.
- The c3 `ge-p10c` peer exchange with Chemistry (planned, never answered): run it in the next round.

## 5. Notes for the self-certification implementer

- Both new branches carry `CorePack()` first; the shared gate reaches them unchanged. Neither new pack defines a self-report
  reader (asserted in `tests/branches/test_d9d10_routing.py::test_every_branch_runs_the_shared_core_pack_first`).
- `tests/branches/c2_hold_texts.py` `BRANCH_OF` now maps Geography to `geography` and Spanish B to `language_b` (stricter: the set
  of branches it covers is checked against the registry's 11 keys). The self-report suites parametrized over `SUBJECTS` now run
  through the new branches; `tests/branches/test_d9d10_parity.py` asserts the gate names the same sentences there as on the generic
  routing for every phrasing set, so a gate change lands on both branches at once.
- `branches/packs.py`: the D9/D10 edits are confined to `_worked_branch`, `pack_decided_equations` (two new keys; the Geography
  pack's decided statements without an '=' join the decided set) and `GenericPack.checks`, factored into `unknown_supports(report)`.

## 6. Measured regeneration (on a scratch copy only; the shared tree was not regenerated)

On a copy of the working tree: set `integration/COMPATIBILITY.json` `subject_map` to version `2026-11-16.1`, sha256
`c4eeaae45660c107c558e71616ccf264b15b9bb2c58913d07a79ded14e1aee85` (the digest of the new map as written by this build; it changes
if the map changes again), then `generate.py` (32 files), `vectors.py` (24 handshake files rewritten) and `manifest.py`. With the
copy's `src` first on the path, `tests/integration`: 1,472 passed, 1 skipped, 1 xfailed, 1 failed:
`test_website_kit.py::test_result_lists_exactly_what_a_full_apply_touches_and_the_copied_files_are_the_tested_ones` (patch set M's
`RESULT.sha256` lines for the two data copies, item 2). The generator refuses to run until the pin's version and digest are both
changed (it names the mismatch); that is the order to follow.

## 7. For the self-certification implementer: false positives of the in-progress gate on recorded answers (urgent)

Measured on the shared tree after your call-site switch had started (late in this run; earlier in the run these answers were clean
and the harness on the copies matched the baseline). Identical on the new branches and on the generic routing, so they come from
the shared gate, not from the branches. `tests/branches/test_d9d10_recorded.py` pins these receipts as `ACCEPTED` and now fails on
two of them; it must not be loosened (fix the reader):

- c2 sp-t15 `g7.2`: "Es cierto, pero el problema no es el turismo en sí, sino el modo en que se gestiona." named CORE-SELF-001
  ("states that the answer or its items were checked, verified or confirmed"); "es cierto" is "it is true", a concession in the
  model article, not a self-report.
- c2 sp-t15 `g11.1`: "Word count: about 513 including headline and byline (about 499 in the body), inside the 450–600 range."
  named CORE-SELF-001 as a verification-status label in front of its content; a word-count line is no verification status.
- c3 sp-p10d `g2.17`: '"merito" is a diminutive-style form of "mero" (exact).' named CORE-SELF-001; "(exact)" glosses the
  Spanish word "mero", it is no verification label.

Each brings INT-HANDOFF-006 (info) and turns the receipt from ACCEPTED to ACCEPTED_WITH_FINDINGS. At the same time
`tests/branches/test_c3_clearance_self_reports.py` (109 failures: `self_report._read_piece` no longer exists) and four cases of
`tests/branches/test_c2b_clearance_parsers.py` fail on the shared tree; those are the test rewrites of your section 6.
