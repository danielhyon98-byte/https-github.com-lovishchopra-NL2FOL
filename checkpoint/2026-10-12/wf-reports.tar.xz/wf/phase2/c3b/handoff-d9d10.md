# Handoff from the D9/D10 implementer (Geography and Language B branches, decision D35)

Every item below is outside the files this implementer owns. Nothing here was done by the D9/D10 build.

## 1. Kit regeneration (the cross-owner fixer, once, together with the POLICY_VERSION bump)

`integration/subject-map.json` changed under option A (approved): the `branch` of the rows `geography`, `spanish-b` and
`language-b-spanish` is now `geography`, `language_b`, `language_b`, and the map version is `2026-11-16.1`. Nothing else in the
file changed (routes null, environments `["service"]`, provisional true, note and slugs as before).

Regenerate with the kit's own tooling, once, after the self-certification implementer's `COMPATIBILITY.json` change:

- `python integration/tools/generate.py` (`src/epinoic_logic/integration/compat.py`, `integration/website/src/verify/compat.js`,
  `integration/website/src/verify/subject-map.js`, the `subject_map` pin in `integration/COMPATIBILITY.json`, `schemas/`);
- the handshake vectors (`integration/tools/vectors.py`; the files under `integration/vectors/handshake/` embed the map digest);
- `integration/MANIFEST.sha256` (also covers the edited `integration/DECISIONS.md`).

Until then the integration tests that compare generated copies, the map digest pin and the manifest fail (expected; listed in the
D9/D10 report). `preflight.subject_map()` (KIT-HS-010) passes only when the map's branch column and the hub's routing agree, which
they now do in the source map.

## 2. Website patch set M

`integration/website/patches/M/RESULT.sha256` records `src/verify/compat.js` and `src/verify/subject-map.js`; both data copies change
with the regeneration. Re-run the patch set's record on a disposable export, or record it as not re-run (precedent in
`integration/website/patches/M/TESTED.json`).

## 3. docs/handoff (round 10 finding #18)

Round 10's finding #18 ("Geography and Language B route to the generic branch") is resolved by D35 on this tree. The run's handoff
notes should name it resolved, with the follow-ups below.

## 4. Follow-ups recorded, not done (design section 15)

- Own code families (GE-, LB-) for deterministic subject findings that are not engine checks: rows in
  `overseer/src/epinoic_overseer/emitted.py`, the families tuples of `overseer/tests/overseer_tests/test_integration_codes.py`,
  the overseer knowledge pack (completeness test), `PINNED_PACK_DIGESTS` and the preflight's KIT-HS-007 pin.
- Re-roling a model text's sentences as a performance (non-assertive), with its fixture and harness impact measured first.
- Promoting the Spanish number-word reader from `integrity/ledger.py` (`_spanish_word_figures`, re-exported today as
  `branches.spanish_lexicon.spanish_number_figures`) into the lexicon module (core owner).
- A `word_count_view` hub hook for Language B, if the channel's measure ever needs to read only the Spanish production.
- Subject aliases ("Spanish", "Español", "Spanish ab initio SL") under the next POLICY_VERSION.
- The c3 `ge-p10c` peer exchange with Chemistry (planned, never answered): run it in the next round.

## 5. Notes for the self-certification implementer

- Both new branches carry `CorePack()` first; the shared gate reaches them unchanged. Neither new pack defines a self-report
  reader (asserted in `tests/branches/test_d9d10_routing.py::test_every_branch_runs_the_shared_core_pack_first`).
- `tests/branches/c2_hold_texts.py` `BRANCH_OF` now maps Geography to `geography` and Spanish B to `language_b` (stricter: the set
  of branches it covers is checked against the registry's 11 keys). The self-report suites parametrized over `SUBJECTS` now run
  through the new branches; `tests/branches/test_d9d10_parity.py` asserts the gate names the same sentences there as on the generic
  routing for every phrasing set, so a gate change lands on both branches at once.
- `branches/packs.py`: the D9/D10 edits are confined to `_worked_branch`, `pack_decided_equations` (two new keys; the Geography
  pack's decided statements without an '=' join the decided set) and `GenericPack.checks`, factored into `unknown_supports(report)`.

## 6. Measured regeneration (on a scratch copy only; the shared tree was not regenerated)

On a copy of the working tree: set `integration/COMPATIBILITY.json` `subject_map` to version `2026-11-16.1`, sha256
`c4eeaae45660c107c558e71616ccf264b15b9bb2c58913d07a79ded14e1aee85` (the digest of the new map as written by this build; it changes
if the map changes again), then `generate.py` (32 files), `vectors.py` (24 handshake files rewritten) and `manifest.py`. With the
copy's `src` first on the path, `tests/integration`: 1,472 passed, 1 skipped, 1 xfailed, 1 failed:
`test_website_kit.py::test_result_lists_exactly_what_a_full_apply_touches_and_the_copied_files_are_the_tested_ones` (patch set M's
`RESULT.sha256` lines for the two data copies, item 2). The generator refuses to run until the pin's version and digest are both
changed (it names the mismatch); that is the order to follow.

## 7. For the self-certification implementer: false positives of the in-progress gate on recorded answers (urgent)

Measured on the shared tree after your call-site switch had started (late in this run; earlier in the run these answers were clean
and the harness on the copies matched the baseline). Identical on the new branches and on the generic routing, so they come from
the shared gate, not from the branches. `tests/branches/test_d9d10_recorded.py` pins these receipts as `ACCEPTED` and now fails on
two of them; it must not be loosened (fix the reader):

- c2 sp-t15 `g7.2`: "Es cierto, pero el problema no es el turismo en sí, sino el modo en que se gestiona." named CORE-SELF-001
  ("states that the answer or its items were checked, verified or confirmed"); "es cierto" is "it is true", a concession in the
  model article, not a self-report.
- c2 sp-t15 `g11.1`: "Word count: about 513 including headline and byline (about 499 in the body), inside the 450–600 range."
  named CORE-SELF-001 as a verification-status label in front of its content; a word-count line is no verification status.
- c3 sp-p10d `g2.17`: '"merito" is a diminutive-style form of "mero" (exact).' named CORE-SELF-001; "(exact)" glosses the
  Spanish word "mero", it is no verification label.

Each brings INT-HANDOFF-006 (info) and turns the receipt from ACCEPTED to ACCEPTED_WITH_FINDINGS. At the same time
`tests/branches/test_c3_clearance_self_reports.py` (109 failures: `self_report._read_piece` no longer exists) and four cases of
`tests/branches/test_c2b_clearance_parsers.py` fail on the shared tree; those are the test rewrites of your section 6.

## 8. Re-validation on the current shared tree (D9/D10 implementer, resumed; supersedes the measurements of sections 6 and 7)

Measured after the self-certification implementer's switch to `epinoic_logic.selfcert` had landed in the shared tree
(`POLICY_VERSION` 2026.11-v5 and `contract` 0.6 in `COMPATIBILITY.json`, kit not yet regenerated).

### 8.1 CRITICAL for the self-certification implementer: input stall in `selfcert/reader.py`

- `tests/integration/test_integration_gate4_branch_checks.py::test_sweep_integration_claims[mark labels]` and
  `::test_sweep_integration_routing_features[mark labels]` fail when run alone. The input is the sweep's 20,007-character
  `x = 5 (A1) (A1) ... z` (Computer Science, not a D9/D10 path).
  - `claim_entries` takes 35.4 s CPU against the 4 s bound.
  - cProfile: `selfcert/reader.py:_tokens` is called 3,120 times and builds 3,654,299 token objects (`reader.py:79 __init__`,
    `:118 _number`). The whole text is re-tokenised once per piece, which is quadratic: the round-10 stall class.
- `tests/branches/test_integration_gate2_quant.py::test_the_generic_parser_reads_a_long_line_of_marks_in_linear_time[<lambda>0]`
  and `[<lambda>2]`, and `tests/branches/test_r5_quant_packs.py::test_bracket_heavy_answers_cross_the_english_branch_quickly[2000-unclosed-fragments]`
  fail when run alone.
  - Under load the growth ratio was 18.4 (bound 8). Alone it measured 0.58 s at 20k and 2.42 s at 80k.
  - The profile is dominated by `selfcert/reader.py` `read_text` and `_net_found`.
  - In the earlier D9/D10 run, before the switch, `tests/branches` had 0 failures.

### 8.2 False positives of the shared gate on the recorded Geography and Spanish answers

Identical on the new branches and on the generic routing (`tests/branches/test_d9d10_parity.py` passes, 23 of 23), so they come
from the gate, not the branches. Each now brings INT-HANDOFF-006, and several make the claim NOT_ELIGIBLE (lost fixtures).

| Answer | Claim | Text | Wrongly read as |
| --- | --- | --- | --- |
| c1 ge-t14 | g5.2 | "The table below is invented for practice (Larkmoor Square is a fictional place)." | verification-status label (also INT-LEDGER-029 on the synthesis) |
| c1 ge-t14 | g7.1 | "Step 1: rank each variable, giving rank 1 to the lowest value." | note/self-report; now NOT_ELIGIBLE (also INT-LEDGER-029 on the synthesis) |
| c1 ge-t14 | g15.1 | "Examiners stop reading at 2,500 words, and that limit covers the whole report." | NOT_ELIGIBLE as a self-report |
| c2 ge-p9c | g4.4 | "Result: the calculated discharge is 16.2 m³ s⁻¹." | note; now NOT_ELIGIBLE |
| c2 ge-p9c | g6.4 | "The lag time fell from 12 hours in 2006 to 4.5 hours in 2024, ..." | NOT_ELIGIBLE as a self-report |
| c2 sp-t15 | g7.2 | "Es cierto, pero el problema no es el turismo en sí, ..." | verification status (a concession in the model article); also INT-LEDGER-029 on the synthesis |
| c2 sp-t15 | g11.1 | "Word count: about 513 including headline and byline (about 499 in the body), inside the 450–600 range." | verification-status label |
| c3 sp-t16 | g1.2, g1.9, g1.23, g1.24 | "What the task wants: ...", "Biggest gap: ...", "Pattern: ...", "Variety (a choice, not an error): ..." | verification-status labels; INT-LEDGER-029 on the synthesis |

Consequences:

- `tests/branches/test_d9d10_recorded.py::test_recorded_answer_receipt_is_pinned[c2/sp-t15]` fails: ACCEPTED became
  ACCEPTED_WITH_FINDINGS. It must not be loosened; fix the reader.
- In the harness, the translations served drop: c1 ge-t14 24 to 23, c2 ge-p9c 19 to 17.
- INT-LEDGER-029 (warning) appears on the synthesis records of c1 ge-t14, c1 sp-t14, c2 sp-t15 and c3 sp-t16. On sp-t14 it is
  raised on the combinator's dropped-entry reason "a remark about a note embedded in the supplied article ...".

Other failures of the gate's test rewrites (still pending):

- `tests/branches`: 1,151 failed and 7,638 passed. Nearly all failures are in the self-report suites (c2_hold_*, c3_*_self_reports).
- Content cases fail on every branch alike:
  - `test_c1_clearance_parsers`: "La respuesta es correcta: el pueblo tenía catorce alumnos." and "Step 1: ...";
  - `test_c2_clearance_parsers`;
  - `test_c2b_clearance_parsers`: narrated self-checks such as "I proofread my answer." are no longer named, on geography and on
    english alike.

### 8.3 Harness on copies of c1, c2 and c3 (current tree)

| Round | Transport | Last verified line |
| --- | --- | --- |
| c1 | 203/203 | 203/203 |
| c2 | 188/188 | 188/188 |
| c3 | 163/176 | 164/176 |

- **The c3 loss is c3 en-t16 `altered_quotation` (English):** "no INT-REQ-003 finding names the injected claims ['p2-s02']".
  An attribution run of the same tree with Geography and Language B routed back to `generic` (in-process, no repository change)
  gives the same 163/176, so the loss is not the branches'. It belongs to whoever owns the channel's INT-REQ-003 and the gate's
  reading of p2-s02.
- **Attribution, record by record (new branches against generic routing on the same tree), c1, c2 and c3.** Every record is
  identical in status, functional, codes, constraints, coverage, claims, translation outcomes and fixtures served. The only
  differences are the added Language B checks, all ENTAILED:
  - sp-t14: `language-b-supplied-figure-1..3`;
  - sp-t15: `language-b-word-count-1,2` and `language-b-word-range-claim-1`;
  - sp-t16: `language-b-word-count-1`, `-word-range-claim-1`, `-address-form-1,2` and `-listed-count-1`.

  Three History/English `self_certification` records (hi-p10b, hi-t16, lit-t16) differed on INT-REQ-005. Those subjects are not
  routed by D9/D10. The difference comes from the shared tree changing between the two runs.
- **Geography records:** no new check, as designed (design section 7.3).
- **Spanish and Geography mutation variants:** every one is still functional.

### 8.4 Integration tests on a scratch copy with the kit regenerated (map pin 2026-11-16.1, `c4eeaae4...`)

On a copy of the current tree with the kit regenerated (`generate.py` 32 files, `vectors.py` 49 written, `manifest.py`):
26 failed, 1,447 passed. No failure is in a D9/D10 path:

- self-report port suites (c2_hold_remedy2_*, combinator self-certification cases): the gate;
- `test_overseer_subproject` (2): `overseer/.../meta_notes.py` imports the translator internal `epinoic_logic.selfcert.normalise`
  (the gate);
- gate4 mark-labels sweeps (8.1);
- `test_readiness` g1;
- `test_website_kit` patch set M `RESULT.sha256` (section 2, expected until re-run).

On the shared tree without regeneration, 354 failed: KIT-HS-002 (policy 2026.11-v5 not in the generated compatibility copy) and
the map digest pin. That is expected until the single regeneration of section 1.

### 8.5 tests/adapters and tests/channel on the shared tree

192 failed, 3,052 passed, 1 skipped. No failure is in a D9/D10 path:

- The self-report and verification-label suites: overseer_round1/2/5/6, verification_labels, synthesis_self_certification,
  gate2 and gate3 parsers, channel verification_labels_at_delivery and r7 note paragraphs.
- `tests/adapters/test_structural.py::test_structural_checks_work_on_reports_not_made_by_this_parser`: the English specialist's
  ES-STR/ES-STY findings are displaced by ES-META-001 (the gate). This is not GEN-STR-001: `unknown_supports` is pinned on both new
  branches by `test_d9d10_parity.py::test_unknown_supports_are_named_on_both_branches`.
- `tests/channel/test_branch_check_mapping.py` (22): the new `BranchRegistryError` "branch 'generic' must run the core pack (the
  self-certification gate) as its first pack" (`branches/base.py`, the gate's rule). The test's bare `SubjectBranch(key="generic",
  packs=...)` needs the gate owner's rewrite. Both D9/D10 branches carry `CorePack()` first.
