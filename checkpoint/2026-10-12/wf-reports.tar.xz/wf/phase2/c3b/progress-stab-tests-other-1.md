# progress stab tests-other round 1
- started; 152 failures in 15 files grouped. Nothing edited yet.
- DONE: tests/channel/test_branch_check_mapping.py, tests/contract/test_receipt_plumbing.py (CorePack first in fixture; 34 pass)
- DONE: test_c2_hold_self_certification_gate.py (patch selfcert_read). core_hostile 94 = tests/branches file (other owner, already rewritten). T8 tamper = overseer/scripts/tamper.py source -> handoff
- DONE: meta_note allowlist + rule_names rewrites (stricter, labelled). Handoff H1 written (Next step compare = reader FP). NEXT: meta_note commas timing, lead_blocks
- DONE: lead_blocks 3 REFUSED_SOURCE_LISTS rows -> SOURCE_LIST_RULE stricter. Handoffs H2 (commas perf), H3 (bi-t14 checking-that FP). NEXT: non_material, round4, round5, round6, delivery_support, review3, adapters round6, e2e english, translate review, integrity synthesis, combinator subproject
- DONE non_material NO_LEAD branch stricter. Handoff H4 (recorded round-8 unread rows: reader FPs + parser change). NEXT: round4/5/6, delivery_support, review3, adapters round6, e2e english, translate review, integrity synthesis, combinator subproject, round4 confusables
- DONE round4: skeleton (Nl) + glued (stricter). Handoffs H5 (CRITICAL glued miss), H6 (parser Q), H7 (ch/ge recorded FPs + script unread). NEXT: round5, round6, delivery_support, review3, adapters round6, e2e english, translate review, integrity synthesis, combinator subproject, scoring T8 handoff
