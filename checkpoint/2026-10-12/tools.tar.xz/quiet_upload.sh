#!/usr/bin/env bash
# Upload the newest final commit once the machine is quiet. The full suite's wall-clock linearity tests fail when other
# workflows load the machine (3adfd73: 1 and 3 such failures at load 10-14; the same tests pass alone). This waits until the
# 1-minute load stays under 3 for 10 minutes, then re-runs presim.sh (a fresh simulation; failed caches are set aside
# first) and event_push.sh, which uploads only on a passing simulation and the publisher's gates. At most 3 attempts.
# Runs detached (setsid nohup), so it continues when this session is idle.
set -uo pipefail
S=$(cd "$(dirname "$0")" && pwd)
for attempt in 1 2 3; do
  quiet=0
  while [ "$quiet" -lt 10 ]; do
    l=$(cut -d' ' -f1 /proc/loadavg)
    if awk -v l="$l" 'BEGIN{exit !(l < 3.0)}'; then quiet=$((quiet + 1)); else quiet=0; fi
    sleep 60
  done
  echo "$(date -u +%H:%M:%S) attempt $attempt: machine quiet"
  for f in "$S"/simcache/translator-*.txt; do grep -qs '^SIMULATION FAILED' "$f" && mv -f "$f" "$f.failed-$(date -u +%H%M)"; done
  nice -n 5 bash "$S/presim.sh"; echo "presim-exit $?"
  NEW=$(ls -t "$S"/simcache/translator-*.txt 2>/dev/null | head -1)
  echo "newest simulation: $(basename "$NEW"): $(tail -1 "$NEW")"
  # event_push does nothing from hh:56 to hh:03 (the hourly push's window); wait outside it.
  while M=$((10#$(date -u +%M))); [ "$M" -ge 55 ] || [ "$M" -le 4 ]; do sleep 30; done
  bash "$S/event_push.sh"; echo "event_push-exit $?"
  if grep -qs '^SIMULATION OK' "$NEW"; then echo "$(date -u +%H:%M:%S) the simulation passed; done"; break; fi
done
echo "$(date -u +%H:%M:%S) quiet_upload finished"
