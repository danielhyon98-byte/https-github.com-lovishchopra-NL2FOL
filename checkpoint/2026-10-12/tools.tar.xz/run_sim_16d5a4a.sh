#!/usr/bin/env bash
# Detached re-run (2 Nov) of the publisher's simulation of 16d5a4a after the first run was cut at the 2-hour limit for
# background commands during its contained run. The suite already passed on exactly this commit in that run (evidence:
# sim-evidence/16d5a4a-run1-cut-at-2h.txt), so it is skipped here (SIM_SKIP_SUITE=1, the script's option for that case).
# Harness floors: 1965f07's record (every recorded round r1 to r7), stricter than 16d5a4a's own record (r7 only).
# Caches exactly as presim.sh does, then runs event_push.sh (outside hh:56-hh:03); it uploads only on SIMULATION OK.
set -uo pipefail
S=/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad
T=16d5a4af748dcde36c8bc6f21cf0daabbaa81584; FLOOR=1965f07823ef96577a885ff81fa1c7cb103165b4
F=$S/simcache/translator-$T.txt
echo "start $(date -u +%H:%M:%S)"
exec 8>"$S/.presim.lock"; flock 8
SIM_SKIP_SUITE=1 bash "$S/simulate.sh" translator "$T" "$FLOOR" > "$F.tmp" 2>&1
if [ "$(grep -c '^SIMULATION ' "$F.tmp")" -gt 0 ]; then date -u +%H:%M:%S >> "$F.tmp"; mv "$F.tmp" "$F"; else echo "simulation did not finish"; fi
flock -u 8; exec 8>&-
echo "simulation $(date -u +%H:%M:%S): $(grep '^SIMULATION ' "$F" 2>/dev/null | tail -1)"
if grep -q '^SIMULATION OK' "$F" 2>/dev/null; then
  for i in $(seq 1 30); do M=$((10#$(date -u +%M))); if [ "$M" -ge 56 ] || [ "$M" -le 3 ]; then sleep 60; continue; fi; bash "$S/event_push.sh"; break; done
fi
echo "done $(date -u +%H:%M:%S)"
