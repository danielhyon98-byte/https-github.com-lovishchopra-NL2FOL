#!/usr/bin/env bash
# Functional simulation of a tree before it is uploaded to the main repository (Daniel, 2026-10-12: "do not upload
# dysfunctional code; always run a simulation to ensure functionality").
#
#   simulate.sh translator TREE SOURCE   full suite, then every recorded arena round replayed through the translator
#                                        code; every round must run, have no infrastructure failure, and keep at least
#                                        the functional count recorded in SOURCE's "Harness after the change" line.
#   simulate.sh overseer TREE SOURCE     the same (rounds the source records, at least r3), plus the overseer's
#                                        contained run over every recorded round: every gate must pass (no false alarm
#                                        on a genuine transfer, every tampering detected, every arena fault named, ...).
#                                        A source that carries a merged development translator (the overseer rebuild
#                                        on the STEM-merged translator, or a later commit on its line) keeps that
#                                        translator as verified: its floor is, per round, the higher of its own record
#                                        and the record of the newest commit in T's first-parent history that has one
#                                        (T: the merge's second parent; overseer_gate.harness_floor). No such record
#                                        fails the simulation.
# SIM_SKIP_SUITE=1 skips the suite when the caller has just run it on the same code.
# Prints one line per measurement and ends with "SIMULATION OK: ..." (exit 0) or "SIMULATION FAILED: ..." (exit 1).
# Recorded rounds are copied first and never modified; no model is called.
set -uo pipefail
KIND=$1; TREE=$2; SOURCE=$3
R=/home/user/https-github.com-lovishchopra-NL2FOL
S=$(cd "$(dirname "$0")" && pwd)
VPY=$S/z3venv/bin/python
W=$(mktemp -d); trap 'rm -rf "$W"' EXIT
FAIL=""
mkdir -p "$W/tree" "$W/rounds"
git -C "$R" archive "$TREE" | tar -x -C "$W/tree" || { echo "SIMULATION FAILED: could not unpack $TREE"; exit 1; }
for d in "$S"/arena/r[0-9]*; do [ -d "$d/specialists" ] && cp -r "$d" "$W/rounds/"; done
# Hermetic interpreter: a few tests start "python -I" subprocesses, which ignore PYTHONPATH and would import the package
# from the shared editable install (the main checkout, possibly mid-merge) instead of the tree under test. An overlay
# environment whose only path file lists the tree's src first, then the shared environment's packages, makes every
# process in the simulation import exactly the tree being simulated.
ZSP=$("$VPY" -c "import sysconfig; print(sysconfig.get_paths()['purelib'])")
"$VPY" -m venv --without-pip "$W/venv" >/dev/null 2>&1 || { echo "SIMULATION FAILED: could not create the overlay environment"; exit 1; }
OSP=$("$W/venv/bin/python" -c "import sysconfig; print(sysconfig.get_paths()['purelib'])")
printf '%s\n%s\n' "$W/tree/src" "$ZSP" > "$OSP/00-simulated-tree.pth"
VPY=$W/venv/bin/python
GOT=$(cd / && "$VPY" -I -c "import epinoic_logic; print(epinoic_logic.__file__)" 2>&1)
case "$GOT" in "$W/tree/src/"*) ;; *) echo "SIMULATION FAILED: the overlay environment imports $GOT, not the tree under test"; exit 1 ;; esac

if [ -z "${SIM_SKIP_SUITE:-}" ]; then
  (cd "$W/tree" && EPINOIC_ARENA_ROUNDS="$W/rounds" PYTHONPATH="$W/tree/src" timeout 5400 "$VPY" -m pytest -q -p no:cacheprovider) >"$W/suite.log" 2>&1
  RC=$?; TAIL=$(tail -1 "$W/suite.log" | sed 's/=//g; s/^ *//; s/ *$//')
  echo "suite: $TAIL (exit $RC)"
  # Name the failing tests, so a red simulation says what failed (the work folder is removed on exit).
  [ "$RC" -ne 0 ] && grep -E '^(FAILED|ERROR) ' "$W/suite.log" | head -20 | sed 's/^/  /'
  if [ $RC -ne 0 ] || ! echo "$TAIL" | grep -qE '^[0-9]+ passed(, [0-9]+ (skipped|deselected|warnings?|xfailed|xpassed|subtests (passed|skipped|xfailed|xpassed)))* in [0-9.]+s'; then FAIL="$FAIL; suite not green ($TAIL)"; fi
else
  echo "suite: run by the caller on the same code"
fi

# Rounds to replay: those the source commit records (translator), at least r3 (overseer); counts must not drop.
RECORDED=$(git -C "$R" log -1 --format=%B "$SOURCE" | sed -n 's/^.*Harness after the change: //p' | head -1)
python3 -I - "$KIND" "$RECORDED" "$W" "$VPY" "$S" "$R" "$SOURCE" <<'EOF' > "$W/harness.txt"
import json, os, re, subprocess, sys
kind, recorded, w, vpy = sys.argv[1:5]
want = {m.group(1): (int(m.group(2)), int(m.group(3))) for m in re.finditer(r"\b(r\d+(?:-[a-z]+)?)\s+(\d+)/(\d+)", recorded)}
fails = []
if kind == "overseer":
    # An overseer source that carries a merged development translator must keep it as verified at T.
    try:
        sys.path.insert(0, sys.argv[5])
        import overseer_gate as G
        fl = G.harness_floor(sys.argv[6], sys.argv[7])
    except Exception as e:
        fl = None
        fails.append(f"translator floor: {e}")
    if fl:
        want, t, rc = fl
        print(f"floor: per round the higher of the source's record and the translator's at {t[:7]} (recorded at {rc[:7]}): "
              + ", ".join(f"{r} {n}/{m}" for r, (n, m) in sorted(want.items())))
rounds = sorted(want) if want else ["r3"]
if kind == "overseer" and "r3" not in rounds:
    rounds.append("r3")
for r in rounds:
    d = os.path.join(w, "rounds", r)
    if not os.path.isdir(d):
        fails.append(f"{r}: recorded round missing"); continue
    p = subprocess.run([vpy, os.path.join(w, "tree", "scripts", "arena", "run_arena.py"), d], capture_output=True, text=True,
                       env={**os.environ, "PYTHONPATH": os.path.join(w, "tree", "src")}, timeout=900)
    try:
        res = json.load(open(os.path.join(d, "results.json")))
        got = (int(res["functional"]), int(res["transmissions"]))
    except Exception as e:
        fails.append(f"{r}: no results ({p.returncode}: {p.stderr.strip().splitlines()[-1:] if p.stderr.strip() else e})"); continue
    infra = re.search(r"^failures: (\d+)", p.stdout, re.M)
    line = f"{r} {got[0]}/{got[1]}" + (f" (recorded {want[r][0]}/{want[r][1]})" if r in want else "")
    print(line)
    if p.returncode != 0:
        fails.append(f"{r}: harness exit {p.returncode}")
    # A recorded round may keep its recorded misses (r1-adv's planted empty answer is correctly REJECTED and counted
    # as not functional); it may never do worse. A round with no record must be fully functional.
    if infra and r in want and int(infra.group(1)) > want[r][1] - want[r][0]:
        fails.append(f"{r}: {infra.group(1)} failure(s), recorded {want[r][1] - want[r][0]}")
    if r in want and got[0] < want[r][0]:
        fails.append(f"{r}: functional {got[0]} < recorded {want[r][0]}")
    if r not in want and got[0] < got[1]:
        fails.append(f"{r}: {got[1] - got[0]} transmission(s) not functional")
print("FAILS:" + "; ".join(fails))
EOF
grep -v '^FAILS:' "$W/harness.txt" | sed 's/^/harness: /'
HF=$(sed -n 's/^FAILS://p' "$W/harness.txt")
[ -n "$HF" ] && FAIL="$FAIL; $HF"

# The overseer's contained run is part of every simulation of a tree that carries the overseer package (once merged into
# the translator, an upload must pass it on every recorded round too).
if [ "$KIND" = "overseer" ] || [ -f "$W/tree/scripts/overseer/run_contained.py" ]; then
  (cd "$W/tree" && PYTHONPATH=src timeout 5400 "$VPY" scripts/overseer/run_contained.py --out "$W/contained" --rounds "$W/rounds") >"$W/contained.log" 2>&1
  CRC=$?
  GATES=$(python3 -I -c "
import json, sys
try:
    d = json.load(open(sys.argv[1]))
except Exception as e:
    print('FAIL no contained results'); sys.exit()
g = d.get('gates', {})
bad = [k + (' (' + str(v.get('value')) + (' of ' + str(v['of']) if 'of' in v else '') + ')' if isinstance(v, dict) and 'value' in v else '') for k, v in g.items() if not (v.get('ok') if isinstance(v, dict) else v)]
t = g.get('tamper_suite', {})
print('contained: rounds ' + ', '.join(f\"{k} {v.get('functional')}/{v.get('transmissions')}\" for k, v in sorted(d.get('rounds', {}).items())) + f\"; tamperings {t.get('detected')}/{t.get('tamperings')}\")
print('FAIL ' + '; '.join(bad) if bad else 'OK')
" "$W/contained/results.json")
  echo "$GATES" | head -1
  echo "$GATES" | tail -1 | grep -q '^OK' || FAIL="$FAIL; contained run (exit $CRC): $(echo "$GATES" | tail -1 | sed 's/^FAIL //')"
fi

if [ -n "$FAIL" ]; then echo "SIMULATION FAILED: ${FAIL#; }"; exit 1; fi
echo "SIMULATION OK: $KIND tree $(git -C "$R" rev-parse --short "$TREE") (source $(git -C "$R" rev-parse --short "$SOURCE"))"
