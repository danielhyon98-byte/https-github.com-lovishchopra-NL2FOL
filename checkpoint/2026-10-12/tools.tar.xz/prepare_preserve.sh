#!/bin/bash
# Build local preservation-snapshot branches refs/heads/preserve/2026-10-16/<name> for the canonical repository
# (Epinoic-AI/Epinoic-Logic-Translator). Each is ONE commit: parent = verified-updates head a91a4f9 (never moved),
# tree = the preserved source (a committed branch, or a checkout's on-disk state captured through a temporary index),
# with a91a4f9's update notes (UPDATE_README.md, docs/updates/) carried over so the diff shows only real changes.
# Nothing is pushed here. Usage: prepare_preserve.sh build | scan
set -euo pipefail
R=/home/user/https-github.com-lovishchopra-NL2FOL
BASE=a91a4f977b39a155722d50fe2808434a35ae315e
NS=refs/heads/preserve/2026-10-16
cd "$R"

tree_of_disk() {  # on-disk state of checkout $1 (tracked + untracked, .gitignore respected), index untouched
  local W=$1 G T IDX; G=$(git -C "$W" rev-parse --absolute-git-dir); IDX=$(mktemp)
  cp "$G/index" "$IDX"; GIT_INDEX_FILE=$IDX git -C "$W" add -A >/dev/null; T=$(GIT_INDEX_FILE=$IDX git -C "$W" write-tree); rm -f "$IDX"; echo "$T"
}
with_notes() {  # tree $1 plus BASE's update notes
  local IDX T; IDX=$(mktemp); GIT_INDEX_FILE=$IDX git read-tree "$1"
  git ls-tree -r "$BASE" -- UPDATE_README.md docs/updates | GIT_INDEX_FILE=$IDX git update-index --index-info
  T=$(GIT_INDEX_FILE=$IDX git write-tree); rm -f "$IDX"; echo "$T"
}
mk() {  # name tree subject body
  local MSG C; MSG=$(mktemp)
  printf '%s\n\n%s\n\nThis branch only preserves work. It is not verified, not merged and must not be released or deployed; the verified line remains verified-updates (%s).\n\nCo-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>\nClaude-Session: https://claude.ai/code/session_016YotQwcC83EEJm8zshdxtW\n' \
    "$3" "$4" "${BASE:0:7}" > "$MSG"
  C=$(git -c user.name=Claude -c user.email=noreply@anthropic.com commit-tree "$(with_notes "$2")" -p "$BASE" -F "$MSG"); rm -f "$MSG"
  git update-ref "$NS/$1" "$C"; echo "$1 $C"
}

build() {
  git for-each-ref --format='%(refname)' "$NS" | while read -r r; do git update-ref -d "$r"; done
  mk overseer-ef4ba9f "$(git rev-parse 'ef4ba9fd82256b4b53effff1bf499f9420bec4a4^{tree}')" \
    "Preservation snapshot (UNVERIFIED, not a release): corrected overseer ef4ba9f" \
    "The overseer with its fault corrections (circular-translation severity by engine evidence, adjudicated genuine faults, STEM-ready checks, knowledge pack 1.2), as committed locally on 12 Oct (source commit ef4ba9fd82256b4b53effff1bf499f9420bec4a4). Its own fix pass measured a green suite and its contained gates; it has not passed the upload gate and was never published."
  mk overseer-rebuild-wip "$(tree_of_disk .worktrees/overseer)" \
    "Preservation snapshot (UNVERIFIED, work in progress): overseer rebuild on the STEM-merged translator" \
    "Uncommitted on-disk state of the overseer rebuild captured 16 Oct 2026 19:4x UTC: merge of translator 47b8c21 into overseer ef4ba9f, all conflicts resolved, first repair applied, second repair interrupted part-way. The last independent audit was NOT clean (open: label-only trust of task_setting restatements and the pack guidance for it, a circular premise hidden by conjoining a verified fact, one adjudicated record that is a correct transcription, pack I85 versus the consolidation code)."
  mk review-fixes-wip "$(tree_of_disk .)" \
    "Preservation snapshot (UNVERIFIED, work in progress): fixes for the nine external-review findings" \
    "Uncommitted on-disk state of the integration of the review fixes into translator 361cc4e, captured 16 Oct 2026 19:4x UTC, with a second repair interrupted part-way. The last independent verification accepted 9 of 11 items; open: finding 2 (a numerals-in-task check confers authority on an invented relation) and finding 6 (some non-asserting phrasings still give E110 and withhold a valid counterexample)."
  for b in review-engine review-translate review-metrics; do
    mk "$b" "$(git rev-parse "$b^{tree}")" "Preservation snapshot (UNVERIFIED, not a release): $b fix branch" \
      "Per-area fixes for the nine external-review findings as committed locally (source commit $(git rev-parse "$b")), with their regression tests. Superseded by the integration in preserve/2026-10-16/review-fixes-wip; not independently verified."
  done
  for b in review-stem-checks review-stem-channel; do
    mk "$b" "$(git rev-parse "$b^{tree}")" "Preservation snapshot (UNVERIFIED, not a release): $b (STEM review fixes)" \
      "Fixes for the STEM review findings as committed locally (source commit $(git rev-parse "$b")), with their regression tests. Not yet integrated and not independently verified."
  done
}

scan() {
  set +e +o pipefail
  git for-each-ref --format='%(refname:short)' "$NS" | while read -r b; do
    local files gen big
    files=$(git diff --name-only "$BASE" "$b" | wc -l)
    gen=$(git diff --name-only "$BASE" "$b" | grep -cE '(__pycache__|\.pyc$|\.egg-info|(^|/)\.?venv/|node_modules/|\.pytest_cache|\.DS_Store|\.coverage)' || true)
    big=$(git diff --name-only --diff-filter=AM "$BASE" "$b" | while read -r f; do s=$(git cat-file -s "$b:$f" 2>/dev/null || echo 0); if [ "$s" -gt 5000000 ]; then echo "$f"; fi; done | wc -l)
    added=$(git diff -U0 "$BASE" "$b" | grep '^+' | grep -v '^+++')
    cnt() { printf '%s\n' "$added" | grep -cE "$1" || true; }
    echo "$b: files=$files generated=$gen over5MB=$big secrets=$(cnt '(ghp_[A-Za-z0-9]{20}|github_pat_|gho_[A-Za-z0-9]{20}|sk-ant-[a-z0-9]|AKIA[0-9A-Z]{16}|BEGIN [A-Z ]*PRIVATE KEY|xox[bap]-|Authorization: (Bearer|token) [A-Za-z0-9])') scratch_paths=$(cnt '/tmp/claude-0|scratchpad') session_ids=$(cnt 'session_0[0-9A-Za-z]{10}|a7c3c8b5-0245') model_names=$(cnt '(claude-(opus|sonnet|haiku|fable)|\b(Opus|Sonnet|Haiku|Fable) [0-9])')"
  done
}
case "${1:-}" in build) build;; scan) scan;; *) echo "usage: $0 build|scan"; exit 2;; esac
