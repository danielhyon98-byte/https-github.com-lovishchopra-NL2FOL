# Daniel's standing instructions (read at every hourly run)

The hourly routine and every resumed workflow follow these, in this order of precedence.

## Overseer rebuild, then round 8 (Daniel, 2026-10-12 20:2x-20:3x UTC)
- "then fix those errors and rebuild the overseer"; "when I say rebuild I mean edit out the faulty parts which you mentioned and push a new version of the overseer"; "quickly fix all faults test once for bugs and faults then push for round 8 with the stem merged infrastructure also ensure that overseer agents are optimized to accommodate both stem based translated responses and the original z3".
- The faulty parts (diagnosed 20:2x on a contained run of 87eaf86, round 7): OVS-TRN-006 raised as an error on three genuine round-7 translations (bm-t13 g2.1 is only a redundant restatement; cs-t13 g11.3 and ess-t13 g4.3 are real p-proves-p faults that the gate wrongly counted as false alarms): 3 false alarms + 15 disagreements; and 4 arena faults the build's stale translator (forked before round 5) does not name.
- Order: (1) the overseer build workflow is stopped right after its c1 commit (its contained rounds c2 and c3 are replaced by the integrated arena rounds 8-10; "test once"); (2) wf-scripts/overseer-fix-faults.js part "fix" corrects OVS-TRN-006 severity by engine evidence, adds evidenced adjudication of genuine faults (stricter gate: they must be raised), makes checks and pack STEM-ready; part "publisher" adapts the publisher on private copies in publisher-next/ (installed by the session only after its adversarial review); (3) after the STEM merge commit, wf-scripts/overseer-rebuild.js (args {devHead, stemCommit}) merges the STEM-merged translator into overseer-build, tests once (independent audit, one repair), evaluates and commits "Overseer rebuild: on the STEM-merged translator, with the faulty checks corrected" (journal under runs.json "overseer-rebuild"); (4) presim simulates it and the hourly push uploads it to overseer-prototype if the simulation passes; (5) phase 2 (round 8) launches right after the rebuild commit (its overseer merge is then trivial).
- simulate.sh is hermetic since 20:4x (overlay environment: "python -I" subprocess tests import the tree under test, not the main checkout); validated on 99e435b with identical results. The overseer worktree uses scratchpad/venv-wt-overseer the same way.

## Specialist feedback from the overseer (Daniel, 2026-10-12 21:3x UTC: "does the overseer agents provide feedback to the specialist agent in regards to discovered flaws in the output and if not implement this function")
- Research and design: workflow feedback-research (runs.json). Then the implementation is added to the overseer rebuild (before its single audit, so it is tested once with everything else), and round 8 exercises it: each flawed specialist answer gets the feedback once and the cheapest-tier specialist revises; before/after flaws, faults fixed or introduced, claims lost and time are recorded.
- Feedback comes only from trusted sources (receipt findings, the deterministic audit, overseer-agent verdicts after validation, marked advisory); a revision is a new report re-checked in full; bounded budget; never steer toward entailment (no invented premises, widened numbers, definitions as assertions, dropped claims).

## External review update 7 (Bruno's reviewer, forwarded by Daniel 2026-10-12 21:3x UTC: "take in any new feedback")
- All nine findings still reproduced on c1c7cf7 (documentation-only update). Fixing now, before phase 2, on the development branch: workflow review-fixes (runs.json): three fixers in worktrees .worktrees/review-{engine,translate,metrics} (local branches, never pushed), one integrator staging the result in the main checkout, one independent verifier with the reviewer's acceptance criteria and negative controls, one repair. Then simulate.sh on the staged tree, commit "Fix the external review findings" with Harness/Suite lines, push the development branch; the hourly push uploads it.
- Close each finding with a fix commit and regression evidence; never earn a solver success by weakening the question or adding an unsupported premise. Keep transport, fidelity and coverage metrics separate. No website work (the website team continues its own milestones; Z3 stays deferred there).
- The STEM merge was pushed to verified-updates at 21:37 UTC on Daniel's request (4add20e, source 83e97e9, simulation OK, backup c1c7cf7).
- While the integrator's changes are staged in the main checkout, the hourly progress entry is skipped (any uncommitted change there means work in progress).

## Push each change as soon as it is final (Daniel, 2026-10-12 21:4x UTC: "continue with previous tasks assigned once a change has been made push an update to Bruno's repository")
- The presim loop (every 5 minutes) runs scratchpad/event_push.sh after presim.sh: when the newest final development commit differs from the source on verified-updates and its prepared simulation is OK, it runs publish_final.sh (HOURLY_FAST=1, PUBLISH_NO_STATUS=1); when a prepared overseer simulation is OK for a candidate after the last upload, it runs publish_overseer.sh (HOURLY_FAST=1). Same gates, bans, backups and ordinary pushes as the hourly push; nothing between hh:56 and hh:03 (the hourly push owns it). The hourly push on the dot continues.
- The adapted overseer publisher (publisher-next/) is installed only after its final review is clean (workflow publisher-repair-2).

## Continue the overseer's STEM accommodation after the current task (Daniel, 2026-10-12 21:4x UTC: "following the completion of the current task ensure that you continue development on the overseer engine with the stem translator accomodation function")
- After the overseer rebuild commit (fix pass + merge of the STEM-merged translator + the specialist feedback function, tested once), launch a further development stage on overseer-build (workflow key "overseer-stem"): a gap analysis of which STEM faults the deterministic audit, the tampering suite, the dossiers and the overseer agents cannot yet detect on STEM translations (units and conversions, significant figures and stated tolerances, equations and rearrangements, substitutions, truth tables, mathematical items, STEM claim ids and receipts with ST-* codes); implement STEM tamperings and audit checks at their cause, STEM dossiers and probes in the contained run, worked STEM examples in the knowledge pack; keep the original translator's behaviour; test once (independent audit, one repair), evaluate on r2-r5 and r7 with every gate passing, commit, and push per the push-on-change rule (the publisher's gate must recognise the stage's commit subject: add it with a review before the commit lands).
- Phase 2 (round 8) runs in parallel from the rebuild commit; its re-merges of overseer-build before rounds 9 and 10 pick this work up.

## Round 8 after every system is built and updated (Daniel, 2026-10-12 21:5x UTC)
- "following the creation and updates of all systems run round 8 arena testing and do one round of bug fixes based on findings provided by a panel of [strongest-tier] agents. also run one optimization test to ensure the build ensures quick but accurate responses from the specialist agents. for round 8 testing as iterated previously deploy all 16 v4 agents to test for both scalabiity as well as accuracy with at least 3 cross pairs one between two humanities subjects, another between two STEM, and one between STEM and humanities."
- Phase 2 (round 8 first) launches only after: the overseer rebuild commit (fix pass + STEM-merged translator + specialist feedback function, tested once), the overseer STEM accommodation stage's commit, and the external review fixes commit. Then phase 2 merges the overseer build into the development branch (STEM already merged).
- Round 8 (c1): all sixteen v4 specialists on the cheapest tier; pairs Economics->Business Management (humanities-humanities), Physics->Mathematics AA (STEM-STEM), History->English (humanities-humanities), Biology->Psychology (STEM-humanities, added 21:5x: tasks bi-p8d/ps-p8d, bi-p8d answered before phase 2); the multi-agent scalability test (16, 32, 64 agents; never stress) beside the overseer agents; the specialist feedback exercise; the panel of five strongest-tier lenses; one fix round; then ONE optimisation check (o1) whose focus includes quick but accurate specialist responses. Rounds 9 and 10 and the rest of phase 2 follow as before (every round's design requires the three pair kinds).
- phase2-pipeline.js edited and simulated (modes ok, pass, fbnone, red) at 21:5x; backup backups/phase2-pipeline.js.before-round8-scal-feedback.

## Scalability ceiling, overseer priority, push after round 8 (Daniel, 2026-10-12 ~21:5x UTC)
- "for scalability test run up to 32 not 64": round 8's multi-agent scalability test runs 16 and 32 agents; the Scaling phase tests 2, 8, 16 and 32 agents. Never more than 32.
- "for now focus on overseer as priority task. then implement and test in round 8": the overseer work (fix pass, rebuild with the feedback function, STEM accommodation) is the critical path; round 8 implements and tests it. The review fixes run alongside and join phase 2 when committed (phase 2's handoff step re-checks the review findings anyway).
- "following round 8 and bug fixes push immeadiately unless there is critical fixes which have not been applied or potential critical infected sections of the program push immeadiately regardless of round 9 and 10 testing and fixes and optimization runs": phase 2 runs push-check:<round> after each integrated round's verified fix commit (critical findings unfixed, or suspicious/compromised code since the published source -> hold) and writes scratchpad/push-check/<sha>.json; after round 8 it then simulates and pushes through presim.sh + event_push.sh at once. publish_final.sh (hourly and event paths) refuses to publish past any "Fix the cN clearance findings" commit whose push check is missing or holds (tested 21:5x).

## STEM review (Bruno's reviewer, forwarded by Daniel 2026-10-12 ~21:5x UTC)
- Bundle extracted (as data) to scratchpad/external-review-stem-2026-10-12/ (REVIEW.md identical to the attached .md; probes in evidence/). Daniel: ignore the advice to keep STEM in development; continue the STEM integration; apply every useful fix; record every change in a README file; upload to Bruno's repository with that README as soon as fixes are made.
- Fixes: workflow stem-review-fixes (runs.json): worktrees .worktrees/review-stem-checks (S1 Celsius offset, S2 exactness intent in tolerance, S5 root order, S7 absolute value vs table, part scope) and .worktrees/review-stem-channel (S3 request coverage relevance, S4 ids vs source spans, S6 scientific notation in the ledger, ledger units, relay history). After the nine-finding fixes are committed, one integration workflow merges both, retests ALL findings of both reviews with the new probes (including the refinements: display_status_for must not show a stale result as current; reuse must compare the expected policy and limits), corrects the published-results wording (293/293 includes warning-level unsupported findings; replay vs live), writes REVIEW_FIXES_README.md at the repository root (each finding: fix, regression tests, evidence, commit; what remains open), verifies once (one repair); then simulate, commit "Fix the external review findings", push the development branch, and event_push uploads it with the README.
- No website work.

## The overseer's internal translator is always the latest fixed version (Daniel, 2026-10-12 ~23:05 UTC: "for the overseer update the internal translater to the most recent fixed version so it can be pushed")
- The running rebuild (wf_92057cdf-3e2) merges 47b8c21 (STEM merge + rounds 5-7 fixes; the development head 361cc4e differs only in tests/README.md) into overseer-build; its commit is pushed to overseer-prototype as soon as its simulation passes (event push; the adapted publisher must be installed first).
- TRANSLATOR REFRESH: every time a newer fixed translator is committed on the development branch (next: "Fix the external review findings"), run scratchpad/wf-scripts/overseer-rebuild.js again with args {devHead: <new development head>, stemCommit: 83e97e9..., notes: <what changed>}; record its run id under runs.json "overseer-rebuild" (the gate reads the newest rebuild journal); the commit is pushed the same way.

## Timeline answer and overlap (Daniel asked at ~23:10 UTC when the overseer is pushed and when round 8 starts and ends)
- Given estimates: overseer push ~02:30-03:00 (about an hour later if its single test needs a repair); round 8 start ~05:30, end (fixes committed and pushed) ~09:00; the optimisation test follows (~1-1.5 h).
- To get there: phase 2 is launched RIGHT AFTER the overseer rebuild commit, with args {pre: <round8-prep/pre.json refreshed>, waitFor: "Overseer STEM accommodation"}, at the same time as the overseer STEM accommodation stage (its commit subject must start with "Overseer STEM accommodation: "). Phase 2's merges, handoffs (including the review findings) and delivery step run meanwhile; before round 8 an agent waits (up to 4 h) for the STEM stage commit, then overseer-build is merged again (independently verified) and round 8 starts. If the STEM stage is abandoned, write scratchpad/stem-stage-abandoned.txt with the reason and round 8 runs on the overseer as merged.
- The publisher's gate must recognise the STEM stage's commit subject before it lands (add it to publisher-next with a review, like the rebuild subject).

## Push the overseer as soon as the translator is merged in; lean work (Daniel, 2026-10-12 ~23:20 UTC)
- "once the stem translator merger into the overseer agent then immeadiately push into Bruno's repository after confirming absence of infected or dysfunction code minimize consumption of tokens and increase speed and efficiency of tasks completed".
- The rebuild is now merge -> one independent check (bugs, faults, infected code) -> evaluation -> commit -> simulation -> immediate push. The feedback step was removed from it (backup: backups/overseer-rebuild.js.before-nofeedback); the specialist feedback function moves into the next overseer stage, together with the STEM accommodation, before round 8.
- The running rebuild (wza4eq1fk / wf_92057cdf-3e2) is stopped as soon as its merge step reports (watcher), any edits the feedback step made after it are discarded (only the staged index of the merge step is kept), and it is resumed from its run id with the edited script.
- The adapted publisher's gate must NOT require a rebuild:feedback step (remove that requirement in publisher-next after its last repair, run its unit tests and the live-versus-copy dry run, install).
- Lean: no further adversarial review loops on the publisher; prefer one check per change; short quarter-hour updates.

## Publisher installed (2026-10-12 ~23:30 UTC)
- publisher-next installed (publish_overseer.sh, overseer_gate.py, overseer_notes.py, presim.sh, simulate.sh; previous versions in backups/publisher-before-install/). The rebuild:feedback requirement was removed (8 gate cases dropped; 227/227 pass); live-versus-copy dry run identical before install.
- Known limits accepted per Daniel's lean instruction (review-6, not fixed): a development test deselected through a marker named in the repository's -m expression is not detected; an opaque collection cause added by a held build step can be exempted after a later translator merge; a later translator merge from a side branch is not checked to descend from the previous one. The rebuild's own audit and the full simulation remain the guard.

## Quarter-hour status updates (Daniel, 2026-10-12 19:39 UTC: "status update every 15 minutes at 15, 30, 45, and 00")
- Routines trig_019NZ6zdBPyFosjgF144dBeL (:13), trig_01TW8XXcXTUpeEynv9GZHjBv (:28) and trig_01R3937JHkQkWazdSZZtrhLH (:43) fire two minutes early (one routine per quarter: the service allows at most one firing per hour per routine).
- Each starts `scratchpad/status_at.sh` in the background; it waits until hh:15:00, hh:30:00 or hh:45:00 and prints the snapshot (files and journals only). The update is written from it: short, plain words, measured numbers, "nothing changed" said plainly.
- The hh:00 update is the hourly status update that follows the hourly push (the :58 routine), so it carries what was pushed or held.
- The update never delays the hourly check and push, which keeps utmost priority.

## Main repository: hourly, final edits only
- The main repository is Bruno's: https://github.com/Bruno-ios/Epinoic-Logic-Translator, branch `verified-updates`.
- Update it once every hour, and only with edits that are final under all of Daniel's commands. A final edit is a verified commit with one of the final titles in `publish_final.sh`. It must record a green suite (no failures or errors) and no harness drop. No replayed round may score lower than in the last published commit. It is never "WIP".
- Run `bash scratchpad/publish_final.sh`. It prints NOTHING, HOLD (with the reason) or pushed. The publisher sends one commit per final source. Its tree is exactly the verified tree plus the import documentation.
- Rules for Bruno's repository:
  - Never push anything else to it.
  - Never touch `import/translator-baseline`.
  - Never force-push or mirror-push.
  - If a push is refused, report it and do not try another way.
- Every update carries an update README (Daniel). The publisher writes `UPDATE_README.md` at the root of the published tree and keeps every note in `docs/updates/NNNN-<source>.md`. It also backfills a note for an earlier update that has none.
  - The note explains what the update changes (commits, files by area).
  - It records the bugs and failures found since the previous update: the overseer verdicts per lens, the top findings, and work-in-progress commits that failed verification.
  - It lists the fixes introduced and anything left undone, with the round results before and after.
  - It is generated by `scratchpad/update_notes.py` from git history and the overseer reports.
  - It is refused if it would contain a scratch path, session id or model name.
- Daniel's development branch (`claude/z3-verification-engine-plan-nk3luq` on origin) carries the working history. The hourly "Progress" section in tests/README.md goes there, staged alone.

## Speed-up of the STEM merge and round 8 (Daniel, 2026-10-12 ~18:50 UTC)
- Daniel: "speed up round 7 and attempt to finish it as soon as possible run all specialist agents at maximum capacity", then: "maximise effort towards stem round and merge operation".
- Round 7 had already finished at 08:52 UTC, so this applies to the next steps. Phase 2's STEM merge runs now, ahead of phase 2, at maximum effort, in the main checkout.
  - The merge is staged by an agent using phase 2's own merge prompt (`scratchpad/round8-prep/merge-prompt.txt`).
  - It is then verified independently with `simulate.sh translator <staged tree> 99e435b` (full suite, every recorded round at least at its recorded count) and a hygiene scan.
  - If that passes, it is committed as "Merge STEM support into the translator" with "Harness after the change:" and "Suite:" lines, and pushed to origin. Phase 2's merge step then sees it as already merged.
  - While MERGE_HEAD exists, the hourly Progress commit is skipped (as before).
- Round 8 (c1) is prepared in parallel. An agent at maximum effort designs `scratchpad/clearance/c1/tasks.json` with phase 2's own design prompt. Then all 16 specialists answer their standalone tasks at once, on the cheapest tier, with phase 2's own specialist prompts.
  - Peer-dependent tasks wait for phase 2, which relays them through the hub on the merged code.
  - `scratchpad/round8-prep/pre.json` records `{"c1": {"tasks": [...], "deployedKbs": [...]}}`. Launch phase 2 with `args: {pre: <that object>}`: phase2-pipeline.js then uses the prepared design and deploys only the specialists not yet answered.
- Phase 2 still starts only when the overseer build has finished. It then merges the overseer build, applies the round-7 handoffs, and runs round 8 from the prepared material.

## Phase 2 starts as soon as the STEM merge is committed (Daniel, 2026-10-12 ~19:20 UTC)
- Daniel: "resolve issue and push fixes as well as merge".
- The overseer round-3 commit (87eaf86) failed its simulation only on round 7: 139/143 functional, 3 false alarms, 235/254 faults named. Its translator base predates the round 5–7 fixes. Rounds 2–5 pass and 110/110 tamperings were detected.
- The resolution is the overseer merge into the current translator. So phase 2 is launched as soon as the STEM merge is committed, without waiting for the overseer build to finish. Phase 2's merge step then sees STEM as already merged and merges the overseer build as it stands.
  - It runs again before rounds 9 and 10 (`mergeBranch`, suffix `:before-cN`), so the overseer build's later contained-round fixes join while it keeps running.
- `simulate.sh` now also runs the overseer's contained run for any translator tree that carries the overseer package. The merged code is uploaded only if every gate passes on every recorded round, round 7 included; otherwise the failure is fixed first.

## Fully fledged prototype after round 8 and o1 (Daniel, 2026-10-12 ~19:15 UTC)
- Daniel: "push a fully fledged prototype repository into Bruno's main repo once round 8 testing and optimization testing and fixing is finished".
- Phase 2 commits "Prototype: integrated translator after round 8 and the first optimisation check" (docs/PROTOTYPE.md, written from measured results) right after round 8's fixes and check o1.
- The hourly publisher uploads it to `verified-updates`, with its simulation first, as with every final title.
- After that upload, run `bash scratchpad/release_prototype.sh`. It adds the new branch `prototype` and the annotated tag `prototype-round8` at that uploaded commit on Bruno's repository: ordinary pushes of new refs, never moving an existing ref. It does nothing until the upload exists. The hourly routine checks this every hour.

## Delivery rule: four-minute translation budget, overseer-selected fallback above 90% (Daniel, 2026-10-12 ~19:05 UTC)
- Daniel: "make sure the z3 logic code is able to perfectly translate and if not within the first minute it defaults to the overseer agent checking and selecting output with highest accuracy to be delivered", then: "edit the limit to be 4 minutes rather than one minute output with highest accuracy must be at least above 90%".
- `phase2-pipeline.js` builds this after the merges and the round-7 handoff fixes, before round 8: step `deliver:implement` at maximum effort, then a verified commit "Delivery: four-minute translation budget, overseer-selected fallback above 90% accuracy".
  - Formal path: within 240 s every material claim reaches a clean, definitive outcome → delivered as formally_checked.
  - Otherwise: the overseer agents check every candidate; accuracy is the validated share of material claims confirmed accurate. The best candidate is delivered as overseer_selected only if its accuracy is above 0.90; otherwise it is withheld with the reasons.
  - If the overseer deadline also runs out: withheld by default. A fallback answer is never labelled checked, and a claim is never changed to make it pass.
- Rounds 8–10 test it. The results-audit lens audits every delivery decision, and the arena harness reports the mode, time to decision, candidates and choice per task.
- Not promised: "perfect" translation cannot be guaranteed. The rounds measure translation fidelity (target 98%), and the fallback covers what the formal path does not finish in four minutes.

## Round 8 order and the mid-phase optimisation check (Daniel, 2026-10-12 ~19:00 UTC)
- Daniel: "run round 8 stem based answers and the humanities based answers simultaneously and run optimization check to reduce time for output generation through the z3 logic code infrastructure and passing the overseer agents. Do this task once round 8 is complete and continue onto round 9 to test for any bugs and apply fixes as soon as bugs are discovered".
- Round 8's sixteen specialists (STEM and humanities) answer all at once, before phase 2 reaches round 8 (see the speed-up section above). Rounds 9 and 10 may be prepared the same way (`args.pre.c2`, `args.pre.c3`) once the previous round's tasks exist, because a design must not reuse their topics.
- `phase2-pipeline.js` now runs ONE optimisation check (o1) right after round 8, before round 9.
  - Focus: the time an output takes through the Z3 logic code infrastructure (claim parsing, eligibility, the translator agents' IR, packs, STEM checks, formal checks and the engine, integrity, ledger, cross-agent consistency, the overseer hook and audit) and through the overseer agents (dossiers, pool, verdicts, validation). Correctness must not drop; receipts, findings and statuses stay identical.
  - Same rules as before: one fix, an A/B for any agent-configuration change, a verified commit "Fix the o1 optimization findings", otherwise reverted.
- Then rounds 9 and 10 always run: the early stop is removed, so all ten bug-testing rounds run. Each round's findings are fixed and verified straight after its reviewers report, before the next round starts.
- The remaining optimisation checks run at the end, at most three in total (o2, o3). The phase-2 simulator (`scratchpad/sim/p2.js`, `p2args.js` with `SIM_ARGS`) confirms the order: merges → round-7 handoffs → round 8 → o1 → round 9 → round 10 → multi-agent → o2/o3 → final.

## Hourly pushes, simulation and backups (Daniel, 2026-10-12 17:45 and 17:50 UTC)
- Daniel: "push updates every hour regardless of progress whilst creating a backup of the previous iteration. do not upload dysfunctional code always run a simulation to ensure functionality", then: "push update for now to show progress but create backup in repository not locally".
- `publish_final.sh` pushes to `verified-updates` every hour.
  - With a new final commit, it publishes that commit, as before.
  - Without one, it pushes an hourly update: the code is exactly the already-published verified code. Only `UPDATE_README.md` and a new `docs/updates/NNNN-hourly-<time>.md` change, written by `status_note.py`: the progress since the previous update (from the dev branch's Progress entries) and the simulation result.
  - It never pushes twice within 30 minutes.
- Before every push, `simulate.sh` runs on exactly the tree to upload. Nothing is pushed unless it passes; the result goes into the note and the commit message.
  - Translator: the full suite, then every recorded arena round replayed. No round may do worse than the counts recorded at the source commit.
  - Overseer: the recorded rounds, plus the contained run over every recorded round; every gate must pass.
- The backup of the previous iteration is kept in Bruno's repository, not locally: the replaced head goes to `backup/verified-updates-previous` (or `backup/overseer-prototype-previous`). It is created or moved forward by an ordinary push before the update is pushed. If that push is refused, nothing is pushed.
- Overseer prototype: its contained simulation fails on round 7 (139/143 functional, 3 false alarms, 235/254 faults named), because its translator base predates the round 5–7 fixes. No overseer code is uploaded until the full simulation passes; the phase-2 merge addresses this. Daniel was asked whether rounds 2–5 alone should be enough; until he answers, every round is required.

## Overseer prototype on the main repository (Daniel, 2026-10-12 15:40 UTC)
- Daniel: "the overseer build should also be uploaded to Bruno's main repository; upload the prototype now; any updates are uploaded at the same hourly interval, only when final and not work in progress".
- Branch `overseer-prototype` on Bruno's repository. The publisher is `bash scratchpad/publish_overseer.sh`; run it every hour, right after `publish_final.sh`, and report its output (NOTHING, HOLD with reason, STOP, or pushed).
- What it uploads: the newest final commit of the local branch `overseer-build`, as one commit.
  - Final means three things. The title is a verified build step (a review round, a contained round or the documentation commit), never WIP. Its message records a green suite, every tampering detected and no false alarm. The publisher's own re-run of the full suite on exactly that tree is green.
  - The tree is exactly the source commit's tree, plus `UPDATE_README.md` and `docs/overseer-updates/NNNN-<source>.md`. The note is written by `scratchpad/overseer_notes.py`: what changed, the bugs found, the fixes, the findings still open, and the verification.
  - The parent is the previous upload. For the first upload it is the build's fork point `ae7b1e6`, which is already in Bruno's history.
- It is a prototype: the overseer build started from the translator at `ae7b1e6`, so the arena fixes for rounds 5–7 are not on this branch. The overseer joins `verified-updates` through phase 2's verified merge, which also resolves the 9 files that conflict.
- The same rules as for `verified-updates`: ordinary pushes only; no other ref is touched; a refused push is reported and never retried another way.

## Order of work
1. **Bug testing and fixes come first.**
   - Arena rounds 4–7 in `arena-oversee-fix-loop.js`. Round 7 deploys all sixteen v4 specialists with the overseer agents attached.
   - The STEM build and the arena run as ONE integrated system. The STEM build finishes its implementation and corpus evaluation. The arena merges it before round 7's harness, adding a STEM lens and a STEM fixer. If STEM is not ready by then, it joins in round 8, which phase 2 merges first. The STEM build's own review rounds and separate STEM arena are not run.
   - The overseer build: exportable code and knowledge pack, consolidation of duplicated answers, repeated-fault suppression, a self-duplicating overseer pool.
   - Phase 2, in this order:
     - merge both builds;
     - apply the round-7 handoffs;
     - arena rounds 8–10 as integrated rounds c1–c3 over all sixteen v4 specialists;
     - scaling, with the multi-agent scalability test;
     - the multi-agent test with all sixteen v4 agents on one task.
2. **Optimisation checks come LAST,** after every bug-testing round.
   - At most three, run on the strongest tier.
   - Goal: fast, efficient responses from every agent (specialists, translator agents, combinator, overseers).
   - One verified fix per check. Agent-configuration changes are A/B-tested.
   - The stand-alone pass `optimization-once.js` was stopped and replaced; never run it.
3. **Final report.** Phase 2 also writes `docs/FINAL_COMPARISON.md`: the final product against the code already on the main repository (its default branch `import/translator-baseline` and `verified-updates`). It also writes `scratchpad/release-readiness.json`, which says whether every bug fix is implemented.
4. **Final release, once every assigned task has finished.** Run `bash scratchpad/release_final.sh` (try `--dry-run` first).
   - It refuses (HOLD) unless every bug fix is implemented and the newest commit is the final report.
   - Backup of the previous edit: a local bundle of the main repository's refs, plus a new branch `backup/verified-updates-before-final` at the current `verified-updates` head.
   - Upload: the final version, labelled "Final version: …", goes to `verified-updates`. Then a new branch `final` and an annotated tag `final-v1.0` are added at that commit.
   - Ordinary pushes only. Existing refs are never moved.
   - The hourly publisher never publishes the final report itself; that is reserved for the release.
   - If the release HOLDs, report the open items to Daniel.

## Daniel's development branch during merges
- Skip the hourly Progress commit while a merge is in progress (`.git/MERGE_HEAD` exists), and do it the next hour.

## Overseer agents in rounds 8–10 (founder)
- The deployed logic-checking overseer agents run on Haiku 5.5 (the session's cheapest `haiku` tier) under the self-duplication protocol.
- A first wave of instances is planned by the package's self-duplicating pool. The pool then reads the validated verdicts. For repeated faults, conflicting or rejected verdicts and duplicated answers, it spawns duplicate Haiku instances to re-review those dossiers: at most two more waves, within the pool's maximum.
- The duplicated verdicts are consolidated by the package, validated exactly as in production, and scored against gold that the agents never see.
- The Opus lenses still do the checking and also judge the overseer agents, as Daniel set earlier ("have opus do the actual checks").

## Limits and tiers
- At most 10 bug-testing arena rounds in total: r1–r7, then rounds 8–10 = c1–c3.
- No stress tests after bug fixes, and no stress testing of any model. The only load testing allowed is multi-agent scalability testing.
- Deployed agents run on the cheapest tier: specialists, translator stand-ins, combinator, overseer agents.
- Checking runs on the strongest tier: overseer lenses, fixers, optimisation checks.
- Specialists run on the v4 knowledge bases, full-context bundles: `scratchpad/kb-v4/ib-specialist-knowledge-bases-v4/_bundles/`.
- Do not raise any spending limit.

## Safety (repository CLAUDE.md)
- The IR is data. Never eval/exec model output.
- Consistency before entailment. Non-success statuses are never shown as success.
- Results prove properties of the encoding only.
- Agent self-reports are advisory. Only signed engine results are trusted.
- Never weaken or delete tests. Never claim deployment or live provider integration without evidence.
- No code or prompt text copied from NL2FOL.
- No model names or session ids in repository code or docs.

## Hourly status update to Daniel (requested 04:30 UTC, every hour from then on)
At every hourly check, after deciding whether to update the main repository, reply to Daniel with a short status update in this order:
1. **Main repository decision:** published (with the update note's headline and source commit), nothing new, held, or stopped, and why.
2. **Arena:** the current round and stage. Rounds finished, with overseer rates per lens (translation accuracy included), harness counts and suite result. Whether STEM joined.
3. **STEM build, overseer build, phase 2:** the current stage of each; what finished since the last update; any failure, restart or limit.
4. **Bugs and fixes:** the number and severity of findings and fixes since the last update.
5. **Next:** what runs next and anything that needs Daniel's decision.

Measured facts only. Use plain English, no model names in repository files. Say plainly when something is stuck or failed.

## Five-minute status updates, 05:00–06:00 UTC on 2026-10-12 (COMPLETED: all 13 updates were given) (Daniel: "starting at 12:00 for the next hour")
- Daniel's 12:00 is taken as 05:00 UTC (he appears to be on UTC+7). One update every 5 minutes, 13 in all: 05:00, 05:05, … 06:00.
- A background timer wakes the session at each mark, and the next timer is armed at each update.
- Each update reports:
  - the watchdog result;
  - `python3 -I scratchpad/status.py`: what finished, what is in flight, round-7 files, new commits;
  - the main-repository readiness check, `bash scratchpad/publish_final.sh --dry-run`, which shows whether anything final is ready to upload.
- Publishing itself stays hourly, at the hourly check.
- After 06:00 UTC, return to the standing routine: the watchdog every 5 minutes, waking only on alerts, and the hourly status update with the readiness check and the publish.

## Five-minute watchdog (Daniel, 04:40 UTC: no token consumption without progress)
- `scratchpad/watchdog.py` runs every 5 minutes in a background loop. It reads only the journals and transcripts, so it costs no model tokens. It wakes the session only on a new anomaly:
  - **STALL:** agents in flight, but no transcript written for 10 minutes.
  - **LOOP:** the same tool call repeated 5 times in a row.
  - **LONG:** an agent past its limit (30 min for cheapest-tier deployed agents, 100 min for checking agents).
  - **ENDED:** no agent in flight and the journal unchanged for 12 minutes.
- **On a STALL or ENDED that is not a known finish:** back up the worktree's uncommitted work and resume the workflow from its cache.
- **On a LOOP or LONG:** read the agent's transcript. If it is spinning, stop the workflow and resume it, so only that step restarts.
- It runs as a Monitor (each alert line is a notification). A Monitor expires after 30 minutes: re-arm it on each expiry notice and check at every hourly run that it is armed. The original background loop stopped at its 2-hour limit at 06:42 UTC.

## Bookkeeping
- Current workflow run ids: `scratchpad/runs.json`. A resume returns a new id; record it.
- Back up `stem-build` and `overseer-build` (bundles and commit lists) hourly.
- Report to Daniel in a few lines each hour.

## Checkpoint for Friday (Daniel, 23:4x UTC 2026-10-12)
"get to the nearest progress point where the project can be picked back up in this conversation by you later this week without any deficiencies, and upload the current finished work to Bruno's repository."
- Not a halt: the in-flight units (review-fix integration wf_b526acb3-6c2, overseer rebuild wf_92057cdf-3e2) were resumed and run to their end; finished, simulated work is uploaded through the normal gates; nothing new (phase 2, STEM accommodation, STEM-review integration) starts before Friday.
- Durable backup: the container is ephemeral, so the checkpoint (git bundle of local branches, scratchpad without venvs, workflow journals, pipeline script, RESUME.md) is committed to the dev branch and removed in the next commit (both pushed together; Bruno's uploads are tree exports, so it never reaches his repository). A local copy is kept too.
- Daniel approved (23:5x UTC): the durable checkpoint goes to a NEW branch `checkpoint/2026-10-12` on origin (his dev repo), purely additive; the dev branch and Bruno's repository are untouched. Refreshes fast-forward that branch (no force). The earlier dev-branch add-then-remove method was refused by the permission check and is not used.
- 00:1x UTC 2026-10-13, Daniel: "wrap up the current work and complete the savings and not continue the project ... complete to a safe checkpoint but not go beyond it ... because tokens are limited." Both in-flight workflows stopped and saved as work in progress; routines, loops and watchdog paused; nothing further runs until Daniel resumes (Friday). Resume order: RESUME.md section 3.

## Resumed (Friday 2026-10-16 16:50 UTC; Daniel: "continue with the work which I told you about")
- Container survived: no restore needed; both work-in-progress states verified unchanged against the checkpoint.
- Resumed: review-fixes wf_b526acb3-6c2 (integrate, then verify) and overseer-rebuild wf_92057cdf-3e2 (rebuild:merge, then audit, eval, commit). Presim/event-push loop, watchdog and the four routines re-enabled.
- BLOCKER: git access to Bruno-ios/Epinoic-Logic-Translator returns 403 (read and push) although the repository is attached to the session; Daniel's own repository works. Until Daniel reconnects GitHub (claude.ai/connect-github) or the Claude GitHub App is installed on Bruno's repository, every upload to it is HELD and reported once per hourly update; never retried another way. Work that does not need Bruno's repository continues; finished code goes to the dev branch and the checkpoint branch.
- 18:5x UTC 2026-10-16: background commands are capped at 2 hours, and the presim/event-push loop (already at the longest timeout) was stopped at that cap; it is not restarted as a loop. Instead presim.sh then event_push.sh run once, on demand, right after each new final commit (review fixes, overseer rebuild) and before an hourly push that has new code. The watchdog loop ends at the same cap; workflow completions arrive as notifications regardless.
- 19:2x UTC 2026-10-16: the overseer rebuild's repair was re-tested NOT clean (2 high: label-only trust for task_setting and the pack steering agents away from it; 2 medium: circular premise hidden by conjoining a verified fact, and an adjudicated "genuine fault" that is really a correct transcription; 1 low: pack I85 vs consolidation code). Nothing committed. One SECOND AND LAST repair round added to wf-scripts/overseer-rebuild.js (same run wf_92057cdf-3e2, earlier agents cached), re-tested once. If still not clean: stop, keep the merge staged, report to Daniel for a decision; no further rounds without him.
- 19:3x UTC 2026-10-16: the review fixes were re-verified NOT clean (9/11; finding 2: a numerals-in-task check confers authority on an invented relation; finding 6: 7 of 32 non-asserting phrasings still give E110). Nothing committed. One SECOND AND LAST repair round added to wf-scripts/external-review-fixes.js (same run wf_b526acb3-6c2), verified once; if still not clean, stop and report to Daniel.

## Recovery task (Daniel, 16 Oct 19:3x UTC): canonical repository Epinoic-AI/Epinoic-Logic-Translator
- Scope: preservation and upload only. No new development, no merge, no deployment, no paid calls, no website change. The two second-repair runs were stopped and the four routines paused for it.
- This session cannot attach the canonical repository (same-named bruno-ios attachment; checkout-layout limit). A new session with Epinoic-AI/Epinoic-Logic-Translator (branch verified-updates) and the NL2FOL repository as sources does the upload: RESUME.md section 0.
- Preservation snapshot branches prepared locally under refs/heads/preserve/2026-10-16/* (parent a91a4f9; never move verified-updates).
