import json, glob, os, re, collections, time
MAIN='/root/.claude/projects/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6.jsonl'
WF='/root/.claude/projects/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/subagents/workflows'
NAMES={'wf_a9b74a4b-4b3':'overseer build','wf_bf7c4c9f-7bc':'arena','wf_025e2061-cf2':'stem','wf_a6994f9a-169':'upload review 1','wf_c16238d2-291':'upload review 2','wf_88904725-4cd':'upload review 3','wf_20ae0d9e-d45':'status workflow'}
# 1. ultracode reminders
print("== ultracode mentions in the main transcript")
seen=set()
for line in open(MAIN, errors='replace'):
    if 'ltracode' not in line: continue
    try: r=json.loads(line)
    except: continue
    ts=r.get('timestamp','?')
    s=json.dumps(r.get('message',{}))
    for m in re.finditer(r'(Ultracode is[^.\\]{0,60}|ultracode[^.\\]{0,80}(on|off|opt)[^.\\]{0,40})', s):
        key=(ts[:16], m.group(0)[:70])
        if key in seen: continue
        seen.add(key); print(ts[:19], r.get('type'), '|', m.group(0)[:110])
# 2. tokens per workflow per hour
def usage_rows(path):
    ids=set()
    for line in open(path, errors='replace'):
        try: r=json.loads(line)
        except: continue
        m=r.get('message') or {}
        if not isinstance(m,dict) or r.get('type')!='assistant': continue
        u=m.get('usage'); mid=m.get('id')
        if not u or (mid and mid in ids): continue
        if mid: ids.add(mid)
        yield r.get('timestamp',''), u
tok=collections.defaultdict(lambda:[0,0])
for d in glob.glob(WF+'/wf_*'):
    wid=os.path.basename(d)
    if os.path.getmtime(d) < time.time()-14*3600 and wid not in NAMES: continue
    for f in glob.glob(d+'/agent-*.jsonl'):
        for ts,u in usage_rows(f):
            if not ts.startswith('2026-10-12'): continue
            h=ts[11:13]
            if h < '10': continue
            k=(NAMES.get(wid,wid),h)
            tok[k][0]+=u.get('output_tokens',0)
            tok[k][1]+=u.get('input_tokens',0)+u.get('cache_creation_input_tokens',0)+u.get('cache_read_input_tokens',0)
for ts,u in usage_rows(MAIN):
    if ts.startswith('2026-10-12') and ts[11:13]>='10':
        k=('main session',ts[11:13]); tok[k][0]+=u.get('output_tokens',0); tok[k][1]+=u.get('input_tokens',0)+u.get('cache_creation_input_tokens',0)+u.get('cache_read_input_tokens',0)
print("== output tokens (thousands) by hour UTC; input incl. cache reads in brackets (millions)")
hours=sorted({h for _,h in tok})
names=sorted({n for n,_ in tok})
print('hour'.ljust(18)+' '.join(h.rjust(13) for h in hours))
for n in names:
    print(n.ljust(18)+' '.join((f"{tok[(n,h)][0]/1e3:.0f}k[{tok[(n,h)][1]/1e6:.1f}M]" if (n,h) in tok else '-').rjust(13) for h in hours))
# 3. weekly limit first seen
print("== weekly limit")
hits=[]
for f in glob.glob(WF+'/wf_*/agent-*.jsonl')+[MAIN]:
    if os.path.getmtime(f) < time.time()-12*3600: continue
    for line in open(f, errors='replace'):
        if 'weekly limit' in line:
            try: r=json.loads(line)
            except: continue
            hits.append((r.get('timestamp',''), os.path.basename(os.path.dirname(f)) if f!=MAIN else 'main', os.path.basename(f)))
hits.sort()
for h in hits[:4]: print(h)
print("total records mentioning it:", len(hits))
# 4. overseer steps after 14:00
print("== overseer build steps from 14:00 UTC")
d=WF+'/wf_a9b74a4b-4b3'
lab={}
for line in open(d+'/journal.jsonl'):
    try: e=json.loads(line)
    except: continue
    if e.get('type')=='started': lab.setdefault(e['agentId'], e.get('label'))
rows=[]
for f in glob.glob(d+'/agent-*.jsonl'):
    a=os.path.basename(f)[6:-6]
    ts=[]
    for line in open(f, errors='replace'):
        try: ts.append(json.loads(line).get('timestamp',''))
        except: pass
    ts=[t for t in ts if t]
    if ts and max(ts)>='2026-10-12T14:00':
        rows.append((min(ts)[11:16], max(ts)[11:16], lab.get(a,'?'), a[:8]))
for r in sorted(rows): print(r)
