#!/usr/bin/env bash
# Publish the latest FINAL translator fixes to Bruno-ios/Epinoic-Logic-Translator, branch verified-updates.
#
# A commit on Daniel's development branch is final when:
#   1. it is a verified commit: an arena fix round ("Fix the rN arena overseer findings"), a stress fix,
#      "Arena results: ...", a verified merge of the STEM or overseer build, a clearance fix round
#      ("Fix the cN clearance findings"; arena rounds 8-10), the round-7 handoff fixes ("Fix the r7 handoff findings"),
#      the scaling commit, a multi-agent fix round, an optimisation check ("Fix the oN optimization findings") or the final report
#      (the builds give these titles only when the suite is green; anything else is titled "WIP: ..."), and
#   2. no replayed round's functional count in its "Harness after the change" line is lower than in the
#      last final commit already published, and its message records a green suite (no failures or errors)
#      and no harness drop.
# The published commit's tree is exactly the final commit's tree, plus the import's documentation
# (docs/baseline-evidence/ and, unless the final commit changed them, the import's versions of
# docs/BASELINE_REVIEW.md and docs/integration-contract.md). No work-in-progress history is published.
# Hourly (Daniel, 2026-10-12 17:45 UTC: "push updates every hour regardless of progress whilst creating a backup of the
# previous iteration; do not upload dysfunctional code; always run a simulation"): when no new final commit exists, an
# hourly update is still pushed whose code is exactly the already-published verified code, with a status note
# (status_note.py: the progress since the previous update and the simulation). Before EVERY push, simulate.sh runs the
# full suite and replays every recorded arena round on exactly the tree to upload (nothing is pushed unless it passes),
# and the replaced head is kept in Bruno's repository itself as backup/verified-updates-previous (an ordinary,
# fast-forward push; Daniel: "create backup in repository not locally").
# Usage: publish_final.sh [--dry-run]
set -euo pipefail
# Report an unexpected failure only where errexit is on (set +e sections test exit codes on purpose).
trap '[[ $- == *e* ]] && echo "STOP: unexpected failure at line $LINENO of publish_final.sh"' ERR
R=/home/user/https-github.com-lovishchopra-NL2FOL
DEV=claude/z3-verification-engine-plan-nk3luq
BASELINE=3147d08e0aa63d5eeaceb1072754f29e3862164d
DOCS_BASE=eee4d369913409b97bb8a1c36feb244041df0e13
IMPORT_HEAD=650d1d36c63e19768d41ca509d86c41e55035373
BR=verified-updates
DRY=${1:-}
# The final release (release_final.sh) sets PUBLISH_LABEL="Final version"; only it publishes the final report commit.
LABEL=${PUBLISH_LABEL:-Verified update}
S=$(cd "$(dirname "$0")" && pwd)
cd "$R"

FINAL=$(git log --format='%H%x09%s' "$BASELINE..$DEV" | awk -F'\t' -v rel="$([ "$LABEL" = "Final version" ] && echo 1 || echo 0)" '!found && ($2 ~ /^Fix the r[0-9]+ arena overseer findings$/ || $2 == "Fix defects found by the contained stress runs" || $2 ~ /^Arena results: / || $2 == "Merge STEM support into the translator" || $2 == "Merge the logic-checking overseer agents into the translator" || $2 ~ /^Fix the c[0-9]+ clearance findings$/ || $2 == "Scaling: any number of agents per task" || $2 ~ /^Fix the m[0-9]+ multi-agent (optimisation )?findings$/ || $2 ~ /^Fix the r[0-9]+ handoff findings$/ || $2 ~ /^Fix the o[0-9]+ optimization findings$/ || ($2 ~ /^Final report: / && rel) || $2 == "Fix the optimization findings" || $2 == "Fix the external review findings" || $2 == "Fix the end-to-end simulation findings" || $2 ~ /^Argument diagnostics: / || $2 ~ /^Integration: / || $2 ~ /^Delivery: / || $2 ~ /^Prototype: /) {print $1; found=1}')
if [ "$DRY" = "--dry-run" ] && [ -n "${PUBLISH_TEST_FINAL:-}" ]; then FINAL=$PUBLISH_TEST_FINAL; fi
if [ -z "$FINAL" ]; then echo "NOTHING: no verified commit after the baseline yet"; exit 0; fi

git fetch -q epinoic "+refs/heads/$BR:refs/remotes/epinoic/$BR" 2>/dev/null || true
PARENT=$(git rev-parse -q --verify "refs/remotes/epinoic/$BR" || echo "$IMPORT_HEAD")
if [ "$DRY" = "--dry-run" ] && [ -n "${PUBLISH_TEST_PARENT:-}" ]; then PARENT=$PUBLISH_TEST_PARENT; fi
# Founder (2026-10-12 22:0x): after round 8's fixes the update goes out at once UNLESS critical fixes have not been applied
# or a section may be critically infected. Every integrated round's fix commit between the published source and FINAL
# therefore needs a push check (push-check/<sha>.json, written by an independent agent after the round) with hold=false;
# if one is missing or holds, no new code is published (the published code stays; the hourly note says why).
PUB_SRC=$(git log -1 --format=%B "$PARENT" 2>/dev/null | sed -n 's/^Source-Commit: //p' | tail -1)
if [ -n "$PUB_SRC" ] && [ "$FINAL" != "$PUB_SRC" ] && git merge-base --is-ancestor "$PUB_SRC" "$FINAL" 2>/dev/null; then
  HELD=""
  for RC in $(git log --format='%H%x09%s' "$PUB_SRC..$FINAL" | awk -F'\t' '$2 ~ /^Fix the c[0-9]+ clearance findings$/ {print $1}'); do
    WHY=$(python3 -I -c "import json, sys
try:
    d = json.load(open(sys.argv[1]))
except Exception:
    print('no push check yet'); sys.exit()
ok = d.get('hold') is False and str(d.get('sha', '')).startswith(sys.argv[2][:12])
print('' if ok else 'held: ' + '; '.join(str(r) for r in (d.get('reasons') or ['hold is not false']))[:300])" "$S/push-check/$RC.json" "$RC")
    [ -n "$WHY" ] && HELD="$HELD; $(git log -1 --format='%h %s' "$RC"): $WHY"
  done
  if [ -n "$HELD" ]; then echo "HOLD (no new code published)${HELD}"; FINAL=$PUB_SRC; fi
fi
MODE=code
# (grep -c reads all its input: "| grep -q" under pipefail can fail when the writer is cut off early)
if [ -z "${PUBLISH_TEST_FINAL:-}" ] && [ "$(git log --format=%B "$IMPORT_HEAD..$PARENT" | grep -c "^Source-Commit: $FINAL$")" -gt 0 ]; then
  # No new final code. The final release (label "Final version") never makes a status update.
  if [ "$LABEL" = "Final version" ] || [ -n "${PUBLISH_NO_STATUS:-}" ]; then echo "NOTHING: $FINAL already published"; exit 0; fi
  LAST=$(git log -1 --format=%ct "$PARENT"); if [ $(( $(date +%s) - LAST )) -lt 1200 ]; then echo "NOTHING: the last update was pushed less than 20 minutes ago (pushes run every 30 minutes)"; exit 0; fi
  MODE=status
fi

harness() { git log -1 --format=%B "$1" | sed -n 's/^.*Harness after the change: //p' | sed -n 1p || true; }
PREV_SRC=$(git log -1 --format=%B "$PARENT" | sed -n 's/^Source-Commit: //p' || true)
PREV_SRC=${PREV_SRC:-$BASELINE}
NEW_H=$(harness "$FINAL"); OLD_H=$(harness "$PREV_SRC")
if [ "$MODE" = code ]; then
python3 - "$OLD_H" "$NEW_H" "$(git log -1 --format=%B "$FINAL")" <<'EOF'
import re, sys
def parse(s): return {m.group(1): int(m.group(2)) for m in re.finditer(r'\b([rcm]\d+(?:-[a-z]+)?)\s+(\d+)/(\d+)', s or '')}
old, new = parse(sys.argv[1]), parse(sys.argv[2])
if not new: sys.exit("HOLD: the final candidate records no harness counts")
drops = [f"{k} {old[k]}->{new[k]}" for k in old if k in new and new[k] < old[k]]
if drops: sys.exit("HOLD: harness counts dropped: " + ", ".join(drops))
# Final only: the candidate must record a green suite and no harness drop (Daniel: publish only edits that are final).
msg = sys.argv[3]
suite = re.search(r"Suite: ([^\n]*)", msg)
if not suite or "passed" not in suite.group(1) or re.search(r"\b(failed|errors?)\b", suite.group(1)): sys.exit("HOLD: the final candidate does not record a green suite: " + (suite.group(1) if suite else "no suite line"))
if "Harness drop:" in msg or msg.startswith("WIP"): sys.exit("HOLD: the final candidate records a harness drop or is work in progress")
print("harness gate passed:", sys.argv[2])
EOF
fi

TMPIDX=$(mktemp); trap 'rm -f "$TMPIDX"' EXIT
NOTES=$(mktemp -d); trap 'rm -f "$TMPIDX"; rm -rf "$NOTES"' EXIT
STAMP=$(date -u +%Y%m%d-%H%M)
# Earlier notes are carried forward; a working-area placeholder in one is rewritten (it says nothing to a reader).
scrub_carried() {
  for P in $(GIT_INDEX_FILE=$TMPIDX git ls-files docs/updates); do
    B=$(GIT_INDEX_FILE=$TMPIDX git rev-parse ":$P")
    if [ "$(git cat-file -p "$B" | grep -c '<scratch')" -gt 0 ]; then
      NB=$(git cat-file -p "$B" | python3 -I "$S/scrub_note.py" | git hash-object -w --stdin)
      GIT_INDEX_FILE=$TMPIDX git update-index --add --cacheinfo "100644,$NB,$P"
    fi
  done
}
if [ "$MODE" = status ]; then
  # Same code as the current head; only the update notes change.
  GIT_INDEX_FILE=$TMPIDX git read-tree "$PARENT"
  scrub_carried
  NUM=$(( $(git log --format=%B "$IMPORT_HEAD..$PARENT" | grep -c '^Source-Commit: ' || true) + 1 ))
  NEWNOTE="docs/updates/$(printf '%04d' "$NUM")-hourly-$STAMP.md"
  EARLIER=$(GIT_INDEX_FILE=$TMPIDX git ls-files docs/updates | sort -r)
  SRC_UPDATE=$(git log --reverse --format='%H' "$IMPORT_HEAD..$PARENT" | while read -r c; do n=$((${n:-0}+1)); [ "$(git log -1 --format=%B "$c" | grep -c "^Source-Commit: $PREV_SRC$")" -gt 0 ] && { echo $n; break; }; done)
  # Simulation first: the note reports it, and nothing is pushed unless it passes.
  # A simulation prepared before the hour (simcache, keyed by the source commit, whose code the tree carries exactly) is used
  # when present, so the hourly check and push take seconds (Daniel: at most 2 min 30 s); otherwise it runs here.
  if grep -qs '^SIMULATION OK' "$S/simcache/translator-$PREV_SRC.txt"; then grep -v '^[0-9][0-9]:' "$S/simcache/translator-$PREV_SRC.txt" > "$NOTES/sim.txt"; echo "(simulation prepared before the hour)"
  else bash "$S/simulate.sh" translator "$(git rev-parse "$PARENT^{tree}")" "$PREV_SRC" > "$NOTES/sim.txt" 2>&1 || { cat "$NOTES/sim.txt"; echo "HOLD: the simulation failed; nothing pushed"; exit 1; }; fi
  cat "$NOTES/sim.txt"
  python3 -I "$S/status_note.py" --repo "$R" --dev "$DEV" --since "$(TZ=UTC git log -1 --date=format-local:'%Y-%m-%dT%H:%M' --format=%cd "$PARENT")" --source "$PREV_SRC" --source-update "$SRC_UPDATE" --number "$NUM" --sim "$NOTES/sim.txt" --out "$NOTES/new.md" --index $EARLIER
  FINAL=$PREV_SRC
else
GIT_INDEX_FILE=$TMPIDX git read-tree "$FINAL"
for p in docs/BASELINE_REVIEW.md docs/integration-contract.md; do
  if git diff --quiet "$DOCS_BASE" "$FINAL" -- "$p"; then
    GIT_INDEX_FILE=$TMPIDX git update-index --add --cacheinfo "100644,$(git rev-parse "$IMPORT_HEAD:$p"),$p"
  fi
done
git ls-tree -r "$IMPORT_HEAD" docs/baseline-evidence | GIT_INDEX_FILE=$TMPIDX git update-index --index-info
# Update notes (Daniel): every update carries UPDATE_README.md (what it changes, the bugs and failures found since the previous
# update, the fixes introduced); every earlier note stays under docs/updates/.
NUM=$(( $(git log --format=%B "$IMPORT_HEAD..$PARENT" | grep -c '^Source-Commit: ' || true) + 1 ))
if [ "$PARENT" != "$IMPORT_HEAD" ]; then
  git ls-tree -r "$PARENT" docs/updates | GIT_INDEX_FILE=$TMPIDX git update-index --index-info
  scrub_carried
  if [ -z "$(git ls-tree -r --name-only "$PARENT" docs/updates)" ]; then
    PP_SRC=$(git log -1 --format=%B "$PARENT^" 2>/dev/null | sed -n 's/^Source-Commit: //p' || true); PP_SRC=${PP_SRC:-$BASELINE}
    python3 -I "$S/update_notes.py" --repo "$R" --from "$PP_SRC" --to "$PREV_SRC" --number $((NUM - 1)) --label "$(git log -1 --format=%s "$PARENT" | sed 's/: .*//')" --published "$(TZ=UTC git log -1 --date=format-local:'%Y-%m-%d %H:%M UTC' --format=%cd "$PARENT")" --scratch "$S" --out "$NOTES/backfill.md"
    GIT_INDEX_FILE=$TMPIDX git update-index --add --cacheinfo "100644,$(git hash-object -w "$NOTES/backfill.md"),docs/updates/$(printf '%04d' $((NUM - 1)))-${PREV_SRC:0:7}.md"
  fi
fi
NEWNOTE="docs/updates/$(printf '%04d' "$NUM")-${FINAL:0:7}.md"
EARLIER=$(GIT_INDEX_FILE=$TMPIDX git ls-files docs/updates | sort -r)
python3 -I "$S/update_notes.py" --repo "$R" --from "$PREV_SRC" --to "$FINAL" --number "$NUM" --label "$LABEL" --scratch "$S" --out "$NOTES/new.md" --index $EARLIER
fi
if grep -qE 'a7c3c8b5|/tmp/claude-0|/root/\.claude|session_0[0-9A-Za-z]|\b(Opus|Haiku|Sonnet)\b|[Cc]laude (cheapest|strongest)-tier|(cheapest|strongest)-tier model [0-9]' "$NOTES"/*.md; then echo "STOP: an update note contains a scratch path, session id or model name"; exit 1; fi
NOTEBLOB=$(git hash-object -w "$NOTES/new.md")
GIT_INDEX_FILE=$TMPIDX git update-index --add --cacheinfo "100644,$NOTEBLOB,$NEWNOTE"
GIT_INDEX_FILE=$TMPIDX git update-index --add --cacheinfo "100644,$NOTEBLOB,UPDATE_README.md"
TREE=$(GIT_INDEX_FILE=$TMPIDX git write-tree)
# Content backstop: nothing published may carry a scratch path, a session id or a model name.
HITS=$(git grep -nIE 'a7c3c8b5|/tmp/claude-0|/root/\.claude|session_01[0-9A-Za-z]|<scratch|scratchpad/|claude-(opus|haiku|sonnet)|\b(Claude )?(Opus|Haiku|Sonnet) [0-9]\.[0-9]' "$TREE" -- . 2>/dev/null | head -5 || true)
if [ -n "$HITS" ]; then echo "STOP: the tree to publish contains a scratch path, session id or model name: $HITS"; exit 1; fi
EXTRA=$(git diff --name-only "$FINAL" "$TREE" | grep -v -E '^(docs/baseline-evidence/|docs/BASELINE_REVIEW\.md$|docs/integration-contract\.md$|UPDATE_README\.md$|docs/updates/)' || true)
if [ -n "$EXTRA" ]; then echo "STOP: tree differs from the final commit outside the import documentation: $EXTRA"; exit 1; fi
if [ "$MODE" = status ]; then
  CODECHG=$(git diff --name-only "$PARENT" "$TREE" | grep -v -E '^(UPDATE_README\.md$|docs/updates/)' || true)
  [ -z "$CODECHG" ] || { echo "STOP: an hourly update would change more than the notes: $CODECHG"; exit 1; }
else
  # Simulation of exactly the tree to upload; nothing is pushed unless it passes.
  SRC_RC=0
  if grep -qs '^SIMULATION OK' "$S/simcache/translator-$FINAL.txt"; then grep -v '^[0-9][0-9]:' "$S/simcache/translator-$FINAL.txt" > "$NOTES/sim.txt"; echo "(simulation prepared before the hour)"
  else bash "$S/simulate.sh" translator "$TREE" "$FINAL" > "$NOTES/sim.txt" 2>&1 || SRC_RC=$?; fi
  cat "$NOTES/sim.txt"
  [ $SRC_RC -eq 0 ] || { echo "HOLD: the simulation failed; nothing pushed"; exit 1; }
fi

SUBJ=$(git log -1 --format=%s "$FINAL")
MSGF=$(mktemp)
SIMLINE=$(grep '^SIMULATION ' "$NOTES/sim.txt" | tail -1)
if [ "$MODE" = status ]; then
cat > "$MSGF" <<EOF
Hourly update: $(date -u '+%Y-%m-%d %H:%M UTC'), no new final code

The code is unchanged: exactly the code verified in source commit
$FINAL ($SUBJ).
This update carries the hourly progress and a fresh simulation of that code
(full suite and every recorded arena round): $SIMLINE
The previous head is kept as backup/verified-updates-previous.
Progress, simulation and earlier notes: UPDATE_README.md and docs/updates/.

Source-Commit: $FINAL

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_016YotQwcC83EEJm8zshdxtW
EOF
else
cat > "$MSGF" <<EOF
$LABEL: $SUBJ

Publishes the translator code exactly as verified in source commit $FINAL on
Daniel's development branch (full suite green; harness replay counts not lower
than the previous published update), with the import's documentation kept.
Harness at the source commit: $NEW_H
Work-in-progress commits are not published.
What this update changes, the bugs and failures found since the previous update
and the fixes introduced: UPDATE_README.md (every note is kept in docs/updates/).

Simulation of this tree before upload: $SIMLINE
The previous head is kept as backup/verified-updates-previous.

Source-Commit: $FINAL

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_016YotQwcC83EEJm8zshdxtW
EOF
fi
NEW=$(git -c user.name=Claude -c user.email=noreply@anthropic.com commit-tree "$TREE" -p "$PARENT" -F "$MSGF"); rm -f "$MSGF"
echo "prepared $NEW (parent $PARENT, tree $TREE, source $FINAL)"
if [ "$DRY" = "--dry-run" ]; then git ls-tree -r --name-only "$TREE" -- UPDATE_README.md docs/updates; cp "$NOTES/new.md" "$S/last-update-note.md"; echo "DRY RUN: not pushed (note copied to $S/last-update-note.md)"; exit 0; fi
# Backup of the previous iteration, kept in the repository itself (Daniel: "create backup in repository not locally"):
# the replaced head as backup/<branch>-previous (created, or moved forward: an ordinary push; a refusal stops here).
timeout 120 git push epinoic "$PARENT:refs/heads/backup/$BR-previous" || { echo "STOP: could not back up the previous head as backup/$BR-previous; nothing pushed"; exit 1; }
timeout 300 git push epinoic "$NEW:refs/heads/$BR"
timeout 120 git ls-remote epinoic "refs/heads/$BR" "refs/heads/backup/$BR-previous"
