import json
import os

SRC = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2/tasks.json"
OUT_DIR = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2/revisions"

with open(SRC, encoding="utf-8") as f:
    tasks = json.load(f)

task = next(t for t in tasks if t["task_id"] == "ps-t15")

response_text = """I can't write your research question, your introduction or your ethical safeguards section, or any other part of the proposal, because it must be your own work. I can help you build each of them through questions, and I will give feedback on your own drafts.

Start with the task. The proposal is designed but never carried out, it is weighted at 20% at HL, and it takes about 20 hours. The criteria most often reported for it are A Introduction, B Research methodology, C Data collection and D Discussion, each marked out of 6, within 2,200 words. Treat these as provisional and check them with your teacher, whose version is the one that counts.

Your topic is allowed: it sits within psychology, it can be linked to existing research, and an experiment with 16- to 18-year-olds can be planned within ethical limits. Your population needs to be narrower first.

A. Introduction (where your research question goes, as your aim)
- Which students exactly: which countries or schools, and what reading do they do in a typical week?
- Why does this problem matter to them in particular?
- Which two published studies will you build on, and what exactly did each find? Ask your teacher or school librarian to help you locate them.
- Can you state your independent variable, dependent variable and population in one sentence? If that sentence is hard to write, that is your first task.

B. Research methodology (where your ethical safeguards go, each tied to a specific risk)
- Why an experiment rather than a survey or interview for this aim? What can an experiment show that the others cannot?
- Independent measures or repeated measures? What does each cost you in participant differences or order effects, and how would you handle that cost?
- How will you recruit students? What kind of sample does that create, and who would be left out?
- What could go wrong for these students? Consider stress during timed reading, deception about the purpose, lost lesson time, and parental consent for anyone under 16. For each risk, which safeguard answers it?

C. Data collection
- Which part of your aim does each comprehension question measure? How will you check that the passages are equally difficult across conditions?
- How will you control the music: type, volume, familiarity and timing?
- How will comprehension be scored, and could the person scoring know which condition a participant was in?

D. Discussion
- If your results showed no difference, what would that mean for your research question?
- Where could expectations enter the study, from participants or from you?
- What would a second method add that an experiment cannot?

When you have a draft of any one section, paste it here. I will tell you where it meets each criterion and where it does not, with a provisional band and one line of reasoning for each.

Sources: none consulted (no retrieval in this session)"""

feedback_handled = [
    {
        "flaw_id": "f1",
        "flaw": "coverage: the student's request to write the research question, introduction and ethical safeguards section was not visibly answered",
        "changed": "The first sentence now names the three parts the student asked for (research question, introduction, ethical safeguards) and says they must be the student's own work. The research question is placed in section A as the aim, and the ethical safeguards are placed in section B, tied to specific risks, so each requested part is mapped to where it belongs in the proposal.",
        "kept": "The decline itself. The knowledge base forbids writing the research question, any section or paragraph of the proposal, or its ethical safeguards, even as a starting draft; the answer therefore addresses the request by declining it and coaching each part through questions. Everything else in the reply (criteria, limit and provisional labelling, topic check, the coaching questions for sections A to D, the closing invitation and the sources line) is unchanged because no problem names it.",
    }
]

record = dict(task)
record["response_text"] = response_text
record["feedback_handled"] = feedback_handled

os.makedirs(OUT_DIR, exist_ok=True)
out_path = os.path.join(OUT_DIR, "ps-t15.json")
with open(out_path, "w", encoding="utf-8") as f:
    json.dump(record, f, ensure_ascii=False, indent=2)

print(out_path)
