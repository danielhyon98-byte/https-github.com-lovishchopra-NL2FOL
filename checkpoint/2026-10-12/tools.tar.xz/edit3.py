p = "src/epinoic_logic/branches/quant.py"
s = open(p, encoding="utf-8").read()
old_start = s.index("#: 'suspended Chinese labour immigration for ten years, from 1882 to 1892': a stated length against the span's own years.\n_DURATION_RE")
old_end = s.index("#: 'Of the $13 billion, the United Kingdom received about $3.2 billion and France about $2.7 billion': a total that opens its clause")
new = r'''#: A stated length of years: 'for ten years', 'lasted five years', 'had run for more than twelve years', 'which lasted about five years'.
_DUR_VERBS = (r"lasted|lasting|lasts|last|ran|run|running|runs|continued|continuing|continues|endured|enduring|endures|spanned|spanning|spans|persisted|"
              r"persisting|went\s+on|going\s+on")
_DUR_PHRASE_RE = re.compile(rf"\b(?:(?P<verb>{_DUR_VERBS})\s+(?:for\s+)?|for\s+)(?:(?P<q>{_QUAL})\s+)?(?P<n>\d{{1,3}}(?:\.\d+)?|{_WNUM})\s+(?:full\s+|whole\s+|long\s+)?years?\b"
                            r"(?![-'’]|\s+(?:old|of\s+age|each|apiece|at\s+a\s+time|later|earlier|ago|per|running|in\s+a\s+row)\b)", re.IGNORECASE)
_MONTHS_TEXT = "January|February|March|April|May|June|July|August|September|October|November|December"
_MONTH_NUMBER = {m.lower(): i for i, m in enumerate(_MONTHS_TEXT.split("|"), start=1)}
#: A date of a span: a year, a month and year, or a day, month and year ('7 October 1949', 'October 7, 1949').
_SPAN_DATE = (rf"(?:(?:\d{{1,2}}(?:st|nd|rd|th)?\s+)?(?:{_MONTHS_TEXT})\s+(?:\d{{1,2}}(?:st|nd|rd|th)?,?\s+)?)?(?:1[0-9]{{3}}|20[0-9]{{2}})(?![\d,.]?\d)"
              r"(?!\s*(?:per\s*cent|percent|%|million|billion|thousand|seats|votes)\b)")
_ONE_DATE_RE = re.compile(rf"^(?:(?:(?P<day>\d{{1,2}})(?:st|nd|rd|th)?\s+)?(?P<month>{_MONTHS_TEXT})\s+(?:(?P<day2>\d{{1,2}})(?:st|nd|rd|th)?,?\s+)?)?(?P<year>1[0-9]{{3}}|20[0-9]{{2}})$",
                          re.IGNORECASE)
_SPAN_DATE_RE = re.compile(rf"(?<![\d,.$£€]){_SPAN_DATE}", re.IGNORECASE)
_SPAN_LEAD = r"(?:(?:the\s+)?(?:early|late|mid)[\s-]+|(?:about|around|c\.|ca\.|circa)\s+)?"
#: A span: 'from 1882 to 1892', 'from June 1924 to January 1926', 'between the founding of the GDR on 7 October 1949 and 1961', 'after the
#: GDR's founding on 7 October 1949, until 13 August 1961'. Words before a date end with 'on', 'in' or 'of' and hold no figure.
_DUR_SPAN_RE = re.compile(
    rf"\b(?P<open>from|between|since|after)\s+(?:[^\d;:!?]{{0,80}}?\b(?:on|in|of)\s+)?{_SPAN_LEAD}(?P<d1>{_SPAN_DATE})"
    rf"\s*,?\s+(?:and|to|until|till|through|up\s+to)\s+(?:[^\d;:!?]{{0,60}}?\b(?:on|in|of)\s+)?{_SPAN_LEAD}(?P<d2>{_SPAN_DATE})", re.IGNORECASE)
#: Days in a year, for an elapsed time stated between day or month dates (the mean Gregorian year).
_DAYS_PER_YEAR = Fraction(3652425, 10000)
#: Half a year: a length stated in whole years and read against day or month dates passes when it rounds the elapsed time.
YEAR_FLOOR = Fraction(1, 2)
_STRICT_LOWER = frozenset({"more than", "over"})
_STRICT_UPPER = frozenset({"less than", "under"})
'''
s = s[:old_start] + new + s[old_end:]
s = s.replace(r'''more\s+than|less\s+than|fewer\s+than|higher\s+than|lower\s+than|larger\s+than|smaller\s+than|greater\s+than|\bfor\s+\S+\s+years?\b|''',
              r'''more\s+than|less\s+than|fewer\s+than|higher\s+than|lower\s+than|larger\s+than|smaller\s+than|greater\s+than|''', 1)
open(p, "w", encoding="utf-8").write(s)
