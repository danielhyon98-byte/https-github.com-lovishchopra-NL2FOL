F=/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/wf/phase2/integrate/g1/combinator-faults/report.json
PY=/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/z3venv/bin/python
for i in $(seq 1 9); do
  if [ -f "$F" ] && $PY -I -c "import json,sys;d=json.load(open(sys.argv[1]));sys.exit(0 if all(k in d for k in ('passed','measured','bugs')) else 1)" "$F" 2>/dev/null; then echo READY; exit 0; fi
  sleep 60
done
echo NOTYET; date
