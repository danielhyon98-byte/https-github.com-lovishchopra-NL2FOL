#!/usr/bin/env bash
# 7 Nov: free disk by archiving finished scratch outputs (argdiag work merged 30 Oct and uploaded; c1 attack rounds 1-6).
# Each directory is archived, the archive tested, and only then the directory removed.
set -uo pipefail
S=/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad
OUT=$S/archives; mkdir -p "$OUT"
for d in wf/argdiag/integ wf/argdiag/accfix wf/argdiag/regr wf/argdiag/secfix wf/argdiag/verify-r2 wf/argdiag/verify-r3 \
         wf/metanote/attack-1-bypass wf/metanote/attack-1-regression wf/metanote/attack-1-review \
         wf/metanote/attack-2-bypass wf/metanote/attack-2-regression wf/metanote/attack-2-review \
         wf/metanote/attack-3-bypass wf/metanote/attack-3-regression wf/metanote/attack-3-review \
         wf/metanote/attack-4-bypass wf/metanote/attack-4-regression wf/metanote/attack-4-review \
         wf/metanote/attack-5-bypass wf/metanote/attack-5-regression wf/metanote/attack-5-review; do
  [ -d "$S/$d" ] || continue
  name=$(echo "$d" | tr / _); a="$OUT/$name.tar.xz"
  if nice -n 19 tar -C "$S" -cf - "$d" | nice -n 19 xz -T1 -6 > "$a.part" && xz -t "$a.part" && tar -tJf "$a.part" >/dev/null; then
    mv "$a.part" "$a"; rm -rf "$S/$d"; echo "archived $d -> $(du -h "$a" | cut -f1)"
  else rm -f "$a.part"; echo "FAILED $d (left in place)"; fi
done
df -h / | tail -1
