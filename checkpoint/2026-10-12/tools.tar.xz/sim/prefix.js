const fs = require('fs')
function trace(path) {
  const src = fs.readFileSync(path, 'utf8').replace(/^export const meta/m, 'const meta')
  const calls = []
  const agent = async (p, o = {}) => { calls.push((o.label || '') + '\u0001' + p + '\u0001' + JSON.stringify(o)); if (calls.length > 40) throw new Error('stop'); const sc = o.schema; if (!sc) return 'ok'; const r = {}; for (const [k, v] of Object.entries(sc.properties || {})) r[k] = v.type === 'array' ? [] : v.type === 'boolean' ? true : v.type === 'integer' || v.type === 'number' ? 1 : v.type === 'object' ? {} : 'x'; if ('modules' in r) r.modules = []; if ('finding_codes' in r) r.finding_codes = []; return r }
  const parallel = async ts => Promise.all(ts.map(t => t().catch(() => null)))
  return new Function('agent', 'parallel', 'pipeline', 'phase', 'log', 'args', 'return (async () => {' + src + '\n})()')(agent, parallel, async () => [], () => {}, () => {}, undefined).catch(e => { calls.push('ERR\u0001' + e.message) }).then(() => calls)
}
Promise.all([trace(process.argv[2]), trace(process.argv[3])]).then(([a, b]) => {
  const lab = c => c.split('\u0001')[0]
  let firstDiff = -1
  for (let i = 0; i < Math.max(a.length, b.length); i++) if (a[i] !== b[i]) { firstDiff = i; break }
  console.log('calls old', a.length, 'new', b.length, '| first difference at call', firstDiff, firstDiff >= 0 ? (lab(a[firstDiff] || '') + ' vs ' + lab(b[firstDiff] || '')) : '')
  console.log('old labels:', a.map(lab).join(' '))
  console.log('new labels:', b.map(lab).join(' '))
})
