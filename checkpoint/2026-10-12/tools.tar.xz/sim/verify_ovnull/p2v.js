const fs = require('fs')
const src = fs.readFileSync(process.argv[2], 'utf8').replace(/^export const meta/m, 'const meta')
const mode = process.argv[3] || 'ok'
const calls = []
const K = ['english-specialist','english-a-literature','english-a-lang-lit','history','economics','business-management','psychology','geography','language-b-spanish','computer-science','physics','chemistry','biology','ess','mathematics-aa','mathematics-ai']
const design = () => { const ts = K.map((k, i) => ({ task_id: 't' + i, agent_id: k + '-specialist', subject: k, kb: k, group: i === 4 ? 'g1' : i === 10 ? 'g2' : i === 3 ? 'g3' : undefined })); ts.push({ task_id: 'd1', agent_id: 'x', subject: 's', kb: 'business-management', peer_of: 't4', group: 'g1' }, { task_id: 'd2', agent_id: 'x', subject: 's', kb: 'mathematics-aa', peer_of: 't10', group: 'g2' }, { task_id: 'd3', agent_id: 'x', subject: 's', kb: 'english-a-literature', peer_of: 't3', group: 'g3' }); return { tasks: ts } }
let opt = 0
async function agent(prompt, opts = {}) {
  const l = opts.label || ''
  calls.push(l + (opts.model ? ' [' + opts.model + ']' : ''))
  if (/^merge:/.test(l)) return mode === 'mergefail' && l.includes('overseer') ? { staged: false, reason: 'conflict' } : { staged: true, conflicts: [] }
  if (/^verify:/.test(l)) return { suite_passed: true, suite_tail: '9 passed', harness_line: 'r1 30/30', harness_dropped: false, hygiene_ok: true }
  if (/^commit:optimize/.test(l)) return { committed: true, pushed: true, reverted: false, sha: 'o' }
  if (/^commit:/.test(l)) return { committed: true, pushed: true, sha: 'abc' }
  if (l === 'handoffs:r7') return { bugs: [{ severity: 'major', file: 'src/epinoic_logic/stem/x.py', summary: 's', expected: 'e', actual: 'a', fix: 'f' }] }
  if (/^fix:/.test(l)) return { fixed: [{ bug: 'b', change: 'c' }], left_undone: [], handoff_written: l.startsWith('fix:core') }
  if (/^design:c|^multiagent:design/.test(l)) return design()
  if (/^relay:/.test(l)) return { relays: [{ task_id: 'd1', delivered: true }, { task_id: 'd2', delivered: true }, { task_id: 'd3', delivered: true }] }
  if (mode === 'prepnull' && l === 'overseer-prep:c1') return null; if (mode === 'scorenull' && l === 'overseer-score:c1') return null; if (/^overseer-prep/.test(l)) return { pack_dir: '/p/overseer-knowledge-docs-1.0', batches: [['/d/d01.json'], ['/d/d02.json']], max_instances: 4 }
  if (/^overseer-pool:w2/.test(l)) return { duplicate_batches: [['/d/d01.json']], reasons: ['conflicting verdicts'], instances_used: 2 }
  if (/^overseer-pool/.test(l)) return { duplicate_batches: [] }
  if (/^overseer-score/.test(l)) return { dossiers: 2, faults_present: 1, faults_named: 1, false_accusations: 0 }
  if (/^overseer:/.test(l) && (mode === 'prepnull' || mode === 'scorenull')) { if (/attached this round/.test(prompt)) console.log('LENS TOLD: not attached', l); return { infrastructure_functional_rate: 0.99, verdict_at_least_98: true, previous_bugs_fixed: 0, previous_bugs_open: [], bugs: [] } }; if (/^overseer:/.test(l)) return { infrastructure_functional_rate: 0.95, verdict_at_least_98: false, previous_bugs_fixed: 0, previous_bugs_open: [], bugs: [{ severity: 'major', file: 'src/epinoic_logic/channel/bus.py', summary: 's', expected: 'e', actual: 'a', fix: 'f' }] }
  if (l === 'scaling:implement') return { done: ['x'], results: 'r' }
  if (/^scaling:test/.test(l)) return { done: [], results: 'measured' }
  if (/^scaling:review/.test(l)) return { bugs: [] }
  if (/^multiagent:overseer/.test(l)) return { infrastructure_functional_rate: 1, verdict_at_least_98: true, previous_bugs_fixed: 0, previous_bugs_open: [], bugs: [] }
  if (/^optimize:test/.test(l)) return { head: 'h', measurements: 'm', issues: opt++ === 0 ? [{ area: 'translator-agents', severity: 'major', summary: 's', evidence: 'e', fix: 'f' }] : [] }
  if (/^optimize:fix/.test(l)) return { fixed: [{ issue: 'i', change: 'c' }], left_undone: [], agent_config_paths: ['src/epinoic_logic/translate/prompts/translate_v1.md'] }
  if (/^ab:prep/.test(l)) return { pack_dir: '/p', batches: [['/d/d01.json']] }
  if (/^ab:judge/.test(l)) return mode === 'abnull' ? null : { quality_kept: true, before_after: 'faster' }
  if (/^ab:undo/.test(l)) return { undone: true }
  if (l === 'final:readiness') return { all_bug_fixes_implemented: true, open: [], summary: 's' }
  return 'ok'
}
const parallel = async ts => Promise.all(ts.map(t => t().catch(e => { console.error('THUNK ERROR', e.message); return null })))
new Function('agent', 'parallel', 'pipeline', 'phase', 'log', 'args', 'return (async () => {' + src + '\n})()')(agent, parallel, async () => [], () => {}, m => console.log('LOG', m), undefined)
  .then(r => { console.log('RETURN', JSON.stringify(r).slice(0, 400)); console.log('CALLS', calls.length); console.log(calls.filter(c => /haiku|pool|optimize|ab:|merge|abort|handoffs|final/.test(c)).join(' | ')) })
  .catch(e => console.error('SCRIPT ERROR', e.stack.split('\n').slice(0, 3).join('\n')))
