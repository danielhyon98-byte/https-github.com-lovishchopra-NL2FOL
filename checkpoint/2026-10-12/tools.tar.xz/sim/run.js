const fs = require('fs')
const src = fs.readFileSync(process.argv[2], 'utf8').replace(/^export const meta/m, 'const meta')
const calls = []
const mode = process.argv[3] || 'merged'
const MERGED = mode !== 'notready'
async function agent(prompt, opts = {}) {
  const l = opts.label || ''
  calls.push(l + (opts.model ? ' [' + opts.model + ']' : ''))
  const sc = opts.schema
  if (!sc) return 'ok'
  const props = sc.properties || {}
  if (l.startsWith('merge:stem')) return MERGED ? { staged: true, conflicts: [] } : { staged: false, reason: 'not ready' }
  if (/^design:r[56]$/.test(l)) return { tasks: [0,1,2,3,4,5].map(i => ({ task_id: 'x' + i, agent_id: i < 3 ? 'english-specialist' : 'history-specialist', subject: 's', peer_of: i === 5 ? 'x0' : undefined })), topics: ['y'] }
  if (l.startsWith('design:r7') || l.startsWith('design-fix:r7')) { const K = ['english-specialist','english-a-literature','english-a-lang-lit','history','economics','business-management','psychology','geography','language-b-spanish','computer-science','physics','chemistry','biology','ess','mathematics-aa','mathematics-ai']; const ts = K.map((k, i) => ({ task_id: 't' + i, agent_id: k + '-specialist', subject: k, kb: k, group: i === 4 ? 'p7a' : i === 10 ? 'p7b' : i === 3 ? 'p7c' : undefined })); if (mode !== 'badgroups' || l.startsWith('design-fix')) { ts.push({ task_id: 'd1', agent_id: 'b', subject: 's', kb: 'business-management', peer_of: 't4', group: 'p7a' }, { task_id: 'd2', agent_id: 'm', subject: 's', kb: 'mathematics-aa', peer_of: 't10', group: 'p7b' }, { task_id: 'd3', agent_id: 'e', subject: 's', kb: 'english-a-literature', peer_of: 't3', group: 'p7c' }) } else { ts.push({ task_id: 'd1', agent_id: 'b', subject: 's', kb: 'business-management', peer_of: 't4', group: 'zz' }, { task_id: 'd2', agent_id: 'm', subject: 's', kb: 'mathematics-aa', peer_of: 't10', group: 'p7b' }, { task_id: 'd3', agent_id: 'e', subject: 's', kb: 'english-a-literature', peer_of: 't3', group: 'p7c' }) } return { tasks: ts, topics: ['x'] } }
  if (l.startsWith('relay:r7')) return { relays: [{ task_id: 'd1', delivered: true }, { task_id: 'd2', delivered: true }, { task_id: 'd3', delivered: false }] }
  if (l.startsWith('overseer-prep')) return { pack_dir: '/x/pack/overseer-knowledge-docs-1.0', batches: [['/x/d01.json'], ['/x/d02.json']] }
  if (l.startsWith('overseer-score')) return { dossiers: 2, faults_present: 1, faults_named: 1, false_accusations: 0 }
  if (l.startsWith('overseer:')) return { infrastructure_functional_rate: 0.9, verdict_at_least_98: false, previous_bugs_fixed: 0, previous_bugs_open: [], extra_transmissions_run: 1, bugs: [{ severity: 'major', file: 'src/epinoic_logic/stem/parse.py', summary: 's', expected: 'e', actual: 'a', fix: 'f' }, { severity: 'minor', file: 'src/epinoic_logic/channel/bus.py', summary: 's', expected: 'e', actual: 'a', fix: 'f' }] }
  if ('suite_passed' in props) return { suite_passed: true, suite_tail: '1 passed', failing_tests: [], harness: [{ round: 'r7', transmissions: 10, functional: 10, rate: 1 }] }
  if ('committed' in props) return { committed: true, pushed: true, sha: 'deadbeef' }
  if ('fixed' in props) return { fixed: [{ bug: 'b', change: 'c' }], left_undone: [], suite_tail: '1 passed' }
  const o = {}; for (const k of (sc.required || [])) o[k] = props[k] && props[k].type === 'array' ? [] : props[k] && props[k].type === 'boolean' ? true : props[k] && (props[k].type === 'integer' || props[k].type === 'number') ? 1 : 'x'
  return o
}
const parallel = async ts => Promise.all(ts.map(t => t().catch(e => { console.error('THUNK ERROR', e.message); return null })))
const pipeline = async () => []
const phase = () => {}, log = m => console.log('LOG', m)
new Function('agent', 'parallel', 'pipeline', 'phase', 'log', 'return (async () => {' + src + '\n})()')(agent, parallel, pipeline, phase, log)
  .then(r => { console.log('RETURN keys', Object.keys(r || {})); console.log(calls.filter(c => /r7|stem/.test(c)).join('\n')) })
  .catch(e => { console.error('SCRIPT ERROR', e.stack.split('\n').slice(0, 4).join('\n')) })
