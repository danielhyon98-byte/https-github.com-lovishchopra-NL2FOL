const fs = require('fs')
function load(path) {
  const src = fs.readFileSync(path, 'utf8')
  const start = src.indexOf('const REPO')
  const end = src.indexOf("phase('Consolidate')")
  const body = src.slice(start, end).replace(/^export /gm, '')
  return new Function('agent', 'parallel', 'phase', 'log', body + '; return {overseerPrompt, fixerPrompt, LENSES, lensesFor: typeof lensesFor === "function" ? lensesFor : null, NO_STRESS_CUT: typeof NO_STRESS_CUT === "string" ? NO_STRESS_CUT : null}')(() => {}, () => {}, () => {}, () => {})
}
const a = load(process.argv[2]), b = load(process.argv[3])
const bugs = [{ severity: 'major', file: 'src/x.py', summary: 's', expected: 'e', actual: 'a', fix: 'f' }]
for (const r of ['r4', 'r5', 'r6', 'r7']) {
  for (const l of a.LENSES) {
    const same = a.overseerPrompt(l, r, 'r3', null) === b.overseerPrompt(l, r, 'r3', null)
    console.log(r, 'overseer', l.key, same ? 'same' : 'CHANGED')
  }
  for (const o of ['channel', 'history', 'english', 'harness']) {
    const pa = a.fixerPrompt(o, bugs, r, ['r1'], 'x'), pb = b.fixerPrompt(o, bugs, r, ['r1'], 'x')
    console.log(r, 'fixer', o, pa === pb ? 'same' : 'CHANGED', pb.includes('stress_arena') ? '(mentions stress_arena)' : '')
  }
}
const adv = b.LENSES.find(l => l.key === 'adversarial-live')
console.log('stress sentence present in lens task:', adv.task.includes(b.NO_STRESS_CUT), '| r7 prompt mentions stress harness:', b.overseerPrompt(adv, 'r7', 'r6', null).includes('stress harness'))
