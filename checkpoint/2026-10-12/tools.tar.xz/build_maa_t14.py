import json
import os

base = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad"
src = os.path.join(base, "clearance", "c1", "tasks.json")
resp_path = os.path.join(base, "maa-t14-response.txt")
out_dir = os.path.join(base, "clearance", "c1", "specialists")
out_path = os.path.join(out_dir, "maa-t14.json")

with open(src, encoding="utf-8") as f:
    tasks = json.load(f)

matches = [t for t in tasks if t.get("task_id") == "maa-t14"]
assert len(matches) == 1, "expected exactly one maa-t14 task"

with open(resp_path, encoding="utf-8") as f:
    response_text = f.read().rstrip("\n")

record = dict(matches[0])
record["response_text"] = response_text

os.makedirs(out_dir, exist_ok=True)
with open(out_path, "w", encoding="utf-8") as f:
    json.dump(record, f, ensure_ascii=False, indent=2)
    f.write("\n")

with open(out_path, encoding="utf-8") as f:
    check = json.load(f)
print(out_path)
print(sorted(check.keys()))
print(len(check["response_text"]), "chars")
