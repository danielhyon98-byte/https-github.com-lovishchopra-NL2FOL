import json
import os

SRC = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2/tasks.json"
OUT_DIR = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2/specialists"
OUT = os.path.join(OUT_DIR, "lit-t15.json")

RESPONSE = """Across the poem, the relationship between the speaker and her mother moves from the mother's authority over language to a reversal in which the speaker holds the mother's words and the mother depends on her. The change begins with the metaphor "hands me her voice", which turns speech into an object passed from one person to another, and the comparison to shopping bags, "the heavy one first", suggests that the mother hands over the hardest load before anything else. The speaker then carries "each sentence across in both hands" and sets it "down on her side of the desk", so she occupies the space between two sides while her mother keeps control of what is opened. A further shift comes when the speaker's own words begin to alter that authority. The mother's only quoted speech, "we have always paid", is framed by her command, "Tell him", yet the speaker repeats it as "we have nearly always paid", and the single word "nearly" softens the claim. This may be an honest correction or a small betrayal, and the poem does not settle which. The clerk's nod, "as if I am the one who owes", suggests that the debt has moved onto the speaker, so the change in the relationship becomes a change in who is held responsible. By the late stanzas the mother "holds my hand too tightly", recalling the speaker "who could not cross a road", so the speaker's old dependence is reversed and the mother's grip reads as need. The poem then ends with words left unsaid, "the word for proud" and "the word for sorry", and with a girl who "is not allowed to sit down in either" language. The recurring phrase "the word for" marks what the speaker's translation cannot carry. The relationship therefore moves from delegation to reversal to shared silence, and the passive "is not allowed" leaves unnamed who denies her a seat.

One correction for your planning: at HL, Paper 1 gives two passages and you write one analysis on each rather than choosing one, so an answer on a single passage can score at most half of the paper's marks.

Next step: write one sentence on what the unsaid words in the last stanza reveal about the relationship, and paste it here.

Sources: Interpreter, the poem you supplied (supplied text); general course knowledge of analytical terms (course notes)"""

with open(SRC, "r", encoding="utf-8") as f:
    tasks = json.load(f)

selected = [t for t in tasks if t.get("task_id") in ["lit-t15"]]
os.makedirs(OUT_DIR, exist_ok=True)
written = []
for t in selected:
    out = dict(t)
    out["response_text"] = RESPONSE
    path = os.path.join(OUT_DIR, t["task_id"] + ".json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    written.append(path)

print("\n".join(written))
print("paragraph words:", len(RESPONSE.split("\n\n")[0].split()))
