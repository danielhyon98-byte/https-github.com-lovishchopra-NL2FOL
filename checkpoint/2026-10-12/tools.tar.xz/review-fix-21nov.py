import pathlib, sys
d = pathlib.Path(sys.argv[1])
def rep(name, old, new, count=1):
    p = d / name; t = p.read_text()
    n = t.count(old)
    assert n == count, (name, old[:60], n)
    p.write_text(t.replace(old, new))
reg_old = 'loses its INT-REQ-003 error), while it found nothing malicious (no eval or exec of data, no new network or subprocess access, and the signing manifest verifies)'
reg_new = 'loses its INT-REQ-003 error when the answer also uses the altered wording), while it found nothing malicious (no eval or exec of data, no new network, subprocess or credential access, no signing change, and the kit\'s hash manifest verifies)'
rep('08-instructions-for-bruno.md', reg_old, reg_new)
rep('08-logic-translator-website-launch.md', reg_old, reg_new)
rep('08-instructions-for-bruno.md',
 "word count; keeping or changing that is the owner's call (the programme recommends reading the stated count as content\nand checking it against the actual count; a recommendation, not a decision).",
 "word count; keeping or changing that is the owner's call.")
rep('08-logic-translator.md',
 "whenever a task asks for a word count. Keeping or changing this is the owner's call. The programme recommends reading\n   the stated count as content and checking it against the actual count; this is a recommendation, not a decision.",
 "whenever a task asks for a word count. Keeping or changing this is the owner's call (`tests/README.md` at\n   `82774fc40b7a6fbb4034ee9f79b7081fbdbd6d33` also records these lines as staying gated under decision D7).")
rep('08-logic-translator.md',
 "It found nothing malicious: no eval or exec of data, no new network or subprocess access, and the signing\nmanifest (`integration/MANIFEST.sha256`) verifies.",
 "It found nothing malicious: no eval or exec of data, no new network, subprocess or credential access, no signing\nchange, and the kit's hash manifest (`integration/MANIFEST.sha256`, 359 entries) verifies.")
rep('08-logic-translator.md',
 "5 of 65 and 20 of 150 fresh phrasings got through\n   in two probes)",
 "5 of 65 fresh phrasings delivered in one probe, 20 of\n   150 missed by the reader in another)")
rep('08-logic-translator.md',
 "directories committed at the repository root. `af6dfe0` fixed those four (its message:",
 "directories committed at the repository root. `af6dfe0` addressed those four (its message:")
rep('08-logic-translator.md',
 "  moves (hourly notes): read with `git ls-remote` on 21 November at\n  [`af6dfe04ef67ad8c934767a78b0b743a14870513`](https://github.com/danielhyon98-byte/https-github.com-lovishchopra-NL2FOL/commit/af6dfe04ef67ad8c934767a78b0b743a14870513)\n  (\"Fix the c3 clearance findings\", 21 Nov 19:15 UTC), which is also its last commit with content.",
 "  moves (hourly notes): read with `git ls-remote` on 21 November at\n  `82774fc40b7a6fbb4034ee9f79b7081fbdbd6d33` (\"Tests README: progress note 20:00\", a `tests/README.md` note only), over\n  [`af6dfe04ef67ad8c934767a78b0b743a14870513`](https://github.com/danielhyon98-byte/https-github.com-lovishchopra-NL2FOL/commit/af6dfe04ef67ad8c934767a78b0b743a14870513)\n  (\"Fix the c3 clearance findings\", 21 Nov 19:15 UTC), its last commit with content.")
rep('08-logic-translator-website-launch.md',
 "its follow-up `af6dfe0` (the head on 21 Nov; between content commits the head moves hourly with progress notes)",
 "its follow-up `af6dfe0` (the last commit with content on 21 Nov; the head moves hourly with progress notes, at 20:00 UTC `82774fc40b7a6fbb4034ee9f79b7081fbdbd6d33`)")
print("ok")
