"""Rewrite working-area placeholders in an update note carried forward from an earlier publish (stdin to stdout)."""
import re
import sys

text = sys.stdin.read()
text = re.sub(r"<scratch(?:pad)?>/(?:[^\s'\"`),;]*[^\s'\"`),;.])?|<scratch file>", "a private working copy", text)
sys.stdout.write(text)
