import json
B='/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/wf/carry-c2/'
G={'lens-ra-1':'lens-ra-1/challenged.json','lens-ra-2':'lens-ra-2/challenge/challenged.json','lens-cf':'lens-cf/challenge/challenged.json','lens-al':'lens-al/challenge/challenged.json','lens-si-1':'lens-si-1/challenge/challenged.json','lens-si-2':'lens-si-2/challenge/challenged.json','lens-tf':'lens-tf/challenged.json','leftovers':'leftovers/challenged.json','queued':'queued/challenged.json'}
def load():
    out={}
    for g,f in G.items():
        out[g]=json.load(open(B+f))
    return out
