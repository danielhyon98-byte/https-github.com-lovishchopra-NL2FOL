import json, sys

SCR = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad"
SPEC = f"{SCR}/arena/r1/specialists"
OUT = f"{SCR}/arena/r1/translations"

REQ = {"hi-t1": "req-hi-t1", "hi-t2": "req-hi-t2", "en-t1": "req-en-t1", "en-t2": "req-en-t2"}
REP = {"hi-t1": "rep-hi-t1-0", "hi-t2": "rep-hi-t2-0", "en-t1": "rep-en-t1-0", "en-t2": "rep-en-t2-0"}

# ---------- IR helpers ----------
def v(n): return {"op": "var", "name": n}
def i(x): return {"op": "int", "value": str(x)}
def r(x): return {"op": "real", "value": str(x)}
def AND(*a): return a[0] if len(a) == 1 else {"op": "and", "args": list(a)}
def IMP(l, rr): return {"op": "implies", "left": l, "right": rr}
def CMP(op, l, rr): return {"op": op, "left": l, "right": rr}
def eq(l, rr): return CMP("eq", l, rr)
def gt(l, rr): return CMP("gt", l, rr)
def lt(l, rr): return CMP("lt", l, rr)

def G(kind, cert, note=None, refs=None):
    g = {"kind": kind, "certainty": cert, "source_refs": refs or []}
    if note:
        g["note"] = note
    return g

def QU(ex, cert="established"):
    return G("quotation", cert, None, [{"document_id": "doc-cdf", "excerpt": ex}])
def SI(cert="probable", note=None): return G("specialist_inference", cert, note)
def AS(cert="probable", note=None): return G("assumption", cert, note)
def GK(cert="probable", note=None): return G("general_knowledge", cert, note)

def S(name, sort, meaning, g): return {"name": name, "sort": sort, "meaning": meaning, "grounding": g}
def A(aid, expr, label, g, mat="material"):
    return {"id": aid, "expr": expr, "label": label, "grounding": g, "materiality": mat}
def F(code, msg, alts): return {"code": code, "message": msg, "alternatives": alts}

def build(task, cid, syms, prems, concl, clabel, cg, notes=None):
    p = {"ir_version": "1.0", "problem_id": f"{task}-{cid}", "request_id": REQ[task], "claim_id": cid,
         "query": "entailment", "symbols": syms, "premises": prems,
         "conclusion": {"id": "claim", "expr": concl, "label": clabel, "grounding": cg, "materiality": "material"}}
    if notes:
        p["notes"] = notes
    return p

def pack(p, reading, flags, amb):
    gl = [{"symbol": s["name"], "meaning": s["meaning"], "grounding": s["grounding"]} for s in p["symbols"]]
    return {"problem": p, "interpretation": {"reading": reading, "glossary": gl, "ambiguity_flags": flags},
            "ambiguous": amb, "unsupported_reason": None}

EST = "established"
PRB = "probable"

# =====================================================================
# hi-t1 (History, no supplied texts)
# =====================================================================
def hi_t1_h11():
    AS_ = AS(PRB, "figure or date from specialist memory (report footnote: dates and figures are from memory)")
    GK_ = GK(PRB, "qualitative historical fact from specialist memory; no supplied text")
    syms = [
        S("unemp_rise", "Bool", "registered unemployment rose from about 1.4 million (1928) to more than six million (early 1932)", AS_),
        S("vote_rise", "Bool", "the Nazi vote rose with unemployment: 2.6 to 18.3 to 37.3 per cent; 12 to 107 to 230 seats", AS_),
        S("agr_ruin", "Bool", "the agrarian crisis ruined farming communities in the Protestant north", GK_),
        S("small_turn", "Bool", "small businesses threatened with bankruptcy turned to the party", GK_),
        S("voted_mod", "Bool", "the groups hit had voted for moderate and conservative parties in 1928", SI(EST, "asserted inside the point; no listed supporting claim establishes it")),
        S("destroyed", "Bool", "the Depression destroyed the economic security of those groups", SI(EST)),
        S("mass", "Bool", "the party gained a mass following it had never possessed", SI(EST)),
        S("fall_largest", "Bool", "the Nazi vote fell only after the party had become the largest in the Reichstag (July 1932)", AS_),
        S("weight", "Bool", "by the criterion of what made the breakthrough possible, the Depression carries the greater weight", SI(EST)),
        S("above", "Bool", "the Depression was responsible for the Nazi electoral rise above all", SI(EST)),
        S("fear", "Bool", "the mechanism was fear of ruin among the lower middle class and farmers", SI(EST)),
        S("corr_not", "Bool", "the correlation is not itself the explanation", SI(EST)),
        S("counter_fig", "Bool", "the Nazi vote fell to 33.1 per cent in November 1932 while the Communist vote rose from 10.6 to 16.9 per cent", AS_),
        S("distress_not", "Bool", "distress alone did not decide where votes went", SI("possible")),
        S("large_deg", "Bool", "the Depression was responsible for the electoral rise to a large degree", SI(EST)),
        S("not_app", "Bool", "the January 1933 appointment depended on the choices of the conservative elite, not the Depression", SI(EST)),
    ]
    prems = [
        A("p_unemp", v("unemp_rise"), "registered unemployment rose from about 1.4 million to over six million", AS_, "supporting"),
        A("p_vote", v("vote_rise"), "the Nazi vote rose with it", AS_, "supporting"),
        A("p_agr", v("agr_ruin"), "the agrarian crisis ruined farming communities in the north", GK_),
        A("p_small", v("small_turn"), "threatened small businesses turned to the party", GK_),
        A("p_fear", v("fear"), "the mechanism was fear of ruin among the lower middle class and farmers", SI(EST), "supporting"),
        A("p_corr", v("corr_not"), "the correlation is not itself the explanation", SI(EST), "supporting"),
        A("p_counter", v("counter_fig"), "counter-case: Nazi vote fell in November 1932 as the Communist vote rose", AS_, "supporting"),
        A("l_distress", IMP(v("counter_fig"), v("distress_not")), "the counter-case suggests distress alone did not decide votes", SI("possible"), "supporting"),
        A("p_fall", v("fall_largest"), "the Nazi vote fell only after the party became the largest", AS_),
        A("l_weight", IMP(v("fall_largest"), v("weight")), "because the crisis had already made the Nazis the largest party, the Depression carries the greater weight", SI(EST)),
        A("l_destroy", IMP(AND(v("agr_ruin"), v("small_turn"), v("voted_mod")), v("destroyed")), "ruin and turning of groups that had voted moderate in 1928 destroyed their economic security", SI(EST)),
        A("l_mass", IMP(v("destroyed"), v("mass")), "so the party gained a mass following it had never possessed", SI(EST)),
        A("l_above", IMP(AND(v("destroyed"), v("weight")), v("above")), "responsible above all, because the Depression destroyed that security and carries the greater weight", SI(EST)),
        A("p_large", v("large_deg"), "the Depression was responsible for the electoral rise to a large degree (h1.7)", SI(EST), "supporting"),
        A("p_notapp", v("not_app"), "not for the January 1933 appointment (h1.7)", SI(EST), "supporting"),
    ]
    p = build("hi-t1", "h1.1", syms, prems, AND(v("above"), v("mass")),
              "The Depression was responsible for the Nazi electoral rise above all, because it destroyed the economic security of groups that had voted moderate or conservative in 1928, and so gave the party a mass following it had never possessed.",
              SI(EST),
              notes="No supplied texts. voted_mod is asserted in the point but no listed support establishes it; entailment is expected to fail there. h1.7 ('to a large degree') is carried as a supporting premise and sits in tension with the 'above all' conclusion.")
    reading = ("Read as the point of the paragraph. Encoded from its listed supports h1.2-h1.7: quantitative and memory facts as assumption premises, "
               "interpretive judgements as specialist_inference premises. The point's 'because' and 'so' are two separate implications. "
               "The point asserts that the destroyed groups had voted moderate or conservative in 1928; no listed support says so, so that symbol is left unsupported and the check should report it. "
               "Not added: any premise the specialist did not state.")
    flags = [
        F("above_all_vs_large_degree", "h1.1 says 'above all' while h1.7 (a support) says 'to a large degree'; both concern the electoral rise", ["'above all' (ranking among causes)", "'to a large degree' (absolute weight)"]),
        F("because_causal_or_evidential", "'because' may give the cause of the rise or the criterion for weighting it", ["causal: destruction of security produced the rise", "evidential: the criterion of breakthrough shows the weight"]),
        F("unsupported_premise_in_point", "the 1928 voting of the affected groups is asserted in the point but not in any listed support", ["add a support establishing 1928 moderate/conservative voting", "report as an unsupported premise"]),
    ]
    return pack(p, reading, flags, True)

def hi_t1_h12():
    g = AS(PRB, "figure from specialist memory (report footnote)")
    syms = [
        S("u28", "Real", "registered unemployment in 1928, millions (specialist: about 1.4)", g),
        S("u32", "Real", "registered unemployment by early 1932, millions", g),
        S("sh28", "Real", "Nazi vote share, May 1928, per cent", g),
        S("sh30", "Real", "Nazi vote share, September 1930, per cent", g),
        S("sh32", "Real", "Nazi vote share, July 1932, per cent", g),
        S("se28", "Int", "Nazi Reichstag seats, May 1928", g),
        S("se30", "Int", "Nazi Reichstag seats, September 1930", g),
        S("se32", "Int", "Nazi Reichstag seats, July 1932", g),
        S("largest32", "Bool", "the party became the largest in the Reichstag after the July 1932 election", g),
    ]
    facts = [
        (eq(v("u28"), r("1.4")), "registered unemployment was about 1.4 million in 1928"),
        (gt(v("u32"), r("6")), "registered unemployment exceeded six million by early 1932"),
        (eq(v("sh28"), r("2.6")), "the Nazi vote was 2.6 per cent in May 1928"),
        (eq(v("se28"), i(12)), "the Nazi party had twelve seats in May 1928"),
        (eq(v("sh30"), r("18.3")), "the Nazi vote was 18.3 per cent in September 1930"),
        (eq(v("se30"), i(107)), "the Nazi party had 107 seats in September 1930"),
        (eq(v("sh32"), r("37.3")), "the Nazi vote was 37.3 per cent in July 1932"),
        (eq(v("se32"), i(230)), "the Nazi party had 230 seats in July 1932"),
        (v("largest32"), "the party became the largest in the Reichstag in July 1932"),
    ]
    prems = [A(f"f{k}", e, lab, g) for k, (e, lab) in enumerate(facts, 1)]
    comps = [lt(v("sh28"), v("sh30")), lt(v("sh30"), v("sh32")), lt(v("se28"), v("se30")), lt(v("se30"), v("se32")), gt(v("u32"), v("u28"))]
    concl = AND(*([e for e, _ in facts] + comps))
    p = build("hi-t1", "h1.2", syms, prems, concl,
              "Unemployment rose from about 1.4 million (1928) to more than six million (early 1932), and the Nazi vote rose with it: 2.6% and 12 seats (May 1928), 18.3% and 107 seats (Sept 1930), 37.3% and 230 seats (July 1932), when the party became the largest in the Reichstag.",
              SI(EST))
    reading = ("Quantitative evidence claim with no supporting claims and no supplied text. Each figure is an assumption premise (specialist memory); the conclusion is the claim as comparisons, "
               "so the solver checks the rises (1.4 < 6, 2.6 < 18.3 < 37.3, 12 < 107 < 230). 'Largest' needs other parties' seat counts, which the claim does not give, so it is carried as a Bool.")
    flags = [
        F("vague_quantity", "'about 1.4 million' has no stated tolerance; encoded as the literal 1.4", ["exact 1.4 million", "a tolerance band around 1.4 million"]),
        F("largest_unquantified", "'became the largest' needs the other parties' seat counts, which are not given", ["Bool assumption (as encoded)", "compare against supplied party totals (none supplied)"]),
    ]
    return pack(p, reading, flags, True)

def hi_t1_h14():
    g = AS(PRB, "date from specialist memory")
    gk = GK(PRB, "qualitative historical fact from specialist memory; no supplied text")
    syms = [
        S("ag1928", "Bool", "the agrarian crisis began in 1928", g),
        S("ruin", "Bool", "the agrarian crisis ruined farming communities in the Protestant north", gk),
        S("turn", "Bool", "small businesses threatened with bankruptcy turned to a party promising national community and the destruction of Marxism", gk),
        S("aud", "Bool", "that message had found little audience among them before the Crash", gk),
    ]
    prems = [
        A("f1", v("ag1928"), "the agrarian crisis that began in 1928", g),
        A("f2", v("ruin"), "the agrarian crisis ruined farming communities in the Protestant north", gk),
        A("f3", v("turn"), "small businesses turned to a party promising national community and the destruction of Marxism", gk),
        A("f4", v("aud"), "the message had found little audience among them before the Crash", gk),
    ]
    p = build("hi-t1", "h1.4", syms, prems, AND(v("ag1928"), v("ruin"), v("turn"), v("aud")),
              "The agrarian crisis that began in 1928 ruined farming communities in the Protestant north, while small businesses threatened with bankruptcy turned to a party promising national community and the destruction of Marxism, a message that had found little audience among them before the Crash.",
              SI(EST))
    reading = ("Historical claim with no listed supports and no supplied text. The four stated facts are premises (memory-based), and the conclusion is their conjunction. "
               "The entailment confirms only that the encoding is consistent with the stated facts; it does not check the facts. The causal reading of 'while' is not encoded.")
    flags = [
        F("while_contrast_or_cause", "'while' may mark contrast of two facts or a causal step from ruin to turning to the party", ["contrast: two separate facts (as encoded)", "cause: ruin led businesses to turn to the party"]),
    ]
    return pack(p, reading, flags, True)

def hi_t1_h15():
    AS_ = AS(PRB, "figure from specialist memory (report footnote)")
    syms = [
        S("nz_nov", "Real", "Nazi vote, November 1932, per cent (33.1)", AS_),
        S("nz_prior", "Real", "Nazi vote at the earlier 1932 election (not stated in this claim; July 1932 value 37.3 appears in h1.2)", None),
        S("cm_nov", "Real", "Communist vote, November 1932, per cent (16.9)", AS_),
        S("cm_28", "Real", "Communist vote, 1928, per cent (10.6)", AS_),
        S("recov", "Bool", "the economy began to recover in 1932", AS_),
        S("distress_not", "Bool", "distress alone did not decide where votes went", SI("possible", "hedged in the claim ('suggesting')")),
    ]
    prems = [
        A("f1", eq(v("nz_nov"), r("33.1")), "the Nazi vote fell to 33.1 per cent in November 1932", AS_),
        A("f2", eq(v("cm_nov"), r("16.9")), "the Communist vote reached 16.9 per cent in November 1932", AS_),
        A("f3", eq(v("cm_28"), r("10.6")), "against 10.6 per cent in 1928", AS_),
        A("f4", v("recov"), "the economy began to recover", AS_),
        A("l1", IMP(AND(gt(v("cm_nov"), v("cm_28")), gt(v("nz_prior"), v("nz_nov")), v("recov")), v("distress_not")),
          "the Communist rise and Nazi fall during recovery suggest distress alone did not decide votes", SI("possible")),
    ]
    concl = AND(eq(v("nz_nov"), r("33.1")), gt(v("nz_prior"), v("nz_nov")), v("recov"),
                eq(v("cm_nov"), r("16.9")), eq(v("cm_28"), r("10.6")), gt(v("cm_nov"), v("cm_28")), v("distress_not"))
    p = build("hi-t1", "h1.5", syms, prems, concl,
              "The strongest counter-case is that the Nazi vote fell to 33.1 per cent in November 1932 as the economy began to recover, while the Communist vote reached 16.9 per cent in the same month, against 10.6 per cent in 1928, suggesting that distress alone did not decide where votes went.",
              SI("possible"),
              notes="nz_prior is deliberately unbound: 'fell to' needs the earlier Nazi vote, which this claim does not state. Entailment is expected to fail on that conjunct.")
    reading = ("Counter-case encoded as the claim's figures (assumption premises), the recovery (assumption), and one hedged inference (possible) that the Communist rise and Nazi fall suggest distress alone did not decide votes. "
               "'Fell' is relative to an earlier value the claim does not give, so the fall is left as an unbound conjunct rather than filled from h1.2.")
    flags = [
        F("unbound_baseline", "'fell to 33.1' needs the earlier Nazi vote; it is not stated in this claim", ["add the July 1932 value 37.3 from h1.2 as a premise", "leave unbound and report the fall as unsupported"]),
        F("hedged_conclusion", "'suggesting that' is hedged; encoded as a Bool with certainty possible, not established", ["strict: distress alone did not decide", "hedged: distress alone may not have decided"]),
        F("as_temporal_or_causal", "'as the economy began to recover' may be temporal or causal", ["temporal coincidence", "recovery caused the fall"]),
    ]
    return pack(p, reading, flags, True)

# =====================================================================
# hi-t2 (History)
# =====================================================================
def hi_t2_h11():
    AS_ = AS(PRB, "figure or date from specialist memory (report footnote)")
    syms = [
        S("coal_brk", "Bool", "the Grand Coalition under Müller broke on 27 March 1930 over whether to raise unemployment insurance contributions", AS_),
        S("unemp_rise", "Bool", "registered unemployment rose from about 1.4 million (1928) to about 3 million (September 1930)", AS_),
        S("dep_sharp", "Bool", "the Depression sharpened the contribution dispute that broke the coalition", SI(EST)),
        S("bruning", "Bool", "Brüning could not secure a majority; on 16 July 1930 the Reichstag overturned his emergency decree and was dissolved", AS_),
        S("pres_dep", "Bool", "from 14 September 1930 the Chancellor depended on presidential rather than parliamentary support", AS_),
        S("se28", "Int", "Nazi seats in 1928 (12)", AS_),
        S("se30", "Int", "Nazi seats on 14 September 1930 (107)", AS_),
        S("parl_coll", "Bool", "parliamentary government collapsed; rule by presidential decree replaced parliamentary majorities", SI(EST)),
        S("dec", "Bool", "the Depression was the decisive trigger of the collapse of parliamentary government", SI(EST)),
        S("not_sole", "Bool", "the Depression was not the sole cause of the collapse", SI(EST, "asserted in the point; the structural case is in h2.1, not in this claim's supports")),
    ]
    prems = [
        A("f_coal", v("coal_brk"), "the Grand Coalition broke over unemployment insurance contributions on 27 March 1930", AS_),
        A("f_unemp", v("unemp_rise"), "unemployment rose from about 1.4 million to about 3 million", AS_),
        A("f_bruning", v("bruning"), "Brüning lacked a majority; the Reichstag overturned his decree and was dissolved", AS_, "supporting"),
        A("f_pres", v("pres_dep"), "the Chancellor depended on presidential support from September 1930", AS_),
        A("f_se28", eq(v("se28"), i(12)), "twelve Nazi seats in 1928", AS_),
        A("f_se30", eq(v("se30"), i(107)), "107 Nazi seats on 14 September 1930", AS_),
        A("l1", IMP(AND(v("coal_brk"), v("unemp_rise")), v("dep_sharp")), "the rising unemployment sharpened the dispute that broke the coalition", SI(EST)),
        A("l2", IMP(AND(v("bruning"), v("pres_dep"), gt(v("se30"), v("se28"))), v("parl_coll")),
          "the seat jump and presidential reliance (with Brüning's lack of majority) mark the collapse of parliamentary government", SI(EST)),
        A("l3", IMP(AND(v("dep_sharp"), v("parl_coll")), v("dec")), "the Depression was the decisive trigger of the collapse", SI(EST)),
    ]
    p = build("hi-t2", "h1.1", syms, prems, AND(v("dec"), v("not_sole")),
              "The Depression was the decisive trigger of the collapse of parliamentary government, but not its sole cause.",
              SI(EST),
              notes="not_sole has no premise among h1.1's listed supports (h1.2-h1.4); the structural counter-case that would support it is h2.1 in the same report. Entailment is expected to fail on that conjunct.")
    reading = ("Point encoded from its listed supports h1.2-h1.4 (dates and figures as assumption premises, the causal steps as separate implications). "
               "'Decisive trigger' is the chain from the Depression-driven dispute to the collapse. 'But not its sole cause' is conjoined in the conclusion without any listed support.")
    flags = [
        F("trigger_vs_cause", "'decisive trigger' (a precipitating event) and 'decisive cause' (a necessary condition) require different links", ["trigger: precipitating event that started the collapse", "cause: necessary condition of the collapse"]),
        F("qualifier_unsupported", "'but not its sole cause' has no premise among h1.1's listed supports", ["add the structural case from h2.1", "leave unsupported and report the gap"]),
    ]
    return pack(p, reading, flags, True)

def hi_t2_h12():
    AS_ = AS(PRB, "date or figure from specialist memory (report footnote)")
    SI_ = SI(EST)
    syms = [
        S("coal_brk", "Bool", "the Grand Coalition under Hermann Müller broke on 27 March 1930 over whether to raise unemployment insurance contributions", AS_),
        S("sharp", "Bool", "the dispute was sharpened by unemployment", SI_),
        S("u28", "Real", "registered unemployment in 1928, millions (about 1.4)", AS_),
        S("u30", "Real", "unemployment in September 1930, millions (about 3)", AS_),
    ]
    prems = [
        A("f_coal", v("coal_brk"), "the Grand Coalition broke on 27 March 1930 over unemployment insurance contributions", AS_),
        A("f_u28", eq(v("u28"), r("1.4")), "unemployment was about 1.4 million in 1928", AS_),
        A("f_u30", eq(v("u30"), r("3")), "unemployment was about 3 million by September 1930", AS_),
        A("l1", IMP(AND(v("coal_brk"), lt(v("u28"), v("u30"))), v("sharp")), "unemployment that had risen sharpened the contribution dispute", SI_),
    ]
    concl = AND(v("coal_brk"), v("sharp"), eq(v("u28"), r("1.4")), eq(v("u30"), r("3")), lt(v("u28"), v("u30")))
    p = build("hi-t2", "h1.2", syms, prems, concl,
              "On 27 March 1930 the Grand Coalition under Hermann Müller broke over whether to raise unemployment insurance contributions, a dispute sharpened by unemployment that had risen from about 1.4 million in 1928 to about 3 million by September 1930.",
              SI_)
    reading = ("Dated evidence claim with a causal clause ('sharpened by'), encoded as an implication from the break plus a rising unemployment comparison. The dates and figures are assumption premises from specialist memory.")
    flags = [
        F("vague_quantities", "'about 1.4 million' and 'about 3 million' have no stated tolerance; encoded as literal values", ["exact values", "tolerance band"]),
    ]
    return pack(p, reading, flags, True)

def hi_t2_h14():
    AS_ = AS(PRB, "date or figure from specialist memory (report footnote: check your notes)")
    syms = [
        S("se30", "Int", "Nazi seats returned by the 14 September 1930 election (107)", AS_),
        S("se28", "Int", "Nazi seats in 1928 (12)", AS_),
        S("pres", "Bool", "from 14 September 1930 the Chancellor depended on presidential rather than parliamentary support", AS_),
        S("nomaj", "Bool", "in 1932 Franz von Papen and then Kurt von Schleicher governed without a majority", AS_),
    ]
    prems = [
        A("f1", eq(v("se30"), i(107)), "the 14 September 1930 election returned 107 Nazi seats", AS_),
        A("f2", eq(v("se28"), i(12)), "12 Nazi seats in 1928", AS_),
        A("f3", v("pres"), "the Chancellor depended on presidential support from then on", AS_),
        A("f4", v("nomaj"), "von Papen and then von Schleicher governed without a majority in 1932", AS_),
    ]
    concl = AND(eq(v("se30"), i(107)), eq(v("se28"), i(12)), gt(v("se30"), v("se28")), v("pres"), v("nomaj"))
    p = build("hi-t2", "h1.4", syms, prems, concl,
              "The election of 14 September 1930 returned 107 Nazi seats, against 12 in 1928, and from then on the Chancellor depended on presidential rather than parliamentary support, and in 1932 Franz von Papen and then Kurt von Schleicher governed without a majority.",
              SI(EST))
    reading = ("Figures and dates from memory (the claim itself flags them), encoded as assumption premises with probable certainty, not established. The seat rise is checked by the solver (12 < 107). Parenthetical disclaimer is not encoded as a premise.")
    return pack(p, reading, [], False)

def hi_t2_h21():
    AS_ = AS(PRB, "date from specialist memory (report footnote)")
    SI_ = SI(EST)
    syms = [
        S("sflaw", "Bool", "proportional representation, the Article 48 emergency power and unwilling parties existed in 1919", AS_),
        S("surv", "Bool", "the system survived the 1923 crisis without ending parliamentary government", AS_),
        S("scounter", "Bool", "the strongest counter-case to the Depression thesis is structural", SI_),
        S("weak", "Bool", "the structural case weighs less by timing: the flaws became decisive only when the crisis made majorities impossible", SI_),
        S("brun", "Bool", "Brüning's deflation deepened the slump but was a response to the Depression, not an independent cause", SI_),
        S("colldep", "Bool", "the collapse was caused by the Depression to a large extent, working through a constitution the parties would not make function", SI_),
    ]
    prems = [
        A("f_flaw", v("sflaw"), "structural flaws existed in 1919", AS_),
        A("f_surv", v("surv"), "the system survived 1923 without ending parliamentary government", AS_, "supporting"),
        A("l1", IMP(v("sflaw"), v("scounter")), "the structural flaws are the strongest counter-case to the Depression thesis", SI_),
        A("f_weak", v("weak"), "the structural case weighs less by the criterion of timing", SI_, "supporting"),
        A("f_brun", v("brun"), "Brüning's policy was a response to the Depression", SI_, "supporting"),
        A("f_colldep", v("colldep"), "the Depression caused the collapse to a large extent", SI_, "supporting"),
    ]
    p = build("hi-t2", "h2.1", syms, prems, v("scounter"),
              "The strongest counter-case is structural.", SI_,
              notes="Supports h2.3-h2.5 weigh the structural case less and do not feed the point; they are carried as supporting premises. The 1923 survival clause cuts against a structural cause and has no stated link.")
    reading = ("Point encoded from its listed supports h2.2-h2.5. The only stated link is from the structural flaws to the counter-case. The judgements h2.3-h2.5 weigh the counter-case down and are carried as supporting premises. "
               "'Strongest' is the point's own word and is not separately encoded.")
    flags = [
        F("strongest_vs_weighs_less", "h2.3 says the structural case 'weighs less', which sits uneasily with calling it the strongest counter-case", ["'strongest counter-case' (as written)", "a counter-case that weighs less (h2.3)"]),
        F("survival_clause_direction", "the 1923 survival clause supports the Depression's sufficiency, not the structural counter-case, and no link from it is stated", ["carry as a supporting premise only (as encoded)", "treat as a rebuttal to the counter-case"]),
    ]
    return pack(p, reading, flags, True)

def hi_t2_h22():
    AS_ = AS(PRB, "date or institutional fact from specialist memory (report footnote)")
    syms = [
        S("pr19", "Bool", "proportional representation existed in 1919", AS_),
        S("a48", "Bool", "the Article 48 emergency power existed in 1919", AS_),
        S("unw", "Bool", "parties unwilling to compromise existed in 1919", AS_),
        S("surv", "Bool", "the system survived the crisis of 1923 without ending parliamentary government", AS_),
    ]
    prems = [
        A("f1", v("pr19"), "proportional representation existed in 1919", AS_),
        A("f2", v("a48"), "the Article 48 emergency power existed in 1919", AS_),
        A("f3", v("unw"), "parties unwilling to compromise existed in 1919", AS_),
        A("f4", v("surv"), "the system survived the 1923 crisis without ending parliamentary government", AS_),
    ]
    p = build("hi-t2", "h2.2", syms, prems, AND(v("pr19"), v("a48"), v("unw"), v("surv")),
              "Proportional representation, the emergency power of Article 48 and parties unwilling to compromise all existed in 1919, and the system had survived the crisis of 1923 without ending parliamentary government.",
              SI(EST))
    reading = ("Dated institutional facts from memory, encoded as assumption premises; the conclusion is their conjunction. The entailment checks only the encoding, not the facts.")
    return pack(p, reading, [], False)

# =====================================================================
# en-t1 and en-t2 (English A, supplied text doc-cdf)
# =====================================================================
def en_p2_t1():
    syms = [
        S("hom", "Bool", "the text says 'homicide in legitimate defense of honor'", QU("homicide in legitimate defense of honor")),
        S("leg", "Bool", "the text uses the word 'legitimate'", QU("legitimate")),
        S("gf", "Bool", "the text says the court upheld the thesis 'in good faith'", QU("in good faith")),
        S("juxt", "Bool", "the phrase juxtaposes a legal doctrine with a social code", SI()),
        S("legmean", "Bool", "'legitimate' conventionally denotes what is lawful or justified by recognised rules", SI()),
        S("attach", "Bool", "'legitimate' attaches to honour, a standing within the community rather than a physical danger", SI()),
        S("lawauth", "Bool", "the adjective lends the authority of law to the code of honour", SI()),
        S("sincere", "Bool", "'in good faith' denotes a phrase of sincere belief", SI()),
        S("honest", "Bool", "the expectation shapes honest judgement rather than corrupting it", SI()),
        S("codedec", "Bool", "the community's code of honour decides what the law recognises as a defence", SI()),
        S("hard", "Bool", "the court's sincerity makes the code's influence hard to detect", SI()),
    ]
    prems = [
        A("ev_hom", v("hom"), "the lawyer's thesis of homicide in legitimate defense of honor", QU("homicide in legitimate defense of honor")),
        A("ev_leg", v("leg"), "the key word 'legitimate'", QU("legitimate")),
        A("ev_gf", v("gf"), "the court upheld the thesis 'in good faith'", QU("in good faith")),
        A("l_juxt", IMP(v("hom"), v("juxt")), "the killing is recast as a phrase juxtaposing legal doctrine with social code", SI()),
        A("l_legmean", IMP(v("leg"), v("legmean")), "'legitimate' denotes what is lawful or justified by recognised rules", SI()),
        A("p_attach", v("attach"), "here 'legitimate' attaches to honour, a community standing", SI()),
        A("l_law", IMP(AND(v("legmean"), v("attach")), v("lawauth")), "so the adjective lends the authority of law to the code of honour", SI()),
        A("l_sinc", IMP(v("gf"), v("sincere")), "'in good faith' is a phrase of sincere belief", SI()),
        A("l_hon", IMP(v("sincere"), v("honest")), "this sincerity matters: the expectation shapes honest judgement", SI(), "supporting"),
        A("l_code", IMP(AND(v("juxt"), v("lawauth")), v("codedec")), "the code decides what the law recognises as a defence", SI()),
        A("l_hard", IMP(AND(v("sincere"), v("codedec")), v("hard")), "the court's sincerity makes this influence hard to detect", SI(), "supporting"),
    ]
    p = build("en-t1", "p2-point", syms, prems, v("codedec"),
              "The lawyer's thesis shows this first: the community's code of honour, not the act, decides what the law recognises as a defence.",
              SI(PRB))
    reading = ("Point encoded from its supports. Quotations are verbatim spans of doc-cdf. Interpretive steps are specialist_inference implications, one per specialist link. "
               "'This' is read as the code-decides mechanism, the nearest content the supporting chain yields; the paragraph's governing thesis is the other reading. "
               "The honest and hard steps are supports that do not feed the point as written and are carried as supporting premises.")
    flags = [
        F("pronoun_this", "'shows this first' has no explicit referent; it may point to the paragraph's governing thesis or to the code-decides mechanism encoded here", ["the governing thesis of the paragraph (p1-s01)", "the code-decides mechanism (as encoded)"]),
    ]
    return pack(p, reading, flags, True)

def en_p3_t1():
    syms = [
        S("maj", "Bool", "the text says 'For the immense majority of people there was only one victim: Bayardo San Roman.'", QU("For the immense majority of people there was only one victim: Bayardo San Roman.")),
        S("vic", "Bool", "the text uses the word 'victim'", QU("victim")),
        S("lost", "Bool", "the text says of Bayardo 'who had lost everything'", QU("who had lost everything")),
        S("vicden", "Bool", "'victim' conventionally denotes the person harmed, here the man who was killed", SI()),
        S("reassign", "Bool", "the majority gives the word 'victim' to Bayardo, the one who had lost everything", SI()),
        S("harm", "Bool", "harm is measured by social standing rather than by the death", SI()),
        S("expw", "Bool", "the text uses the verb 'expiated'", QU("expiated")),
        S("ins", "Bool", "the text uses 'the insult'", QU("the insult")),
        S("expmean", "Bool", "to expiate conventionally means to atone for guilt, often through ritual", SI()),
        S("payment", "Bool", "Santiago Nasar's death is a payment that cancels 'the insult'", SI()),
        S("proved", "Bool", "the text says the brothers 'had proved their status as men'", QU("had proved their status as men")),
        S("honorb", "Bool", "the text says the sister was 'in possession of her honor once more'", QU("in possession of her honor once more")),
        S("ledger", "Bool", "justice becomes a ledger in which a life settles a reputation", SI()),
        S("social", "Bool", "the town's idea of the victim is a social verdict rather than an assessment of the crime", SI()),
    ]
    prems = [
        A("ev_maj", v("maj"), "for the immense majority there was only one victim: Bayardo San Roman", QU("For the immense majority of people there was only one victim: Bayardo San Roman.")),
        A("ev_vic", v("vic"), "the word 'victim'", QU("victim")),
        A("ev_lost", v("lost"), "Bayardo 'who had lost everything'", QU("who had lost everything")),
        A("p_vicden", v("vicden"), "'victim' conventionally denotes the person harmed", SI()),
        A("l_reassign", IMP(AND(v("maj"), v("vic"), v("lost"), v("vicden")), v("reassign")), "yet the majority gives the word to Bayardo, the one who had lost everything", SI()),
        A("l_harm", IMP(v("reassign"), v("harm")), "this semantic inversion suggests harm is measured by social standing", SI()),
        A("ev_expw", v("expw"), "the verb 'expiated'", QU("expiated")),
        A("ev_ins", v("ins"), "'the insult'", QU("the insult")),
        A("p_expmean", v("expmean"), "to expiate means to atone for guilt, often through ritual", SI()),
        A("l_pay", IMP(AND(v("expw"), v("expmean"), v("ins")), v("payment")), "Santiago Nasar's death is a payment that cancels the insult", SI()),
        A("ev_proved", v("proved"), "the brothers 'had proved their status as men'", QU("had proved their status as men")),
        A("ev_honorb", v("honorb"), "the sister 'in possession of her honor once more'", QU("in possession of her honor once more")),
        A("l_ledger", IMP(AND(v("proved"), v("honorb"), v("payment")), v("ledger")), "justice becomes a ledger in which a life settles a reputation", SI()),
        A("l_social", IMP(AND(v("harm"), v("ledger")), v("social")), "the reader is positioned to see the town's idea of the victim as a social verdict", SI()),
    ]
    p = build("en-t1", "p3-point", syms, prems, v("social"),
              "The town's verdict follows the same logic: a social verdict on honour rather than an assessment of the crime.",
              SI(PRB))
    reading = ("Point encoded from its eight quotation and interpretive supports. The majority's sentence is a verbatim quotation (its restatement in p3-s02 is the same span). "
               "The chain runs: 'victim' reassigned to Bayardo, harm measured by standing, the expiation ledger, then the social verdict.")
    flags = [
        F("same_logic_referent", "'follows the same logic' does not state which logic; it may mean the court's honour-governed reasoning (p2) or the social-verdict reading encoded here", ["the court's honour-governed logic (p2)", "social verdict rather than assessment of the crime (as encoded)"]),
    ]
    return pack(p, reading, flags, True)

def en_p4_t1():
    syms = [
        S("court_acc", "Bool", "the text says the court upheld the thesis in good faith", QU("which was upheld by the court in good faith")),
        S("maj_r", "Bool", "the majority reassigned the victim to Bayardo (the p3-point reading)", SI()),
        S("measure", "Bool", "both institutions measure the killing by the reputation it was believed to restore", SI()),
        S("subord", "Bool", "justice is presented as subordinate to honour", SI()),
        S("reproduces", "Bool", "the legal process reproduces communal judgement", SI()),
        S("not_tests", "Bool", "the legal process does not test the act against law", SI()),
    ]
    prems = [
        A("ev_court", v("court_acc"), "the court upheld the thesis in good faith", QU("which was upheld by the court in good faith")),
        A("p_maj", v("maj_r"), "the majority's reassignment of the victim (stated in the point; chain in p3-point)", SI()),
        A("l_measure", IMP(AND(v("court_acc"), v("maj_r")), v("measure")), "both institutions measure the killing by reputation", SI()),
        A("l_subord", IMP(v("measure"), v("subord")), "the extract therefore presents justice as subordinate to honour", SI()),
        A("l_together", IMP(AND(v("subord"), v("court_acc"), v("maj_r")), AND(v("reproduces"), v("not_tests"))),
          "together, these show the legal process reproduces communal judgement rather than testing the act against law", SI()),
    ]
    concl = AND(v("reproduces"), v("not_tests"))
    p = build("en-t1", "p4-point", syms, prems, concl,
              "Together, the court's acceptance of the thesis and the majority's reassignment of the victim show that the legal process reproduces communal judgement rather than testing the act against law.",
              SI(PRB))
    reading = ("Point encoded from its stated bases (the court's acceptance and the majority's reassignment, as named in the point) and its one listed support p4-s02. "
               "The 'rather than testing the act against law' clause is a separate conjunct.")
    return pack(p, reading, [], False)

def en_p1_t1():
    syms = [
        S("p2p", "Bool", "p2-point: the code of honour, not the act, decides what the law recognises as a defence", SI(PRB)),
        S("p3p", "Bool", "p3-point: the town's verdict is a social verdict following the same logic", SI(PRB)),
        S("p4p", "Bool", "p4-point: the legal process reproduces communal judgement rather than testing the act against law", SI(PRB)),
        S("thesis", "Bool", "justice is governed less by the act than by the community's honour expectations; court and town reach the same verdict by different routes", SI(PRB)),
    ]
    prems = [
        A("sup_p2", v("p2p"), "the lawyer's thesis shows the code decides the legal defence (p2-point)", SI(PRB)),
        A("sup_p3", v("p3p"), "the town's verdict follows the same logic (p3-point)", SI(PRB)),
        A("sup_p4", v("p4p"), "the legal process reproduces communal judgement (p4-point)", SI(PRB)),
        A("l_thesis", IMP(AND(v("p2p"), v("p3p"), v("p4p")), v("thesis")), "the three points together establish the thesis", SI(PRB)),
    ]
    p = build("en-t1", "p1-s01", syms, prems, v("thesis"),
              "García Márquez presents the administration of justice as governed less by the act itself than by the community's expectations of honour, so that the court and the town reach the same verdict by different routes.",
              SI(PRB))
    reading = ("Thesis encoded from its three supporting points as premises (specialist_inference, each as the point's own encoding states it), joined by one conjunctive implication, since the report lists them jointly.")
    return pack(p, reading, [], False)

def en_p2_t2():
    syms = [
        S("conf", "Bool", "the declaration admits the killing: 'We killed him openly,'", QU("We killed him openly,")),
        S("innoc", "Bool", "the declaration claims innocence: 'but we're innocent.'", QU("but we're innocent.")),
        S("killed", "Bool", "the text uses the verb 'killed'", QU("killed")),
        S("but_w", "Bool", "the text uses the conjunction 'but'", QU("but")),
        S("side", "Bool", "confession and innocence stand side by side in one sentence", SI()),
        S("openly_w", "Bool", "the text uses the adverb 'openly'", QU("openly")),
        S("candour", "Bool", "'openly' means publicly and without concealment, carrying connotations of candour and moral transparency", SI()),
        S("cancel", "Bool", "candour makes the confession appear to cancel culpability", SI()),
        S("ppb", "Bool", "the priest replies 'Perhaps before God'", QU("Perhaps before God")),
        S("defer", "Bool", "the priest's reply defers judgement to God rather than settling it", SI()),
        S("test", "Bool", "the reader is encouraged to test the claim rather than accept it", SI()),
        S("sep", "Bool", "the declaration makes the separation of guilt and innocence explicit", SI()),
    ]
    prems = [
        A("ev_conf", v("conf"), "'We killed him openly,'", QU("We killed him openly,")),
        A("ev_innoc", v("innoc"), "'but we're innocent.'", QU("but we're innocent.")),
        A("ev_killed", v("killed"), "the verb 'killed' carries the admission", QU("killed")),
        A("ev_but", v("but_w"), "the conjunction 'but' sets a denial against it", QU("but")),
        A("l_side_a", IMP(AND(v("conf"), v("innoc")), v("side")), "confession and innocence in one sentence", SI()),
        A("l_side_b", IMP(AND(v("killed"), v("but_w")), v("side")), "the paradox turns on 'killed' and 'but'", SI()),
        A("ev_openly", v("openly_w"), "the adverb 'openly'", QU("openly")),
        A("l_candour", IMP(v("openly_w"), v("candour")), "'openly' carries connotations of candour and moral transparency", SI()),
        A("l_cancel", IMP(v("candour"), v("cancel")), "candour lends the confession a virtue, so it appears to cancel culpability", SI()),
        A("ev_ppb", v("ppb"), "the priest's reply 'Perhaps before God'", QU("Perhaps before God"), "supporting"),
        A("l_defer", IMP(v("ppb"), v("defer")), "the reply defers judgement to God", SI(), "supporting"),
        A("l_test", IMP(AND(v("cancel"), v("defer")), v("test")), "the reader is encouraged to test the claim", SI(), "supporting"),
        A("l_sep", IMP(AND(v("side"), v("cancel")), v("sep")), "the twins' declaration makes this separation explicit", SI()),
    ]
    p = build("en-t2", "p2-point", syms, prems, v("sep"),
              "The twins' declaration makes this separation explicit: confession and claimed innocence stand together, separating guilt from innocence.",
              SI(PRB),
              notes="The s06 chain (reader tests the claim; priest defers judgement) is a listed support but does not feed the point as written; carried as supporting premises.")
    reading = ("Point encoded from its supports. Quotations are verbatim doc-cdf spans. The paradox, the candour step and the cancellation step are separate implications. "
               "'This separation' is read as the separation of guilt and innocence named in the thesis; the twins' declaration is the instance encoded here.")
    flags = [
        F("this_separation_referent", "'this separation' has no explicit antecedent in the point; it may refer to the separation of the two judgements in the thesis or to the declaration's own paradox", ["the separation of the two judgements in the thesis", "the paradox of confession and innocence (as encoded)"]),
        F("support_not_feeding", "p2-s06 (reader tests the claim; priest defers judgement) is listed as support but does not connect to the point as written", ["link it to the point (not stated by the specialist)", "carry as supporting premises only (as encoded)"]),
    ]
    return pack(p, reading, flags, True)

def en_p3_t2():
    syms = [
        S("clean", "Bool", "the twins laid the knives 'with clean blades,' on the priest's desk", QU("with clean blades,")),
        S("smear", "Bool", "the twins arrived with 'faces smeared with sweat and still living blood'", QU("faces smeared with sweat and still living blood")),
        S("traces", "Bool", "the traces of the act stay on their bodies while the weapons look clean", SI()),
        S("guilt_men", "Bool", "guilt is located in the men rather than in the instruments", SI()),
        S("barb_work", "Bool", "both twins were exhausted 'from the barbarous work of death'", QU("from the barbarous work of death")),
        S("narr_judg", "Bool", "the narration passes judgement on the twins", SI()),
        S("barb", "Bool", "the text uses the word 'barbarous'", QU("barbarous")),
        S("dign", "Bool", "the priest recalls the surrender as 'an act of great dignity'", QU("an act of great dignity")),
        S("barb_cruel", "Bool", "'barbarous' conventionally denotes savage cruelty", SI()),
        S("uneasy", "Bool", "the condemnation sits uneasily with the priest's view of the surrender", SI()),
        S("visible", "Bool", "the reader holds the twins' appearance against the act their bodies record, so visible guilt persists beneath declared innocence", SI()),
        S("works", "Bool", "the physical detail works against the declared innocence", SI()),
    ]
    prems = [
        A("ev_clean", v("clean"), "the knives 'with clean blades,'", QU("with clean blades,")),
        A("ev_smear", v("smear"), "'faces smeared with sweat and still living blood'", QU("faces smeared with sweat and still living blood")),
        A("l_traces", IMP(AND(v("clean"), v("smear")), v("traces")), "the traces stay on their bodies while the weapons look clean", SI()),
        A("l_guilt", IMP(v("traces"), v("guilt_men")), "this contrast locates guilt in the men rather than the instruments", SI()),
        A("ev_barbwork", v("barb_work"), "'from the barbarous work of death'", QU("from the barbarous work of death")),
        A("l_narr", IMP(v("barb_work"), v("narr_judg")), "the narration passes judgement", SI()),
        A("ev_barb", v("barb"), "the word 'barbarous'", QU("barbarous")),
        A("l_cruel", IMP(v("barb"), v("barb_cruel")), "'barbarous' conventionally denotes savage cruelty", SI()),
        A("ev_dign", v("dign"), "the surrender as 'an act of great dignity'", QU("an act of great dignity")),
        A("l_uneasy", IMP(AND(v("barb_cruel"), v("dign")), v("uneasy")), "the condemnation sits uneasily with the priest's view", SI()),
        A("l_visible", IMP(AND(v("guilt_men"), v("narr_judg")), v("visible")), "the reader is positioned to hold appearance against the act recorded by the bodies", SI()),
        A("l_works", IMP(AND(v("guilt_men"), v("visible"), v("uneasy")), v("works")), "the physical detail works against that declared innocence", SI()),
    ]
    p = build("en-t2", "p3-point", syms, prems, v("works"),
              "The physical detail works against that declared innocence.",
              SI(PRB),
              notes="Excerpt for the claim's p3-q03 is the verbatim span 'from the barbarous work of death' without the trailing period quoted in the claim, because the source continues with a comma there.")
    reading = ("Point encoded from its supports. The excerpt for p3-q03 is the exact source span (the claim adds a period the source does not have). Each interpretive step is a separate specialist_inference implication. "
               "'That declared innocence' is not restated in p3's supports; it is left as the referent in the point's meaning.")
    flags = [
        F("declared_innocence_referent", "'that declared innocence' refers to the twins' claim 'but we're innocent' (p2), which is not among p3's supports", ["the twins' declared innocence (p2 quotation)", "the verdict of innocence from court and town"]),
    ]
    return pack(p, reading, flags, True)

def en_p4_t2():
    syms = [
        S("p2p", "Bool", "p2-point: the twins' declaration makes the separation explicit", SI(PRB)),
        S("p3p", "Bool", "p3-point: the physical detail works against the declared innocence", SI(PRB)),
        S("blame", "Bool", "the text says 'we all could have been to blame'", QU("we all could have been to blame")),
        S("spread", "Bool", "the narrator's observation spreads culpability across the community", SI()),
        S("redistr", "Bool", "guilt is redistributed rather than cancelled", SI()),
        S("narr_keeps", "Bool", "the narrative detail keeps the killing's guilt in view", SI()),
        S("phys_keeps", "Bool", "the physical detail keeps the killing's guilt in view", SI()),
        S("honour_rest", "Bool", "the verdicts of innocence from court and town rest on honour", SI(EST, "asserted in the point; no listed support in this report establishes it")),
    ]
    prems = [
        A("sup_p2", v("p2p"), "the twins' declaration makes the separation explicit (p2-point)", SI(PRB), "supporting"),
        A("sup_p3", v("p3p"), "the physical detail works against the declared innocence (p3-point)", SI(PRB)),
        A("ev_blame", v("blame"), "'we all could have been to blame'", QU("we all could have been to blame")),
        A("l_spread", IMP(v("blame"), v("spread")), "the narrator's observation spreads culpability across the community", SI()),
        A("l_redistr", IMP(v("spread"), v("redistr")), "guilt is redistributed rather than cancelled", SI()),
        A("l_narr", IMP(v("redistr"), v("narr_keeps")), "the reader is left to weigh a declared innocence against a guilt the text refuses to erase", SI()),
        A("l_phys", IMP(v("p3p"), v("phys_keeps")), "the physical detail keeps the guilt visible", SI()),
    ]
    concl = AND(v("honour_rest"), v("narr_keeps"), v("phys_keeps"))
    p = build("en-t2", "p4-point", syms, prems, concl,
              "Together, these strands show that the verdicts of innocence from court and town rest on honour, whereas the extract's physical and narrative detail keeps the killing's guilt in view.",
              SI(PRB),
              notes="honour_rest has no premise: the point asserts that the verdicts rest on honour, and no listed support (p4-q01, p4-s02, p4-s03) or stated strand establishes it. Entailment is expected to fail on that conjunct.")
    reading = ("Point encoded from its stated bases ('these strands': the p2 and p3 points, and the narrator's observation) and its listed supports. "
               "The honour clause is asserted with no premise; it is kept as an unsupported conjunct rather than filled in, so the gap shows.")
    flags = [
        F("these_strands_referent", "'these strands' could mean the p2 and p3 points or only the narrative observation in p4's supports", ["the p2 and p3 points (as encoded as premises)", "the narrative observation alone"]),
        F("unsupported_honour_clause", "'the verdicts ... rest on honour' has no listed support in this report", ["add a support (not supplied)", "report the unsupported conjunct (as encoded)"]),
    ]
    return pack(p, reading, flags, True)

def en_p1_t2():
    syms = [
        S("p2p", "Bool", "p2-point: the twins' declaration makes the separation of guilt and innocence explicit", SI(PRB)),
        S("p3p", "Bool", "p3-point: the physical detail works against the declared innocence", SI(PRB)),
        S("p4p", "Bool", "p4-point: verdicts of innocence rest on honour, while detail keeps the killing's guilt in view", SI(PRB)),
        S("thesis", "Bool", "the reader's view of guilt and innocence is constructed by separating the two judgements; court and town grant innocence while the extract keeps guilt visible", SI(PRB)),
    ]
    prems = [
        A("sup_p2", v("p2p"), "the declaration makes the separation explicit (p2-point)", SI(PRB)),
        A("sup_p3", v("p3p"), "the physical detail works against the declared innocence (p3-point)", SI(PRB)),
        A("sup_p4", v("p4p"), "verdicts rest on honour and detail keeps guilt in view (p4-point)", SI(PRB)),
        A("l_thesis", IMP(AND(v("p2p"), v("p3p"), v("p4p")), v("thesis")), "the three points together establish the thesis", SI(PRB)),
    ]
    p = build("en-t2", "p1-s01", syms, prems, v("thesis"),
              "García Márquez constructs the reader's view of guilt and innocence by separating the two judgements, so that the court and the town grant the twins innocence while the extract keeps their guilt physically and morally visible.",
              SI(PRB),
              notes="Entailment here takes p4-point as a premise; p4-point's own problem reports its unsupported honour clause, so this result inherits that gap.")
    reading = ("Thesis encoded from its three supporting points as premises, joined by one conjunctive implication. The p4-point premise carries the unsupported honour clause from its own problem.")
    return pack(p, reading, [], False)

BUILDERS = {
    ("hi-t1", "h1.1"): hi_t1_h11, ("hi-t1", "h1.2"): hi_t1_h12, ("hi-t1", "h1.4"): hi_t1_h14, ("hi-t1", "h1.5"): hi_t1_h15,
    ("hi-t2", "h1.1"): hi_t2_h11, ("hi-t2", "h1.2"): hi_t2_h12, ("hi-t2", "h1.4"): hi_t2_h14,
    ("hi-t2", "h2.1"): hi_t2_h21, ("hi-t2", "h2.2"): hi_t2_h22,
    ("en-t1", "p2-point"): en_p2_t1, ("en-t1", "p3-point"): en_p3_t1, ("en-t1", "p4-point"): en_p4_t1, ("en-t1", "p1-s01"): en_p1_t1,
    ("en-t2", "p2-point"): en_p2_t2, ("en-t2", "p3-point"): en_p3_t2, ("en-t2", "p4-point"): en_p4_t2, ("en-t2", "p1-s01"): en_p1_t2,
}

def walk_quotes(obj, text, found):
    if isinstance(obj, dict):
        if obj.get("kind") == "quotation":
            for ref in obj.get("source_refs", []):
                assert ref["document_id"] == "doc-cdf", ref
                assert ref["excerpt"] in text, f"EXCERPT NOT FOUND: {ref['excerpt']!r}"
                found.append(ref["excerpt"])
        for val in obj.values():
            walk_quotes(val, text, found)
    elif isinstance(obj, list):
        for x in obj:
            walk_quotes(x, text, found)

if __name__ == "__main__":
    summary = {}
    for task in ["hi-t1", "hi-t2", "en-t1", "en-t2"]:
        spec = json.load(open(f"{SPEC}/{task}.json", encoding="utf-8"))
        text = "\n".join(t["text"] for t in spec.get("supplied_texts", []))
        # eligible claim ids from list_claims output (passed in via file)
        elig = json.load(open(f"{SCR}/arena/r1/elig_{task}.json", encoding="utf-8"))
        ids = [c["claim_id"] for c in elig["claims"] if c["eligible"]]
        claims = {}
        for cid in ids:
            fn = BUILDERS.get((task, cid))
            if fn is None:
                print("MISSING BUILDER", task, cid, file=sys.stderr)
                continue
            obj = fn()
            found = []
            walk_quotes(obj["problem"], text, found)
            claims[cid] = obj
            summary.setdefault(task, []).append((cid, len(found)))
        assert set(claims) == set(ids), (task, set(ids) - set(claims))
        out = {"report_id": REP[task], "claims": claims}
        with open(f"{OUT}/{task}.json", "w", encoding="utf-8") as fh:
            json.dump(out, fh, ensure_ascii=False, indent=2)
        print(task, "wrote", len(claims), "claims; quotation excerpts verified:", summary[task])
