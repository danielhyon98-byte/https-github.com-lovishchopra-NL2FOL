#!/bin/bash
# Checkpoint for continuing this project in a fresh container.
#   make_checkpoint.sh build   -> local copy in $OUT: branch bundle, work in progress, journals, scratchpad tools and records
#   make_checkpoint.sh commit  -> pushes the dev tree plus checkpoint/$TAG/ to the backup branch checkpoint/$TAG on origin
#                                 (approved by Daniel; additive, fast-forward only). Temporary index: no checkout is touched.
set -euo pipefail
S=/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad
R=/home/user/https-github.com-lovishchopra-NL2FOL
WFDIR=/root/.claude/projects/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/subagents/workflows
DEV=claude/z3-verification-engine-plan-nk3luq
TAG=${CHECKPOINT_TAG:-2026-10-12}
OUT=/home/user/epinoic-checkpoint-$TAG
cd "$R"

build() {
  rm -rf "$OUT"; mkdir -p "$OUT/wip"
  # 1. Work in progress in any checkout: patches, merge state, untracked files, and (when the index has no
  #    conflicts) the staged index as a commit object under refs/checkpoint/, carried by the bundle.
  git for-each-ref --format='%(refname)' "refs/checkpoint/$TAG" | while read -r ref; do git update-ref -d "$ref"; done
  if [ -n "${NO_WIP:-}" ]; then echo "early checkpoint: agents were still editing; work in progress not captured" > "$OUT/wip/README.txt"; else
  git worktree list --porcelain | awk '/^worktree /{print $2}' | while read -r W; do
    case "$W" in "$S"/*) continue;; esac
    N=$(basename "$W"); [ "$W" = "$R" ] && N=main
    [ -z "$(git -C "$W" status --porcelain)" ] && continue
    D="$OUT/wip/$N"; mkdir -p "$D"
    G=$(git -C "$W" rev-parse --absolute-git-dir)
    git -C "$W" status --porcelain > "$D/status.txt"
    git -C "$W" rev-parse HEAD > "$D/HEAD"
    for f in MERGE_HEAD MERGE_MSG MERGE_MODE; do if [ -f "$G/$f" ]; then cp "$G/$f" "$D/$f"; fi; done
    git -C "$W" diff --cached --binary > "$D/staged.patch"
    git -C "$W" diff --binary > "$D/unstaged.patch"
    (cd "$W" && git ls-files --others --exclude-standard -z | tar --null -T - -cJf "$D/untracked.tar.xz")
    (cd "$W" && { git diff --name-only -z HEAD; git diff --name-only -z --cached HEAD; } | sort -zu | while IFS= read -r -d "" f; do [ -e "$f" ] && printf "%s\0" "$f"; done | tar --null -T - -cJf "$D/changed-files-on-disk.tar.xz")
    if T=$(git -C "$W" write-tree 2>/dev/null); then
      P=(-p "$(git -C "$W" rev-parse HEAD)")
      if [ -f "$G/MERGE_HEAD" ]; then while read -r mh; do [ -n "$mh" ] && P+=(-p "$mh"); done < "$G/MERGE_HEAD"; fi  # an octopus merge lists several heads
      C=$(git -C "$W" commit-tree "$T" "${P[@]}" -m "Work in progress at the $TAG checkpoint ($N): staged index, not a release")
      git update-ref "refs/checkpoint/$TAG/$N-staged" "$C"; echo "$C" > "$D/staged-commit"
    else
      echo "the index has unmerged paths; use staged.patch, unstaged.patch and status.txt" > "$D/staged-commit"
    fi
  done
  fi
  # 2. Local branches and checkpoint refs that origin does not already hold.
  git bundle create "$OUT/branches.bundle" $(git for-each-ref --format='%(refname)' refs/heads "refs/checkpoint/$TAG") --not "origin/$DEV"
  git branch -vv --no-color > "$OUT/branches.txt"; git worktree list > "$OUT/worktrees.txt"
  git for-each-ref --format='%(refname) %(objectname)' refs/heads "refs/checkpoint/$TAG" > "$OUT/branch-tips.txt"
  # 3. Workflow journals (the overseer publisher gates on them).
  mkdir -p "$OUT/local-only"; (cd "$WFDIR" && tar -cJf "$OUT/local-only/journals.tar.xz" */journal.jsonl)
  # 4. Untracked pipeline scripts beside the worktrees.
  tar -C "$R/.worktrees" -cJf "$OUT/worktree-scripts.tar.xz" scripts
  # 5. The scratchpad without regenerable environments, downloads and working copies.
  # Exit status 1 means only that a live work folder changed while it was read; the archive is complete otherwise.
  rc=0; tar -C "$S" -cJf "$OUT/local-only/scratchpad.tar.xz" --warning=no-file-changed --exclude=./z3venv --exclude=./cleanenv --exclude=./nodesmoke --exclude=./pipdl \
    --exclude=./zip_extract --exclude=./workerd_probe --exclude=./kb_v3 --exclude=./kb_v3_extract --exclude=./simtest \
    --exclude=./simtest-ovs --exclude='__pycache__' --exclude='./publisher-next/clone*' --exclude=./wf --exclude=./archives --exclude=./ovsmerge \
    --exclude='./arena-overseer/c1/export*' --exclude=./arena-overseer/c1/tamper-rounds --exclude=./arena-overseer/c1/dossiers \
    --exclude='*.whl' --exclude='./simcache/*.tmp' --exclude=./cp-measure . || rc=$?
  [ "$rc" -le 1 ] || { echo "scratchpad archive failed (tar exit $rc)"; exit "$rc"; }
  # 6. Small reports from the workflow working folders (no source copies).
  (cd "$S" && find wf -maxdepth 4 -type f -size -2M \( -name '*.json' -o -name '*.md' -o -name '*.txt' -o -name '*.js' \) -print0 \
    | tar --null -T - -cJf "$OUT/local-only/wf-reports.tar.xz")
  tar -C "$OUT" -cJf "$OUT/wip.tar.xz" wip
  # 7. Pushed tier: the project's own tools, instructions, run records, recorded rounds and round 8 data only.
  (cd "$S" && { find . -maxdepth 1 -type f \( -name '*.sh' -o -name '*.py' -o -name '*.js' -o -name '*.md' -o -name '*.json' -o -name 'rebuild-notes.txt' \); \
    find wf-scripts sim round8-prep clearance push-check simcache c1-design -type f -not -name '*.tmp' -not -path '*__pycache__*' 2>/dev/null; \
    find publisher-next -maxdepth 1 -type f \( -name '*.sh' -o -name '*.py' \); find publisher-next/tests -type f -name '*.py' 2>/dev/null; \
    find arena -mindepth 1 -maxdepth 1 -type d -name 'r[0-9]*'; \
    find KNOWLEDGE patches -type f -not -name '*.mjs' -not -name '*.json.tmp' 2>/dev/null; \
    find wf/argdiag/corpus wf/rerun-lenses/by-owner -type f -not -path '*__pycache__*' 2>/dev/null; \
    find wf/argdiag wf/rerun-lenses wf/integration-kit wf/prebuild wf/overseer-flash -maxdepth 1 -type f \( -name '*.md' -o -name '*.json' -o -name '*.txt' \) 2>/dev/null; \
    find wf/overseer-flash/tools wf/overseer-flash/compact -type f -size -5M 2>/dev/null; \
    find e2e -maxdepth 1 -type f 2>/dev/null; find e2e/run1 e2e/harness -type f -size -5M 2>/dev/null; } | tar -T - -cJf "$OUT/tools.tar.xz")
  cp "$S/RESUME.md" "$OUT/RESUME.md"
  (cd "$OUT" && sha256sum branches.bundle branch-tips.txt worktree-scripts.tar.xz tools.tar.xz wip.tar.xz RESUME.md > SHA256SUMS)
  git bundle verify "$OUT/branches.bundle" >/dev/null 2>&1 && echo "bundle verifies" || { echo "STOP: bundle does not verify"; exit 1; }
  du -sh "$OUT"/* "$OUT"/local-only/* | sort -h
}

commit() {
  local BASE IDX f sz blob T PREV C MSG i BR=checkpoint/$TAG
  git fetch -q origin "$DEV"
  BASE=$(git rev-parse "origin/$DEV")
  PREV=$(git ls-remote origin "refs/heads/$BR" | cut -f1)
  if [ -n "$PREV" ]; then git fetch -q origin "refs/heads/$BR"; PREV=$(git rev-parse FETCH_HEAD); fi
  IDX=$(mktemp); trap 'rm -f "$IDX"' RETURN
  GIT_INDEX_FILE=$IDX git read-tree "$BASE"
  for f in RESUME.md SHA256SUMS branches.txt branch-tips.txt worktrees.txt branches.bundle worktree-scripts.tar.xz tools.tar.xz wip.tar.xz; do
    sz=$(stat -c %s "$OUT/$f")
    if [ "$sz" -gt 90000000 ]; then
      rm -rf "$OUT/parts"; mkdir -p "$OUT/parts"; split -b 90m -d "$OUT/$f" "$OUT/parts/$f.part"
      for q in "$OUT/parts/$f".part*; do blob=$(git hash-object -w "$q"); GIT_INDEX_FILE=$IDX git update-index --add --cacheinfo "100644,$blob,checkpoint/$TAG/$(basename "$q")"; done
    else
      blob=$(git hash-object -w "$OUT/$f"); GIT_INDEX_FILE=$IDX git update-index --add --cacheinfo "100644,$blob,checkpoint/$TAG/$f"
    fi
  done
  T=$(GIT_INDEX_FILE=$IDX git write-tree)
  MSG=$(mktemp)
  printf '%s\n\n%s\n\n%s\n%s\n' "Checkpoint $TAG: resume state on $(git rev-parse --short "$BASE")" \
    "The dev branch tree at $(git rev-parse --short "$BASE") plus checkpoint/$TAG/: bundle of the local branches, saved work in progress, the pipeline and publisher tools, standing instructions, run records, recorded arena rounds, round 8 data, and RESUME.md. Backup branch only; never published." \
    "Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>" "Claude-Session: https://claude.ai/code/session_016YotQwcC83EEJm8zshdxtW" > "$MSG"
  C=$(git commit-tree "$T" -p "${PREV:-$BASE}" -F "$MSG"); rm -f "$MSG"
  for i in 0 2 4 8 16; do sleep "$i"; if timeout 600 git push origin "$C:refs/heads/$BR"; then break; fi; [ "$i" = 16 ] && { echo "STOP: push failed"; exit 1; }; done
  echo "checkpoint $C pushed to origin/$BR"; echo "$C" > "$OUT/CHECKPOINT_COMMIT"
}

case "${1:-}" in build) build;; commit) commit;; *) echo "usage: $0 build|commit"; exit 2;; esac
