#!/usr/bin/env bash
# Final release to the main repository (Bruno-ios/Epinoic-Logic-Translator), run once every assigned task has finished.
# Daniel's instruction: compare the final product with the code already on the main repository (phase 2 writes
# docs/FINAL_COMPARISON.md), back up the previous edit, and upload the updated final version labelled as such,
# given that all bug fixes have been implemented.
#
# Steps, each refusing rather than guessing:
#   1. readiness: scratchpad/release-readiness.json (written by phase 2) says all_bug_fixes_implemented=true;
#      the newest final candidate on the development branch is the "Final report: ..." commit.
#   2. backup of the previous edit: a git bundle of Bruno's refs in scratchpad/backups/, and a new branch on Bruno's
#      repository, backup/verified-updates-before-final, at the current verified-updates head.
#   3. the final version: publish_final.sh with the label "Final version" (same gates: green suite recorded, no harness
#      drop, tree = verified tree + import docs), an ordinary fast-forward push to verified-updates.
#   4. the label: a new branch "final" and an annotated tag "final-v1.0" at that commit.
# Every push is ordinary (no force, no mirror); existing refs are never moved or deleted; import/translator-baseline is
# never touched. Usage: release_final.sh [--dry-run]
set -euo pipefail
S=/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad
R=/home/user/https-github.com-lovishchopra-NL2FOL
DEV=claude/z3-verification-engine-plan-nk3luq
BASELINE=3147d08e0aa63d5eeaceb1072754f29e3862164d
DRY=${1:-}
cd "$R"

# 1. readiness
[ -f "$S/release-readiness.json" ] || { echo "HOLD: no release-readiness.json yet (phase 2 has not finished)"; exit 0; }
python3 -I - "$S/release-readiness.json" <<'EOF' || exit 0
import json, sys
r = json.load(open(sys.argv[1]))
if not r.get("all_bug_fixes_implemented"):
    print("HOLD: not every bug fix is implemented; open: " + "; ".join(r.get("open", []))[:2000]); sys.exit(1)
print("readiness: every bug fix implemented")
EOF
LATEST=$(git log --format='%H%x09%s' "$BASELINE..$DEV" | awk -F'\t' '$2 !~ /^WIP/ && $2 !~ /^Testing README/ {print; exit}')
case "$(printf '%s' "$LATEST" | cut -f2)" in
  "Final report: "*) ;;
  *) echo "HOLD: the newest commit is not the final report: $LATEST"; exit 0 ;;
esac
[ -z "$(git status --porcelain --untracked-files=no)" ] || { echo "HOLD: the development tree has uncommitted changes"; exit 0; }

# 2. backup of the previous edit
git fetch -q epinoic "+refs/heads/verified-updates:refs/remotes/epinoic/verified-updates" "+refs/heads/import/translator-baseline:refs/remotes/epinoic/import/translator-baseline"
PREV=$(git rev-parse refs/remotes/epinoic/verified-updates)
mkdir -p "$S/backups"
git bundle create -q "$S/backups/main-repository-before-final-${PREV:0:7}.bundle" refs/remotes/epinoic/verified-updates refs/remotes/epinoic/import/translator-baseline
echo "local backup: $S/backups/main-repository-before-final-${PREV:0:7}.bundle"
BK=backup/verified-updates-before-final
if git ls-remote --exit-code epinoic "refs/heads/$BK" >/dev/null 2>&1; then BK="$BK-${PREV:0:7}"; fi
if git ls-remote --exit-code epinoic "refs/heads/final" >/dev/null 2>&1 || git ls-remote --exit-code epinoic "refs/tags/final-v1.0" >/dev/null 2>&1; then
  echo "HOLD: a final branch or tag already exists on the main repository; not moving it"; exit 0
fi
if [ "$DRY" = "--dry-run" ]; then
  echo "DRY RUN: would push $PREV to refs/heads/$BK"
  PUBLISH_LABEL="Final version" bash "$S/publish_final.sh" --dry-run
  echo "DRY RUN: would then push branch final and tag final-v1.0 at the published commit"; exit 0
fi
git push epinoic "$PREV:refs/heads/$BK"
echo "backup branch on the main repository: $BK -> $PREV"

# 3. the final version
OUT=$(PUBLISH_LABEL="Final version" bash "$S/publish_final.sh" 2>&1) || { echo "$OUT"; echo "STOP: final publish failed; backup kept"; exit 1; }
echo "$OUT"
case "$OUT" in *HOLD*|*NOTHING*|*STOP*) echo "STOP: the final version was not published; backup kept"; exit 1 ;; esac
git fetch -q epinoic "+refs/heads/verified-updates:refs/remotes/epinoic/verified-updates"
NEWF=$(git rev-parse refs/remotes/epinoic/verified-updates)
[ "$(git log -1 --format=%s "$NEWF" | grep -c '^Final version: ')" -gt 0 ] || { echo "STOP: the verified-updates head is not labelled Final version"; exit 1; }

# 4. the label
git -c user.name=Claude -c user.email=noreply@anthropic.com tag -a final-v1.0 "$NEWF" -m "Final version of the Epinoic logic translator and Z3 verification engine

All assigned work finished and every bug fix implemented (release readiness recorded by the final pipeline).
Previous edit backed up as $BK ($PREV). Comparison with the code previously on this repository: docs/FINAL_COMPARISON.md.

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_016YotQwcC83EEJm8zshdxtW"
git push epinoic "refs/tags/final-v1.0"
git push epinoic "$NEWF:refs/heads/final"
git ls-remote epinoic "refs/heads/final" "refs/tags/final-v1.0" "refs/heads/$BK" "refs/heads/verified-updates"
echo "RELEASED: final-v1.0 = $NEWF (backup $BK = $PREV)"
