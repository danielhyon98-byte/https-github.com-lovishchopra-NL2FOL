import sys, time
from epinoic_logic.branches import RouterHub
from epinoic_logic.engine import SolverConfig
from epinoic_logic.integrity import WorkPlan
from epinoic_logic.overseer import EngineKey, KeyRing, TransferAuditor
subject, agent, k = sys.argv[1], sys.argv[2], int(sys.argv[3])
text = "The total is " + "one hundred and " * k + "five."
KEY = b"k" * 32
kr = KeyRing({x: EngineKey(KEY) for x in ("hub", "channel", "default", "integrity")}, b"s" * 40)
hub = RouterHub(signing_key=KEY, key_id="hub", config=SolverConfig(timeout_ms=8000, memory_max_mb=None),
                auditor=TransferAuditor(kr, replay_mode="inline", eager=True, shadow="always"))
hub.open_task(WorkPlan(plan_id="p", request_id="q", task_id="t", subject=subject, task_type="short_answer", selected_agent_ids=[agent]))
m, _, _ = hub.dispatch("t", agent, "Answer the question.")
_r, rc = hub.receive("t", m.message_id, text, agent_id=agent, report_id="r1")
a = hub.audit("t")
print(k, len(text), rc.status.value, a.state)
for f in a.report.findings:
    print(" ", f.code, f.severity, f.claim_ids, f.message[:400])
rep = hub.channels["t"].transmitted_reports["r1"] if hasattr(hub, "channels") else None
