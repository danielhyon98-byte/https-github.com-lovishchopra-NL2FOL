#!/usr/bin/env bash
# Prepare, ahead of the hour, the simulations the hourly push needs (Daniel: the hourly check and upload take at most
# 2 min 30 s). Writes simcache/translator-<source>.txt and simcache/overseer-<sha>.txt (atomically); skips what is cached.
#   translator: the source commit now published on verified-updates, and the newest final commit on the development branch
#   overseer:   the newest overseer-build commits after the last upload that pass overseer_gate.py (the rebuild
#               on the STEM-merged translator against the rebuild journal, every other commit against the build's)
# Prints one line per simulation it ran. Safe to run repeatedly (a lock prevents overlap).
set -uo pipefail
S=$(cd "$(dirname "$0")" && pwd)
R=/home/user/https-github.com-lovishchopra-NL2FOL
DEV=claude/z3-verification-engine-plan-nk3luq
BASELINE=3147d08e0aa63d5eeaceb1072754f29e3862164d
mkdir -p "$S/simcache"
exec 8>"$S/.presim.lock"; flock -n 8 || exit 0
cd "$R"
timeout 60 git fetch -q epinoic 2>/dev/null || true
run() {  # kind source-commit
  local f="$S/simcache/$1-$2.txt"
  # An overseer cache that predates the translator floor (no "harness: floor:" line) for a source that carries a merged
  # development translator is set aside and simulated again; the publisher holds such a cache.
  if [ -s "$f" ] && [ "$1" = overseer ] && [ -z "$(awk '/^harness: floor: /{print; exit}' "$f")" ] \
     && [ "$(python3 -I -c "import sys; sys.path.insert(0, sys.argv[1]); import overseer_gate as G; print('yes' if G.translator_merge(sys.argv[2], sys.argv[3]) else 'no')" "$S" "$R" "$2" 2>/dev/null)" = yes ]; then
    mv -f "$f" "$f.prefloor"
    echo "presim $1 $(git rev-parse --short "$2"): the cached simulation predates the translator floor; simulating again"
  fi
  [ -s "$f" ] && return 0
  pgrep -f "simulate.sh $1 $2" >/dev/null && return 0     # already being simulated
  bash "$S/simulate.sh" "$1" "$2" "$2" > "$f.tmp" 2>&1
  # A simulation that died before its last line (killed, out of memory) is not cached, so it runs again next time.
  if [ "$(grep -c '^SIMULATION ' "$f.tmp")" -eq 0 ]; then
    echo "presim $1 $(git rev-parse --short "$2"): the simulation did not finish (no SIMULATION line); not cached"
    rm -f "$f.tmp"; return 0
  fi
  date -u +%H:%M:%S >> "$f.tmp"; mv "$f.tmp" "$f"
  echo "presim $1 $(git rev-parse --short "$2"): $(awk '/^SIMULATION /{l=$0} END{print l}' "$f")"
}
PUB=$(git log -1 --format=%B refs/remotes/epinoic/verified-updates 2>/dev/null | sed -n 's/^Source-Commit: //p' | tail -1)
[ -n "$PUB" ] && run translator "$PUB"
FINAL=$(git log --format='%H%x09%s' "$BASELINE..$DEV" | awk -F'\t' '!found && ($2 ~ /^Fix the r[0-9]+ arena overseer findings$/ || $2 ~ /^Arena results: / || $2 == "Merge STEM support into the translator" || $2 == "Merge the logic-checking overseer agents into the translator" || $2 ~ /^Fix the c[0-9]+ clearance findings$/ || $2 == "Scaling: any number of agents per task" || $2 ~ /^Fix the m[0-9]+ multi-agent (optimisation )?findings$/ || $2 ~ /^Fix the r[0-9]+ handoff findings$/ || $2 ~ /^Fix the o[0-9]+ optimization findings$/ || $2 == "Fix the optimization findings" || $2 == "Fix the external review findings" || $2 == "Fix the end-to-end simulation findings" || $2 ~ /^Argument diagnostics: / || $2 ~ /^Integration: / || $2 ~ /^Delivery: / || $2 ~ /^Prototype: /) {print $1; found=1}')
[ -n "$FINAL" ] && [ "$FINAL" != "$PUB" ] && run translator "$FINAL"
# Overseer: candidates after the last upload, newest first, that pass the gate (the publisher uses the newest passing one).
WFDIR=/root/.claude/projects/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/subagents/workflows
RUN=$(python3 -I -c "import json,sys; print(json.load(open(sys.argv[1])).get('overseer') or '')" "$S/runs.json")
J=$WFDIR/$RUN/journal.jsonl
[ -n "$RUN" ] || J=""
# The overseer rebuild on the STEM-merged translator is gated against its own workflow's journal (runs.json
# "overseer-rebuild"); without it that candidate is skipped here (the publisher reports it as HOLD), the others are not.
GIMPORT="import sys; sys.path.insert(0, sys.argv[1]); import overseer_gate as G; print(G.REBUILD_SUBJECT)"
REBUILD_SUBJ=$(python3 -I -c "$GIMPORT" "$S" 2>/dev/null)
# Without a valid subject (stderr kept out of it; one line starting "Overseer rebuild: ") nothing can be gated and the
# publisher holds every candidate; say so, with the import error, instead of skipping silently.
if [[ "$REBUILD_SUBJ" != "Overseer rebuild: "?* ]] || [[ "$REBUILD_SUBJ" == *$'\n'* ]]; then
  echo "presim overseer: skipped: the rebuild subject could not be read from overseer_gate.py ($(python3 -I -c "$GIMPORT" "$S" 2>&1 >/dev/null | tail -1))"
  REBUILD_SUBJ=""
fi
RRUN=$(python3 -I -c "import json,sys; print(json.load(open(sys.argv[1])).get('overseer-rebuild') or '')" "$S/runs.json")
RJ=""; [ -n "$RRUN" ] && RJ=$WFDIR/$RRUN/journal.jsonl
LAST=$(git log -1 --format=%B refs/remotes/epinoic/overseer-prototype 2>/dev/null | sed -n 's/^Source-Commit: //p' | tail -1)
if [ -n "$LAST" ] && [ -n "$REBUILD_SUBJ" ]; then
  for C in $(git log --format='%H%x09%s' "$LAST..overseer-build" | awk -F'\t' -v rb="$REBUILD_SUBJ" '$2 ~ /^Overseer (review round [0-9]+: fix |contained round c[0-9]+: fix judge findings$|agents: documentation and contained-test results$)/ || $2 == rb {print $1}'); do
    CJ=$J; [ "$(git log -1 --format=%s "$C")" = "$REBUILD_SUBJ" ] && CJ=$RJ
    if ! { [ -n "$CJ" ] && [ -s "$CJ" ]; }; then echo "presim overseer $(git rev-parse --short "$C"): skipped: its journal is missing"; continue; fi
    python3 -I "$S/overseer_gate.py" "$R" "$C" "$CJ" >/dev/null 2>&1 || continue
    run overseer "$C"; break
  done
fi
