"""Print REBUILD-BOUNDARY once when the overseer STEM repair with the given key has a result (or failed)."""
import json, os, sys
J = '/root/.claude/projects/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/subagents/workflows/wf_92057cdf-3e2/journal.jsonl'
KEY = 'v2:a8d66469fd06e6642d2948af80b51b2c185dc05fc8d979d8a18caa8806a4fe84'
STATE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'rebuild-boundary.done')
if os.path.exists(STATE): sys.exit()
try:
    for l in open(J):
        if KEY in l and ('"type":"result"' in l or '"type":"failed"' in l):
            print('REBUILD-BOUNDARY: STEM repair returned; apply the severity edit (stop + resume)', flush=True)
            open(STATE, 'w').write('1'); break
except OSError:
    pass
