#!/usr/bin/env bash
# 8 Nov: free disk before rounds 9 and 10 by archiving finished workflow folders no live script references
# (overseer rebuild, deployment package, review fixes, e2e fixes, round-8 contained-run fix). Waits for any checkpoint
# build (it tars the scratchpad). Each folder is archived and the archive tested; the folder is removed only after that.
set -uo pipefail
S=/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad
OUT=$S/archives; mkdir -p "$OUT"
while pgrep -f "make_checkpoint.sh" >/dev/null; do sleep 20; done
for d in wf/contained-fix wf/e2e-fixes wf/review-fixes wf/z3-deploy wf/overseer-rebuild; do
  [ -d "$S/$d" ] || continue
  while pgrep -f "make_checkpoint.sh" >/dev/null; do sleep 20; done
  name=$(echo "$d" | tr / _); a="$OUT/$name.tar.xz"
  if nice -n 19 tar -C "$S" -cf - "$d" | nice -n 19 xz -T1 -6 > "$a.part" && xz -t "$a.part" && tar -tJf "$a.part" >/dev/null; then
    mv "$a.part" "$a"; rm -rf "$S/$d"; echo "archived $d -> $(du -h "$a" | cut -f1)"
  else rm -f "$a.part"; echo "FAILED $d (left in place)"; fi
done
df -h / | tail -1
