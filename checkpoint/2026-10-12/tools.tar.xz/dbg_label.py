import json
from pathlib import Path
from epinoic_logic.ir.schema import Problem
from epinoic_logic.translate.pipeline import label_beyond_expression
TR = json.loads(Path("/home/user/https-github.com-lovishchopra-NL2FOL/tests/channel/data/r7_translations.json").read_text())
for task, d in TR.items():
    for cid, obj in d["claims"].items():
        if obj.get("problem"):
            p = Problem.model_validate(obj["problem"])
            print(task, cid, repr(p.conclusion.label if p.conclusion else None)[:120], label_beyond_expression(p))
