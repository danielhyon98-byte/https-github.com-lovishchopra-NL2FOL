import sys
from epinoic_logic.branches.quant import extract_quant_checks, undecided_quant_statements
from epinoic_logic.engine import SolverConfig, verify
CFG = SolverConfig(timeout_ms=3000, memory_max_mb=None)
for s in sys.argv[1:]:
    print(repr(s[:100]))
    for c in extract_quant_checks(s, request_id="r", claim_id="c"):
        print("   ", c.kind, verify(c.problem, CFG).status.value, c.phrase, "|", c.problem.conclusion.label[:150])
    for u in undecided_quant_statements(s):
        print("    UNDECIDED", u.phrase[:80], "|", u.reason[:250])
