"""Round-6 fixtures (throwaway clone only; nothing is pushed, no ref is written), made on top of the fixtures of
make_commits.sh and make_commits_5.py. Rewrites COMMITS_TXT with every earlier line plus the new names (an existing name
is replaced).

  review-5 defect 1, development tests switched off by a build step on the rebuild (each on c2_on_good's tree, which
  passes): c2_skip_module_mark, c2_xfail_decorators, c2_conftest_ignore_glob (review-5's three reproductions, on all 31
  test files the development side added under tests/stem); c2_skipif_true, c2_unittest_skip, c2_body_skip,
  c2_body_xfail, c2_body_importorskip, c2_if_false, c2_redefined, c2_rebound (one development test each);
  c2_conftest_collect_ignore, c2_conftest_hook, c2_pyproject_ignore, c2_pyproject_k, c2_pyproject_testpaths,
  c2_pytest_ini_deselect, c2_setup_cfg_ignore_glob, c2_tox_ini_norecursedirs (collection);
  not held: c2_overseer_test_skipped, c2_overseer_conftest_ignore (overseer-only tests), and tskip_rebuild /
  c2_on_tskip_rebuild (T itself skips a development test and collect-ignores a development test file; dev head tskip_dev)
  and tskip_reenabled (the rebuild runs them again: no skip mark, an empty collect_ignore).
  review-5 defect 2, the phase-2 sequence: p2_dev_merge (the development branch merges the rebuild), p2_dev (a later
  development commit), p2_merge (the build merges p2_dev back onto c2_on_good); build steps on it: p2_c3_good,
  p2_c3_reverts (a pre-rebuild development file reverted to the fork point), p2_c3_deletes (a pre-rebuild development
  file deleted), p2_c3_drops_guard (two pre-rebuild development lines dropped: reported), p2_c3_disables (development
  tests switched off). Superseded legitimately: p2s_dev (the development side itself reverts that file, deletes that
  file, drops a test and the guard), p2s_merge, p2s_c3_follows_dev. A no-op translator merge: noop_merge (merges T, already in
  c2_on_good's history) and c2_on_noop_partial (reverts a development file on top of it).

Usage: make_commits_6.py CLONE COMMITS_TXT
"""
import os
import re
import subprocess
import sys
import tempfile

clone, commits = sys.argv[1:3]
lines = [ln for ln in open(commits).read().splitlines() if ln.strip()]
sha = dict(ln.split() for ln in lines)
ENV = {**os.environ, "GIT_AUTHOR_NAME": "Test", "GIT_AUTHOR_EMAIL": "test@example.invalid", "GIT_COMMITTER_NAME": "Test",
       "GIT_COMMITTER_EMAIL": "test@example.invalid"}


def git(*a, inp=None, env=None):
    return subprocess.run(["git", "-C", clone, *a], input=inp, capture_output=True, check=True,
                          env={**ENV, **(env or {})}).stdout.decode()


def blob(rev, path):
    return git("cat-file", "blob", f"{rev}:{path}")


def tree_of(rev):
    return git("rev-parse", rev + "^{tree}").strip()


def tree_with(base_tree, changes):
    """changes: {path: text or None (removed)}"""
    with tempfile.TemporaryDirectory() as d:
        env = {"GIT_INDEX_FILE": os.path.join(d, "i")}
        git("read-tree", base_tree, env=env)
        for p, txt in changes.items():
            if txt is None:
                git("update-index", "--force-remove", "--", p, env=env)
            else:
                oid = git("hash-object", "-w", "--stdin", inp=txt.encode()).strip()
                git("update-index", "--add", "--cacheinfo", f"100644,{oid},{p}", env=env)
        return git("write-tree", env=env).strip()


def commit(tree, parents, msg):
    args = []
    for p in parents:
        args += ["-p", p]
    return git("commit-tree", tree, *args, inp=msg.encode()).strip()


def add_import(text, line):
    """Insert an import after a leading docstring and any __future__ import (a plain prefix would not parse)."""
    out = text.split("\n")
    at = 0
    for i, ln in enumerate(out):
        if ln.startswith("from __future__ import"):
            at = i + 1
    if at == 0 and out and out[0].lstrip().startswith(('"""', "'''")):
        q = out[0].lstrip()[:3]
        at = next(i for i, ln in enumerate(out) if (i == 0 and ln.count(q) >= 2) or (i > 0 and q in ln)) + 1
    return "\n".join(out[:at] + [line] + out[at:])


def one_line_test(text):
    """The first module-level test whose def fits on one line (name, def line index)."""
    for i, ln in enumerate(text.split("\n")):
        m = re.match(r"^def (test_\w+)\([^)]*\)(?: -> None)?:\s*$", ln)
        if m:
            return m.group(1), i
    raise SystemExit("no one-line test def")


def block(text, i):
    """(start, end) of the module-level def at line i, decorators included."""
    ls = text.split("\n")
    s = i
    while s > 0 and ls[s - 1].startswith("@"):
        s -= 1
    e = i + 1
    while e < len(ls) and (not ls[e] or ls[e][0].isspace() or ls[e].startswith("#")):
        e += 1
    return s, e


GOOD, C2G, T, FIXC, MB = sha["good"], sha["c2_on_good"], sha["devhead"], sha["faultfix"], sha["mergebase"]
assert MB.startswith("ae7b1e6")
C2_MSG = git("log", "-1", "--format=%B", C2G)
REB_MSG = git("log", "-1", "--format=%B", GOOD)
new = {}
STEM_TESTS = [p for p in git("diff", "--name-only", "--diff-filter=A", MB, T, "--", "tests/stem").split()
              if p.endswith(".py") and "/test_" in p]
assert len(STEM_TESTS) == 31, len(STEM_TESTS)


def c2(name, changes):
    new[name] = commit(tree_with(tree_of(C2G), changes), [GOOD], C2_MSG)


# --- Defect 1: development tests switched off (review-5's three reproductions first).
c2("c2_skip_module_mark", {p: add_import(blob(C2G, p), "import pytest\npytestmark = pytest.mark.skip(reason='after the merge')") for p in STEM_TESTS})
c2("c2_xfail_decorators", {p: re.sub(r"^def (test\w*)", r"@pytest.mark.xfail(strict=False)\ndef \1", add_import(blob(C2G, p), "import pytest"), flags=re.M) for p in STEM_TESTS})
c2("c2_conftest_ignore_glob", {"tests/stem/conftest.py": "collect_ignore_glob = ['test_*.py']\n"})
ONE = "tests/stem/test_reading_extensions.py"
one = blob(C2G, ONE)
tname, ti = one_line_test(one)
ls = one.split("\n")


def with_line_before(i, extra, imp="import pytest"):
    return add_import("\n".join(ls[:i] + [extra] + ls[i:]), imp)


def with_line_after(i, extra, imp="import pytest"):
    return add_import("\n".join(ls[:i + 1] + [extra] + ls[i + 1:]), imp)


c2("c2_skipif_true", {ONE: with_line_before(ti, "@pytest.mark.skipif(True, reason='after the merge')")})
c2("c2_unittest_skip", {ONE: with_line_before(ti, "@unittest.skip('after the merge')", "import unittest")})
c2("c2_body_skip", {ONE: with_line_after(ti, "    pytest.skip('after the merge')")})
c2("c2_body_xfail", {ONE: with_line_after(ti, "    pytest.xfail('after the merge')")})
c2("c2_body_importorskip", {ONE: with_line_after(ti, "    pytest.importorskip('a_module_that_is_not_installed')")})
s_, e_ = block(one, ti)
c2("c2_if_false", {ONE: "\n".join(ls[:s_] + ["if False:"] + ["    " + x if x else x for x in ls[s_:e_]] + ls[e_:])})
c2("c2_redefined", {ONE: one.rstrip("\n") + f"\n\n\ndef {tname}():\n    pass\n"})
c2("c2_rebound", {ONE: one.rstrip("\n") + f"\n\n{tname} = None\n"})
c2("c2_conftest_collect_ignore", {"tests/stem/conftest.py": f"collect_ignore = [{ONE.rsplit('/', 1)[1]!r}]\n"})
c2("c2_conftest_hook", {"tests/conftest.py": "def pytest_collection_modifyitems(config, items):\n    items[:] = [i for i in items if 'stem' not in str(i.fspath)]\n"})
PY = blob(C2G, "pyproject.toml")
assert "addopts = \"-ra -m 'not stress'\"" in PY and 'testpaths = ["tests"]' in PY
c2("c2_pyproject_ignore", {"pyproject.toml": PY.replace("addopts = \"-ra ", "addopts = \"-ra --ignore=tests/stem ")})
c2("c2_pyproject_k", {"pyproject.toml": PY.replace("addopts = \"-ra ", "addopts = \"-ra -k 'not stem' ")})
c2("c2_pyproject_testpaths", {"pyproject.toml": PY.replace('testpaths = ["tests"]', 'testpaths = ["tests/engine", "tests/overseer"]')})
c2("c2_pytest_ini_deselect", {"pytest.ini": f"[pytest]\ntestpaths = tests\naddopts = -ra -m 'not stress' --deselect {ONE}::{tname}\n"})
c2("c2_setup_cfg_ignore_glob", {"setup.cfg": "[metadata]\nname = x\n\n[tool:pytest]\naddopts = --ignore-glob=tests/stem/*\n"})
c2("c2_tox_ini_norecursedirs", {"tox.ini": "[tox]\nenvlist = py313\n\n[pytest]\nnorecursedirs = stem .git\n"})
# Not held: tests the development side never had.
OV = next(p for p in sorted(git("ls-tree", "-r", "--name-only", C2G, "--", "tests/overseer").split())
          if p.endswith(".py") and "/test_" in p and p not in git("ls-tree", "-r", "--name-only", T, "--", "tests").split())
ov = blob(C2G, OV)
c2("c2_overseer_test_skipped", {OV: add_import(re.sub(r"^def (test\w*)", r"@pytest.mark.skip(reason='overseer only')\ndef \1", ov, count=1, flags=re.M), "import pytest")})
c2("c2_overseer_conftest_ignore", {"tests/overseer/conftest.py": blob(C2G, "tests/overseer/conftest.py").rstrip("\n") + f"\n\ncollect_ignore = [{OV.rsplit('/', 1)[1]!r}]\n"})

# T itself switches a development test off (a skip mark, and a collect_ignore of a whole development test file): a
# rebuild that keeps them so passes, and so does one that runs them again.
TWO = "tests/stem/test_document.py" if "tests/stem/test_document.py" in STEM_TESTS else STEM_TESTS[1]
tsk = {ONE: add_import("\n".join(ls[:ti] + ["@pytest.mark.skip(reason='known gap in the development branch')"] + ls[ti:]), "import pytest"),
       "tests/stem/conftest.py": f"collect_ignore = [{TWO.rsplit('/', 1)[1]!r}]\n"}
assert blob(T, ONE) == one
TSKIP = commit(tree_with(tree_of(T), tsk), [T], "Testing README: a known gap is skipped for now\n")
new["tskip_dev"] = TSKIP
MTREE = tree_of(GOOD)
new["tskip_rebuild"] = commit(tree_with(MTREE, tsk), [FIXC, TSKIP], REB_MSG.replace(T[:7], TSKIP[:7]))
new["c2_on_tskip_rebuild"] = commit(tree_with(MTREE, tsk), [new["tskip_rebuild"]], C2_MSG)
new["tskip_reenabled"] = commit(tree_with(MTREE, {"tests/stem/conftest.py": "collect_ignore = []\n"}), [FIXC, TSKIP], REB_MSG.replace(T[:7], TSKIP[:7]))

# --- Defect 2: the phase-2 sequence. The development branch merges the rebuild, moves on, and the build merges it back.
SP = "src/epinoic_logic/adapters/english_specialist/structural.py"
DOC = "docs/STEM_RESULTS.md"
assert blob(MB, SP) != blob(T, SP) and blob(GOOD, SP) == blob(T, SP)
D2 = commit(tree_of(GOOD), [T, GOOD], "Merge the logic-checking overseer agents into the translator\n")
doc = blob(D2, DOC) + "A later development note.\n"
D3 = commit(tree_with(tree_of(D2), {DOC: doc}), [D2], "Testing README: progress after the overseer merge\n")
M2 = commit(tree_with(tree_of(C2G), {DOC: doc}), [C2G, D3], "Overseer: merge the development branch\n")
new.update(p2_dev_merge=D2, p2_dev=D3, p2_merge=M2)
M2T = tree_of(M2)
new["p2_c3_good"] = commit(M2T, [M2], C2_MSG)
new["p2_c3_reverts"] = commit(tree_with(M2T, {SP: blob(MB, SP)}), [M2], C2_MSG)
# A file the development side added before the rebuild (not a test; the overseer side never had it).
ADDED = "src/epinoic_logic/branches/stem_pack.py"
assert ADDED not in git("ls-tree", "-r", "--name-only", MB).split() and ADDED not in git("ls-tree", "-r", "--name-only", FIXC).split()
new["p2_c3_deletes"] = commit(tree_with(M2T, {ADDED: None}), [M2], C2_MSG)
GUARD_PATH = "src/epinoic_logic/adapters/stem_specialist/parser.py"
g = blob(M2, GUARD_PATH).split("\n")
gi = next(i for i, ln in enumerate(g) if ln.strip() == 'raise AdapterError("the specialist answer is empty")')
assert g[gi - 1].strip() == "if not text or not text.strip():"
NOGUARD = "\n".join(g[:gi - 1] + g[gi + 1:])
new["p2_c3_drops_guard"] = commit(tree_with(M2T, {GUARD_PATH: NOGUARD}), [M2], C2_MSG)
new["p2_c3_disables"] = commit(tree_with(M2T, {"tests/stem/conftest.py": "collect_ignore_glob = ['test_*.py']\n"}), [M2], C2_MSG)
# The development side itself supersedes its earlier changes: it reverts the file, deletes the other, drops a test and
# the guard. A build step that follows it passes, and the report does not list what the development side removed.
two = blob(D3, ONE)
two_ls = two.split("\n")
s2, e2 = block(two, one_line_test(two)[1])
sup = {SP: blob(MB, SP), ADDED: None, GUARD_PATH: NOGUARD, ONE: "\n".join(two_ls[:s2] + two_ls[e2:])}
D4 = commit(tree_with(tree_of(D3), sup), [D3], "Testing README: the development side reworks the STEM parser\n")
M3 = commit(tree_with(M2T, sup), [C2G, D4], "Overseer: merge the development branch\n")
new.update(p2s_dev=D4, p2s_merge=M3)
new["p2s_c3_follows_dev"] = commit(tree_of(M3), [M3], C2_MSG)
# A no-op translator merge (its second parent T is already in the first parent's history), then a revert on top.
NOOP = commit(tree_of(C2G), [C2G, T], "Overseer: merge the development branch\n")
new["noop_merge"] = NOOP
new["c2_on_noop_partial"] = commit(tree_with(tree_of(C2G), {SP: blob(MB, SP)}), [NOOP], C2_MSG)

keep = [ln for ln in lines if ln.split()[0] not in new]
with open(commits, "w") as fh:
    fh.write("\n".join(keep + [f"{k} {v}" for k, v in new.items()]) + "\n")
for k, v in new.items():
    print(k, v)
print("_one", f"{ONE}::{tname}", "_two", TWO, "_overseer", OV)
