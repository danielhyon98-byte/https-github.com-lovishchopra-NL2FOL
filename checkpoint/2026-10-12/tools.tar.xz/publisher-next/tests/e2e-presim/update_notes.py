"""Write the update notes that go with every publish to the main repository (Daniel's instruction).

Each note explains what the update changes, records the bugs and failures found since the previous update
(overseer verdicts and findings, work-in-progress commits that did not verify) and lists the fixes introduced.
It is built only from git history and the recorded overseer reports. Scratch paths, session ids and model names
are removed, since repository documents must not contain them.

Usage: update_notes.py --repo R --from SRC_A --to SRC_B --number N --label L --scratch S --out FILE
       [--published ISO_DATE] [--index PATH ...]
"""
import argparse
import datetime
import glob
import json
import os
import re
import subprocess

FINAL_TITLES = [
    r"^Fix the r\d+ arena overseer findings$", r"^Fix the c\d+ clearance findings$", r"^Fix the m\d+ multi-agent (optimisation )?findings$",
    r"^Fix the r\d+ handoff findings$", r"^Fix the o\d+ optimization findings$", r"^Fix the optimization findings$",
    r"^Fix defects found by the contained stress runs$", r"^Arena results: ", r"^Merge STEM support into the translator$",
    r"^Merge the logic-checking overseer agents into the translator$", r"^Scaling: any number of agents per task$", r"^Final report: ",
    r"^Fix the external review findings$", r"^Delivery: ", r"^Prototype: ",
]
SEV_ORDER = {"blocker": 0, "major": 1, "minor": 2}


def git(repo, *args):
    return subprocess.run(["git", "-C", repo, *args], check=True, capture_output=True, text=True).stdout


def clean(text):
    """Remove what repository documents must not carry."""
    out = []
    for line in str(text or "").splitlines():
        if re.match(r"^\s*(Co-Authored-By|Claude-Session|Source-Commit):", line):
            continue
        out.append(line)
    t = "\n".join(out)
    t = re.sub(r"(/tmp|/root)/(?:[^\s'\"`),;]*[^\s'\"`),;.])?", "a private working copy", t)
    # Relative or placeholder references into the private working area say nothing to a reader and must not leak.
    t = re.sub(r"<scratch(?:pad)?>/\S*", "a private working copy", t)
    t = re.sub(r"\bscratchpad/arena\b[^\s'\"`),;]*", "the recorded rounds", t)
    t = re.sub(r"\bscratchpad/[^\s'\"`),;]*", "a private working copy", t)
    t = re.sub(r"(?<![\w/.<])\.\.\./(?:[^\s'\"`),;]*[^\s'\"`),;.])?", "a private working copy", t)
    t = re.sub(r"(?<![\w/.])(?:wf|fixcheck|pack-export|review-pub|arena-overseer)/(?:[^\s'\"`),;]*[^\s'\"`),;.])?", "a private working copy", t)
    # Model names: whole identifiers and "Claude <name> <version>" first, so no vendor or version is left behind;
    # lowercase or all-caps tier words only in a model context (bare words can be literary: "magnum opus", a haiku).
    t = re.sub(r"\bclaude[-_](?:[\d.]+[-_])*(?:opus|sonnet|haiku|fable)[\w.-]*", "a model tier", t, flags=re.I)
    t = re.sub(r"\bclaude[\s_-]+(?:opus|sonnet|haiku|fable)(?:[\s_-]*\d+(?:\.\d+)*)?\b", "a model tier", t, flags=re.I)
    t = re.sub(r"\b(?:Claude\s+)?Haiku(?:\s+\d+(?:\.\d+)?)?\b", "cheapest-tier model", t)
    t = re.sub(r"\b(?:Claude\s+)?(?:Opus|Sonnet|Fable)(?:\s+\d+(?:\.\d+)?)?\b", "strongest-tier model", t)
    t = re.sub(r"\b(model\s*[=:]\s*['\"]?)(?:haiku|opus|sonnet|fable)\b", r"\1a model tier", t, flags=re.I)
    t = re.sub(r"\bhaiku(?=[\s_-]*(?:\d+\.\d+|models?\b|tier\b|agents?\b|lens(?:es)?\b|overseers?\b|instances?\b))", "cheapest-tier model", t, flags=re.I)
    t = re.sub(r"\bopus(?=[\s_-]*(?:\d+\.\d+|models?\b|tier\b|agents?\b|lens(?:es)?\b|overseers?\b|instances?\b|checks?\b))", "strongest-tier model", t, flags=re.I)
    t = re.sub(r"https://claude\.ai/\S+", "", t)
    t = re.sub(r"\bsession_[A-Za-z0-9]+\b", "", t)
    t = re.sub(r"\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b", "", t)
    t = re.sub(r"\b(?:Claude\s+)?Haiku(?:\s+\d+(?:\.\d+)?)?\b", "cheapest-tier model", t)
    t = re.sub(r"\b(?:Claude\s+)?(?:Opus|Sonnet|Fable)(?:\s+\d+(?:\.\d+)?)?\b", "strongest-tier model", t)
    t = t.replace("|", "/")
    return t.strip()


def short(text, n):
    t = " ".join(clean(text).split())
    return t if len(t) <= n else t[: n - 1].rstrip() + "…"


def commits(repo, a, b):
    raw = git(repo, "log", "--reverse", "--format=%H%x1f%s%x1f%b%x1e", f"{a}..{b}")
    out = []
    for rec in raw.split("\x1e"):
        rec = rec.strip("\n")
        if not rec:
            continue
        sha, subj, body = (rec.split("\x1f") + ["", ""])[:3]
        out.append({"sha": sha.strip(), "subject": subj.strip(), "body": body})
    return out


def kind(subject):
    if subject.startswith("WIP"):
        return "wip"
    if any(re.search(p, subject) for p in FINAL_TITLES):
        return "final"
    if subject.startswith("Testing README") or subject.startswith("Progress"):
        return "docs"
    return "other"


def harness_line(body):
    m = re.search(r"Harness after the change: ([^\n]*)", body or "")
    return m.group(1).strip() if m else ""


def report_files(subject, scratch):
    m = re.match(r"^Fix the (r\d+) arena overseer findings$", subject)
    if m:
        return sorted(glob.glob(os.path.join(scratch, "arena", m.group(1), "overseers", "*.json")))
    m = re.match(r"^Fix the (c\d+) clearance findings$", subject)
    if m:
        return sorted(glob.glob(os.path.join(scratch, "clearance", m.group(1), "overseers", "*.json")))
    m = re.match(r"^Fix the (m\d+) multi-agent", subject)
    if m:
        return sorted(glob.glob(os.path.join(scratch, "wf", "phase2", m.group(1), "overseer.json")))
    m = re.match(r"^Fix the (o\d+) optimization findings$", subject)
    if m:
        return sorted(glob.glob(os.path.join(scratch, "optimization", m.group(1), "report.json")))
    return []


def round_findings(files):
    lines, rows = [], []
    for f in files:
        try:
            d = json.load(open(f, encoding="utf-8"))
        except (OSError, ValueError):
            continue
        name = os.path.splitext(os.path.basename(f))[0]
        bugs = d.get("bugs") or d.get("issues") or []
        sev = {k: sum(1 for b in bugs if b.get("severity") == k) for k in ("blocker", "major", "minor")}
        rate = d.get("infrastructure_functional_rate")
        rows.append(f"| {name} | {'' if rate is None else rate} | {'yes' if d.get('verdict_at_least_98') else 'no' if 'verdict_at_least_98' in d else ''} | {sev['blocker']} | {sev['major']} | {sev['minor']} |")
        for b in sorted(bugs, key=lambda b: SEV_ORDER.get(b.get("severity"), 3)):
            lines.append((SEV_ORDER.get(b.get("severity"), 3), f"- **{b.get('severity', '?')}** ({name}) {short(b.get('summary', ''), 260)}"))
    lines.sort(key=lambda x: x[0])
    shown = [l for _, l in lines[:25]]
    if len(lines) > 25:
        shown.append(f"- … and {len(lines) - 25} more (minor first omitted).")
    table = ["| Overseer lens | Rate | 98% verdict | Blockers | Majors | Minors |", "| --- | --- | --- | --- | --- | --- |"] + rows if rows else []
    return table, shown


def fixes_of(body):
    fixed, undone = [], ""
    for line in (body or "").splitlines():
        if line.startswith("- "):
            fixed.append("- " + short(line[2:], 300))
        m = re.match(r"^Left undone: (.*)$", line)
        if m:
            undone = short(m.group(1), 600)
    return fixed, undone


def area_stats(repo, a, b):
    rows = {}
    for line in git(repo, "diff", "--name-status", a, b).splitlines():
        parts = line.split("\t")
        status, path = parts[0][0], parts[-1]
        segs = path.split("/")
        if segs[0] == "src" and len(segs) > 2:
            area = "/".join(segs[:3])
        elif segs[0] in ("tests", "scripts", "docs") and len(segs) > 1:
            area = "/".join(segs[:2]) if len(segs) > 2 else segs[0]
        else:
            area = segs[0]
        r = rows.setdefault(area, {"A": 0, "M": 0, "D": 0, "R": 0})
        r[status if status in r else "M"] += 1
    return rows, git(repo, "diff", "--shortstat", a, b).strip()


def main():
    ap = argparse.ArgumentParser()
    for k in ("repo", "from", "to", "label", "scratch", "out"):
        ap.add_argument("--" + k, required=True)
    ap.add_argument("--number", type=int, required=True)
    ap.add_argument("--published", default="")
    ap.add_argument("--index", nargs="*", default=[])
    a = ap.parse_args()
    cs = commits(a.repo, getattr(a, "from"), a.to)
    final = next((c for c in reversed(cs) if c["sha"] == git(a.repo, "rev-parse", a.to).strip()), cs[-1] if cs else None)
    subj = final["subject"] if final else git(a.repo, "log", "-1", "--format=%s", a.to).strip()
    when = a.published or datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    prev_h = harness_line(git(a.repo, "log", "-1", "--format=%B", getattr(a, "from")))
    new_h = harness_line(final["body"]) if final else ""
    suite = re.search(r"Suite: ([^\n]*)", final["body"]) if final else None
    md = [f"# Update {a.number}: {clean(a.label)}: {clean(subj)}", "",
          f"Published {when}. Source commit `{a.to[:7]}` on the development branch; the previous published source was `{getattr(a, 'from')[:7]}`. "
          "This update publishes the translator code exactly as verified at that commit (full suite green, harness replay counts not lower than the previous update). "
          "Results prove properties of the encoded problems only, never that a specialist's premises are true.", ""]
    rows, shortstat = area_stats(a.repo, getattr(a, "from"), a.to)
    md += ["## What this update changes", "", f"{len(cs)} commit(s) since the previous update; {shortstat or 'no file changes'}.", ""]
    if rows:
        md += ["| Area | Added | Modified | Deleted | Renamed |", "| --- | --- | --- | --- | --- |"]
        md += [f"| {k} | {v['A']} | {v['M']} | {v['D']} | {v['R']} |" for k, v in sorted(rows.items())]
        md.append("")
    md += ["Commits, oldest first:", ""]
    for c in cs:
        k = kind(c["subject"])
        tag = {"final": "verified", "wip": "work in progress (not published on its own; superseded by a later verified commit)", "docs": "test report", "other": "change"}[k]
        md.append(f"- `{c['sha'][:7]}` {short(c['subject'], 160)} ({tag})")
    md.append("")
    md += ["## Bugs and failures found since the previous update", ""]
    any_found = False
    for c in cs:
        files = report_files(c["subject"], a.scratch)
        table, bugs = round_findings(files)
        first = short(re.split(r"\n|(?<=:)\s+-\s", c["body"].strip())[0], 600) if kind(c["subject"]) == "final" else ""
        if table or bugs or (first and re.search(r"overseer|finding|issue", first, re.I)):
            any_found = True
            md += [f"### {short(c['subject'], 160)}", ""]
            if first:
                md += [first, ""]
            md += table + ([""] if table else []) + bugs + ([""] if bugs else [])
    failures = [c for c in cs if kind(c["subject"]) == "wip"]
    if failures:
        any_found = True
        md += ["### Verification failures (work in progress that did not verify)", ""]
        for c in failures:
            tail = re.search(r"(Suite tail|Harness drop|Hygiene): ([^\n]*)", c["body"])
            md.append(f"- `{c['sha'][:7]}` {short(c['subject'], 200)}" + (f": {short(tail.group(2), 240)}" if tail else ""))
        md.append("")
    if not any_found:
        md += ["No overseer findings or verification failures were recorded in this interval.", ""]
    md += ["## Fixes introduced", ""]
    any_fix = False
    for c in cs:
        if kind(c["subject"]) != "final":
            continue
        fixed, undone = fixes_of(c["body"])
        if fixed or undone:
            any_fix = True
            md += [f"### {short(c['subject'], 160)}", ""] + fixed[:60]
            if len(fixed) > 60:
                md.append(f"- … and {len(fixed) - 60} more (see the commit).")
            if undone:
                md += ["", f"Left undone: {undone}"]
            md.append("")
    if not any_fix:
        md += ["No fix list was recorded in this interval (see the commits above).", ""]
    md += ["## Verification", "",
           f"- Harness before (previous update): {clean(prev_h) or 'not recorded'}",
           f"- Harness after (this update): {clean(new_h) or 'not recorded'}",
           f"- Suite at this update: {clean(suite.group(1)) if suite else 'not recorded'}", ""]
    if a.index:
        md += ["## Earlier updates", ""] + [f"- {p}" for p in a.index] + [""]
    with open(a.out, "w", encoding="utf-8") as fh:
        fh.write("\n".join(md).rstrip() + "\n")


if __name__ == "__main__":
    main()
