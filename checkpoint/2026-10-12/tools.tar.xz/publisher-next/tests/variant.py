"""Fixture helper (throwaway clone only): a variant of a tree, printed as a new tree id.

  variant.py CLONE TREE notests MB T            drop every test file T added since MB
  variant.py CLONE TREE revert MB PATH          PATH as it was at MB
  variant.py CLONE TREE replace PATH OTHER      PATH's content replaced by OTHER's (from TREE)
  variant.py CLONE TREE hunk MB T PATH          PATH as at T with T's first change reverted to MB's lines
  variant.py CLONE TREE edit PATH               a legitimate merge edit: a comment line added at the end and one in the middle
  variant.py CLONE TREE remove PATH             PATH removed
"""
import difflib
import os
import subprocess
import sys
import tempfile

clone, tree, op, *args = sys.argv[1:]


def git(*a, inp=None, env=None):
    return subprocess.run(["git", "-C", clone, *a], input=inp, capture_output=True, check=True,
                          env={**os.environ, **(env or {})}).stdout


def blob_of(rev, path):
    return git("cat-file", "blob", f"{rev}:{path}")


def put(env, path, data):
    oid = git("hash-object", "-w", "--stdin", inp=data).decode().strip()
    git("update-index", "--add", "--cacheinfo", f"100644,{oid},{path}", env=env)


with tempfile.TemporaryDirectory() as d:
    env = {"GIT_INDEX_FILE": os.path.join(d, "index")}
    git("read-tree", tree, env=env)
    if op == "notests":
        mb, t = args
        added = [ln.split("\t", 1)[1] for ln in git("diff", "--no-renames", "--name-status", "--diff-filter=A", mb, t, "--", "tests").decode().splitlines()]
        git("update-index", "--force-remove", "--", *added, env=env)
    elif op == "revert":
        mb, path = args
        put(env, path, blob_of(mb, path))
    elif op == "replace":
        path, other = args
        put(env, path, blob_of(tree, other))
    elif op == "hunk":
        mb, t, path = args
        a, b = blob_of(mb, path).decode().split("\n"), blob_of(t, path).decode().split("\n")
        ops = [o for o in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes() if o[0] != "equal"]
        _, i1, i2, j1, j2 = ops[0]
        put(env, path, "\n".join(b[:j1] + a[i1:i2] + b[j2:]).encode())
    elif op == "edit":
        (path,) = args
        lines = blob_of(tree, path).decode().split("\n")
        mid = len(lines) // 2
        while mid < len(lines) and lines[mid].strip():
            mid += 1
        lines[mid:mid] = ["# merge note: the overseer reads this module unchanged"]
        put(env, path, ("\n".join(lines).rstrip("\n") + "\n# merge note: kept as on the development branch\n").encode())
    elif op == "remove":
        (path,) = args
        git("update-index", "--force-remove", "--", path, env=env)
    else:
        sys.exit("unknown variant " + op)
    print(git("write-tree", env=env).decode().strip())
