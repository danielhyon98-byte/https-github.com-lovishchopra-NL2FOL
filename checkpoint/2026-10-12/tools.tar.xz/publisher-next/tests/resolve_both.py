"""Fixture helper (throwaway clone only): a merge tree of OURS and THEIRS that keeps both sides, the way a careful
resolution does. git merges every file it can; each conflicted file is resolved by keeping both sides' lines (git
merge-file --union), and import lines that both sides edited ("from M import a, b" next to "from M import a, c") are
combined into one line, as a resolver writes them, so T's lines are not all present verbatim. Not a verified resolution:
the tree is for the gate's tree check, never run.

Usage: resolve_both.py CLONE OURS THEIRS        prints the tree id
"""
import os
import re
import subprocess
import sys
import tempfile

clone, ours, theirs = sys.argv[1:4]


def git(*a, inp=None, env=None):
    return subprocess.run(["git", "-C", clone, *a], input=inp, capture_output=True, check=True,
                          env={**os.environ, **(env or {})}).stdout


mb = git("merge-base", ours, theirs).decode().strip()
p = subprocess.run(["git", "-C", clone, "merge-tree", "--write-tree", "--name-only", "--no-messages", ours, theirs],
                   capture_output=True, text=True)
if p.returncode not in (0, 1):
    sys.exit(f"merge-tree failed: {p.stderr}")
lines = p.stdout.split("\n")
tree, conflicted = lines[0], sorted({ln for ln in lines[1:] if ln})
IMPORT = re.compile(r"^(\s*)from (\S+) import ([^()#]+)$")


def combine_imports(text):
    out = text.split("\n")
    i = 0
    while i < len(out):
        m = IMPORT.match(out[i])
        if m:
            for j in range(i + 1, min(i + 4, len(out))):
                n = IMPORT.match(out[j])
                if n and n.group(1) == m.group(1) and n.group(2) == m.group(2):
                    names = [x.strip() for x in m.group(3).split(",")]
                    names += [x.strip() for x in n.group(3).split(",") if x.strip() not in names]
                    out[i] = f"{m.group(1)}from {m.group(2)} import {', '.join(names)}"
                    del out[j]
                    m = IMPORT.match(out[i])
                    break
        i += 1
    return "\n".join(out)


with tempfile.TemporaryDirectory() as d:
    idx = os.path.join(d, "index")
    env = {"GIT_INDEX_FILE": idx}
    git("read-tree", tree, env=env)
    for path in conflicted:
        names = []
        for side, rev in (("ours", ours), ("base", mb), ("theirs", theirs)):
            r = subprocess.run(["git", "-C", clone, "cat-file", "blob", f"{rev}:{path}"], capture_output=True)
            names.append(os.path.join(d, side))
            with open(names[-1], "wb") as fh:
                fh.write(r.stdout if r.returncode == 0 else b"")
        merged = subprocess.run(["git", "merge-file", "-p", "--union", *names], capture_output=True).stdout.decode()
        blob = git("hash-object", "-w", "--stdin", inp=combine_imports(merged).encode()).decode().strip()
        mode = git("ls-tree", ours, "--", path).decode().split()[0]
        git("update-index", "--add", "--cacheinfo", f"{mode},{blob},{path}", env=env)
    print(git("write-tree", env=env).decode().strip())
