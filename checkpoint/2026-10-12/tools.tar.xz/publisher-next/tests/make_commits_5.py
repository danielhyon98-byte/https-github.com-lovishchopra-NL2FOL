"""Round-5 fixtures (throwaway clone only; nothing is pushed), made on top of the fixtures of make_commits.sh.
Rewrites COMMITS_TXT with every earlier line plus the new names (an existing name is replaced).

  build steps on top of a rebuild: c2_on_good, c2_on_overseer_whole, c2_on_notests, c2_on_dropped, c2_on_offdev,
    c2_on_squashed, c2_on_devmerge_offdev (on a later development merge whose second parent is off the branch), c2_drops_tests (the build step itself deletes development tests), c2_drops_guard (the build step
    drops one development line, a guard)
  review-4 reproductions on the rebuild: tests_dropped_in_added_files, guard_dropped, test_renamed (a development test
    renamed in a development-modified file), base_test_file_deleted (a test file the development side never changed)
  the development branch merges the overseer side: dev_merged_overseer (the development head that merges it),
    later_rebuild (a correct rebuild made after that, on a later overseer commit), p1_in_t (a rebuild whose first
    parent is already in T's history)

Usage: make_commits_5.py CLONE COMMITS_TXT
"""
import os
import re
import subprocess
import sys
import tempfile

clone, commits = sys.argv[1:3]
lines = [ln for ln in open(commits).read().splitlines() if ln.strip()]
sha = dict(ln.split() for ln in lines)
ENV = {**os.environ, "GIT_AUTHOR_NAME": "Test", "GIT_AUTHOR_EMAIL": "test@example.invalid", "GIT_COMMITTER_NAME": "Test",
       "GIT_COMMITTER_EMAIL": "test@example.invalid"}


def git(*a, inp=None, env=None):
    return subprocess.run(["git", "-C", clone, *a], input=inp, capture_output=True, check=True,
                          env={**ENV, **(env or {})}).stdout.decode()


def blob(rev, path):
    return git("cat-file", "blob", f"{rev}:{path}")


def tree_of(rev):
    return git("rev-parse", rev + "^{tree}").strip()


def tree_with(base_tree, changes):
    """changes: {path: text or None (removed)}"""
    with tempfile.TemporaryDirectory() as d:
        env = {"GIT_INDEX_FILE": os.path.join(d, "i")}
        git("read-tree", base_tree, env=env)
        for p, txt in changes.items():
            if txt is None:
                git("update-index", "--force-remove", "--", p, env=env)
            else:
                oid = git("hash-object", "-w", "--stdin", inp=txt.encode()).strip()
                git("update-index", "--add", "--cacheinfo", f"100644,{oid},{p}", env=env)
        return git("write-tree", env=env).strip()


def commit(tree, parents, msg):
    args = []
    for p in parents:
        args += ["-p", p]
    return git("commit-tree", tree, *args, inp=msg.encode()).strip()


def drop_tests(text, names):
    """Remove the top-level test functions named (with their decorators and bodies)."""
    out, skip = [], False
    for ln in text.split("\n"):
        m = re.match(r"^def (test_\w+)\(", ln)
        if m:
            skip = m.group(1) in names
            if skip:
                while out and out[-1].startswith("@"):
                    out.pop()
        elif skip and ln and not ln[0].isspace() and not ln.startswith("#"):
            skip = False
        if not skip:
            out.append(ln)
    return "\n".join(out)


GOOD, T, FIXC, MB, MTREE = sha["good"], sha["devhead"], sha["faultfix"], sha["mergebase"], sha["mergetree"]
body = git("log", "-1", "--format=%B", GOOD)
REB, GOOD_BODY = body.split("\n", 1)
new = {}

# Review-4 reproductions on the rebuild itself.
dropped = {}
for path in ("tests/engine/test_pack_policies.py", "tests/branches/test_r6_chronology_quant_hub.py", "tests/stem/test_reading_extensions.py"):
    names = re.findall(r"^def (test_\w+)\(", blob(T, path), re.M)
    dropped[path] = set(names[1::6])  # every sixth test
DROPPED_TESTS = {p: drop_tests(blob(T, p), n) for p, n in dropped.items()}
new["tests_dropped_in_added_files"] = commit(tree_with(MTREE, DROPPED_TESTS), [FIXC, T], REB + "\n" + GOOD_BODY)
GUARD_PATH = "src/epinoic_logic/adapters/stem_specialist/parser.py"
g = blob(T, GUARD_PATH).split("\n")
gi = next(i for i, ln in enumerate(g) if ln.strip() == 'raise AdapterError("the specialist answer is empty")')
assert g[gi - 1].strip() == "if not text or not text.strip():", g[gi - 1]
GUARD_DROPPED = {GUARD_PATH: "\n".join(g[:gi - 1] + g[gi + 1:])}
new["guard_dropped"] = commit(tree_with(MTREE, GUARD_DROPPED), [FIXC, T], REB + "\n" + GOOD_BODY)
# A test renamed in a development-modified test file (one the overseer side never changed).
fx = set(git("diff", "--no-renames", "--name-only", MB, FIXC).split())
mods = [p for p in git("diff", "--no-renames", "--name-only", "--diff-filter=M", MB, T, "--", "tests").split() if p.endswith(".py") and p not in fx]
REN_PATH = next(p for p in mods if re.search(r"^def test_\w+\(", blob(T, p), re.M))
rtxt = blob(T, REN_PATH)
rname = re.search(r"^def (test_\w+)\(", rtxt, re.M).group(1)
new["test_renamed"] = commit(tree_with(MTREE, {REN_PATH: rtxt.replace(f"def {rname}(", f"def {rname}_renamed(", 1)}), [FIXC, T], REB + "\n" + GOOD_BODY)
# A test file the development side never changed (as at the merge base and at T), deleted by the rebuild.
devchg = set(git("diff", "--no-renames", "--name-only", MB, T).split())
BASE_TEST = next(p for p in sorted(git("ls-tree", "-r", "--name-only", T, "--", "tests").split())
                 if p.endswith(".py") and p not in devchg and p not in fx and re.search(r"^def test_\w+\(", blob(T, p), re.M))
new["base_test_file_deleted"] = commit(tree_with(MTREE, {BASE_TEST: None}), [FIXC, T], REB + "\n" + GOOD_BODY)

# Build steps on top of a rebuild (the build-step commit keeps the rebuild's tree, or edits it).
C2 = "Overseer contained round c2: fix judge findings"
C2_BODY = ("Fixes the judge findings of contained round c2.\n"
           "After: 110/110 tamperings detected, 0 false alarms on 254 genuine transfers; suite 4520 passed, 6 skipped in 600.00s.\n"
           "Harness after the change: r1 30/30, r1-adv 150/151, r2 46/46, r3 46/46, r4 46/46, r5 46/46, r6 46/46, r7 177/177\n")
for base in ("good", "overseer_whole", "notests", "dropped", "offdev", "squashed"):
    new[f"c2_on_{base}"] = commit(tree_of(sha[base]), [sha[base]], C2 + "\n\n" + C2_BODY)
# A later merge of the development side (not titled as a rebuild) whose second parent is not on the development branch,
# with a build step on top: translator_merge finds it, and it fails the structural checks.
new["devmerge_offdev"] = commit(MTREE, [GOOD, sha["offdev_head"]], "Merge the development branch into the overseer build\n")
new["c2_on_devmerge_offdev"] = commit(MTREE, [new["devmerge_offdev"]], C2 + "\n\n" + C2_BODY)
new["c2_drops_tests"] = commit(tree_with(tree_of(GOOD), DROPPED_TESTS), [GOOD], C2 + "\n\n" + C2_BODY)
new["c2_drops_guard"] = commit(tree_with(tree_of(GOOD), GUARD_DROPPED), [GOOD], C2 + "\n\n" + C2_BODY)

# The development branch merges the overseer side (review-4 minor): its head DEVM merges FIXC into T. A correct
# rebuild made later merges DEVM into a later overseer commit; a "rebuild" whose first parent is FIXC itself has its
# first parent in T's history.
DEVM = commit(MTREE, [T, FIXC], "Merge the logic-checking overseer agents into the translator\n")
new["dev_merged_overseer"] = DEVM
FIXC2 = commit(tree_of(FIXC), [FIXC], "Overseer: a later overseer commit after the development branch merged the overseer\n")
new["overseer_after_devmerge"] = FIXC2
new["later_rebuild"] = commit(MTREE, [FIXC2, DEVM], REB + "\n" + GOOD_BODY.replace(T[:7], DEVM[:7]))
new["p1_in_t"] = commit(MTREE, [FIXC, DEVM], REB + "\n" + GOOD_BODY.replace(T[:7], DEVM[:7]))

info = {"_renamed": f"{REN_PATH}::{rname}", "_base_test_file": BASE_TEST,
        "_dropped_tests": ";".join(f"{p}:{len(n)}" for p, n in dropped.items()), "_guard": f"{GUARD_PATH}:{gi}"}
keep = [ln for ln in lines if ln.split()[0] not in new]
with open(commits, "w") as fh:
    fh.write("\n".join(keep + [f"{k} {v}" for k, v in new.items()]) + "\n")
for k, v in {**new, **info}.items():
    print(k, v)
