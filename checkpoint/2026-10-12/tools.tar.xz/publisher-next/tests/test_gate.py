"""Gate tests on synthetic rebuild journals and commits (throwaway clone). Usage: test_gate.py GATE_DIR CLONE COMMITS OUT"""
import json
import os
import re
import subprocess
import sys

gate_dir, clone, commits_file, out = sys.argv[1:5]
sha = dict(l.split() for l in open(commits_file) if l.strip())
os.makedirs(out, exist_ok=True)
GOOD_EVAL = {"suite_passed": True, "suite_tail": "4520 passed, 6 skipped, 45 deselected in 600.00s", "failing_tests": [],
             "tamperings": 110, "tamperings_detected": 110, "false_alarms_on_genuine": 0, "genuine_transfers": 254,
             "contained_gates_ok": True, "contained_gates": "all pass", "harness_line": "r1 30/30", "export_ok": True}
STEP = {"staged": True, "suite": "4520 passed, 6 skipped", "harness": ["r7 162/162"], "contained_gates": "all pass",
        "test_changes": [{"test": "tests/overseer/test_trn.py", "change": "severity now from the engine",
                          "why_not_weaker": "asserts the error case and the warning case"}], "left_undone": []}
AUDIT_OK = {"ok": True, "violations": [], "measured": "suite 4520 passed"}
FEEDBACK = {"staged": True, "implemented": ["revision_request/1.0 built from trusted findings only"], "tests": ["tests/overseer/test_feedback.py"],
            "suite": "4520 passed, 6 skipped", "contained_gates": "all pass", "left_undone": []}
# A build step's evaluation (the build journal's eval:<round>; no rebuild fields).
C2_EVAL = {k: v for k, v in GOOD_EVAL.items() if k not in ("contained_gates_ok", "contained_gates", "export_ok")}
VIOL = [{"area": "tests", "problem": "assertion loosened", "evidence": "diff", "severity": "major"}]
AUDIT_BAD = {"ok": False, "violations": VIOL}


def journal(name, events):
    """events: (label, type, result) in order; each gets its own started/result (or failed) pair."""
    p = os.path.join(out, name + ".jsonl")
    with open(p, "w") as fh:
        fh.write(json.dumps({"type": "launched"}) + "\n")
        for i, (label, typ, res) in enumerate(events):
            k = f"v2:{name}:{i}"
            fh.write(json.dumps({"type": "started", "key": k, "label": label}) + "\n")
            fh.write(json.dumps({"type": typ, "key": k, **({"result": res} if typ == "result" else {"error": "x"})}) + "\n")
    return p


def std(c, ev=None, step=STEP, audit=AUDIT_OK, order=("step", "audit", "eval", "commit"), step_type="result", audit_type="result",
        feedback=FEEDBACK, feedback_type="result", add_feedback=True):
    """The rebuild workflow's journal in order. The specialist feedback step (rebuild:feedback) runs after the first merge
    step (the live workflow's order), so it is inserted after the first "step" unless the order names it or
    add_feedback is False."""
    if add_feedback and "step" in order and "feedback" not in order:
        i = order.index("step") + 1
        order = tuple(order[:i]) + ("feedback",) + tuple(order[i:])
    parts = {"step": ("rebuild:merge", step_type, step if step_type == "result" else None),
             "feedback": ("rebuild:feedback", feedback_type, feedback if feedback_type == "result" else None),
             "audit": ("rebuild:audit", audit_type, audit if audit_type == "result" else None),
             "repair": ("rebuild:merge", "result", step),
             "retest": ("rebuild:audit", "result", AUDIT_OK),
             "retest_bad": ("rebuild:audit", "result", AUDIT_BAD),
             "eval": ("eval:rebuild", "result", dict(GOOD_EVAL, **(ev or {}))),
             "commit": ("commit:rebuild", "result", {"committed": True, "sha": sha[c]})}
    return [parts[o] for o in order]


def c2std(c, ev=None):
    """A build step's journal (contained round c2): its fix step, its evaluation and its commit agent."""
    return [("fix:c2", "result", {"done": [{"item": "judge finding", "change": "fixed"}], "left_undone": []}),
            ("eval:c2", "result", dict(C2_EVAL, **(ev or {}))), ("commit:contained-c2", "result", {"committed": True, "sha": sha[c]})]


G = "good"
cases = [
    # name, commit, events, expect_ok, expected substring
    ("well_formed", G, std(G), True, "OK 4520 6"),
    ("well_formed_repaired_retested", G, std(G, audit=AUDIT_BAD, order=("step", "audit", "repair", "retest", "eval", "commit")), True, "OK 4520 6"),
    ("repaired_not_retested", G, std(G, audit=AUDIT_BAD, order=("step", "audit", "repair", "eval", "commit")), False, "did not complete after the repair"),
    ("retest_not_clean", G, std(G, audit=AUDIT_BAD, order=("step", "audit", "repair", "retest_bad", "eval", "commit")), False, "was not clean"),
    ("no_evaluation", G, std(G, order=("step", "audit", "commit")), False, "evaluation before the commit (eval:rebuild) did not complete"),
    ("eval_failed", G, std(G, order=("step", "audit")) + [("eval:rebuild", "failed", None)] + std(G, order=("commit",)), False, "(eval:rebuild) did not complete"),
    ("eval_before_step", G, std(G, order=("eval", "step", "audit", "commit")), False, "evaluation predates the step"),
    ("step_failed", G, std(G, step_type="failed"), False, "(rebuild:merge) did not complete"),
    ("no_step", G, std(G, order=("audit", "eval", "commit")), False, "(rebuild:merge) did not complete"),
    ("step_not_staged", G, std(G, step=dict(STEP, staged=False)), False, "did not leave the merge staged"),
    ("audit_missing", G, std(G, order=("step", "eval", "commit")), False, "the independent test (rebuild:audit) did not complete"),
    ("audit_null_failed", G, std(G, audit_type="failed"), False, "the independent test (rebuild:audit) did not complete"),
    ("audit_before_step", G, std(G, order=("audit", "step", "eval", "commit")), False, "the independent test (rebuild:audit) did not complete"),
    ("audit_after_eval", G, std(G, order=("step", "eval", "audit", "commit")), False, "the independent test (rebuild:audit) did not complete"),
    ("audit_not_ok_no_repair", G, std(G, audit=AUDIT_BAD), False, "was not clean: ok=False, 1 violation(s)"),
    ("audit_not_ok_empty_violations", G, std(G, audit={"ok": False, "violations": []}), False, "was not clean: ok=False, 0 violation(s)"),
    ("audit_ok_with_violations", G, std(G, audit={"ok": True, "violations": VIOL}), False, "reported ok with violations listed"),
    ("contained_gates_not_ok", G, std(G, ev={"contained_gates_ok": False}), False, "contained gate passing"),
    ("contained_gates_absent", G, std(G, ev={"contained_gates_ok": None}), False, "contained gate passing"),
    ("export_failed", G, std(G, ev={"export_ok": False}), False, "failed knowledge-pack export"),
    ("eval_false_alarms", G, std(G, ev={"false_alarms_on_genuine": 2}), False, "recorded 2 false alarms"),
    ("eval_missed_tampering", G, std(G, ev={"tamperings_detected": 108}), False, "108/110 tamperings detected"),
    ("eval_suite_failing", G, std(G, ev={"suite_passed": False, "failing_tests": ["tests/x.py::t"]}), False, "did not record a passing suite"),
    ("eval_failing_tests_only", G, std(G, ev={"failing_tests": ["tests/x.py::t"]}), False, "did not record a passing suite"),
    ("commit_sha_mismatch", G, std(G)[:4] + [("commit:rebuild", "result", {"committed": True, "sha": sha["wip"]})], False, "no journal record of commit:rebuild"),
    ("commit_not_committed", G, std(G)[:4] + [("commit:rebuild", "result", {"committed": False, "sha": sha[G]})], False, "no journal record of commit:rebuild"),
    ("msg_missed_tampering", "msg_missed", std("msg_missed"), False, "tamperings missed: 108/110"),
    ("msg_false_alarms", "msg_false_alarms", std("msg_false_alarms"), False, "false alarms recorded: 2"),
    ("msg_failing_suite", "msg_failing_suite", std("msg_failing_suite"), False, "the recorded suite has failures"),
    ("wrong_subject", "wrong_subject", std("wrong_subject"), False, "not a verified overseer build step"),
    ("wip_subject", "wip", std("wip"), False, "work in progress"),
    # review-2 minor: export_ok must be exactly true.
    ("export_absent", G, std(G, ev={"export_ok": None}), False, "export_ok not recorded"),
    # review-2 major 1: the rebuild is a two-parent merge of the STEM-merged translator into the overseer build's line.
    ("squashed_single_parent", "squashed", std("squashed"), False, "not a two-parent merge (1 parent(s))"),
    ("octopus_three_parents", "octopus", std("octopus"), False, "not a two-parent merge (3 parent(s))"),
    ("second_parent_before_stem", "no_stem", std("no_stem"), False, "is not a merge of the STEM-merged translator"),
    ("parents_swapped", "swapped", std("swapped"), False, "does not descend from the development branch's STEM merge"),
    ("first_parent_off_line", "p1_off_line", std("p1_off_line"), False, "is not on the overseer build's line"),
    # review-2 major 2: the rebuild keeps the translator as verified at T (its record at the STEM merge).
    ("harness_below_translator", "harness_below", std("harness_below"), False, "r7 170/177 (translator 177/177)"),
    ("harness_round_missing", "harness_missing_round", std("harness_missing_round"), False, "r6 not recorded (translator 46/46)"),
    ("harness_not_recorded", "harness_none", std("harness_none"), False, "drops below the translator"),
    ("harness_above_translator", "harness_above", std("harness_above"), True, "OK 4520 6"),
    ("translator_has_no_record", "t_no_record", std("t_no_record"), False, "has no \"Harness after the change\" record", "orphan_dev2"),
    # The STEM merge is now pinned (review-3 minor), so a development branch without it no longer hides it; the rebuild's
    # T is then not on that branch, which fails (the "no STEM merge anywhere" case is checked directly below).
    ("no_stem_on_dev_branch", G, std(G), False, "is not on the development branch", "stem^1"),
    # review-3 MAJOR: the tree keeps every development change since merge-base(p1, T) (three-way check on every path).
    ("tree_overseer_whole", "overseer_whole", std("overseer_whole"), False, "taken whole from the overseer side: README.md, src/epinoic_logic/branches/README.md, src/epinoic_logic/branches/hub.py"),
    ("tree_tests_deleted", "notests", std("notests"), False, "on 168 path(s): deleted by the rebuild: tests/"),
    ("tree_one_file_reverted", "partial", std("partial"), False, "on 1 path(s): reverted to the merge base: src/epinoic_logic/adapters/english_specialist/structural.py"),
    # Session policy (round 5): line-level differences in a file the development side changed are reported, not held;
    # these two pass the gate and their lines are listed by the report (report_* checks below).
    ("tree_file_replaced_reported", "replaced", std("replaced"), True, "OK 4520 6"),
    ("tree_one_hunk_dropped_reported", "hunk_dropped", std("hunk_dropped"), True, "OK 4520 6"),
    ("tree_all_dropped", "dropped", std("dropped"), False, "on 268 path(s)"),
    ("tree_dev_deletion_undone", "dev_deleted_kept", std("dev_deleted_kept"), False, "deleted by the development side but kept by the rebuild: THIRD_PARTY_NOTICES.md", "dev_deletes"),
    ("tree_merge_edits_pass", "merge_edit", std("merge_edit"), True, "OK 4520 6"),
    ("tree_dev_deletion_kept_passes", "dev_deleted_dropped", std("dev_deleted_dropped"), True, "OK 4520 6", "dev_deletes"),
    # review-3 MAJOR (suite): the evaluation passes at least the translator's recorded suite.
    ("eval_suite_below_translator", G, std(G, ev={"suite_tail": "4300 passed, 6 skipped in 500.00s"}), False, "passed fewer tests (4300 passed) than the translator as verified at"),
    ("eval_suite_no_count", G, std(G, ev={"suite_tail": "all green"}), False, "passed fewer tests (no passed count)"),
    ("translator_has_no_suite_record", "t_no_suite", std("t_no_suite"), False, "has no \"Suite: N passed\" record", "nosuite_dev"),
    # review-3 minors: T on the development branch; p1 on the overseer line and not on the development branch.
    ("second_parent_off_dev_branch", "offdev", std("offdev"), False, "is not on the development branch"),
    # review-4 minor: the "p1 on the development branch" check is replaced by "p1 already in T's history"; a first parent
    # on the development line is held by the overseer build's first commit.
    ("first_parent_on_dev_branch", "devp1", std("devp1"), False, "does not descend from the overseer build's first commit 3b13b46"),
    ("first_parent_side_line", "p1_side", std("p1_side"), False, "does not descend from the overseer build's first commit 3b13b46"),
    ("first_parent_in_t_history", "p1_in_t", std("p1_in_t"), False, "is already in the history of its second parent", "dev_merged_overseer"),
    ("good_after_dev_merged_overseer", G, std(G), True, "OK 4520 6", "dev_merged_overseer"),
    ("later_rebuild_after_dev_merged_overseer", "later_rebuild", std("later_rebuild"), True, "OK 4520 6", "dev_merged_overseer"),
    # Session policy (round 5) (a): a test function or class T has under tests/ or scripts/ missing from the candidate holds.
    ("tests_dropped_in_added_files", "tests_dropped_in_added_files", std("tests_dropped_in_added_files"), False, "on 3 path(s): development test(s) missing: tests/branches/test_r6_chronology_quant_hub.py (7 test(s): "),
    ("test_renamed", "test_renamed", std("test_renamed"), False, "development test(s) missing: tests/adapters_history/test_history_adapter.py (1 test(s): test_body1_roles_follow_the_claim_evidence_analysis_judgement_link_operation)"),
    ("base_test_file_deleted", "base_test_file_deleted", std("base_test_file_deleted"), False, "development test(s) missing: tests/adapters/test_consolidation_attribution.py ("),
    # A dropped line that is no test (review-4's guard_dropped) is reported, not held.
    ("guard_dropped_reported", "guard_dropped", std("guard_dropped"), True, "OK 4520 6"),
    # review-4 MAJOR 1: a build step on top of a rebuild gets the translator checks too.
    ("c2_on_good", "c2_on_good", c2std("c2_on_good"), True, "OK 4520 6"),
    ("c2_on_good_after_dev_merged_overseer", "c2_on_good", c2std("c2_on_good"), True, "OK 4520 6", "dev_merged_overseer"),
    ("c2_on_overseer_whole", "c2_on_overseer_whole", c2std("c2_on_overseer_whole"), False, "this commit (on the translator merged at a63ef0a) does not keep the development side's changes at 79056ae (since the merge base ae7b1e6) on 10 path(s): taken whole from the overseer side: README.md"),
    ("c2_on_notests", "c2_on_notests", c2std("c2_on_notests"), False, "on 168 path(s): deleted by this commit's line: tests/"),
    ("c2_on_dropped", "c2_on_dropped", c2std("c2_on_dropped"), False, "on 268 path(s)"),
    ("c2_on_offdev", "c2_on_offdev", c2std("c2_on_offdev"), False, "this commit sits on the rebuild acbcf36, which is not a well-formed translator merge: the rebuild acbcf36's second parent 98b8295 is not on the development branch"),
    ("c2_on_squashed", "c2_on_squashed", c2std("c2_on_squashed"), False, "this commit sits on the rebuild a2ae59c, which is not a well-formed translator merge: the rebuild a2ae59c is not a two-parent merge (1 parent(s))"),
    ("c2_on_devmerge_offdev", "c2_on_devmerge_offdev", c2std("c2_on_devmerge_offdev"), False, "which does not pass the rebuild's structural checks: the translator merge {devmerge_offdev}'s second parent 98b8295 is not on the development branch"),
    ("c2_drops_tests", "c2_drops_tests", c2std("c2_drops_tests"), False, "this commit (on the translator merged at c5df078) does not keep the development side's changes at 79056ae (since the merge base ae7b1e6) on 3 path(s): development test(s) missing: "),
    ("c2_drops_guard_reported", "c2_drops_guard", c2std("c2_drops_guard"), True, "OK 4520 6"),
    ("c2_eval_suite_below_translator", "c2_on_good", c2std("c2_on_good", ev={"suite_tail": "4300 passed, 6 skipped in 500.00s"}), False, "the evaluation passed fewer tests (4300 passed) than the translator as verified at 79056ae (Suite: 4353 passed"),
    ("c2_eval_suite_no_count", "c2_on_good", c2std("c2_on_good", ev={"suite_tail": "all green"}), False, "the evaluation passed fewer tests (no passed count)"),
    # review-5 MAJOR 1: a development test the candidate keeps but switches off while T runs it counts as missing (a).
    ("c2_skip_module_mark", "c2_skip_module_mark", c2std("c2_skip_module_mark"), False, "this commit (on the translator merged at c5df078) does not keep the development side's changes at 79056ae (since the merge base ae7b1e6) on 31 path(s): development test(s) switched off (missing under the policy): tests/stem/"),
    ("c2_xfail_decorators", "c2_xfail_decorators", c2std("c2_xfail_decorators"), False, "on 31 path(s): development test(s) switched off (missing under the policy): "),
    ("c2_conftest_ignore_glob", "c2_conftest_ignore_glob", c2std("c2_conftest_ignore_glob"), False, "on 31 path(s): development test(s) switched off (missing under the policy): "),
    ("c2_skipif_true", "c2_skipif_true", c2std("c2_skipif_true"), False, "this commit (on the translator merged at c5df078) does not keep the development side's changes at 79056ae (since the merge base ae7b1e6) on 1 path(s): development test(s) switched off (missing under the policy): tests/stem/test_reading_extensions.py (1 test(s): test_a_restatement_written_as_inline_maths_is_checked; a skip or xfail mark on "),
    ("c2_unittest_skip", "c2_unittest_skip", c2std("c2_unittest_skip"), False, "development test(s) switched off (missing under the policy): tests/stem/test_reading_extensions.py (1 test(s): test_a_restatement_written_as_inline_maths_is_checked; a skip or xfail mark on "),
    ("c2_body_skip", "c2_body_skip", c2std("c2_body_skip"), False, "development test(s) switched off (missing under the policy): tests/stem/test_reading_extensions.py (1 test(s): test_a_restatement_written_as_inline_maths_is_checked; a skip, xfail or importorskip call in the body of "),
    ("c2_body_xfail", "c2_body_xfail", c2std("c2_body_xfail"), False, "development test(s) switched off (missing under the policy): tests/stem/test_reading_extensions.py (1 test(s): test_a_restatement_written_as_inline_maths_is_checked; a skip, xfail or importorskip call in the body of "),
    ("c2_body_importorskip", "c2_body_importorskip", c2std("c2_body_importorskip"), False, "development test(s) switched off (missing under the policy): tests/stem/test_reading_extensions.py (1 test(s): test_a_restatement_written_as_inline_maths_is_checked; a skip, xfail or importorskip call in the body of "),
    ("c2_if_false", "c2_if_false", c2std("c2_if_false"), False, "development test(s) switched off (missing under the policy): tests/stem/test_reading_extensions.py (1 test(s): test_a_restatement_written_as_inline_maths_is_checked; test_a_restatement_written_as_inline_maths_is_checked defined under a constant-false condition)"),
    ("c2_redefined", "c2_redefined", c2std("c2_redefined"), False, "development test(s) switched off (missing under the policy): tests/stem/test_reading_extensions.py (1 test(s): test_a_restatement_written_as_inline_maths_is_checked; defined again later)"),
    ("c2_rebound", "c2_rebound", c2std("c2_rebound"), False, "development test(s) switched off (missing under the policy): tests/stem/test_reading_extensions.py (1 test(s): test_a_restatement_written_as_inline_maths_is_checked; test_a_restatement_written_as_inline_maths_is_checked bound again later in the file)"),
    ("c2_conftest_collect_ignore", "c2_conftest_collect_ignore", c2std("c2_conftest_collect_ignore"), False, "this commit (on the translator merged at c5df078) does not keep the development side's changes at 79056ae (since the merge base ae7b1e6) on 1 path(s): development test(s) switched off (missing under the policy): tests/stem/test_reading_extensions.py (39 test(s): "),
    ("c2_conftest_hook", "c2_conftest_hook", c2std("c2_conftest_hook"), False, "the hook pytest_collection_modifyitems in tests/conftest.py (in neither the translator nor the overseer side))"),
    ("c2_pyproject_ignore", "c2_pyproject_ignore", c2std("c2_pyproject_ignore"), False, "on 31 path(s): development test(s) switched off (missing under the policy): "),
    ("c2_pyproject_k", "c2_pyproject_k", c2std("c2_pyproject_k"), False, "addopts -k not stem in pyproject.toml (in neither the translator nor the overseer side))"),
    ("c2_pyproject_testpaths", "c2_pyproject_testpaths", c2std("c2_pyproject_testpaths"), False, "testpaths in pyproject.toml (tests/engine tests/overseer) leaves it out)"),
    ("c2_pytest_ini_deselect", "c2_pytest_ini_deselect", c2std("c2_pytest_ini_deselect"), False, "this commit (on the translator merged at c5df078) does not keep the development side's changes at 79056ae (since the merge base ae7b1e6) on 1 path(s): development test(s) switched off (missing under the policy): tests/stem/test_reading_extensions.py (1 test(s): test_a_restatement_written_as_inline_maths_is_checked; --deselect tests/stem/test_reading_extensions.py::test_a_restatement_written_as_inline_maths_is_checked (addopts --deselect in pytest.ini))"),
    ("c2_setup_cfg_ignore_glob", "c2_setup_cfg_ignore_glob", c2std("c2_setup_cfg_ignore_glob"), False, "--ignore-glob tests/stem/* in addopts --ignore-glob in setup.cfg)"),
    ("c2_tox_ini_norecursedirs", "c2_tox_ini_norecursedirs", c2std("c2_tox_ini_norecursedirs"), False, "norecursedirs in tox.ini matches stem (stem))"),
    # Not held: tests the development side never had, and tests T itself does not run (its own skip mark and
    # collect_ignore); a rebuild that runs them again passes too.
    ("c2_overseer_test_skipped", "c2_overseer_test_skipped", c2std("c2_overseer_test_skipped"), True, "OK 4520 6"),
    ("c2_overseer_conftest_ignore", "c2_overseer_conftest_ignore", c2std("c2_overseer_conftest_ignore"), True, "OK 4520 6"),
    ("tskip_rebuild_t_already_skips", "tskip_rebuild", std("tskip_rebuild"), True, "OK 4520 6", "tskip_dev"),
    ("c2_on_tskip_rebuild_t_already_skips", "c2_on_tskip_rebuild", c2std("c2_on_tskip_rebuild"), True, "OK 4520 6", "tskip_dev"),
    ("tskip_reenabled", "tskip_reenabled", std("tskip_reenabled"), True, "OK 4520 6", "tskip_dev"),
    # review-5 MAJOR 2: every translator merge on the candidate's line since the fork, oldest first. The phase-2
    # sequence: the development branch merges the rebuild, moves on, and the build merges it back (p2_merge).
    ("p2_c3_good", "p2_c3_good", c2std("p2_c3_good"), True, "OK 4520 6", "p2_dev"),
    ("p2_c3_reverts_pre_rebuild_dev_file", "p2_c3_reverts", c2std("p2_c3_reverts"), False, "this commit (on the translator merged at c5df078) does not keep the development side's changes at 79056ae (since the merge base ae7b1e6) on 1 path(s): reverted to the merge base: src/epinoic_logic/adapters/english_specialist/structural.py", "p2_dev"),
    ("p2_c3_deletes_pre_rebuild_dev_file", "p2_c3_deletes", c2std("p2_c3_deletes"), False, "this commit (on the translator merged at c5df078) does not keep the development side's changes at 79056ae (since the merge base ae7b1e6) on 1 path(s): deleted by this commit's line: src/epinoic_logic/branches/stem_pack.py", "p2_dev"),
    ("p2_c3_drops_guard_reported", "p2_c3_drops_guard", c2std("p2_c3_drops_guard"), True, "OK 4520 6", "p2_dev"),
    ("p2_c3_disables_dev_tests", "p2_c3_disables", c2std("p2_c3_disables"), False, "this commit (on the translator merged at {p2_merge}) does not keep the development side's changes at {p2_dev} (since the merge base c5df078) on 31 path(s): development test(s) switched off (missing under the policy): ", "p2_dev"),
    ("p2s_c3_follows_dev_superseded", "p2s_c3_follows_dev", c2std("p2s_c3_follows_dev"), True, "OK 4520 6", "p2s_dev"),
    ("p2_c3_reverts_dev_not_moved", "p2_c3_reverts", c2std("p2_c3_reverts"), False, "the translator merge {p2_merge}'s second parent {p2_dev} is not on the development branch"),
    ("c2_on_noop_merge", "c2_on_noop_partial", c2std("c2_on_noop_partial"), False, "this commit carries the translator merge {noop_merge}, which does not pass the rebuild's structural checks: the translator merge {noop_merge}'s second parent 79056ae is already in the history of its first parent affb641: it brings in nothing from the development branch"),
]
DEVB = "refs/heads/claude/z3-verification-engine-plan-nk3luq"
dev_head = subprocess.run(["git", "-C", clone, "rev-parse", DEVB], capture_output=True, text=True, check=True).stdout.strip()


def set_dev(target):
    rev = sha[target[:-2]] + "^1" if target.endswith("^1") else sha[target]
    subprocess.run(["git", "-C", clone, "update-ref", DEVB, rev], check=True)


fails = 0
for name, c, events, ok, want, *dev in cases:
    j = journal(name, events)
    if dev:
        set_dev(dev[0])
    try:
        p = subprocess.run(["python3", "-I", os.path.join(gate_dir, "overseer_gate.py"), clone, sha[c], j], capture_output=True, text=True)
    finally:
        subprocess.run(["git", "-C", clone, "update-ref", DEVB, dev_head], check=True)
    got = (p.stdout.strip().splitlines() or [""])[-1]
    want = re.sub(r"\{(\w+)\}", lambda m: sha[m.group(1)][:7], want)
    good = (p.returncode == 0) == ok and want in got
    fails += not good
    print(f"{'PASS' if good else 'FAIL'} {name:30s} exit={p.returncode} -> {got}")
p = subprocess.run(["python3", "-I", os.path.join(gate_dir, "overseer_gate.py"), clone, sha[G], os.path.join(out, "missing.jsonl")], capture_output=True, text=True)
good = p.returncode == 1 and "rebuild's journal is unreadable" in p.stdout
fails += not good
print(f"{'PASS' if good else 'FAIL'} {'missing_journal':30s} exit={p.returncode} -> {p.stdout.strip()}")

# The shared definitions used by simulate.sh (floor) and the note (translator basis), called directly.
sys.path.insert(0, gate_dir)
import overseer_gate as GT  # noqa: E402
import overseer_notes as ON  # noqa: E402
checks = []
fl, t, rc = GT.harness_floor(clone, sha["harness_below"])
checks.append(("floor_is_per_round_max", fl.get("r7") == (177, 177) and fl.get("r6") == (46, 46) and t == sha["devhead"] and rc == sha["stem"]))
fl, _, _ = GT.harness_floor(clone, sha["harness_above"])
checks.append(("floor_keeps_higher_own_count", fl.get("r1-adv") == (151, 151)))
checks.append(("floor_none_for_build_source", GT.harness_floor(clone, "origin/overseer-build") is None))
set_dev("orphan_dev2")
try:
    try:
        GT.harness_floor(clone, sha["t_no_record"])
        checks.append(("floor_fails_without_record", False))
    except ValueError as e:
        checks.append(("floor_fails_without_record", "no \"Harness after the change\" record" in str(e)))
finally:
    subprocess.run(["git", "-C", clone, "update-ref", DEVB, dev_head], check=True)
b = ON.translator_basis(clone, sha[G])
checks.append(("basis_is_rebuild", b and b["rebuild"] == sha[G] and b["translator"] == sha["devhead"] and b["stem"] == sha["stem"]))
needs, merged = ON.translator_changes(clone, b, sha[G])
checks.append(("good_merge_all_overseer_files", len(needs) > 0 and merged == []))
bd = ON.translator_basis(clone, sha["dropped"])
needs_d, merged_d = ON.translator_changes(clone, bd, sha["dropped"])
checks.append(("dropped_merge_files_disclosed", needs_d == needs and len(merged_d) > 0))
# A later first-parent merge of a newer development head supersedes the rebuild as the translator basis.
T_ = ["-c", "user.name=Test", "-c", "user.email=test@example.invalid"]
newer = subprocess.run(["git", "-C", clone, *T_, "commit-tree", sha["devhead"] + "^{tree}", "-p", sha["devhead"], "-m", "Testing README: progress, 22:00 UTC"], capture_output=True, text=True, check=True).stdout.strip()
later = subprocess.run(["git", "-C", clone, *T_, "commit-tree", sha[G] + "^{tree}", "-p", sha[G], "-p", newer, "-m", "Merge the development branch into the overseer build"], capture_output=True, text=True, check=True).stdout.strip()
subprocess.run(["git", "-C", clone, "update-ref", DEVB, newer], check=True)
try:
    bl = ON.translator_basis(clone, later)
finally:
    subprocess.run(["git", "-C", clone, "update-ref", DEVB, dev_head], check=True)
checks.append(("newer_merge_supersedes_rebuild", bl and bl["translator"] == newer and bl["merge"] == later and bl["rebuild"] is None))
checks.append(("basis_none_for_build_source", ON.translator_basis(clone, "origin/overseer-build") is None))
# review-3 minor: the STEM merge is pinned (sha and subject), then found in the source's own history, then on the
# development branch; translator merges and the floor survive the development branch being rewritten or removed.
import contextlib  # noqa: E402
import io  # noqa: E402
PIN, FIRST = GT.STEM_MERGE_SHA, GT.OVERSEER_FIRST_SHA
try:
    checks.append(("stem_pinned", GT.stem_merge(clone) == sha["stem"]))
    set_dev("faultfix")
    bp = ON.translator_basis(clone, sha[G])
    checks.append(("basis_survives_dev_ref_rewritten", bool(bp) and bp["translator"] == sha["devhead"] and bp["stem"] == sha["stem"]))
    checks.append(("floor_survives_dev_ref_rewritten", (GT.harness_floor(clone, sha[G]) or (None,))[0] is not None))
    GT.STEM_MERGE_SHA = sha["devhead"]  # a pin whose subject is not the STEM merge's is not used
    checks.append(("stem_wrong_subject_falls_back_to_source_history", GT.stem_merge(clone, sha[G]) == sha["stem"]))
    GT.STEM_MERGE_SHA = "0" * 40  # a pin the repository does not have
    checks.append(("stem_absent_pin_falls_back_to_source_history", GT.stem_merge(clone, sha[G]) == sha["stem"]))
    checks.append(("stem_none_when_nowhere", GT.stem_merge(clone, "origin/overseer-build") is None))
    reason, _, _ = GT.merge_structure(clone, sha["no_stem"], "the rebuild")
    checks.append(("gate_fails_when_no_stem_merge_anywhere", bool(reason) and "\"Merge STEM support into the translator\" was found (not the pinned" in reason))
    subprocess.run(["git", "-C", clone, "update-ref", DEVB, dev_head], check=True)
    checks.append(("stem_absent_pin_falls_back_to_dev_branch", GT.stem_merge(clone, "origin/overseer-build") == sha["stem"]))
    checks.append(("overseer_first_pinned", GT.overseer_first(clone) == FIRST))
    GT.OVERSEER_FIRST_SHA = "0" * 40
    checks.append(("overseer_first_falls_back_to_branch", GT.overseer_first(clone) == FIRST))
finally:
    GT.STEM_MERGE_SHA, GT.OVERSEER_FIRST_SHA = PIN, FIRST
    subprocess.run(["git", "-C", clone, "update-ref", DEVB, dev_head], check=True)
# Session policy (round 5): the line-level report (never a reason to hold).
GUARD = "src/epinoic_logic/adapters/stem_specialist/parser.py"
r = GT.development_report(clone, sha[G])
checks.append(("report_good_merge_keeps_every_line", r is not None and r["n"] == 0 and r["files"] == 0 and r["translator"] == sha["devhead"] and r["merge"] == sha[G]))
checks.append(("report_none_for_build_source", GT.development_report(clone, "origin/overseer-build") is None))
r = GT.development_report(clone, sha["merge_edit"])
checks.append(("report_merge_edits_keep_every_line", r is not None and r["n"] == 0))
r = GT.development_report(clone, sha["guard_dropped"])
checks.append(("report_guard_dropped_lists_the_guard", r is not None and r["files"] == 1 and list(r["lines"]) == [GUARD]
               and {ln for ln, _ in r["lines"][GUARD]} == {"if not text or not text.strip():", 'raise AdapterError("the specialist answer is empty")'}))
r = GT.development_report(clone, sha["c2_drops_guard"])
checks.append(("report_c2_drops_guard_lists_the_guard", r is not None and r["merge"] == sha[G] and list(r["lines"]) == [GUARD] and r["n"] == 2))
r = GT.development_report(clone, sha["replaced"])
checks.append(("report_replaced_lists_parser", r is not None and "src/epinoic_logic/adapters/english_specialist/parser.py" in r["lines"] and r["n"] > 50))
r = GT.development_report(clone, sha["hunk_dropped"])
checks.append(("report_hunk_dropped_lists_chronology", r is not None and list(r["lines"]) == ["src/epinoic_logic/adapters/history_specialist/chronology.py"]))
# Line accounting: verbatim, an import superset, an ordered token subsequence; a base copy the overseer side removed.
LNK = GT.lines_not_kept
checks.append(("lines_import_superset_kept", LNK("from m import a, b, c\n", "", "from m import a, c\n", "") == []))
checks.append(("lines_import_names_dropped", LNK("from m import a\n", "", "from m import a, c\n", "") == [("from m import a, c", 1)]))
checks.append(("lines_argument_added_kept", LNK("f(x, noted=n)\n", "", "f(x)\n", "") == []))
checks.append(("lines_reordered_tokens_reported", LNK("g(y, x)\n", "", "g(x, y)\n", "") == [("g(x, y)", 1)]))
checks.append(("lines_copies_counted", LNK("x = 1\n", "", "x = 1\nx = 1\n", "") == [("x = 1", 1)]))
checks.append(("lines_base_copy_removed_by_overseer", LNK("x = 1\n", "x = 1\n", "x = 1\nx = 1\n", "") == []))
checks.append(("lines_reindented_kept", LNK("    if a:\n        b()\n", "", "if a:\n    b()\n", "") == []))
# Test names: qualified by class, async and nested-in-if tests counted; a file this Python cannot parse is read by line.
TM = GT.tests_missing
checks.append(("tests_missing_qualified", TM("class TestA:\n    def test_x(self): pass\n", "class TestB:\n    def test_x(self): pass\n") == {"TestA": 1, "TestA.test_x": 1}))
checks.append(("tests_missing_async_and_if", TM("if True:\n    async def test_a(): pass\n", "") == {"test_a": 1}))
checks.append(("tests_missing_none_when_kept", not TM("def test_a(): pass\n", "import x\n\ndef test_a():\n    assert x\n")))
checks.append(("tests_missing_unparsable_falls_back", TM("def test_a(:\n", "def test_b(:\n") == {"test_a": 1}))
checks.append(("tests_missing_helpers_ignored", not TM("def helper(): pass\nclass Helper: pass\n", "")))
# review-5 MAJOR 1: switched-off tests, each form on its own (T runs test_a and TestB.test_c).
TD = GT.tests_disabled
TT = "import pytest\n\n\ndef test_a():\n    assert 1\n\n\nclass TestB:\n    def test_c(self):\n        pass\n"
OFF_FORMS = {
    "skip_mark": (TT.replace("def test_a", "@pytest.mark.skip\ndef test_a"), ["test_a"]),
    "skipif_mark": (TT.replace("def test_a", "@pytest.mark.skipif(sys.version_info > (3,), reason='x')\ndef test_a"), ["test_a"]),
    "xfail_mark": (TT.replace("def test_a", "@pytest.mark.xfail(strict=False)\ndef test_a"), ["test_a"]),
    "unittest_skip": (TT.replace("def test_a", "@unittest.skip('x')\ndef test_a"), ["test_a"]),
    "unittest_skipif": (TT.replace("def test_a", "@unittest.skipIf(True, 'x')\ndef test_a"), ["test_a"]),
    "unittest_expected_failure": (TT.replace("    def test_c", "    @unittest.expectedFailure\n    def test_c"), ["TestB.test_c"]),
    "mark_alias": ("later = pytest.mark.skip(reason='x')\n" + TT.replace("def test_a", "@later\ndef test_a"), ["test_a"]),
    "module_pytestmark": ("pytestmark = pytest.mark.skip\n" + TT, ["TestB", "TestB.test_c", "test_a"]),
    "module_pytestmark_list": ("pytestmark = [pytest.mark.stress, pytest.mark.xfail]\n" + TT, ["TestB", "TestB.test_c", "test_a"]),
    "class_pytestmark": (TT.replace("class TestB:\n", "class TestB:\n    pytestmark = pytest.mark.skip\n"), ["TestB", "TestB.test_c"]),
    "class_decorator": (TT.replace("class TestB:", "@pytest.mark.skip\nclass TestB:"), ["TestB", "TestB.test_c"]),
    "dunder_test_false": (TT.replace("class TestB:\n", "class TestB:\n    __test__ = False\n"), ["TestB", "TestB.test_c"]),
    "body_skip": (TT.replace("    assert 1", "    pytest.skip('x')\n    assert 1"), ["test_a"]),
    "body_xfail": (TT.replace("    assert 1", "    pytest.xfail('x')"), ["test_a"]),
    "body_importorskip": (TT.replace("    assert 1", "    mod = pytest.importorskip('nothere')\n    assert mod"), ["test_a"]),
    "body_skiptest": (TT.replace("        pass", "        self.skipTest('x')"), ["TestB.test_c"]),
    "body_raise_skiptest": (TT.replace("    assert 1", "    raise unittest.SkipTest('x')"), ["test_a"]),
    "module_skip": ("pytest.skip('x', allow_module_level=True)\n" + TT, ["TestB", "TestB.test_c", "test_a"]),
    "setup_module_skip": ("def setup_module():\n    pytest.skip('x')\n" + TT, ["TestB", "TestB.test_c", "test_a"]),
    "if_false": (TT.replace("def test_a():\n    assert 1", "if False:\n    def test_a():\n        assert 1"), ["test_a"]),
    "if_zero_class": (TT.replace("class TestB:\n    def test_c(self):\n        pass", "if 0:\n    class TestB:\n        def test_c(self):\n            pass"), ["TestB", "TestB.test_c"]),
    "else_of_true": (TT.replace("def test_a():\n    assert 1", "if True:\n    pass\nelse:\n    def test_a():\n        assert 1"), ["test_a"]),
    "if_main": (TT.replace("def test_a():\n    assert 1", "if __name__ == '__main__':\n    def test_a():\n        assert 1"), ["test_a"]),
    "redefined": (TT + "\n\ndef test_a():\n    pass\n", ["test_a"]),
    "rebound": (TT + "\ntest_a = None\n", ["test_a"]),
    "deleted_name": (TT + "\ndel test_a\n", ["test_a"]),
    "class_rebound": (TT + "\nTestB = object\n", ["TestB", "TestB.test_c"]),
}
for form, (cand, want) in OFF_FORMS.items():
    checks.append((f"tests_disabled_{form}", [q for q, _ in TD(TT, cand)] == want and not TM(TT, cand)))
# Not switched off: the same file, a conditional skip inside the body, a skip on another test, a test T itself skips.
checks.append(("tests_disabled_none_when_same", TD(TT, TT) == []))
checks.append(("tests_disabled_conditional_in_body_ignored", TD(TT, TT.replace("    assert 1", "    if X:\n        pytest.skip('x')\n    assert 1")) == []))
checks.append(("tests_disabled_new_test_skipped_ignored", TD(TT, TT + "\n\n@pytest.mark.skip\ndef test_new():\n    pass\n") == []))
TSK = OFF_FORMS["skip_mark"][0]
checks.append(("tests_disabled_t_already_skips", TD(TSK, TSK) == [] and TD(TSK, TSK.replace("@pytest.mark.skip", "@pytest.mark.skip\n@pytest.mark.xfail")) == []))
checks.append(("tests_disabled_t_already_dead_code", TD(OFF_FORMS["if_false"][0], OFF_FORMS["if_false"][0]) == []))
TSI = OFF_FORMS["skipif_mark"][0]
checks.append(("tests_disabled_same_conditional_skip_kept", TD(TSI, TSI) == []))
checks.append(("tests_disabled_conditional_skip_changed", [q for q, _ in TD(TSI, TSI.replace("(3,)", "(2,)"))] == ["test_a"]))
TIM = "import pytest\npytest.importorskip('epinoic_logic.translate.pipeline')\n\n\ndef test_a():\n    pass\n"
checks.append(("tests_disabled_module_importorskip_in_t_still_runs", [q for q, _ in TD(TIM, "pytestmark = pytest.mark.skip\n" + TIM)] == ["test_a"]))
checks.append(("tests_disabled_unparsable_is_not_guessed", TD(TT, "def test_a(:\n") == []))
# Collection: evaluated per file and per test; what cannot be evaluated is compared with T and the overseer side.
PYP = '[tool.pytest.ini_options]\ntestpaths = ["tests"]\naddopts = "-ra -m \'not stress\'"\n'
F = "tests/stem/test_a.py"


def coll(files, path=F, q="test_a", kind="function", base=None):
    rb, rc = GT.collection_rules(base or {"pyproject.toml": PYP}), GT.collection_rules(files)
    if GT.file_off(rb, path) or GT.name_off(rb, path, q, kind):
        return "T"
    novel = [v for k, v in rc["opaque"].items() if k not in rb["opaque"]]
    return GT.file_off(rc, path) or GT.name_off(rc, path, q, kind) or next((t for sc, t in novel if GT._under(path, sc)), None)


COLL = {
    "pyproject_ignore": ({"pyproject.toml": PYP.replace("-ra ", "-ra --ignore=tests/stem ")}, "--ignore tests/stem"),
    "pyproject_ignore_glob": ({"pyproject.toml": PYP.replace("-ra ", "-ra --ignore-glob='tests/st*' ")}, "--ignore-glob tests/st*"),
    "pyproject_deselect": ({"pyproject.toml": PYP.replace("-ra ", f"-ra --deselect {F}::test_a ")}, "--deselect"),
    "pyproject_k": ({"pyproject.toml": PYP.replace("-ra ", "-ra -k 'not stem' ")}, "addopts -k not stem"),
    "pyproject_m_changed": ({"pyproject.toml": PYP.replace("not stress", "not stress and not stem")}, "addopts -m not stress and not stem"),
    "pyproject_testpaths": ({"pyproject.toml": PYP.replace('["tests"]', '["tests/engine"]')}, "testpaths in pyproject.toml"),
    "pyproject_norecursedirs": ({"pyproject.toml": PYP + 'norecursedirs = ["st*"]\n'}, "norecursedirs"),
    "pyproject_python_files": ({"pyproject.toml": PYP + 'python_files = ["check_*.py"]\n'}, "python_files"),
    "pyproject_python_functions": ({"pyproject.toml": PYP + 'python_functions = ["check"]\n'}, "python_functions"),
    "pyproject_positional": ({"pyproject.toml": PYP.replace("-ra ", "-ra tests/engine ")}, "the arguments of addopts"),
    "pyproject_unreadable": ({"pyproject.toml": PYP + "[tool.pytest\n"}, "could not be read"),
    "pytest_ini_shadows": ({"pyproject.toml": PYP, "pytest.ini": "[pytest]\naddopts = --ignore=tests/stem/test_a.py\n"}, "--ignore tests/stem/test_a.py in addopts --ignore in pytest.ini"),
    "pytest_ini_override": ({"pyproject.toml": PYP, "pytest.ini": "[pytest]\naddopts = -o python_files=check_*.py\n"}, "python_files"),
    "setup_cfg": ({"pyproject.toml": PYP, "setup.cfg": "[tool:pytest]\naddopts = --ignore-glob=tests/stem/*\n"}, "setup.cfg"),
    "tox_ini": ({"pyproject.toml": PYP, "tox.ini": "[pytest]\naddopts = -p no:randomly --deselect tests/stem/test_a.py\n"}, "tox.ini"),
    "conftest_collect_ignore": ({"pyproject.toml": PYP, "tests/stem/conftest.py": "collect_ignore = ['test_a.py']\n"}, "collect_ignore test_a.py"),
    "conftest_collect_ignore_glob": ({"pyproject.toml": PYP, "tests/conftest.py": "collect_ignore_glob = ['st*/test_*.py']\n"}, "collect_ignore_glob"),
    "conftest_collect_ignore_append": ({"pyproject.toml": PYP, "conftest.py": "collect_ignore = []\ncollect_ignore.append('tests/stem')\n"}, "collect_ignore tests/stem"),
    "conftest_collect_ignore_dynamic": ({"pyproject.toml": PYP, "tests/stem/conftest.py": "import glob\ncollect_ignore = glob.glob('*.py')\n"}, "collect_ignore in tests/stem/conftest.py"),
    "conftest_hook": ({"pyproject.toml": PYP, "tests/conftest.py": "def pytest_ignore_collect(collection_path, config):\n    return 'stem' in str(collection_path)\n"}, "the hook pytest_ignore_collect"),
    "conftest_autouse_skip": ({"pyproject.toml": PYP, "tests/stem/conftest.py": "import pytest\n\n@pytest.fixture(autouse=True)\ndef _off():\n    pytest.skip('x')\n"}, "the autouse fixture _off"),
    "conftest_module_skip": ({"pyproject.toml": PYP, "tests/stem/conftest.py": "import pytest\npytest.skip('x', allow_module_level=True)\n"}, "a module-level skip in tests/stem/conftest.py"),
}
for form, (files, want) in COLL.items():
    got = coll(files)
    checks.append((f"collection_{form}", isinstance(got, str) and got != "T" and want in got))
checks.append(("collection_same_not_off", coll({"pyproject.toml": PYP}) is None))
checks.append(("collection_more_inclusive_not_off", coll({"pyproject.toml": PYP.replace(" -m 'not stress'", "")}) is None))
checks.append(("collection_other_dir_not_off", coll({"pyproject.toml": PYP.replace("-ra ", "-ra --ignore=tests/overseer/slow "), "tests/overseer/conftest.py": "collect_ignore = ['x.py']\ndef pytest_collection_modifyitems(items):\n    pass\n"}) is None))
checks.append(("collection_t_already_ignores", coll({"pyproject.toml": PYP, "tests/stem/conftest.py": "collect_ignore = ['test_a.py']\n"}, base={"pyproject.toml": PYP, "tests/stem/conftest.py": "collect_ignore = ['test_a.py']\n"}) == "T"))
checks.append(("collection_autouse_without_skip_not_off", coll({"pyproject.toml": PYP, "tests/conftest.py": "import pytest\n\n@pytest.fixture(autouse=True)\ndef _env(monkeypatch):\n    monkeypatch.setenv('X', '1')\n"}) is None))
checks.append(("collection_configure_markers_only_not_off", coll({"pyproject.toml": PYP, "tests/conftest.py": "def pytest_configure(config):\n    \"\"\"Markers.\"\"\"\n    config.addinivalue_line('markers', 'slow: slow')\n"}) is None))
checks.append(("collection_configure_other_is_off", "the hook pytest_configure" in (coll({"pyproject.toml": PYP, "tests/conftest.py": "def pytest_configure(config):\n    config.option.markexpr = 'not stem'\n"}) or "")))
checks.append(("collection_t_hook_kept_not_off", coll({"pyproject.toml": PYP, "tests/conftest.py": "def pytest_configure(config):\n    pass\n"}, base={"pyproject.toml": PYP, "tests/conftest.py": "def pytest_configure(config):\n    pass\n"}) is None))
# review-5 MAJOR 2: every translator merge on the line, oldest first; the report covers them all.
ml = GT.translator_merges(clone, sha["p2_c3_good"])
checks.append(("translator_merges_oldest_first", [m["merge"] for m in ml] == [sha[G], sha["p2_merge"]] and [m["translator"] for m in ml] == [sha["devhead"], sha["p2_dev"]]))
checks.append(("translator_merges_none_for_build_source", GT.translator_merges(clone, "origin/overseer-build") == []))
r = GT.development_report(clone, sha["p2_c3_drops_guard"])
checks.append(("report_p2_drops_pre_rebuild_guard", r is not None and r["merge"] == sha["p2_merge"] and list(r["lines"]) == [GUARD] and r["n"] == 2
               and {ln for ln, _ in r["lines"][GUARD]} == {"if not text or not text.strip():", 'raise AdapterError("the specialist answer is empty")'}))
r = GT.development_report(clone, sha["p2_c3_good"])
checks.append(("report_p2_good_keeps_every_line", r is not None and r["not_verbatim"] == 0 and r["files"] == 0))
r = GT.development_report(clone, sha["p2s_c3_follows_dev"])
checks.append(("report_p2s_superseded_lines_not_listed", r is not None and r["not_verbatim"] == 0 and r["lines"] == {} and r["rewritten"] == {}))
reason, _, _ = GT.merge_structure(clone, sha["noop_merge"], "the merge")
checks.append(("merge_structure_noop_merge_fails", bool(reason) and "is already in the history of its first parent" in reason))
# review-5 MINOR: every development line not there verbatim is counted, and those found rewritten are counted again.
LA = GT.line_accounting
checks.append(("accounting_argument_added_is_rewritten", LA("f(x, noted=n)\n", "", "f(x)\n", "") == ([], [("f(x)", 1)])))
checks.append(("accounting_import_superset_is_rewritten", LA("from m import a, b, c\n", "", "from m import a, c\n", "") == ([], [("from m import a, c", 1)])))
checks.append(("accounting_verbatim_is_neither", LA("x = 1\n", "", "x = 1\n", "") == ([], [])))
checks.append(("accounting_dropped_is_missing", LA("y = 2\n", "", "x = 1\n", "") == ([("x = 1", 1)], [])))
r = GT.development_report(clone, sha[G])
checks.append(("report_good_counts_the_rewritten_import", r["not_verbatim"] == 1 and r["m"] == 1 and r["n"] == 0 and r["not_verbatim_files"] == 1
               and r["rewritten"] == {"src/epinoic_logic/channel/bus.py": [("from typing import Callable, Mapping, Optional, Union", 1)]}))
r = GT.development_report(clone, sha["guard_dropped"])
checks.append(("report_guard_dropped_counts_both", r["not_verbatim"] == 3 and r["m"] == 1 and r["n"] == 2 and r["not_verbatim_files"] == 2))
nl = ON.kept_lines(GT.development_report(clone, sha["guard_dropped"]))
checks.append(("note_states_rewritten_count", "- development lines not kept verbatim: 3 in 2 files (1 of them found rewritten: an import with the same or more names, or their tokens in order); behaviour verified by the full suite and the recorded rounds." in nl
               and "  - `src/epinoic_logic/channel/bus.py`: 1 line(s), 1 of them found rewritten" in nl and f"  - `{GUARD}`: 2 line(s)" in nl))
for name, good in checks:
    fails += not good
    print(f"{'PASS' if good else 'FAIL'} {name}")
total = len(cases) + 1 + len(checks)
print(f"{total - fails}/{total} gate cases as expected")
sys.exit(1 if fails else 0)
