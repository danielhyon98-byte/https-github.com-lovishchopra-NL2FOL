from epinoic_logic.branches import RouterHub
from epinoic_logic.engine import SolverConfig
from epinoic_logic.integrity import WorkPlan
def run(text, q="A 1500 W heater runs for 14.6 s. Find the energy transferred."):
    hub = RouterHub(signing_key=b"k" * 32, key_id="hub", config=SolverConfig(timeout_ms=8000, memory_max_mb=None))
    hub.open_task(WorkPlan(plan_id="p", request_id="q", task_id="t", subject="Physics", task_type="calculation", selected_agent_ids=["physics-specialist"]))
    m, _, _ = hub.dispatch("t", "physics-specialist", q)
    _r, rc = hub.receive("t", m.message_id, text, agent_id="physics-specialist", report_id="r1")
    return rc
for label, t in [("plain slip", "E = 1500 × 14.6 = 21990 J"),
                 ("plain right", "E = 1500 × 14.6 = 21900 J"),
                 ("grouped slip", "E = 1500 × 14.6 = 21 990 J"),
                 ("grouped right", "E = 1500 × 14.6 = 21 900 J"),
                 ("thin slip", "E = 1500 × 14.6 = 21 990 J"),
                 ("comma slip", "E = 1500 × 14.6 = 21,990 J"),
                 ("list control", "The readings were 21 990 and 300 J.")]:
    rc = run(t)
    sf = [(f.code, f.severity, (f.message or "")[:120]) for f in rc.structural_findings]
    fc = [(c.satisfied, (getattr(c, "label", None) or getattr(c, "detail", None) or getattr(c, "constraint", None) or str(c))[:150]) for c in rc.formal_checks]
    print(f"{label:14s}", rc.status.value, sf[:2], fc[:2])
