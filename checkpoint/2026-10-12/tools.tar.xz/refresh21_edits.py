"""Apply the 21 November refresh edits to copies of the 16 November handoff documents."""
import pathlib
import sys

S = pathlib.Path(sys.argv[1])
SRC = S / "handoff" / "filled-16nov"
DST = S / "handoff" / "refresh-21nov"
DST.mkdir(parents=True, exist_ok=True)

DEV = "https://github.com/danielhyon98-byte/https-github.com-lovishchopra-NL2FOL"
F2FF = "2ff70224ca4a44a6a5f1164aa1183d12e225dcb3"
FAF6 = "af6dfe04ef67ad8c934767a78b0b743a14870513"
FEC9 = "ec911d5f2debba84326472df0092b22e21f17e25"
L2FF = f"[`{F2FF}`]({DEV}/commit/{F2FF})"
LAF6 = f"[`{FAF6}`]({DEV}/commit/{FAF6})"

CHANGES = []


def apply(name, edits):
    text = (SRC / name).read_text()
    for old, new in edits:
        n = text.count(old)
        if n != 1:
            raise SystemExit(f"{name}: expected one match, found {n}: {old[:90]!r}")
        text = text.replace(old, new)
        CHANGES.append((name, old, new))
    (DST / name).write_text(text)


# ---------------------------------------------------------------- report
apply("08-logic-translator.md", [
(
"""Written 16 November 2026 for Bruno's integration conversation and the website integration owner. It replaces the report
of 2 November (`d3af9f3e2dadcc37f127031b4c899888d5b898f3` on this branch, with its two companions), whose pin
(`verified-updates` `7a939fd`, development `16d5a4a`) and whose "round 8 in progress, architecture step and rounds 9-10
not started" are out of date. What changed: arena round 8""",
f"""Written 21 November 2026 for Bruno's integration conversation and the website integration owner. It refreshes the
report of 16 November (`{FEC9}` on this branch, with its two companions), which replaced the report
of 2 November (`d3af9f3e2dadcc37f127031b4c899888d5b898f3` on this branch, with its two companions), whose pin
(`verified-updates` `7a939fd`, development `16d5a4a`) and whose "round 8 in progress, architecture step and rounds 9-10
not started" are out of date. **The uploaded code is unchanged since 16 November.** What changed since then: on the
owner's request to resolve everything, development commit `{F2FF}` added the Geography and Language B
(Spanish) subject branches (decision D35), one shared self-certification reader consulted by every release path,
`POLICY_VERSION` 2026.11-v5 and contract 0.6; it was verified but its push check **held** it. The follow-up
`{FAF6}` fixed that check's other holds; it is on the development branch and **not uploaded**
(section 9). What changed before 16 November, and still stands: arena round 8"""),
(
"""**Source upload status: VERIFIED UPLOADED (9 Nov 17:37 UTC; read back 16 Nov 08:11 UTC).**""",
"""**Source upload status: VERIFIED UPLOADED (9 Nov 17:37 UTC; read back 16 Nov 08:11 UTC and again on 21 Nov).**"""),
(
"""architecture findings after round 8", 9 Nov 03:01 UTC). Read back: `git ls-remote` gives `verified-updates` at
`d920479811e4ab46fb80ff03664062f19aaad94c` (08:00 UTC), which contains `1c2fb5c`; `git diff c4f276c 1c2fb5c` outside""",
"""architecture findings after round 8", 9 Nov 03:01 UTC). Read back on 21 November: `git ls-remote` gives `verified-updates` at
`0467db35f48b482cf714631d70487b651862578c` (the hourly update of 19:00 UTC), which contains `1c2fb5c`, and `1c2fb5c` is
still the branch's last "Verified update:" commit (on 16 November the head was
`d920479811e4ab46fb80ff03664062f19aaad94c`); `git diff c4f276c 1c2fb5c` outside"""),
(
"""**The branch head moves every hour** with progress-only commits ("Hourly update: ..., no new final code"): the 86
commits from `1c2fb5c` to `d920479` each name `Source-Commit: c4f276ca060909e1e7d26c2ed403a6726c50eb2c` and change only
`docs/updates/` and `UPDATE_README.md` (files of `verified-updates`). Never cite the moving head as the pin.""",
"""**The branch head moves every hour** with progress-only commits ("Hourly update: ..., no new final code"): the 148
commits from `1c2fb5c` to `0467db3` (21 November, 19:00 UTC) each name
`Source-Commit: c4f276ca060909e1e7d26c2ed403a6726c50eb2c` and change only `docs/updates/` and `UPDATE_README.md` (files
of `verified-updates`); they carry no new final code. Never cite the moving head as the pin."""),
(
"""**Pull requests:** none for this work. Open refs read with `git ls-remote` on 16 November: `refs/pull/1` to `refs/pull/6`""",
"""**Pull requests:** none for this work. Open refs read with `git ls-remote` on 16 November and again on 21 November
(unchanged, no new pull ref): `refs/pull/1` to `refs/pull/6`"""),
(
"""- Branch [`claude/z3-verification-engine-plan-nk3luq`](https://github.com/danielhyon98-byte/https-github.com-lovishchopra-NL2FOL/tree/claude/z3-verification-engine-plan-nk3luq)
  moves (hourly notes): `beb5ee327590ab2518abb92e25437180c11a52c5` at 08:11 UTC on 16 November, over the last commit with
  content, [`ab9276ae26c6b4f959ed2d437bb3ab7a5b3dc0a6`](https://github.com/danielhyon98-byte/https-github.com-lovishchopra-NL2FOL/commit/ab9276ae26c6b4f959ed2d437bb3ab7a5b3dc0a6)
  ("Testing README: clearance round c3"). It carries the held rounds 9 and 10 (section 9).""",
f"""- Branch [`claude/z3-verification-engine-plan-nk3luq`](https://github.com/danielhyon98-byte/https-github.com-lovishchopra-NL2FOL/tree/claude/z3-verification-engine-plan-nk3luq)
  moves (hourly notes): read with `git ls-remote` on 21 November at
  {LAF6}
  ("Fix the c3 clearance findings", 21 Nov 19:15 UTC), which is also its last commit with content. On 16 November it was
  `beb5ee327590ab2518abb92e25437180c11a52c5` over
  [`ab9276ae26c6b4f959ed2d437bb3ab7a5b3dc0a6`](https://github.com/danielhyon98-byte/https-github.com-lovishchopra-NL2FOL/commit/ab9276ae26c6b4f959ed2d437bb3ab7a5b3dc0a6)
  ("Testing README: clearance round c3"). It carries the held rounds 9 and 10, the held `2ff7022` and the follow-up
  `af6dfe0` (section 9)."""),
(
"""**Main repository refs this work does not own** (16 November): `import/translator-baseline` (default, `650d1d3`,
untouched); `backup/verified-updates-previous` (`73cb2619aa4fedb2dfc2dfb9a2c20c4b0cefead6`, the previous hourly head,
moves every hour);""",
"""**Main repository refs this work does not own** (16 November; re-read 21 November, unchanged except the backup
head): `import/translator-baseline` (default, `650d1d3`, untouched); `backup/verified-updates-previous`
(`3668171ff16ccf0345174b640147eaf9bc0da9bb` on 21 November, the previous hourly head, moves every hour);"""),
(
"""in [Epinoic-Ai-Website](https://github.com/Epinoic-AI/Epinoic-Ai-Website) (merge of PR #35, 5 Nov 05:10 UTC; 11 commits after `b2ffbcc`). Not reviewed.""",
"""in [Epinoic-Ai-Website](https://github.com/Epinoic-AI/Epinoic-Ai-Website) (merge of PR #35, 5 Nov 05:10 UTC; 11 commits after `b2ffbcc`); a read-only
`git ls-remote` on 21 November gives the same commit. Not reviewed."""),
(
"""**Out of scope of the pin:** rounds 9 and 10 and their remedies (held, section 9);""",
"""**Out of scope of the pin:** rounds 9 and 10 and their remedies, and the resolution commits `2ff7022` (held) and
`af6dfe0` (not uploaded) (section 9);"""),
(
"""| IR / engine / translator / policy | `1.0` / `0.4.0` / `0.4.0` / `2026.10-v4` | none | none (`POLICY_VERSION` bump is an open decision) |""",
"""| IR / engine / translator / policy | `1.0` / `0.4.0` / `0.4.0` / `2026.10-v4` | none | none (the `POLICY_VERSION` bump came later, in `2ff7022`: `2026.11-v5`) |"""),
(
"""The kit's `integration-kit-v1` tag is **not created** (D20).""",
f"""**At `af6dfe0` (development branch, not uploaded; `2ff7022` the same):** policy `2026.11-v5`, contract **0.6**
(`docs/integration-contract.md`, dated 2026-11-16; `integration/COMPATIBILITY.json` there accepts only policy
2026.11-v5 and contract 0.6), translator public API `1.2`, `epinoic-flash-router` 0.5.0, `epinoic-overseer` 1.2.0 with
pack 2.2 (`ef3bed4fca02551f01dea7b1085829d5c6a723fed7222920761c819470771a28`, the only digest the service pins there),
combinator 0.1.5 (pack 1.4), kit integration tree `81ee8ce53f6b78c06f3afffba4cf676f7f7abd9b`, root
`z3-solver>=5.1.0,<5.2`; IR, engine and translator unchanged (1.0 / 0.4.0 / 0.4.0); rule 6d unchanged. New subject
branches `geography` and `language_b` (D35; subject map 2026-11-16.1). None of this is uploaded.

The kit's `integration-kit-v1` tag is **not created** (D20)."""),
(
"""Rounds 9 and 10 (held, not in the pin) are measured in section 9.""",
"""Rounds 9 and 10 and the resolution commits after them (held or not uploaded, not in the pin) are measured in
section 9. For this refresh of 21 November no check was run either: it read `git` (including `git ls-remote` of the
main, development and website repositories), the commit messages, `tests/README.md` and the push-check records."""),
(
"""**Preservation refs** `preserve/2026-10-16/*` (heads unchanged since the report of 2 November, read with `git ls-remote`):""",
"""**Preservation refs** `preserve/2026-10-16/*` (heads unchanged since the report of 2 November, read with `git ls-remote`,
last on 21 November):"""),
(
"""The held rounds' records are only on the development branch: [`tests/README.md` at `ab9276a`](https://github.com/danielhyon98-byte/https-github.com-lovishchopra-NL2FOL/blob/ab9276ae26c6b4f959ed2d437bb3ab7a5b3dc0a6/tests/README.md)
(sections "Arena round 9" and "Arena round 10").""",
f"""The held rounds' records are only on the development branch: [`tests/README.md` at `ab9276a`](https://github.com/danielhyon98-byte/https-github.com-lovishchopra-NL2FOL/blob/ab9276ae26c6b4f959ed2d437bb3ab7a5b3dc0a6/tests/README.md)
(sections "Arena round 9" and "Arena round 10"). The resolution after round 10 and decision D35 are also only there:
[`tests/README.md` at `af6dfe0`]({DEV}/blob/{FAF6}/tests/README.md)
(sections "Rounds 9 and 10: resolution attempt after round 10" and "D9/D10: the Geography and Language B branches
(decision D35)") and [`integration/DECISIONS.md` at `af6dfe0`]({DEV}/blob/{FAF6}/integration/DECISIONS.md)
(appendix D35)."""),
(
"""- This report supersedes the report of 2 November (`d3af9f3`) and its two companions.""",
f"""- This report supersedes the report of 16 November (`{FEC9}`) and, before it, the report
  of 2 November (`d3af9f3`), each with its two companions.
- D35 (16 November) amends D9/D10 for the `branch` column only: Geography and Language B (Spanish) route to their own
  branches on the development line from `2ff7022` on (not uploaded); at the pin they still route to `generic`."""),
(
"""**Held and unuploaded work: rounds 9 and 10.** On the development branch (pushed to `origin`, none uploaded):""",
"""**Held and unuploaded work: rounds 9 and 10 and the resolution commits.** On the development branch (pushed to
`origin`, none uploaded):"""),
(
"""| [`03a3021`](https://github.com/danielhyon98-byte/https-github.com-lovishchopra-NL2FOL/commit/03a30212c6d25d3f267858b8941a5ba7053ad2c7) | round 10 (c3) fixes | **39,129 passed, 1 xfailed, 1 skipped, 0 failed** (39,131 collected; three shards after a single run was stopped at 99% by a 7,200 s limit); harness r1 to r7 as above, c1 203/203, c2 188/188, **c3 164/176** | **HELD** |""",
f"""| [`03a3021`](https://github.com/danielhyon98-byte/https-github.com-lovishchopra-NL2FOL/commit/03a30212c6d25d3f267858b8941a5ba7053ad2c7) | round 10 (c3) fixes | **39,129 passed, 1 xfailed, 1 skipped, 0 failed** (39,131 collected; three shards after a single run was stopped at 99% by a 7,200 s limit); harness r1 to r7 as above, c1 203/203, c2 188/188, **c3 164/176** | **HELD** |
| {L2FF} | resolution on the owner's request: one shared self-certification reader (`epinoic_logic.selfcert`) consulted by every release path, the Geography and Language B (Spanish) branches (D35), `POLICY_VERSION` 2026.11-v5, contract 0.6, round 10's open items that still reproduced | **42,725 passed, 1 skipped, 29 deselected, 1 xfailed** (three shards of 42,727 collected); harness r1 to r7 as above, c1 203/203, c2 188/188, c3 164/176: every recorded round unchanged | **HELD** |
| {LAF6} | follow-up: fixes the other holds of `2ff7022`'s push check | **43,633 passed, 1 skipped, 29 deselected, 1 xfailed, 28 warnings in 4,517.84 s** (two shards of 43,635 collected); harness unchanged (c3 164/176) | no push-check record; not uploaded |"""),
(
"""**The open critical defect (why all four are held).** c2 results-audit bug 13 with adversarial-live bugs 10/11: an
answer whose own text certifies that it was checked (a self-certification) can still be delivered NOT CHECKED, because
the self-report readers (`is_self_report`, `is_self_certification`, `self_certifying_sentence`, `self_report_reading`)
are an open phrase list.""",
"""**The open critical defect (why all four are held, and `2ff7022` too).** c2 results-audit bug 13 with adversarial-live
bugs 10/11: an answer whose own text certifies that it was checked (a self-certification) can still be delivered NOT
CHECKED, because on the round commits the self-report readers (`is_self_report`, `is_self_certification`,
`self_certifying_sentence`, `self_report_reading`) are an open phrase list."""),
(
"""the fallback's NOT CHECKED or OVERSEER-SELECTED delivery.
""",
"""the fallback's NOT CHECKED or OVERSEER-SELECTED delivery.

**After round 10 (`2ff7022`, `af6dfe0`).** On the owner's request to resolve everything, with no status line on answers
and no documented limitation, `2ff7022` replaced those readers with one shared reader, `epinoic_logic.selfcert` (rules
`selfcert-1`, bound into the policy identity), which every release path consults; text it cannot read is refused
(CORE-SELF-002). Its push check (the push-check record of `2ff7022`) found every named sentence of the four earlier
holds now gated, the boundary (b) negatives still free, POLICY_VERSION 2026.11-v5 and the D9/D10 routing resolved, and
the safety majors of rounds 9 and 10 not regressed; it **held** the commit because fresh self-certifying phrasings are
still delivered on every release path (for example "Every figure in this response survived an independent recount."
delivered NOT CHECKED on 15 of 15 subjects; misses also delivered OVERSEER-SELECTED above 0.90), and for four further
holds: misspelling exemptions in the reader's lexicon, encoded check labels recorded as a limitation awaiting the
owner, two test pins of "(sat)" and "; this is fully reliable." as not self-certifications, and five stray scratch
directories committed at the repository root. `af6dfe0` fixed those four (its message: real-word exemptions from a
committed word source, encoded labels decoded and read, the solver label and the answer's own confidence gated, a debug
print of answer tokens removed, the scratch directories removed with a hygiene test); its check round after the fixes
still reproduced 72 items, and the class itself stays open pending the owner's decision on a meaning check.
"""),
(
"""**Decisions open with the owner (stated, not decided):**
1. **The self-certification class:** (a) a fixed status line on every answer that is not formally checked, so that no
   answer's own words can claim a check, or (b) keep the narrow reader and document the limitation.""",
"""**Decisions open with the owner (stated, not decided; items 3 and 4 are now settled on the development line):**
1. **The self-certification class:** the owner asked for it to be closed by meaning, with no status line and no
   documented limitation (the push-check record of `2ff7022`), which sets aside the former options (a) a fixed status
   line on every answer that is not formally checked and (b) keeping the narrow reader and documenting the limitation.
   `2ff7022` and `af6dfe0` still deliver fresh self-certifying phrasings; closing that needs the owner's decision on a
   meaning check."""),
(
"""   `1c2fb5c` was refused with HTTP 403 (recorded by the programme, not retried); `git ls-remote` on 16 November shows no
   tag on the main repository,""",
"""   `1c2fb5c` was refused with HTTP 403 (recorded by the programme, not retried; a repository admin must allow tag
   creation or create the tag); `git ls-remote` on 16 and on 21 November shows no tag on the main repository,"""),
(
"""3. **Subject branches for Geography and Language B (Spanish), a new decision under D9/D10:** they still route to the
   generic branch with no subject pack (the push-check record of `be91e89`: "the Geography and Language B branches still
   route to generic (decisions D9/D10 needed)"). `integration/DECISIONS.md` at `c4f276c` records D9/D10 as decided
   (History only on the website; `english` mapped only in `sim`; STEM checked by the service); the open question is
   whether these two subjects get branches or packs, so it does not appear to contradict that record.
4. **A `POLICY_VERSION` bump** for eligibility rule 0 (added in `fe2e639`, held), which would make recorded results stale.""",
"""3. **Subject branches for Geography and Language B (Spanish): decided as D35 (16 November 2026)**, under D9/D10. They
   get their own branches (`geography`, `language_b`, each with the shared core pack first and its own subject pack;
   subject map 2026-11-16.1), which resolves round 10's finding #18 that those subjects routed to the generic branch.
   Implemented in `2ff7022` (held) and carried in `af6dfe0` (not uploaded); at the pin they still route to the generic
   branch with no subject pack. `integration/DECISIONS.md` at `c4f276c` records D9/D10 as decided (History only on the
   website; `english` mapped only in `sim`; STEM checked by the service); D35 amends only the `branch` column and adds
   no website route.
4. **The `POLICY_VERSION` bump** for eligibility rule 0 (added in `fe2e639`, held): **done on the development line**
   in `2ff7022` (`2026.10-v4` to `2026.11-v5`, with the self-certification rules' digest bound into the policy identity;
   contract 0.5 to 0.6). A result signed under `2026.10-v4` is stale there. Not uploaded."""),
(
"""**Not done:** any live run through the product's provider path (arena answers and overseer verdicts are recorded
agent-session outputs, replayed); the upload of rounds 9 and 10 (held);""",
"""**Not done:** any live run through the product's provider path (arena answers and overseer verdicts are recorded
agent-session outputs, replayed); the upload of rounds 9 and 10 and of `2ff7022` (held) and `af6dfe0` (no push-check
record);"""),
(
"""1. **Daniel:** decide the self-certification class (decision 1); then the programme fixes it on the development branch,""",
"""1. **Daniel:** decide the meaning check for the self-certification class (decision 1); then the programme closes it on
   the development branch on top of `af6dfe0`,"""),
(
"""2. **Daniel:** the release tag (decision 2: allow tag pushes, or Bruno tags `1c2fb5c` himself), D9/D10, the policy bump.""",
"""2. **Daniel:** the release tag (decision 2: a repository admin allows tag creation, or Bruno tags `1c2fb5c` himself).
   D9/D10 (now D35) and the policy bump are done on the development line and travel with the next upload."""),
(
"""| 1 | Upload of rounds 9-10 | Held by push checks | **Yourself, only on Daniel's go** after decision 1: fix, verify, new push check, publisher |
| 2 | Release tag `prototype-round8-arch` | HTTP 403; the annotated tag exists only in the programme's local checkout (not uploaded) | **User input:** an owner allows tag pushes or tags `1c2fb5c` |
| 3 | Self-certification class; D9/D10; policy bump | Owner decisions | **User input:** Daniel |""",
"""| 1 | Upload of rounds 9-10, `2ff7022` and `af6dfe0` | Held by push checks (`af6dfe0`: no push-check record) | **Yourself, only on Daniel's go** after decision 1: fix, verify, new push check, publisher |
| 2 | Release tag `prototype-round8-arch` | HTTP 403; the annotated tag exists only in the programme's local checkout (not uploaded) | **User input:** a repository admin allows tag creation or tags `1c2fb5c` |
| 3 | Self-certification class (a meaning check) | Owner decision; D9/D10 (decided as D35) and the policy bump are done on the development line | **User input:** Daniel |"""),
])

# ---------------------------------------------------------------- instructions for Bruno
apply("08-instructions-for-bruno.md", [
(
"""Written 16 November 2026 for Bruno, from Daniel's programme; it replaces the note of 2 November.""",
"""Written 21 November 2026 for Bruno, from Daniel's programme; it refreshes the note of 16 November, which replaced the
note of 2 November. The code you are receiving has not changed since 16 November."""),
(
"""(VERIFIED UPLOADED, 9 Nov 17:37 UTC; read back 16 Nov: it carries""",
"""(VERIFIED UPLOADED, 9 Nov 17:37 UTC; read back 16 Nov and again 21 Nov: it carries"""),
(
"""it still says "Rounds 9 and 10 have not run" (section 7). Rounds 9 and 10 are recorded only in `tests/README.md` at `ab9276a` on the development branch |""",
"""it still says "Rounds 9 and 10 have not run" (section 7). Rounds 9 and 10 and the work after them are recorded only in `tests/README.md` on the development branch (rounds at `ab9276a`; the resolution attempt and decision D35 at `af6dfe0`) |"""),
(
"""can still be delivered NOT CHECKED, because the readers that catch such sentences are a list of phrasings. The last
check found 6 of 45 new phrasings and an obfuscated "VERIFIED" getting through on every subject. This defect is delivered NOT CHECKED on the operator's `deliver_canonical_not_checked` path (the
last check measured it with that setting); earlier checks (the push-check records of `bef76ad` and `fe2e639`, for example
12/12 at `fe2e639`) also showed it delivered OVERSEER-SELECTED above 0.90; the last check did not re-run that path. The uploaded code has none of the round 9 and 10 remedies.""",
"""can still be delivered NOT CHECKED, because the readers that catch such sentences are a list of phrasings. The
round-10 check found 6 of 45 new phrasings and an obfuscated "VERIFIED" getting through on every subject. This defect is delivered NOT CHECKED on the operator's `deliver_canonical_not_checked` path (the
round-10 check measured it with that setting); earlier checks (the push-check records of `bef76ad` and `fe2e639`, for example
12/12 at `fe2e639`) also showed it delivered OVERSEER-SELECTED above 0.90; the round-10 check did not re-run that path. The uploaded code has none of the round 9 and 10 remedies.

**Since 16 November:** on the owner's request to resolve everything, commit
`2ff70224ca4a44a6a5f1164aa1183d12e225dcb3` added the Geography and Language B (Spanish) subject branches (decision
D35), one shared self-certification reader consulted by every release path, policy `2026.11-v5` and contract 0.6. It
was verified (full suite 42,725 passed; every recorded round unchanged), but its push check held it: every item of the
four earlier holds is fixed, yet fresh self-certifying phrasings are still delivered (NOT CHECKED on 15 of 15
subjects, and OVERSEER-SELECTED above 0.90), and closing that needs the owner's decision on a meaning check. The
follow-up `af6dfe04ef67ad8c934767a78b0b743a14870513` fixed the check's other holds (43,633 passed, 1 skipped, 1
expected failure); it is on the development branch and not uploaded. Nothing new has been uploaded, so nothing changes
for you yet."""),
(
"""Website `main` has moved since our last
   read (now `b6720c1`, 5 November UTC); we did not check what it carries.""",
"""Website `main` has moved since our last
   read (now `b6720c1`, 5 November UTC; the same on 21 November); we did not check what it carries."""),
(
"""The
   development line at the pin carries contract 0.5, the overseer sub-project and the flash router.""",
"""The
   development line at the pin carries contract 0.5, the overseer sub-project and the flash router; the development
   commits after it (`2ff7022`, `af6dfe0`, not uploaded) carry contract 0.6 and policy `2026.11-v5`."""),
(
"""**Open with Daniel** (stated, not decided): (1) the self-certification class: a fixed status line on every answer that
is not formally checked, so no answer's own words can claim a check, or keep the narrow reader and document the
limitation; (2) the release tag for the round-8 upload (`prototype-round8-arch` at `1c2fb5c`, refused with HTTP 403; no
release tag exists on the main repository; the annotated tag exists only in the programme's local checkout, not
uploaded); (3) a new decision under D9/D10 (which `integration/DECISIONS.md` records as decided for History, `english`
and STEM): whether Geography and Language B (Spanish), which still route to the generic branch with no subject pack,
get subject branches or packs; (4) a `POLICY_VERSION` bump.""",
"""**Open with Daniel** (stated, not decided): (1) the self-certification class: the owner asked for it to be closed by
meaning, with no status line and no documented limitation; closing it needs the owner's decision on a meaning check;
(2) the release tag for the round-8 upload (`prototype-round8-arch` at `1c2fb5c`, refused with HTTP 403: a repository
admin must allow tag creation or create it; no release tag exists on the main repository; the annotated tag exists
only in the programme's local checkout, not uploaded). **Settled since 16 November on the development line, not
uploaded:** (3) Geography and Language B (Spanish) get subject branches (decision D35 under D9/D10, which
`integration/DECISIONS.md` records as decided for History, `english` and STEM; it adds no website route); until an
upload they still route to the generic branch in the code you have; (4) the `POLICY_VERSION` bump (`2026.11-v5`, with
contract 0.6)."""),
(
"""Any live run through the product's provider path; the upload of rounds 9 and 10 (held); the release tag (refused); scaling, the final report and the
website integration (not started).""",
"""Any live run through the product's provider path; the upload of rounds 9 and 10 and of `2ff7022` (held) and
`af6dfe0` (no push-check record); the release tag (refused, HTTP 403); scaling, the final report and the
website integration (not started)."""),
])

# ---------------------------------------------------------------- website launch package
apply("08-logic-translator-website-launch.md", [
(
"""Written 16 November 2026 from `git` reads of that day and the owner's preflight update of 25 October, which remains the
agents' launch state. It replaces the version of 2 November. What changed: the translator pin is now""",
"""Written 21 November 2026 from `git` reads of that day and the owner's preflight update of 25 October, which remains the
agents' launch state. It refreshes the version of 16 November, which replaced the version of 2 November. The
translator pin has not changed since 16 November and the integration steps below still use it: it is"""),
(
"""Rounds 9 and 10 are done
but **held and not uploaded** (report, section 9).""",
"""Rounds 9 and 10 are done
but **held and not uploaded** (report, section 9), and so are the two development commits after them:
`2ff70224ca4a44a6a5f1164aa1183d12e225dcb3` (held: the Geography and Language B branches of decision D35, one shared
self-certification reader, policy `2026.11-v5`, contract 0.6) and its follow-up
`af6dfe04ef67ad8c934767a78b0b743a14870513` (not uploaded)."""),
(
"""VERIFIED UPLOADED 9 Nov 17:37 UTC, read back 16 Nov (code of `c4f276c`;""",
"""VERIFIED UPLOADED 9 Nov 17:37 UTC, read back 16 Nov and again 21 Nov (code of `c4f276c`;"""),
(
"""The branch has moved on to the held rounds 9 and 10 (`03a3021`; `tests/README.md` sections at `ab9276a`; the head moves hourly with progress notes, `beb5ee3` at 08:11 UTC on 16 Nov); **do not take a kit from it**""",
"""The branch has moved on to the held rounds 9 and 10 (`03a3021`; `tests/README.md` sections at `ab9276a`), the held `2ff7022` and its follow-up `af6dfe0` (the head on 21 Nov; between content commits the head moves hourly with progress notes); **do not take a kit from it**"""),
(
"""read-only fetch 16 Nov `b6720c121d184a4b91f913ee638190a9dc770fd5` (merge of PR #35, 5 Nov 05:10 UTC; not reviewed)""",
"""read-only fetch 16 Nov `b6720c121d184a4b91f913ee638190a9dc770fd5` (merge of PR #35, 5 Nov 05:10 UTC; not reviewed); the same on 21 Nov (`git ls-remote`)"""),
(
"""held `03a3021` changes none of these versions; it moves the combinator to 0.1.5 and narrows the root `pyproject.toml`
to `z3-solver>=5.1.0,<5.2`.""",
"""held `03a3021` changes none of these versions; it moves the combinator to 0.1.5 and narrows the root `pyproject.toml`
to `z3-solver>=5.1.0,<5.2`. The later development commits do change versions: `2ff7022` and `af6dfe0` set policy
`2026.11-v5` and contract **0.6** (their `COMPATIBILITY.json` accepts only those), translator public API 1.2, flash
router 0.5.0 and overseer pack 2.2 (`ef3bed4f…`, the one digest the service pins there), and route Geography and
Language B to their own branches (D35, subject map 2026-11-16.1); IR, engine and translator stay 1.0 / 0.4.0 / 0.4.0.
None of this is uploaded."""),
(
"""critical, open at the pin and still open on the held commits (report, section 9);""",
"""critical, open at the pin and still open on the held commits, including `2ff7022` (its push check) and the follow-up
`af6dfe0`, pending the owner's decision on a meaning check (report, section 9);"""),
(
"""**Done, held:** rounds 9 and 10 (`be91e89`, `bef76ad`, `fe2e639`, `03a3021`). **To do, only on Daniel's go:** his decision on the self-certification class, its fix, a passing push check and the upload;""",
"""**Done, held:** rounds 9 and 10 (`be91e89`, `bef76ad`, `fe2e639`, `03a3021`) and the resolution commit `2ff7022` (D35 branches, shared self-certification reader, policy 2026.11-v5, contract 0.6). **Done, not uploaded, no push-check record:** `af6dfe0` (fixes `2ff7022`'s other holds). **To do, only on Daniel's go:** his decision on a meaning check for the self-certification class, its fix, a passing push check and the upload;"""),
(
"""**Version changes.** None at the pin. If a release bumps a component (the open `POLICY_VERSION` decision would),""",
"""**Version changes.** None at the pin. The development line after it bumps the policy (`2026.11-v5`) and the contract (0.6) and changes the subject map (D35, 2026-11-16.1); when a release carries them, or bumps any other component,"""),
(
"""- **Programme:** rounds 9 and 10 held on the development branch (`03a3021`: 39,129 passed, 0 failed; c3 164/176) until
  Daniel decides the self-certification class;""",
"""- **Programme:** rounds 9 and 10 held on the development branch (`03a3021`: 39,129 passed, 0 failed; c3 164/176), and
  with them `2ff7022` (held; 42,725 passed, 1 skipped, 1 xfailed; every recorded round unchanged) and `af6dfe0` (not
  uploaded; 43,633 passed, 1 skipped, 1 xfailed), until Daniel decides a meaning check for the self-certification class;"""),
(
"""- **Release tag** `prototype-round8-arch` at `1c2fb5c`: push refused (HTTP 403); no tag on the main repository.""",
"""- **Release tag** `prototype-round8-arch` at `1c2fb5c`: push refused (HTTP 403; a repository admin must allow tag
  creation or create it); no tag on the main repository (re-read 21 November)."""),
(
"""- **Superseded:** the version of this file of 2 November (pin `16d5a4a`, round 8 in progress, `KIT-HS-007` expected),""",
"""- **Superseded:** the version of this file of 16 November (`ec911d5f2debba84326472df0092b22e21f17e25`, same pin) and
  the version of 2 November (pin `16d5a4a`, round 8 in progress, `KIT-HS-007` expected),"""),
])

out = S / "refresh21_changes.txt"
with out.open("w") as fh:
    for name, old, new in CHANGES:
        fh.write(f"### {name}\n--- OLD\n{old}\n+++ NEW\n{new}\n\n")
print(len(CHANGES), "edits applied")
