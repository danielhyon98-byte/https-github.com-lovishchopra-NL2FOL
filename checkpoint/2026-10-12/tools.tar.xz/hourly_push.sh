#!/usr/bin/env bash
# The hourly check and push at the top of the hour (Daniel: "on the dot"; at most 2 min 30 s; utmost priority).
# Started a few minutes before the hour; waits until hh:00:00 UTC, then runs both publishers with the simulations prepared
# ahead of the hour (HOURLY_FAST=1: nothing is pushed without a passing simulation of that exact code), and logs timings.
# Usage: hourly_push.sh [--now]
set -uo pipefail
S=$(cd "$(dirname "$0")" && pwd)
if [ "${1:-}" != "--now" ]; then
  python3 -I -c "
import time
now = time.time()
target = (int(now) // 3600 + 1) * 3600
if target - now > 600:            # started more than 10 minutes early: run now rather than wait
    target = now
time.sleep(max(0, target - now))
"
fi
T0=$(date +%s)
LOG="$S/hourly-push-$(date -u +%Y%m%d-%H).log"
{
  echo "start $(date -u +%H:%M:%S)"
  ( cd "$S" && HOURLY_FAST=1 timeout 100 bash "$S/publish_final.sh" 2>&1 | tail -6 )
  echo "translator done $(( $(date +%s) - T0 ))s"
  ( cd "$S" && HOURLY_FAST=1 timeout 40 bash "$S/publish_overseer.sh" 2>&1 | tail -4 )
  echo "overseer done $(( $(date +%s) - T0 ))s; end $(date -u +%H:%M:%S)"
} > "$LOG" 2>&1
cat "$LOG"
