p = "src/epinoic_logic/branches/quant.py"
s = open(p, encoding="utf-8").read()
# 1. _Spec gets an optional rule
s = s.replace('''    phrase: str = ""          # the derived phrase or relation the check reads ('added roughly 4,500 miles'), for naming its claim


def _amount_comparable''', '''    phrase: str = ""          # the derived phrase or relation the check reads ('added roughly 4,500 miles'), for naming its claim
    rule: str = ""            # the rule the check applies, when it is not the kind's default (a duration with a qualifier or day dates)


def _amount_comparable''', 1)
# 2. remove the old duration block from _part_specs
start = s.index("    for m in _DURATION_RE.finditer(sent):\n")
end = s.index("    return specs, undecided\n\n\n#: 'From 1961 the flow slowed")
s = s[:start] + s[end:]
open(p, "w", encoding="utf-8").write(s)
