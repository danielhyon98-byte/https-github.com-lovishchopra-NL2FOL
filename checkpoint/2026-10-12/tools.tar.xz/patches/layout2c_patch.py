#!/usr/bin/env python3
"""8 Nov, third part: rounds 9 and 10 exercise the twofold (N_FOLD) review of combined answers live, and round 9 the specialist
feedback function once it exists. Conditional on LAYOUT2 / FEEDBACK_LIVE, so every prompt that already ran stays identical."""
import sys
src, dst = sys.argv[1], sys.argv[2]
t = open(src).read()
def rep(old, new, count=1):
    global t
    n = t.count(old)
    assert n == count, f"expected {count}, found {n}: {old[:140]!r}"
    t = t.replace(old, new)

rep("let LAYOUT2 = false\n",
    "let LAYOUT2 = false\n"
    "// Set when the architecture step's specialist feedback function was implemented (integrate:feedback returned): round 9 runs the\n"
    "// feedback exercise that round 8 could not (the function did not exist then).\n"
    "let FEEDBACK_LIVE = false\n")
rep("if (feedbackImpl) await verifyAndCommit([], 'Integration: specialist feedback and revision function',",
    "FEEDBACK_LIVE = !!feedbackImpl\nif (feedbackImpl) await verifyAndCommit([], 'Integration: specialist feedback and revision function',")
rep("  const fb = k === 1 ? await feedbackExercise(dir, round) : null\n",
    "  const fb = (k === 1 || (FEEDBACK_LIVE && k === 2)) ? await feedbackExercise(dir, round) : null\n")
# the overseer stage: combined answers reviewed N_FOLD (architecture step 3)
rep("issue BLIND dossiers per instance under that instance's own agent id ovs-w1-<i> exactly as the plan says (a transfer planned for duplicate review is issued to separate instances);",
    "issue BLIND dossiers per instance under that instance's own agent id ovs-w1-<i> exactly as the plan says (a transfer planned for duplicate review is issued to separate instances);${LAYOUT2 ? ' include every combined answer of the round (a synthesis citing the reports of two or more specialists) among the chosen transfers: the floor requires N_FOLD for each (overseer/README.md, the twofold mode), so issue its SOURCE dossiers (role source, one per specialist) in this first wave exactly as the plan says; its MERGED review needs the validated source verdicts and is issued in the next wave;' : ''}")
rep("Rebuild the intake from ${odir}/records/ with the package's harness tooling. For bundled instances",
    "Rebuild the intake from ${odir}/records/ with the package's harness tooling.${LAYOUT2 && wave === 2 ? ' COMBINED ANSWERS FIRST: for every combined answer whose SOURCE dossiers the first wave reviewed (N_FOLD), validate those source verdicts, build its temporary context with the package\\'s twofold tooling (overseer/src/epinoic_overseer/twofold.py: only what validation accepted, scoped to the request, bounded and recorded) and issue its MERGED-review dossier carrying that context through the intake under a new agent id ovs-w2-m<j>. Each is an instance of this wave that the floor requires (not a duplicate): list them first among the instances you return, with the reason N_FOLD merged review. If the tooling cannot build a context from these verdicts, issue none and say exactly why in the reasons.' : ''} For bundled instances")
rep("Combine the verdicts given on the same transfer by different instances with the package's verdict combination (one outcome per transfer, conflicts disclosed, repeated faults stopped), then score",
    "Combine the verdicts given on the same transfer by different instances with the package's verdict combination (one outcome per transfer, conflicts disclosed, repeated faults stopped)${LAYOUT2 ? '; combine the parts of every N_FOLD combined answer (its source and merged reviews) by the package\\'s rule and report, per combined answer, the source faults the synthesis kept, dropped and added, and whether its temporary context was complete, scoped, bounded, recorded and discarded (or that its merged review was not issued, and why)' : ''}, then score")
open(dst, 'w').write(t)
print("patched", len(t))
