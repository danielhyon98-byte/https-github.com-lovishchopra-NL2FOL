#!/usr/bin/env python3
"""8 Nov: phase2-cont.js edits for the steps after the architecture commit (sub-project layout). Every edit is conditional on
LAYOUT2 (set where ROUNDS_ENV is set, after commit:arch-overseer), so every prompt that already ran stays byte-identical."""
import sys
src, dst = sys.argv[1], sys.argv[2]
t = open(src).read()
def rep(old, new, count=1):
    global t
    n = t.count(old)
    assert n == count, f"expected {count} occurrence(s), found {n}: {old[:120]!r}"
    t = t.replace(old, new)

# 1. the flag and the carried records
rep("let ROUNDS_ENV = false\n",
    "let ROUNDS_ENV = false\n"
    "// 8 Nov: set after the architecture commit (ab44c8a). The overseer, the flash router and the combinator are sub-projects since then,\n"
    "// so the steps after it use the sub-project paths; every earlier prompt stays exactly as it ran (its result replays on resume).\n"
    "let LAYOUT2 = false\n"
    "// Records carried into a round's fixes from earlier rounds (8 Nov: round 8's leftovers, reproduced at 5060a52 and challenged;\n"
    "// filled in from wf/carry-c2/carry-c2.json before round c2's fix round). Each has the BUG fields plus source.\n"
    "const CARRY = {}\n")
rep("ROUNDS_ENV = true\n", "ROUNDS_ENV = true\nLAYOUT2 = true\n")

# 2. owners in the sub-project layout
rep("const ownerOf = b => (OWNERS.find(o => o.match.some(m => (b.file || '').includes(m))) || OWNERS[OWNERS.length - 1]).key\n",
    "// After the architecture commit (LAYOUT2): the sub-projects have their own owners, matched before the translator's.\n"
    "const OWNERS2 = [\n"
    "  { key: 'overseer', match: ['overseer/', 'OVERSEER_', 'epinoic_overseer'], paths: 'overseer/** (the overseer sub-project: overseer/src/epinoic_overseer/**, overseer/tests/**, overseer/scripts/**, overseer/docs/**, its README.md and pyproject.toml) and the pointer stubs docs/OVERSEER_*.md' },\n"
    "  { key: 'router', match: ['flash-router/', 'epinoic_flash_router'], paths: 'flash-router/** (the flash router sub-project: its package, data files, tests, docs, README.md and pyproject.toml)' },\n"
    "  { key: 'combinator', match: ['combinator/', 'epinoic_combinator'], paths: 'combinator/** (the combinator sub-project: its package, exported instructions, tests, docs, README.md and pyproject.toml)' },\n"
    "  { key: 'integration', match: ['integration/'], paths: 'integration/** (the integration kit: protocol, simulator, tools and vectors), src/epinoic_logic/integration/** and tests/integration/**' },\n"
    "  OWNERS[0], OWNERS[2], OWNERS[3], OWNERS[4],\n"
    "]\n"
    "const ownersNow = () => (LAYOUT2 ? OWNERS2 : OWNERS)\n"
    "const ownerOf = b => { const T = ownersNow(); return (T.find(o => o.match.some(m => (b.file || '').includes(m))) || T[T.length - 1]).key }\n")
rep("  const o = OWNERS.find(x => x.key === owner)\n", "  const o = ownersNow().find(x => x.key === owner)\n")

# 3. the overseer agents' preparation: sub-project paths and pool capacity kept for the later waves
rep("Read docs/OVERSEER_DESIGN.md and src/epinoic_logic/overseer/README.md (the fast profile, the oversight planner and the harness tools are documented there). Attach the logic-checking OVERSEER AGENTS",
    "${LAYOUT2 ? 'Read overseer/README.md and overseer/docs/OVERSEER_DESIGN.md (the overseer sub-project at overseer/, package epinoic_overseer: the fast profile, the oversight planner and its flash router attachment, the minimum-oversight floor and the harness tools are documented there)' : 'Read docs/OVERSEER_DESIGN.md and src/epinoic_logic/overseer/README.md (the fast profile, the oversight planner and the harness tools are documented there)'}. Attach the logic-checking OVERSEER AGENTS")
rep("(2) With the package's own harness tooling (scripts/overseer/), replay a copy of",
    "(2) With the package's own harness tooling (${LAYOUT2 ? 'overseer/scripts/' : 'scripts/overseer/'}), replay a copy of")
rep("within the self-duplicating pool's maximum (returned as max_instances); write the plan to ${odir}/plan.json",
    "within the self-duplicating pool's maximum (returned as max_instances)${LAYOUT2 ? ', keeping at least a quarter of that maximum (at least one instance) free for the self-duplication protocol\\'s later waves (round 8 left 9 contested transfers unresolved because its first wave used the whole pool; say in plan_summary how many instances the first wave leaves free)' : ''}; write the plan to ${odir}/plan.json")

# 4. translations bound to the claim texts they were produced for (round 8's harness fixer: from round 9 on)
rep("(including dependent tasks), run ${PY} ${REPO}/scripts/arena/list_claims.py <file> --eligible --json and produce, for EACH eligible claim, the object the instructions specify; peer tasks may quote",
    "(including dependent tasks), run ${PY} ${REPO}/scripts/arena/list_claims.py <file> --eligible --json and produce, for EACH eligible claim, the object the instructions specify;${LAYOUT2 ? ` save the listing you were given, exactly the stdout of that command, to ${dir}/listings/<task_id>.json (mkdir -p ${dir}/listings; it records the claim texts each translation is produced for);` : ''} peer tasks may quote", count=1)
rep("  ])\n  return { delivered: delivered.size, deps: deps.length }\n}\n",
    "  ])\n"
    "  // Round 8's harness fixer (8 Nov carry): from round 9 on, the recording step binds each translation fixture to the claim text it\n"
    "  // was produced for, right after the translation agents write their files, so a replay is not FIXTURES_UNBOUND.\n"
    "  if (LAYOUT2) {\n"
    "    const bind = await agent(`${CTX}\\nRecording step for ${tag}, right after the translation agents wrote ${dir}/translations/ and before anything changes the code: cd ${REPO} && ${PY} scripts/arena/bind_translations.py ${dir} --listings ${dir}/listings (the listings the translation agents saved). If it exits non-zero because a listing is missing or unreadable, run it once more with --current-parse instead of --listings and say so; never use --force. Do not modify source files, and nothing in ${dir} except what the tool writes. Return the tool's output (at most 1500 characters) and the exit status of each run.`, { label: `bind:${tag}`, phase: phaseName, effort: 'low' })\n"
    "    log(`${tag}: translations bound to their claim texts: ${String(bind || 'no result').slice(0, 300)}`)\n"
    "  }\n"
    "  return { delivered: delivered.size, deps: deps.length }\n}\n")

# 5. carried records join the round's findings; the push check counts the carried critical ones
rep("  const bugs = present.flatMap(r => r.bugs)\n  const fx = await fixRound(bugs, `The overseers of arena round ${8 + k - 1} (integrated round ${round}; reports in ${dir}/overseers/) found these defects.`,",
    "  const carried = LAYOUT2 ? (CARRY[round] || []) : []\n"
    "  if (carried.length) log(`${round}: ${carried.length} records carried from earlier rounds join the ${present.flatMap(r => r.bugs).length} findings`)\n"
    "  const bugs = present.flatMap(r => r.bugs).concat(carried)\n"
    "  const fx = await fixRound(bugs, `The overseers of arena round ${8 + k - 1} (integrated round ${round}; reports in ${dir}/overseers/) found these defects.${carried.length ? ` The list also carries ${carried.length} records from earlier rounds, each reproduced at an earlier commit and challenged before this round (field source names where each came from): check that each still reproduces, then fix it like the others.` : ''}`,")
rep("+ `. ${bugs.length} findings; fixed:\\n${fx.lines.join('\\n').slice(0, 6000)}",
    "+ `. ${bugs.length} findings${carried.length ? ` (${carried.length} carried from earlier rounds)` : ''}; fixed:\\n${fx.lines.join('\\n').slice(0, 6000)}")
rep("in ${dir}/overseers/*.json and in the validated overseer-agent findings under ${WF2}/${round}/overseer-agents/; check each against the committed code and its regression test.",
    "in ${dir}/overseers/*.json and in the validated overseer-agent findings under ${WF2}/${round}/overseer-agents/${carried.some(b => b.critical === true || b.severity === 'blocker') ? `, and every critical or blocker record carried into this round's fixes from earlier rounds: ${JSON.stringify(carried.filter(b => b.critical === true || b.severity === 'blocker').map(b => ({ file: b.file, summary: String(b.summary || '').slice(0, 300), source: b.source })))}` : ''}; check each against the committed code and its regression test.")

open(dst, 'w').write(t)
print("patched", len(t), "bytes")
