"""Build the flash-arm helper workflows for one pilot round of the overseer rebuild, from the rebuild script itself and the
prep result in its journal, so prompts, models and labels are identical. Usage:
python3 -I make_arm_helper.py <overseer-rebuild.js> <journal.jsonl> <tag> <parts> <outdir>"""
import json, re, sys
src, journal, tag, parts, outdir = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4]), sys.argv[5]
L = open(src).read().split('\n')
START = re.compile(r'^(const |let |function |async function |// |phase\(|if \(|for \(|await |log\(|return |export |m = |a = |fm = |prep = )')
def stmt(name):
    hits = [i for i, l in enumerate(L) if l.startswith(f'const {name} = ')]
    assert len(hits) == 1, (name, hits)
    i = hits[0]; j = i + 1
    while j < len(L) and not START.match(L[j]): j += 1
    return '\n'.join(L[i:j]).rstrip()
body = '\n'.join(stmt(n) for n in ['S', 'WF', 'FW', 'promptA', 'promptB', 'armInstances', 'markerOf'])
ev = [json.loads(l) for l in open(journal)]
lab = {e['agentId']: e.get('label') for e in ev if e.get('type') == 'started'}
prep = fm = None
for e in ev:
    if e.get('type') != 'result': continue
    l = lab.get(e['agentId']); r = e.get('result')
    if l == 'rebuild:merge' and isinstance(r, dict) and r.get('prompt_fast'): fm = r
    if l == f'flash-prep:{tag}': prep = r; fm_at_prep = fm
assert prep and fm_at_prep, 'no prep or fast-profile result for ' + tag
with_a = tag == 'f1'
for p in range(parts):
    hargs = {'tag': tag, 'withA': with_a, 'pr': prep, 'tmpl': fm_at_prep['prompt_fast'], 'part': p, 'parts': parts}
    open(f'{outdir}/arm-helper-{tag}-{p}.js', 'w').write(f"""export const meta = {{
  name: 'flash-arms-{tag}-part-{p}',
  description: 'Run part {p + 1} of {parts} of the Haiku overseer instances of oversight pilot round {tag} for the overseer rebuild (two agents per workflow on this machine); prompts, models and labels built from the rebuild script; writes a marker per finished instance',
  phases: [{{ title: 'Arms', detail: 'overseer instances' }}],
}}
{body}
const HARGS = {json.dumps(hargs)}
phase('Arms')
const insts = armInstances(HARGS.tag, HARGS.pr, HARGS.withA, HARGS.tmpl).filter((x, i) => i % HARGS.parts === HARGS.part)
const out = await parallel(insts.map(x => () => agent(x.prompt, {{ label: x.label, phase: 'Arms', ...x.opts }})))
const done = insts.filter((x, i) => out[i] !== null && out[i] !== undefined)
if (done.length) await agent(`Run exactly: mkdir -p ${{FW}}/${{HARGS.tag}}/arms-done && touch ${{done.map(x => "'" + markerOf(HARGS.tag, x.label) + "'").join(' ')}} . Do nothing else.`, {{ label: `flash-arms-mark:${{HARGS.tag}}:${{HARGS.part}}`, phase: 'Arms', effort: 'low' }})
return {{ part: HARGS.part, instances: insts.length, finished: done.length }}
""")
print(f'{parts} helper(s) for {tag}: instances total', 'see scripts')
