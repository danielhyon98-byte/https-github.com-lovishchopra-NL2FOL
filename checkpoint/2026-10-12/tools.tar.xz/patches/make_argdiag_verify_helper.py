"""Build the argument-diagnostics verification helper from the main workflow script, so its lens prompts are the main
script's own verifyPrompt. Usage: python3 -I make_argdiag_verify_helper.py <argument-diagnostics script> <out.js>
Launch: Workflow({scriptPath: out, args: {round: <n>, keys: ['adversarial', 'rerun']}}) as soon as repair:<n-1> returns."""
import re, sys
src, out = sys.argv[1], sys.argv[2]
L = open(src).read().split('\n')
START = re.compile(r'^(const |let |function |async function |// |phase\(|if \(|for \(|await |log\(|return |export )')
def stmt(name):
    hits = [i for i, l in enumerate(L) if l.startswith(f'const {name} = ')]
    assert len(hits) == 1, (name, hits)
    i = hits[0]; j = i + 1
    while j < len(L) and not START.match(L[j]): j += 1
    return '\n'.join(L[i:j]).rstrip()
NAMES = ['S', 'R', 'DEVB', 'BASE', 'VPY', 'AUD', 'AUDJ', 'WF', 'COR', 'E2E', 'STR', 'STRS', 'LABELS', 'CTX', 'RERUN',
         'ISSUE', 'VER', 'IT', 'LENSES', 'verifyPrompt']
body = '\n'.join(stmt(n) for n in NAMES)
open(out, 'w').write("""export const meta = {
  name: 'argdiag-verify-lenses',
  description: 'Run a share of one argument-diagnostics verification round (two agents per workflow on this machine, so this runs beside the main workflow); prompts are the main script verifyPrompt; each result is written for the main workflow to collect',
  phases: [{ title: 'Verify', detail: 'the lenses named in args.keys for round args.round' }],
}
""" + body + """
const ROUND = args.round, KEYS = args.keys
phase('Verify')
const mine = LENSES.filter(l => KEYS.includes(l.key))
const file = (l) => `${WF}/verify-${ROUND}/${l.key}/result.json`
const out = await parallel(mine.map(l => () => agent(verifyPrompt(l, ROUND) + `\\nBEFORE RETURNING write exactly the JSON you return to ${file(l)} (mkdir -p first; python3 -I with json.dump).`, { label: `verify:${l.key}:${ROUND}:run`, phase: 'Verify', schema: VER, effort: 'high' })))
await agent(`For each entry below, check that the file exists and parses as JSON with the fields ok, measured and issues; for any that does not, write the JSON given for it to that path exactly (mkdir -p first; python3 -I with json.dump). Do nothing else. Entries: ${JSON.stringify(mine.map((l, i) => ({ path: file(l), json: out[i] || { ok: false, measured: 'the helper lens did not return', issues: [{ id: 'verifier-failed', area: 'verification', severity: 'high', problem: 'the helper verifier did not return; re-measure this lens' }] } })))}`, { label: `verify:${ROUND}:write`, phase: 'Verify', effort: 'low' })
return { round: ROUND, keys: KEYS, returned: mine.map((l, i) => ({ lens: l.key, ok: out[i] ? out[i].ok : null, issues: out[i] ? out[i].issues.length : null })) }
""")
print('wrote', out)
