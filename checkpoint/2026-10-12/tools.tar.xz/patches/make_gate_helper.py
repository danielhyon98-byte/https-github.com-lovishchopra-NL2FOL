"""Build the integration-gate helper workflow from phase2-pipeline.js so its lens prompts are identical to the pipeline's.
Usage: python3 -I make_gate_helper.py <phase2-pipeline.js> <out.js>"""
import re, sys
src, out = sys.argv[1], sys.argv[2]
L = open(src).read().split('\n')
START = re.compile(r'^(const |let |function |async function |// |phase\(|if \(|for \(|await |log\(|return |export )')
def stmt(name):
    hits = [i for i, l in enumerate(L) if l.startswith(f'const {name} = ')]
    assert len(hits) == 1, (name, hits)
    i = hits[0]; j = i + 1
    while j < len(L) and not START.match(L[j]): j += 1
    return '\n'.join(L[i:j]).rstrip()
NAMES = ['REPO', 'S', 'PY', 'WF2', 'BRANCH', 'CTX', 'STR', 'STRS', 'BUG', 'GATE', 'CONNECTOR_REPO', 'WEBSITE_REPO', 'ILENSES', 'RERUN_KEYS', 'RERUN_NOTE', 'gateLensPrompt']
body = '\n'.join(stmt(n) for n in NAMES)
open(out, 'w').write("""export const meta = {
  name: 'integration-gate-lenses',
  description: 'Run a share of one integration-gate round of the round 8 pipeline (two agents per workflow on this machine, so several of these run side by side); prompts built from the pipeline itself; each lens writes its report for the pipeline collector',
  phases: [{ title: 'Gate', detail: 'the lenses named in args.keys for round args.g' }],
}
""" + body + """
const G = args.g, KEYS = args.keys
phase('Gate')
const mine = ILENSES.filter(l => KEYS.includes(l.key))
const out = await parallel(mine.map(l => () => agent(gateLensPrompt(l, G), { label: `gate:${l.key}:g${G}:run`, phase: 'Gate', schema: GATE, effort: 'high' })))
await agent(`For each entry below, check that the file exists and parses as JSON; for any that does not, write the JSON given for it to that path exactly (python3 -I with json.dump). Do nothing else. Entries: ${JSON.stringify(mine.map((l, i) => ({ path: `${WF2}/integrate/g${G}/${l.key}/report.json`, json: out[i] })).filter(e => e.json)).slice(0, 200000)}`, { label: `gate:files:g${G}`, phase: 'Gate', effort: 'low' })
return { g: G, keys: KEYS, returned: mine.map((l, i) => ({ lens: l.key, ok: !!out[i], passed: out[i] ? out[i].passed : null, bugs: out[i] ? (out[i].bugs || []).length : null })) }
""")
print('wrote', out)
