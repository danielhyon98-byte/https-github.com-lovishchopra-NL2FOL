# End-to-end simulation, run 1: overall judgement

**Scope.** This is a simulation run on a frozen local copy of the translator package
(`epinoic_logic`, tree commit `0cadc3c`). No live website, deployed service or live
model provider was contacted. The HTTP checks used a service started on 127.0.0.1 for
this run only. Every engine result proves a property of its encoding only: it does not
show that a premise is true, that a translation is faithful, or that a reading is
correct. The specialists, the translation provider, the combinator and the overseer
agents ran on the cheapest model tier. The judging below was done on the strongest
tier, against the files on disk.

Files judged (paths relative to the e2e directory): `run1/inputs.md`, `run1/tasks.json`,
all 16 files in `run1/specialists/`, `run1/relayed/` (2 peer reports),
`run1/translations/` (16 files, 224 claim records, 156 IR problems), `run1/syntheses/`
(16 files), the arena round results (`harness/rounds/arena_subprocess/run1/results.json`
and `summary.md`; the instrumented copy is identical), `run1-overseer/` (39 verdicts,
gold, score), `harness/timings.json`, `harness/gate.json` and `agent_times.json`.

## 0. Were all sixteen specialists deployed, and was any output cut?

Yes, all sixteen were deployed. Nothing was cut.

- **Deployment.** `agent_times.json` records 16 distinct specialist agents on the
  cheapest tier: 8 in the first wave, the 2 peer-dependent specialists (History and
  ESS), and 6 in the top-up. `harness/timings.json` confirms 16 routed tasks, 16 answers,
  16 distinct agents and 16 knowledge bases, with no unrouted file.
- **The ten-task stage.** An earlier build of this run had 10 tasks. It is kept as
  `run1_build/tasks.before-topup.json`. The top-up restored all sixteen before any
  translation or checking ran.
- **Answer lengths.** Every answer on disk is complete, from 235 to 810 words. The
  lengths differ because the students set word limits (word counts in §3).
- **Why the output can look reduced.** The `output` column of `agent_times.json` does
  not measure answer size. It records 14 output tokens for the 326-word Business
  answer and 33 for the 271-word English answer. Read that column, and the outputs
  look cut when they are not. This is logged as bug B24.

## 1. The requests

There are 14 website requests and 16 routed tasks. Twelve requests take the fast path
(one specialist each). Requests 7 and 8 each go to two specialists, and the second
specialist answers from the first one's relayed report.

| # | Request | Task(s) | Student's specific questions |
| --- | --- | --- | --- |
| 1 | English A Lang & Lit, Paper 1 paragraph on a council leaflet (300 words, one paragraph) | `ll-e1` | "level 7" paragraph with exact quotes |
| 2 | Business Management, Luma Bakes break-even, margin of safety, ratios, loan (e) under 150 words | `bm-e1` | 1,800 or 3,000? |
| 3 | Physics HL, kettle: current, resistance, energy, efficiency, latent heat | `ph-e1` | minutes-to-seconds |
| 4 | Maths AI SL, loan (TVM) and normal distribution | `mai-e1` | GDC inputs, 3 s.f., money to 2 d.p. |
| 5 | Biology HL, test cross, chi-squared, linkage (explanations under 200 words) | `bi-e1` | is χ² ≈ 384 right? |
| 6 | Spanish B SL, mark a blog post (A/B/C) and 5 worst mistakes with exact quotes | `sp-e1` | marks and corrections |
| 7 | Maths AA SL + History HL, 1923 hyperinflation model and a 300-word paragraph | `maa-e1a` then `hi-e1a` (peer) | is hyperinflation the main reason? |
| 8 | Chemistry SL + ESS SL, ocean acidification, [H⁺], 30 %?, coral reefs (250 words) | `ch-e1b` then `ess-e1b` (peer) | how can 0.1 be 30 %? |
| 9 | English (English Specialist method), poem, ONE PETAL/DIE paragraph of 250 words max, plus simile or metaphor? | `en-e1` | patience, not death |
| 10 | English A Literature SL, unseen prose, thesis plus ONE body paragraph (300 words max) | `lit-e1` | does my thesis work? |
| 11 | Economics SL, sugar tax: PED, revenue, incidence, two diagrams (under 120 words each) | `ec-e1` | −2.5 or −0.4? $30 m? two-thirds? |
| 12 | Psychology SL, Paper 2 Section B: plan and answer (answer max 500 words) | `ps-e1` | is 2.6 ÷ 8.6 = 30 % right? |
| 13 | Geography SL, Selvaria population (NIR, doubling, dependency, age structure) | `ge-e1` | 0.92 and 0.62 circled, why? |
| 14 | Computer Science SL, binary/hex, truth table, Boolean algebra, binary search traces | `cs-e1` | 182 or 109? (−1, 4)? |

## 2. Headline results

| Measure | Result |
| --- | --- |
| Specialist answers numerically correct (every figure recomputed by the judge) | **16 / 16** |
| Specialist answers correct and appropriate for an IB student as written | **13 / 16** (`hi-e1a` and `ess-e1b` repeat a false check result to the student; `en-e1` ignores "ONE paragraph" and misattributes lines) |
| Error-level findings on genuine receipts | **29**, of which the judge finds **0 true** (2 borderline word-limit findings, counted false) |
| Genuine translations: 224 claims, 156 IR problems | 124 ENTAILED, 7 COUNTEREXAMPLE, 24 AMBIGUOUS, 68 UNSUPPORTED, 1 INVALID |
| Definitive displays faithful to what the specialist claimed | **123 / 131** (93.9 %). The 7 COUNTEREXAMPLEs come from links the translator dropped; 1 ENTAILED covers only half of its claim |
| Z3 verdicts correct for their encodings | **156 / 156** translated problems re-run identically by the judge; every false STEM error traces to its encoding, not to the solver |
| Injected faults named by the hub (mutations) | **96 / 102** (94.1 %); 6 missed |
| Combinator syntheses accepted | **0 / 14** (every one schema-invalid) |
| Tampered transfers named by the overseer agents | **7 / 9** |
| Real infrastructure faults raised by the overseer agents | 13 accusations, all left unresolved for human review; 1 correct accusation wrongly refuted; 1 false accusation accepted |
| Student-facing gate | 0 VERIFIED, 6 DELIVERED_UNVERIFIED, 8 WITHHELD. Every invariant holds: nothing unverified is shown as verified |
| Gate decisions the judge agrees with | 9 / 14 (6 correct answers delivered as "not verified"; 3 flawed requests withheld). 5 requests whose answers are all correct were withheld because of false findings and the synthesis failure |
| Deterministic time per request | 0.06 to 0.81 s, against a 240 s budget |

**Bottom line.** The specialists did well: every calculation is right, and most of the
prose is exam-appropriate. The engine is sound: every verdict reproduces, and every
verdict is right for the problem it was given. Two infrastructure faults dominate the
run:

- the STEM front end and the request-constraint reader produce **false error findings**
  on correct work;
- the combinator's syntheses all fail the schema, so **no request can be VERIFIED**.

The gate never shows anything unverified as verified. Because of those false findings,
it withholds correct answers, and in two places the false findings reached the
student-facing text through the peer relay.

## 3. Per-request outcome

Columns:

- **Specialist**: the judge's verdict on the answer.
- **Hub findings**: the error-level findings on the genuine receipt (T = true, F = false).
- **Translation / Z3**: the outcomes of the translated claims.
- **Overseer agents**: what the agents raised on the genuine transfer.
- **Gate**: what the student would be shown.

| # | Task | Specialist (judge) | Hub error findings | Translation / Z3 | Overseer agents | Gate |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | ll-e1 | Correct. All 12 quotations verbatim; paragraph 249 words | none (warning c3 "2 paragraphs" is F: the trailing note was counted) | 1 claim, AMBIGUOUS (19 premises relied on) | none (clean, correct) | WITHHELD (0.78) |
| 2 | bm-e1 | Correct: 2.70; 3,000 (friend right); MoS 500 (14.29 %); profit 1,350; 1.60; 1.00; (e) 141 words | INT-REQ-005 279 > 150: F (the bound applies to (e)) | 11 ENTAILED, 2 AMBIGUOUS | word-bound scope raised twice (correct, unresolved) | DELIVERED, not verified (0.909) |
| 3 | ph-e1 | Correct: 9.57 A; 24.0 Ω; 5.94×10⁵ J; 5.166×10⁵ J; 0.870; 2.3×10⁶ J kg⁻¹; sound (g) | INT-SUBJ-001 s3.1 F; s5.2 F; INT-CONFLICT-001 s2.1/s2.2 F | 12 ENTAILED, 1 AMBIGUOUS, 3 UNSUPPORTED | false conflict accused (correct, but refuted by the check); s7.2 interval (correct) | DELIVERED, not verified (0.913) |
| 4 | mai-e1 | Correct: €352.19; €21 131.40; €3131.40; €11 491.11; 0.0478; 155 cm; 19.1 | none | 11 ENTAILED, 3 AMBIGUOUS, 12 UNSUPPORTED (ln and exp) | none | DELIVERED, not verified (0.952) |
| 5 | bi-e1 | Correct: 1:1:1:1, 250 each; χ² = 384.864; df 3; linked; 19 % | INT-SUBJ-001 s4.1 "− 1 = 3": F | 10 ENTAILED, 3 UNSUPPORTED | none on genuine; "− 1 = 3" raised on the mutation copy (correct) | DELIVERED, not verified (0.917) |
| 6 | sp-e1 | Correct marking (A 7/12, B 8/12, C 4/6) and 5 correct corrections; one debatable extra ("cansado") | INT-REQ-003 ×7: F (the corrected forms were read as quotations) | 3 UNSUPPORTED | none on genuine; on the mutation copy, accepted the false findings as correct and accused 'para ayudar' (F, confirmed) | WITHHELD (0.333) |
| 7 | maa-e1a | Correct: P₀ = 250, k = 2.05, factor 7.77, 10.1 days, 5.51×10⁷ vs 3465, not a good fit | INT-SUBJ-001 m2.5 F; m4.2 F | 7 ENTAILED, 20 UNSUPPORTED (ln and exp) | m2.5 chain cut (correct, unresolved) | WITHHELD with hi-e1a (0.879) |
| 7 | hi-e1a | Paragraph correct and well argued (Rentenmark Nov 1923, NSDAP small in 1928, surge in 1930). **But** it tells the student the maths report's log lines "do not hold" and not to copy them (false), and says the July model figure "agrees with the table" (it is 15,900 times the table value) | INT-REQ-005 311 > 300: borderline F (paragraph 268 words; the "Limit:" note was counted) | 4 ENTAILED, 1 AMBIGUOUS, 2 UNSUPPORTED | "ONE body paragraph" missing as a constraint (correct) | WITHHELD |
| 8 | ch-e1b | Correct: 6.31×10⁻⁹, 7.94×10⁻⁹, 25.9 %, equations, carbonate shift, factor 2.5 | INT-SUBJ-001 '0.1 pH' as a restated result: F | 5 ENTAILED, 1 AMBIGUOUS, 12 UNSUPPORTED | none | WITHHELD with ess-e1b (0.889) |
| 8 | ess-e1b | Correct figures (CO₂ +50.4 %) and a reasonable [6] evaluation. **But** it tells the student "a formal check failed the report's restated '0.1 pH' result" (false, and meaningless to a student) | INT-SUBJ-001 '26 %' vs the CO₂ chain F; '1' F | 2 ENTAILED, 3 AMBIGUOUS, 1 UNSUPPORTED | none | WITHHELD |
| 9 | en-e1 | Reading defensible; metaphor/simile answer correct. **But** 4 paragraphs where ONE was asked, PETAL/DIE stages not visible, and "the grandfather's remark rests on anaphora" (the "as if" lines are the speaker's, not the grandfather's) | INT-REQ-003 'like' ×2 F; ES-SRC-001 ×2 F; INT-REQ-005 271 > 250 F (the side answer was counted). True finding: c3 "5 paragraphs vs 1" (a warning) | 4 ENTAILED, 1 COUNTEREXAMPLE (dropped link), 1 AMBIGUOUS | none | WITHHELD (0.500) |
| 10 | lit-e1 | Correct: thesis corrected, 10 exact quotations, thesis plus paragraph 296 words. Assumes the narrator is "she" | none | 4 AMBIGUOUS | "300 words max" and "ONE body paragraph" not extracted as constraints (correct ×3) | WITHHELD (0.750; only the synthesis failed) |
| 11 | ec-e1 | Correct: regressive tax; PED −0.40; $27 m; 0.40/0.20 (two-thirds); diagrams described; 113 and 114 words | INT-SUBJ-001 pair_direction ("falls from $1.60 to $2.00 − $0.60 = $1.40") F; INT-REQ-005 427 > 120 F | 14 ENTAILED, 1 AMBIGUOUS, 4 UNSUPPORTED | word-bound scope (correct) | WITHHELD (0.893) |
| 12 | ps-e1 | Correct and strong: plan plus 480-word answer; 2.6 ÷ 11.2 = 23 % | INT-REQ-005 779 > 500 F (the plan was counted) | 2 ENTAILED, **6 COUNTEREXAMPLE** (dropped links), 4 AMBIGUOUS, 3 UNSUPPORTED | none | WITHHELD (0.429) |
| 13 | ge-e1 | Correct: 17 per 1,000 (1.7 %); 41 years; 92.0 and 61.8; shares; +85.4 %. Leaks "a fictional country" | none | 13 ENTAILED, 2 AMBIGUOUS, 2 UNSUPPORTED | g4.1 half-encoded yet displayed ENTAILED (correct ×2) | DELIVERED, not verified (0.962) |
| 14 | cs-e1 | Correct: 182, B6; 4096; truth table; Boolean proof; (6, 2); (−1, 3); counter-example (−1, 2) | INT-SUBJ-001 '1011' F; '0110₂' F; '2 <= 1' F | 29 ENTAILED, 1 INVALID (E108), 3 UNSUPPORTED | '2 <= 1' misread (correct) | DELIVERED, not verified (0.915) |

**What the student would be shown.**

- **Delivered.** Requests 2, 3, 4, 5, 13 and 14 are delivered labelled "not verified".
  All six answers are correct.
- **Withheld.** Requests 1, 6, 7, 8, 9, 10, 11 and 12 are withheld.
  - 9 is rightly withheld: the format is ignored and lines are misattributed.
  - 7 and 8 are rightly withheld: each contains a false claim relayed from a false
    check.
  - 1, 6, 10, 11 and 12 contain only correct answers and should have reached the
    student "not verified".
- **Verified.** Nothing is VERIFIED, because no synthesis was delivered (B1).
- **Delivered records.** The records of requests 3, 5 and 14 carry 7 false "FAILED"
  formal checks. If the website surfaces failed checks, the student is told that
  correct working (270 s, 0.870, df = 3, 1011 is B) is wrong.

## 4. Accuracy, in detail

- **Specialists.** About 80 figures were recomputed independently. All are correct,
  including:
  - Physics: 9.565 A, 24.03/24.05 Ω, η = 0.8697;
  - Maths AI: TVM 352.19, balance 11 491.11, P(X > 190) = 0.04779;
  - Biology: χ² = 384.864;
  - Maths AA: k = 2.0505, e^k = 7.772, 10.14 days, model ratio 15,900;
  - Chemistry: 10^0.1 = 1.2589, log₁₀1.3 = 0.114;
  - Economics: PED −0.4;
  - Geography: 61.8 and the age shares;
  - Computer Science: both traces and the [9, 3, 8] example.

  Every quotation of a supplied text or peer report in `ll-e1`, `en-e1`, `lit-e1`,
  `hi-e1a` and `ess-e1b` occurs in its source, word for word. (en-e1's quoted
  "like"/"as" are mentions of words, not quotations.) Word limits set by the students
  were met by every answer when measured on the part each limit applies to:

  | Answer | Measured part | Words | Limit |
  | --- | --- | --- | --- |
  | ll-e1 | paragraph | 249 | 300 |
  | bm-e1 | (e) | 141 | 150 |
  | bi-e1 | whole answer, as the hub counts it | 200 | 200 |
  | hi-e1a | paragraph | 268 | 300 |
  | ess-e1b | whole answer | 235 | 250 |
  | en-e1 | paragraph | 234 | 250 |
  | lit-e1 | thesis and paragraph | 296 | 300 |
  | ec-e1 | (e) / (f) | 113 / 114 | 120 each |
  | ps-e1 | answer | 480 | 500 |

  Paragraph counts are a different matter: `en-e1` gave 4 paragraphs where one was
  asked.
- **Hub findings on genuine receipts.**
  - Errors: 29, all false. They are 12 false INT-SUBJ-001, 5 out-of-scope word
    bounds, 9 correction or mention "quotations" (INT-REQ-003 and ES-SRC-001), 1 false
    pair direction, 1 false conflict and 1 borderline word count. The rate in
    `summary.md` counts each of these receipts as "functional" because it does not
    judge truth.
  - True findings: the en-e1 paragraph-count warning, the ST-UNDEC and ST-PARSE "not
    checked" warnings, and the INT-GLOSSARY-005 translation-fault warnings in bi-e1
    and ess-e1b.
- **Translations.** The 156 problems are well-formed and Z3 decides them
  deterministically. The material fidelity faults are:
  - 7 dropped inferential links that produce COUNTEREXAMPLE (ps ×6, en ×1);
  - 2 exact encodings of rounded figures that produce a false conflict (ph s2.1/s2.2);
  - 1 clause dropped but displayed ENTAILED (ge g4.1);
  - 1 interval narrower than the stated precision (ph s7.2);
  - 4 quotation groundings in the wrong document and 1 unstated figure 12 (bm).

  Also, 31 ENTAILED results rest only on ungrounded premises. They are labelled as
  such and are not displayed as verified.
- **Mutations.** 96 of 102 injected faults are named. The 6 misses are: mai-e1 ×2
  (thousands separators are not parsed), ch-e1b ×2 (decimal powers of 10 are outside
  the encodings), maa-e1a ×1 (no injection site recorded), and hi-e1a ×1 (an altered
  quotation of the peer report was not detected).
- **Overseer agents.** There were 4 instances and 39 verdicts, all validated.
  - Tampers named: 7 of 9 (T3, T4, T5b, T7b, T8, T22g, T22i). T1 and T22a were missed.
  - Real infrastructure faults found: 13 accusations, all "unresolved", because no
    deterministic kind confirms a false finding.
  - Wrong refutation: the ph-e1 false conflict was a correct accusation, refuted by
    the check.
  - False accusation accepted: 'para ayudar', a correction rather than a quotation.
  - Deference: the agents treated the 7 false Spanish findings as correct.
  - Not raised: none of the 7 false COUNTEREXAMPLEs, none of the false findings
    relayed into hi-e1a and ess-e1b, and no other false STEM error.
  - Score file: "false accusations accepted 0" and "recall 9/53" are measured against
    gold built from the deterministic auditor's own findings, so neither figure
    reflects the run's real faults (B12).

## 5. Stage timings (from `harness/timings.json`)

All times are deterministic replay times in milliseconds. Model time is not
included, because translations were replayed from the recorded fixtures. The budget
is 240 s per request.

| Task | Req | Validation | Routing | Channel + translator | of which pipeline | Peer relay | Synthesis | Z3 in process | Gate | Total | Z3 over HTTP | Engine calls | Arena fault variants |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ll-e1 | 1 | 1.2 | 0.2 | 28.1 | 3.7 | 0.0 | 0.7 | 30.8 | 0.0 | 61.0 | 46.6 | 4 | 6 in 0.34 s |
| bm-e1 | 2 | 1.3 | 0.2 | 60.5 | 25.4 | 0.0 | 0.8 | 182.7 | 0.1 | 245.7 | 268.0 | 20 | 6 in 1.27 s |
| ph-e1 | 3 | 1.7 | 0.1 | 114.5 | 20.7 | 0.0 | 0.8 | 361.4 | 0.2 | 478.7 | 453.1 | 45 | 8 in 3.59 s |
| mai-e1 | 4 | 1.9 | 0.3 | 89.6 | 22.6 | 0.0 | 0.9 | 127.4 | 0.3 | 220.3 | 173.3 | 19 | 7 in 1.52 s |
| bi-e1 | 5 | 3.6 | 0.5 | 204.1 | 18.5 | 0.0 | 1.8 | 196.0 | 0.2 | 406.2 | 342.7 | 21 | 7 in 1.74 s |
| sp-e1 | 6 | 1.5 | 0.2 | 52.6 | 0.6 | 0.0 | 0.9 | 0.0 | 0.0 | 55.2 | 0.0 | 0 | 6 in 0.20 s |
| maa-e1a | 7 | 3.3 | 0.2 | 112.0 | 14.3 | 0.0 | 0.0 | 349.7 | 0.2 | 465.4 | 133.4 | 15 | 7 in 3.40 s |
| hi-e1a | 7 | 1.7 | 0.0 | 48.0 | 8.8 | 2.3 | 0.8 | 64.1 | 0.0 | 117.0 | 90.0 | 8 | 6 in 3.16 s |
| ch-e1b | 8 | 1.4 | 0.2 | 71.7 | 11.5 | 0.0 | 0.0 | 120.6 | 0.1 | 194.0 | 185.2 | 15 | 7 in 1.40 s |
| ess-e1b | 8 | 1.8 | 0.1 | 86.8 | 9.5 | 2.6 | 0.8 | 141.4 | 0.1 | 233.5 | 149.4 | 13 | 8 in 3.27 s |
| en-e1 | 9 | 1.2 | 0.2 | 32.4 | 7.9 | 0.0 | 0.8 | 55.3 | 0.1 | 90.0 | 113.9 | 10 | 6 in 0.53 s |
| lit-e1 | 10 | 1.1 | 0.2 | 47.6 | 17.6 | 0.0 | 0.8 | 74.0 | 0.0 | 123.7 | 95.7 | 5 | 6 in 0.94 s |
| ec-e1 | 11 | 1.8 | 0.2 | 90.9 | 37.9 | 0.0 | 0.8 | 291.4 | 0.1 | 385.1 | 465.5 | 33 | 5 in 1.91 s |
| ps-e1 | 12 | 1.3 | 0.2 | 105.0 | 25.8 | 0.0 | 0.8 | 204.4 | 0.1 | 311.8 | 282.5 | 23 | 5 in 1.47 s |
| ge-e1 | 13 | 1.3 | 0.1 | 71.4 | 32.9 | 0.0 | 0.9 | 227.9 | 0.1 | 301.8 | 416.2 | 31 | 5 in 1.60 s |
| cs-e1 | 14 | 1.7 | 0.2 | 265.9 | 144.1 | 0.0 | 0.8 | 536.0 | 0.2 | 804.8 | 622.1 | 39 | 7 in 5.80 s |
| **Total** | | 27.7 | 3.2 | 1,481.0 | 401.7 | 4.9 | 12.5 | 2,962.9 | 1.9 | **4,494.2** | 3,837.6 | 301 | 102 in 32.1 s |

- **Slowest stages.** Z3 in process takes 66 % of the deterministic time (2.96 s), and
  channel plus translator takes 33 % (1.48 s). The slowest task is `cs-e1` at 0.805 s
  (Z3 0.536 s, channel 0.266 s), then `ph-e1` at 0.479 s (45 engine calls) and
  `maa-e1a` at 0.465 s (15 calls under the nonlinear policy, about 23 ms per call).
- **Arena wall time.** The arena took 36.4 s of wall time, 32.1 s of it on the fault
  variants. The whole harness took 82.3 s.
- **Synthesis stage.** The 0.7 to 1.8 ms "synthesis" times are the time to fail
  schema validation. No synthesis check ran.
- **Model stages, from `agent_times.json`.** These are not in the 240 s budget
  measured above:

  | Stage | Calls | Duration each | Total |
  | --- | --- | --- | --- |
  | Specialists | 16 | 1.6–3.4 min | 38.9 min |
  | Translation-provider batches | 10 | 1.7–16.8 min | 91.6 min |
  | Combinator batches | 2 | 7.1–9.1 min | 16.2 min |

  Translation is by far the slowest stage of the real pipeline.

## 6. Bugs, errors, mistakes and optimisation issues

Severities:

- **critical**: blocks delivery or puts a false statement in front of the student;
- **major**: a wrong verdict, a missed fault or a wrong decision;
- **minor**: noise, coverage or measurement;
- **cosmetic**: wording or presentation only.

Optimisation items are recorded with their measurements and are **not** bugs in this
phase (founder's order).

### 6.1 Infrastructure (code)

| ID | Sev | Where | Evidence | Suggested fix |
| --- | --- | --- | --- | --- |
| B1 | critical | Combinator output contract; the syntheses format in the `run_arena.py` docstring | 14/14 syntheses have free text in `transformation` (allowed values: carried, paraphrased, merged, narrowed, generalized, new, dropped). The hub rejects them with INT-REQ-009 (gate.json "as JSON"), so no synthesis is delivered and no request can be VERIFIED. The docstring's format line lists `transformation` without its allowed values | State the enum wherever the combinator is told the format (and in a published JSON Schema). Give the combinator a separate free-text field for its note. Add a regression test: free-text `transformation` gives a REJECTED synthesis with INT-REQ-009 |
| B1b | major | `scripts/arena/run_arena.py` `group_synthesis` | Builds `SynthesizedClaim` objects directly and records a pydantic ValidationError crash (0/14 functional) instead of relaying the mapping through the channel, so the arena's result differs from the hub's (REJECTED, INT-REQ-009) and no synthesis check is exercised | Relay the raw mapping with `ch.relay` and record the receipt; test that a schema-invalid synthesis is a REJECTED record, not a crash |
| B2 | critical | STEM front end (`stem/`): relation reader and stem-res restatement | 12 false INT-SUBJ-001 on correct work: bi s4.1 "4 categories − 1 = 3" → "− 1 = 3"; ph s3.1 "4 min 30 s = (4×60+30) s" → "30 s = …"; ph s5.2 "5.166 × 10⁵ J / 5.94 × 10⁵ J = 0.870 (87%)" UNSATISFIABLE (true value 0.8697); maa m2.5 and m4.2 chains cut at "…" (the same claims also carry ST-PARSE-001 saying the relation is withheld); ch "0.1 pH" read as the restated result of the 25.9 % chain; ess "26 %" checked against the CO₂ chain (0.504); ess "1" from "(1.259 − 1)"; cs "1011 is B and 0110 is 6" read as restated results ×2; cs "the final test (2 <= 1) fails" read as an asserted comparison | Never drop a word-bearing operand (read it or withhold it). Read compound quantities ("4 min 30 s"). Treat a trailing "…"/`\ldots` as an enclosure that continues the side. A restatement must be of the same quantity (same symbol, unit or chain). A comparison followed by "fails", "no" or "is false" is negated. Digit groups in a base-conversion context are numerals of that base. When a check and a translation of the same claim disagree, emit a warning, not an error. Add one regression test per sentence quoted here |
| B3 | major | Peer relay (`relayed/*.json` carries `peer_receipt` with findings) | The dependent specialists were given the peer's receipt findings and repeated the false ones to the student (hi-e1a "do not copy those two lines"; ess-e1b "a formal check failed the report's restated 0.1 pH result") | Relay the delivered report only, not router-side findings. Flag a dependent answer that states a check result (self-report as content) |
| B4 | major | Request-constraint extraction and measurement (INT-REQ-005) | Bounds applied to the wrong span: bm "(e) under 150 words" measured on the whole answer (279); ec "(e) and (f) under 120 words each" measured on the whole (427); ps "max 500 words for the answer" measured with the plan (779 vs 480); en counted the separate side answer (271 vs 234); hi counted the "Limit:" note (311 vs 268). Not extracted at all: lit-e1 "300 words max" and "ONE body paragraph"; hi-e1a "ONE body paragraph" (ll-e1's was extracted) | Bind each bound to its scope (part label, "each", "for the answer", "the paragraph") and measure that span. Recognise "N words max". Use one meta-text classifier ("Limit:", "Next step:", trailing notes) for word and paragraph counts |
| B5 | major | Quotation checks (INT-REQ-003, CORE-SRC-003) and overseer auditor OVS-FID-004 | sp-e1: the 7 corrected forms ("una mujer muy simpática" …) are flagged as altered quotations (errors), and 15 as unverifiable; the auditor marks 'para ayudar' (a suggestion) OVS-FID-004, so the audit fails; request 6 is withheld | Recognise correction notation (`"X" → "Y"`, "should be", "becomes", "Model:"). Check only the student-side text against the supplied text |
| B6 | major | English quotation checks (INT-REQ-003, ES-SRC-001) | en-e1: `without "like" or "as"` makes 'like' an invented quotation (4 errors) | Treat a quoted single function word used as a mention (grammatical term) as a mention, or at most a warning |
| B7 | major | Cross-claim consistency (INT-CONFLICT-001) and overseer adjudication of `false_conflict` | ph-e1 s2.1 (230/9.57) and s2.2 (230²/2200) are pooled exactly under one symbol and conflict (24.033 vs 24.045), although both state 24.0 Ω (3 s.f.). The agent's correct false_conflict accusation was refuted by re-running the same pooled encoding | Pool derived figures at their stated precision, or rename symbols apart by route. Adjudicate false_conflict on the claims' stated values at stated precision |
| B8 | major | Translation provider plus outcome rules (E111 exempts Bool points) | 7 COUNTEREXAMPLEs on correct claims (ps g2.1, g3.1, g6.5, g6.7, g7.1, g8.1; en p4-point). The provider's readings say "expected to show as not entailed": the specialist's reason (stated in the claim or the next sentence) was left unencoded. The gate counts each as a failed check, and request 12 is withheld | Require every conclusion conjunct to be linked from the claim's supports, or else mark it AMBIGUOUS or UNSUPPORTED. Withhold a COUNTEREXAMPLE whose falsifying atoms are specialist-inference Bools that no premise mentions ("judgement not encoded"), and do not count it as failed |
| B9 | major | History-branch quotation check against `peer:` documents | Mutation `hi-e1a altered_quotation`: "the model is not aly good fit for 1923", credited to the Mathematics specialist, crosses with no INT-REQ-003, CORE-SRC-005 or CORE-SRC-003 | Search peer documents for quotations attributed to a named specialist and report a one-word alteration. Add a regression test with this sentence |
| B10 | major | STEM lexer coverage; mutation harness | mai-e1: "18 000", "21 131.40" and `18\,000` give ST-PARSE-001 "unexpected '000'", so none of the loan arithmetic is checked and 2 injected faults are missed. ch-e1b: 10^(−8.2) is outside the encodings and 2 faults are missed. maa-e1a stem_substitution records no injection site | Read space, thin-space and `\,` thousands separators. Add decimal powers of 10 as enclosures. The harness should refuse to count a mutation with no injection site |
| B11 | major | Overseer knowledge pack 1.3 (I3, kinds table) | There is no confirmable kind for "a receipt finding that is false"; I3 says a named fault is not accused. Agents deferred to the 7 false Spanish findings and filed the false STEM errors under `translation_unfaithful`/`other` (always unresolved) | Add a `finding_false` kind with a deterministic confirmation (re-read the claim substring the check encoded; the correction-arrow rule; same-quantity restatement). Restrict I3 to findings that are true |
| B12 | major | Overseer scoring (`run1-overseer/score.json`, gold) | Gold faults are the auditor's own findings, so a false OVS-FID-004 is a "fault present" and an agent repeating it scores a catch. The run's real faults (false findings) are absent from gold: recall 9/53 and "false accusations accepted 0" both misstate performance | Build gold from adjudicated truth (the strongest-tier judge), with false auditor findings removed and false receipt findings added as faults |
| B13 | major | Response gate (`gate.json` rule) | ENTAILED results resting only on ungrounded premises (31) count as passed checks. False findings count as failed. A fast-path request with no combinator need still fails "synthesis delivered". The 90 % accuracy that decides delivery does not measure correctness (ll-e1, sp-e1, lit-e1, ec-e1 and ps-e1 were withheld although correct) | Count "only ungrounded" ENTAILED as unresolved. Gate on engine-confirmed findings. Make the synthesis check conditional on a combinator being part of the request's plan |
| B14 | major | HTTP service `POST /v1/verify` | 8 of 301 genuine problems decide differently over HTTP (UNSUPPORTED or INVALID instead of ENTAILED, SATISFIABLE, UNSATISFIABLE or CONSISTENT), because the request cannot carry the channel's engine policy (nonlinear STEM policy, larger limits) | Add an allowlisted, named `policy` field bound into the config digest. Test parity on the 301 problems |
| B15 | minor | Service versus integration contract | The service refuses `grounding.verified: true` with 400 E505 (207 of 508 calls were refused and re-sent). Contract §2 says the flag is discarded with diagnostic E505 | Align the two (document the refusal in the HTTP row, or demote and proceed) |
| B16 | minor | `translate/grounding.py` figures_in_excerpt | Verbatim-found excerpts fail when the premise encodes the quoted figure at its stated precision: "1.259" → [1.2585, 1.2595); "6.31 × 10⁻⁹" → [6.305e−9, 6.315e−9); "≈ 1.55" → [1.545, 1.555). ess s2.1 3/3 and hi h1.2 3/3 groundings are reported as ungrounded | Accept bounds that are exactly the half-unit enclosure of a stated figure, including ×10ⁿ superscript notation and "≈" |
| B17 | minor | STEM claim ids | ess-e1b and ch-e1b both deliver s1.1 to s3.4 in one task (INT-REQ-016 on 8 ids; ledger ambiguity) | Namespace STEM ids by agent, as the generic branch does (`@agent`) |
| B18 | minor | Request-item coverage heuristic (INT-REQ-004) | 10 false "unaddressed" warnings: question stems, "(a)", "(c) Construct the truth table" (the table is there), "Explain in English" (it is in English). Item text corrupted: "Please my exact words when you point out a mistake." (the word "quote" was lost) | Skip stems with no command term, match part labels, and fix the item extraction that dropped "quote" |
| B19 | minor | Paragraph count (INT-REQ-005 c3) | ll-e1: the trailing one-line note counts as a second paragraph; the gate fails it and the request is withheld | Use the shared meta-text classifier (B4) |
| B20 | minor | Receipt consistency | The same claim carries a translated ENTAILED and a failed STEM check (ph s3.1, s5.2; bi s4.1; cs c2.1/c2.2/c12.3) with no notice of disagreement | Cross-check the two encodings, warn, and gate the claim as unresolved |
| B21 | minor | Translation provider | ge g4.1 encodes only "correct as ratios"; the "but … per 100" clause is dropped, yet the claim is displayed ENTAILED | Partial encodings show as AMBIGUOUS, or display "first clause only" |
| B22 | minor | Translation provider | ph s7.2 encodes "2.3 × 10⁶" as [2,294,000, 2,298,000), narrower than the 2 s.f. stated | Intervals must follow the stated precision of the claim's own figure |
| B23 | minor | Translation provider (bm) | The student's 1,800 and "9 %" (as 0.09) are grounded as quotations of doc-luma (OVS-TRN-004 ×4); the figure 12 (months) is never stated (OVS-TRN-005 ×3) | Ground request figures as task_setting; recognise percent-to-decimal; state assumed constants |
| B24 | minor | `agent_times.json` (harness metering) | `output` is 14 tokens for a 326-word answer and 33 for a 271-word answer: the column is not answer size and invites "the output was reduced" | Sum the output tokens over every API call and record each answer's word count |
| B25 | minor | Generic, Business, Economics and Psychology branches | CORE-QNT-001: "written arithmetic in '=' form … which this branch's prose arithmetic reader does not decide" on every worked line of bm, ec, ge and ps; only the translations check them | Reuse the STEM '=' chain checker in the non-STEM branches |
| B26 | minor (known; xfail in the suite) | IR schema patterns | `tests/engine/test_pack_policies.py` xfail: identifiers, assertion ids and numeric literals end in `$`, so `'x\n'` is accepted as a symbol distinct from `'x'` | Anchor with `\Z` or use `fullmatch`; then remove the xfail marker (a stricter test, not a weaker one) |
| B27 | minor (known; xfail in the suite) | Validator `_decode_text` | xfail: a lone surrogate in a text payload raises UnicodeEncodeError and becomes INTERNAL_ERROR (E900) instead of INVALID_FORMALIZATION (E100) | Catch UnicodeEncodeError; remove the marker |

### 6.2 Specialist, combinator and overseer agents (cheapest tier)

| ID | Sev | Where | Evidence | Suggested fix |
| --- | --- | --- | --- | --- |
| S1 | major | hi-e1a (History) | Tells the student the maths log lines "do not hold" and not to copy them (they are correct). Says "the rates and the July figure above agree with the table" (the July model figure is 15,900 times the table's) | Root cause B2 and B3. Add a knowledge-pack rule: never pass system check results to the student as subject advice |
| S2 | major | ess-e1b (ESS) | "(A formal check failed the report's restated '0.1 pH' result; its 25.9 % arithmetic holds.)" in a student answer | As S1 |
| S3 | minor | en-e1 (English Specialist) | 4 paragraphs plus a side answer where "ONE paragraph" was asked; PETAL/DIE stages not visible; "the grandfather's remark rests on anaphora" (the "as if" lines are the speaker's) | Enforce the one-paragraph and format request; attribute speech correctly |
| S4 | minor | lit-e1 | Narrator called "she" throughout; the extract never says so | Use "the narrator" |
| S5 | minor | ge-e1 | "Selvaria, a fictional country": task metadata leaked into a student answer | Never echo document metadata |
| S6 | minor | sp-e1 | "Fue muy cansado" → "agotador" is marked as an error; in peninsular Spanish "cansado" also means "tiring" (RAE sense 2) | Mark it as a style suggestion |
| S7 | minor | ch-e1b | "'about 30%' is not right": the 26 % from the rounded pH values and the usual ~30 % (8.25 → 8.14) agree within the stated precision; the answer hedges later, but the verdict is too strong | Say "26 % from these rounded values; 30 % comes from more precise pH values" |
| S8 | minor | bi-e1 | "[1 spare]" mark annotation in (e) | Drop it |
| S9 | cosmetic | bm-e1 | "the $6,000 of cash and the $4,000 overdraft do not have to pay for it" (an overdraft is borrowing, not a fund) | Rephrase |
| S10 | (see B1) | combinator | Free-text `transformation` in all 14 syntheses. To its credit, it dropped the relayed false-check notes (ess s2.3, hi h2.1 and h2.2) from the syntheses | — |
| O1 | major | overseer agents | Missed tampers T1 (ps-e1 payload altered) and T22a (ps-e1 translation invalid) | Add pack examples for these two |
| O2 | major | overseer agents | On sp-e1 they accepted the false INT-REQ-003 findings as correct and accused 'para ayudar' (confirmed): a false accusation accepted | B5 and B11 |
| O3 | minor | overseer agents | Raised none of the 7 false COUNTEREXAMPLEs, the propagated false claims (hi, ess), the false en-e1 quotation errors, the ps, hi and en word-bound errors, or the false STEM errors in ch, ess, ph and cs | B11 (a `finding_false` kind) and pack examples drawn from this run |

### 6.3 Optimisation (recorded with measurements; not fixed in the bug-testing phases)

| ID | Where | Measurement |
| --- | --- | --- |
| P1 | Z3 in process | 2.96 of 4.49 s (66 %). cs-e1 0.536 s for 39 calls; ph-e1 0.361 s for 45 calls; maa-e1a 0.350 s for 15 nonlinear calls (about 23 ms per call). Includes repeated E111/E112 probes, translator probes and cross-agent re-runs |
| P2 | Arena fault variants | 32.1 of 36.4 s arena wall time; every mutation re-runs every check of the whole answer (cs-e1: 7 variants in 5.8 s). Unchanged claims could reuse their results by claim-text digest |
| P3 | HTTP replay | 207 of 508 requests refused (400 E505) and re-sent, so those problems make two round trips |
| P4 | Model stages | Translation-provider batches 1.7–16.8 min, combinator 7.1–9.1 min, specialists 1.6–3.4 min. The 240 s budget measured here covers deterministic time only (max 0.81 s per request); a live request with model translation was not measured and, for long answers (cs-e1: 33 claims translated), is likely to exceed it |
| P5 | Translator pipeline (parse, validation, grounding) | 0.40 s in total; cs-e1 0.144 s. No action needed |

**Severity counts (all 44 items).**

| Severity | Count | Items |
| --- | --- | --- |
| critical | 2 | B1, B2 |
| major | 17 | B1b, B3–B14, S1, S2, O1, O2 |
| minor | 19 | B15–B27, S3–S8, O3 |
| cosmetic | 1 | S9 |
| optimisation (recorded only) | 5 | P1–P5 |

## 7. Not done in this judgement

- **Default suite.** The suite was run on the frozen tree (stress tests excluded): it
  ran to completion with no failure. Nine tests were skipped because the recorded
  rounds r5 and r7 are not present in this copy, so those regression checks did not
  run here. Four tests are xfail; they mark the known defects B26 and B27.
- **Tests and code.** No test was weakened or rewritten. No code was changed. Stress
  tests were not run.
- **Live behaviour.** No live provider and no deployed service were exercised.
- **Overseer dossiers.** The dossiers were judged through their verdicts and the
  score; the dossier texts were not re-read line by line.

## 8. Scope statement

This report judges a simulation on a frozen local copy of the code. No live website,
deployed service or live model provider was contacted. Engine results prove
properties of their encodings only. They do not establish that premises are true,
that a translation is faithful, or that an interpretation is correct. Specialist,
translator, combinator and overseer self-reports were treated as advisory; only signed
engine results, re-run here, were trusted.
