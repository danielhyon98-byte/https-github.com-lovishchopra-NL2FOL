"""Shared helpers for building translate_v1 output objects (translation provider step).

Only the translation step: this module writes JSON under run1/translations and never touches the tree.
"""
import json
import os

BASE = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/e2e"
SPEC = os.path.join(BASE, "run1", "specialists")
OUT = os.path.join(BASE, "run1", "translations")


# ---- IR expression constructors (allowlisted nodes only) ----
def V(n): return {"op": "var", "name": n}
def B(v): return {"op": "bool", "value": bool(v)}
def I(s): return {"op": "int", "value": str(s)}
def R(s): return {"op": "real", "value": str(s)}
def NOT(a): return {"op": "not", "arg": a}
def AND(*a):
    assert len(a) >= 2, "and needs two args"
    return {"op": "and", "args": list(a)}
def OR(*a):
    assert len(a) >= 2, "or needs two args"
    return {"op": "or", "args": list(a)}
def IMP(l, r): return {"op": "implies", "left": l, "right": r}
def IFF(l, r): return {"op": "iff", "left": l, "right": r}
def ITE(c, t, o): return {"op": "ite", "cond": c, "then": t, "otherwise": o}
def ADD(*a):
    assert len(a) >= 2
    return {"op": "add", "args": list(a)}
def MUL(*a):
    assert len(a) >= 2
    return {"op": "mul", "args": list(a)}
def SUB(l, r): return {"op": "sub", "left": l, "right": r}
def NEG(a): return {"op": "neg", "arg": a}
def DIV(l, r): return {"op": "div", "left": l, "right": r}
def IDIV(l, r): return {"op": "idiv", "left": l, "right": r}
def MOD(l, r): return {"op": "mod", "left": l, "right": r}
def TOR(a): return {"op": "to_real", "arg": a}
def EQ(l, r): return {"op": "eq", "left": l, "right": r}
def NE(l, r): return {"op": "ne", "left": l, "right": r}
def LT(l, r): return {"op": "lt", "left": l, "right": r}
def LE(l, r): return {"op": "le", "left": l, "right": r}
def GT(l, r): return {"op": "gt", "left": l, "right": r}
def GE(l, r): return {"op": "ge", "left": l, "right": r}


# ---- grounding / symbol / assertion constructors ----
def G(kind, cert="established", refs=None, note=None):
    """refs: list of (document_id, excerpt) pairs; excerpt must be verbatim in the supplied text."""
    g = {"kind": kind, "certainty": cert}
    if refs:
        g["source_refs"] = [{"document_id": d, "excerpt": e} for d, e in refs]
    if note:
        g["note"] = note
    return g


def S(name, sort, meaning, grounding=None):
    return {"name": name, "sort": sort, "meaning": meaning, "grounding": grounding}


def A(aid, expr, label, grounding=None, materiality="material"):
    return {"id": aid, "expr": expr, "label": label, "grounding": grounding, "materiality": materiality}


def flag(code, message, alternatives):
    return {"code": code, "message": message, "alternatives": alternatives}


def problem(pid, req, cid, syms, prems, concl, reading, ambiguous=False, flags=None):
    """Build one per-claim output object. concl is an Assertion dict (entailment query)."""
    prob = {"ir_version": "1.0", "problem_id": pid, "request_id": req, "claim_id": cid,
            "query": "entailment", "symbols": syms, "premises": prems, "conclusion": concl}
    gloss = [{"symbol": s["name"], "meaning": s["meaning"], "grounding": s["grounding"]} for s in syms]
    return {"problem": prob,
            "interpretation": {"reading": reading, "glossary": gloss, "ambiguity_flags": flags or []},
            "ambiguous": bool(ambiguous), "unsupported_reason": None}


def null(reading, reason):
    return {"problem": None,
            "interpretation": {"reading": reading, "glossary": [], "ambiguity_flags": []},
            "ambiguous": False, "unsupported_reason": reason}


# ---- checks ----
def load_docs(task):
    d = json.load(open(os.path.join(SPEC, task + ".json"), encoding="utf-8"))
    return d, {s["document_id"]: s["text"] for s in d["supplied_texts"]}


def excerpt_problems(obj, docs):
    """Return every grounding excerpt that is not verbatim in its named document."""
    bad = []
    if obj.get("problem") is None:
        return bad
    prob = obj["problem"]
    grounds = [("symbol " + s["name"], s.get("grounding")) for s in prob["symbols"]]
    grounds += [("premise " + p["id"], p.get("grounding")) for p in prob["premises"]]
    grounds += [("conclusion " + prob["conclusion"]["id"], prob["conclusion"].get("grounding"))]
    for where, g in grounds:
        if not g:
            continue
        for r in g.get("source_refs", []):
            ex = r.get("excerpt")
            if ex is not None and ex not in docs.get(r["document_id"], ""):
                bad.append((where, r["document_id"], ex))
    return bad


def write_and_validate(task, report_id, claims, docs):
    """Write run1/translations/<task>.json and validate each problem with the engine."""
    from epinoic_logic.engine import parse_and_validate
    out = {"report_id": report_id, "claims": claims}
    path = os.path.join(OUT, task + ".json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    report = {}
    for cid, obj in claims.items():
        bad = excerpt_problems(obj, docs)
        if bad:
            report[cid] = "EXCERPT-MISMATCH " + repr(bad[:3])
            continue
        if obj["problem"] is None:
            report[cid] = "null"
            continue
        p, o = parse_and_validate(json.dumps(obj["problem"]))
        report[cid] = "ok" if o.ok else "FAIL " + repr(o)[:300]
    return path, report


def run_task(task, report_id, builder):
    """builder(docs) -> dict of claims. Writes the file and prints the per-claim status."""
    d, docs = load_docs(task)
    claims = builder(docs)
    path, report = write_and_validate(task, report_id, claims, docs)
    n_ok = sum(1 for v in report.values() if v in ("ok", "null"))
    print(f"{task}: wrote {path}; {len(claims)} claims; {n_ok} ok-or-null")
    for cid, st in report.items():
        if st not in ("ok", "null"):
            print("   PROBLEM", cid, st)
    return report
