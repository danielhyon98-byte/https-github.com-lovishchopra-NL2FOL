import json, sys
from epinoic_logic.engine.runner import verify
path = sys.argv[1]
d = json.load(open(path, encoding="utf-8"))
for cid, obj in d["claims"].items():
    if obj["problem"] is None:
        print(cid, "NULL", obj["unsupported_reason"][:60])
        continue
    r = verify(json.dumps(obj["problem"]))
    st = getattr(r.status, "value", r.status)
    diags = [getattr(x, "code", None) for x in (getattr(r, "diagnostics", []) or [])]
    print(cid, st, diags[:4])
