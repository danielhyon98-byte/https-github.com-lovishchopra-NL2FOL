import json, subprocess, sys
BASE = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/e2e"
PY = BASE + "/venv/bin/python"
LC = BASE + "/tree/scripts/arena/list_claims.py"
for task in sys.argv[1:]:
    out = subprocess.run([PY, "-I", LC, f"{BASE}/run1/specialists/{task}.json", *(["--json"] if "--all" in __import__("os").environ.get("DUMP_MODE","") else ["--eligible","--json"])],
                         capture_output=True, text=True, check=True).stdout
    d = json.loads(out)
    print(f"##### {task} report={d['report_id']} request={d['request_id']} branch={d['branch']} eligible={len(d['claims'])}")
    for c in d["claims"]:
        print(f"-- {c['claim_id']} | role={c['role']} | mat={c['materiality']} | cert={c['certainty']} | supports={c['supporting_claim_ids']}")
        print(f"   TEXT: {c['text']}")
        for r in c["source_refs"]:
            print(f"   REF: doc={r['document_id']} located={r['located']} excerpt={r.get('excerpt')!r} locator={r.get('locator')}")
        for a in c["assumptions"]:
            print(f"   ASSUMP: {a}")
        if c["advisory_verification_status"]:
            print(f"   SELF: {c['advisory_verification_status']}")
