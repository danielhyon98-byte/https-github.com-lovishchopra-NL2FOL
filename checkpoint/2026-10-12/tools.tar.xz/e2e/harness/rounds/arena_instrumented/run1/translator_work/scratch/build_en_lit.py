"""Translations for en-e1 (English A: Literature, poem) and lit-e1 (English A: Literature, prose extract)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *  # noqa: E402,F401,F403

EN = "doc-allotment"
LIT = "doc-last-morning"


def prem(sym, aid, label):
    return A(aid, V(sym["name"]), label, sym["grounding"])


def build_en(docs):
    REQ = "req-en-e1"
    out = {}
    PH = G("specialist_inference", "probable")

    # ---- shared symbols (one meaning each across the en-e1 report) ----
    q_asif1 = S("q_asif1", "Bool", "the line 'as if that were the point of them,' begins with the phrase 'as if'",
                G("quotation", "established", [(EN, "as if that were the point of them")]))
    q_asif2 = S("q_asif2", "Bool", "the line 'as if the waiting were the gift.' begins with the phrase 'as if'",
                G("quotation", "established", [(EN, "as if the waiting were the gift")]))
    q_succ = S("q_succ", "Bool", "the two 'as if' lines are successive lines of the poem (only a stanza break separates them)",
               G("supplied_text", "established", [(EN, "as if that were the point of them"), (EN, "as if the waiting were the gift")],
                 note="structural fact about the layout of the poem"))
    anaphora = S("anaphora", "Bool", "the grandfather's remark rests on anaphora, the repetition of a phrase at the start of successive lines", PH)
    fist_named = S("fist_named", "Bool", "the bulbs are named as fists in the image 'each one a closed fist'",
                   G("quotation", "established", [(EN, "each one a closed fist")]))
    fist_no_marker = S("fist_no_marker", "Bool", "the image 'each one a closed fist' contains neither 'like' nor 'as'",
                       G("supplied_text", "established", [(EN, "each one a closed fist")]))
    fist_metaphor = S("fist_metaphor", "Bool", "the image 'each one a closed fist' is a metaphor", PH)
    dark_shown = S("dark_shown", "Bool", "the poem shows the dark is real: 'We walk home with the dark already in our coats'",
                   G("quotation", "established", [(EN, "We walk home with the dark already in our coats")]))
    patience_hope = S("patience_hope", "Bool", "patience is how hope is kept until it can be seen (the specialist's reading of the poem)", PH)
    dusk_frames = S("dusk_frames", "Bool", "within the poem the dusk frames the waiting rather than ending it", PH)
    dark_point = S("dark_point", "Bool", "the dark is real and the dusk frames the waiting rather than ending it (the fourth supporting point)", PH)

    # p2-point: anaphora
    out["p2-point"] = problem(
        "en-p2-point", REQ, "p2-point",
        [q_asif1, q_asif2, q_succ, anaphora],
        [prem(q_asif1, "pr_asif1", "the line 'as if that were the point of them' begins with 'as if'"),
         prem(q_asif2, "pr_asif2", "the line 'as if the waiting were the gift' begins with 'as if'"),
         prem(q_succ, "pr_succ", "the two 'as if' lines are successive lines of the poem"),
         A("pr_def", IMP(AND(V("q_asif1"), V("q_asif2"), V("q_succ")), V("anaphora")),
           "a phrase repeated at the start of successive lines is anaphora", G("general_knowledge", "probable"))],
        A("concl", V("anaphora"), "The grandfather's remark rests on anaphora, the repetition of a phrase at the start of successive lines.", PH),
        reading="The point is read as the claim that the grandfather's remark ('as if that were the point of them' / 'as if the "
                "waiting were the gift') repeats 'as if' at the start of successive lines, which is anaphora. The two quoted "
                "clauses and their line position are the evidence; the definition of anaphora is a general-knowledge premise "
                "at the specialist's stated certainty. The 'gift' and 'the waiting' material (p2-q03, p2-q04, p2-s03, p2-s04) "
                "bears on the device's effect, not on whether anaphora is present, so it is not a premise of this point.")

    # p3-point: 'each one a closed fist' is a metaphor
    out["p3-point"] = problem(
        "en-p3-point", REQ, "p3-point",
        [fist_named, fist_no_marker, fist_metaphor],
        [prem(fist_named, "pr_named", "the bulbs are named as fists: 'each one a closed fist'"),
         prem(fist_no_marker, "pr_nomarker", "the phrase contains neither 'like' nor 'as'"),
         A("pr_def", IMP(AND(V("fist_named"), V("fist_no_marker")), V("fist_metaphor")),
           "a comparison that names one thing as another without 'like' or 'as' is a metaphor", G("general_knowledge", "probable"))],
        A("concl", V("fist_metaphor"), "The image 'each one a closed fist' is a metaphor, since the bulbs are named as fists without 'like' or 'as'.", PH),
        reading="The point is the classification of 'each one a closed fist' as a metaphor. The chain is the quotation of the image, "
                "the structural fact that the phrase contains no 'like' or 'as', and the criterion for metaphor. The word 'like' is "
                "not in the poem, so it is not quoted (p3-q02 is unlocated); its absence is encoded as a fact about the phrase. "
                "The interpretive points on closed and open (p3-s02 to p3-s04) are not needed for the classification.")

    # p4-point: dark real, dusk frames the waiting rather than ending it
    out["p4-point"] = problem(
        "en-p4-point", REQ, "p4-point",
        [dark_shown, patience_hope, dusk_frames],
        [prem(dark_shown, "pr_dark", "the poem shows the dark is real: 'We walk home with the dark already in our coats'"),
         prem(patience_hope, "pr_patience", "patience is how hope is kept until it can be seen")],
        A("concl", AND(V("dark_shown"), V("dusk_frames")),
          "The dark is real, but within the poem the dusk frames the waiting rather than ending it.", PH),
        reading="The first conjunct (the dark is real, shown by the quoted line) is encoded from the quotation. The second "
                "conjunct, that the dusk frames the waiting rather than ending it, has no link stated in the specialist's chain: "
                "the supporting claims give only the quotation and 'patience is how hope is kept until it can be seen'. No link "
                "is added, so the check is expected to expose this missing step rather than entail the whole claim.")

    # p5-point: 'It is a metaphor' (the bulbs are called fists)
    papery_as = S("papery_as", "Bool", "the phrase 'papery as onions' contains the marker 'as'",
                  G("supplied_text", "established", [(EN, "papery as onions")]))
    papery_simile = S("papery_simile", "Bool", "'papery as onions' is a simile", PH)
    out["p5-point"] = problem(
        "en-p5-point", REQ, "p5-point",
        [fist_named, fist_no_marker, fist_metaphor, papery_as, papery_simile],
        [prem(fist_named, "pr_named", "the bulbs are called fists: 'each one a closed fist'"),
         prem(fist_no_marker, "pr_nomarker", "the phrase contains neither 'like' nor 'as'"),
         A("pr_def", IMP(AND(V("fist_named"), V("fist_no_marker")), V("fist_metaphor")),
           "a comparison that names one thing as another without 'like' or 'as' is a metaphor", G("general_knowledge", "probable")),
         prem(papery_as, "pr_papery", "'papery as onions' contains the marker 'as'"),
         A("pr_simile", IMP(V("papery_as"), V("papery_simile")),
           "a comparison marked by 'as' or 'like' is a simile", G("general_knowledge", "probable"))],
        A("concl", V("fist_metaphor"), "It is a metaphor: the bulbs are called fists with no 'like' or 'as' to mark the comparison.", PH),
        reading="The same classification as the p3 point, now stated for the bulbs. The contrast with the simile 'papery as "
                "onions' in the same line (p5-s02) is encoded as a supporting premise. The word 'like' is not quoted "
                "(p5-q01 is unlocated); its absence is a supplied-text fact about the phrase. The symbol names and meanings "
                "are shared with the p3 point because it is the same quantity.")

    # p1-s01: thesis, supported by four points
    out["p1-s01"] = problem(
        "en-p1-s01", REQ, "p1-s01",
        [anaphora, fist_metaphor, dark_point, patience_hope,
         S("thesis_ps", "Bool", "Ashdown presents patience as a form of hope", PH)],
        [prem(anaphora, "pr_anaphora", "the grandfather's remark rests on anaphora"),
         prem(fist_metaphor, "pr_metaphor", "the image 'each one a closed fist' is a metaphor"),
         prem(dark_point, "pr_dark", "the dark is real and the dusk frames the waiting rather than ending it"),
         prem(patience_hope, "pr_patience", "patience is how hope is kept until it can be seen"),
         A("pr_link", IMP(AND(V("anaphora"), V("fist_metaphor"), V("dark_point"), V("patience_hope")), V("thesis_ps")),
           "the four supporting points, with patience as how hope is kept, support the thesis", PH)],
        A("concl", V("thesis_ps"), "Ashdown presents patience as a form of hope.", PH),
        reading="The thesis is encoded as following from the four points listed as its support, joined by the specialist's "
                "single asserted link. Only the p4 point and p4-s02 mention patience or hope, so the thesis depends on that "
                "one link. The points themselves are encoded as premises at the specialist's stated certainty, not checked here.",
        ambiguous=True,
        flags=[flag("form_of", "'a form of hope' (patience is a kind of hope) is not the same as 'how hope is kept' (p4-s02)",
                    ["patience is a kind of hope", "patience is the means by which hope is kept until it can be seen"])])

    # p1-s02: bulbs and words ask the speaker to value a growth not yet seen
    bulbs_given = S("bulbs_given", "Bool", "the grandfather hands the speaker bulbs", G("quotation", "established", [(EN, "He hands me bulbs")]))
    words_unseen = S("words_unseen", "Bool", "the grandfather says the bulbs will not be seen till spring",
                     G("quotation", "established", [(EN, "You won't see these till spring")]))
    words_wait_gift = S("words_wait_gift", "Bool", "the grandfather's words treat the waiting as the gift",
                        G("quotation", "established", [(EN, "as if the waiting were the gift")]))
    bulbs_growth = S("bulbs_growth", "Bool", "the bulbs are a growth that cannot yet be seen", PH)
    ask_value = S("ask_value", "Bool", "the bulbs and his few words ask the speaker to value a growth that cannot yet be seen", PH)
    out["p1-s02"] = problem(
        "en-p1-s02", REQ, "p1-s02",
        [bulbs_given, words_unseen, words_wait_gift, bulbs_growth, ask_value, anaphora, fist_metaphor, dark_point],
        [prem(bulbs_given, "pr_bulbs", "the grandfather hands the speaker bulbs"),
         prem(words_unseen, "pr_unseen", "the bulbs will not be seen till spring"),
         prem(words_wait_gift, "pr_wait", "the waiting is treated as the gift"),
         A("pr_growth", IMP(AND(V("bulbs_given"), V("words_unseen")), V("bulbs_growth")),
           "bulbs given with the promise that they will not be seen till spring are a growth not yet visible", PH),
         prem(anaphora, "pr_anaphora", "the grandfather's remark rests on anaphora"),
         prem(fist_metaphor, "pr_metaphor", "the image 'each one a closed fist' is a metaphor"),
         prem(dark_point, "pr_dark", "the dark is real and the dusk frames the waiting rather than ending it"),
         A("pr_ask", IMP(AND(V("bulbs_growth"), V("words_wait_gift"), V("anaphora"), V("fist_metaphor"), V("dark_point")), V("ask_value")),
           "the bulbs and words, with the supporting points, ask the speaker to value the growth", PH)],
        A("concl", V("ask_value"), "The grandfather's bulbs and his few words ask the speaker to value a growth that cannot yet be seen.", PH),
        reading="The thesis is encoded from its quoted evidence (the bulbs, 'You won't see these till spring', 'as if the waiting "
                "were the gift') through two asserted links, and from the four supporting points through the specialist's single "
                "listed-support link. The link that the bulbs are a growth is the specialist's inference from the quoted words. "
                "'His few words' is read as the grandfather's spoken lines in the poem.",
        ambiguous=False)

    return out


def build_lit(docs):
    REQ = "req-lit-e1"
    out = {}
    PH = G("specialist_inference", "probable")

    told_glad = S("told_glad", "Bool", "the narrator tells herself she is glad", G("quotation", "established", [(LIT, "I told myself I was glad")]))
    gave_back = S("gave_back", "Bool", "the kitchen gives her gladness back to her thinner", G("quotation", "established", [(LIT, "gave it back to me thinner")]))
    gladness_not_felt = S("gladness_not_felt", "Bool", "her gladness is something she tells herself, not something she feels", PH)
    gladness_empty = S("gladness_empty", "Bool", "her gladness does not hold: the passage shows it is empty", PH)
    relieved = S("relieved", "Bool", "the narrator is relieved to leave the house", PH)
    looking_forward = S("looking_forward", "Bool", "the narrator is looking forward to the new flat", PH)
    reluctance = S("reluctance", "Bool", "the narrator's feelings about leaving home are reluctance", PH)
    house_emptied = S("house_emptied", "Bool", "the emptied kitchen shelves look like a mouth with its teeth knocked out",
                      G("quotation", "established", [(LIT, "looked like a mouth with its teeth knocked out")]))
    reluctance_visible = S("reluctance_visible", "Bool", "the emptying house makes that reluctance visible", PH)

    # p3-point
    out["p3-point"] = problem(
        "lit-p3-point", REQ, "p3-point",
        [told_glad, gladness_not_felt, gave_back, gladness_empty, relieved, reluctance, house_emptied, reluctance_visible],
        [prem(told_glad, "pr_told", "the narrator tells herself she is glad"),
         A("pr_told_link", IMP(V("told_glad"), V("gladness_not_felt")),
           "a gladness the narrator tells herself is not one she feels", PH),
         prem(gave_back, "pr_gave", "the kitchen gives her gladness back to her thinner"),
         A("pr_gave_link", IMP(V("gave_back"), V("gladness_empty")), "a gladness returned thinner is shown to be empty", PH),
         A("pr_relief_link", IMP(V("gladness_not_felt"), NOT(V("relieved"))),
           "gladness she only tells herself leaves her reluctant rather than relieved", PH),
         A("pr_reluct_link", IMP(AND(V("gladness_not_felt"), V("gladness_empty")), V("reluctance")),
           "unfelt and empty gladness amounts to reluctance about leaving", PH),
         prem(house_emptied, "pr_house", "the emptied kitchen shelves look like a mouth with its teeth knocked out"),
         A("pr_visible_link", IMP(AND(V("house_emptied"), V("reluctance")), V("reluctance_visible")),
           "an emptied house makes the reluctance visible", PH)],
        A("concl", AND(V("reluctance"), NOT(V("relieved")), V("reluctance_visible")),
          "Marlowe presents the narrator's feelings about leaving home as reluctance rather than relief, and the emptying house makes that reluctance visible.", PH),
        reading="The point has two parts. The first (reluctance rather than relief) is encoded from 'I told myself I was glad' and "
                "'gave it back to me thinner' through the specialist's gloss that the gladness is told, not felt, and empty; the "
                "reluctance and not-relieved steps are separate links. The second (the emptying house makes it visible) is encoded "
                "from the quoted image of the bare shelves. The 'knocked out', 'handle' and stairs and bedroom material is "
                "supporting interpretation and is not needed for the entailment.")

    # p1-s01: student's thesis does not survive
    thesis_reason = S("thesis_reason", "Bool", "the narrator is relieved to leave because the house is old and uncomfortable",
                      G("task_setting", "established", note="the student's own thesis, given with the task"))
    student_thesis = S("student_thesis", "Bool", "the student's thesis: relieved to leave because the house is old and uncomfortable, and looking forward to the new flat",
                       G("task_setting", "established", note="the student's own thesis, given with the task"))
    out["p1-s01"] = problem(
        "lit-p1-s01", REQ, "p1-s01",
        [relieved, looking_forward, thesis_reason, student_thesis, reluctance],
        [A("pr_thesis_def", IFF(V("student_thesis"), AND(V("relieved"), V("thesis_reason"), V("looking_forward"))),
           "the student's thesis is the conjunction of relief, the old-and-uncomfortable reason and looking forward to the flat",
           G("task_setting", "established", note="the student's own thesis, given with the task")),
         prem(reluctance, "pr_reluct", "the narrator's feelings about leaving are reluctance"),
         A("pr_not_relief", IMP(V("reluctance"), NOT(V("relieved"))), "reluctance rather than relief: she is not relieved", PH)],
        A("concl", NOT(V("student_thesis")), "Your thesis does not survive the extract.", PH),
        reading="The claim is that the student's whole thesis fails against the extract. The thesis is encoded as a conjunction "
                "that includes relief, so the claim follows from the specialist's point that the narrator is reluctant rather "
                "than relieved. The thesis's reason ('old and uncomfortable') and the looking-forward part are kept in the "
                "definition but are not separately checked.")

    # p1-s02: not relieved, not looking forward, told glad, gladness does not hold
    out["p1-s02"] = problem(
        "lit-p1-s02", REQ, "p1-s02",
        [told_glad, gave_back, gladness_empty, relieved, looking_forward],
        [prem(told_glad, "pr_told", "the narrator tells herself she is glad"),
         prem(gave_back, "pr_gave", "the kitchen gives her gladness back to her thinner"),
         A("pr_empty_link", IMP(V("gave_back"), V("gladness_empty")), "a gladness returned thinner does not hold", PH),
         A("pr_relief_link", IMP(AND(V("told_glad"), V("gladness_empty")), NOT(V("relieved"))),
           "she has to tell herself she is glad, and the gladness does not hold, so she is not relieved", PH),
         A("pr_forward_link", IMP(AND(V("told_glad"), V("gladness_empty")), NOT(V("looking_forward"))),
           "she has to tell herself she is glad, and the gladness does not hold, so she is not looking forward to the flat", PH)],
        A("concl", AND(NOT(V("relieved")), NOT(V("looking_forward")), V("told_glad"), V("gladness_empty")),
          "The narrator is not relieved and is not looking forward to the flat: she has to tell herself she is glad, and the passage shows that her gladness does not hold.", PH),
        reading="Four conjuncts: not relieved, not looking forward, the narrator tells herself she is glad (quoted), and her "
                "gladness does not hold (from the quoted 'gave it back to me thinner'). The two not-claims are separate asserted "
                "links from the telling and the failing gladness; 'has to tell herself' is read as 'told myself'.")

    # p1-s03: discomforts have some support, but the passage uses them to show loss
    stairs_groan = S("stairs_groan", "Bool", "the stairs groan", G("quotation", "established", [(LIT, "The stairs groaned")]))
    bedroom_narrow = S("bedroom_narrow", "Bool", "the bedroom is narrow", G("quotation", "established", [(LIT, "My bedroom was so narrow")]))
    house_uncomf_supported = S("house_uncomf_supported", "Bool",
                               "the point that the house is uncomfortable has some support from the extract", PH)
    uses_for_loss = S("uses_for_loss", "Bool", "the passage uses the house's discomforts to show what the narrator is losing", PH)
    out["p1-s03"] = problem(
        "lit-p1-s03", REQ, "p1-s03",
        [stairs_groan, bedroom_narrow, house_uncomf_supported, uses_for_loss, reluctance, reluctance_visible],
        [prem(stairs_groan, "pr_groan", "the stairs groan"),
         prem(bedroom_narrow, "pr_narrow", "the bedroom is narrow"),
         A("pr_support_link", IMP(AND(V("stairs_groan"), V("bedroom_narrow")), V("house_uncomf_supported")),
           "stairs that groan and a narrow bedroom support the point that the house is uncomfortable", PH),
         prem(reluctance, "pr_reluct", "the narrator's feelings about leaving are reluctance"),
         prem(reluctance_visible, "pr_visible", "the emptying house makes that reluctance visible"),
         A("pr_loss_link", IMP(AND(V("reluctance"), V("reluctance_visible")), V("uses_for_loss")),
           "the discomforts are used to show the loss the reluctance reveals", PH)],
        A("concl", AND(V("house_uncomf_supported"), V("uses_for_loss")),
          "Your point that the house is old and uncomfortable has some support, since the stairs groan and the bedroom is narrow, but the passage uses those discomforts to show what she is losing.", PH),
        reading="The claim has a concession (the discomfort point has some support, from the stairs and the narrow bedroom) and a "
                "counter-claim (the passage uses those discomforts to show loss). The concession is encoded only for "
                "'uncomfortable': the extract gives no evidence that the house is old, so the claim's 'old' is not encoded as "
                "supported, and the ambiguity is flagged.",
        ambiguous=True,
        flags=[flag("old_not_evidenced", "the extract gives evidence of discomfort (stairs, narrow bedroom) but nothing about the house's age",
                    ["encode only the uncomfortable part, as here", "encode 'old and uncomfortable', which the extract does not support"])])

    return out


if __name__ == "__main__":
    run_task("en-e1", "rep-en-e1-0", build_en)
    run_task("lit-e1", "rep-lit-e1-0", build_lit)
