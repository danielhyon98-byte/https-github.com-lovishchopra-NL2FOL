"""Translations for ge-e1 (Geography, Selvaria population resource table)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *  # noqa: E402,F401,F403

DOC = "doc-selvaria"
ROW = {
    "pop": "Total population (millions) | 9.6 | 17.8",
    "kids": "Aged 0–14 (millions) | 4.3 | 5.9",
    "mid": "Aged 15–64 (millions) | 5.0 | 11.0",
    "old": "Aged 65 and over (millions) | 0.3 | 0.9",
    "cbr": "Crude birth rate (per 1,000 per year) | 38 | 24",
    "cdr": "Crude death rate (per 1,000 per year) | 14 | 7",
    "lit": "Female literacy rate (%) | 54 | 91",
    "contra": "Contraceptive prevalence (% of women aged 15–49) | 21 | 58",
}
# name: (table row key, value written in the table, meaning)
FIGS = {
    "pop_1990": ("pop", "9.6", "total population in 1990 (millions)"),
    "pop_2024": ("pop", "17.8", "total population in 2024 (millions)"),
    "kids_1990": ("kids", "4.3", "population aged 0-14 in 1990 (millions)"),
    "kids_2024": ("kids", "5.9", "population aged 0-14 in 2024 (millions)"),
    "mid_1990": ("mid", "5.0", "population aged 15-64 in 1990 (millions)"),
    "mid_2024": ("mid", "11.0", "population aged 15-64 in 2024 (millions)"),
    "old_1990": ("old", "0.3", "population aged 65 and over in 1990 (millions)"),
    "old_2024": ("old", "0.9", "population aged 65 and over in 2024 (millions)"),
    "cbr_1990": ("cbr", "38", "crude birth rate in 1990 (per 1,000 per year)"),
    "cbr_2024": ("cbr", "24", "crude birth rate in 2024 (per 1,000 per year)"),
    "cdr_1990": ("cdr", "14", "crude death rate in 1990 (per 1,000 per year)"),
    "cdr_2024": ("cdr", "7", "crude death rate in 2024 (per 1,000 per year)"),
    "lit_1990": ("lit", "54", "female literacy rate in 1990 (%)"),
    "lit_2024": ("lit", "91", "female literacy rate in 2024 (%)"),
    "contra_1990": ("contra", "21", "contraceptive prevalence in 1990 (% of women aged 15-49)"),
    "contra_2024": ("contra", "58", "contraceptive prevalence in 2024 (% of women aged 15-49)"),
}
ARITH = "arithmetic_fact"


def FS(name):
    key, _, meaning = FIGS[name]
    return S(name, "Real", meaning, G(ARITH, "established", [(DOC, ROW[key])]))


def FP(name):
    key, val, meaning = FIGS[name]
    return A("fp_" + name, EQ(V(name), R(val)), f"the table gives the {meaning} as {val}",
             G(ARITH, "established", [(DOC, ROW[key])]))


def DS(name, meaning, ground):
    return S(name, "Real", meaning, ground)


def build_ge(docs):
    REQ = "req-ge-e1"
    out = {}
    GK = G("general_knowledge", "established")
    SI = G("specialist_inference", "established")
    AR = G(ARITH, "established")

    # ---- symbol sets reused by several claims ----
    def figs(*names):
        return [FS(n) for n in names], [FP(n) for n in names]

    # natural increase and its percentage (g1.1, g2.1)
    nir = DS("nir_2024", "natural increase rate in 2024 (per 1,000 per year) = crude birth rate minus crude death rate", SI)
    nir_pct = DS("nir_pct_2024", "natural increase rate in 2024 as a percentage per year", SI)
    dbl = DS("dbl_years", "doubling time in years at the 2024 natural increase rate", SI)
    rate_constant = S("rate_constant", "Bool", "the 2024 rate of natural increase stays constant",
                      G("assumption", "established", note="explicit assumption stated in the claim"))

    s_cbr24, p_cbr24 = figs("cbr_2024")
    s_cdr24, p_cdr24 = figs("cdr_2024")
    out["g1.1@geography-specialist"] = problem(
        "ge-g1-1", REQ, "g1.1@geography-specialist",
        [s_cbr24[0], s_cdr24[0], nir, nir_pct],
        [p_cbr24[0], p_cdr24[0],
         A("def_nir", EQ(V("nir_2024"), SUB(V("cbr_2024"), V("cdr_2024"))),
           "natural increase equals crude birth rate minus crude death rate", GK),
         A("def_pct", EQ(MUL(V("nir_pct_2024"), R("10")), V("nir_2024")),
           "per 1,000 converts to a percentage by dividing by ten", GK)],
        A("concl", AND(EQ(V("nir_2024"), R("17")), EQ(V("nir_pct_2024"), R("1.7"))),
          "Natural increase rate = 24 - 7 = 17 per 1,000 per year, which is 1.7% per year.", SI),
        reading="Figures are the 2024 crude birth rate (24) and crude death rate (7) from Figure 1 (arithmetic facts with the table "
                "row as excerpt). The formula and the per-1,000-to-percent conversion are general-knowledge premises. The claim's "
                "result, 17 per 1,000 and 1.7%, is the conclusion.")

    # (a)(ii) doubling time (g2.1) -- 'about 41 years' has no stated precision: encoded to the whole year
    out["g2.1@geography-specialist"] = problem(
        "ge-g2-1", REQ, "g2.1@geography-specialist",
        [nir_pct, dbl, rate_constant],
        [A("def_dbl", EQ(MUL(V("dbl_years"), R("1.7")), R("70")),
           "doubling time in years is 70 divided by the growth rate in percent, applied to the 1.7% rate", GK)],
        A("concl", IMP(V("rate_constant"), AND(GE(V("dbl_years"), R("40.5")), LT(V("dbl_years"), R("41.5")))),
          "Assuming the 1.7% rate stays constant, the doubling time is about 41 years.", SI),
        reading="The doubling time is 70 divided by 1.7 (the rule-of-70 formula as general knowledge, with the specialist's "
                "1.7 constant). 'About 41 years' has no stated precision, so it is encoded as the whole-year figure 41, i.e. "
                "within half a year. The assumption of a constant rate is the antecedent of the conclusion.",
        ambiguous=True,
        flags=[flag("about_41", "'about 41 years' gives no stated precision",
                    ["41 years to the nearest whole year", "a looser figure of about 40 to 42 years"])])

    # g3.1 -- a definition from memory: nothing to check
    out["g3.1@geography-specialist"] = null(
        "The claim is the dependency-ratio formula itself, given from memory and not a statement about the table's figures.",
        "a definition from memory with no figure or claim to check; the formula is applied, and checked, in g3.2 and g3.3")

    # dependency ratios (g3.2, g3.3, g4.1)
    ratio_1990 = DS("ratio_1990", "dependency ratio in 1990 as a ratio: (aged 0-14 + aged 65 and over) divided by aged 15-64", SI)
    ratio_2024 = DS("ratio_2024", "dependency ratio in 2024 as a ratio: (aged 0-14 + aged 65 and over) divided by aged 15-64", SI)
    dep_1990 = DS("dep_1990", "dependants per 100 people of working age in 1990", SI)
    dep_2024 = DS("dep_2024", "dependants per 100 people of working age in 2024", SI)
    dep_defs = [
        A("def_ratio_1990", EQ(MUL(V("ratio_1990"), R("5.0")), ADD(V("kids_1990"), V("old_1990"))),
          "the 1990 ratio times the aged 15-64 figure of 5.0 equals the sum of the aged 0-14 and aged 65+ figures",
          G("general_knowledge", "established", note="dependency ratio formula applied to the table")),
        A("def_ratio_2024", EQ(MUL(V("ratio_2024"), R("11.0")), ADD(V("kids_2024"), V("old_2024"))),
          "the 2024 ratio times the aged 15-64 figure of 11.0 equals the sum of the aged 0-14 and aged 65+ figures",
          G("general_knowledge", "established", note="dependency ratio formula applied to the table")),
        A("def_dep_1990", EQ(V("dep_1990"), MUL(R("100"), V("ratio_1990"))), "dependants per 100 is the ratio times 100",
          G("general_knowledge", "established")),
        A("def_dep_2024", EQ(V("dep_2024"), MUL(R("100"), V("ratio_2024"))), "dependants per 100 is the ratio times 100",
          G("general_knowledge", "established")),
    ]

    s_k90, p_k90 = figs("kids_1990")
    s_o90, p_o90 = figs("old_1990")
    s_m90, p_m90 = figs("mid_1990")
    s_k24, p_k24 = figs("kids_2024")
    s_o24, p_o24 = figs("old_2024")
    s_m24, p_m24 = figs("mid_2024")

    out["g3.2@geography-specialist"] = problem(
        "ge-g3-2", REQ, "g3.2@geography-specialist",
        s_k90 + s_o90 + s_m90 + [ratio_1990, dep_1990],
        p_k90 + p_o90 + p_m90 + dep_defs[0:1] + dep_defs[2:3],
        A("concl", AND(GE(V("dep_1990"), R("91.95")), LT(V("dep_1990"), R("92.05"))),
          "1990: (4.3 + 0.3) divided by 5.0 times 100 = 92.0 dependants per 100 people of working age.", SI),
        reading="The 1990 figures (aged 0-14 4.3, aged 65+ 0.3, aged 15-64 5.0) are table facts. The ratio formula is applied "
                "to them. The claimed 92.0 is written to one decimal place, so it is encoded as the interval [91.95, 92.05).")

    out["g3.3@geography-specialist"] = problem(
        "ge-g3-3", REQ, "g3.3@geography-specialist",
        s_k24 + s_o24 + s_m24 + [ratio_2024, dep_2024],
        p_k24 + p_o24 + p_m24 + dep_defs[1:2] + dep_defs[3:4],
        A("concl", AND(GE(V("dep_2024"), R("61.75")), LT(V("dep_2024"), R("61.85"))),
          "2024: (5.9 + 0.9) divided by 11.0 times 100 = 61.8 dependants per 100 people of working age.", SI),
        reading="The 2024 figures (aged 0-14 5.9, aged 65+ 0.9, aged 15-64 11.0) are table facts. The claimed 61.8 is written to "
                "one decimal place, so it is encoded as [61.75, 61.85); the exact value is 61.82.")

    # g4.1 -- the student's 0.92 and 0.62 are correct as ratios (the per-100 convention is not encoded as a fact)
    out["g4.1@geography-specialist"] = problem(
        "ge-g4-1", REQ, "g4.1@geography-specialist",
        s_k90 + s_o90 + s_m90 + s_k24 + s_o24 + s_m24 + [ratio_1990, ratio_2024],
        p_k90 + p_o90 + p_m90 + p_k24 + p_o24 + p_m24 + dep_defs[0:2],
        A("concl", AND(GE(V("ratio_1990"), R("0.915")), LT(V("ratio_1990"), R("0.925")),
                       GE(V("ratio_2024"), R("0.615")), LT(V("ratio_2024"), R("0.625"))),
          "The student's 0.92 (1990) and 0.62 (2024) are correct as ratios.", SI),
        reading="The student's ratios are checked against the table: 0.92 is 4.6 divided by 5.0 and 0.62 is 6.8 divided by 11.0 "
                "(2 d.p. intervals). The second clause, that the dependency ratio is conventionally given per 100 people of working "
                "age, is a bare fact from memory with no figure to check, so it is not in the conclusion; the per-100 scale is "
                "encoded in g3.2 and g3.3.",
        ambiguous=False)

    # g4.2 -- a guess about the teacher's reason, resting on a mark scheme the specialist has not seen
    out["g4.2@geography-specialist"] = null(
        "The claim is the specialist's guess at why the teacher circled the answers; it is not a statement about Selvaria's figures.",
        "a guess about the teacher's reason that depends on a mark scheme the specialist has not seen; no checkable proposition about the table")

    # g5.1, g5.2, g5.3 -- shares of the population, 1990 and 2024
    share_defs = []
    share_syms = {}

    def share(name, num, den_val, year_pop_name, meaning):
        sym = DS(name, meaning, G(ARITH, "established", [(DOC, ROW["pop"]), (DOC, ROW[num.split("_")[0]])]))
        share_syms[name] = sym
        share_defs.append(A("def_" + name, EQ(MUL(V(name), R(den_val)), MUL(R("100"), V(num))),
                            f"{meaning} is 100 times the figure divided by the total population",
                            G(ARITH, "established", [(DOC, ROW["pop"]), (DOC, ROW[num.split("_")[0]])])))
        return sym

    sh_kids90 = share("sh_kids_1990", "kids_1990", "9.6", "pop_1990", "share of the population aged 0-14 in 1990 (%)")
    sh_kids24 = share("sh_kids_2024", "kids_2024", "17.8", "pop_2024", "share of the population aged 0-14 in 2024 (%)")
    sh_mid90 = share("sh_mid_1990", "mid_1990", "9.6", "pop_1990", "share of the population aged 15-64 in 1990 (%)")
    sh_mid24 = share("sh_mid_2024", "mid_2024", "17.8", "pop_2024", "share of the population aged 15-64 in 2024 (%)")
    sh_old90 = share("sh_old_1990", "old_1990", "9.6", "pop_1990", "share of the population aged 65 and over in 1990 (%)")
    sh_old24 = share("sh_old_2024", "old_2024", "17.8", "pop_2024", "share of the population aged 65 and over in 2024 (%)")
    s_pop90, p_pop90 = figs("pop_1990")
    s_pop24, p_pop24 = figs("pop_2024")
    fig_pre = p_pop90 + p_pop24

    out["g5.1@geography-specialist"] = problem(
        "ge-g5-1", REQ, "g5.1@geography-specialist",
        s_pop90 + s_pop24 + s_k90 + s_k24 + s_o90 + s_o24 + [sh_kids90, sh_kids24, sh_old90, sh_old24],
        fig_pre + p_k90 + p_k24 + p_o90 + p_o24 + share_defs[0:1] + share_defs[1:2] + share_defs[4:5] + share_defs[5:6],
        A("concl", AND(GT(V("sh_old_2024"), V("sh_old_1990")), LT(V("sh_kids_2024"), V("sh_kids_1990"))),
          "Between 1990 and 2024, the population of Selvaria became older.", SI),
        reading="'Became older' is operationalised as a rising share aged 65 and over together with a falling share aged 0-14, "
                "the two shares the specialist cites (g5.2). Both shares are arithmetic from the table totals.",
        ambiguous=True,
        flags=[flag("older", "'became older' is not defined in the claim; the encoding uses the shares of the oldest and youngest groups",
                    ["the share aged 65 and over rose and the share aged 0-14 fell (encoded)",
                     "median age rose (not in the table)"])])

    sh_mid_vals = []
    out["g5.2@geography-specialist"] = problem(
        "ge-g5-2", REQ, "g5.2@geography-specialist",
        s_pop90 + s_pop24 + s_k90 + s_k24 + s_m90 + s_m24 + s_o90 + s_o24 + [sh_kids90, sh_kids24, sh_mid90, sh_mid24, sh_old90, sh_old24],
        fig_pre + p_k90 + p_k24 + p_m90 + p_m24 + p_o90 + p_o24 + share_defs,
        A("concl", AND(
            GE(V("sh_kids_1990"), R("44.75")), LT(V("sh_kids_1990"), R("44.85")),
            GE(V("sh_kids_2024"), R("33.05")), LT(V("sh_kids_2024"), R("33.15")),
            GE(V("sh_mid_1990"), R("52.05")), LT(V("sh_mid_1990"), R("52.15")),
            GE(V("sh_mid_2024"), R("61.75")), LT(V("sh_mid_2024"), R("61.85")),
            GE(V("sh_old_1990"), R("3.05")), LT(V("sh_old_1990"), R("3.15")),
            GE(V("sh_old_2024"), R("5.05")), LT(V("sh_old_2024"), R("5.15"))),
          "The share aged 0-14 fell from 44.8% to 33.1%, the share aged 15-64 rose from 52.1% to 61.8%, and the share aged 65 and over rose from 3.1% to 5.1%.", SI),
        reading="Six shares, each written to one decimal place and encoded as the interval for its last place. The shares are "
                "computed from the table totals and figures (arithmetic facts). The parenthetical counts are the table figures.")

    out["g5.3@geography-specialist"] = problem(
        "ge-g5-3", REQ, "g5.3@geography-specialist",
        s_k90 + s_k24 + [sh_kids90, sh_kids24],
        p_k90 + p_k24 + share_defs[0:2],
        A("concl", AND(GT(V("kids_2024"), V("kids_1990")), LT(V("sh_kids_2024"), V("sh_kids_1990"))),
          "The number of children rose from 4.3 million to 5.9 million, so the fall is in their share of the population rather than in their number.", SI),
        reading="The children's number rose (table figures) while their share fell (computed shares). The conclusion is the "
                "combination the claim states: number up, share down.")

    # g6.1 -- the crude birth rate fell from 38 to 24
    s_cbr90, p_cbr90 = figs("cbr_1990")
    out["g6.1@geography-specialist"] = problem(
        "ge-g6-1", REQ, "g6.1@geography-specialist",
        s_cbr90 + s_cbr24 + [],
        p_cbr90 + p_cbr24,
        A("concl", GT(V("cbr_1990"), V("cbr_2024")),
          "The crude birth rate fell from 38 per 1,000 per year in 1990 to 24 in 2024 (Figure 1).", SI),
        reading="The conclusion is the fall. The values 38 and 24 are table figures, and the table-row excerpt grounds them, "
                "so restating them as conclusion conjuncts would only repeat the premises.")

    # g7 / g8 -- the two reasons for the fall (contraception; female literacy)
    s_con90, p_con90 = figs("contra_1990")
    s_con24, p_con24 = figs("contra_2024")
    s_lit90, p_lit90 = figs("lit_1990")
    s_lit24, p_lit24 = figs("lit_2024")
    out["g7.1@geography-specialist"] = problem(
        "ge-g7-1", REQ, "g7.1@geography-specialist",
        s_con90 + s_con24, p_con90 + p_con24,
        A("concl", GT(V("contra_2024"), V("contra_1990")), "Reason 1: more women use contraception.", SI),
        reading="Reason 1 is read as a rise in contraceptive prevalence between 1990 and 2024, which is the figure the specialist cites "
                "(21% to 58%). The conclusion is the comparison.")

    out["g7.2@geography-specialist"] = problem(
        "ge-g7-2", REQ, "g7.2@geography-specialist",
        s_con90 + s_con24, p_con90 + p_con24,
        A("concl", GT(V("contra_2024"), V("contra_1990")),
          "Contraceptive prevalence rose from 21% in 1990 to 58% in 2024 (Figure 1).", SI),
        reading="The conclusion is the rise. The values are table facts, grounded by the row excerpt.")

    out["g7.3@geography-specialist"] = problem(
        "ge-g7-3", REQ, "g7.3@geography-specialist",
        [S("contra_up", "Bool", "contraceptive prevalence rose between 1990 and 2024", SI),
         S("more_choice", "Bool", "more women can choose when to have children and how many to have", SI),
         S("fewer_births_pw", "Bool", "fewer births occur per woman", SI),
         S("cbr_falls", "Bool", "fewer babies are born per 1,000 people, so the crude birth rate falls", SI)] + s_con90 + s_con24,
        p_con90 + p_con24 + [
            A("pr_contra_def", IFF(V("contra_up"), GT(V("contra_2024"), V("contra_1990"))),
              "contraceptive prevalence rose from 1990 to 2024", G(ARITH, "established", [(DOC, ROW["contra"])])),
            A("link_choice", IMP(V("contra_up"), V("more_choice")), "more contraception means more women can choose", SI),
            A("link_births", IMP(V("more_choice"), V("fewer_births_pw")), "choice over children means fewer births per woman", SI),
            A("link_cbr", IMP(V("fewer_births_pw"), V("cbr_falls")), "fewer births per woman means the crude birth rate falls", SI)],
        A("concl", AND(V("more_choice"), V("fewer_births_pw"), V("cbr_falls")),
          "As more women can choose when to have children and how many to have, fewer births occur per woman, so fewer babies are born per 1,000 people and the crude birth rate falls.", SI),
        reading="The mechanism is encoded as three asserted implications from the rise in contraception (itself a table comparison). "
                "Each link is the specialist's causal step, not a table fact; the check can only show the chain as written.")

    out["g8.1@geography-specialist"] = problem(
        "ge-g8-1", REQ, "g8.1@geography-specialist",
        s_lit90 + s_lit24, p_lit90 + p_lit24,
        A("concl", GT(V("lit_2024"), V("lit_1990")), "Reason 2: female literacy rose.", SI),
        reading="Reason 2 is read as a rise in the female literacy rate between 1990 and 2024 (54% to 91%).")

    out["g8.2@geography-specialist"] = problem(
        "ge-g8-2", REQ, "g8.2@geography-specialist",
        s_lit90 + s_lit24, p_lit90 + p_lit24,
        A("concl", GT(V("lit_2024"), V("lit_1990")),
          "The female literacy rate rose from 54% in 1990 to 91% in 2024 (Figure 1).", SI),
        reading="The conclusion is the rise. The values are table facts, grounded by the row excerpt.")

    # g9.2 -- population growth of 85.4%
    pct_growth = DS("pct_growth", "percentage increase in the total population from 1990 to 2024", SI)
    out["g9.2@geography-specialist"] = problem(
        "ge-g9-2", REQ, "g9.2@geography-specialist",
        s_pop90 + s_pop24 + [pct_growth],
        p_pop90 + p_pop24 + [
            A("def_growth", EQ(MUL(V("pct_growth"), R("9.6")), MUL(R("100"), SUB(V("pop_2024"), V("pop_1990")))),
              "the percentage increase times the 1990 population of 9.6 equals 100 times the increase of 8.2 million",
              G("general_knowledge", "established", note="percentage increase formula"))],
        A("concl", AND(GE(V("pct_growth"), R("85.35")), LT(V("pct_growth"), R("85.45"))),
          "The population grew by 85.4% from 1990 to 2024, (17.8 - 9.6) divided by 9.6 times 100 = 85.4%.", SI),
        reading="The increase is computed from the two table totals and encoded as [85.35, 85.45) for the one-decimal figure "
                "85.4 (the exact value is 85.42). The claim that the population did not quite double is a separate claim "
                "(g9.3) and is not encoded here.")

    return out


if __name__ == "__main__":
    run_task("ge-e1", "rep-ge-e1-0", build_ge)
