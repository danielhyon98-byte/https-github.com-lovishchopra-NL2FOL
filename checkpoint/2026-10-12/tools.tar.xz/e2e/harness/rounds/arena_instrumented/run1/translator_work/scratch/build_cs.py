"""Translations for cs-e1 (Computer Science: binary, truth tables, Boolean algebra, binary_search traces)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *  # noqa: E402,F401,F403

CS_DOC = "doc-binary-search"
CODE_LIST = "scores = [3, 8, 12, 17, 21, 26, 30, 35, 41]"
VALS = [3, 8, 12, 17, 21, 26, 30, 35, 41]
# passes actually run for each trace, as branch labels: lt (items[mid] < target), gt (>), eq (found, returns)
TRACE_SEQ = {"t30": ["lt", "eq"], "t9": ["gt", "lt", "gt"], "s9": ["lt", "lt"]}
TRACE_TGT = {"t30": 30, "t9": 9, "s9": 9}
TRACE_LIST = {"t30": VALS, "t9": VALS, "s9": [9, 3, 8]}
TRACE_CALL = {"t30": "print(binary_search(scores, 30))", "t9": "print(binary_search(scores, 9))"}


def lookup(mid_name, items):
    """items[mid] as nested allowlisted ite nodes over the supplied list."""
    expr = I(items[-1])
    for i in range(len(items) - 2, -1, -1):
        expr = ITE(EQ(V(mid_name), I(i)), I(items[i]), expr)
    return expr


def trace(P, K, exit_flag=False):
    """Symbols and premises for binary_search trace P through K passes (plus the exit test if exit_flag)."""
    items, seq, tgt = TRACE_LIST[P], TRACE_SEQ[P], TRACE_TGT[P]
    n = len(items)
    if P == "s9":
        g_list = G("assumption", "established", note="the specialist's own example list [9, 3, 8], not a supplied text")
        g_tgt = G("assumption", "established", note="the example target in the claim")
    else:
        g_list = G("quotation", "established", [(CS_DOC, CODE_LIST)])
        g_tgt = G("quotation", "established", [(CS_DOC, TRACE_CALL[P])])
    code_g = G("quotation", "established", [(CS_DOC, "low = 0")])  # placeholder, replaced below per line
    syms, prems = [], []

    def si(name, meaning):
        syms.append(S(name, "Int", meaning, None))

    def pa(pid, expr, label, grounding):
        prems.append(A(pid, expr, label, grounding))

    si(f"{P}_len", f"the length of the list in the trace {P} (number of items)")
    si(f"{P}_tgt", f"the target value searched for in trace {P}")
    pa(f"{P}_pr_len", EQ(V(f"{P}_len"), I(n)), f"the list has {n} items", g_list)
    pa(f"{P}_pr_tgt", EQ(V(f"{P}_tgt"), I(tgt)), f"the target is {tgt}", g_tgt)
    si(f"{P}_lo0", f"low at the start of trace {P}")
    si(f"{P}_hi0", f"high at the start of trace {P}")
    si(f"{P}_st0", f"steps at the start of trace {P}")
    pa(f"{P}_pr_lo0", EQ(V(f"{P}_lo0"), I(0)), "low starts at 0",
       G("quotation", "established", [(CS_DOC, "low = 0")]) if P != "s9" else G("assumption", "established"))
    pa(f"{P}_pr_hi0", EQ(V(f"{P}_hi0"), SUB(V(f"{P}_len"), I(1))), "high starts at len(items) - 1",
       G("quotation", "established", [(CS_DOC, "high = len(items) - 1")]) if P != "s9" else G("assumption", "established"))
    pa(f"{P}_pr_st0", EQ(V(f"{P}_st0"), I(0)), "steps starts at 0",
       G("quotation", "established", [(CS_DOC, "steps = 0")]) if P != "s9" else G("assumption", "established"))

    for k in range(1, K + 1):
        lo_p, hi_p, st_p = f"{P}_lo{k-1}", f"{P}_hi{k-1}", f"{P}_st{k-1}"
        lo, hi, st, mid, it = f"{P}_lo{k}", f"{P}_hi{k}", f"{P}_st{k}", f"{P}_mid{k}", f"{P}_it{k}"
        for nm, mg in ((mid, f"mid in pass {k}"), (it, f"items[mid] in pass {k}"), (st, f"steps after pass {k}")):
            si(nm, mg)
        br = seq[k - 1]
        if br in ("lt", "gt"):
            si(lo, f"low after pass {k}")
            si(hi, f"high after pass {k}")
        pa(f"{P}_pr_mid{k}", EQ(V(mid), IDIV(ADD(V(lo_p), V(hi_p)), I(2))),
           f"pass {k}: mid = (low + high) // 2",
           G("quotation", "established", [(CS_DOC, "mid = (low + high) // 2")]) if P != "s9" else G("assumption", "established"))
        pa(f"{P}_pr_it{k}", EQ(V(it), lookup(mid, items)), f"pass {k}: items[mid] is the list value at mid",
           g_list)
        pa(f"{P}_pr_st{k}", EQ(V(st), ADD(V(st_p), I(1))), f"pass {k}: steps = steps + 1",
           G("quotation", "established", [(CS_DOC, "steps = steps + 1")]) if P != "s9" else G("assumption", "established"))
        if br == "lt":
            pa(f"{P}_pr_br{k}", IMP(LT(V(it), V(f"{P}_tgt")), AND(EQ(V(lo), ADD(V(mid), I(1))), EQ(V(hi), V(hi_p)))),
               f"pass {k}: if items[mid] < target then low = mid + 1 and high is unchanged",
               G("quotation", "established", [(CS_DOC, "low = mid + 1")]) if P != "s9" else G("assumption", "established"))
        elif br == "gt":
            pa(f"{P}_pr_br{k}", IMP(GT(V(it), V(f"{P}_tgt")), AND(EQ(V(hi), SUB(V(mid), I(1))), EQ(V(lo), V(lo_p)))),
               f"pass {k}: if items[mid] > target then high = mid - 1 and low is unchanged",
               G("quotation", "established", [(CS_DOC, "high = mid - 1")]) if P != "s9" else G("assumption", "established"))
        elif br == "eq":
            si(f"{P}_ret_idx", f"the index returned by the call in trace {P}")
            si(f"{P}_ret_st", f"the steps returned by the call in trace {P}")
            pa(f"{P}_pr_ret{k}", IMP(EQ(V(it), V(f"{P}_tgt")), AND(EQ(V(f"{P}_ret_idx"), V(mid)), EQ(V(f"{P}_ret_st"), V(st)))),
               f"pass {k}: if items[mid] == target then return mid, steps",
               G("quotation", "established", [(CS_DOC, "return mid, steps")]) if P != "s9" else G("assumption", "established"))

    if exit_flag:
        last = K
        if f"{P}_ret_idx" not in [s["name"] for s in syms]:
            si(f"{P}_ret_idx", f"the index returned by the call in trace {P}")
            si(f"{P}_ret_st", f"the steps returned by the call in trace {P}")
        pa(f"{P}_pr_exit", IMP(NOT(LE(V(f"{P}_lo{last}"), V(f"{P}_hi{last}"))),
                               AND(EQ(V(f"{P}_ret_idx"), I(-1)), EQ(V(f"{P}_ret_st"), V(f"{P}_st{last}")))),
           "when low > high the loop ends and returns -1, steps",
           G("quotation", "established", [(CS_DOC, "return -1, steps")]) if P != "s9" else G("assumption", "established"))
    return syms, prems


def build_cs(docs):
    REQ = "req-cs-e1"
    out = {}
    SI = G("specialist_inference", "established")
    TK = G("task_setting", "established", note="the binary number is given in the question")

    # ---- binary 1011 0110 (c1.2, c1.3, c2.1, c2.2, c3.1, c3.2, c4.2 and c4.3 use these) ----
    bits = {"bit7": 1, "bit6": 0, "bit5": 1, "bit4": 1, "bit3": 0, "bit2": 1, "bit1": 1, "bit0": 0}

    def bit_syms():
        s = [S(b, "Int", f"bit {b[3:]} of 1011 0110 (1 or 0)", TK) for b in bits]
        p = [A("pr_" + b, EQ(V(b), I(v)), f"bit {b[3:]} of 1011 0110 is {v}", TK) for b, v in bits.items()]
        return s, p

    bs, bp = bit_syms()
    value = S("value", "Int", "denary value of 1011 0110", SI)
    hex_hi = S("hex_hi", "Int", "the high nibble 1011 as a denary digit", SI)
    hex_lo = S("hex_lo", "Int", "the low nibble 0110 as a denary digit", SI)
    rev_value = S("rev_value", "Int", "denary value of the same eight digits read in reverse (0110 1101)", SI)
    place_sum = None  # built inline
    v_def = A("def_value", EQ(V("value"), ADD(MUL(I(128), V("bit7")), MUL(I(64), V("bit6")), MUL(I(32), V("bit5")),
                                             MUL(I(16), V("bit4")), MUL(I(8), V("bit3")), MUL(I(4), V("bit2")),
                                             MUL(I(2), V("bit1")), MUL(I(1), V("bit0")))),
              "denary value is the sum of place values 128 down to 1 times the bits", G("general_knowledge", "established"))
    hi_def = A("def_hi", EQ(V("hex_hi"), ADD(MUL(I(8), V("bit7")), MUL(I(4), V("bit6")), MUL(I(2), V("bit5")), V("bit4"))),
               "the high nibble value is 8, 4, 2, 1 times its bits", G("general_knowledge", "established"))
    lo_def = A("def_lo", EQ(V("hex_lo"), ADD(MUL(I(8), V("bit3")), MUL(I(4), V("bit2")), MUL(I(2), V("bit1")), V("bit0"))),
               "the low nibble value is 8, 4, 2, 1 times its bits", G("general_knowledge", "established"))
    rev_def = A("def_rev", EQ(V("rev_value"), ADD(MUL(I(1), V("bit7")), MUL(I(2), V("bit6")), MUL(I(4), V("bit5")),
                                                 MUL(I(8), V("bit4")), MUL(I(16), V("bit3")), MUL(I(32), V("bit2")),
                                                 MUL(I(64), V("bit1")), MUL(I(128), V("bit0")))),
                "reading the eight bits in reverse gives the place values 1 up to 128 on the bits", G("general_knowledge", "established"))
    bin_base_syms = bs + [value, hex_hi, hex_lo, rev_value]
    bin_base_prems = bp + [v_def, hi_def, lo_def, rev_def]

    out["c1.2"] = problem(
        "cs-c1-2", REQ, "c1.2", bin_base_syms, bin_base_prems,
        A("concl", EQ(V("value"), I(182)), "1011 0110 in denary is 182.", SI),
        reading="The student's binary to denary conversion is checked against the bit pattern given in the question (1011 0110) "
                "with the place values 128 to 1. The bit values are task-given; the place-value sum is a general-knowledge "
                "premise.")

    out["c1.3"] = problem(
        "cs-c1-3", REQ, "c1.3", bin_base_syms, bin_base_prems,
        A("concl", AND(EQ(V("hex_hi"), I(11)), EQ(V("hex_lo"), I(6))),
          "1011 0110 in hexadecimal is B6, where B is 11 and 6 is 6.", SI),
        reading="Each nibble is converted to a denary digit (1011 = 11, the digit B; 0110 = 6). The conclusion is the two digits; "
                "the nibble values follow from the bit premises.")

    out["c2.1"] = problem(
        "cs-c2-1", REQ, "c2.1", bin_base_syms, bin_base_prems,
        A("concl", AND(EQ(ADD(I(128), I(32), I(16), I(4), I(2)), I(182)), EQ(V("value"), I(182))),
          "The 1 bits have place values 128, 32, 16, 4 and 2, so 128 + 32 + 16 + 4 + 2 = 182 (denary).", SI),
        reading="The working is encoded as the place-value sum of the set bits, equal to the bit-pattern value. The bits "
                "themselves are task-given premises, not restated in the conclusion.",
        flags=[])

    out["c2.2"] = problem(
        "cs-c2-2", REQ, "c2.2", bin_base_syms, bin_base_prems,
        A("concl", AND(EQ(V("hex_hi"), I(11)), EQ(V("hex_lo"), I(6))),
          "Grouping the bits in fours from the right, 1011 is B and 0110 is 6, so 1011 0110 is B6 in hexadecimal.", SI),
        reading="Same nibble grouping as the hexadecimal conversion: the two groups of four are encoded as digit values.")

    out["c3.1"] = problem(
        "cs-c3-1", REQ, "c3.1", bin_base_syms, bin_base_prems,
        A("concl", EQ(V("value"), I(182)), "The student's 182 is correct.", SI),
        reading="The point is the student's denary answer, checked against the bit pattern (the same check as c1.2).")

    out["c3.2"] = problem(
        "cs-c3-2", REQ, "c3.2", bin_base_syms, bin_base_prems,
        A("concl", EQ(V("rev_value"), I(109)),
          "109 is the value of the same eight digits read in reverse (0110 1101 = 109).", SI),
        reading="The reversed digits 0110 1101 read as binary give 109; the reversal is encoded as place values on the original "
                "bits. The 'likely cause' is an interpretation and is not encoded.")

    # ---- 12-bit values (c4.2, c4.3) ----
    n_values = S("n_values", "Int", "number of distinct values in 12 bits (2 to the power 12)", SI)
    max_val = S("max_val", "Int", "largest unsigned value in 12 bits", SI)
    pow_def = A("def_pow", EQ(V("n_values"), MUL(*[I(2)] * 12)), "2 to the power 12 is 2 multiplied by itself 12 times",
                G("general_knowledge", "established"))
    out["c4.2"] = problem(
        "cs-c4-2", REQ, "c4.2", [n_values], [pow_def],
        A("concl", EQ(V("n_values"), I(4096)), "12 bits give 4096 (2 to the power 12) different values.", SI),
        reading="The count of values for 12 bits is 2 to the power 12, encoded as the product of twelve 2s.")
    out["c4.3"] = problem(
        "cs-c4-3", REQ, "c4.3", [n_values, max_val],
        [pow_def, A("def_max", EQ(V("max_val"), SUB(V("n_values"), I(1))),
                    "the largest unsigned value is the number of values minus one", G("general_knowledge", "established"))],
        A("concl", EQ(V("max_val"), I(4095)), "Taking the bits as unsigned, 12 bits represent 0 to 4095.", SI),
        reading="The upper end 4095 is the number of 12-bit values minus one. The lower end 0 (all bits zero) is not encoded "
                "as a separate conjunct because it would only restate a definition.")

    # ---- truth table rows (c6.2 to c6.9): X = (A AND B) OR (NOT A AND C) ----
    rows = {
        2: (0, 0, 0, 0, 1, 0, 0), 3: (0, 0, 1, 0, 1, 1, 1), 4: (0, 1, 0, 0, 1, 0, 0), 5: (0, 1, 1, 0, 1, 1, 1),
        6: (1, 0, 0, 0, 0, 0, 0), 7: (1, 0, 1, 0, 0, 0, 0), 8: (1, 1, 0, 1, 0, 0, 1), 9: (1, 1, 1, 1, 0, 0, 1),
    }
    for idx, (a, b, c, ab, na, nac, x) in rows.items():
        cid = f"c6.{idx}"
        p = f"tt{idx}"
        sy = [S(f"{p}_a", "Bool", "A is 1 in this row", SI), S(f"{p}_b", "Bool", "B is 1 in this row", SI),
              S(f"{p}_c", "Bool", "C is 1 in this row", SI), S(f"{p}_ab", "Bool", "A AND B in this row", SI),
              S(f"{p}_na", "Bool", "NOT A in this row", SI), S(f"{p}_nac", "Bool", "NOT A AND C in this row", SI),
              S(f"{p}_x", "Bool", "X in this row", SI)]

        def inp(nm, v):
            return V(nm) if v else NOT(V(nm))
        pr = [A(f"{p}_in_a", inp(f"{p}_a", a), "input A in this row", SI),
              A(f"{p}_in_b", inp(f"{p}_b", b), "input B in this row", SI),
              A(f"{p}_in_c", inp(f"{p}_c", c), "input C in this row", SI),
              A(f"{p}_def_ab", IFF(V(f"{p}_ab"), AND(V(f"{p}_a"), V(f"{p}_b"))), "A AND B is true when A and B are both true",
                G("general_knowledge", "established")),
              A(f"{p}_def_na", IFF(V(f"{p}_na"), NOT(V(f"{p}_a"))), "NOT A is the negation of A",
                G("general_knowledge", "established")),
              A(f"{p}_def_nac", IFF(V(f"{p}_nac"), AND(V(f"{p}_na"), V(f"{p}_c"))), "NOT A AND C",
                G("general_knowledge", "established")),
              A(f"{p}_def_x", IFF(V(f"{p}_x"), OR(V(f"{p}_ab"), V(f"{p}_nac"))), "X = (A AND B) OR (NOT A AND C)",
                G("task_setting", "established", note="the expression for X given in the question"))]
        concl = AND(IFF(V(f"{p}_ab"), B(ab)), IFF(V(f"{p}_na"), B(na)), IFF(V(f"{p}_nac"), B(nac)), IFF(V(f"{p}_x"), B(x)))
        out[cid] = problem(
            f"cs-{cid.replace('.', '-')}", REQ, cid, sy, pr,
            A("concl", concl, f"the row A={a}, B={b}, C={c} gives A AND B={ab}, NOT A={na}, NOT A AND C={nac}, X={x}", SI),
            reading=f"Row with inputs A={a}, B={b}, C={c}. The column formulas and the X expression are encoded as premises; the "
                    f"claimed row values are the conclusion.")

    # ---- Boolean algebra (c7.2): A.B + A.NOT B = A ----
    out["c7.2"] = problem(
        "cs-c7-2", REQ, "c7.2",
        [S("ba_a", "Bool", "the Boolean variable A", G("task_setting", "established", note="from the question")),
         S("ba_b", "Bool", "the Boolean variable B", G("task_setting", "established", note="from the question"))],
        [],
        A("concl", IFF(OR(AND(V("ba_a"), V("ba_b")), AND(V("ba_a"), NOT(V("ba_b")))), V("ba_a")),
          "A.B + A.NOT B = A.(B + NOT B) = A.1 = A (distributive, complement and identity laws).", SI),
        reading="The claimed identity is a Boolean law and holds for every assignment, so the conclusion is valid with no premises. "
                "The intermediate steps name laws that the single equivalence already covers.")

    # ---- binary_search traces (c8.2, c11.2-c11.4, c12.2, c12.3, c14.2-c14.6, c15.5, c15.6) ----
    def tr_problem(cid, pid, P, K, concl_expr, label, exit_flag=False, extra_syms=None, extra_prems=None, reading="", amb=False):
        syms, prems = trace(P, K, exit_flag)
        if extra_syms:
            syms += extra_syms
        if extra_prems:
            prems += extra_prems
        return problem(pid, REQ, cid, syms, prems, A("concl", concl_expr, label, SI), reading=reading, ambiguous=amb)

    out["c8.2"] = tr_problem(
        "c8.2", "cs-c8-2", "t30", 2,
        AND(EQ(V("t30_ret_idx"), I(6)), EQ(V("t30_ret_st"), I(2))),
        "The call binary_search(scores, 30) prints (6, 2).",
        reading="Trace of binary_search(scores, 30) through the two passes that run: pass 1 finds 21 < 30 (low becomes 5), pass 2 "
                "finds 30 at mid 6 and returns (6, 2). The list values are the quoted code line.")

    out["c11.2"] = tr_problem(
        "c11.2", "cs-c11-2", "t30", 0,
        EQ(V("t30_hi0"), I(8)),
        "start: low 0, high 8, steps 0 (trace of binary_search(scores, 30)).",
        reading="The start state of the trace. high is len(items) - 1 = 8 (the list has nine values, quoted). low = 0 and steps = 0 "
                "are the code's initial assignments and are premises, not conclusion conjuncts.")

    out["c11.3"] = tr_problem(
        "c11.3", "cs-c11-3", "t30", 1,
        AND(EQ(V("t30_mid1"), I(4)), EQ(V("t30_st1"), I(1)), EQ(V("t30_lo1"), I(5)), EQ(V("t30_hi1"), I(8))),
        "pass 1: mid 4, steps 1, items[mid] 21, 21 < 30, so low = 5.",
        reading="Pass 1 of the trace: mid = (0 + 8) // 2 = 4, steps becomes 1, items[4] = 21 is less than 30, so low becomes 5 "
                "and high stays 8. The row's low value is the state after the update.")

    out["c11.4"] = tr_problem(
        "c11.4", "cs-c11-4", "t30", 2,
        AND(EQ(V("t30_mid2"), I(6)), EQ(V("t30_st2"), I(2)), LE(V("t30_lo1"), V("t30_hi1")),
            EQ(V("t30_ret_idx"), I(6)), EQ(V("t30_ret_st"), I(2))),
        "pass 2: 5 <= 8, mid 6, steps 2, items[mid] 30, so return (6, 2).",
        reading="Pass 2 of the trace: the loop test 5 <= 8 holds, mid = (5 + 8) // 2 = 6, steps becomes 2, items[6] = 30 equals "
                "the target, so the call returns mid and steps, (6, 2).")

    out["c14.2"] = tr_problem(
        "c14.2", "cs-c14-2", "t9", 0,
        EQ(V("t9_hi0"), I(8)),
        "start: low 0, high 8, steps 0 (trace of binary_search(scores, 9)).",
        reading="The start state of the trace of binary_search(scores, 9). high is len(items) - 1 = 8; the initial low and steps "
                "are code assignments and premises.")

    out["c14.3"] = tr_problem(
        "c14.3", "cs-c14-3", "t9", 1,
        AND(EQ(V("t9_mid1"), I(4)), EQ(V("t9_st1"), I(1)), EQ(V("t9_hi1"), I(3)), EQ(V("t9_lo1"), I(0))),
        "pass 1: 0 <= 8, mid 4, steps 1, items[mid] 21, 21 > 9, so high = 3.",
        reading="Pass 1 of the trace for 9: mid = 4, steps = 1, items[4] = 21 is greater than 9, so high becomes mid - 1 = 3 and "
                "low stays 0.")

    out["c14.4"] = tr_problem(
        "c14.4", "cs-c14-4", "t9", 2,
        AND(EQ(V("t9_mid2"), I(1)), EQ(V("t9_st2"), I(2)), EQ(V("t9_lo2"), I(2)), EQ(V("t9_hi2"), I(3))),
        "pass 2: 0 <= 3, mid 1, steps 2, items[mid] 8, 8 < 9, so low = 2.",
        reading="Pass 2 of the trace for 9: mid = (0 + 3) // 2 = 1, steps = 2, items[1] = 8 is less than 9, so low becomes 2.")

    out["c14.5"] = tr_problem(
        "c14.5", "cs-c14-5", "t9", 3,
        AND(EQ(V("t9_mid3"), I(2)), EQ(V("t9_st3"), I(3)), EQ(V("t9_hi3"), I(1)), EQ(V("t9_lo3"), I(2))),
        "pass 3: 2 <= 3, mid 2, steps 3, items[mid] 12, 12 > 9, so high = 1.",
        reading="Pass 3 of the trace for 9: mid = (2 + 3) // 2 = 2, steps = 3, items[2] = 12 is greater than 9, so high becomes 1.")

    exit_concl = AND(NOT(LE(V("t9_lo3"), V("t9_hi3"))), EQ(V("t9_ret_st"), I(3)))
    out["c14.6"] = tr_problem(
        "c14.6", "cs-c14-6", "t9", 3,
        exit_concl,
        "exit: 2 <= 1 is false, so the loop ends and returns (-1, 3).",
        exit_flag=True,
        reading="After three passes low = 2 and high = 1, so the loop test fails and the call returns -1 with steps 3. The literal "
                "-1 is the code's return value and is a premise of the exit rule, not a conjunct of the conclusion.")

    out["c12.2"] = tr_problem(
        "c12.2", "cs-c12-2", "t9", 3,
        exit_concl,
        "The call binary_search(scores, 9) prints (-1, 3).",
        exit_flag=True,
        reading="The printed steps value is the number of passes (3) and the search ends with low above high. The -1 is the code's "
                "return value and is a premise of the exit rule.")

    out["c12.3"] = tr_problem(
        "c12.3", "cs-c12-3", "t9", 3,
        AND(EQ(V("t9_ret_st"), I(3)), NE(V("t9_ret_st"), I(4)), NOT(LE(V("t9_lo3"), V("t9_hi3")))),
        "The count is 3, not 4: steps rises by one for each pass, and the final test (2 <= 1) fails before the body runs.",
        exit_flag=True,
        reading="Steps increases by one per pass through the loop body; there are three passes and the final test 2 <= 1 is false, "
                "so the count is 3 and not 4. The student's -1 is the code's return value, not restated.")

    # ---- the example list [9, 3, 8] with target 9 (c15.5, c15.6) ----
    s9_item0 = S("s9_item0", "Int", "the first item of the example list [9, 3, 8]", G("assumption", "established", note="the specialist's own example"))
    s9_present = S("s9_present", "Bool", "the target 9 is present in the example list [9, 3, 8]", SI)
    s9_present_def = A("def_present", IFF(V("s9_present"), EQ(V("s9_item0"), I(9))),
                       "9 is present in [9, 3, 8] because the first item is 9", G("assumption", "established", note="the specialist's own example"))
    s9_item0_pr = A("pr_item0", EQ(V("s9_item0"), I(9)), "the first item of [9, 3, 8] is 9",
                    G("assumption", "established", note="the specialist's own example"))
    out["c15.5"] = tr_problem(
        "c15.5", "cs-c15-5", "s9", 1,
        AND(EQ(V("s9_mid1"), I(1)), LT(V("s9_it1"), V("s9_tgt")), GT(V("s9_lo1"), I(0))),
        "For [9, 3, 8] and target 9, mid is 1 and 3 < 9, so index 0, which holds 9, is discarded.",
        extra_syms=[s9_item0, s9_present],
        extra_prems=[s9_item0_pr],
        reading="The example is worked on the list [9, 3, 8] with target 9: mid = (0 + 2) // 2 = 1, items[1] = 3 is less than 9, "
                "so low becomes 2 and index 0 lies outside the range. The example list is the specialist's, not a supplied text.")

    out["c15.6"] = tr_problem(
        "c15.6", "cs-c15-6", "s9", 2,
        AND(NOT(LE(V("s9_lo2"), V("s9_hi2"))), EQ(V("s9_ret_st"), I(2)), V("s9_present")),
        "The call returns (-1, 2) although 9 is present.",
        exit_flag=True,
        extra_syms=[s9_item0, s9_present],
        extra_prems=[s9_item0_pr, s9_present_def],
        reading="Tracing the call on [9, 3, 8] for 9: two passes (the first discards index 0 because 3 < 9 and the second "
                "discards index 2 because 8 < 9) leave low above high, so the call returns (-1, 2) while 9 is present at index 0.")

    # ---- null: not checkable as written ----
    out["c5.1"] = null("The claim is a question label ('1(c)') with no content to encode.",
                       "a question label with no statement to check")
    out["c9.2"] = null("The claim transcribes the supplied list. Its only encoding restates the supplied code line.",
                       "a transcription of the supplied list: the only encoding restates the supplied code line")
    out["c15.3"] = null("The claim says the code assumes every item up to mid is smaller than the target. That is a universal "
                        "statement over list positions.",
                        "the claim quantifies over every list position up to mid, which the IR does not express (no quantifiers)")

    return out


if __name__ == "__main__":
    run_task("cs-e1", "rep-cs-e1-0", build_cs)
