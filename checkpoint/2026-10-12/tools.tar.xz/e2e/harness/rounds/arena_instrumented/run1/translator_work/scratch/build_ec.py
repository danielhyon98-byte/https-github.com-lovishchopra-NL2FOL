"""Translations for ec-e1 (Economics: Teravia sugar tax, PED, incidence, revenue, diagrams)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *  # noqa: E402,F401,F403

DOC = "doc-teravia"
ROW = {
    "price": "Average price per litre | $1.60 | $2.00",
    "qty": "Quantity sold per month | 50 million litres | 45 million litres",
    "tax": "Specific tax per litre | $0.00 | $0.60",
}
# name: (table row key, table value, meaning)
FIGS = {
    "p_before": ("price", "1.60", "average price per litre before the tax ($)"),
    "p_after": ("price", "2.00", "average price per litre after the tax ($)"),
    "q_before": ("qty", "50", "quantity sold per month before the tax (million litres)"),
    "q_after": ("qty", "45", "quantity sold per month after the tax (million litres)"),
    "tax_after": ("tax", "0.60", "specific tax per litre after the tax ($)"),
}
SI = G("specialist_inference", "established")
GK = G("general_knowledge", "established")


def FS(name):
    key, _, meaning = FIGS[name]
    return S(name, "Real", meaning, G("arithmetic_fact", "established", [(DOC, ROW[key])]))


def FP(name):
    key, val, meaning = FIGS[name]
    return A("fp_" + name, EQ(V(name), R(val)), f"the table gives the {meaning} as {val}",
             G("arithmetic_fact", "established", [(DOC, ROW[key])]))


def DS(name, meaning, ground=SI):
    return S(name, "Real", meaning, ground)


def build_ec(docs):
    REQ = "req-ec-e1"
    out = {}
    TK = G("task_setting", "established", note="the figure is given in the question")

    def figs(*names):
        return [FS(n) for n in names], [FP(n) for n in names]

    s_pb, p_pb = figs("p_before")
    s_pa, p_pa = figs("p_after")
    s_qb, p_qb = figs("q_before")
    s_qa, p_qa = figs("q_after")
    s_tx, p_tx = figs("tax_after")
    fig_s = s_pb + s_pa + s_qb + s_qa + s_tx
    fig_p = p_pb + p_pa + p_qb + p_qa + p_tx

    dq = DS("dq", "percentage change in quantity demanded (%)")
    dp = DS("dp", "percentage change in price (%)")
    ped = DS("ped", "price elasticity of demand")
    dq_def = A("def_dq", EQ(MUL(V("dq"), R("50")), MUL(R("100"), SUB(V("q_after"), V("q_before")))),
               "the percentage change in quantity is (45 - 50) divided by 50 times 100", GK)
    dp_def = A("def_dp", EQ(MUL(V("dp"), R("1.60")), MUL(R("100"), SUB(V("p_after"), V("p_before")))),
               "the percentage change in price is (2.00 - 1.60) divided by 1.60 times 100", GK)
    ped_def = A("def_ped", EQ(MUL(V("ped"), R("25")), V("dq")),
                "PED is the percentage change in quantity divided by the percentage change in price (25.00)", GK)
    inelastic = S("inelastic", "Bool", "demand is price inelastic", SI)
    inel_def = A("def_inel", IFF(V("inelastic"), AND(GT(V("ped"), R("-1")), LT(V("ped"), R("0")))),
                 "demand is price inelastic when its absolute value is below 1", GK)
    ped_chain_s = [dq, dp, ped]
    ped_chain_p = [dq_def, dp_def, ped_def]

    # g2.1
    out["g2.1@economics-specialist"] = problem(
        "ec-g2-1", REQ, "g2.1@economics-specialist",
        fig_s + [dq], fig_p + [dq_def],
        A("concl", AND(GE(V("dq"), R("-10.005")), LT(V("dq"), R("-9.995"))),
          "%ΔQd = (45 - 50) divided by 50 times 100 = -10.00%.", SI),
        reading="The quantities are the table figures (50 before, 45 after). The percentage change is encoded with the "
                "claimed -10.00 written to two decimal places as the interval [-10.005, -9.995).")

    # g2.2
    out["g2.2@economics-specialist"] = problem(
        "ec-g2-2", REQ, "g2.2@economics-specialist",
        fig_s + [dp], fig_p + [dp_def],
        A("concl", AND(GE(V("dp"), R("24.995")), LT(V("dp"), R("25.005"))),
          "%ΔP = (2.00 - 1.60) divided by 1.60 times 100 = 25.00%.", SI),
        reading="The prices are the table figures (1.60 before, 2.00 after). The claimed 25.00 is encoded as the interval for "
                "two decimal places.")

    # g2.3
    out["g2.3@economics-specialist"] = problem(
        "ec-g2-3", REQ, "g2.3@economics-specialist",
        fig_s + ped_chain_s, fig_p + ped_chain_p,
        A("concl", AND(GE(V("ped"), R("-0.405")), LT(V("ped"), R("-0.395"))),
          "PED = -10.00% divided by 25.00% = -0.40.", SI),
        reading="PED is the quantity change over the price change, with the 25% price change as the divisor (encoded as a constant "
                "multiple). The claimed -0.40 is encoded as [-0.405, -0.395).")

    # g3.1 -- a definition from memory
    out["g3.1@economics-specialist"] = null(
        "The claim is the definition of PED, given from memory with no figure to check. The definition is applied in g2.3.",
        "a definition from memory with no figure or claim to check; applied and checked in g2.3")

    # g3.2 -- the student's -2.5 is the reciprocal of -0.4 (27 divided by -10 check)
    stud = DS("stud_ped", "the student's PED answer (-2.5)", TK)
    out["g3.2@economics-specialist"] = problem(
        "ec-g3-2", REQ, "g3.2@economics-specialist",
        [stud], [A("pr_stud", EQ(V("stud_ped"), R("-2.5")), "the student's PED answer is -2.5", TK)],
        A("concl", AND(EQ(MUL(V("stud_ped"), R("-10")), R("25")), EQ(MUL(V("stud_ped"), R("-0.4")), R("1"))),
          "The student's -2.5 is the reciprocal of -0.4 because they divided 25.00 by -10.00.", SI),
        reading="Checks the student's -2.5 against the two relations the specialist states: -2.5 times -10 is 25 (division of "
                "25 by -10) and -2.5 times -0.4 is 1 (reciprocal of -0.4). Both are linear with constant multipliers.")

    # g3.3 -- the answer sheet's -0.40 is correct
    out["g3.3@economics-specialist"] = problem(
        "ec-g3-3", REQ, "g3.3@economics-specialist",
        fig_s + ped_chain_s, fig_p + ped_chain_p,
        A("concl", AND(GE(V("ped"), R("-0.405")), LT(V("ped"), R("-0.395"))),
          "The -0.40 on the answer sheet is correct.", SI),
        reading="The answer sheet's -0.40 is the same PED value as g2.3 and is checked the same way.")

    # g3.4 -- price inelastic because |PED| < 1
    out["g3.4@economics-specialist"] = problem(
        "ec-g3-4", REQ, "g3.4@economics-specialist",
        fig_s + ped_chain_s + [inelastic], fig_p + ped_chain_p + [inel_def],
        A("concl", AND(V("inelastic"), GT(V("ped"), R("-1")), LT(V("ped"), R("0"))),
          "Demand is price inelastic, because its absolute value is below 1.", SI),
        reading="The 'because' is the definition of inelastic demand as |PED| below 1, encoded as the general-knowledge "
                "equivalence; the PED value comes from the table chain.")

    # g4.1 -- tax revenue = 0.60 x 45 million litres = $27 million a month
    rev = DS("rev", "monthly tax revenue after the tax ($ million)")
    out["g4.1@economics-specialist"] = problem(
        "ec-g4-1", REQ, "g4.1@economics-specialist",
        fig_s + [rev], fig_p + [A("def_rev", EQ(V("rev"), MUL(R("0.60"), V("q_after"))),
                                  "revenue is the tax per litre times the quantity sold after the tax",
                                  G("general_knowledge", "established"))],
        A("concl", EQ(V("rev"), R("27")), "Tax revenue is $0.60 times 45 million litres = $27 million per month.", SI),
        reading="Revenue is the tax per litre times the post-tax quantity. Both figures are table figures.")

    # g4.2 -- the friend's $30 million uses the pre-tax quantity
    fr_fig = DS("friend_fig", "the friend's monthly revenue figure ($ million)", TK)
    fr_q = DS("friend_q", "the quantity the friend's figure is based on (million litres)", SI)
    out["g4.2@economics-specialist"] = problem(
        "ec-g4-2", REQ, "g4.2@economics-specialist",
        fig_s + [fr_fig, fr_q],
        fig_p + [A("pr_friend", EQ(V("friend_fig"), R("30")), "the friend says the tax raises $30 million a month", TK),
                 A("pr_friend_q", EQ(V("friend_q"), V("q_before")),
                   "the friend's figure uses the quantity before the tax (50 million litres)", SI)],
        A("concl", AND(EQ(MUL(R("0.60"), V("friend_q")), V("friend_fig")), NE(V("friend_q"), V("q_after"))),
          "Your friend's $30 million is $0.60 times 50 million litres, the quantity before the tax, so it ignores the fall in sales.", SI),
        reading="The friend's figure (task-given) equals the tax times the pre-tax quantity, and that quantity is not the post-tax "
                "quantity, so the calculation ignores the fall in sales.")

    # g5.1-g5.5 -- incidence per litre and shares
    cons = DS("cons_tax", "consumers' share of the tax per litre ($)")
    keep = DS("keep", "price producers keep after the tax per litre ($)")
    prod = DS("prod_tax", "producers' share of the tax per litre ($)")
    sh_c = DS("sh_cons", "consumers' share of the tax (%)")
    sh_p = DS("sh_prod", "producers' share of the tax (%)")
    d_cons = A("def_cons", EQ(V("cons_tax"), SUB(V("p_after"), V("p_before"))),
               "consumers pay the rise in the price: $2.00 minus $1.60", GK)
    d_keep = A("def_keep", EQ(V("keep"), SUB(V("p_after"), V("tax_after"))),
               "the price producers keep is the new price minus the tax: $2.00 minus $0.60", GK)
    d_prod = A("def_prod", EQ(V("prod_tax"), SUB(V("p_before"), V("keep"))),
               "producers bear the fall in the price they keep: $1.60 minus the price kept", GK)
    d_shc = A("def_sh_cons", EQ(MUL(V("sh_cons"), R("0.60")), MUL(R("100"), V("cons_tax"))),
              "consumers' share is 0.40 divided by 0.60 times 100", GK)
    d_shp = A("def_sh_prod", EQ(MUL(V("sh_prod"), R("0.60")), MUL(R("100"), V("prod_tax"))),
              "producers' share is 0.20 divided by 0.60 times 100", GK)

    out["g5.1@economics-specialist"] = problem(
        "ec-g5-1", REQ, "g5.1@economics-specialist",
        fig_s + [cons], fig_p + [d_cons],
        A("concl", EQ(V("cons_tax"), R("0.40")), "Consumers: $2.00 - $1.60 = $0.40 per litre.", SI),
        reading="Consumers' part is the rise in the price from 1.60 to 2.00 (table figures).")

    out["g5.2@economics-specialist"] = problem(
        "ec-g5-2", REQ, "g5.2@economics-specialist",
        fig_s + [keep, prod], fig_p + [d_keep, d_prod],
        A("concl", AND(EQ(V("keep"), R("1.40")), EQ(V("prod_tax"), R("0.20"))),
          "Producers: $1.60 - $1.40 = $0.20 per litre; the price kept falls to $2.00 - $0.60 = $1.40.", SI),
        reading="The price producers keep is 2.00 minus the 0.60 tax (1.40), and their part is 1.60 minus that (0.20).")

    out["g5.3@economics-specialist"] = problem(
        "ec-g5-3", REQ, "g5.3@economics-specialist",
        fig_s + [keep, cons, prod], fig_p + [d_keep, d_cons, d_prod],
        A("concl", EQ(ADD(V("cons_tax"), V("prod_tax")), R("0.60")), "Check: $0.40 + $0.20 = $0.60 per litre.", SI),
        reading="The two parts sum to the tax per litre (0.60), checked on the computed parts.")

    out["g5.4@economics-specialist"] = problem(
        "ec-g5-4", REQ, "g5.4@economics-specialist",
        fig_s + [cons, sh_c], fig_p + [d_cons, d_shc],
        A("concl", AND(GE(V("sh_cons"), R("66.665")), LT(V("sh_cons"), R("66.675"))),
          "Consumers' share = 0.40 divided by 0.60 times 100 = 66.67%.", SI),
        reading="The share is 0.40 over 0.60 as a percentage, checked as the interval for 66.67 at two decimal places.")

    out["g5.5@economics-specialist"] = problem(
        "ec-g5-5", REQ, "g5.5@economics-specialist",
        fig_s + [keep, prod, sh_p], fig_p + [d_keep, d_prod, d_shp],
        A("concl", AND(GE(V("sh_prod"), R("33.325")), LT(V("sh_prod"), R("33.335"))),
          "Producers' share = 0.20 divided by 0.60 times 100 = 33.33%.", SI),
        reading="The producers' share is 0.20 over 0.60 as a percentage, checked as the interval for 33.33 at two decimal places.")

    # g6.3 -- diagram description (null), g6.5 -- transcription of the equilibrium (null)
    out["g6.3@economics-specialist"] = null(
        "The claim describes the curves of Diagram 1; its only encoding restates the tax figure.",
        "a description of diagram curves whose only encoding restates the tax figure; no inference to check")
    out["g6.5@economics-specialist"] = null(
        "The claim transcribes the equilibrium values from Table 1.",
        "a transcription of the table's equilibrium values: the only encoding restates the table")

    # g7.1 -- the tax shifts supply up, so price rises by 25% and quantity falls by only 10%
    shift_up = S("shift_up", "Bool", "the $0.60 tax shifts supply up (Diagram 1)", SI)
    price_rises = S("price_rises", "Bool", "the price rises from $1.60 to $2.00", SI)
    qty_falls = S("qty_falls", "Bool", "the quantity falls from 50 to 45 million litres", SI)
    out["g7.1@economics-specialist"] = problem(
        "ec-g7-1", REQ, "g7.1@economics-specialist",
        fig_s + ped_chain_s + [shift_up, price_rises, qty_falls],
        fig_p + ped_chain_p + [
            A("pr_shift", V("shift_up"), "the tax shifts supply up, as Diagram 1 shows", SI),
            A("pr_shift_link", IMP(V("shift_up"), AND(V("price_rises"), V("qty_falls"))),
              "a supply shift up raises the price and lowers the quantity", SI),
            A("pr_rises", IFF(V("price_rises"), GT(V("p_after"), V("p_before"))), "the price rises from 1.60 to 2.00",
              G("arithmetic_fact", "established", [(DOC, ROW["price"])])),
            A("pr_falls", IFF(V("qty_falls"), LT(V("q_after"), V("q_before"))), "the quantity falls from 50 to 45",
              G("arithmetic_fact", "established", [(DOC, ROW["qty"])]))],
        A("concl", AND(V("price_rises"), V("qty_falls"), GE(V("dp"), R("24.5")), LT(V("dp"), R("25.5")),
                       GE(V("dq"), R("-10.5")), LT(V("dq"), R("-9.5"))),
          "As Diagram 1 shows, the $0.60 tax shifts supply up, so the price rises by 25% while quantity falls by only 10%.", SI),
        reading="The shift and the causal link are the specialist's (Diagram 1). The percentages are written to no decimal places, "
                "so 25% and 10% are encoded as half-unit intervals. 'Only' is not encoded as a separate comparison.")

    # g7.2 -- inelastic demand (steep curve), so the shift moves the market only a short way along D
    steep = S("steep_demand", "Bool", "the demand curve D is steep", SI)
    short = S("short_move", "Bool", "the shift moves the market only a short way along D", SI)
    out["g7.2@economics-specialist"] = problem(
        "ec-g7-2", REQ, "g7.2@economics-specialist",
        fig_s + ped_chain_s + [inelastic, steep, short],
        fig_p + ped_chain_p + [inel_def,
                               A("pr_steep", IMP(V("inelastic"), V("steep_demand")),
                                 "inelastic demand is drawn as a steep demand curve", SI),
                               A("pr_short", IMP(V("steep_demand"), V("short_move")),
                                 "a steep demand curve means the shift moves the market only a short way along D", SI)],
        A("concl", AND(V("inelastic"), V("short_move")),
          "Demand is price inelastic (PED = -0.40), so the steep demand curve means the shift moves the market only a short way along D.", SI),
        reading="PED gives inelastic demand (the value from the table chain), and the two links from inelastic to a steep curve and "
                "from a steep curve to a short movement are the specialist's diagram steps.")

    # g9.1 -- restates the supplied sentence about the ministry's cost estimate
    out["g9.1@economics-specialist"] = null(
        "The claim restates the supplied sentence in paragraph 1 that the health ministry says obesity costs $310 million a year.",
        "a restatement of a supplied sentence with no inference: the only encoding repeats the quoted figure")

    return out


if __name__ == "__main__":
    run_task("ec-e1", "rep-ec-e1-0", build_ec)
