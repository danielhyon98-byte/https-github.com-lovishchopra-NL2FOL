#!/usr/bin/env python3
"""Translator work for the lit-e1 and cs-e1 reports (scratch, not part of the tree).

Writes run1/translations/lit-e1.json and run1/translations/cs-e1.json as
{"report_id": ..., "claims": {claim_id: {problem, interpretation, ambiguous, unsupported_reason}}}.
Every eligible claim from list_claims.py gets an object; claims that cannot be
encoded get problem null with a reason.
"""
import json
import re

BASE = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/e2e"
SPEC = BASE + "/run1/specialists"
MINE = BASE + "/run1/translator_work/mine"
OUT = BASE + "/run1/translations"


def load_json(path):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


SPEC_LIT = load_json(SPEC + "/lit-e1.json")
SPEC_CS = load_json(SPEC + "/cs-e1.json")
DOCS = {}
for _spec in (SPEC_LIT, SPEC_CS):
    for _d in _spec["supplied_texts"]:
        DOCS[_d["document_id"]] = _d["text"]

CLAIMS_LIT = load_json(MINE + "/lit-e1.claims.json")
CLAIMS_CS = load_json(MINE + "/cs-e1.claims.json")
CLAIM_TEXT_CS = {c["claim_id"]: c["text"] for c in CLAIMS_CS["claims"]}

LIT_DOC = "doc-last-morning"
CODE = "doc-binary-search"
SCORES_LINE = "scores = [3, 8, 12, 17, 21, 26, 30, 35, 41]"
SORTED = [3, 8, 12, 17, 21, 26, 30, 35, 41]


# --------------------------------------------------------------------------- #
# Expression helpers (IR 1.0 allowlist only)
# --------------------------------------------------------------------------- #
def V(n):
    return {"op": "var", "name": n}


def B(v):
    return {"op": "bool", "value": bool(v)}


def I(v):
    return {"op": "int", "value": str(v)}


def NOT(a):
    return {"op": "not", "arg": a}


def AND(*xs):
    return xs[0] if len(xs) == 1 else {"op": "and", "args": list(xs)}


def OR(*xs):
    return xs[0] if len(xs) == 1 else {"op": "or", "args": list(xs)}


def IMP(left, right):
    return {"op": "implies", "left": left, "right": right}


def IFF(left, right):
    return {"op": "iff", "left": left, "right": right}


def ITE(c, t, o):
    return {"op": "ite", "cond": c, "then": t, "otherwise": o}


def ADD(*xs):
    return {"op": "add", "args": list(xs)}


def SUB(left, right):
    return {"op": "sub", "left": left, "right": right}


def MUL(*xs):
    return {"op": "mul", "args": list(xs)}


def IDIV(left, right):
    return {"op": "idiv", "left": left, "right": right}


def EQ(left, right):
    return {"op": "eq", "left": left, "right": right}


def NE(left, right):
    return {"op": "ne", "left": left, "right": right}


def LT(left, right):
    return {"op": "lt", "left": left, "right": right}


def LE(left, right):
    return {"op": "le", "left": left, "right": right}


def GT(left, right):
    return {"op": "gt", "left": left, "right": right}


# --------------------------------------------------------------------------- #
# Grounding helpers (quotations are checked verbatim against the supplied text)
# --------------------------------------------------------------------------- #
def GQ(doc, excerpt, certainty="established", note=None):
    assert excerpt in DOCS[doc], f"excerpt not in {doc}: {excerpt!r}"
    g = {"kind": "quotation", "source_refs": [{"document_id": doc, "excerpt": excerpt}],
         "certainty": certainty}
    if note:
        g["note"] = note
    return g


def GK(kind, certainty="established", note=None, doc=None, excerpt=None):
    refs = []
    if doc is not None:
        ref = {"document_id": doc}
        if excerpt is not None:
            assert excerpt in DOCS[doc], f"excerpt not in {doc}: {excerpt!r}"
            ref["excerpt"] = excerpt
        refs.append(ref)
    g = {"kind": kind, "source_refs": refs, "certainty": certainty}
    if note:
        g["note"] = note
    return g


class Prob:
    def __init__(self, problem_id, request_id, claim_id):
        self.p = {"ir_version": "1.0", "problem_id": problem_id, "request_id": request_id,
                  "claim_id": claim_id, "query": "entailment", "symbols": [], "premises": []}
        self._names = set()
        self._ids = set()

    def sym(self, name, sort, meaning, grounding=None):
        assert re.fullmatch(r"[a-z][a-z0-9_]{0,63}", name), name
        assert name not in self._names, f"duplicate symbol {name}"
        self._names.add(name)
        s = {"name": name, "sort": sort, "meaning": meaning}
        if grounding is not None:
            s["grounding"] = grounding
        self.p["symbols"].append(s)

    def prem(self, pid, expr, label, grounding, materiality="material"):
        assert pid not in self._ids, f"duplicate premise id {pid}"
        self._ids.add(pid)
        self.p["premises"].append({"id": pid, "expr": expr, "label": label,
                                   "grounding": grounding, "materiality": materiality})

    def concl(self, cid, expr, label, grounding):
        assert "conclusion" not in self.p
        self.p["conclusion"] = {"id": cid, "expr": expr, "label": label,
                                "grounding": grounding, "materiality": "material"}


def claim_obj(prob, reading, ambiguous=False, flags=None):
    gloss = [{"symbol": s["name"], "meaning": s["meaning"], "grounding": s.get("grounding")}
             for s in prob["symbols"]]
    return {"problem": prob,
            "interpretation": {"reading": reading, "glossary": gloss,
                               "ambiguity_flags": flags or []},
            "ambiguous": ambiguous, "unsupported_reason": None}


def null_obj(reading, reason):
    return {"problem": None,
            "interpretation": {"reading": reading, "glossary": [], "ambiguity_flags": []},
            "ambiguous": False, "unsupported_reason": reason}


# =========================================================================== #
# lit-e1 (English A: Literature), document doc-last-morning
# =========================================================================== #
REQ_LIT = SPEC_LIT and CLAIMS_LIT["request_id"]

EVQ = {
    "ev_teeth": ("the shelves looked like a mouth with its teeth knocked out",
                 "looked like a mouth with its teeth knocked out"),
    "ev_knocked": ("the phrase 'knocked out'", "knocked out"),
    "ev_told": ("the narrator says she told herself she was glad", "I told myself I was glad"),
    "ev_amen": ("the flat has a dishwasher, a lift and a view of the river",
                "dishwasher and a lift and a view of the river"),
    "ev_twice": ("she says it twice, out loud, to the empty kitchen",
                 "twice, out loud, to the empty kitchen"),
    "ev_thinner": ("the kitchen gave her words back thinner", "gave it back to me thinner"),
    "ev_stairs": ("the stairs groaned", "The stairs groaned"),
    "ev_palms": ("on bad nights she pressed her palms flat against the wall until she felt held",
                 "my palms flat against the cold plaster until I felt held"),
    "ev_click": ("she listened for the click of the door, as every morning",
                 "for the click, the way I had every morning of my life"),
    "ev_handle": ("she had not let go of the handle", "had not let go of the handle"),
    "ev_narrow": ("her bedroom was so narrow she could touch both walls",
                  "My bedroom was so narrow that I could touch both walls at once"),
}

INTERP = {
    "i_injured": "the simile makes the bare shelves an injured body",
    "i_blow": "'knocked out' implies a blow",
    "i_imposed": "the loss suggests something imposed on the narrator rather than chosen by her",
    "i_not_felt": "her gladness is something she told herself, not something she feels",
    "i_echo": "the personification turns her words into an echo with less substance",
    "i_amen_flat": "the amenities describe the flat rather than her response",
    "i_glad_empty": "the gladness she recites is shown to be empty",
    "i_discomfort": "the house's discomforts are real",
    "i_holds": "the room she complains about is also the place that holds her",
    "i_physical": "the final gesture makes the reluctance physical",
    "i_habit": "the body keeps a habit the mind has tried to end",
    "i_unaccepted": "the passage suggests a loss the narrator has not accepted",
}

EV_P3 = ["ev_teeth", "ev_knocked", "ev_told", "ev_amen", "ev_twice", "ev_thinner",
         "ev_stairs", "ev_palms", "ev_click", "ev_handle"]

# The specialist's own chain from supporting claims p3-s02 to p3-s10.
LINKS = [
    ("lk-injured", IMP(V("ev_teeth"), V("i_injured")), "the simile makes the bare shelves an injured body"),
    ("lk-blow", IMP(V("ev_knocked"), V("i_blow")), "'knocked out' implies a blow"),
    ("lk-imposed", IMP(AND(V("i_injured"), V("i_blow")), V("i_imposed")),
     "so the loss suggests something imposed on the narrator rather than chosen by her"),
    ("lk-notfelt", IMP(V("ev_told"), V("i_not_felt")),
     "her gladness is something she told herself, not something she feels"),
    ("lk-echo", IMP(V("ev_thinner"), V("i_echo")),
     "the personification turns her words into an echo with less substance"),
    ("lk-amen", IMP(V("ev_amen"), V("i_amen_flat")),
     "the amenities describe the flat rather than her response"),
    ("lk-glad", IMP(AND(V("i_echo"), V("i_amen_flat")), V("i_glad_empty")),
     "so the gladness she recites is shown to be empty"),
    ("lk-discomfort", IMP(V("ev_stairs"), V("i_discomfort")), "the house's discomforts are real"),
    ("lk-holds", IMP(V("ev_palms"), V("i_holds")),
     "the room she complains about is also the place that holds her"),
    ("lk-physical", IMP(AND(V("ev_click"), V("ev_handle")), V("i_physical")),
     "the final gesture makes the reluctance physical"),
    ("as-habit", V("i_habit"), "the body keeps a habit the mind has tried to end (asserted, no cited link)"),
    ("lk-unaccepted", IMP(V("i_habit"), V("i_unaccepted")),
     "so the passage suggests a loss the narrator has not accepted"),
]

NARR_RELUCTANT = "the narrator's feelings about leaving home are reluctance rather than relief"
HOUSE_VISIBLE = "the emptying house makes that reluctance visible"


def lit_chain(p, ev_names):
    for n in ev_names:
        meaning, excerpt = EVQ[n]
        p.sym(n, "Bool", f"the text presents: {meaning}", GQ(LIT_DOC, excerpt))
    for n, meaning in INTERP.items():
        p.sym(n, "Bool", meaning, GK("specialist_inference", "probable"))
    for n in ev_names:
        _, excerpt = EVQ[n]
        p.prem(n.replace("_", "-"), V(n), f'the text reads "{excerpt}"', GQ(LIT_DOC, excerpt))
    for pid, expr, label in LINKS:
        p.prem(pid, expr, label, GK("specialist_inference", "probable"))


def lit_p3_point():
    p = Prob("lit-p3-point", REQ_LIT, "p3-point")
    lit_chain(p, EV_P3)
    p.sym("narr_reluctant", "Bool", NARR_RELUCTANT, GK("specialist_inference", "probable"))
    p.sym("house_visible", "Bool", HOUSE_VISIBLE, GK("specialist_inference", "probable"))
    p.concl("concl-p3-point", AND(V("narr_reluctant"), V("house_visible")),
            "Marlowe presents the narrator's feelings about leaving home as reluctance rather "
            "than relief, and the emptying house makes that reluctance visible.",
            GK("specialist_inference", "probable"))
    flags = [{
        "code": "MISSING_STEP",
        "message": ("The chain ends at a loss the narrator has not accepted (i_unaccepted). "
                    "No written step links that to reluctance rather than relief, and no step "
                    "links the emptied house to visible reluctance. The final gesture is linked "
                    "only to physical reluctance."),
        "alternatives": [
            "Reluctance is read as the same thing as an unaccepted loss, so a further step "
            "links them (not encoded here).",
            "The report makes no such step, so the point is left without support in the chain "
            "(encoded as written).",
        ],
    }]
    reading = ("Evidence atoms are verbatim quotations from the extract; each interpretive step "
               "the report makes is a specialist_inference link at its stated 'probable' "
               "certainty. The conclusion is the point as written: reluctance rather than relief, "
               "and the emptying house making it visible. Steps the report does not make are not "
               "added, so the check should report the missing link to the reluctance and house parts.")
    return claim_obj(p.p, reading, ambiguous=True, flags=flags)


def lit_sup_premises(p):
    p.prem("sup-p2", AND(V("narr_reluctant"), V("i_unaccepted")),
           "p2-point: reluctance rather than relief, suggested by a loss she has not accepted",
           GK("specialist_inference", "probable"), materiality="supporting")
    p.prem("sup-p3", AND(V("narr_reluctant"), V("house_visible")),
           "p3-point: reluctance rather than relief, made visible by the emptying house",
           GK("specialist_inference", "probable"), materiality="supporting")


def lit_p1_s01():
    p = Prob("lit-p1-s01", REQ_LIT, "p1-s01")
    lit_chain(p, EV_P3)
    p.sym("narr_reluctant", "Bool", NARR_RELUCTANT, GK("specialist_inference", "probable"))
    p.sym("house_visible", "Bool", HOUSE_VISIBLE, GK("specialist_inference", "probable"))
    p.sym("narr_relieved", "Bool", "the narrator is relieved to leave the house",
          GK("specialist_inference", "probable"))
    p.sym("narr_forward", "Bool", "the narrator is looking forward to the new flat",
          GK("specialist_inference", "probable"))
    p.sym("stu_because_old", "Bool",
          "the student's causal claim: she is relieved because the house was old and uncomfortable",
          GK("specialist_inference", "probable"))
    lit_sup_premises(p)
    p.prem("lk-rel", IMP(V("narr_reluctant"), NOT(V("narr_relieved"))),
           "reluctance rather than relief: she is not relieved", GK("specialist_inference", "probable"))
    p.concl("concl-p1-s01",
            NOT(AND(V("narr_relieved"), V("stu_because_old"), V("narr_forward"))),
            "Your thesis does not survive the extract: it is not the case that she is relieved "
            "to leave because the house was old and she is looking forward to the flat.",
            GK("specialist_inference", "probable"))
    flags = [{
        "code": "SCOPE_OF_SURVIVE",
        "message": "'does not survive the extract' can mean the extract contradicts the thesis, "
                   "or only that the extract does not support it.",
        "alternatives": [
            "The extract contradicts the thesis: its negation follows (encoded).",
            "The extract does not support the thesis: a weaker claim, not encoded as a negation.",
        ],
    }]
    reading = ("The student's thesis is three conjuncts: relieved, relief because the house was old, "
               "and looking forward to the flat. The specialist's supporting claims (p2-point, p3-point) "
               "and its 'rather than' contrast give 'not relieved', which refutes the conjunction. The "
               "claim is encoded as the negation of the student's thesis.")
    return claim_obj(p.p, reading, ambiguous=True, flags=flags)


def lit_p1_s02():
    p = Prob("lit-p1-s02", REQ_LIT, "p1-s02")
    lit_chain(p, EV_P3)
    p.sym("narr_reluctant", "Bool", NARR_RELUCTANT, GK("specialist_inference", "probable"))
    p.sym("house_visible", "Bool", HOUSE_VISIBLE, GK("specialist_inference", "probable"))
    p.sym("narr_relieved", "Bool", "the narrator is relieved to leave the house",
          GK("specialist_inference", "probable"))
    p.sym("narr_forward", "Bool", "the narrator is looking forward to the new flat",
          GK("specialist_inference", "probable"))
    p.sym("i_tells", "Bool", "she has to tell herself she is glad", GK("specialist_inference", "probable"))
    lit_sup_premises(p)
    p.prem("lk-tells", IMP(V("ev_told"), V("i_tells")),
           "she has to tell herself she is glad", GK("specialist_inference", "probable"))
    p.prem("lk-colon",
           IMP(AND(V("i_tells"), V("i_glad_empty")),
               AND(NOT(V("narr_relieved")), NOT(V("narr_forward")))),
           "she has to tell herself she is glad and her gladness does not hold: so she is not relieved "
           "and not looking forward to the flat",
           GK("specialist_inference", "probable"))
    p.concl("concl-p1-s02",
            AND(NOT(V("narr_relieved")), NOT(V("narr_forward")), V("i_tells"), V("i_glad_empty")),
            "The narrator is not relieved and is not looking forward to the flat: she has to tell "
            "herself she is glad, and the passage shows that her gladness does not hold.",
            GK("specialist_inference", "probable"))
    flags = [{
        "code": "COLON_RELATION",
        "message": "The colon may give the reason for 'not relieved' or only evidence for it.",
        "alternatives": [
            "Reason: her telling herself and the failed gladness make her not relieved (encoded).",
            "Evidence only: the same facts are shown but do not entail the negations.",
        ],
    }]
    reading = ("The claim has two parts. The conjunction of 'not relieved' and 'not looking forward' "
               "is encoded as the consequence of the specialist's colon explanation. The other two parts, "
               "that she tells herself she is glad and that the gladness does not hold, come from the "
               "quoted 'I told myself I was glad' and the p3 chain (device links on the amenities and "
               "'gave it back to me thinner').")
    return claim_obj(p.p, reading, ambiguous=True, flags=flags)


def lit_p1_s03():
    p = Prob("lit-p1-s03", REQ_LIT, "p1-s03")
    lit_chain(p, EV_P3 + ["ev_narrow"])
    p.sym("narr_reluctant", "Bool", NARR_RELUCTANT, GK("specialist_inference", "probable"))
    p.sym("house_visible", "Bool", HOUSE_VISIBLE, GK("specialist_inference", "probable"))
    p.sym("i_losing", "Bool", "the passage uses those discomforts to show what she is losing",
          GK("specialist_inference", "probable"))
    lit_sup_premises(p)
    p.prem("lk-losing", IMP(AND(V("i_discomfort"), V("i_holds")), V("i_losing")),
           "the passage uses those discomforts to show what she is losing",
           GK("specialist_inference", "probable"))
    p.concl("concl-p1-s03", AND(V("i_discomfort"), V("i_losing")),
            "Your point that the house is old and uncomfortable has some support, since the stairs "
            "groan and the bedroom is narrow, but the passage uses those discomforts to show what "
            "she is losing.",
            GK("specialist_inference", "probable"))
    flags = [{
        "code": "VAGUE_SUPPORT",
        "message": "'has some support' gives no degree; it is encoded as the discomforts being real, "
                   "not as partial support.",
        "alternatives": ["Support means the discomfort is real (encoded).",
                         "Support is partial, so the discomfort is only weakly grounded."],
    }]
    reading = ("The claim has two parts: the house's discomforts are real (quoted stairs and the "
               "narrow bedroom) and the passage uses them to show what she is losing (the link from "
               "the discomforts and the room that holds her to loss). The second link is the specialist's "
               "own reading.")
    return claim_obj(p.p, reading, ambiguous=True, flags=flags)


# =========================================================================== #
# cs-e1 (Computer Science), document doc-binary-search
# =========================================================================== #
REQ_CS = CLAIMS_CS["request_id"]
BITS = {7: 1, 6: 0, 5: 1, 4: 1, 3: 0, 2: 1, 1: 1, 0: 0}  # 1011 0110
Q1A = "question 1(a) gives the binary number 1011 0110"
TASK_BITS_G = GK("task_setting", note=Q1A)


def add_bits(p):
    for i in range(7, -1, -1):
        p.sym(f"bit{i}", "Bool", f"binary digit {i} (place value {2 ** i}) of 1011 0110", TASK_BITS_G)
    for i in range(7, -1, -1):
        lit = V(f"bit{i}") if BITS[i] else NOT(V(f"bit{i}"))
        p.prem(f"bit{i}-value", lit, f"binary digit {i} of 1011 0110 is {BITS[i]}", TASK_BITS_G)


def den_expr():
    return ADD(*[ITE(V(f"bit{i}"), I(2 ** i), I(0)) for i in range(7, -1, -1)])


def rev_expr():
    return ADD(*[ITE(V(f"bit{i}"), I(2 ** (7 - i)), I(0)) for i in range(7, -1, -1)])


def hi_expr():
    return ADD(*[ITE(V(f"bit{i}"), I(2 ** (i - 4)), I(0)) for i in range(7, 3, -1)])


def lo_expr():
    return ADD(*[ITE(V(f"bit{i}"), I(2 ** i), I(0)) for i in range(3, -1, -1)])


PLACE_G = GK("general_knowledge", note="binary place values")
GROUP_G = GK("general_knowledge", note="grouping bits in fours from the right gives hexadecimal digits")
SPEC_EST = GK("specialist_inference", "established")


def c1_2():
    p = Prob("cs-c1-2-denary", REQ_CS, "c1.2")
    add_bits(p)
    p.sym("bin_denary", "Int", "denary value of 1011 0110", GK("arithmetic_fact", note="computed from the task's digits"))
    p.prem("den-def", EQ(V("bin_denary"), den_expr()),
           "denary value is the sum of place values of the 1 digits", PLACE_G)
    p.concl("concl-c1.2", EQ(V("bin_denary"), I(182)), "Denary: 182.", SPEC_EST)
    return claim_obj(p.p, "1011 0110 is encoded by its eight task-given digits; the denary value is the "
                          "place-value sum of the set digits; the claim is that the sum is 182.")


def c1_3():
    p = Prob("cs-c1-3-hex", REQ_CS, "c1.3")
    add_bits(p)
    p.sym("hex_hi", "Int", "value of the high nibble 1011 (hex digit)", GROUP_G)
    p.sym("hex_lo", "Int", "value of the low nibble 0110 (hex digit)", GROUP_G)
    p.sym("hex_b", "Int", "value of the hexadecimal digit B", GK("general_knowledge", note="hexadecimal B is 11"))
    p.prem("hex-b-value", EQ(V("hex_b"), I(11)), "hexadecimal digit B stands for 11", GK("general_knowledge"))
    p.prem("hi-def", EQ(V("hex_hi"), hi_expr()), "high nibble 1011 has value 11", GROUP_G)
    p.prem("lo-def", EQ(V("hex_lo"), lo_expr()), "low nibble 0110 has value 6", GROUP_G)
    p.concl("concl-c1.3", AND(EQ(V("hex_hi"), V("hex_b")), EQ(V("hex_lo"), I(6))),
            "Hexadecimal: B6 (high digit B, low digit 6).", SPEC_EST)
    return claim_obj(p.p, "Each nibble of 1011 0110 is evaluated from its digits; B is 11 and the low "
                          "nibble is 6, so the hexadecimal form is B6.")


def c2_1():
    p = Prob("cs-c2-1-working", REQ_CS, "c2.1")
    add_bits(p)
    p.sym("pv_sum", "Int", "sum of place values of the 1 digits of 1011 0110", GK("arithmetic_fact"))
    p.prem("pv-def", EQ(V("pv_sum"), den_expr()),
           "the 1 digits sit at place values 128, 32, 16, 4 and 2", PLACE_G)
    p.concl("concl-c2.1",
            AND(EQ(V("pv_sum"), I(182)),
                EQ(ADD(I(128), I(32), I(16), I(4), I(2)), V("pv_sum"))),
            "Working: the 1 bits have place values 128, 32, 16, 4 and 2, so 128 + 32 + 16 + 4 + 2 = 182.",
            SPEC_EST)
    return claim_obj(p.p, "The working lists the place values of the 1 digits of 1011 0110 and their "
                          "sum; both the place-value list and the sum are encoded.")


def c2_2():
    p = Prob("cs-c2-2-grouping", REQ_CS, "c2.2")
    add_bits(p)
    p.sym("hex_hi", "Int", "value of the high nibble 1011 (hex digit)", GROUP_G)
    p.sym("hex_lo", "Int", "value of the low nibble 0110 (hex digit)", GROUP_G)
    p.sym("hex_b", "Int", "value of the hexadecimal digit B", GK("general_knowledge", note="hexadecimal B is 11"))
    p.prem("hex-b-value", EQ(V("hex_b"), I(11)), "hexadecimal digit B stands for 11", GK("general_knowledge"))
    p.prem("hi-def", EQ(V("hex_hi"), hi_expr()), "grouping in fours: 1011 has value 11", GROUP_G)
    p.prem("lo-def", EQ(V("hex_lo"), lo_expr()), "grouping in fours: 0110 has value 6", GROUP_G)
    p.concl("concl-c2.2", AND(EQ(V("hex_hi"), V("hex_b")), EQ(V("hex_lo"), I(6))),
            "Grouping the bits in fours from the right, 1011 is B and 0110 is 6, so 1011 0110 = B6 "
            "in hexadecimal.", SPEC_EST)
    return claim_obj(p.p, "The byte is split into two nibbles from the right; 1011 is B and 0110 is 6. "
                          "The hexadecimal form B6 is encoded as those two digit values.")


def c3_1():
    p = Prob("cs-c3-1-correct", REQ_CS, "c3.1")
    add_bits(p)
    p.sym("bin_denary", "Int", "denary value of 1011 0110", GK("arithmetic_fact"))
    p.prem("den-def", EQ(V("bin_denary"), den_expr()),
           "denary value is the sum of place values of the 1 digits", PLACE_G)
    p.sym("stu_ans", "Int", "the student's denary answer to 1(a)", GK("task_setting", note="'I got 182' in the question"))
    p.prem("stu-ans", EQ(V("stu_ans"), I(182)), "the student's answer is 182",
           GK("task_setting", note="'I got 182' in the question"))
    p.sym("rev_val", "Int", "value of the eight digits read in reverse order", GK("arithmetic_fact"))
    p.prem("rev-def", EQ(V("rev_val"), rev_expr()),
           "reversed reading of the digits (supporting claim c3.2)", GK("arithmetic_fact", note="computed from task digits"),
           materiality="supporting")
    p.prem("sup-c3-2", EQ(V("rev_val"), I(109)),
           "109 is the value of the reversed digits (supporting claim c3.2)", SPEC_EST,
           materiality="supporting")
    p.concl("concl-c3.1", EQ(V("bin_denary"), V("stu_ans")), "Your 182 is correct.", SPEC_EST)
    return claim_obj(p.p, "The student's 182 is compared with the denary value of 1011 0110. The "
                          "supporting claim about the reversed reading (109) is encoded as a supporting premise.")


def c3_2():
    p = Prob("cs-c3-2-reversed", REQ_CS, "c3.2")
    add_bits(p)
    p.sym("rev_val", "Int", "value of the eight digits read in reverse order", GK("arithmetic_fact"))
    p.sym("cause_wrong_end", "Bool", "a likely cause is reading the place values from the wrong end",
          GK("specialist_inference", "probable"))
    p.prem("rev-def", EQ(V("rev_val"), rev_expr()),
           "reversed reading of the digits 0110 1101", GK("arithmetic_fact", note="computed from task digits"))
    p.prem("cause-link", IMP(EQ(V("rev_val"), I(109)), V("cause_wrong_end")),
           "so a likely cause is reading the place values from the wrong end",
           GK("specialist_inference", "probable"))
    p.concl("concl-c3.2", AND(EQ(V("rev_val"), I(109)), V("cause_wrong_end")),
            "109 is the value of the same eight digits read in reverse (0110 1101 = 109), so a likely "
            "cause is reading the place values from the wrong end.",
            GK("specialist_inference", "probable"))
    return claim_obj(p.p, "The reversed reading 0110 1101 is computed from the digits and equals 109. The "
                          "'likely cause' step is the specialist's link, encoded at the stated 'probable' "
                          "certainty (the claim's field says established, but the text says likely).")


def c4_2():
    p = Prob("cs-c4-2-values", REQ_CS, "c4.2")
    p.sym("n_vals", "Int", "number of different values twelve bits can represent", GK("general_knowledge"))
    p.prem("pow2-12", EQ(V("n_vals"), MUL(*[I(2)] * 12)),
           "2 to the power 12 written as twelve factors of 2", GK("general_knowledge", note="2^n values for n bits, n = 12"))
    p.concl("concl-c4.2", EQ(V("n_vals"), I(4096)), "4096 (2^12).", SPEC_EST)
    return claim_obj(p.p, "Twelve bits give 2^12 distinct values; the claim 4096 is checked against that count.")


def c4_3():
    p = Prob("cs-c4-3-range", REQ_CS, "c4.3")
    p.sym("n_vals", "Int", "number of different values twelve bits can represent", GK("general_knowledge"))
    p.prem("pow2-12", EQ(V("n_vals"), MUL(*[I(2)] * 12)),
           "2 to the power 12 written as twelve factors of 2", GK("general_knowledge"))
    p.sym("unsigned", "Bool", "the bits are taken as unsigned", GK("assumption"))
    p.sym("min_val", "Int", "smallest unsigned value of twelve bits", GK("general_knowledge"))
    p.sym("max_val", "Int", "largest unsigned value of twelve bits", GK("general_knowledge"))
    p.prem("unsigned-assumed", V("unsigned"), "the bits are taken as unsigned",
           GK("assumption", note="'Taking the bits as unsigned' in the claim"))
    p.prem("unsigned-min", IMP(V("unsigned"), EQ(V("min_val"), I(0))),
           "as unsigned, the smallest value is 0", GK("general_knowledge"))
    p.prem("unsigned-max", IMP(V("unsigned"), EQ(V("max_val"), SUB(V("n_vals"), I(1)))),
           "as unsigned, the largest value is one less than the number of values", GK("general_knowledge"))
    p.concl("concl-c4.3", AND(EQ(V("min_val"), I(0)), EQ(V("max_val"), I(4095))),
            "Taking the bits as unsigned, 12 bits represent 0 to 4095.", SPEC_EST)
    return claim_obj(p.p, "The unsigned reading is an explicit assumption; the range 0 to 4095 is one less "
                          "than the 4096 values.")


def c5_1():
    return null_obj("The claim is the question-part label '1(c)' with no assertion of its own.",
                    "Question-part label '1(c)' with no assertion to check; nothing to encode.")


def lit_row(name, v):
    return V(name) if v else NOT(V(name))


def tt_claim(cid, text):
    k = cid.split(".")[1]
    pre = f"tt{k}"
    vals = [int(x) for x in re.findall(r"(?<![\w.])[01](?![\w.])", text)]
    assert len(vals) == 7, (cid, text, vals)
    a, b, c, ab, na, nac, x = vals
    names = ["a", "b", "c", "ab", "na", "nac", "x"]
    meanings = {
        "a": "input A in this row", "b": "input B in this row", "c": "input C in this row",
        "ab": "column A AND B in this row", "na": "column NOT A in this row",
        "nac": "column NOT A AND C in this row",
        "x": "column X = (A AND B) OR (NOT A AND C) in this row",
    }
    p = Prob(f"cs-c6-{k}-row", REQ_CS, cid)
    for n in names:
        p.sym(f"{pre}_{n}", "Bool", meanings[n], GK("task_setting", note="question 1(c) truth table"))
    A, Bv, C = V(f"{pre}_a"), V(f"{pre}_b"), V(f"{pre}_c")
    AB, NA, NAC, X = V(f"{pre}_ab"), V(f"{pre}_na"), V(f"{pre}_nac"), V(f"{pre}_x")
    row_g = GK("task_setting", note="truth table row: input enumeration for the three inputs")
    p.prem(f"{pre}-in-a", lit_row(f"{pre}_a", a), f"A is {a} in this row", row_g)
    p.prem(f"{pre}-in-b", lit_row(f"{pre}_b", b), f"B is {b} in this row", row_g)
    p.prem(f"{pre}-in-c", lit_row(f"{pre}_c", c), f"C is {c} in this row", row_g)
    formula_g = GK("task_setting", note="X = (A AND B) OR (NOT A AND C), question 1(c)")
    p.prem(f"{pre}-def-ab", IFF(AB, AND(A, Bv)), "column A AND B is A and B", formula_g)
    p.prem(f"{pre}-def-na", IFF(NA, NOT(A)), "column NOT A is the negation of A", formula_g)
    p.prem(f"{pre}-def-nac", IFF(NAC, AND(NA, C)), "column NOT A AND C is NOT A and C", formula_g)
    p.prem(f"{pre}-def-x", IFF(X, OR(AB, NAC)), "column X is (A AND B) or (NOT A AND C)", formula_g)
    concl = AND(lit_row(f"{pre}_a", a), lit_row(f"{pre}_b", b), lit_row(f"{pre}_c", c),
                lit_row(f"{pre}_ab", ab), lit_row(f"{pre}_na", na), lit_row(f"{pre}_nac", nac),
                lit_row(f"{pre}_x", x))
    label = (f"row A={a}, B={b}, C={c}: A AND B={ab}, NOT A={na}, NOT A AND C={nac}, X={x}")
    p.concl(f"concl-{cid}", concl, label, SPEC_EST)
    return claim_obj(p.p, f"One truth-table row for X = (A AND B) OR (NOT A AND C). The row inputs and the "
                          f"four column definitions are encoded; the row's stated values are the conclusion.")


def c7_2():
    p = Prob("cs-c7-2-algebra", REQ_CS, "c7.2")
    p.sym("alg_a", "Bool", "Boolean variable A", GK("task_setting", note="question 1(d)"))
    p.sym("alg_b", "Bool", "Boolean variable B", GK("task_setting", note="question 1(d)"))
    A, Bv = V("alg_a"), V("alg_b")
    lhs = OR(AND(A, Bv), AND(A, NOT(Bv)))
    p.prem("law-distrib", IFF(lhs, AND(A, OR(Bv, NOT(Bv)))),
           "step 1: A·B + A·NOT B = A·(B + NOT B) by the distributive law",
           GK("general_knowledge", note="distributive law"))
    p.prem("law-compl", IFF(OR(Bv, NOT(Bv)), B(True)),
           "step 2: B + NOT B = 1 by the complement law", GK("general_knowledge", note="complement law"))
    p.prem("law-ident", IFF(AND(A, B(True)), A),
           "step 3: A·1 = A by the identity law", GK("general_knowledge", note="identity law"))
    p.concl("concl-c7.2", IFF(lhs, A), "A·B + A·NOT B = A", SPEC_EST)
    return claim_obj(p.p, "Each algebra step is encoded as a Boolean law premise; the conclusion is the "
                          "equivalence of the left-hand side with A.")


# ---- binary search traces (target 30 and target 9 on the supplied list; unsorted example) ----
ELEMS_SORTED = [I(v) for v in SORTED]
TGT_SORTED_G = {30: GK("task_setting", note="call binary_search(scores, 30), question 2(a)"),
                9: GK("task_setting", note="call binary_search(scores, 9), question 2(b)")}
LEN_SORTED_G = GK("arithmetic_fact", doc=CODE, excerpt=SCORES_LINE, note="count of the nine list entries")
ELEM_SORTED_G = GK("supplied_text", doc=CODE, excerpt=SCORES_LINE,
                   note="items[mid] reads the list defined in the supplied code")


def lookup(mid_name, elems):
    expr = elems[-1]
    for idx in range(len(elems) - 2, -1, -1):
        expr = ITE(EQ(V(mid_name), I(idx)), elems[idx], expr)
    return expr


def add_trace(p, pre, tgt_val, elems, K, tgt_g, len_name, len_val, len_g, elem_g):
    tgt = f"{pre}_tgt"
    p.sym(tgt, "Int", f"search target of the {pre} call", tgt_g)
    p.prem(f"{pre}-tgt", EQ(V(tgt), I(tgt_val)), f"the search target is {tgt_val}", tgt_g)
    p.sym(len_name, "Int", "number of items in the list", len_g)
    p.prem(f"{pre}-len", EQ(V(len_name), I(len_val)), f"the list has {len_val} items", len_g)
    p.sym(f"{pre}_lo0", "Int", "low before pass 1")
    p.sym(f"{pre}_hi0", "Int", "high before pass 1")
    p.sym(f"{pre}_st0", "Int", "steps before pass 1")
    p.prem(f"{pre}-lo0", EQ(V(f"{pre}_lo0"), I(0)), "low starts at 0", GQ(CODE, "low = 0"))
    p.prem(f"{pre}-hi0", EQ(V(f"{pre}_hi0"), SUB(V(len_name), I(1))),
           "high starts at the length minus 1", GQ(CODE, "high = len(items) - 1"))
    p.prem(f"{pre}-st0", EQ(V(f"{pre}_st0"), I(0)), "steps starts at 0", GQ(CODE, "steps = 0"))
    if K == 0:
        return
    p.sym(f"{pre}_retidx", "Int", "index returned by the call")
    p.sym(f"{pre}_retst", "Int", "steps returned by the call")
    for k in range(1, K + 1):
        lo_p, hi_p, st_p = f"{pre}_lo{k - 1}", f"{pre}_hi{k - 1}", f"{pre}_st{k - 1}"
        mid, it, st = f"{pre}_mid{k}", f"{pre}_it{k}", f"{pre}_st{k}"
        lo, hi = f"{pre}_lo{k}", f"{pre}_hi{k}"
        p.sym(mid, "Int", f"mid index in pass {k}")
        p.sym(it, "Int", f"items[mid] in pass {k}")
        p.sym(st, "Int", f"steps after pass {k}")
        p.sym(lo, "Int", f"low after pass {k}")
        p.sym(hi, "Int", f"high after pass {k}")
        p.prem(f"{pre}-mid{k}", EQ(V(mid), IDIV(ADD(V(lo_p), V(hi_p)), I(2))),
               f"pass {k}: mid = (low + high) // 2", GQ(CODE, "mid = (low + high) // 2"))
        p.prem(f"{pre}-it{k}", EQ(V(it), lookup(mid, elems)),
               f"pass {k}: items[mid] is the list entry at index mid", elem_g)
        p.prem(f"{pre}-st{k}", EQ(V(st), ADD(V(st_p), I(1))),
               f"pass {k}: steps rises by one", GQ(CODE, "steps = steps + 1"))
        p.prem(f"{pre}-lo{k}", EQ(V(lo), ITE(LT(V(it), V(tgt)), ADD(V(mid), I(1)), V(lo_p))),
               f"pass {k}: low = mid + 1 when items[mid] < target, else unchanged",
               GQ(CODE, "low = mid + 1"))
        p.prem(f"{pre}-hi{k}", EQ(V(hi), ITE(GT(V(it), V(tgt)), SUB(V(mid), I(1)), V(hi_p))),
               f"pass {k}: high = mid - 1 when items[mid] > target, else unchanged",
               GQ(CODE, "high = mid - 1"))
        p.prem(f"{pre}-found{k}",
               IMP(EQ(V(it), V(tgt)), AND(EQ(V(f"{pre}_retidx"), V(mid)), EQ(V(f"{pre}_retst"), V(st)))),
               f"pass {k}: when items[mid] equals the target the call returns mid and steps",
               GQ(CODE, "return mid, steps"))
    lo_k, hi_k, st_k = f"{pre}_lo{K}", f"{pre}_hi{K}", f"{pre}_st{K}"
    p.prem(f"{pre}-exit",
           IMP(GT(V(lo_k), V(hi_k)), AND(EQ(V(f"{pre}_retidx"), I(-1)), EQ(V(f"{pre}_retst"), V(st_k)))),
           "when low > high the loop ends and the call returns -1 and the steps count",
           GQ(CODE, "return -1, steps"))


def trace_claim(prob_id, cid, pre_tgt, K, concl_expr, concl_label, reading):
    p = Prob(prob_id, REQ_CS, cid)
    add_trace(p, pre_tgt[0], pre_tgt[1], ELEMS_SORTED, K, TGT_SORTED_G[pre_tgt[1]],
              "sc_len", 9, LEN_SORTED_G, ELEM_SORTED_G)
    p.concl(f"concl-{cid}", concl_expr, concl_label, SPEC_EST)
    return claim_obj(p.p, reading)


def c8_2():
    return trace_claim("cs-c8-2-prints", "c8.2", ("t30", 30), 2,
                       AND(EQ(V("t30_retidx"), I(6)), EQ(V("t30_retst"), I(2))),
                       "The call prints (6, 2).",
                       "The trace of binary_search(scores, 30) runs two passes: mid 4 then mid 6, where items[6] = 30 "
                       "returns (6, 2). The output is encoded from the code's own update rules.")


def c11_2():
    return trace_claim("cs-c11-2-start", "c11.2", ("t30", 30), 0,
                       AND(EQ(V("t30_lo0"), I(0)), EQ(V("t30_hi0"), I(8)), EQ(V("t30_st0"), I(0))),
                       "start | 0 | 8 | | 0 (low, high, steps before the first pass)",
                       "Initial state of the trace: low 0, high 8 (len 9 minus 1), steps 0.")


def c11_3():
    return trace_claim("cs-c11-3-pass1", "c11.3", ("t30", 30), 1,
                       AND(EQ(V("t30_lo1"), I(5)), EQ(V("t30_hi1"), I(8)), EQ(V("t30_mid1"), I(4)),
                           EQ(V("t30_st1"), I(1)), EQ(V("t30_it1"), I(21)),
                           LE(V("t30_lo0"), V("t30_hi0")), NE(V("t30_it1"), V("t30_tgt")),
                           LT(V("t30_it1"), V("t30_tgt"))),
                       "Pass 1: low 5, high 8, mid 4, steps 1, items[mid] 21; 0 <= 8 yes; 21 == 30 no; "
                       "21 < 30 yes, so low = 5.",
                       "Pass 1 of the target-30 trace: mid is 4 and items[4] is 21, which is below 30, so low moves to 5.")


def c11_4():
    return trace_claim("cs-c11-4-pass2", "c11.4", ("t30", 30), 2,
                       AND(EQ(V("t30_lo2"), I(5)), EQ(V("t30_hi2"), I(8)), EQ(V("t30_mid2"), I(6)),
                           EQ(V("t30_st2"), I(2)), EQ(V("t30_it2"), V("t30_tgt")),
                           LE(V("t30_lo1"), V("t30_hi1")),
                           EQ(V("t30_retidx"), V("t30_mid2")), EQ(V("t30_retst"), V("t30_st2"))),
                       "Pass 2: low 5, high 8, mid 6, steps 2, items[mid] 30; 5 <= 8 yes; 30 == 30 yes, so return (6, 2).",
                       "Pass 2 of the target-30 trace: mid is 6 and items[6] equals 30, so the call returns (6, 2).")


def c12_2():
    p = Prob("cs-c12-2-prints", REQ_CS, "c12.2")
    add_trace(p, "t9", 9, ELEMS_SORTED, 3, TGT_SORTED_G[9], "sc_len", 9, LEN_SORTED_G, ELEM_SORTED_G)
    p.concl("concl-c12.2",
            AND(EQ(V("t9_retidx"), I(-1)), EQ(V("t9_retst"), I(3)), NOT(LE(V("t9_lo3"), V("t9_hi3"))),
                NE(V("t9_it1"), V("t9_tgt")), NE(V("t9_it2"), V("t9_tgt")), NE(V("t9_it3"), V("t9_tgt"))),
            "The call prints (-1, 3).", SPEC_EST)
    return claim_obj(p.p, "The target-9 trace runs three passes with no match, then the loop test "
                          "2 <= 1 fails and the call returns (-1, 3).")


def c12_3():
    p = Prob("cs-c12-3-count", REQ_CS, "c12.3")
    add_trace(p, "t9", 9, ELEMS_SORTED, 3, TGT_SORTED_G[9], "sc_len", 9, LEN_SORTED_G, ELEM_SORTED_G)
    p.concl("concl-c12.3",
            AND(EQ(V("t9_retidx"), I(-1)), EQ(V("t9_st3"), I(3)), NE(V("t9_st3"), I(4)),
                NOT(LE(V("t9_lo3"), V("t9_hi3"))),
                EQ(V("t9_st3"), ADD(V("t9_st0"), I(1), I(1), I(1)))),
            "Your -1 is right, but the count is 3, not 4: steps rises by one for each pass through the loop "
            "body, and the final test (2 <= 1) fails before the body runs.",
            SPEC_EST)
    return claim_obj(p.p, "The student's -1 is checked, and the steps count is checked against three increments "
                          "and the final loop test.")


def c14_2():
    return trace_claim("cs-c14-2-start", "c14.2", ("t9", 9), 0,
                       AND(EQ(V("t9_lo0"), I(0)), EQ(V("t9_hi0"), I(8)), EQ(V("t9_st0"), I(0))),
                       "start | 0 | 8 | | 0 (low, high, steps before the first pass)",
                       "Initial state of the target-9 trace: low 0, high 8, steps 0.")


def c14_3():
    return trace_claim("cs-c14-3-pass1", "c14.3", ("t9", 9), 1,
                       AND(EQ(V("t9_lo1"), I(0)), EQ(V("t9_hi1"), I(3)), EQ(V("t9_mid1"), I(4)),
                           EQ(V("t9_st1"), I(1)), EQ(V("t9_it1"), I(21)),
                           LE(V("t9_lo0"), V("t9_hi0")), NE(V("t9_it1"), V("t9_tgt")),
                           NOT(LT(V("t9_it1"), V("t9_tgt")))),
                       "Pass 1: low 0, high 3, mid 4, steps 1, items[mid] 21; 0 <= 8 yes; 21 == 9 no; "
                       "21 < 9 no, so high = 3.",
                       "Pass 1 of the target-9 trace: items[4] is 21, above 9, so high moves to 3.")


def c14_4():
    return trace_claim("cs-c14-4-pass2", "c14.4", ("t9", 9), 2,
                       AND(EQ(V("t9_lo2"), I(2)), EQ(V("t9_hi2"), I(3)), EQ(V("t9_mid2"), I(1)),
                           EQ(V("t9_st2"), I(2)), EQ(V("t9_it2"), I(8)),
                           LE(V("t9_lo1"), V("t9_hi1")), NE(V("t9_it2"), V("t9_tgt")),
                           LT(V("t9_it2"), V("t9_tgt"))),
                       "Pass 2: low 2, high 3, mid 1, steps 2, items[mid] 8; 0 <= 3 yes; 8 == 9 no; "
                       "8 < 9 yes, so low = 2.",
                       "Pass 2 of the target-9 trace: items[1] is 8, below 9, so low moves to 2.")


def c14_5():
    return trace_claim("cs-c14-5-pass3", "c14.5", ("t9", 9), 3,
                       AND(EQ(V("t9_lo3"), I(2)), EQ(V("t9_hi3"), I(1)), EQ(V("t9_mid3"), I(2)),
                           EQ(V("t9_st3"), I(3)), EQ(V("t9_it3"), I(12)),
                           LE(V("t9_lo2"), V("t9_hi2")), NE(V("t9_it3"), V("t9_tgt")),
                           NOT(LT(V("t9_it3"), V("t9_tgt")))),
                       "Pass 3: low 2, high 1, mid 2, steps 3, items[mid] 12; 2 <= 3 yes; 12 == 9 no; "
                       "12 < 9 no, so high = 1.",
                       "Pass 3 of the target-9 trace: items[2] is 12, above 9, so high moves to 1.")


def c14_6():
    return trace_claim("cs-c14-6-exit", "c14.6", ("t9", 9), 3,
                       AND(EQ(V("t9_lo3"), I(2)), EQ(V("t9_hi3"), I(1)), EQ(V("t9_st3"), I(3)),
                           NOT(LE(V("t9_lo3"), V("t9_hi3"))),
                           EQ(V("t9_retidx"), I(-1)), EQ(V("t9_retst"), I(3))),
                       "exit | 2 | 1 | | 3 | | 2 <= 1 no, so the loop ends and returns | (-1, 3)",
                       "Exit row of the target-9 trace: the loop test 2 <= 1 fails and the call returns (-1, 3).")


def add_list(p, vals):
    names = ["u_e0", "u_e1", "u_e2"]
    for i, (n, v) in enumerate(zip(names, vals)):
        p.sym(n, "Int", f"value at index {i} of the claim's example list", GK("assumption"))
        p.prem(f"u-e{i}", EQ(V(n), I(v)), f"the example list has {v} at index {i}",
               GK("assumption", note="the specialist's own example list [9, 3, 8], not in the supplied code"))
    return [V(n) for n in names]


UNSORTED_TGT_G = GK("assumption", note="target 9 from the claim's own example")
UNSORTED_LEN_G = GK("arithmetic_fact", note="count of the three entries in the claim's own example list")
UNSORTED_ELEM_G = GK("assumption", note="items[mid] reads the claim's own example list")


def c15_5():
    p = Prob("cs-c15-5-discard", REQ_CS, "c15.5")
    elems = add_list(p, [9, 3, 8])
    add_trace(p, "u", 9, elems, 1, UNSORTED_TGT_G, "u_len", 3, UNSORTED_LEN_G, UNSORTED_ELEM_G)
    p.concl("concl-c15.5",
            AND(EQ(V("u_mid1"), I(1)), LT(V("u_it1"), V("u_tgt")), EQ(V("u_lo1"), I(2)),
                GT(V("u_lo1"), I(0)), EQ(V("u_e0"), I(9))),
            "For [9, 3, 8] and target 9, mid is 1 and 3 < 9, so index 0, which holds 9, is discarded.",
            SPEC_EST)
    return claim_obj(p.p, "The specialist's counterexample list [9, 3, 8] is an explicit assumption. The first pass "
                          "is checked, and index 0 is discarded when low moves past it.")


def c15_6():
    p = Prob("cs-c15-6-returns", REQ_CS, "c15.6")
    elems = add_list(p, [9, 3, 8])
    add_trace(p, "u", 9, elems, 2, UNSORTED_TGT_G, "u_len", 3, UNSORTED_LEN_G, UNSORTED_ELEM_G)
    p.concl("concl-c15.6",
            AND(EQ(V("u_retidx"), I(-1)), EQ(V("u_retst"), I(2)),
                OR(EQ(V("u_e0"), I(9)), EQ(V("u_e1"), I(9)), EQ(V("u_e2"), I(9)))),
            "The call returns (-1, 2) although 9 is present.", SPEC_EST)
    return claim_obj(p.p, "Two passes on the unsorted example, then the loop ends and the call returns (-1, 2); "
                          "9 is present at index 0 of the example list.")


def c15_3():
    return null_obj("The claim is a general statement about every list position the search could visit "
                    "('every item up to mid is smaller than the target').",
                    "Universal claim over all list positions; IR 1.0 has no quantifiers, so the general "
                    "statement cannot be encoded without dropping part of its meaning. The concrete instance "
                    "is encoded in c15.5.")


def c9_2():
    return null_obj("The claim is the table row transcribing the supplied list [3, 8, 12, 17, 21, 26, 30, 35, 41].",
                    "Pure transcription of the supplied list: the only encoding restates the supplied text, "
                    "so there is no relation to check.")


CS_FUNCS = {
    "c1.2": c1_2, "c1.3": c1_3, "c2.1": c2_1, "c2.2": c2_2, "c3.1": c3_1, "c3.2": c3_2,
    "c4.2": c4_2, "c4.3": c4_3, "c5.1": c5_1, "c7.2": c7_2, "c8.2": c8_2, "c9.2": c9_2,
    "c11.2": c11_2, "c11.3": c11_3, "c11.4": c11_4, "c12.2": c12_2, "c12.3": c12_3,
    "c14.2": c14_2, "c14.3": c14_3, "c14.4": c14_4, "c14.5": c14_5, "c14.6": c14_6,
    "c15.3": c15_3, "c15.5": c15_5, "c15.6": c15_6,
}
for _cid in ("c6.2", "c6.3", "c6.4", "c6.5", "c6.6", "c6.7", "c6.8", "c6.9"):
    CS_FUNCS[_cid] = (lambda cid: (lambda: tt_claim(cid, CLAIM_TEXT_CS[cid])))(_cid)


def build_report(report, funcs, lit_mode=False):
    out = {}
    for c in report["claims"]:
        if not c["eligible"]:
            continue
        cid = c["claim_id"]
        out[cid] = funcs[cid]()
    return out


LIT_FUNCS = {
    "p3-point": lit_p3_point,
    "p1-s01": lit_p1_s01,
    "p1-s02": lit_p1_s02,
    "p1-s03": lit_p1_s03,
}


def write(task_id, report_id, claims):
    path = f"{OUT}/{task_id}.json"
    with open(path, "w", encoding="utf-8") as fh:
        json.dump({"report_id": report_id, "claims": claims}, fh, ensure_ascii=False, indent=2)
    return path


def main():
    lit_eligible = [c["claim_id"] for c in CLAIMS_LIT["claims"] if c["eligible"]]
    cs_eligible = [c["claim_id"] for c in CLAIMS_CS["claims"] if c["eligible"]]
    assert set(lit_eligible) == set(LIT_FUNCS), (lit_eligible, sorted(LIT_FUNCS))
    assert set(cs_eligible) == set(CS_FUNCS), (sorted(set(cs_eligible) ^ set(CS_FUNCS)))

    lit_claims = {cid: LIT_FUNCS[cid]() for cid in lit_eligible}
    cs_claims = {cid: CS_FUNCS[cid]() for cid in cs_eligible}
    p1 = write("lit-e1", CLAIMS_LIT["report_id"], lit_claims)
    p2 = write("cs-e1", CLAIMS_CS["report_id"], cs_claims)
    print("wrote", p1, len(lit_claims), "claims")
    print("wrote", p2, len(cs_claims), "claims")
    nulls = [k for k, v in cs_claims.items() if v["problem"] is None] + \
            [k for k, v in lit_claims.items() if v["problem"] is None]
    print("null problems:", nulls)


if __name__ == "__main__":
    main()
