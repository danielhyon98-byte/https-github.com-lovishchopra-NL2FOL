# End-to-end run 1: simulated student requests

What eight students typed into the website, exactly as submitted, with the documents they pasted. Six are single-subject questions that take the fast path (one specialist). Two ask about two subjects at once; the router splits each into two specialist tasks that share one hub task, and the second specialist answers only after the first one's delivered report has been relayed to it through the hub. That makes 10 routed tasks in `tasks.json`.

Every business, council and person named in the pasted documents is fictional, apart from the historical bread prices, which the student copied from a textbook table.

| # | Website request | Path | Routed task(s) |
| --- | --- | --- | --- |
| 1 | English A: Language and Literature, Paper 1 claim with pasted leaflet | fast path | `ll-e1` (english-a-lang-lit) |
| 2 | Business Management, case with figures | fast path | `bm-e1` (business-management) |
| 3 | Physics, kettle calculation | fast path | `ph-e1` (physics) |
| 4 | Mathematics AI, loan and normal distribution | fast path | `mai-e1` (mathematics-ai) |
| 5 | Biology, test cross and chi-squared | fast path | `bi-e1` (biology) |
| 6 | Spanish B, marking of the student's own writing | fast path | `sp-e1` (language-b-spanish) |
| 7 | Mathematics AA and History, 1923 hyperinflation (STEM and humanities) | cross-subject, group `e1a` | `maa-e1a` (mathematics-aa), then `hi-e1a` (history, peer of `maa-e1a`) |
| 8 | Chemistry and ESS, ocean acidification (STEM and STEM) | cross-subject, group `e1b` | `ch-e1b` (chemistry), then `ess-e1b` (ess, peer of `ch-e1b`) |

## Request 1: English A: Language and Literature

Routed as `ll-e1` (fast path, one specialist).

**Student's message**

```text
hi! I'm doing English A Lang and Lit HL (exams May 2027) and this is Paper 1 practice. Our teacher gave us this council leaflet about food waste, I've pasted it below. Guiding question: How does the leaflet try to change the way its readers behave? My claim is: the leaflet uses direct address and shocking statistics to make the reader feel personally responsible for food waste, and then makes the solution seem easy. Can you write ONE body paragraph that proves my claim, using exact quotes from the leaflet? Max 300 words please, I want to see what a level 7 paragraph looks like.
```

**Pasted document:** Love it? Don't bin it. (council leaflet, supplied text)

```text
LOVE IT? DON’T BIN IT.
A message from Kestrelford Borough Council

You wouldn’t throw a £10 note in the bin. So why are you throwing away food?

Every week, the average Kestrelford household bins 8 kg of food that could have been eaten. That’s a whole roast dinner, a loaf of bread and a bag of salad – every single week. Across the borough, it adds up to 14,000 tonnes a year.

It’s not just your money going in the bin. When food rots in landfill, it gives off methane, a gas that traps far more heat than carbon dioxide.

The good news? You can fix this in three small steps.

1. PLAN IT. Check your fridge before you shop. Write a list. Stick to it.
2. STORE IT. Keep bread in the freezer and salad in a sealed box. Your food will last days longer.
3. USE IT. Leftover rice? Make fried rice. Soft bananas? Banana bread.

“I used to clear out half the fridge every Sunday. Now I plan our meals on a Thursday and we hardly waste a thing.” – Amira, Kestrelford resident

Small changes. Big difference.

Start tonight: open your fridge and see what needs eating first.

Food you don’t waste is food you don’t buy. Save up to £60 a month.*

*Based on the average family of four.
```

## Request 2: Business Management

Routed as `bm-e1` (fast path, one specialist).

**Student's message**

```text
Business Management SL, exams May 2027. This is Paper 2 practice on the case from our worksheet (pasted below).
(a) Calculate the contribution per cake. [1]
(b) Calculate the break-even quantity per month. [2]
(c) Calculate the margin of safety in March and the profit Luma Bakes made in March. [3]
(d) Calculate the current ratio and the acid-test ratio on 31 March. [2]
(e) Explain one advantage and one disadvantage for Luma Bakes of taking the bank loan to open the second shop. [4]
For (b) I got 1,800 cakes but my friend got 3,000, which one is right?? Please show working, and keep (e) under 150 words.
```

**Pasted document:** Luma Bakes (case study from a class worksheet, supplied text)

```text
Luma Bakes

Inés Duarte opened Luma Bakes, a small bakery selling cakes from a shop in the town centre, in 2023. She sells each cake for $4.50. Ingredients, packaging and card-payment fees cost $1.80 per cake. Her fixed costs, including rent, her assistant's wages and loan repayments, are $8,100 per month.

In March, Luma Bakes sold 3,500 cakes. Inés wants to open a second shop near the university and has been offered a bank loan of $40,000 over five years at 9% interest per year. Her accountant has warned her that the business "does not have much cash to spare".

Extract from Luma Bakes' balance sheet on 31 March:
Cash: $6,000
Debtors: $9,000
Inventory (stock): $9,000
Current assets: $24,000
Creditors: $11,000
Overdraft: $4,000
Current liabilities: $15,000
```

## Request 3: Physics

Routed as `ph-e1` (fast path, one specialist).

**Student's message**

```text
physics HL (new syllabus, exams May 2027). I'm stuck on this one from my revision booklet:
An electric kettle is rated 2.2 kW, 230 V. It heats 1.5 kg of water from 18 °C to 100 °C in 4 minutes 30 seconds. Specific heat capacity of water = 4200 J kg⁻¹ K⁻¹.
(a) Calculate the current in the heating element. [1]
(b) Calculate the resistance of the heating element. [1]
(c) Calculate the energy supplied to the kettle in this time. [1]
(d) Calculate the energy absorbed by the water. [2]
(e) Determine the efficiency of the kettle. [1]
(f) The kettle is left switched on for another 30 s after the water starts to boil, and 25 g of water boils away. Assuming the same efficiency, estimate the specific latent heat of vaporization of water. [2]
(g) Suggest one reason why your answer to (f) is different from the accepted value of 2.26 × 10⁶ J kg⁻¹. [1]
pls show all the working with units, I keep messing up the minutes to seconds thing
```

## Request 4: Mathematics: Applications and Interpretation

Routed as `mai-e1` (fast path, one specialist).

**Student's message**

```text
Maths AI SL, exams May 2027. Two questions from my paper 2 revision pack (GDC allowed):
1. Priya buys a car and borrows €18 000. The loan is repaid in equal monthly instalments over 5 years, at an annual interest rate of 6.5% compounded monthly.
(a) Calculate her monthly payment. [3]
(b) Calculate the total amount she pays back. [2]
(c) Calculate the total interest she pays. [1]
(d) Find the amount she still owes after 2 years. [3]
2. The heights of sunflowers in a field are normally distributed with mean 170 cm and standard deviation 12 cm.
(a) Find the probability that a randomly chosen sunflower is taller than 190 cm. [2]
(b) 10% of the sunflowers are shorter than h cm. Find h. [2]
(c) 400 of the sunflowers are measured. Find the expected number that are taller than 190 cm. [1]
can you show what I'm supposed to put into the GDC as well? our teacher says we lose marks if we don't write the TVM inputs. answers to 3 sf, money to 2 dp
```

## Request 5: Biology

Routed as `bi-e1` (fast path, one specialist).

**Student's message**

```text
Biology HL, new course, my exams are May 2027. Our teacher gave us this fruit fly test cross and I'm confused.
A fly heterozygous for grey body and long wings (GgLl) was crossed with a fly with a black body and vestigial wings (ggll). Grey (G) is dominant to black (g) and long (L) is dominant to vestigial (l). The offspring were: grey body, long wings 412; black body, vestigial wings 398; grey body, vestigial wings 92; black body, long wings 98.
(a) State the expected ratio and the expected number of each phenotype if the two genes were unlinked. [2]
(b) Calculate the chi-squared value. [3]
(c) State the number of degrees of freedom and use the critical value of 7.815 (p = 0.05) to state what the result shows. [2]
(d) Calculate the percentage of the offspring that are recombinants. [1]
(e) Explain why recombinant offspring are produced at all if the genes are linked. [2]
my chi squared came out at like 384 which seems insane, is that right?? keep the explanations under 200 words
```

## Request 6: Language B: Spanish

Routed as `sp-e1` (fast path, one specialist).

**Student's message**

```text
Hola! I'm doing Spanish B SL (exams May 2027). This is my Paper 1 writing practice, I've pasted it below. The task was: 'Has participado en un proyecto de voluntariado en tu comunidad. Escribe una entrada de blog para contar tu experiencia y animar a otros jóvenes a participar.' (SL, 250–400 words). Can you mark it using the Paper 1 criteria (A: language, B: message, C: conceptual understanding) and give me a mark for each, then list my 5 worst grammar mistakes with the correction? Please quote my exact words when you point out a mistake. Explain in English pls
```

**Pasted document:** Mi verano en el banco de alimentos (the student's own Paper 1 writing, supplied text)

```text
Mi verano en el banco de alimentos

¡Hola a todos!

Me llamo Lucas y hoy quiero contaros sobre mi experiencia como voluntario en el banco de alimentos de mi barrio. El verano pasado he trabajado allí cada sábado durante dos meses. Decidí ser voluntario por ayudar a mi comunidad y también porque quería hacer algo diferente en las vacaciones.

Al principio, era un poco nervioso porque no conocía a nadie. El primer día, la coordinadora, una mujer muy simpático que se llama Rosa, me explicó que el banco de alimentos ayuda a más de doscientas familias cada mes. Mi trabajo era clasificar la comida y preparar las cajas para las familias. Fue muy cansado pero también muy bonito.

Lo que más me gustó fue hablar con las personas que venían a recoger la comida. Una señora mayor me dijo que sin el banco de alimentos no podría comer bien. Esto me hizo pensar mucho sobre la pobreza en mi ciudad, porque antes no sabía que había tanta gente con problemas.

Tambien aprendí muchas cosas útiles. Por ejemplo, aprendí a trabajar en equipo y a organizar mi tiempo. Ahora soy más responsable que antes y creo que soy más abierto con otras personas.

Si eres joven y tienes tiempo libre, te recomiendo que participas en un proyecto de voluntariado. No es necesario tener experiencia y la gente es muy agradecidos. Además, es una experiencia muy buena para tu currículum.

Para participar, solo tienes que ir a la página web del ayuntamiento y rellenar un formulario. ¡Es muy fácil!

¡Espero que os animéis! Si tenéis preguntas, escribidme en los comentarios.

¡Hasta pronto!
Lucas
```

## Request 7: Mathematics AA and History

Routed as group `e1a`: `maa-e1a` receives the introduction and the maths part with the table; `hi-e1a` receives the introduction, the history part and the table, and answers after `maa-e1a`'s delivered report has been relayed to it as the document `peer:maa-e1a` (the router's hand-off note is shown after the message).

**Student's message**

```text
Hi, I take Maths AA SL and History HL, both exams May 2027. In History we're doing Paper 2 authoritarian states (Hitler) and I want to use the 1923 hyperinflation in my essay, and in maths we've just done exponential models so I thought I could use that lol. I've pasted the bread prices table from my History textbook below.

MATHS PART (Paper 2 style, GDC allowed): Let t be the number of months after January 1923 and P the price of a loaf of bread in marks. Use the model P = P₀e^(kt) with the January 1923 and November 1923 prices from the table.
(a) Write down P₀ and find the exact value of k, then give k to 3 sf. [4]
(b) Find the factor that prices were multiplied by each month according to the model. [2]
(c) Find how many days it took prices to double according to the model (take 1 month = 30 days). [3]
(d) Use the model to predict the price in July 1923 and compare it with the actual July price in the table. Comment on whether the model is a good fit for 1923. [3]
Please show the log working. The history bit needs these numbers so make them clear.

HISTORY PART: My essay question is 'To what extent was the economic crisis of 1923 the main reason why Hitler came to power in 1933?' My claim is that hyperinflation was the main reason people started voting for the Nazis. Write me ONE body paragraph (max 300 words) that tests my claim, using the maths results and dates. If my claim is wrong please tell me!
```

**Pasted document:** Price of a loaf of bread in Berlin, 1918–1923 (table from the student's History textbook, supplied text)

```text
Price of a loaf of bread in Berlin, 1918–1923

Date | Price of a loaf of bread (marks)
December 1918 | 0.63
December 1922 | 163
January 1923 | 250
July 1923 | 3,465
September 1923 | 1,512,000
November 1923 | 201,000,000,000
```

**Router's hand-off note added to the History task**

```text
(Hand-off from the router: the Mathematics specialist's answer to the maths part of this request has been relayed to you through the hub as the document peer:maa-e1a. Where you use its results, quote them exactly and attribute them to the Mathematics specialist.)
```

## Request 8: Chemistry and ESS

Routed as group `e1b`: `ch-e1b` receives the introduction and the chemistry part; `ess-e1b` receives the introduction and the ESS part, and answers after `ch-e1b`'s delivered report has been relayed to it as the document `peer:ch-e1b`.

**Student's message**

```text
hey, I do Chemistry SL and ESS SL (exams May 2027). In ESS my teacher said the ocean is 'about 30% more acidic' than before the Industrial Revolution because surface ocean pH has dropped from about 8.2 to 8.1. how can 0.1 be 30%?? so I need help with both:

CHEM PART:
(a) Calculate [H+] in seawater at pH 8.2 and at pH 8.1. [2]
(b) Calculate the percentage increase in [H+]. Is 'about 30%' right? [2]
(c) Write equations to show how CO2 dissolving in seawater increases [H+]. [2]
(d) Explain why the concentration of carbonate ions (CO3^2-) goes down as the ocean becomes more acidic. [2]
(e) Some models predict a surface pH of 7.8 by 2100. By what factor would [H+] be higher than at pH 8.2? [1]
Please make the numbers really clear because I need them for the ESS part.

ESS PART: Practice question: 'Evaluate the impact of ocean acidification on coral reef ecosystems.' [6] Use the chem numbers, and this data: atmospheric CO2 was about 280 ppm in 1750 and about 421 ppm in 2023, so work out the percentage increase first. Max 250 words.
```

**Router's hand-off note added to the ESS task**

```text
(Hand-off from the router: the Chemistry specialist's answer to the chem part of this request has been relayed to you through the hub as the document peer:ch-e1b. Where you use its figures, quote them exactly and attribute them to the Chemistry specialist.)
```

## Top-up: requests 9 to 14 (all sixteen specialists deployed)

Six more students typed a single-subject request each, so that the simulation deploys all sixteen v4 specialists. Each takes the fast path (one specialist), and none is a peer of another task. With them, run 1 has 14 website requests and 16 routed tasks in `tasks.json`, one for each of the sixteen specialists. Tasks 1 to 10 are unchanged.

Every poem, extract, country, study, person and code fragment in requests 9 to 14 is fictional and was written for this simulation.

| # | Website request | Path | Routed task(s) |
| --- | --- | --- | --- |
| 9 | English (English Specialist method), close analysis of a pasted poem, non-exam homework | fast path | `en-e1` (english-specialist) |
| 10 | English A: Literature, Paper 1 thesis and paragraph on a pasted unseen extract | fast path | `lit-e1` (english-a-literature) |
| 11 | Economics, Paper 2 data response with pasted text and table | fast path | `ec-e1` (economics) |
| 12 | Psychology, Paper 2 Section B study with pasted description | fast path | `ps-e1` (psychology) |
| 13 | Geography, Paper 2 changing population with pasted data table | fast path | `ge-e1` (geography) |
| 14 | Computer Science, number bases, Boolean logic and a pasted Python trace | fast path | `cs-e1` (computer-science) |

## Request 9: English (the English Specialist)

Routed as `en-e1` (fast path, one specialist).

**Student's message**

```text
hiii so this isn't exam stuff, it's homework for our poetry unit in English A Lit (HL, exams May 2027). Our teacher gave us this poem, I've pasted it below. She said in class it's about death because it's set in November and it gets dark at the end, but I think it's actually about patience and hope. Can you write ONE paragraph in my PETAL and DIE format arguing that it's about patience, with exact quotes from the poem? max 250 words. also quick question: is 'each one a closed fist' a simile or a metaphor? I always mix them up
```

**Pasted document:** Allotment, November (poem from a class handout, supplied text)

```text
Allotment, November

My grandfather digs in the last of the light,
turning the clay the way you turn a page
you have already read and want again.

The bean poles lean together, out of work.
A robin keeps the hours he keeps,
arriving where the spade has just been,

taking the small reward of what he breaks.
He does not speak to me. He hands me bulbs,
papery as onions, each one a closed fist,

and shows me how deep: two thumbs, no more.
"You won't see these till spring," he says,
as if that were the point of them,

as if the waiting were the gift.
We walk home with the dark already in our coats,
and somewhere under the cold, the fists begin to open.
```

## Request 10: English A: Literature

Routed as `lit-e1` (fast path, one specialist).

**Student's message**

```text
Hi, English A: Literature SL, exams May 2027. Paper 1 practice: my teacher gave us this unseen prose extract (pasted below) with the guiding question: How does the writer present the narrator's feelings about leaving home?
My thesis: The narrator is relieved to leave the house because it was old and uncomfortable, and is looking forward to the new flat.
Can you write my thesis statement properly and then ONE body paragraph proving it with exact quotes? 300 words max. If my thesis doesn't work with the extract pls tell me and fix it, I'm not sure about it
```

**Pasted document:** The Last Morning (unseen prose extract from a Paper 1 practice booklet, supplied text)

```text
The Last Morning

The removal van was due at nine, so I got up at six to say goodbye to the house without anyone watching.

The kitchen had already stopped being ours. Mum had wrapped the plates in yesterday's newspaper and stacked them in boxes marked FRAGILE in her square capitals, and without them the shelves looked like a mouth with its teeth knocked out. The clock was gone. I kept looking at the pale circle where it had hung, as if the time might still be written there.

I ran my hand along the doorframe. Four pencil lines climbed it, each with a date beside it, the last one level with my shoulder. Nobody had painted over them. Nobody had thought to.

For eleven years I had complained about this house. The stairs groaned. The bathroom window stuck in winter and would not close in summer. My bedroom was so narrow that I could touch both walls at once, and I used to do it on bad nights, pressing my palms flat against the cold plaster until I felt held.

Outside, the street was grey and ordinary. Mrs Okafor's cat sat on the wall exactly where it always sat, unbothered, as if nothing in the world were about to change.

I told myself I was glad. The new flat had a dishwasher and a lift and a view of the river. I said it twice, out loud, to the empty kitchen, and the kitchen gave it back to me thinner.

At ten to nine the van turned into our road. I pulled the front door shut behind me and listened for the click, the way I had every morning of my life, and only realised on the pavement that I had not let go of the handle.
```

## Request 11: Economics

Routed as `ec-e1` (fast path, one specialist).

**Student's message**

```text
Economics SL, exams May 2027. Paper 2 practice, the text and table are pasted below.
(a) Define the term regressive tax (paragraph 3). [2]
(b) Using Table 1, calculate the price elasticity of demand (PED) for sugar-sweetened drinks between December 2025 and June 2026. [2]
(c) Using Table 1, calculate the government's monthly revenue from the tax. [2]
(d) Using Table 1, calculate how much of the tax per litre is paid by consumers and how much by producers. [2]
(e) Using an appropriate diagram, explain why the tax reduced the quantity of sugar-sweetened drinks sold by only 10%. [4]
(f) Using a demerit good diagram, explain why the government of Teravia taxed sugar-sweetened drinks. [4]
I got PED = -2.5 for (b) but the answer sheet says -0.4?? and my friend says the tax raises $30 million a month, is that right? I think consumers pay two thirds of the tax. Diagrams can just be described in words, keep (e) and (f) under 120 words each
```

**Pasted document:** Teravia's sugar tax (Paper 2 practice text and table, supplied text)

```text
Text A: Teravia's sugar tax

[1] In January 2026 the government of Teravia, a middle-income country, placed a specific (per-unit) tax of $0.60 per litre on sugar-sweetened drinks. The aim was to reduce obesity, which the health ministry says costs the public health service $310 million a year.

[2] Before the tax, a litre of sugar-sweetened drink sold for $1.60 on average and Teravians bought 50 million litres a month. Six months after the tax was introduced, the average price was $2.00 a litre and monthly sales had fallen to 45 million litres.

[3] Drinks firms argue that the tax is regressive and say it has cost 400 jobs in bottling plants. Health campaigners want the revenue spent on free fruit in schools, and point out that sales of bottled water rose by 18% over the same period.

Table 1: The market for sugar-sweetened drinks in Teravia

Indicator | Before the tax (December 2025) | After the tax (June 2026)
Average price per litre | $1.60 | $2.00
Quantity sold per month | 50 million litres | 45 million litres
Specific tax per litre | $0.00 | $0.60
```

## Request 12: Psychology

Routed as `ps-e1` (fast path, one specialist).

**Student's message**

```text
Psychology SL, new course (exams May 2027). This is Paper 2 Section B practice, the study is pasted below. Question: 'Discuss the study with reference to two or more of the following concepts: bias, causality, measurement, responsibility.' [15]
Can you give me a short plan AND the full answer pls (max 500 words for the answer)? Use causality and measurement. Also I worked out that recall dropped by about 30% in the stress condition (2.6 ÷ 8.6 = 0.30), is that right? and can the researchers really say that stress impairs memory?
```

**Pasted document:** Stress and memory (practice Paper 2 Section B study, supplied text)

```text
Stress and memory (study for Paper 2 Section B)

Researchers at a university wanted to investigate whether stress affects memory. They recruited 48 undergraduate students through an advertisement offering course credit. Participants were randomly allocated to one of two conditions.

In the stress condition (24 participants), participants were told that they would shortly give a five-minute speech that would be filmed and judged by a panel. In the control condition (24 participants), participants read a magazine for five minutes.

All participants then studied a list of 20 words for two minutes and wrote down as many words as they could recall after a 10-minute delay. Saliva samples were taken before and after the task to measure cortisol, a stress hormone.

Participants in the stress condition recalled a mean of 8.6 words; participants in the control condition recalled a mean of 11.2 words. Cortisol levels rose in the stress condition but not in the control condition. The researchers concluded that stress impairs memory.

At the end, all participants were debriefed and told that no speech would actually be given.
```

## Request 13: Geography

Routed as `ge-e1` (fast path, one specialist).

**Student's message**

```text
Geography SL (exams May 2027). Paper 2 Section A practice on changing population, I typed the resource table in below.
(a) (i) Calculate the natural increase rate of Selvaria in 2024. [1]
(ii) Estimate the doubling time of Selvaria's population at the 2024 rate of natural increase. [1]
(b) Calculate the dependency ratio of Selvaria in 1990 and in 2024. [2]
(c) Describe the changes in Selvaria's age structure between 1990 and 2024. [2]
(d) Explain two reasons why Selvaria's crude birth rate fell between 1990 and 2024. [2 + 2]
For (b) I put 0.92 and 0.62 and my teacher circled them, why?? Also my friend says Selvaria's population nearly doubled between 1990 and 2024, is that true? short answers pls, it's only a 10 mark question
```

**Pasted document:** Figure 1: Population data for Selvaria (resources booklet table, supplied text)

```text
Figure 1: Population data for Selvaria

Indicator | 1990 | 2024
Total population (millions) | 9.6 | 17.8
Aged 0–14 (millions) | 4.3 | 5.9
Aged 15–64 (millions) | 5.0 | 11.0
Aged 65 and over (millions) | 0.3 | 0.9
Crude birth rate (per 1,000 per year) | 38 | 24
Crude death rate (per 1,000 per year) | 14 | 7
Urban population (%) | 31 | 57
Female literacy rate (%) | 54 | 91
Contraceptive prevalence (% of women aged 15–49) | 21 | 58
```

## Request 14: Computer Science

Routed as `cs-e1` (fast path, one specialist).

**Student's message**

```text
CS SL, new course, Python option, exams May 2027. Some revision questions from my Paper 1 and Paper 2 practice sheets:
1. (a) Convert the binary number 1011 0110 into denary and into hexadecimal. [2]
(b) State how many different values can be represented with 12 bits. [1]
(c) Construct the truth table for X = (A AND B) OR (NOT A AND C). [4]
(d) Show that A·B + A·NOT B = A using Boolean algebra. [2]
2. The Python code from the practice sheet is pasted below.
(a) Trace the call binary_search(scores, 30) and state what is printed. [3]
(b) Trace the call binary_search(scores, 9) and state what is printed. [3]
(c) Explain why binary search would not work if scores were not sorted. [2]
For 1(a) I got 182 but my friend got 109?? and for 2(b) I think it prints (-1, 4). pls show the trace tables
```

**Pasted document:** binary_search (Python code from a Paper 2 practice sheet, supplied text)

```text
def binary_search(items, target):
    low = 0
    high = len(items) - 1
    steps = 0
    while low <= high:
        mid = (low + high) // 2
        steps = steps + 1
        if items[mid] == target:
            return mid, steps
        elif items[mid] < target:
            low = mid + 1
        else:
            high = mid - 1
    return -1, steps


scores = [3, 8, 12, 17, 21, 26, 30, 35, 41]
print(binary_search(scores, 30))
print(binary_search(scores, 9))
```

