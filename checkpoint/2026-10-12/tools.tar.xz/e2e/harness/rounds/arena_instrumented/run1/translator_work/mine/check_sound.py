import json, copy, sys
from epinoic_logic.engine.runner import verify
path = sys.argv[1]
d = json.load(open(path, encoding="utf-8"))
def st(r):
    return getattr(r.status, "value", r.status)
# 1) premises consistent (vacuity guard)
bad = []
for cid, obj in d["claims"].items():
    if obj["problem"] is None:
        continue
    p = copy.deepcopy(obj["problem"])
    p.pop("conclusion", None)
    p["query"] = "consistency"
    s = st(verify(json.dumps(p)))
    if s != "CONSISTENT":
        bad.append((cid, s))
print("consistency failures:", bad if bad else "none")
# 2) negative control: swap each conclusion for its negation; must not be ENTAILED
#    (a correct claim's negation should give COUNTEREXAMPLE, a wrong encoding would stay ENTAILED)
from copy import deepcopy
res = {}
for cid, obj in d["claims"].items():
    if obj["problem"] is None:
        continue
    p = deepcopy(obj["problem"])
    c = p["conclusion"]
    c["expr"] = {"op": "not", "arg": c["expr"]}
    res[cid] = st(verify(json.dumps(p)))
print("negated conclusions:", res)
