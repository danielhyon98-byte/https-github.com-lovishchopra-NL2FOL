import json, sys
from epinoic_logic.engine.runner import verify
path = sys.argv[1]
d = json.load(open(path, encoding="utf-8"))
syms, sym_src = {}, {}
prems, seen = [], set()
conflicts = []
for cid, obj in d["claims"].items():
    if obj["problem"] is None:
        continue
    pr = obj["problem"]
    for s in pr["symbols"]:
        key = (s["sort"], s["meaning"])
        if s["name"] in syms and syms[s["name"]] != key:
            conflicts.append(("symbol", s["name"], sym_src[s["name"]], cid))
        syms.setdefault(s["name"], key); sym_src.setdefault(s["name"], cid)
    for p in pr["premises"]:
        k = json.dumps(p["expr"], sort_keys=True)
        if k not in seen:
            seen.add(k)
            prems.append({"id": "pooled-%d" % len(prems), "expr": p["expr"], "label": p["label"], "grounding": p["grounding"], "materiality": p["materiality"]})
symbols = [{"name": n, "sort": v[0], "meaning": v[1]} for n, v in syms.items()]
pooled = {"ir_version": "1.0", "problem_id": "pooled", "request_id": d["report_id"], "claim_id": "pooled",
          "query": "consistency", "symbols": symbols, "premises": prems}
from epinoic_logic.ir.schema import Limits
lim = Limits(max_symbols=512, max_premises=1024, max_nodes=200000, max_depth=80)
r = verify(json.dumps(pooled), limits=lim)
print("diagnostics:", [getattr(x, "code", None) for x in (r.diagnostics or [])][:5])
print("symbol name conflicts:", conflicts if conflicts else "none")
print("symbols:", len(symbols), "unique premises:", len(prems), "pooled status:", getattr(r.status, "value", r.status))
