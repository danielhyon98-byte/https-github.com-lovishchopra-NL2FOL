import glob, json, os, subprocess
from epinoic_logic.engine import parse_and_validate
BASE = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/e2e"
PY = BASE + "/venv/bin/python"
LC = BASE + "/tree/scripts/arena/list_claims.py"
tot_claims = tot_enc = tot_null = 0
for spec in sorted(glob.glob(BASE + "/run1/specialists/*.json")):
    task = os.path.basename(spec)[:-5]
    out = subprocess.run([PY, "-I", LC, spec, "--eligible", "--json"], capture_output=True, text=True, check=True).stdout
    elig = [c["claim_id"] for c in json.loads(out)["claims"]]
    path = f"{BASE}/run1/translations/{task}.json"
    if not os.path.exists(path):
        print(f"{task}: NO TRANSLATION FILE (eligible={len(elig)})"); continue
    d = json.load(open(path))
    cl = d["claims"]
    missing = [c for c in elig if c not in cl]
    extra = [c for c in cl if c not in elig]
    bad = []; enc = nul = 0
    for cid, obj in cl.items():
        if obj.get("problem") is None:
            nul += 1
            if not obj.get("unsupported_reason"):
                bad.append((cid, "null without reason"))
            continue
        enc += 1
        p, o = parse_and_validate(json.dumps(json.load(open(path))["claims"][cid]["problem"]))
        if not o.ok:
            bad.append((cid, "INVALID"))
    tot_claims += len(cl); tot_enc += enc; tot_null += nul
    print(f"{task}: eligible={len(elig)} translated={len(cl)} encoded={enc} null={nul} missing={missing} extra={extra} bad={bad}")
print(f"TOTAL translated={tot_claims} encoded={tot_enc} null={tot_null}")
