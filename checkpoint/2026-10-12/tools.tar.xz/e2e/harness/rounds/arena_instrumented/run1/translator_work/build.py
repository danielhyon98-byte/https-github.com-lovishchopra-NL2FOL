#!/usr/bin/env python3
"""Build translation objects (translate_v1 output contract) for the eligible claims of
ll-e1 (English A), bi-e1 (Biology) and ch-e1b (Chemistry). Writes one JSON file per task
into run1/translations. Only the translation step: the tree is not modified."""
import json
import os

BASE = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/e2e/run1"
OUT = os.path.join(BASE, "translations")


# ---------- IR expression helpers (allowlisted nodes only) ----------
def V(n): return {"op": "var", "name": n}
def B(v): return {"op": "bool", "value": v}
def I(s): return {"op": "int", "value": str(s)}
def R(s): return {"op": "real", "value": str(s)}
def NOT(a): return {"op": "not", "arg": a}
def AND(*a): return {"op": "and", "args": list(a)}
def IMP(l, r): return {"op": "implies", "left": l, "right": r}
def IFF(l, r): return {"op": "iff", "left": l, "right": r}
def ADD(*a): return {"op": "add", "args": list(a)}
def MUL(*a): return {"op": "mul", "args": list(a)}
def SUB(l, r): return {"op": "sub", "left": l, "right": r}
def DIV(l, r): return {"op": "div", "left": l, "right": r}
def TOR(a): return {"op": "to_real", "arg": a}
def EQ(l, r): return {"op": "eq", "left": l, "right": r}
def NE(l, r): return {"op": "ne", "left": l, "right": r}
def LT(l, r): return {"op": "lt", "left": l, "right": r}
def GT(l, r): return {"op": "gt", "left": l, "right": r}
def GE(l, r): return {"op": "ge", "left": l, "right": r}
def LE(l, r): return {"op": "le", "left": l, "right": r}


# ---------- grounding / symbol / assertion helpers ----------
def G(kind, cert="established", excerpts=None, doc=None, note=None):
    g = {"kind": kind, "certainty": cert}
    if excerpts:
        g["source_refs"] = [{"document_id": doc, "excerpt": e} for e in excerpts]
    if note:
        g["note"] = note
    return g


def S(name, sort, meaning, grounding=None):
    return {"name": name, "sort": sort, "meaning": meaning, "grounding": grounding}


def A(aid, expr, label, grounding, materiality="material"):
    return {"id": aid, "expr": expr, "label": label, "grounding": grounding, "materiality": materiality}


def gloss(syms):
    return [{"symbol": s["name"], "meaning": s["meaning"], "grounding": s["grounding"]} for s in syms]


def claim_obj(pid, req, cid, syms, prems, concl, reading, flags=None, ambiguous=False):
    prob = {"ir_version": "1.0", "problem_id": pid, "request_id": req, "claim_id": cid,
            "query": "entailment", "symbols": syms, "premises": prems, "conclusion": concl}
    return {"problem": prob,
            "interpretation": {"reading": reading, "glossary": gloss(syms), "ambiguity_flags": flags or []},
            "ambiguous": ambiguous, "unsupported_reason": None}


def null_obj(reading, reason):
    return {"problem": None,
            "interpretation": {"reading": reading, "glossary": [], "ambiguity_flags": []},
            "ambiguous": False, "unsupported_reason": reason}


# =====================================================================
# ll-e1 (English A: Language and Literature), request req-ll-e1
# =====================================================================
LD = "doc-leaflet"


def build_ll():
    REQ = "req-ll-e1"
    TASK = "ll-e1"
    CL = "p1-point"

    def q(name, meaning, ex):
        return S(name, "Bool", meaning, G("quotation", "established", [ex], LD))

    def ib(name, meaning):
        return S(name, "Bool", meaning, G("specialist_inference", "probable"))

    syms = [
        q("q_question", "the leaflet asks the reader: So why are you throwing away food?",
          "So why are you throwing away food?"),
        q("q_money_note", "the leaflet compares binning food with binning a £10 note",
          "You wouldn’t throw a £10 note in the bin"),
        q("q_your_money", "the leaflet says the loss is the reader's own money", "your money"),
        q("q_weight", "the leaflet's figure: 8 kg of food that could have been eaten per household per week",
          "8 kg of food that could have been eaten"),
        q("q_meal", "the leaflet turns that food into a whole roast dinner, a loaf of bread and a bag of salad",
          "a whole roast dinner, a loaf of bread and a bag of salad"),
        q("q_weekly", "the leaflet repeats the waste as happening every single week", "every single week"),
        q("q_good_news", "the leaflet turns to 'The good news?'", "The good news?"),
        q("q_three_steps", "the leaflet says the problem can be fixed in three small steps",
          "You can fix this in three small steps."),
        q("q_imperative", "the first step is an imperative: check the fridge", "Check your fridge before you shop"),
        q("q_everyday", "the steps use everyday food: leftover rice", "Leftover rice?"),
        q("q_small", "the leaflet's slogan: small changes, big difference", "Small changes. Big difference."),
        q("q_hardly", "a resident says the change means they hardly waste a thing", "we hardly waste a thing"),
        S("s_order", "Bool",
          "in the leaflet the passage making the loss personal ('It’s not just your money going in the bin.') "
          "comes before the 'The good news?' passage",
          G("supplied_text", "established", ["It’s not just your money going in the bin.", "The good news?"], LD,
            note="structural fact about the order of two passages")),
        ib("i_noreason", "the question's implied answer is that the reader has no good reason to waste food"),
        ib("i_personal", "the comparison with money and 'your money' makes the loss personal to the reader"),
        ib("i_vivid", "the statistic is turned into a meal the reader can picture as binned"),
        ib("i_answerable", "the reader is made to feel answerable for food waste"),
        ib("i_comfort", "'The good news?' turns the accusation into reassurance"),
        ib("i_checklist", "the remedy is a short list of imperative steps grounded in everyday food"),
        ib("i_modest", "the required action looks modest and already under way"),
        ib("i_shrunk", "the remedy is shrunk to a checklist"),
    ]
    by = {s["name"]: s for s in syms}

    def ev(sname, label):
        s = by[sname]
        return A("ev_" + sname[2:], V(sname), label, s["grounding"])

    prems = [
        ev("q_question", "the leaflet asks: So why are you throwing away food?"),
        ev("q_money_note", "the leaflet says: You wouldn’t throw a £10 note in the bin"),
        ev("q_your_money", "the leaflet says: your money"),
        ev("q_weight", "the leaflet says: 8 kg of food that could have been eaten"),
        ev("q_meal", "the leaflet says: a whole roast dinner, a loaf of bread and a bag of salad"),
        ev("q_weekly", "the leaflet says: every single week"),
        ev("q_good_news", "the leaflet says: The good news?"),
        ev("q_three_steps", "the leaflet says: You can fix this in three small steps."),
        ev("q_imperative", "the leaflet says: Check your fridge before you shop"),
        ev("q_everyday", "the leaflet says: Leftover rice?"),
        ev("q_small", "the leaflet says: Small changes. Big difference."),
        ev("q_hardly", "the leaflet quotes a resident: we hardly waste a thing"),
        ev("s_order", "the guilt passage comes before the 'good news' passage in the leaflet"),
        A("lk_noreason", IMP(V("q_question"), V("i_noreason")),
          "the question implies the reader has no good reason", G("specialist_inference", "probable")),
        A("lk_personal", IMP(AND(V("q_money_note"), V("q_your_money")), V("i_personal")),
          "the money comparison and 'your money' make the loss personal",
          G("specialist_inference", "probable")),
        A("lk_vivid", IMP(AND(V("q_weight"), V("q_meal"), V("q_weekly")), V("i_vivid")),
          "the weight becomes a meal the reader can picture, repeated every week",
          G("specialist_inference", "probable")),
        A("lk_answerable", IMP(AND(V("i_noreason"), V("i_personal"), V("i_vivid")), V("i_answerable")),
          "direct address combined with a concrete statistic makes the reader feel answerable",
          G("specialist_inference", "probable")),
        A("lk_comfort", IMP(V("q_good_news"), V("i_comfort")),
          "'The good news?' shifts the register from accusation to comfort",
          G("specialist_inference", "probable"), materiality="supporting"),
        A("lk_checklist", IMP(AND(V("q_three_steps"), V("q_imperative"), V("q_everyday")), V("i_checklist")),
          "the three steps are short imperatives grounded in everyday food",
          G("specialist_inference", "probable")),
        A("lk_modest", IMP(AND(V("q_small"), V("q_hardly")), V("i_modest")),
          "the slogan and the resident's testimony make the required action look modest",
          G("specialist_inference", "probable")),
        A("lk_shrunk", IMP(AND(V("i_checklist"), V("i_modest")), V("i_shrunk")),
          "a short imperative checklist that looks modest is a remedy shrunk to a checklist",
          G("specialist_inference", "probable")),
    ]
    concl = A("concl", AND(V("i_answerable"), V("i_shrunk"), V("s_order")),
              "the leaflet makes its reader feel answerable for food waste, then shrinks the remedy to a checklist",
              G("specialist_inference", "probable"))
    reading = (
        "Stage 1: the quotations are the evidence atoms: the direct question, the £10 note comparison, 'your money', "
        "the 8 kg figure, the roast-dinner translation, 'every single week', 'The good news?', the three-step sentence, "
        "the imperative 'Check your fridge before you shop', 'Leftover rice?', 'Small changes. Big difference.' and "
        "'we hardly waste a thing'. Stage 2: the specialist's links are separate implications: the question implies no "
        "good reason; the money comparison with 'your money' makes the loss personal; the statistic becomes a meal "
        "the reader can picture; direct address plus the statistic makes the reader feel answerable; the imperative "
        "steps grounded in everyday food make a checklist; the slogan and testimony make the action look modest; "
        "checklist plus modest action shrink the remedy. 'The good news?' is kept as a supporting premise. 'Then' is "
        "encoded as textual order (s_order, a structural fact about the leaflet), not as causation. 'Stick to it' and "
        "'Start tonight' are not needed for the point and are not encoded. Conclusion: both halves and the order."
    )
    flags = [{"code": "then-sequence",
              "message": "'then' could mark the textual order of two moves or a causal step from answerability to the "
                         "checklist. Only textual order is encoded (s_order); a causal link is not in the specialist's report.",
              "alternatives": ["textual order of the two moves (encoded as s_order)",
                               "causal: answerability leads to the shrinking (not encoded)"]}]
    out = {"report_id": "rep-ll-e1-0", "claims": {
        CL: claim_obj(f"{TASK}-{CL}", REQ, CL, syms, prems, concl, reading, flags, ambiguous=True)}}
    return TASK, out


# =====================================================================
# bi-e1 (Biology), request req-bi-e1
# =====================================================================
def chi_term(o):
    return DIV(MUL(SUB(R(o), R(250)), SUB(R(o), R(250))), R(250))


def chi_sum():
    return ADD(chi_term(412), chi_term(398), chi_term(92), chi_term(98))


def build_bi():
    REQ = "req-bi-e1"
    TASK = "bi-e1"
    cnt_g = G("task_setting", "established")
    arith = lambda note=None: G("arithmetic_fact", "established", note=note)
    gen = lambda note=None: G("general_knowledge", "established", note=note)
    spec = lambda: G("specialist_inference", "established")

    chi_sym = S("chi2", "Real", "chi-squared statistic from the four offspring classes with expected 250 each",
                arith("computed from the task counts"))
    pr_chi2 = A("pr_chi2", EQ(V("chi2"), chi_sum()),
                "chi-squared = sum of (observed - 250)^2 / 250 over the four classes",
                arith("observed counts 412, 398, 92, 98 and expected 250 (1000 / 4) computed from the task; "
                      "the formula is the standard chi-squared definition"))
    crit_sym = S("crit", "Real", "critical chi-squared value for df = 3 at p = 0.05, as given in the question", cnt_g)
    pr_crit = A("pr_crit", EQ(V("crit"), R("7.815")),
                "the critical value is 7.815 (p = 0.05)", G("task_setting", "established",
                                                          note="given in the question"))

    out = {"report_id": "rep-bi-e1-0", "claims": {}}

    # s1.1 -- chi-squared value 384.9
    out["claims"]["s1.1"] = claim_obj(
        f"{TASK}-s1.1", REQ, "s1.1", [chi_sym], [pr_chi2],
        A("concl", AND(GE(V("chi2"), R("384.85")), LT(V("chi2"), R("384.95"))),
          "the chi-squared value is 384.9 (to 4 significant figures)", spec()),
        "Encoded the chi-squared value from the four offspring counts against the expected 250 per class: the sum of "
        "(O - E)^2 / E is 384.864, so 384.9 to 4 s.f. is entailed. Only the value is encoded; the student's rounded "
        "'384' is not a figure in the claim. The supporting claim s1.2 is not encoded (see s1.2).")

    # s1.2 -- looks large because far from 250
    out["claims"]["s1.2"] = null_obj(
        "Supporting claim: 'It looks large because every observed count is far from the expected 250.' Encoding "
        "needs a threshold for 'far' and 'looks large' is a judgement; neither is stated in the report or the task.",
        "vague comparison ('far', 'looks large') with no stated threshold; encoding would invent one")

    # s2.1 -- expected ratio 1:1:1:1
    gm = ["gm_gl", "gm_gv", "gm_bl", "gm_bv"]
    xs = ["x_gl", "x_gv", "x_bl", "x_bv"]
    syms21 = [S(n, "Real", "proportion of GgLl gametes of type " + t, None)
              for n, t in zip(gm, ["GL", "Gl", "gL", "gl"])] + \
             [S(n, "Real", "expected proportion of offspring in class " + t, None)
              for n, t in zip(xs, ["grey long", "grey vestigial", "black long", "black vestigial"])]
    pr21 = [
        A("pr_gamete", AND(EQ(V("gm_gl"), V("gm_gv")), EQ(V("gm_gv"), V("gm_bl")), EQ(V("gm_bl"), V("gm_bv"))),
          "unlinked genes: the four gamete types of GgLl are equally frequent", gen()),
        A("pr_carry", AND(EQ(V("x_gl"), V("gm_gl")), EQ(V("x_gv"), V("gm_gv")), EQ(V("x_bl"), V("gm_bl")),
                          EQ(V("x_bv"), V("gm_bv"))),
          "the ggll parent gives only gl gametes, so each offspring class has the frequency of the gamete it carries",
          gen()),
    ]
    out["claims"]["s2.1"] = claim_obj(
        f"{TASK}-s2.1", REQ, "s2.1", syms21, pr21,
        A("concl", AND(EQ(V("x_gl"), V("x_gv")), EQ(V("x_gv"), V("x_bl")), EQ(V("x_bl"), V("x_bv"))),
          "the expected ratio of the four classes is 1:1:1:1", spec()),
        "Encoded as equal expected proportions of the four offspring classes. Premises: under unlinked assortment the "
        "four GgLl gamete types are equally frequent, and the ggll parent contributes only gl, so each offspring class "
        "has the frequency of the gamete it carries (both general knowledge). Conclusion: the four classes are equal.")

    # s2.2 -- expected numbers 250 each
    syms22 = [S(n, "Real", "expected count proportion of class " + t, None)
              for n, t in zip(xs, ["grey long", "grey vestigial", "black long", "black vestigial"])] + \
             [S("total", "Real", "total number of offspring in the task (1000)", arith("sum of the task counts"))]
    pr22 = [
        A("pr_total", EQ(V("total"), ADD(R(412), R(398), R(92), R(98))),
          "the total number of offspring is 412 + 398 + 92 + 98 = 1000", arith("sum of task counts")),
        A("pr_equal", AND(EQ(V("x_gl"), V("x_gv")), EQ(V("x_gv"), V("x_bl")), EQ(V("x_bl"), V("x_bv"))),
          "the expected ratio is 1:1:1:1 (from s2.1)", spec()),
        A("pr_sum", EQ(ADD(V("x_gl"), V("x_gv"), V("x_bl"), V("x_bv")), V("total")),
          "the expected counts add up to the total", gen()),
    ]
    out["claims"]["s2.2"] = claim_obj(
        f"{TASK}-s2.2", REQ, "s2.2", syms22, pr22,
        A("concl", AND(EQ(V("x_gl"), R(250)), EQ(V("x_gv"), R(250)), EQ(V("x_bl"), R(250)), EQ(V("x_bv"), R(250))),
          "each expected class is 250 (1000 divided by 4)", spec()),
        "Encoded the expected count per class: the four expected classes are equal (s2.1), they sum to the total of "
        "1000 from the task counts, so each is 1000 / 4 = 250.")

    # s3.1 -- formula definition only
    out["claims"]["s3.1"] = null_obj(
        "Supporting claim: 'chi-squared = sum of (O - E)^2 / E, with E = 250 for each phenotype.' This is the "
        "chi-squared definition from general knowledge plus the expected value from s2.2. Its value is encoded in "
        "s1.1 and s3.3; the definition alone has no separate relation to check.",
        "a definitional formula stated from memory; the only encoding restates the definition")

    # s3.2 -- arithmetic of the four terms
    tsyms = [S("t_gl", "Real", "(412 - 250)^2 / 250", arith()), S("t_bv", "Real", "(398 - 250)^2 / 250", arith()),
             S("t_gv", "Real", "(92 - 250)^2 / 250", arith()), S("t_bl", "Real", "(98 - 250)^2 / 250", arith())]
    pr32 = [A("pr_terms", AND(EQ(V("t_gl"), chi_term(412)), EQ(V("t_bv"), chi_term(398)),
                              EQ(V("t_gv"), chi_term(92)), EQ(V("t_bl"), chi_term(98))),
              "each term is (observed - 250)^2 / 250 for its class",
              arith("computed from the task counts"))]
    out["claims"]["s3.2"] = claim_obj(
        f"{TASK}-s3.2", REQ, "s3.2", tsyms, pr32,
        A("concl", AND(EQ(V("t_gl"), R("104.976")), EQ(V("t_bv"), R("87.616")), EQ(V("t_gv"), R("99.856")),
                       EQ(V("t_bl"), R("92.416")),
                       EQ(ADD(V("t_gl"), V("t_bv"), V("t_gv"), V("t_bl")), R("384.864"))),
          "the four terms are 104.976, 87.616, 99.856 and 92.416, and they sum to 384.864",
          G("arithmetic_fact", "established")),
        "Encoded the four squared-deviation terms as exact arithmetic and checked the printed values and their sum "
        "(384.864 = 96216 / 250, exact). The terms are in the order the claim lists the counts: 412, 398, 92, 98.",
        ambiguous=False)

    # s3.3 -- 384.9 (385 to 3 s.f.)
    out["claims"]["s3.3"] = claim_obj(
        f"{TASK}-s3.3", REQ, "s3.3", [chi_sym], [pr_chi2],
        A("concl", AND(GE(V("chi2"), R("384.85")), LT(V("chi2"), R("384.95")),
                       GE(V("chi2"), R("384.5")), LT(V("chi2"), R("385.5"))),
          "chi-squared = 384.9, which is 385 to 3 significant figures", spec()),
        "Encoded chi-squared from the formula premise (384.864). The claim is 384.9 to 4 s.f. (384.85 up to 384.95) "
        "and 385 to 3 s.f. (384.5 up to 385.5); both bounds are checked.")

    # s4.1 -- df = 3
    out["claims"]["s4.1"] = claim_obj(
        f"{TASK}-s4.1", REQ, "s4.1",
        [S("categories", "Int", "number of phenotype classes in the test cross", cnt_g),
         S("df", "Int", "degrees of freedom of the chi-squared test", gen())],
        [A("pr_cat", EQ(V("categories"), I(4)), "there are four phenotype classes in the question",
           G("task_setting", "established")),
         A("pr_df", EQ(V("df"), SUB(V("categories"), I(1))), "degrees of freedom = categories - 1",
           gen())],
        A("concl", EQ(V("df"), I(3)), "the degrees of freedom are 4 categories - 1 = 3", spec()),
        "Encoded df = categories - 1 with four categories (the four classes in the question), giving 3.")

    # s4.2 -- 384.9 > 7.815, null rejected
    reject = S("reject_null", "Bool", "the null hypothesis of independent assortment (1:1:1:1) is rejected", None)
    out["claims"]["s4.2"] = claim_obj(
        f"{TASK}-s4.2", REQ, "s4.2", [chi_sym, crit_sym, reject],
        [pr_chi2, pr_crit,
         A("pr_rule", IMP(GT(V("chi2"), V("crit")), V("reject_null")),
           "a chi-squared above the critical value at p = 0.05 rejects the null hypothesis",
           gen())],
        A("concl", AND(GT(V("chi2"), V("crit")), V("reject_null")),
          "384.9 is greater than 7.815, so the null hypothesis is rejected", spec()),
        "Encoded the comparison of chi-squared with the critical value 7.815 (from the question) and the decision rule "
        "for p = 0.05. The rejection follows from the rule; the value 384.9 is the formula value.",)

    # s4.3 -- significant, not unlinked, linked
    sig = S("sig", "Bool", "the difference is significant at p = 0.05", None)
    unl = S("unlinked", "Bool", "the two genes assort independently (unlinked)", None)
    lnk = S("linked", "Bool", "the two genes are linked", None)
    out["claims"]["s4.3"] = claim_obj(
        f"{TASK}-s4.3", REQ, "s4.3", [chi_sym, crit_sym, sig, unl, lnk],
        [pr_chi2, pr_crit,
         A("pr_sig", IFF(V("sig"), GT(V("chi2"), V("crit"))),
           "significant at p = 0.05 exactly when chi-squared exceeds the critical value",
           gen()),
         A("pr_notunlinked", IMP(V("sig"), NOT(V("unlinked"))),
           "a significant result means the genes are not unlinked", spec()),
         A("pr_linked", IFF(V("linked"), NOT(V("unlinked"))),
           "for two genes, linked means not assorting independently", gen())],
        A("concl", AND(V("sig"), NOT(V("unlinked")), V("linked")),
          "the difference is significant at p = 0.05, the genes are not unlinked, and they are linked", spec()),
        "Encoded significance (chi-squared above 7.815), the specialist's step from significance to 'not unlinked', "
        "and the meaning of linked as not assorting independently. The conclusion has the three parts of the claim.")

    # s5.1 -- recombinants 92 + 98 = 190
    ncnt = [S("n_gl", "Int", "observed grey body, long wings", cnt_g),
            S("n_gv", "Int", "observed grey body, vestigial wings", cnt_g),
            S("n_bl", "Int", "observed black body, long wings", cnt_g),
            S("n_bv", "Int", "observed black body, vestigial wings", cnt_g),
            S("recomb", "Int", "number of recombinant offspring", gen())]
    out["claims"]["s5.1"] = claim_obj(
        f"{TASK}-s5.1", REQ, "s5.1", ncnt,
        [A("pr_ngl", EQ(V("n_gl"), I(412)), "grey body, long wings: 412", G("task_setting", "established")),
         A("pr_nbv", EQ(V("n_bv"), I(398)), "black body, vestigial wings: 398", G("task_setting", "established")),
         A("pr_ngv", EQ(V("n_gv"), I(92)), "grey body, vestigial wings: 92", G("task_setting", "established")),
         A("pr_nbl", EQ(V("n_bl"), I(98)), "black body, long wings: 98", G("task_setting", "established")),
         A("pr_recomb", EQ(V("recomb"), SUB(SUB(ADD(V("n_gl"), V("n_gv"), V("n_bl"), V("n_bv")), V("n_gl")), V("n_bv"))),
           "recombinants are the offspring that are neither parental type (grey long, black vestigial)", gen())],
        A("concl", AND(EQ(V("recomb"), ADD(V("n_gv"), V("n_bl"))), EQ(ADD(V("n_gv"), V("n_bl")), I(190))),
          "recombinants are grey vestigial plus black long: 92 + 98 = 190", spec()),
        "Encoded the recombinant count as the offspring not of a parental type: 1000 - 412 - 398 = 190, which equals "
        "92 (grey vestigial) + 98 (black long). The claim's identification is checked numerically through the parental "
        "classes.")

    # s5.2 -- 190 / 1000 x 100 = 19%
    out["claims"]["s5.2"] = claim_obj(
        f"{TASK}-s5.2", REQ, "s5.2",
        [S("n_gv", "Int", "observed grey body, vestigial wings", cnt_g),
         S("n_bl", "Int", "observed black body, long wings", cnt_g),
         S("recomb", "Int", "number of recombinant offspring", gen())],
        [A("pr_ngv", EQ(V("n_gv"), I(92)), "grey body, vestigial wings: 92", G("task_setting", "established")),
         A("pr_nbl", EQ(V("n_bl"), I(98)), "black body, long wings: 98", G("task_setting", "established")),
         A("pr_recomb", EQ(V("recomb"), ADD(V("n_gv"), V("n_bl"))),
           "the recombinant count is 92 + 98 (from s5.1)", arith("sum of task counts"))],
        A("concl", EQ(MUL(DIV(TOR(V("recomb")), R("1000")), R("100")), R("19")),
          "190 divided by 1000 times 100 = 19%", spec()),
        "Encoded 190 / 1000 x 100 = 19 as exact arithmetic on the recombinant count (the denominator 1000 is the total "
        "from the task).",
        ambiguous=False)

    # s6.1 -- meiosis fact from memory
    out["claims"]["s6.1"] = null_obj(
        "Supporting claims s6.2 and s6.3 are analyses of the gamete mechanism. The point itself is a general-knowledge "
        "fact about prophase I (pairing and crossing over) stated from memory.",
        "general knowledge stated from memory with no supplied text or task figure; the only encoding restates it")

    return TASK, out


# =====================================================================
# ch-e1b (Chemistry), request req-e1b
# Units: [H+] values are in units of 1e-9 mol dm^-3 (so 1.58e-8 is 15.8).
# =====================================================================
def build_ch():
    REQ = "req-e1b"
    TASK = "ch-e1b"
    spec = lambda: G("specialist_inference", "established")

    h81 = S("h81", "Real", "[H+] at pH 8.1 in units of 1e-9 mol dm-3 (specialist figure)", spec())
    h82 = S("h82", "Real", "[H+] at pH 8.2 in units of 1e-9 mol dm-3 (specialist figure)", spec())
    h78 = S("h78", "Real", "[H+] at pH 7.8 in units of 1e-9 mol dm-3 (specialist figure)", spec())
    r = S("r", "Real", "ratio [H+] at pH 8.1 divided by [H+] at pH 8.2, as stated (1.259)", spec())
    pct = S("pct", "Real", "percentage rise of [H+] from pH 8.2 to pH 8.1", spec())

    pr_h81 = A("pr_h81", AND(GE(V("h81"), R("7.9425")), LT(V("h81"), R("7.9435"))),
               "[H+] at pH 8.1 is 7.943 (4 s.f.) in units of 1e-9 mol dm-3", spec())
    pr_h82_4 = A("pr_h82", AND(GE(V("h82"), R("6.3095")), LT(V("h82"), R("6.3105"))),
                 "[H+] at pH 8.2 is 6.310 (4 s.f.) in units of 1e-9 mol dm-3", spec())
    pr_h82_3 = A("pr_h82", AND(GE(V("h82"), R("6.305")), LT(V("h82"), R("6.315"))),
                 "[H+] at pH 8.2 is 6.31 (3 s.f.) in units of 1e-9 mol dm-3", spec())
    pr_h78 = A("pr_h78", AND(GE(V("h78"), R("15.75")), LT(V("h78"), R("15.85"))),
               "[H+] at pH 7.8 is 1.58 x 10^-8 (3 s.f.), i.e. 15.8 in units of 1e-9 mol dm-3", spec())
    pr_r = A("pr_r", AND(GE(V("r"), R("1.2585")), LT(V("r"), R("1.2595"))),
             "the ratio stated in s2.1 is 1.259 (4 s.f.)", spec())
    pr_pct = A("pr_pct", EQ(V("pct"), MUL(SUB(V("r"), R("1")), R("100"))),
               "percentage rise = (ratio - 1) x 100", spec())

    out = {"report_id": "rep-ch-e1b-0", "claims": {}}

    null_reason_exp = ("exponentiation (10^(-pH)) is outside the IR allowlist, so the only encodable form is the "
                       "stated figure itself, which restates the claim")
    for cid, txt in [
        ("s1.1", "The claim is the definition [H+] = 10^(-pH) mol dm-3, a general-knowledge formula."),
        ("s1.2", "The claim gives [H+] at pH 8.2 as 10^(-8.2) = 6.31 x 10^-9 mol dm-3."),
        ("s1.3", "The claim gives [H+] at pH 8.1 as 10^(-8.1) = 7.94 x 10^-9 mol dm-3."),
        ("s5.1", "The claim gives [H+] at pH 7.8 as 10^(-7.8) = 1.58 x 10^-8 mol dm-3."),
        ("s6.2", "Supporting figure: [H+] at pH 8.2 = 6.31 x 10^-9 mol dm-3."),
        ("s6.3", "Supporting figure: [H+] at pH 8.1 = 7.94 x 10^-9 mol dm-3."),
    ]:
        reason = ("definition needs exponentiation, which is outside the IR allowlist; the definition is general "
                  "knowledge with no relation to check in the report") if cid == "s1.1" else null_reason_exp
        out["claims"][cid] = null_obj(txt + " Not encodable: " + reason + ". Figures used as premises elsewhere "
                                      "are taken as the specialist's figures in those problems.", reason)

    # s2.1 -- ratio 1.259
    out["claims"]["s2.1"] = claim_obj(
        f"{TASK}-s2.1", REQ, "s2.1", [h81, h82],
        [pr_h81, pr_h82_4],
        A("concl", AND(GE(V("h81"), MUL(R("1.2585"), V("h82"))), LT(V("h81"), MUL(R("1.2595"), V("h82")))),
          "[H+] at pH 8.1 divided by [H+] at pH 8.2 = 1.259 (to 4 s.f.)", spec()),
        "Encoded the quotient of the two stated figures, 7.943 (pH 8.1) and 6.310 (pH 8.2), each to 4 s.f. with its "
        "half-unit range, as a ratio in [1.2585, 1.2595): the claim's 1.259. The ratio is checked as a linear comparison "
        "(no division of symbols). The parenthetical '(this is 10^0.1)' is not encoded: the IR has no exponentiation, "
        "and the identity is a figure from memory.")

    # s2.2 -- percentage increase 25.9%, about 26%
    out["claims"]["s2.2"] = claim_obj(
        f"{TASK}-s2.2", REQ, "s2.2", [r, pct], [pr_r, pr_pct],
        A("concl", AND(GE(V("pct"), R("25.85")), LT(V("pct"), R("25.95")),
                       GE(V("pct"), R("25.5")), LT(V("pct"), R("26.5"))),
          "percentage increase = (1.259 - 1) x 100 = 25.9%, so about 26%", spec()),
        "Encoded (ratio - 1) x 100 with the ratio from s2.1 (1.2585 up to 1.2595). The rise is in [25.85, 25.95), which "
        "is 25.9% to 1 d.p., and in [25.5, 26.5), which is about 26% to the nearest whole percent. 'About 26%' is "
        "encoded at the integer precision written.")

    # s2.3 -- about 30% overstates
    out["claims"]["s2.3"] = claim_obj(
        f"{TASK}-s2.3", REQ, "s2.3", [r, pct], [pr_r, pr_pct],
        A("concl", LT(V("pct"), R("30")),
          "'about 30%' overstates the change: the rise is below 30%", spec(), materiality="supporting"),
        "Encoded the overstatement part of 'about 30% is not right; it overstates the change': the rise from s2.2 is "
        "below 30%. Whether 30% is 'not right' depends on a tolerance for 'about' that the report does not state; the "
        "encoding does not check that part.",
        flags=[{"code": "about-tolerance",
                "message": "'about 30%' is called not right, but no tolerance for 'about' is stated. Only the "
                           "overstatement (a rise below 30%) is encoded.",
                "alternatives": ["rise < 30%: 30% overstates the change (encoded)",
                                 "rise differs from 30% by more than an unstated tolerance (not encoded)"]}],
        ambiguous=True)

    # s2.4 -- wherever the pH starts
    out["claims"]["s2.4"] = null_obj(
        "Claim: a fall of 0.1 pH unit multiplies [H+] by 1.26 wherever the pH starts. Not encodable: 'wherever the pH "
        "starts' is a universal claim over pH values (the IR has no quantifiers) and 10^0.1 needs exponentiation.",
        "universal claim over pH values needs quantification; exponentiation is outside the IR allowlist")

    # s2.5 -- 30% rise needs a pH fall of about 0.11
    out["claims"]["s2.5"] = null_obj(
        "Claim: a 30% rise would need a pH fall of about 0.11 units. This needs log10(1.30), a logarithm, which is "
        "outside the IR allowlist.",
        "requires a logarithm (log10 of 1.30); outside the IR allowlist")

    # s2.6 -- advice
    out["claims"]["s2.6"] = null_obj(
        "Sentence 'If your teacher's source says 30%, check the exact pH values it uses.' is advice to the student, not "
        "a truth-apt claim.",
        "imperative advice, not a truth-apt claim; nothing to encode")

    # s3.1 -- chemical equilibrium
    out["claims"]["s3.1"] = null_obj(
        "Claim: CO2(g) is in equilibrium with CO2(aq). Species and reactions are not IR constructs; the only encoding "
        "would be a bare Bool restating the equilibrium from general knowledge.",
        "chemical equilibrium from general knowledge; no species or reaction construct in the IR, so the encoding "
        "would restate the claim")

    # s3.4 -- overall equation
    out["claims"]["s3.4"] = null_obj(
        "Claim: the overall equation CO2(g) + H2O(l) <-> H+(aq) + HCO3-(aq) is the sum of the three equilibria in "
        "s3.1 to s3.3. With no species or reaction constructs in the IR, the only encoding is a conjunction of Bool "
        "restatements of the parts.",
        "overall equation is a bookkeeping combination of stated equilibria with no IR construct; the encoding would "
        "restate its parts")

    # s4.1 -- carbonate equilibrium
    out["claims"]["s4.1"] = null_obj(
        "Claim: CO3^2- + H+ <-> HCO3- and the Bronsted-Lowry base role of carbonate. These are chemistry facts from "
        "general knowledge with no IR construct; the only encoding restates them.",
        "chemical equilibrium and acid-base role from general knowledge; no IR construct; the encoding would restate it")

    # s5.2 -- factor 2.5 from 1.58e-8 / 6.31e-9
    out["claims"]["s5.2"] = claim_obj(
        f"{TASK}-s5.2", REQ, "s5.2", [h78, h82], [pr_h78, pr_h82_3],
        A("concl", AND(GE(V("h78"), MUL(R("2.45"), V("h82"))), LT(V("h78"), MUL(R("2.55"), V("h82")))),
          "factor = 1.58 x 10^-8 divided by 6.31 x 10^-9 = 2.5 (to 2 s.f.)", spec(), materiality="supporting"),
        "Encoded the factor from the stated concentrations 15.8 and 6.31 (units 1e-9, 3 s.f. each) as a ratio in "
        "[2.45, 2.55): the claim's 2.5 to 2 s.f. The concentrations are the specialist's figures (their derivation "
        "needs exponentiation, so it is not checked). The parenthetical 10^(8.2 - 7.8) = 10^0.4 = 2.51 is not encoded "
        "(exponentiation).")

    # s6.4 -- rise 25.9%, about 26%, not 30%
    out["claims"]["s6.4"] = claim_obj(
        f"{TASK}-s6.4", REQ, "s6.4", [h81, h82], [pr_h81, pr_h82_4],
        A("concl", AND(GE(V("h81"), MUL(R("1.2585"), V("h82"))), LT(V("h81"), MUL(R("1.2595"), V("h82"))),
                       GE(V("h81"), MUL(R("1.255"), V("h82"))), LT(V("h81"), MUL(R("1.265"), V("h82"))),
                       NE(V("h81"), MUL(R("1.3"), V("h82")))),
          "rise in [H+] from pH 8.2 to pH 8.1 = 25.9% (about 26%), not 30%", spec(), materiality="supporting"),
        "Encoded the rise as the quotient of the stated figures: a rise of 25.9% (1 d.p.) is a ratio in [1.2585, "
        "1.2595); 'about 26%' is a ratio in [1.255, 1.265); 'not 30%' is a ratio different from 1.30. All are linear "
        "comparisons on the two figures.")

    # s6.5 -- about 2.5 times
    out["claims"]["s6.5"] = claim_obj(
        f"{TASK}-s6.5", REQ, "s6.5", [h78, h82], [pr_h78, pr_h82_3],
        A("concl", AND(GE(V("h78"), MUL(R("2.45"), V("h82"))), LT(V("h78"), MUL(R("2.55"), V("h82")))),
          "[H+] at pH 7.8 is about 2.5 times the value at pH 8.2 (to 2 s.f.)", spec()),
        "Encoded the claim as a ratio of the two specialist figures (pH 7.8: 15.8; pH 8.2: 6.31, in units 1e-9) lying "
        "in [2.45, 2.55). The figures are the specialist's (s5.1 and s6.2), so the check is of the arithmetic, not of "
        "the pH-to-[H+] conversion.")

    return TASK, out


def main():
    os.makedirs(OUT, exist_ok=True)
    built = {}
    for fn in (build_ll, build_bi, build_ch):
        task, obj = fn()
        built[task] = obj
        with open(os.path.join(OUT, task + ".json"), "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, indent=2)
        n_claims = len(obj["claims"])
        n_enc = sum(1 for c in obj["claims"].values() if c["problem"] is not None)
        print(f"{task}: wrote {n_claims} claims, {n_enc} encoded, {n_claims - n_enc} null")
    return built


if __name__ == "__main__":
    main()
