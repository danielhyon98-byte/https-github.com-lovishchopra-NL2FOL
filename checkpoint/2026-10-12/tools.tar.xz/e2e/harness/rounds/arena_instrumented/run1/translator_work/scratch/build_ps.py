"""Translations for ps-e1 (Psychology: stress and memory study, Paper 2 Section B)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *  # noqa: E402,F401,F403

PS = "doc-stress-study"
SI = G("specialist_inference", "established")
SIP = G("specialist_inference", "probable")
GK = G("general_knowledge", "established")


def q(excerpt):
    return G("quotation", "established", [(PS, excerpt)])


def build_ps(docs):
    REQ = "req-ps-e1"
    out = {}

    # ---- shared quotations and figures ----
    rand = S("rand", "Bool", "participants were randomly allocated to one of two conditions",
             q("Participants were randomly allocated to one of two conditions"))
    manip = S("manip", "Bool", "the stress condition was told of a shortly upcoming speech that would be filmed and judged (the manipulation)",
              q("told that they would shortly give a five-minute speech that would be filmed and judged by a panel"))
    mean_s = S("mean_stress", "Real", "mean words recalled in the stress condition", q("recalled a mean of 8.6 words"))
    mean_c = S("mean_control", "Real", "mean words recalled in the control condition", q("recalled a mean of 11.2 words"))
    pr_rand = A("pr_rand", V("rand"), "participants were randomly allocated to one of two conditions", rand["grounding"])
    pr_manip = A("pr_manip", V("manip"), "the stress condition was told of an upcoming judged speech", manip["grounding"])
    pr_ms = A("pr_ms", EQ(V("mean_stress"), R("8.6")), "the stress condition recalled a mean of 8.6 words", mean_s["grounding"])
    pr_mc = A("pr_mc", EQ(V("mean_control"), R("11.2")), "the control condition recalled a mean of 11.2 words", mean_c["grounding"])
    gap = S("gap", "Real", "control mean minus stress mean (words)", GK)
    d_gap = A("def_gap", EQ(V("gap"), SUB(V("mean_control"), V("mean_stress"))), "the gap is the control mean minus the stress mean", GK)
    general = S("general_stress", "Bool", "stress impairs memory in general", SI)
    one_delay = S("one_delay", "Bool", "recall is measured after one 10-minute delay",
                  q("after a 10-minute delay"))

    # g2.1 -- the study supports a causal claim about anticipation, not the general claim that stress impairs memory
    causal_anticip = S("causal_anticip", "Bool", "the study supports a causal claim: anticipating a judged speech lowers recall in these 48 students", SI)
    out["g2.1@psychology-specialist"] = problem(
        "ps-g2-1", REQ, "g2.1@psychology-specialist",
        [rand, manip, mean_s, mean_c, causal_anticip, general],
        [pr_rand, pr_manip, pr_ms, pr_mc,
         A("link_causal", IMP(AND(V("rand"), LT(V("mean_stress"), V("mean_control"))), V("causal_anticip")),
           "random allocation with lower recall in the stress condition supports a causal claim about anticipation", SI),
         A("link_scope", IMP(V("manip"), NOT(V("general_stress"))),
           "the manipulation is an anticipated speech, not stress itself, so the general claim is not supported", SI)],
        A("concl", AND(V("causal_anticip"), NOT(V("general_stress"))),
          "The study supports a causal claim about anticipating a judged speech and recall of words in these 48 students, but not the general claim that stress impairs memory.", SI),
        reading="The judgement has two parts: a causal claim about anticipation (supported by random allocation and the lower stress "
                "mean) and a denial of the general claim (the manipulation is anticipation, not stress). Both links are the "
                "specialist's; the means are quoted.")

    # g3.1 -- causal claim plausible but narrow
    causal_plaus = S("causal_plausible", "Bool", "random allocation and manipulation make a causal claim about the condition plausible", SIP)
    narrow = S("narrow", "Bool", "the causal claim is narrow: it concerns the condition, not stress in general", SIP)
    out["g3.1@psychology-specialist"] = problem(
        "ps-g3-1", REQ, "g3.1@psychology-specialist",
        [rand, manip, causal_plaus, narrow],
        [pr_rand, pr_manip,
         A("link_plaus", IMP(AND(V("rand"), V("manip")), V("causal_plausible")),
           "random allocation and manipulation make a causal claim about the condition plausible", SIP),
         A("link_narrow", IMP(V("manip"), V("narrow")),
           "the manipulated variable is the anticipated speech, so the causal claim is narrow", SIP)],
        A("concl", AND(V("causal_plausible"), V("narrow")),
          "Unit 1 (causality), claim: random allocation and manipulation make a causal claim about the condition plausible, but a narrow one.", SIP),
        reading="Plausibility follows from random allocation and manipulation; narrowness follows from what was manipulated. Both "
                "are the specialist's judgements at probable certainty.")

    # g5.2 -- the gap is more plausibly due to the condition than to differences between people
    spread = S("spread", "Bool", "differences between people, such as vocabulary or motivation, are spread across both groups", SIP)
    due = S("due_condition", "Bool", "the gap in recall is more plausibly due to the condition than to differences between people", SIP)
    out["g5.2@psychology-specialist"] = problem(
        "ps-g5-2", REQ, "g5.2@psychology-specialist",
        [rand, mean_s, mean_c, gap, spread, due],
        [pr_rand, pr_ms, pr_mc, d_gap,
         A("link_spread", IMP(V("rand"), V("spread")), "random allocation spreads differences between people across both groups", SIP),
         A("link_due", IMP(AND(V("spread"), LT(V("mean_stress"), V("mean_control"))), V("due_condition")),
           "with differences spread, the lower stress mean is more plausibly due to the condition", SIP)],
        A("concl", AND(EQ(V("gap"), R("2.6")), V("due_condition")),
          "Because participants were allocated at random, differences should be spread across both groups, so the gap in recall (8.6 against 11.2 words) is more plausibly due to the condition than to differences between people.", SIP),
        reading="The gap of 2.6 words is computed from the two quoted means. The chain (randomisation spreads differences, so the gap "
                "is more plausibly due to the condition) is the specialist's, at probable certainty as the hedged wording states.")

    # g5.3 -- no standard deviations and no test, so the gap cannot be shown to exceed chance
    no_sd = S("no_sd_or_test", "Bool", "the supplied text reports no standard deviations and no statistical test",
              G("supplied_text", "established", note="a fact about what the supplied text does not contain"))
    beyond = S("beyond_chance", "Bool", "the text shows the 2.6-word gap is more than chance variation", SI)
    out["g5.3@psychology-specialist"] = problem(
        "ps-g5-3", REQ, "g5.3@psychology-specialist",
        [mean_s, mean_c, gap, no_sd, beyond],
        [pr_ms, pr_mc, d_gap,
         A("pr_no_sd", V("no_sd_or_test"), "the text reports no standard deviations and no statistical test",
           no_sd["grounding"]),
         A("link_chance", IMP(V("no_sd_or_test"), NOT(V("beyond_chance"))),
           "without standard deviations or a test, the text cannot show the gap is more than chance", SI)],
        A("concl", AND(EQ(V("gap"), R("2.6")), NOT(V("beyond_chance"))),
          "However, the text reports no standard deviations and no statistical test, so it cannot show that a 2.6-word gap between two groups of 24 is more than chance variation.", SI),
        reading="The absence of any spread or test is a fact about the supplied text; the step from that absence to 'cannot show "
                "more than chance' is the specialist's. The gap is computed from the two means.")

    # g6.5 -- the outcome is a count (objective), but narrow: one list of 20 words, one delay
    count_w = S("count_words", "Bool", "recall is measured as a count of words written down",
                q("wrote down as many words as they could recall"))
    list20 = S("list_20", "Bool", "participants studied one list of 20 words", q("studied a list of 20 words"))
    objective = S("objective", "Bool", "the outcome is objective", SIP)
    narrow2 = S("narrow_outcome", "Bool", "the outcome measure is narrow: one list and one delay", SIP)
    out["g6.5@psychology-specialist"] = problem(
        "ps-g6-5", REQ, "g6.5@psychology-specialist",
        [count_w, list20, one_delay, objective, narrow2],
        [A("pr_count", V("count_words"), "recall is a count of the words written down", count_w["grounding"]),
         A("pr_list", V("list_20"), "one list of 20 words was studied", list20["grounding"]),
         A("pr_delay", V("one_delay"), "one 10-minute delay was used", one_delay["grounding"]),
         A("link_obj", IMP(V("count_words"), V("objective")), "a count of words is an objective outcome", SIP),
         A("link_narrow", IMP(AND(V("list_20"), V("one_delay")), V("narrow_outcome")),
           "one list and one delay make the outcome narrow", SIP)],
        A("concl", AND(V("objective"), V("narrow_outcome")),
          "The outcome is also objective, a count of words recalled, but it is narrow: one list of 20 words and one 10-minute delay.", SIP),
        reading="Objectivity and narrowness are the specialist's evaluations of the quoted measure; the quoted facts are the list, "
                "the delay and the counting method.")

    # g6.7 -- lower recall after one delay, not impaired memory in general
    lower = S("lower_recall", "Bool", "recall in the stress condition is lower after one delay", SI)
    out["g6.7@psychology-specialist"] = problem(
        "ps-g6-7", REQ, "g6.7@psychology-specialist",
        [mean_s, mean_c, lower, one_delay, general],
        [pr_ms, pr_mc,
         A("def_lower", IFF(V("lower_recall"), LT(V("mean_stress"), V("mean_control"))),
           "lower recall means the stress mean is below the control mean", GK),
         A("pr_delay", V("one_delay"), "recall is measured after one 10-minute delay", one_delay["grounding"]),
         A("link_general", IMP(AND(V("lower_recall"), V("one_delay")), NOT(V("general_stress"))),
           "lower recall after one delay shows lower recall of a word list, not impaired memory in general", SI)],
        A("concl", AND(V("lower_recall"), NOT(V("general_stress"))),
          "The result therefore shows lower recall of a word list after one delay, not impaired memory in general.", SI),
        reading="The lower stress mean is computed from the quoted means; the step to 'lower recall after one delay, not impaired "
                "memory in general' is the specialist's.")

    # g7.1 -- the researchers' conclusion goes further than the design allows
    concl_q = S("concluded", "Bool", "the researchers concluded that stress impairs memory",
                q("The researchers concluded that stress impairs memory"))
    sep = S("design_separates", "Bool", "the design separates stress from attention and tests several kinds of memory across several delays", SIP)
    goes = S("goes_further", "Bool", "the researchers' conclusion goes further than the design allows", SIP)
    out["g7.1@psychology-specialist"] = problem(
        "ps-g7-1", REQ, "g7.1@psychology-specialist",
        [concl_q, sep, goes],
        [A("pr_concl", V("concluded"), "the researchers concluded that stress impairs memory", concl_q["grounding"]),
         A("pr_sep", NOT(V("design_separates")),
           "the design does not separate stress from attention or test several kinds of memory and delays", SIP),
         A("link_goes", IMP(AND(V("concluded"), NOT(V("design_separates"))), V("goes_further")),
           "a stress-impairs-memory conclusion from this design goes beyond it", SIP)],
        A("concl", V("goes_further"),
          "The researchers concluded that stress impairs memory, which goes further than the design allows.", SIP),
        reading="The conclusion is the second part of the claim (the goes-further judgement). The first part, that the researchers "
                "concluded it, is the quoted premise and is not repeated as a conjunct.")

    # g8.1 -- 2.6 / 8.6 = 0.30 is correct arithmetic, but 8.6 is the wrong base
    ratio_s = S("ratio_stress_base", "Real", "2.6 divided by the stress mean (8.6)", SI)
    control_base = S("control_base", "Bool", "the gap should be measured against the control mean", SIP)
    wrong_base = S("wrong_base", "Bool", "8.6 is the wrong base for the percentage gap", SIP)
    out["g8.1@psychology-specialist"] = problem(
        "ps-g8-1", REQ, "g8.1@psychology-specialist",
        [mean_s, mean_c, gap, ratio_s, control_base, wrong_base],
        [pr_ms, pr_mc, d_gap,
         A("def_ratio_s", EQ(MUL(V("ratio_stress_base"), R("8.6")), V("gap")),
           "the ratio times the stress mean 8.6 equals the gap", GK),
         A("pr_base", V("control_base"), "the gap should be measured against the control mean", SIP),
         A("link_wrong", IMP(V("control_base"), V("wrong_base")), "if the control mean is the base, the stress mean is the wrong base", SIP)],
        A("concl", AND(GE(V("ratio_stress_base"), R("0.295")), LT(V("ratio_stress_base"), R("0.305")), V("wrong_base")),
          "On your 30% figure: 2.6 divided by 8.6 = 0.30 is correct arithmetic, but 8.6 is the wrong base.", SIP),
        reading="The arithmetic 2.6 / 8.6 is encoded from the quoted means as an interval for 0.30 (two decimals). The 'wrong base' "
                "is the consequence of the specialist's base judgement, which is an assumption-level premise.",
        ambiguous=True,
        flags=[flag("base_choice", "the choice of base for a percentage gap is a method judgement, not a figure",
                    ["the control mean is the base (as the specialist states)", "the stress mean is the base (the student's choice)"])])

    # g8.2 -- 2.6 / 11.2 = 0.23, about 23% lower
    ratio_c = S("ratio_control_base", "Real", "2.6 divided by the control mean (11.2)", SI)
    out["g8.2@psychology-specialist"] = problem(
        "ps-g8-2", REQ, "g8.2@psychology-specialist",
        [mean_s, mean_c, gap, ratio_c, control_base],
        [pr_ms, pr_mc, d_gap,
         A("def_ratio_c", EQ(MUL(V("ratio_control_base"), R("11.2")), V("gap")),
           "the ratio times the control mean 11.2 equals the gap", GK),
         A("pr_base", V("control_base"), "the gap should be measured against the control mean (the specialist's method choice)",
           G("assumption", "probable", note="a methodological choice stated by the specialist; not part of the arithmetic checked here"))],
        A("concl", AND(GE(V("ratio_control_base"), R("0.225")), LT(V("ratio_control_base"), R("0.235"))),
          "The gap should be measured against the control mean, so 2.6 divided by 11.2 = 0.23: recall in the stress condition was about 23% lower than in the control condition.", SIP),
        reading="The arithmetic 2.6 / 11.2 is checked as the interval for 0.23 (two decimals). 'About 23%' has no stated precision "
                "and is read as the same interval; the choice of base is carried as an assumption premise, not in the conclusion.",
        ambiguous=True,
        flags=[flag("about_23", "'about 23%' gives no stated precision, and the base choice is a method judgement",
                    ["0.23 to two decimals (encoded)", "about 23% to the nearest whole percent (22.5 to 23.5%)"])])

    # g8.3 -- 30% is correct only for the reverse statement
    rev_pct = S("rev_pct", "Real", "percentage by which the control mean exceeds the stress mean, relative to the stress mean", SI)
    drop_pct = S("drop_pct", "Real", "percentage by which the stress mean falls below the control mean, relative to the control mean", SI)
    out["g8.3@psychology-specialist"] = problem(
        "ps-g8-3", REQ, "g8.3@psychology-specialist",
        [mean_s, mean_c, gap, rev_pct, drop_pct],
        [pr_ms, pr_mc, d_gap,
         A("def_rev", EQ(MUL(V("rev_pct"), R("8.6")), MUL(R("100"), V("gap"))),
           "the reverse percentage times the stress mean equals 100 times the gap", GK),
         A("def_drop", EQ(MUL(V("drop_pct"), R("11.2")), MUL(R("100"), V("gap"))),
           "the forward percentage times the control mean equals 100 times the gap", GK)],
        A("concl", AND(GE(V("rev_pct"), R("29.5")), LT(V("rev_pct"), R("30.5")), LT(V("drop_pct"), R("29.5"))),
          "Your 30% is correct only for the reverse statement, that the control group recalled about 30% more words than the stress group.", SI),
        reading="The reverse figure (control above stress, over the stress mean) is 30.2%, encoded for 'about 30%' as [29.5, 30.5). "
                "The forward figure (stress below control, over the control mean) is 23.2%, so the 30% is not the forward figure.",
        ambiguous=True,
        flags=[flag("about_30", "'about 30%' gives no stated precision",
                    ["30% to the nearest whole percent (encoded)", "a looser figure"])])

    # ---- null: restatements, a superlative with no scale, and descriptions of the study ----
    out["g3.2@psychology-specialist"] = null(
        "The claim lists the two randomly allocated groups of 24 and the two means; all are supplied facts restated.",
        "a restatement of supplied facts (groups, means) with no inference to check")
    out["g3.6@psychology-specialist"] = null(
        "The claim lists the cortisol result and the recall measure; both are supplied facts restated.",
        "a restatement of supplied facts (cortisol, count of words) with no inference to check")
    out["g4.1@psychology-specialist"] = null(
        "The claim describes the study design, restating the supplied description of the allocation and the speech condition.",
        "a description of the study design that restates supplied facts; the inference is in g4.2 and g4.3")
    out["g5.1@psychology-specialist"] = null(
        "The claim calls random allocation the strongest feature, a superlative over design features with no ranking or scale.",
        "a superlative judgement over design features with no defined comparison set or scale to check")
    out["g6.1@psychology-specialist"] = null(
        "The claim says measurement is where the claim about stress is most exposed, a superlative over aspects of the study with no defined comparison set.",
        "a superlative judgement over study aspects with no defined comparison set or scale to check")

    return out


if __name__ == "__main__":
    run_task("ps-e1", "rep-ps-e1-0", build_ps)
