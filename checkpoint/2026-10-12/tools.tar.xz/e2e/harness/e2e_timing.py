#!/usr/bin/env python3
"""End-to-end pipeline timing harness for one simulated round on the frozen translator tree.

Run with the e2e venv interpreter in isolated mode:  <venv>/bin/python -I -B e2e_timing.py [--round DIR] [--out DIR]

The frozen tree is never modified: the round is copied before the arena runs on it (the arena writes results.json and
summary.md into its round directory), every interpreter runs with -B (no bytecode written into the tree), and the
in-process leg only wraps functions in this process to time them (each wrapper delegates and returns the original
result unchanged; the in-process results.json is compared with the subprocess one to show it).

Legs
  0  inputs     every routed task of <round>/tasks.json has its specialist answer, translation fixtures and synthesis
                (sixteen specialists are expected: a smaller count is reported as a reduced round, never passed over)
  1  service    the Z3 verification service started exactly as shipped (`python -m epinoic_logic.cli serve`, settings
                from EPINOIC_* environment variables: a test bearer token and a test signing key) on 127.0.0.1;
                health, auth refusal, verify and signature round trips, as the website's backend would call it
  2a arena      `python -I -B scripts/arena/run_arena.py <copy of the round>` in a subprocess, exactly as documented:
                total wall time and each record's own latency (the only per-task timing that tooling gives)
  2b arena      the same run_round in this process on a second copy with timing wrappers, for per-task stage
                timings (request validation, routing, channel, translator, engine, peer relay, synthesis)
  3  http       every engine problem of the genuine pass (each translated claim's IR problem, and the channel's own
                formal checks) sent to the running service over HTTP; latency p50/p95/max; HTTP vs in-process equality
  4  gate       the student-facing response gate per request
  5  output     <out>/timings.json and <out>/gate.json
"""
from __future__ import annotations

import argparse
import copy
import importlib
import inspect
import json
import os
import platform
import re
import secrets
import shutil
import socket
import statistics
import subprocess
import sys
import time
import traceback
from collections import defaultdict
from pathlib import Path
from typing import Any, Optional

HERE = Path(__file__).resolve().parent
E2E = HERE.parent

ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
ap.add_argument("--tree", default=str(E2E / "tree"))
ap.add_argument("--round", default=str(E2E / "run1"))
ap.add_argument("--out", default=str(HERE))
ap.add_argument("--expected-specialists", type=int, default=16)
ARGS = ap.parse_args()
TREE = Path(ARGS.tree).resolve()
ROUND = Path(ARGS.round).resolve()
OUT = Path(ARGS.out).resolve()
PY = sys.executable
ARENA_DIR = TREE / "scripts" / "arena"
sys.path.insert(0, str(ARENA_DIR))  # as run_arena.py itself does for stem_mutations

import httpx  # noqa: E402

import run_arena  # noqa: E402  (the arena module of the frozen tree)
from epinoic_logic import version as ep_version  # noqa: E402
from epinoic_logic.branches import RouterHub  # noqa: E402
from epinoic_logic.channel import TransmissionStatus  # noqa: E402
from epinoic_logic.channel.bus import TranslatorChannel  # noqa: E402
from epinoic_logic.engine.provenance import z3_version  # noqa: E402
from epinoic_logic.engine.results import SolverConfig, VerificationResult  # noqa: E402
from epinoic_logic.engine.runner import verify as engine_verify_direct  # noqa: E402
from epinoic_logic.engine.statuses import DEFINITIVE, VerificationStatus  # noqa: E402
from epinoic_logic.integrity import AgentRole  # noqa: E402
from epinoic_logic.ir.canonical import problem_digest  # noqa: E402
from epinoic_logic.ir.schema import DEFAULT_LIMITS, Problem  # noqa: E402

BUDGET_S = 240.0          # the four-minute translation budget
DELIVERY_THRESHOLD = 0.90  # a candidate is delivered (unverified) only above this accuracy
BUGS: list[dict] = []
NOTES: list[str] = []


def bug(kind: str, title: str, repro: str, detail: Any = None) -> None:
    BUGS.append({"kind": kind, "title": title, "repro": repro, **({"detail": detail} if detail is not None else {})})


def pct(values: list[float], q: float) -> Optional[float]:
    """Nearest-rank percentile (q in 0..100) of ``values``; None when empty."""
    if not values:
        return None
    s = sorted(values)
    k = max(1, int(-(-q * len(s) // 100)))  # ceil(q/100 * n), at least 1
    return s[min(k, len(s)) - 1]


def lat_stats(ms: list[float]) -> dict:
    return {"n": len(ms), "p50_ms": pct(ms, 50), "p95_ms": pct(ms, 95), "max_ms": max(ms) if ms else None,
            "mean_ms": statistics.fmean(ms) if ms else None, "total_s": sum(ms) / 1000.0}


def rnd(x: Optional[float], n: int = 6) -> Optional[float]:
    return None if x is None else round(x, n)


# ============================================================================ leg 0: inputs
def check_inputs() -> dict:
    t0 = time.perf_counter()
    tasks = json.loads((ROUND / "tasks.json").read_text())
    spec_dir, tr_dir, syn_dir = ROUND / "specialists", ROUND / "translations", ROUND / "syntheses"
    specs = {p.stem: json.loads(p.read_text()) for p in sorted(spec_dir.glob("*.json"))}
    trs = {p.stem for p in tr_dir.glob("*.json")}
    syns = {p.stem for p in syn_dir.glob("*.json")}
    problems = []
    for t in tasks:
        tid = t["task_id"]
        s = specs.get(tid)
        if s is None:
            problems.append(f"{tid}: no specialist answer")
            continue
        for k in ("subject", "agent_id", "kb", "task_type", "question"):
            if s.get(k) != t.get(k):
                problems.append(f"{tid}: specialist file {k} {s.get(k)!r} differs from the routed task's {t.get(k)!r}")
        if not s.get("response_text"):
            problems.append(f"{tid}: empty response_text")
        if tid not in trs:
            problems.append(f"{tid}: no translation fixtures")
        if tid not in syns:
            problems.append(f"{tid}: no synthesis")
    extra = sorted(set(specs) - {t["task_id"] for t in tasks})
    agents = sorted({t["agent_id"] for t in tasks})
    kbs = sorted({t["kb"] for t in tasks})
    # the website requests (inputs.md tables): request number -> title and routed tasks
    requests: dict[str, dict] = {}
    inputs_md = ROUND / "inputs.md"
    if inputs_md.exists():
        for line in inputs_md.read_text().splitlines():
            m = re.match(r"^\| (\d+) \| ([^|]+?) \| ([^|]+?) \| (.+) \|$", line)
            if m:
                tids = list(dict.fromkeys(re.findall(r"`([a-z]+-[a-z0-9]+)`", m.group(4))))
                requests[m.group(1)] = {"request": int(m.group(1)), "title": m.group(2).strip(), "path": m.group(3).strip(), "tasks": tids}
    routed_in_requests = sorted({x for r in requests.values() for x in r["tasks"]})
    out = {"round": ROUND.name, "routed_tasks": len(tasks), "specialist_answers": len(specs), "translations": len(trs), "syntheses": len(syns),
           "distinct_specialist_agents": len(agents), "distinct_kbs": len(kbs), "kbs": kbs, "agents": agents,
           "website_requests": len(requests), "tasks_named_by_requests": len(routed_in_requests),
           "expected_specialists": ARGS.expected_specialists, "problems": problems, "unrouted_specialist_files": extra,
           "check_s": time.perf_counter() - t0}
    if len(agents) < ARGS.expected_specialists or len(tasks) < ARGS.expected_specialists:
        bug("inconsistency", f"round carries {len(agents)} specialists / {len(tasks)} routed tasks, fewer than the {ARGS.expected_specialists} expected",
            f"python -I -c \"import json; print(len(json.load(open('{ROUND}/tasks.json'))))\"")
    if problems:
        bug("inconsistency", "routed tasks and specialist inputs disagree", f"see inputs.problems in timings.json ({ROUND})", problems)
    if set(routed_in_requests) != {t["task_id"] for t in tasks}:
        bug("inconsistency", "inputs.md requests do not name exactly the routed tasks of tasks.json", f"{inputs_md}",
            {"only_in_requests": sorted(set(routed_in_requests) - {t['task_id'] for t in tasks}), "only_in_tasks": sorted({t['task_id'] for t in tasks} - set(routed_in_requests))})
    return {"summary": out, "tasks": tasks, "requests": requests}


# ============================================================================ leg 1: service
class Service:
    def __init__(self) -> None:
        s = socket.socket()
        s.bind(("127.0.0.1", 0))
        self.port = s.getsockname()[1]
        s.close()
        self.token = "e2e-test-token-" + secrets.token_hex(16)
        self.key_hex = secrets.token_hex(32)
        self.key = bytes.fromhex(self.key_hex)
        self.key_id = "e2e-test-key"
        self.base = f"http://127.0.0.1:{self.port}"
        self.proc: Optional[subprocess.Popen] = None
        self.log_path = OUT / "service.log"
        self.client: Optional[httpx.Client] = None
        self.n = 0

    def start(self) -> dict:
        env = dict(os.environ)
        env.update({"EPINOIC_SERVICE_TOKEN": self.token, "EPINOIC_SIGNING_KEY": self.key_hex, "EPINOIC_SIGNING_KEY_ID": self.key_id,
                    # a test-only rate: the default 60/min per token would answer 429 to a whole round sent in seconds
                    "EPINOIC_RATE_PER_MINUTE": "100000"})
        cmd = [PY, "-I", "-B", "-m", "epinoic_logic.cli", "serve", "--host", "127.0.0.1", "--port", str(self.port)]
        self.logf = open(self.log_path, "w")
        t0 = time.perf_counter()
        self.proc = subprocess.Popen(cmd, env=env, stdout=self.logf, stderr=subprocess.STDOUT, cwd=str(OUT))
        self.client = httpx.Client(base_url=self.base, timeout=httpx.Timeout(120.0))
        health = None
        while time.perf_counter() - t0 < 60:
            if self.proc.poll() is not None:
                break
            try:
                r = self.client.get("/healthz")
                if r.status_code == 200:
                    health = r.json()
                    break
            except httpx.TransportError:
                pass
            time.sleep(0.05)
        startup = time.perf_counter() - t0
        if health is None:
            raise RuntimeError(f"service did not become healthy in {startup:.1f}s (exit code {self.proc.poll()}); see {self.log_path}")
        return {"command": " ".join(["<venv python>", *cmd[1:]]), "env": ["EPINOIC_SERVICE_TOKEN (test token)", "EPINOIC_SIGNING_KEY (test key)",
                                                                           f"EPINOIC_SIGNING_KEY_ID={self.key_id}", "EPINOIC_RATE_PER_MINUTE=100000"],
                "bind": "127.0.0.1 (ephemeral port)", "startup_s": startup, "healthz": health}

    def headers(self, auth: bool = True, token: Optional[str] = None) -> dict:
        self.n += 1
        h = {"X-Request-Id": f"e2e-{self.n}", "Content-Type": "application/json"}
        if auth:
            h["Authorization"] = f"Bearer {token or self.token}"
        return h

    def post(self, path: str, body: Any, auth: bool = True, token: Optional[str] = None) -> tuple[int, Any, float]:
        data = json.dumps(body, ensure_ascii=False).encode("utf-8")
        t0 = time.perf_counter()
        r = self.client.post(path, content=data, headers=self.headers(auth, token))
        ms = (time.perf_counter() - t0) * 1000.0
        try:
            payload = r.json()
        except ValueError:
            payload = r.text
        return r.status_code, payload, ms

    def stop(self) -> dict:
        out = {}
        if self.client is not None:
            self.client.close()
        if self.proc is not None:
            self.proc.terminate()
            try:
                out["exit_code"] = self.proc.wait(timeout=15)
            except subprocess.TimeoutExpired:
                self.proc.kill()
                out["exit_code"] = self.proc.wait(timeout=5)
                out["killed"] = True
            out["stopped"] = True
        try:
            self.logf.close()
        except Exception:
            pass
        return out


TRANSITIVITY = {"ir_version": "1.0", "problem_id": "p1", "request_id": "req1", "claim_id": "c1", "query": "entailment",
                "symbols": [{"name": "x", "sort": "Int"}, {"name": "y", "sort": "Int"}, {"name": "z", "sort": "Int"}],
                "premises": [{"id": "P1", "expr": {"op": "gt", "left": {"op": "var", "name": "x"}, "right": {"op": "var", "name": "y"}}},
                             {"id": "P2", "expr": {"op": "gt", "left": {"op": "var", "name": "y"}, "right": {"op": "var", "name": "z"}}}],
                "conclusion": {"id": "C", "expr": {"op": "gt", "left": {"op": "var", "name": "x"}, "right": {"op": "var", "name": "z"}}}}


def service_round_trip(svc: Service) -> dict:
    out: dict[str, Any] = {}
    expected_versions = {"ir_version": ep_version.IR_VERSION, "engine_version": ep_version.ENGINE_VERSION, "policy_version": ep_version.POLICY_VERSION,
                         "translator_version": ep_version.TRANSLATOR_VERSION, "z3_version": z3_version()}
    t0 = time.perf_counter()
    r = svc.client.get("/healthz", headers={"X-Request-Id": "e2e-health"})
    out["healthz"] = {"http": r.status_code, "ms": (time.perf_counter() - t0) * 1000.0, "ok": r.json().get("ok"), "versions_match_in_process": r.json().get("versions") == expected_versions}
    code, body, ms = svc.post("/v1/verify", {"problem": TRANSITIVITY}, auth=False)
    out["verify_without_token"] = {"http": code, "code": body.get("code") if isinstance(body, dict) else None, "ms": ms}
    code, body, ms = svc.post("/v1/verify", {"problem": TRANSITIVITY}, token="wrong-token-" + secrets.token_hex(8))
    out["verify_wrong_token"] = {"http": code, "code": body.get("code") if isinstance(body, dict) else None, "ms": ms}
    code, body, ms = svc.post("/v1/verify", {"problem": TRANSITIVITY})
    local = engine_verify_direct(TRANSITIVITY)
    out["verify_transitivity"] = {"http": code, "ms": ms, "status": body.get("status") if isinstance(body, dict) else None,
                                  "signed": bool(isinstance(body, dict) and body.get("signature")), "signature_key_id": body.get("signature_key_id") if isinstance(body, dict) else None,
                                  "in_process_status": local.status.value,
                                  "problem_digest_equal": isinstance(body, dict) and body.get("binding", {}).get("problem_digest") == local.binding.problem_digest}
    if code == 200:
        c2, b2, ms2 = svc.post("/v1/results/verify-signature", {"result": body})
        tampered = dict(body, status="COUNTEREXAMPLE")
        c3, b3, ms3 = svc.post("/v1/results/verify-signature", {"result": tampered})
        out["signature_round_trip"] = {"http": c2, "valid": b2.get("valid") if isinstance(b2, dict) else None, "ms": ms2}
        out["signature_tampered"] = {"http": c3, "valid": b3.get("valid") if isinstance(b3, dict) else None, "reason": b3.get("reason") if isinstance(b3, dict) else None, "ms": ms3}
    ok = (out["healthz"]["http"] == 200 and out["healthz"]["versions_match_in_process"] and out["verify_without_token"]["http"] == 401
          and out["verify_wrong_token"]["http"] == 401 and out["verify_transitivity"]["status"] == "ENTAILED" and out["verify_transitivity"]["signed"]
          and out.get("signature_round_trip", {}).get("valid") is True and out.get("signature_tampered", {}).get("valid") is False)
    out["all_ok"] = bool(ok)
    if not ok:
        bug("inconsistency", "service health/verify round trip did not behave as documented", "see service.round_trip in timings.json", out)
    return out


# ============================================================================ leg 2a: arena in a subprocess
def fresh_copy(dest: Path) -> Path:
    if dest.exists():
        shutil.rmtree(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(ROUND, dest, ignore=shutil.ignore_patterns("results.json", "summary.md", "__pycache__"))
    return dest


def arena_subprocess() -> dict:
    copy_dir = fresh_copy(OUT / "rounds" / "arena_subprocess" / ROUND.name)
    cmd = [PY, "-I", "-B", str(ARENA_DIR / "run_arena.py"), str(copy_dir)]
    t0 = time.perf_counter()
    proc = subprocess.run(cmd, cwd=str(OUT), capture_output=True, text=True, timeout=3600)
    wall = time.perf_counter() - t0
    (OUT / "arena_subprocess.stdout.txt").write_text(proc.stdout + ("\n--- stderr ---\n" + proc.stderr if proc.stderr else ""))
    res_path = copy_dir / "results.json"
    if proc.returncode != 0 or not res_path.exists():
        bug("crash", f"run_arena.py exited {proc.returncode}", " ".join(["<venv python>", "-I", "-B", str(ARENA_DIR / 'run_arena.py'), "<copy of the round>"]), proc.stderr[-3000:])
        return {"wall_s": wall, "returncode": proc.returncode, "results": None}
    return {"wall_s": wall, "returncode": proc.returncode, "results": json.loads(res_path.read_text()), "dir": str(copy_dir)}


# ============================================================================ leg 2b: arena in-process, instrumented
class Bucket:
    __slots__ = ("task", "variant", "stage", "engine_s", "engine_n", "translator_s", "claims")

    def __init__(self, task: str, variant: str, stage: str) -> None:
        self.task, self.variant, self.stage = task, variant, stage
        self.engine_s = 0.0
        self.engine_n = 0
        self.translator_s = 0.0
        self.claims = 0


STACK: list[Bucket] = []
STATS: dict[tuple[str, str], dict[str, float]] = defaultdict(lambda: defaultdict(float))
ENGINE_CALLS: list[dict] = []
OUTCOMES: list[tuple[str, str, Any]] = []
REQ_RECEIPTS: dict[str, Any] = {}
RECEIPTS: dict[str, Any] = {}
REPLIES: dict[str, Any] = {}
PEER_RECORDS: dict[str, dict] = {}
SYN_RECORDS: dict[str, dict] = {}
CH_HUB: dict[int, Any] = {}
GROUP_CHANNELS: dict[str, Any] = {}
SEEN_GROUPS: set[str] = set()
UNATTRIBUTED = {"engine_s": 0.0, "engine_n": 0}
STATE = {"item": None}
AGENT_TO_TASK: dict[str, str] = {}
TEXT_TO_TASK: dict[str, str] = {}
GROUP_FIRST_TASK: dict[str, str] = {}
PATCHES: list[tuple[Any, str, Any]] = []


def patch(owner: Any, name: str, new: Any) -> None:
    PATCHES.append((owner, name, getattr(owner, name)))
    setattr(owner, name, new)


def unpatch_all() -> None:
    while PATCHES:
        owner, name, orig = PATCHES.pop()
        setattr(owner, name, orig)


def key_variant(key: Any) -> str:
    return key.split("::", 1)[1] if isinstance(key, str) and "::" in key else "genuine"


def channel_key(ch: Any) -> Optional[str]:
    hub = CH_HUB.get(id(ch))
    if hub is None:
        return None
    return next((k for k, v in hub.channels.items() if v is ch), None)


def run_in(bucket: Bucket, stat: str, fn, *a, **k):
    STACK.append(bucket)
    t0 = time.perf_counter()
    try:
        return fn(*a, **k)
    finally:
        dt = time.perf_counter() - t0
        STACK.pop()
        s = STATS[(bucket.task, bucket.variant)]
        s[stat] += dt
        s[f"{stat}.engine_s"] += bucket.engine_s
        s[f"{stat}.engine_n"] += bucket.engine_n
        s[f"{stat}.translator_s"] += bucket.translator_s
        s[f"{stat}.claims"] += bucket.claims


def install_wrappers() -> None:
    import epinoic_logic.channel.bus as bus_mod
    import epinoic_logic.integrity.cross_check as cc_mod
    import epinoic_logic.translate.outcome as outcome_mod
    import epinoic_logic.translate.pipeline as pipeline_mod

    def wrap_engine(mod, name: str, category: str) -> None:
        orig = getattr(mod, name)
        sig = inspect.signature(orig)

        def wrapped(*a, **k):
            t0 = time.perf_counter()
            res = orig(*a, **k)
            dt = time.perf_counter() - t0
            b = STACK[-1] if STACK else None
            if b is None:
                UNATTRIBUTED["engine_s"] += dt
                UNATTRIBUTED["engine_n"] += 1
                return res
            b.engine_s += dt
            b.engine_n += 1
            if b.variant == "genuine":
                ba = sig.bind(*a, **k)
                ba.apply_defaults()
                ENGINE_CALLS.append({"task": b.task, "stage": b.stage, "category": category, "problem": ba.arguments["problem_or_raw"],
                                     "config": ba.arguments["config"], "limits": ba.arguments["limits"], "signed": bool(ba.arguments["signing_key"]),
                                     "key_id": ba.arguments["key_id"], "result": res, "wall_s": dt})
            return res
        patch(mod, name, wrapped)

    wrap_engine(outcome_mod, "engine_verify", "translated_claim")
    wrap_engine(pipeline_mod, "engine_verify", "translator_probe")
    wrap_engine(bus_mod, "verify", "channel_check")
    wrap_engine(cc_mod, "verify", "cross_agent_check")

    orig_vc = run_arena.verify_claim

    def verify_claim(*a, **k):
        b = STACK[-1] if STACK else None
        e0 = b.engine_s if b else 0.0
        t0 = time.perf_counter()
        out = orig_vc(*a, **k)
        dt = time.perf_counter() - t0
        if b is not None:
            b.translator_s += dt - (b.engine_s - e0)
            b.claims += 1
            if b.variant == "genuine":
                OUTCOMES.append((b.task, b.stage, out))
        return out
    patch(run_arena, "verify_claim", verify_claim)

    orig_mutate = run_arena.mutate

    def mutate(text, kind, texts=()):
        STATE["item"] = TEXT_TO_TASK.get(text, STATE["item"])
        return orig_mutate(text, kind, texts)
    patch(run_arena, "mutate", mutate)

    orig_open = RouterHub.open_task

    def open_task(self, plan):
        group = plan.task_id
        genuine = group not in SEEN_GROUPS
        SEEN_GROUPS.add(group)
        task = GROUP_FIRST_TASK.get(group, group) if genuine else (STATE["item"] or group)
        ch = run_in(Bucket(task, "genuine" if genuine else "mutation", "open_task"), "open_task_s", orig_open, self, plan)
        CH_HUB[id(ch)] = self
        if genuine:
            GROUP_CHANNELS[group] = ch
        return ch
    patch(RouterHub, "open_task", open_task)

    orig_dispatch = RouterHub.dispatch

    def dispatch(self, task_id, to_agent_id, user_input, supplied_texts=(), *, from_agent_id="router"):
        variant = key_variant(task_id)
        task = AGENT_TO_TASK.get(to_agent_id, str(to_agent_id)) if variant == "genuine" else (STATE["item"] or AGENT_TO_TASK.get(to_agent_id, "?"))
        out = run_in(Bucket(task, variant, "dispatch"), "dispatch_s", orig_dispatch, self, task_id, to_agent_id, user_input, supplied_texts, from_agent_id=from_agent_id)
        if variant == "genuine":
            REQ_RECEIPTS[task] = out
        return out
    patch(RouterHub, "dispatch", dispatch)

    orig_receive = RouterHub.receive

    def receive(self, task_id, request_message_id, payload, *, agent_id=None, report_id=None, agent_version=None):
        variant = key_variant(task_id)
        m = re.match(r"^rep-(.+)-(\d+)$", str(report_id or ""))
        own = m.group(1) if m else AGENT_TO_TASK.get(agent_id or "", "?")
        task = own if variant == "genuine" else (STATE["item"] or own)
        stat = "receive_s" if own == task else "variant_peer_receive_s"
        out = run_in(Bucket(task, variant, "receive"), stat, orig_receive, self, task_id, request_message_id, payload,
                     agent_id=agent_id, report_id=report_id, agent_version=agent_version)
        if variant == "genuine":
            REPLIES[task], RECEIPTS[task] = out
        return out
    patch(RouterHub, "receive", receive)

    orig_rfp = run_arena.relay_from_peer

    def relay_from_peer(ch, items, item, delivered, file_name, document_text=None):
        if not item.get("peer_of"):
            return orig_rfp(ch, items, item, delivered, file_name, document_text)
        variant = key_variant(channel_key(ch))
        out = run_in(Bucket(item["task_id"], variant, "peer_relay"), "peer_relay_s", orig_rfp, ch, items, item, delivered, file_name, document_text)
        if variant == "genuine" and out[0] is not None:
            PEER_RECORDS[item["task_id"]] = out[0]
        return out
    patch(run_arena, "relay_from_peer", relay_from_peer)

    orig_syn = run_arena.synthesis_record

    def synthesis_record(ch, items, item, group, syntheses, delivered):
        rec = run_in(Bucket(item["task_id"], "genuine", "synthesis"), "synthesis_s", orig_syn, ch, items, item, group, syntheses, delivered)
        SYN_RECORDS[group] = rec
        return rec
    patch(run_arena, "synthesis_record", synthesis_record)


def arena_instrumented(tasks: list[dict]) -> dict:
    copy_dir = fresh_copy(OUT / "rounds" / "arena_instrumented" / ROUND.name)
    items = run_arena.load_items(copy_dir / "specialists")
    for it in items:
        AGENT_TO_TASK[it["agent_id"]] = it["task_id"]
        TEXT_TO_TASK[it["response_text"]] = it["task_id"]
        GROUP_FIRST_TASK.setdefault(run_arena.group_of(it), it["task_id"])
    from epinoic_logic.engine.sink import capture_results
    install_wrappers()
    t0 = time.perf_counter()
    try:
        with capture_results() as cap:
            res = run_arena.run_round(copy_dir)
    finally:
        wall = time.perf_counter() - t0
        unpatch_all()
    wrapped_calls = sum(int(v.get(f"{k}.engine_n", 0)) for v in STATS.values() for k in ("dispatch_s", "receive_s", "variant_peer_receive_s", "peer_relay_s", "synthesis_s", "open_task_s")) + UNATTRIBUTED["engine_n"]
    coverage = {"engine_runs_emitted": len(cap) + cap.overflow, "engine_runs_through_wrappers": wrapped_calls}
    coverage["every_engine_run_timed"] = coverage["engine_runs_emitted"] == wrapped_calls
    if not coverage["every_engine_run_timed"]:
        NOTES.append(f"engine runs emitted to the result sink ({coverage['engine_runs_emitted']}) differ from runs timed by the wrappers ({wrapped_calls}): some engine path is not timed")
    return {"wall_s": wall, "results": res, "items": items, "dir": str(copy_dir), "engine_coverage": coverage}


_HEX = re.compile(r"\b(?=[0-9a-f]*[a-f])[0-9a-f]{8,}\b")


def projection(results: dict) -> list:
    """What the arena decided, per record, with run-specific ids and timings folded out."""
    def fold(x):
        return _HEX.sub("<id>", json.dumps(x, sort_keys=True, default=str))
    out = []
    for r in results["records"]:
        out.append(fold({"file": r.get("file"), "variant": r.get("variant"), "functional": r.get("functional"), "status": r.get("status"), "codes": r.get("codes"),
                         "outcomes": [(o["claim_id"], o["display_status"], o.get("engine_status")) for o in r.get("outcomes", [])],
                         "formal_checks": r.get("formal_checks"), "constraints": r.get("constraints"), "coverage": r.get("coverage"),
                         "failure_reasons": r.get("failure_reasons"), "error": (r.get("error") or "")[:300]}))
    return out


def compare_arena_legs(a: dict, b: dict) -> dict:
    pa, pb = projection(a), projection(b)
    diffs = [i for i, (x, y) in enumerate(zip(pa, pb)) if x != y]
    keys = ("transmissions", "functional", "by_variant", "provider_dependent_translation_outcomes")
    same_summary = all(json.dumps(a.get(k), sort_keys=True) == json.dumps(b.get(k), sort_keys=True) for k in keys if k != "provider_dependent_translation_outcomes") and \
        a["provider_dependent_translation_outcomes"]["by_status"] == b["provider_dependent_translation_outcomes"]["by_status"]
    out = {"records_subprocess": len(pa), "records_in_process": len(pb), "records_differing": len(diffs) + abs(len(pa) - len(pb)), "summary_equal": same_summary,
           "differing_records": [{"subprocess": pa[i][:600], "in_process": pb[i][:600]} for i in diffs[:10]]}
    out["identical"] = out["records_differing"] == 0 and same_summary
    return out


# ============================================================================ leg 3: HTTP
def to_json_problem(p: Any) -> Optional[dict]:
    if isinstance(p, Problem):
        return p.model_dump(mode="json", exclude_none=True)
    if isinstance(p, dict):
        return copy.deepcopy(p)
    if isinstance(p, (str, bytes)):
        try:
            return json.loads(p)
        except ValueError:
            return None
    return None


def verified_paths(obj: Any) -> list[str]:
    found, stack = [], [(obj, "problem")]
    while stack:
        node, path = stack.pop()
        if isinstance(node, dict):
            if node.get("verified") is True:
                found.append(f"{path}.verified")
            stack += [(v, f"{path}.{k}") for k, v in node.items() if isinstance(v, (dict, list))]
        elif isinstance(node, list):
            stack += [(v, f"{path}[{i}]") for i, v in enumerate(node) if isinstance(v, (dict, list))]
    return sorted(found)


def sanitize(obj: Any) -> Any:
    """What a backend must do before posting a problem: an asserted grounding.verified=true is reset to null (unchecked),
    exactly as the engine itself demotes it on an untrusted payload. Everything else is sent unchanged."""
    if isinstance(obj, dict):
        return {k: (None if (k == "verified" and v is True) else sanitize(v)) for k, v in obj.items()}
    if isinstance(obj, list):
        return [sanitize(v) for v in obj]
    return obj


def decision(r: Any) -> dict:
    """The fields of a result that carry its decision (ids, timestamps, timings and signatures excluded)."""
    d = r.model_dump(mode="json") if isinstance(r, VerificationResult) else r
    ce = d.get("counterexample") or {}
    core = d.get("unsat_core") or {}
    return {"status": d.get("status"), "query": d.get("query"), "premises_relied_on": sorted(d.get("premises_relied_on") or []),
            "unsat_core": sorted(core.get("premise_ids") or []), "negated_conclusion_in_core": core.get("includes_negated_conclusion"),
            "counterexample": sorted((a["symbol"], a["value"]) for a in (ce.get("assignments") or [])),
            "witness_model": sorted((a["symbol"], a["value"]) for a in (d.get("witness_model") or [])),
            "diagnostic_codes": sorted(x["code"] for x in (d.get("diagnostics") or [])),
            "ungrounded_dependencies": sorted(d.get("ungrounded_dependencies") or []), "unverified_dependencies": sorted(d.get("unverified_dependencies") or []),
            "reason_unknown": d.get("reason_unknown"), "problem_digest": (d.get("binding") or {}).get("problem_digest"), "smt2": (d.get("binding") or {}).get("smt2"),
            "versions": d.get("versions")}


CORE_FIELDS = ("status", "query", "premises_relied_on", "unsat_core", "negated_conclusion_in_core", "counterexample", "witness_model", "reason_unknown")


def http_leg(svc: Service) -> dict:
    calls = []
    verify_ms_200, verify_ms_400, verify_ms_all, sig_ms = [], [], [], []
    http_status = defaultdict(int)
    by_category = defaultdict(lambda: {"calls": 0, "http_200": 0, "http_400": 0, "other_http": 0, "decision_equal_to_pipeline": 0,
                                       "equal_to_in_process_same_payload": 0, "status_equal_to_pipeline": 0, "ms": []})
    mismatches = []
    for i, c in enumerate(ENGINE_CALLS):
        pj = to_json_problem(c["problem"])
        cat = c["category"]
        rec: dict[str, Any] = {"i": i, "task": c["task"], "stage": c["stage"], "category": cat, "problem_id": pj.get("problem_id") if pj else None,
                               "claim_id": pj.get("claim_id") if pj else None, "in_process_status": c["result"].status.value, "in_process_wall_ms": c["wall_s"] * 1000.0,
                               "non_default_limits": c["limits"] != DEFAULT_LIMITS}
        bc = by_category[cat]
        bc["calls"] += 1
        if pj is None:
            rec["skipped"] = "problem is not JSON-serialisable data"
            calls.append(rec)
            continue
        cfg = c["config"].model_dump(mode="json", exclude={"memory_max_mb"})
        vpaths = verified_paths(pj)
        rec["asserted_verified_groundings"] = len(vpaths)
        code, body, ms = svc.post("/v1/verify", {"problem": pj, "config": cfg})
        verify_ms_all.append(ms)
        http_status[code] += 1
        rec["as_delivered"] = {"http": code, "ms": ms, **({"code": body.get("code")} if code != 200 and isinstance(body, dict) else {})}
        sent = pj
        if code == 400 and vpaths:
            verify_ms_400.append(ms)
            bc["http_400"] += 1
            sent = sanitize(pj)
            code, body, ms = svc.post("/v1/verify", {"problem": sent, "config": cfg})
            verify_ms_all.append(ms)
            http_status[code] += 1
            rec["sanitized"] = {"http": code, "ms": ms, "verified_flags_reset": len(vpaths)}
        if code != 200:
            bc["other_http"] += 1
            rec["error"] = body if isinstance(body, dict) else str(body)[:300]
            bug("inconsistency", f"service answered HTTP {code} to a pipeline problem ({c['task']} {cat} {rec['problem_id']})",
                "POST /v1/verify with the problem recorded in timings.json http.calls[%d]" % i, rec["error"])
            calls.append(rec)
            continue
        verify_ms_200.append(ms)
        bc["http_200"] += 1
        bc["ms"].append(ms)
        rec["http_ms"] = ms
        rec["http_status"] = body.get("status")
        # (a) the same payload decided in this process (the engine's untrusted-payload path, as the service runs it)
        local = engine_verify_direct(sent, SolverConfig.model_validate(cfg), DEFAULT_LIMITS, svc.key, svc.key_id)
        d_http, d_local, d_pipe = decision(body), decision(local), decision(c["result"])
        same_payload_equal = d_http == d_local
        rec["equal_to_in_process_same_payload"] = same_payload_equal
        if same_payload_equal:
            bc["equal_to_in_process_same_payload"] += 1
        else:
            diff = {k: {"http": d_http[k], "in_process": d_local[k]} for k in d_http if d_http[k] != d_local[k]}
            mismatches.append({"i": i, "task": c["task"], "category": cat, "problem_id": rec["problem_id"], "against": "in-process, same payload", "diff": diff})
            bug("inconsistency", f"HTTP result differs from the in-process result of the same payload ({c['task']} {rec['problem_id']})",
                "POST /v1/verify vs epinoic_logic.engine.runner.verify(payload, config) on timings.json http.calls[%d]" % i, diff)
        # (b) against the result the pipeline actually used (its own Problem object, its own limits)
        core_equal = all(d_http[k] == d_pipe[k] for k in CORE_FIELDS)
        rec["status_equal_to_pipeline"] = d_http["status"] == d_pipe["status"]
        rec["decision_equal_to_pipeline"] = core_equal and d_http["diagnostic_codes"] == d_pipe["diagnostic_codes"]
        rec["problem_digest_equal_to_pipeline"] = d_http["problem_digest"] == d_pipe["problem_digest"]
        rec["dependency_lists_equal_to_pipeline"] = (d_http["ungrounded_dependencies"], d_http["unverified_dependencies"]) == (d_pipe["ungrounded_dependencies"], d_pipe["unverified_dependencies"])
        if rec["status_equal_to_pipeline"]:
            bc["status_equal_to_pipeline"] += 1
        if rec["decision_equal_to_pipeline"]:
            bc["decision_equal_to_pipeline"] += 1
        else:
            rec["pipeline_diff"] = {k: {"http": d_http[k], "pipeline": d_pipe[k]} for k in CORE_FIELDS + ("diagnostic_codes",) if d_http[k] != d_pipe[k]}
        # signature of the service's result, checked by the service
        c2, b2, ms2 = svc.post("/v1/results/verify-signature", {"result": body})
        sig_ms.append(ms2)
        rec["signature_valid"] = c2 == 200 and isinstance(b2, dict) and b2.get("valid") is True
        calls.append(rec)
    for bc in by_category.values():
        bc["latency"] = lat_stats(bc.pop("ms"))
    not_decision_equal = [r for r in calls if r.get("http_status") and not r.get("decision_equal_to_pipeline")]
    explained, repro_problems = [], []
    for r in not_decision_equal:
        c = ENGINE_CALLS[r["i"]]
        cfg_http = SolverConfig.model_validate(c["config"].model_dump(mode="json", exclude={"memory_max_mb"}))
        # (1) the pipeline's own problem object under the service's limits: does the policy alone explain the difference?
        under_default = decision(engine_verify_direct(c["problem"], cfg_http, DEFAULT_LIMITS))
        # (2) the reset payload under the pipeline's own limits: does the grounding reset alone change the decision?
        sanitized_own_limits = decision(engine_verify_direct(sanitize(to_json_problem(c["problem"])), cfg_http, c["limits"]))
        pipe = decision(c["result"])
        why = []
        if r["non_default_limits"] and under_default["status"] == r["http_status"]:
            why.append("engine policy: the pipeline decided it under non-default limits (allow_nonlinear or larger bounds) that POST /v1/verify cannot carry; "
                       f"the same problem under DEFAULT_LIMITS in process is {under_default['status']} {under_default['diagnostic_codes']}, as over HTTP")
        if all(sanitized_own_limits[k] == pipe[k] for k in CORE_FIELDS):
            why.append("not the grounding reset: the reset payload under the pipeline's own limits decides as the pipeline did")
        elif r.get("sanitized"):
            why.append(f"grounding reset: the reset payload under the pipeline's own limits decides {sanitized_own_limits['status']} (pipeline {pipe['status']})")
        if not any(w.startswith(("engine policy", "grounding reset")) for w in why):
            why.append("unexplained")
        explained.append({"i": r["i"], "task": r["task"], "category": r["category"], "problem_id": r["problem_id"], "pipeline_status": pipe["status"],
                          "http_status": r["http_status"], "http_diagnostic_codes": (r.get("pipeline_diff") or {}).get("diagnostic_codes", {}).get("http"),
                          "pipeline_limits": c["limits"].model_dump(mode="json") if hasattr(c["limits"], "model_dump") else str(c["limits"]),
                          "pipeline_diff": r.get("pipeline_diff"), "why": why})
        repro_problems.append({"i": r["i"], "task": r["task"], "problem_id": r["problem_id"], "problem": to_json_problem(c["problem"]),
                               "config": c["config"].model_dump(mode="json", exclude={"memory_max_mb"}),
                               "pipeline_limits": c["limits"].model_dump(mode="json") if hasattr(c["limits"], "model_dump") else None,
                               "pipeline_status": pipe["status"], "http_status": r["http_status"]})
    (OUT / "http_differences_problems.json").write_text(json.dumps(repro_problems, indent=1, ensure_ascii=False, default=str))
    dep_diff = sum(1 for r in calls if r.get("http_status") and r.get("dependency_lists_equal_to_pipeline") is False)
    if explained:
        policy = [e for e in explained if any(w.startswith("engine policy") for w in e["why"])]
        bug("inconsistency", f"{len(explained)} of {len(verify_ms_200)} genuine-pass engine problems decide differently over HTTP than in the pipeline "
            f"({len(policy)} because POST /v1/verify cannot carry the engine policy the channel used; all {by_category['translated_claim']['calls']} translated-claim problems agree)",
            f"<venv python> -I -B -c \"import json; from epinoic_logic.engine.runner import verify; from epinoic_logic.ir.schema import Limits; "
            f"from epinoic_logic.engine.results import SolverConfig; d=[x for x in json.load(open('{OUT / 'http_differences_problems.json'}')) if x['problem_id'].startswith('stem-')][0]; "
            "c=SolverConfig(**d['config']); print(d['problem_id'], verify(d['problem'], c).status.value, verify(d['problem'], c, limits=Limits(**d['pipeline_limits'])).status.value)\" "
            "(first: what POST /v1/verify returns under DEFAULT_LIMITS; second: what the channel decided under its policy)",
            [{k: e[k] for k in ("task", "category", "problem_id", "pipeline_status", "http_status", "http_diagnostic_codes", "why")} for e in explained])
    unexplained = [e for e in explained if e["why"] == ["unexplained"]]
    if unexplained:
        bug("inconsistency", f"{len(unexplained)} HTTP decisions differ from the pipeline's in-process decision with no policy or grounding difference to explain them",
            "see http.differences_from_pipeline in timings.json", unexplained[:10])
    return {"calls": calls, "http_status_counts": dict(http_status), "by_category": dict(by_category),
            "verify_latency_decisions_http200": lat_stats(verify_ms_200), "verify_latency_rejections_http400": lat_stats(verify_ms_400),
            "verify_latency_all_calls": lat_stats(verify_ms_all), "verify_signature_latency": lat_stats(sig_ms),
            "signatures_valid": sum(1 for r in calls if r.get("signature_valid")), "results_http200": len(verify_ms_200),
            "equal_to_in_process_same_payload": sum(1 for r in calls if r.get("equal_to_in_process_same_payload")),
            "mismatches_same_payload": mismatches,
            "status_equal_to_pipeline": sum(1 for r in calls if r.get("status_equal_to_pipeline")),
            "decision_equal_to_pipeline": sum(1 for r in calls if r.get("decision_equal_to_pipeline")),
            "differences_from_pipeline": explained, "dependency_lists_differ_from_pipeline": dep_diff,
            "refused_as_delivered_E505": sum(1 for r in calls if r.get("sanitized"))}


# ============================================================================ leg 4: response gate
PASSED, FAILED, UNRESOLVED, EXCLUDED = "passed", "failed", "unresolved", "not_required"
PASS_STATUSES = {VerificationStatus.ENTAILED.value, VerificationStatus.CONSISTENT.value, VerificationStatus.SATISFIABLE.value}
FAIL_STATUSES = {s.value for s in DEFINITIVE} - PASS_STATUSES
#: Findings that restate a check already listed (request constraint, request-item coverage): not counted twice.
RESTATING_CODES = {"INT-REQ-005", "INT-REQ-004"}


def receipt_checks(rc: Any, prefix: str) -> list[dict]:
    """Every check a receipt carries, each passed / failed / unresolved (or not required), with what it rests on."""
    checks: list[dict] = []
    add = lambda name, result, detail: checks.append({"check": f"{prefix}:{name}", "result": result, "detail": str(detail)[:400]})  # noqa: E731
    add("delivered", FAILED if rc.status is TransmissionStatus.REJECTED else PASSED, f"receipt {rc.status.value} via branch {rc.branch}")
    for c in rc.constraint_results:
        add(f"constraint {c.constraint_id}", PASSED if c.satisfied is True else FAILED if c.satisfied is False else UNRESOLVED, f"{c.method}: {c.detail}")
    for cov in rc.coverage:
        # the hub's coverage rule is a heuristic and it only warns (INT-REQ-004): an unaddressed item is unresolved, not failed
        add(f"request item {cov.item_id}", PASSED if cov.addressed else UNRESOLVED, f"{cov.method}; addressed by {cov.addressed_by_claim_ids}")
    sev_by_result = {}
    for f in rc.findings:
        if getattr(f, "formal_result_id", None):
            sev_by_result.setdefault(f.formal_result_id, set()).add(f.code)
    formal_ids = set()
    for fc in rc.formal_checks:
        if fc.formal_result_id:
            formal_ids.add(fc.formal_result_id)
        codes = sev_by_result.get(fc.formal_result_id, set())
        if fc.satisfied is True:
            res = PASSED
        elif fc.satisfied is False:
            res = UNRESOLVED if "INT-SUBJ-004" in codes and "INT-SUBJ-001" not in codes else FAILED  # a reading the report did not state: a warning
        else:
            res = UNRESOLVED
        add(f"formal {fc.constraint_id}", res, f"{fc.formal_status}: {fc.detail}")
    for o in rc.outcomes:
        st = o.display_status.value
        if st in PASS_STATUSES:
            res = PASSED
        elif st in FAIL_STATUSES:
            res = FAILED
        elif st == VerificationStatus.NOT_ELIGIBLE.value:
            res = EXCLUDED
        else:
            res = UNRESOLVED
        v = o.verification
        rests = f"; relied on {len(v.premises_relied_on)}, ungrounded {len(v.ungrounded_dependencies)}, unverified {len(v.unverified_dependencies)}" if v is not None else ""
        add(f"claim {o.claim_id}", res, f"display {st}; translation {o.translation.status.value}{rests}")
        checks[-1]["display_status"] = st
    for f in list(rc.findings) + list(rc.structural_findings):
        if f.code in RESTATING_CODES or (getattr(f, "formal_result_id", None) in formal_ids and f.code in ("INT-SUBJ-001", "INT-SUBJ-002", "INT-SUBJ-004")):
            continue
        if f.severity == "error":
            add(f"finding {f.code} {list(f.claim_ids)}", FAILED, f.message)
        elif f.severity == "warning":
            add(f"finding {f.code} {list(f.claim_ids)}", UNRESOLVED, f.message)
    return checks


def tally(checks: list[dict]) -> dict:
    n = defaultdict(int)
    for c in checks:
        n[c["result"]] += 1
    required = n[PASSED] + n[FAILED] + n[UNRESOLVED]
    decided = n[PASSED] + n[FAILED]
    return {"required": required, "passed": n[PASSED], "failed": n[FAILED], "unresolved": n[UNRESOLVED], "not_required": n[EXCLUDED],
            # the delivery measure: passed share of the DECIDED checks (an unresolved check is neither passed nor failed)
            "accuracy": (n[PASSED] / decided) if decided else 0.0,
            # sensitivity: unresolved checks counted as not accurate
            "accuracy_strict": (n[PASSED] / required) if required else 0.0}


def display(t: dict, elapsed_s: float, measure: str = "accuracy") -> dict:
    """The delivery rule. VERIFIED only when every required check passed inside the budget; otherwise the candidate is
    delivered only above the accuracy threshold, labelled as not verified (never 'checked'), its failed checks shown as
    failed and its unresolved ones as unresolved; at or below the threshold it is withheld."""
    within = elapsed_s <= BUDGET_S
    if t["required"] and t["failed"] == 0 and t["unresolved"] == 0 and within:
        return {"display_status": "VERIFIED", "label": "verified", "delivered": True}
    if t[measure] > DELIVERY_THRESHOLD:
        return {"display_status": "DELIVERED_UNVERIFIED", "label": "not verified", "delivered": True}
    return {"display_status": "WITHHELD", "label": "withheld: below the delivery threshold", "delivered": False}


def synthesis_mapping(items, group, syntheses, delivered, plan) -> Optional[dict]:
    """The combinator's synthesis of the group as the JSON a router receives (the fields group_synthesis builds), so the
    hub's own contract validation decides it instead of a constructor in the harness."""
    members = [it for it in items if run_arena.group_of(it) == group and it["_path"].stem in delivered and it["_path"].stem in syntheses]
    if not members:
        return None
    claims, ledger, sources = [], [], []
    for it in members:
        syn, reply = syntheses[it["_path"].stem], delivered[it["_path"].stem]
        by_id = {c["claim_id"]: c for c in reply.payload["claims"]}
        prefix = "" if len(members) == 1 else f"{it['task_id']}-"
        for i, c in enumerate(syn["claims"]):
            cited = [x for x in c.get("source_claim_ids", []) if x in by_id] or c.get("source_claim_ids", [])
            refs = [dict(r) for r in c["evidence_refs"]] if "evidence_refs" in c else [
                {k: r[k] for k in ("document_id", "locator", "excerpt")} for r in run_arena.reproduced_evidence_refs(c["text"], cited, by_id)]
            claims.append({"claim_id": f"{prefix}s{i}", "text": c["text"], "certainty": c.get("certainty", "established"), "source_claim_ids": cited,
                           "transformation": c.get("transformation", "paraphrased"), "evidence_refs": refs})
        ledger += [{"source_claim_ids": d["source_claim_ids"], "transformation": "dropped", "reason": d.get("reason")} for d in syn.get("dropped", [])]
        sources.append(reply.payload["report_id"])
    text = " ".join(c["text"] for c in claims) or "(empty)"
    from epinoic_logic.translate.contracts import sha256_text
    return {"synthesis_id": f"syn-{group}", "request_id": plan.request_id, "task_id": plan.task_id, "combinator_agent_id": "dummy-combinator",
            "source_report_ids": sources, "claims": claims, "ledger": ledger, "text": text, "text_sha256": sha256_text(text), "created_at": "2026-10-11T15:00:00Z"}


def gate_leg(inputs: dict, items: list[dict], task_times: dict) -> dict:
    syntheses = {p.stem: json.loads(p.read_text()) for p in (ROUND / "syntheses").glob("*.json")}
    delivered = {t: m for t, m in REPLIES.items() if m is not None}
    per_task, per_request = {}, {}
    for it in items:
        tid = it["task_id"]
        t0 = time.perf_counter()
        rc = RECEIPTS.get(tid)
        checks = receipt_checks(rc, tid) if rc is not None else [{"check": f"{tid}:delivered", "result": FAILED, "detail": "no receipt"}]
        rq = REQ_RECEIPTS.get(tid)
        if rq is not None:
            checks.insert(0, {"check": f"{tid}:request accepted", "result": FAILED if rq[0] is None else PASSED, "detail": f"request receipt {rq[2].status.value}"})
        t = tally(checks)
        disp = display(t, task_times.get(tid, {}).get("pre_gate_s", 0.0))
        disp["display_status_if_unresolved_counted_as_inaccurate"] = display(t, task_times.get(tid, {}).get("pre_gate_s", 0.0), "accuracy_strict")["display_status"]
        gate_s = time.perf_counter() - t0
        per_task[tid] = {"task": tid, "subject": it["subject"], "kb": it.get("kb"), "receipt_status": rc.status.value if rc is not None else None,
                         **t, **disp, "gate_s": gate_s, "checks": checks}
    for rid, req in inputs["requests"].items():
        t0 = time.perf_counter()
        tids = req["tasks"]
        groups = list(dict.fromkeys(run_arena.group_of(next(it for it in items if it["task_id"] == x)) for x in tids))
        member_checks = [c for x in tids for c in per_task[x]["checks"]]
        peer_checks = []
        for x in tids:
            pr = PEER_RECORDS.get(x)
            if pr is not None:
                peer_checks.append({"check": f"{x}:peer relay of {pr.get('peer_of')}", "result": PASSED if pr.get("functional") and pr.get("status") != "REJECTED" else FAILED,
                                    "detail": f"relay receipt {pr.get('status')}; codes {pr.get('codes')}" + (f"; error {pr.get('error')}" if pr.get("error") else "")})
                for f in pr.get("findings", []) + pr.get("subject_findings", []):
                    if f["severity"] in ("error", "warning"):
                        peer_checks.append({"check": f"{x}:peer relay finding {f['code']}", "result": FAILED if f["severity"] == "error" else UNRESOLVED, "detail": f["message"][:400]})
        syn_info, syn_checks, syn_delivered = [], [], False
        for g in groups:
            srec = SYN_RECORDS.get(g) or {}
            entry = {"group": g, "arena_record": {k: srec.get(k) for k in ("status", "delivered", "functional", "codes", "failure_reasons")} | ({"error": srec["error"].splitlines()[0][:300]} if srec.get("error") else {})}
            ch = GROUP_CHANNELS.get(g)
            json_receipt = None
            if not srec.get("delivered") and ch is not None:
                # the combinator's synthesis as the JSON the router would receive, relayed on the group's channel (after the arena run)
                try:
                    mapping = synthesis_mapping(items, g, syntheses, delivered, ch.plan)
                    if mapping is not None:
                        relayed, rr = ch.relay("dummy-combinator", AgentRole.COMBINATOR, "router", AgentRole.ROUTER, mapping)
                        json_receipt = rr
                        entry["as_json"] = {"status": rr.status.value, "delivered": relayed is not None, "codes": sorted({f.code for f in rr.findings}),
                                            "message": next((f.message[:400] for f in rr.findings if f.code == "INT-REQ-009"), None)}
                except Exception as exc:  # a crash here is a hub bug
                    entry["as_json"] = {"error": f"{type(exc).__name__}: {exc}"[:400]}
                    bug("crash", f"relaying the combinator's synthesis of group {g} as JSON raised", f"TranslatorChannel.relay(..., <synthesis mapping of {g}>)", traceback.format_exc()[-1500:])
            ok_arena = bool(srec.get("delivered")) and srec.get("status") != "REJECTED"
            ok_json = json_receipt is not None and json_receipt.status is not TransmissionStatus.REJECTED
            syn_delivered = syn_delivered or ok_arena or ok_json
            syn_checks.append({"check": f"{g}:combinator synthesis delivered", "result": PASSED if (ok_arena or ok_json) else FAILED,
                               "detail": ("arena synthesis " + str(srec.get("status")) if srec.get("status") else "arena synthesis not built: " + (srec.get("error") or "").splitlines()[0][:200] if srec.get("error") else "no synthesis record")
                               + (f"; as JSON: {entry['as_json'].get('status')} {entry['as_json'].get('codes')}" if entry.get("as_json") else "")})
            if ok_arena or ok_json:
                rcpt = json_receipt if ok_json and not ok_arena else None
                if rcpt is not None:
                    syn_checks += receipt_checks(rcpt, f"{g}:synthesis")
            syn_info.append(entry)
        members_delivered = all(per_task[x]["receipt_status"] not in (None, "REJECTED") for x in tids)
        candidates = []
        if syn_delivered:
            ch_ = syn_checks + member_checks + peer_checks
            candidates.append({"candidate": "combinator synthesis of the delivered reports", **tally(ch_), "checks": ch_})
        if members_delivered:
            ch_ = [c for c in syn_checks if c["check"].endswith("combinator synthesis delivered")] + member_checks + peer_checks
            candidates.append({"candidate": "the delivered specialist report(s) as the router holds them (no combinator synthesis)" if not syn_delivered else "the delivered specialist report(s)",
                               **tally(ch_), "checks": ch_})
        elapsed = sum(task_times.get(x, {}).get("pre_gate_s", 0.0) for x in tids)
        best = max(candidates, key=lambda c: (c["accuracy"], c["accuracy_strict"])) if candidates else None
        if best is None:
            disp = {"display_status": "WITHHELD", "label": "withheld: no complete candidate", "delivered": False, "display_status_if_unresolved_counted_as_inaccurate": "WITHHELD"}
        else:
            disp = display(best, elapsed)
            best_strict = max(candidates, key=lambda c: (c["accuracy_strict"], c["accuracy"]))
            disp["display_status_if_unresolved_counted_as_inaccurate"] = display(best_strict, elapsed, "accuracy_strict")["display_status"]
        gate_s = time.perf_counter() - t0 + sum(per_task[x]["gate_s"] for x in tids)
        resolution = ("all required checks passed" if best and best["failed"] == 0 and best["unresolved"] == 0 else
                      f"{best['failed']} failed, {best['unresolved']} unresolved (unresolved stays unresolved)" if best else "no candidate")
        per_request[rid] = {"request": req["request"], "title": req["title"], "path": req["path"], "tasks": tids, "groups": groups,
                            "budget_s": BUDGET_S, "deterministic_elapsed_s": elapsed, "within_budget": elapsed <= BUDGET_S,
                            "delivery_threshold": DELIVERY_THRESHOLD, "synthesis": syn_info,
                            "candidates": [{k: v for k, v in c.items() if k != "checks"} for c in candidates],
                            "chosen_candidate": best["candidate"] if best else None, **({k: best[k] for k in ("required", "passed", "failed", "unresolved", "not_required", "accuracy", "accuracy_strict")} if best else {}),
                            **disp, "resolution": resolution, "gate_s": gate_s,
                            "failed_checks": [c for c in (best["checks"] if best else []) if c["result"] == FAILED],
                            "unresolved_checks": [c for c in (best["checks"] if best else []) if c["result"] == UNRESOLVED]}
    # invariants of what the student is shown
    inv = {
        "no_verified_with_failed_or_unresolved_check": all(not (r["display_status"] == "VERIFIED" and (r.get("failed") or r.get("unresolved"))) for r in per_request.values())
        and all(not (t["display_status"] == "VERIFIED" and (t["failed"] or t["unresolved"])) for t in per_task.values()),
        "no_non_success_status_counted_as_passed": all(c["display_status"] in PASS_STATUSES for t in per_task.values() for c in t["checks"]
                                                       if c.get("display_status") and c["result"] == PASSED),
        "every_failed_or_undecided_engine_status_kept": all(c["result"] in (FAILED, UNRESOLVED, EXCLUDED) for t in per_task.values() for c in t["checks"]
                                                            if c.get("display_status") and c["display_status"] not in PASS_STATUSES),
        "delivered_unverified_never_labelled_checked_or_verified": all(r["label"] == "not verified" for r in per_request.values() if r["display_status"] == "DELIVERED_UNVERIFIED"),
        "delivered_unverified_only_above_threshold": all(r.get("accuracy", 0.0) > DELIVERY_THRESHOLD for r in per_request.values() if r["display_status"] == "DELIVERED_UNVERIFIED"),
        "withheld_only_at_or_below_threshold": all(r.get("chosen_candidate") is None or r.get("accuracy", 0.0) <= DELIVERY_THRESHOLD for r in per_request.values() if r["display_status"] == "WITHHELD"),
        "all_sixteen_tasks_gated": len(per_task) == ARGS.expected_specialists,
    }
    if not all(inv.values()):
        bug("inconsistency", "response gate invariant violated", "see gate.json invariants", inv)
    return {"per_task": per_task, "per_request": per_request, "invariants": inv}


# ============================================================================ per-task timings
def routing_times(items: list[dict], tasks: list[dict]) -> dict:
    """Routing: the router's kb assignment for the task (tasks.json), the hub branch for its subject, the group's plan."""
    by_id = {t["task_id"]: t for t in tasks}
    hub = RouterHub(signing_key=run_arena.KEY, config=run_arena.CFG)
    out = {}
    for it in items:
        t0 = time.perf_counter()
        routed = by_id[it["task_id"]]
        kb, agent = routed["kb"], routed["agent_id"]
        plan = run_arena.group_plan(items, run_arena.group_of(it))
        branch = hub.branch_for(plan.agent_subjects.get(agent, plan.subject))
        dt = time.perf_counter() - t0
        out[it["task_id"]] = {"kb": kb, "agent_id": agent, "branch": branch, "group": run_arena.group_of(it), "assign_s": dt}
    hub.close()
    return out


def build_task_times(items: list[dict], routing: dict, http: dict, arena_a: dict) -> dict:
    http_ms = defaultdict(float)
    http_n = defaultdict(int)
    for r in http["calls"]:
        if r.get("http_ms") is not None:
            http_ms[r["task"]] += r["http_ms"]
            http_n[r["task"]] += 1
            if r.get("sanitized"):
                http_ms[r["task"]] += r["as_delivered"]["ms"]  # the refused first attempt is part of the HTTP cost
    calls_by_task = defaultdict(lambda: defaultdict(int))
    for c in ENGINE_CALLS:
        calls_by_task[c["task"]][c["category"]] += 1
    a_records = defaultdict(list)
    for r in (arena_a.get("results") or {}).get("records", []):
        a_records[r["task_id"]].append(r)
    out = {}
    for it in items:
        tid = it["task_id"]
        s = STATS.get((tid, "genuine"), {})
        mut = STATS.get((tid, "mutation"), {})
        variants = [v for (t, v) in STATS if t == tid and v not in ("genuine", "mutation")]
        mut_s = sum(sum(STATS[(tid, v)].get(k, 0.0) for k in ("dispatch_s", "receive_s", "variant_peer_receive_s", "peer_relay_s", "open_task_s")) for v in variants) + mut.get("open_task_s", 0.0)
        eng = {k: s.get(f"{k}.engine_s", 0.0) for k in ("dispatch_s", "receive_s", "peer_relay_s", "synthesis_s", "open_task_s")}
        engine_all = sum(eng.values())
        translator = s.get("receive_s.translator_s", 0.0) + s.get("peer_relay_s.translator_s", 0.0)
        routing_s = routing[tid]["assign_s"] + s.get("open_task_s", 0.0) - eng["open_task_s"]
        validation_s = s.get("dispatch_s", 0.0) - eng["dispatch_s"]
        channel_s = s.get("receive_s", 0.0) - eng["receive_s"]
        peer_s = s.get("peer_relay_s", 0.0) - eng["peer_relay_s"]
        syn_s = s.get("synthesis_s", 0.0) - eng["synthesis_s"]
        pre_gate = validation_s + routing_s + channel_s + peer_s + syn_s + engine_all
        a_gen = next((r for r in a_records[tid] if r["variant"] == "genuine"), {})
        rc = RECEIPTS.get(tid)
        out[tid] = {
            "task": tid, "subject": it["subject"], "agent_id": it["agent_id"], "kb": routing[tid]["kb"], "group": routing[tid]["group"],
            "branch_assigned": routing[tid]["branch"], "branch_on_receipt": rc.branch if rc is not None else None,
            "stages_s": {
                "request_validation": validation_s,
                "routing_kb_assignment": routing_s,
                "channel_translator_processing": channel_s,
                "peer_relay": peer_s,
                "combinator_synthesis": syn_s,
                "z3_engine_in_process": engine_all,
                "response_gate": None,  # filled after the gate runs
            },
            "z3_engine_http_s": http_ms[tid] / 1000.0,
            "of_which_translator_pipeline_s": translator,
            "engine_in_process_by_stage_s": {k.replace("_s", ""): v for k, v in eng.items()},
            "pre_gate_s": pre_gate,
            "engine_calls_in_process": dict(calls_by_task[tid]), "engine_calls_http_200": http_n[tid],
            "translated_claims": int(s.get("receive_s.claims", 0)),
            "receipt_status": rc.status.value if rc is not None else None,
            "arena_subprocess_genuine_latency_s": (a_gen.get("latency_ms") or 0.0) / 1000.0 if a_gen else None,
            "arena_fault_variants_s": mut_s, "arena_fault_variants": len(variants),
        }
        if routing[tid]["branch"] != (rc.branch if rc is not None else None):
            bug("inconsistency", f"{tid}: the hub's branch for the routed subject ({routing[tid]['branch']}) is not the branch on its receipt ({rc.branch if rc else None})",
                f"RouterHub.branch_for(subject) vs the genuine receipt of {tid}")
    return out


# ============================================================================ main
def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    t_all = time.perf_counter()
    timings: dict[str, Any] = {"harness": {"python": platform.python_version(), "z3": z3_version(), "versions": {"ir": ep_version.IR_VERSION, "engine": ep_version.ENGINE_VERSION,
                                                                                                                 "policy": ep_version.POLICY_VERSION, "translator": ep_version.TRANSLATOR_VERSION},
                                            "frozen_tree_commit": (E2E / "TREE").read_text().strip() if (E2E / "TREE").exists() else None,
                                            "round": ROUND.name, "budget_s": BUDGET_S, "delivery_threshold": DELIVERY_THRESHOLD, "units": "seconds unless a key ends in _ms"}}
    inputs = check_inputs()
    timings["inputs"] = inputs["summary"]
    svc = Service()
    gate: dict = {}
    try:
        timings["service"] = {"start": svc.start()}
        timings["service"]["round_trip"] = service_round_trip(svc)

        a = arena_subprocess()
        b = arena_instrumented(inputs["tasks"])
        items = b["items"]
        if a.get("results"):
            ra = a["results"]
            timings["arena_subprocess"] = {"command": "<venv python> -I -B scripts/arena/run_arena.py <copy of the round>", "wall_s": a["wall_s"], "arena_wall_s": ra["wall_s"],
                                           "transmissions": ra["transmissions"], "functional": ra["functional"], "functional_rate": ra["functional_rate"], "by_variant": ra["by_variant"],
                                           "genuine_translation_outcomes": ra["provider_dependent_translation_outcomes"]["by_status"],
                                           "failures": [{"file": r["file"], "variant": r["variant"], "why": ((r.get("error") or "").splitlines()[0][:300] if r.get("error") else None) or r.get("failure_reasons")}
                                                        for r in ra["failures"]]}
            cmp_ = compare_arena_legs(ra, b["results"])
        else:
            cmp_ = {"identical": False, "reason": "the subprocess arena produced no results"}
        timings["arena_instrumented"] = {"wall_s": b["wall_s"], "arena_wall_s": b["results"]["wall_s"], "equal_to_subprocess": cmp_,
                                         "unattributed_engine_s": UNATTRIBUTED["engine_s"], "unattributed_engine_calls": UNATTRIBUTED["engine_n"],
                                         "genuine_engine_calls": len(ENGINE_CALLS), "genuine_claim_outcomes": len(OUTCOMES), "engine_coverage": b["engine_coverage"]}
        if not cmp_.get("identical"):
            bug("inconsistency", "the instrumented in-process arena run decided differently from the subprocess run", "compare the two results.json under harness/rounds/", cmp_)
        if a.get("results"):
            for r in a["results"]["failures"]:
                if r["variant"] == "synthesis" and r.get("error"):
                    continue  # reported once below
                bug("arena-failure", f"{r['file']} [{r['variant']}] not functional", f"<venv python> -I -B {ARENA_DIR / 'run_arena.py'} <copy of {ROUND}>; results.json failures",
                    r.get("failure_reasons") or (r.get("error") or "")[:500])
            syn_crashes = [r for r in a["results"]["failures"] if r["variant"] == "synthesis" and r.get("error")]
            if syn_crashes:
                first = syn_crashes[0]["error"].splitlines()
                bug("crash", f"{len(syn_crashes)} of {a['results']['by_variant'].get('synthesis', {}).get('total')} combinator syntheses crash in the arena before reaching the hub "
                    f"(pydantic ValidationError: SynthesizedClaim.transformation is free text in the round's syntheses files)",
                    f"cd {E2E} && venv/bin/python -I -B -c \"import json; from epinoic_logic.integrity import SynthesizedClaim; c=json.load(open('{ROUND.name}/syntheses/bi-e1.json'))['claims'][0]; "
                    "SynthesizedClaim(claim_id='s0', text=c['text'], source_claim_ids=c['source_claim_ids'], transformation=c['transformation'])\"",
                    {"files": [r["file"] for r in syn_crashes], "error": first[:3]})

        routing = routing_times(items, inputs["tasks"])
        http = http_leg(svc)
        task_times = build_task_times(items, routing, http, a)
        gate = gate_leg(inputs, items, task_times)
        req_of_task = {x: r for r in gate["per_request"].values() for x in r["tasks"]}
        for tid, tt in task_times.items():
            tt["stages_s"]["response_gate"] = gate["per_task"][tid]["gate_s"]
            tt["total_deterministic_s"] = tt["pre_gate_s"] + tt["stages_s"]["response_gate"]
            tt["total_deterministic_with_http_engine_s"] = tt["total_deterministic_s"] - tt["stages_s"]["z3_engine_in_process"] + tt["z3_engine_http_s"]
            r = req_of_task.get(tid)
            tt["request"] = r["request"] if r else None
            tt["request_total_deterministic_s"] = (sum(task_times[x]["pre_gate_s"] for x in r["tasks"]) + r["gate_s"]) if r else None
            tt["task_display_status"] = gate["per_task"][tid]["display_status"]
            tt["request_display_status"] = r["display_status"] if r else None
        timings["tasks"] = task_times
        timings["requests"] = {rid: {"request": r["request"], "title": r["title"], "tasks": r["tasks"], "total_deterministic_s": sum(task_times[x]["pre_gate_s"] for x in r["tasks"]) + r["gate_s"],
                                     "response_gate_s": r["gate_s"], "display_status": r["display_status"]} for rid, r in gate["per_request"].items()}
        stage_keys = list(next(iter(task_times.values()))["stages_s"].keys())
        timings["totals"] = {"tasks": len(task_times), "requests": len(gate["per_request"]),
                             "stages_s": {k: sum(t["stages_s"][k] or 0.0 for t in task_times.values()) for k in stage_keys},
                             "total_deterministic_s": sum(t["total_deterministic_s"] for t in task_times.values()),
                             "z3_engine_http_s": sum(t["z3_engine_http_s"] for t in task_times.values()),
                             "of_which_translator_pipeline_s": sum(t["of_which_translator_pipeline_s"] for t in task_times.values()),
                             "arena_fault_variants_s": sum(t["arena_fault_variants_s"] for t in task_times.values()),
                             "arena_subprocess_wall_s": a["wall_s"], "arena_in_process_wall_s": b["wall_s"],
                             "slowest_task": max(task_times.values(), key=lambda t: t["total_deterministic_s"])["task"],
                             "slowest_task_s": max(t["total_deterministic_s"] for t in task_times.values()),
                             "max_request_total_s": max(r["total_deterministic_s"] for r in timings["requests"].values())}
        timings["service"]["http"] = {k: v for k, v in http.items() if k not in ("calls",)}
        timings["service"]["http"]["calls"] = [{k: v for k, v in c.items() if k not in ("pipeline_diff",)} for c in http["calls"]]
        timings["service"]["p50_ms"] = http["verify_latency_decisions_http200"]["p50_ms"]
        timings["service"]["p95_ms"] = http["verify_latency_decisions_http200"]["p95_ms"]
        timings["service"]["max_ms"] = http["verify_latency_decisions_http200"]["max_ms"]
    except Exception:
        bug("crash", "the harness raised", f"<venv python> -I -B {Path(__file__).resolve()}", traceback.format_exc()[-3000:])
    finally:
        timings.setdefault("service", {})["stop"] = svc.stop()
    timings["harness"]["wall_s"] = time.perf_counter() - t_all
    timings["bugs"] = BUGS
    timings["notes"] = NOTES + [
        "Translations are the round's recorded translator outputs (fixtures); model translation time is not part of this replay, so the budget measured is the deterministic time only.",
        "stages_s are additive: request_validation, routing_kb_assignment, channel_translator_processing, peer_relay and combinator_synthesis are each that stage's wall time minus the engine time inside it; z3_engine_in_process is all engine time of the task's genuine pass; their sum plus response_gate is total_deterministic_s.",
        "z3_engine_http_s is the same problems decided again by the running service over HTTP (an alternative path, not added to the total); total_deterministic_with_http_engine_s swaps it in.",
        "of_which_translator_pipeline_s is the part of channel_translator_processing spent in the translation pipeline (fixture parse, strict validation, grounding checks).",
        "Problems with grounding.verified=true are refused by the service (400 E505) as delivered; they are re-sent with the flag reset to null, as the engine itself demotes it.",
    ]
    (OUT / "timings.json").write_text(json.dumps(timings, indent=2, ensure_ascii=False, default=str))
    gate_out = {"rule": {"verified": "every required check passed (request accepted, delivered, every request constraint, every request item, every formal check, every claim with a translation, every error or warning finding not already one of those, the combinator synthesis) inside the four-minute budget",
                         "unresolved": "an undecided check (UNKNOWN, TIMEOUT, UNSUPPORTED, AMBIGUOUS_TRANSLATION, INVALID_FORMALIZATION, INTERNAL_ERROR, not checkable, a reading the report did not state, a warning) stays unresolved and is never counted as passed",
                         "delivery": f"otherwise the most accurate candidate is delivered only above {DELIVERY_THRESHOLD:.0%} accuracy, labelled 'not verified' (never 'checked'), else withheld",
                         "accuracy": "passed / (passed + failed) over the candidate's required checks: an unresolved check stays unresolved, counted neither as passed nor as failed; a candidate with no decided check has accuracy 0",
                         "accuracy_strict": "passed / required (unresolved counted as not accurate); display_status_if_unresolved_counted_as_inaccurate applies the same rule with it",
                         "candidates": "the combinator's synthesis of the delivered reports when the hub delivered it; the delivered specialist report(s) as the router holds them (with the synthesis check failed when it was not delivered)",
                         "budget_s": BUDGET_S, "not_required": "NOT_ELIGIBLE claims (routed to another check by policy)"},
                "requests": gate.get("per_request", {}), "tasks": {k: {kk: vv for kk, vv in v.items() if kk != "checks"} | {"failed_checks": [c for c in v["checks"] if c["result"] == FAILED],
                                                                                                                     "unresolved_checks": [c for c in v["checks"] if c["result"] == UNRESOLVED]}
                                                                for k, v in gate.get("per_task", {}).items()},
                "invariants": gate.get("invariants", {}),
                "summary": {s: sum(1 for r in gate.get("per_request", {}).values() if r["display_status"] == s) for s in ("VERIFIED", "DELIVERED_UNVERIFIED", "WITHHELD")},
                "summary_if_unresolved_counted_as_inaccurate": {s: sum(1 for r in gate.get("per_request", {}).values() if r.get("display_status_if_unresolved_counted_as_inaccurate") == s) for s in ("VERIFIED", "DELIVERED_UNVERIFIED", "WITHHELD")}}
    (OUT / "gate.json").write_text(json.dumps(gate_out, indent=2, ensure_ascii=False, default=str))
    print(json.dumps({"wall_s": timings["harness"]["wall_s"], "tasks": len(timings.get("tasks", {})), "requests": len(gate.get("per_request", {})),
                      "service": {k: timings["service"].get(k) for k in ("p50_ms", "p95_ms", "max_ms")}, "gate": gate_out["summary"], "bugs": len(BUGS)}, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
