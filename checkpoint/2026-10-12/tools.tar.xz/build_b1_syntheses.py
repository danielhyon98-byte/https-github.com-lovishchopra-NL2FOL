import json, os, sys

B = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/breadth/b1"
RAW = os.path.join(B, "claims_raw")
OUT = os.path.join(B, "syntheses")
os.makedirs(OUT, exist_ok=True)

def C(text, src, cert, tr):
    return {"text": text, "source_claim_ids": src, "certainty": cert, "transformation": tr}

def D(src, reason):
    return {"source_claim_ids": src, "reason": reason}

S = {}

S["ps-1"] = {
 "claims": [
  C("Dual processing proposes two modes of thinking: fast, automatic, intuitive processing (System 1) and slow, effortful, deliberate processing (System 2), a distinction popularised by Kahneman (2011). It explains cognitive biases to a considerable but limited extent: its causal support is strongest where an experiment sets the trigger, as with anchors, and weakest where it names System 1 as the mechanism, which the cited studies test only indirectly.",
    ["g2.1", "g2.3", "g1.1", "g6.1", "g6.2"], "established", "merged"),
  C("Causality here means one variable produces change in another, a claim that only controlled experiments with manipulation and random allocation can support. The clearest causal case is anchoring: after a wheel of fortune stopped on a high or a low number, Tversky and Kahneman (1974) found that participants' estimates of the percentage of African countries in the United Nations were higher after the high number. Because the wheel, not the participant, set the number, the anchor was manipulated and the estimates changed with it, which supports a causal claim within the study's conditions.",
    ["g2.2", "g3.1", "g3.2", "g3.3"], "established", "merged"),
  C("Dual processing supplies the mechanism: System 1 adjusts from the anchor quickly and stops too soon. The mechanism is plausible, but the study records estimates, not the two systems.",
    ["g3.4", "g3.5"], "probable", "merged"),
  C("Frederick (2005) reports that many people give the quick, intuitive and wrong answer to simple reasoning problems such as the bat-and-ball problem. This fits the theory's sequence, with System 1 answering before System 2 checks, but the pattern manipulates neither system, so it cannot show that an intuitive system caused the error rather than a failure to check it; the evidence supports an association between intuition and error. Wason (1960) found that participants in the 2-4-6 task tested their hypotheses mainly with examples that would confirm them; dual processing can file this under System 1, but a strategic explanation, in which people deliberately choose confirming tests, predicts the same result without an intuitive system, so the label adds little causal evidence beyond the finding itself.",
    ["g4.1", "g4.2", "g4.3", "g4.4", "g5.2", "g5.3", "g5.4"], "established", "merged"),
 ],
 "dropped": [
  D(["g1.2", "g1.3"], "Outline of the response's units and a conclusion label; the assertions they summarise are carried in the claims above."),
  D(["g5.1"], "Signposting sentence ('A rival account must also be weighed') with no content of its own."),
 ],
}

S["ps-2"] = {
 "claims": [
  C("Neuroplasticity is the brain's capacity to change its structure and function with experience and after injury.",
    ["g1.1"], "established", "carried"),
  C("Repeated use strengthens the connections between the neurons involved, a process called long-term potentiation; new synaptic connections and dendritic branches can form, and connections that are no longer used are pruned.",
    ["g1.2", "g1.3"], "established", "merged"),
  C("Example: Draganski et al. (2004) found that people who learned to juggle over three months showed increased grey matter in an area that processes visual motion. The increase shows the brain's structure changing in response to practice, and the grey matter decreased after participants stopped practising, which fits the pruning described above.",
    ["g2.1", "g2.2", "g2.3"], "established", "merged"),
 ],
 "dropped": [],
}

S["ps-3"] = {
 "claims": [
  C("Section B is worth 15 marks, not 25: Paper 2 is 35 marks in total (20 in Section A, 15 in Section B) and takes 1 hour 30 minutes.",
    ["g1.2"], "established", "carried"),
  C("The question lists four or more concepts, and discussing the study through two or more is needed, since one concept is not enough: one concept caps a response at the 7-9 band.",
    ["g1.3"], "established", "paraphrased"),
  C("Per mark: the guide's suggested Section B time is about 45 minutes, which gives about 3 minutes per mark (45 divided by 15). The student's own figures give 2.4 minutes per mark (60 divided by 25), but that rests on the 25-mark total.",
    ["g2.1", "g2.2"], "established", "merged"),
  C("Suggested split, applicable once the Section B time on the student's own paper has been checked: about 5 minutes planning, choosing the two concepts that the study's details engage most and noting one specific detail for each; then about 40 minutes writing: a short opening, two concept units each tied to specific details, and a conclusion on how far the study's conclusion holds.",
    ["g3.1", "g3.2"], "established", "narrowed"),
 ],
 "dropped": [
  D(["g1.1"], "Note about the response (two points differ from the guide, so the guide's figures are used); not a claim."),
  D(["g1.4"], "Hedge deferring to the student's own paper; not a claim about the exam."),
 ],
}

S["ps-p"] = {
 "claims": [
  C("Anchoring bias is the tendency to pull an estimate towards an initial value, the anchor, and to adjust away from it too little. People judging a value start from whatever figure they meet first, and their adjustment stops too close to it, so the final estimate stays near the anchor.",
    ["g1.1", "g1.2"], "established", "merged"),
  C("Illustrative example: an online jacket shown with a crossed-out 'was £180' beside 'now £95'. The £180 is the anchor: shoppers adjust down from it, stop too close to it, and judge £95 a bargain, even though they have no independent reason to think £95 is good value.",
    ["g2.1", "g2.2"], "probable", "merged"),
  C("The display triggers the bias because the higher figure is seen first and sets the starting point for the judgement.",
    ["g2.3"], "established", "paraphrased"),
 ],
 "dropped": [],
}

S["ge-1"] = {
 "claims": [
  C("Vulnerability to climate change is a society's susceptibility to harm from climate hazards such as sea-level rise, storm surge and drought. It depends on exposure (the degree to which people and assets are in harm's way) and capacity (the ability to absorb a shock, recover and adapt): exposure explains where harm is possible, and capacity explains why societies with comparable exposure suffer different harm. Low-lying deltas expose the Netherlands and Bangladesh to sea-level rise and storm surge: much of the densely populated western Netherlands is close to or below sea level, and much of Bangladesh is low delta land facing a coast where tropical cyclones make landfall. Physical geography therefore sets a comparable exposure, so it cannot alone explain why similar hazards produce very different harm.",
    ["g1.1", "g1.2", "g1.3", "g2.1", "g2.2", "g2.3"], "established", "merged"),
  C("The Netherlands turned exposure into low risk through capacity: after the North Sea flood of 1953 it built the Delta Works between 1954 and 1997 (dams, sluices and storm-surge barriers in Zeeland and South Holland, completed by the Maeslantkering in 1997), and the accepted flood risk for North and South Holland is set at 1 in 10,000 years. A high-income state can fund and maintain protection to this standard, so the risk to people is kept low; such protection depends on resources the poorest societies may lack.",
    ["g3.1", "g3.2", "g3.3", "g3.4", "g3.5"], "established", "merged"),
  C("Bangladesh shows that capacity can lower harm without high income. When Cyclone Sidr made landfall on 15 November 2007, at least 3,447 deaths were reported (some estimates are far higher), against roughly 140,000 in a 1991 cyclone (counts range from about 138,000 to 143,000). Early warnings, volunteers of the Cyclone Preparedness Programme and coastal shelters were credited with reducing the toll, so preparedness cut deaths while the cyclone was no weaker; but preparedness cannot remove economic loss, as poorer households, with fewer assets and little insurance, are likely to be least able to recover.",
    ["g4.1", "g4.2", "g4.3", "g4.4"], "established", "merged"),
  C("Vulnerability is shaped more by capacity than by physical exposure, and wealth is the largest source of capacity, because it funds protection such as the Delta Works. The view that money alone decides the outcome does not fully hold, since warnings and volunteers reduced deaths in Bangladesh at low income and Dutch protection depends on continuing investment. Wealth explains most of the difference in vulnerability provided it is spent on protection and preparedness that reach poorer households; physical geography sets the stage, but capacity decides how far exposure becomes harm.",
    ["g5.1", "g5.2", "g5.3", "g5.4"], "established", "paraphrased"),
 ],
 "dropped": [],
}

S["ge-2"] = {
 "claims": [
  C("Answer (a)(ii): the population of Country P became older between 1990 and 2030.",
    ["g1.1"], "established", "paraphrased"),
  C("The share aged 0-14 fell in every period, from 31.0% in 1990 to 15.9% in 2030 (projected), while the share aged 65 and over rose in every period, from 6.1% to 18.2% (projected).",
    ["g1.2"], "established", "carried"),
  C("The anomaly is the 15-64 group: its share rose from 62.9% in 1990 to 68.1% in 2010, stayed at 68.1% in 2020, then fell to 65.9% in 2030 (projected).",
    ["g1.3"], "established", "carried"),
 ],
 "dropped": [],
}

S["ge-3"] = {
 "claims": [
  C("The case study can be built without memorised figures: state the processes (growth from natural increase and from rural-urban migration, the push and pull factors behind that migration, the informal housing that rapid growth can produce, the strain on services, and the responses to that strain), and attach one verified figure, with its year and source, to each process.",
    ["g3.1", "g3.2", "g3.3"], "established", "merged"),
  C("Before using any figure, check three things: the definition (a population may refer to the city proper or to the wider urban agglomeration, and the two differ greatly), the year (a growth rate means little without the years it covers), and the threshold (a megacity is a city of 10 million or more people, so whether Lagos qualifies depends on the figure verified).",
    ["g2.1", "g2.2", "g2.3", "g2.4"], "established", "merged"),
  C("City populations are estimated differently by different bodies, and migration figures are usually estimates rather than daily counts. Start with the teacher's notes and the official statistics the course uses, such as UN population estimates or the national statistics office, treating them as sources to verify rather than as confirmed figures.",
    ["g1.3", "g2.5"], "established", "merged"),
 ],
 "dropped": [
  D(["g1.1"], "Declined request: the response does not supply Lagos's 2026 population, annual growth rate or daily migrant figures; a refusal is not a claim."),
  D(["g1.2"], "Self-certification and refusal to supply figures from memory; not a claim."),
  D(["g4.1"], "Self-limitation note ('none of the Lagos figures is confirmed in this session'); not a claim."),
  D(["g5.1"], "Request for the student to return with figures; a request, not a claim."),
 ],
}

S["sp-1"] = {
 "claims": [
  C("The model article says that from Monday the school canteen will serve drinks in reusable cups and stop handing out plastic straws. The proposal rests on three measures: first, disposable cups are replaced by reusable ones, which are returned to the counter after use and washed in the school itself; second, sandwiches are wrapped in paper rather than clear plastic; third, a water fountain is installed in the yard so that nobody has to buy bottled water between classes.",
    ["g5.1", "g7.1", "g7.2", "g7.3", "g7.4"], "established", "merged"),
  C("The model article states that the «Cero plástico» campaign aims to reduce the rubbish generated each day on school grounds. Items used for a few minutes, such as cups, wrappers, straws and trays, take a very long time to disappear, and many end up in the street or the sea, where collecting them costs time and money.",
    ["g5.2", "g6.1", "g6.2"], "established", "merged"),
  C("The model article says that at the end of the first month the school council will review the results with class representatives. If the campaign works it continues; if not, the failing aspects will be corrected.",
    ["g9.1", "g9.2"], "established", "merged"),
  C("The model article argues that the campaign will not work if only the canteen applies it, and that when everyone takes part it becomes a habit rather than a slogan. Remembering to return a reusable cup becomes a habit with a little practice, and the effort is small compared with the benefit for everyone; if everyone brought their own bottle, the canteen would need fewer containers and could lower its drink prices.",
    ["g8.2", "g8.3", "g10.1", "g10.3"], "established", "merged"),
 ],
 "dropped": [
  D(["g1.1"], "Label saying the text is written for practice; not a claim."),
  D(["g2.1"], "Headline of the model text; not a claim."),
  D(["g3.1"], "Restates claims 1 and 4 (the campaign starts on Monday; its success depends on everyone)."),
  D(["g4.1"], "Byline of the model text; not a claim."),
  D(["g5.3"], "Rhetorical framing that the measure is a proposal, not an imposition; participation is carried in the fourth claim."),
  D(["g8.1"], "Framing of a hypothetical objection; the reply to it is carried in the fourth claim."),
  D(["g10.2"], "Call to action addressed to the readers of the text; not a claim."),
  D(["g11.1", "g11.2"], "Question and invitation addressed to the reader; not claims."),
 ],
}

S["sp-2"] = {
 "claims": [
  C("Answer to question 3 (2 points), first change: «Menos peleas en el recreo» (fewer fights in the playground), located in the director's quote in paragraph 2.",
    ["g1.1", "g2.1", "g2.2"], "established", "merged"),
  C("Second change: older pupils help the younger ones without anyone asking them to («Los alumnos mayores ayudan a los pequeños sin que nadie se lo pida»), from the same quote.",
    ["g3.1", "g3.2"], "established", "merged"),
 ],
 "dropped": [
  D(["g3.3"], "Exam-trap note contrasting the teachers' canteen observations in paragraph 3 with the director's; a note, not an answer."),
 ],
}

S["sp-3"] = {
 "claims": [
  C("Question 1 (1 point): «catorce años» (fourteen years old) when Julián started working in the bakery, located in paragraph 1 («tenía catorce años cuando empezó a trabajar»).",
    ["g1.1", "g2.1", "g2.2"], "established", "merged"),
  C("Question 2 (1 point): the statement is FALSO; the words from the text that justify it are «Quiero que ella elija su camino.» (paragraph 3).",
    ["g3.1", "g4.1"], "established", "merged"),
  C("Question 3 (1 point): «la» in «nunca la cerró» refers to «la panadería» (Julián's bakery, named in paragraph 1); the phrase is in paragraph 2.",
    ["g5.1", "g6.1", "g6.2", "g6.4"], "established", "merged"),
 ],
 "dropped": [
  D(["g2.3"], "Exam-trap note on the age figure 'sesenta y dos'; a note, not an answer."),
  D(["g4.2"], "Exam-trap note on the conditional sentence; a note, not an answer."),
  D(["g6.3"], "Exam-trap note on the nearest feminine noun; a note, not an answer."),
 ],
}

S["cs-1"] = {
 "claims": [
  C("Part (c): the function relies on values being sorted in ascending order. Its base case, low > high, means the target is not in the range, so the function returns -1; this also covers an empty list, where high is -1.",
    ["g1.1", "g2.1", "g2.2"], "established", "merged"),
  C("Trace of binary_search(values, 31, 0, 6) with values = [3, 8, 12, 17, 25, 31, 40]: call 1 has low 0, high 6, mid 3 and values[mid] 17; since 17 < 31 it calls again with low = mid + 1 = 4. Call 2 has low 4, high 6, mid 5 and values[mid] 31, so it returns 5. Call 1 passes that value back unchanged, so the call returns 5, the index of 31. For n = 7 the search makes at most ⌊log₂ 7⌋ + 1 = 3 comparisons; this trace needed 2.",
    ["g3.1", "g4.1", "g5.1", "g6.3"], "established", "merged"),
  C("Time complexity is O(log n), where n is the number of items in values. Each call compares the middle item with the target and discards the half of the remaining range that cannot contain it, leaving at most half for the next call; doubling n adds at most one comparison, so the number of calls grows with log n, not with n. Each call does a fixed amount of work and adds a frame to the call stack, so the space used is O(log n) too.",
    ["g6.1", "g6.2", "g6.4", "g6.5", "g6.6"], "established", "merged"),
 ],
 "dropped": [],
}

S["cs-2"] = {
 "claims": [
  C("Working: subtract each place value that fits: 181 − 128 = 53; 53 − 32 = 21; 21 − 16 = 5; 5 − 4 = 1; 1 − 1 = 0.",
    ["g1.1", "g1.2", "g1.3", "g1.4", "g1.5", "g1.6"], "established", "merged"),
  C("Bits 128, 32, 16, 4 and 1 are 1; 64, 8 and 2 did not fit, so they are 0. So 181₁₀ = 1011 0101₂.",
    ["g2.1", "g3.1"], "established", "merged"),
  C("Hexadecimal, from the bits in fours: 1011 = B, 0101 = 5, so B5₁₆.",
    ["g4.1"], "established", "carried"),
 ],
 "dropped": [],
}

S["cs-3"] = {
 "claims": [
  C("The question (construct, 4 marks) asks for a loop over the list that tracks the index of the highest value, using comparisons and without max or index.",
    ["g1.1"], "established", "paraphrased"),
  C("Provisional mark: 1–2 / 4. What earned credit: for i in range(1, len(scores)): and if scores[i] > highest: form a sound loop and comparison over the list. The second mark is borderline: highest = scores[i] updates the best value, but the index is never updated.",
    ["g1.2", "g1.3", "g1.4"], "probable", "merged"),
  C("Faults: return highest returns the largest value, not its index (the biggest gap). Test: find_max_index([3, 9, 4]) should return 1; the code returns 9. Second fault: highest = 0 assumes no value is negative; for find_max_index([-5, -2, -9]) the code returns 0, which is not in the list, and the answer is 1.",
    ["g1.5", "g1.7", "g1.8", "g1.9"], "established", "merged"),
  C("Fix: start from the first item, with best_index = 0 (the index of the first item); compare scores[i] with scores[best_index], not with 0; when a larger value is found, set best_index = i; after the loop, return best_index. Model key lines: best_index = 0; if scores[i] > scores[best_index]: best_index = i; return best_index.",
    ["g1.6", "g1.10", "g1.11", "g1.12", "g1.13", "g1.14", "g1.15", "g1.16"], "established", "merged"),
 ],
 "dropped": [],
}

RANK = {"possible": 0, "probable": 1, "established": 2}
ALLOWED_T = {"carried", "paraphrased", "merged", "narrowed"}

problems = []
for sid, body in S.items():
    raw = json.load(open(os.path.join(RAW, sid + ".json"), encoding="utf-8"))
    ids = {c["claim_id"]: c for c in raw["claims"]}
    n = len(body["claims"])
    if not (2 <= n <= 4):
        problems.append(f"{sid}: {n} claims")
    used = []
    for c in body["claims"]:
        if c["certainty"] not in RANK:
            problems.append(f"{sid}: bad certainty {c['certainty']}")
        if c["transformation"] not in ALLOWED_T:
            problems.append(f"{sid}: bad transformation {c['transformation']}")
        if not c["source_claim_ids"]:
            problems.append(f"{sid}: claim without sources")
        weakest = min(RANK[ids[s]["certainty"]] for s in c["source_claim_ids"] if s in ids) if c["source_claim_ids"] else 0
        for s in c["source_claim_ids"]:
            if s not in ids:
                problems.append(f"{sid}: unknown source {s}")
        if RANK[c["certainty"]] > weakest:
            problems.append(f"{sid}: certainty stronger than weakest source")
        used += c["source_claim_ids"]
    dropped_ids = []
    for d in body["dropped"]:
        for s in d["source_claim_ids"]:
            if s not in ids:
                problems.append(f"{sid}: unknown dropped source {s}")
        dropped_ids += d["source_claim_ids"]
    dup = sorted({s for s in used if used.count(s) > 1})
    overlap = sorted(set(used) & set(dropped_ids))
    uncovered = sorted(set(ids) - set(used) - set(dropped_ids))
    print(f"{sid}: report_id={raw['report_id']} claims={n} sources={len(ids)} dup_in_claims={dup} overlap_with_dropped={overlap} uncovered={uncovered}")
    out = {"report_id": raw["report_id"], "claims": body["claims"], "dropped": body["dropped"]}
    with open(os.path.join(OUT, sid + ".json"), "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2, ensure_ascii=False)
        f.write("\n")

print("PROBLEMS:", problems if problems else "none")
