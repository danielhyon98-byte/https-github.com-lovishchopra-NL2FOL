"""Price token_meter.py output. Output tokens are estimated from saved content size (chars/3.5); the transcripts
store placeholder output counts. Prices per million tokens (secondary sources, Oct 2026)."""
import json, sys
P = {"opus": dict(input=4, cache_write_5m=5, cache_write_1h=8, cache_read=0.20, output=20),
     "haiku": dict(input=0.10, cache_write_5m=0.125, cache_write_1h=0.20, cache_read=0.01, output=0.50),
     "fable": dict(input=4, cache_write_5m=5, cache_write_1h=8, cache_read=0.20, output=20)}
def price(a):
    m = (a.get("model") or "opus")
    k = "haiku" if "haiku" in m else "fable" if "fable" in m else "opus"
    out = a["out_chars"] / 3.5
    pr = P[k]
    return (a["input"] * pr["input"] + a["cache_write_5m"] * pr["cache_write_5m"] + a["cache_write_1h"] * pr["cache_write_1h"]
            + a["cache_read"] * pr["cache_read"] + out * pr["output"]) / 1e6, out
