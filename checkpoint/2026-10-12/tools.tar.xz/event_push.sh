#!/usr/bin/env bash
# Push a change to Bruno's repository as soon as it is final and simulated (Daniel, 2026-10-12 21:4x UTC: "once a change
# has been made push an update to Bruno's repository"), in addition to the hourly push on the dot.
# Runs after presim.sh in the presim loop. It pushes nothing by itself: it calls the same publishers the hourly push uses,
# on their fast path (HOURLY_FAST=1: only a simulation prepared by presim.sh on exactly that code, the bans, the backup
# branch, ordinary pushes), and only when there is NEW final code:
#   translator: the newest final commit on the development branch differs from the source on verified-updates and its
#               prepared simulation is OK (PUBLISH_NO_STATUS=1: never an hourly progress note from here);
#   overseer:   a prepared simulation is OK for a candidate after the last upload (the publisher re-checks its gate).
# The hourly push owns hh:56 to hh:03; nothing runs then. Prints one line per publisher it ran.
set -uo pipefail
S=$(cd "$(dirname "$0")" && pwd)
R=/home/user/https-github.com-lovishchopra-NL2FOL
DEV=claude/z3-verification-engine-plan-nk3luq
BASELINE=3147d08e0aa63d5eeaceb1072754f29e3862164d
M=$((10#$(date -u +%M)))
[ "$M" -ge 56 ] || [ "$M" -le 3 ] && exit 0
cd "$R" || exit 0
PUB=$(git log -1 --format=%B refs/remotes/epinoic/verified-updates 2>/dev/null | sed -n 's/^Source-Commit: //p' | tail -1)
# The same final-commit rule as presim.sh and publish_final.sh.
FINAL=$(git log --format='%H%x09%s' "$BASELINE..$DEV" | awk -F'\t' '!found && ($2 ~ /^Fix the r[0-9]+ arena overseer findings$/ || $2 ~ /^Arena results: / || $2 == "Merge STEM support into the translator" || $2 == "Merge the logic-checking overseer agents into the translator" || $2 ~ /^Fix the c[0-9]+ clearance findings$/ || $2 == "Scaling: any number of agents per task" || $2 ~ /^Fix the m[0-9]+ multi-agent (optimisation )?findings$/ || $2 ~ /^Fix the r[0-9]+ handoff findings$/ || $2 ~ /^Fix the o[0-9]+ optimization findings$/ || $2 == "Fix the optimization findings" || $2 == "Fix the external review findings" || $2 ~ /^Delivery: / || $2 ~ /^Prototype: /) {print $1; found=1}')
if [ -n "$FINAL" ] && [ -n "$PUB" ] && [ "$FINAL" != "$PUB" ] && [ "$(grep -c '^SIMULATION OK' "$S/simcache/translator-$FINAL.txt" 2>/dev/null)" -gt 0 ]; then
  OUT=$(cd "$S" && HOURLY_FAST=1 PUBLISH_NO_STATUS=1 timeout 100 bash "$S/publish_final.sh" 2>&1 | tail -4 | tr '\n' ' ')
  echo "event push translator $(git rev-parse --short "$FINAL") $(date -u +%H:%M:%S): $OUT"
fi
LAST=$(git log -1 --format=%B refs/remotes/epinoic/overseer-prototype 2>/dev/null | sed -n 's/^Source-Commit: //p' | tail -1)
if [ -n "$LAST" ]; then
  NEW=""
  for f in "$S"/simcache/overseer-*.txt; do
    [ -e "$f" ] || continue
    C=$(basename "$f" .txt); C=${C#overseer-}
    [ "$(grep -c '^SIMULATION OK' "$f")" -gt 0 ] || continue
    git merge-base --is-ancestor "$C" "$LAST" 2>/dev/null && continue    # already uploaded (or older)
    NEW=$C
  done
  if [ -n "$NEW" ]; then
    OUT=$(cd "$S" && HOURLY_FAST=1 timeout 40 bash "$S/publish_overseer.sh" 2>&1 | tail -4 | tr '\n' ' ')
    echo "event push overseer $(git rev-parse --short "$NEW") $(date -u +%H:%M:%S): $OUT"
  fi
fi
exit 0
