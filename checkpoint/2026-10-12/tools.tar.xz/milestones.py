#!/usr/bin/env python3
"""Print one MILESTONE line, once, for each phase-2 journal event listed in watch-milestones.txt ("<started|result> <label regex>")."""
import json, os, re, sys
S = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad"
J = "/root/.claude/projects/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/subagents/workflows/wf_eee12853-0ae/journal.jsonl"
cfg, state = os.path.join(S, "watch-milestones.txt"), os.path.join(S, "watch-milestones.state")
try:
    wants = [l.split(None, 1) for l in open(cfg) if l.strip() and not l.startswith("#")]
except OSError:
    sys.exit()
try:
    seen = set(json.load(open(state)))
except Exception:
    seen = set()
lab, hits = {}, []
for l in open(J):
    try:
        d = json.loads(l)
    except Exception:
        continue
    if d.get("type") == "started":
        lab[d["key"]] = d.get("label", "")
    L = lab.get(d.get("key"), "")
    for kind, pat in wants:
        key = f"{kind} {pat.strip()}"
        if key not in seen and d.get("type") == kind and re.search(pat.strip(), L or ""):
            seen.add(key); hits.append(f"MILESTONE {kind} {L}")
for h in hits:
    print(h)
json.dump(sorted(seen), open(state, "w"))
