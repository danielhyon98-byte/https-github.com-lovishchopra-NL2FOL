# Prints one line per new result event (key labels) in the watched workflow journals; state in result_watch.state
import json,sys,os,time
WF='/root/.claude/projects/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/subagents/workflows'
RUNS=['wf_0d5b0b62-dbd','wf_92057cdf-3e2','wf_1683c1c3-d71','wf_4015a4e9-d80','wf_c141b543-aff','wf_f3ecd8b3-a17','wf_78542ca7-4b8']
ST=os.path.join(os.path.dirname(os.path.abspath(__file__)),'result_watch.state')
seen=set(json.load(open(ST))) if os.path.exists(ST) else None
cur=set(); out=[]
for run in RUNS:
    p=os.path.join(WF,run,'journal.jsonl')
    if not os.path.exists(p): continue
    lab={}
    for i,l in enumerate(open(p)):
        try: e=json.loads(l)
        except Exception: continue
        if e.get('type')=='started': lab[e.get('agentId')]=e.get('label')
        if e.get('type')=='result':
            k=f"{run}:{i}"; cur.add(k)
            if seen is not None and k not in seen:
                r=e.get('result'); s=''
                if isinstance(r,dict):
                    if 'issues' in r: s=f"ok={r.get('ok')} issues={len(r['issues'])} high={sum(1 for x in r['issues'] if x.get('severity') in ('high','blocker','critical'))}"
                    else: s=f"keys={list(r)[:6]}"
                out.append(f"RESULT {run} {lab.get(e.get('agentId'))} {s}")
        if e.get('type') in ('workflow_end','ended','error','failed'):
            k=f"{run}:{i}:end"; cur.add(k)
            if seen is not None and k not in seen: out.append(f"ENDED {run} {e.get('type')}")
json.dump(sorted(cur),open(ST,'w'))
for o in out: print(o,flush=True)
