#!/usr/bin/env bash
# Daniel approved pushes on 9 Nov 14:2x (#208). Install the publisher gate change ONLY when the upload simulation of the
# publisher's FINAL commit passed and its independent push check holds nothing; then dry-run. Pushes nothing itself.
set -euo pipefail
S=/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad
C4=c4f276ca060909e1e7d26c2ed403a6726c50eb2c
grep -q '^SIMULATION OK' "$S/simcache/translator-$C4.txt" || { echo "STOP: no passing simulation of $C4 yet"; exit 1; }
python3 -I -c "import json,sys; d=json.load(open(sys.argv[1])); sys.exit(0 if d.get('hold') is False and d.get('sha')==sys.argv[2] else 1)" "$S/push-check/$C4.json" "$C4" || { echo "STOP: the push check of $C4 does not pass"; exit 1; }
[ -e "$S/publish_final.sh.before-208" ] || cp -p "$S/publish_final.sh" "$S/publish_final.sh.before-208"
cp "$S/publish_final.sh.new" "$S/publish_final.sh"; chmod 700 "$S/publish_final.sh"
cmp -s "$S/publish_final.sh" "$S/publish_final.sh.new" && echo "installed: publish_final.sh = publish_final.sh.new (backup publish_final.sh.before-208)"
cd "$S" && HOURLY_FAST=1 PUBLISH_NO_STATUS=1 timeout 300 bash "$S/publish_final.sh" --dry-run 2>&1 | tail -8
