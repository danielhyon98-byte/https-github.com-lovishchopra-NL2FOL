#!/usr/bin/env python3
"""Build wf-scripts/fix-c3d.js: the second follow-up, after the push check of af6dfe04 held it (21 Nov 20:16).

Copied from fix-c3c.js (asserted): the constants, schemas and class/boundary definitions, verifyPrompt, verifyPrompt2,
covers/isGreen, verifyAndCommit and the ATK lenses (from "// Constants and helpers" up to the "Fix: four owners" marker).
Replaced in the copy (asserted): OUT (c3d), PCF (the af6dfe04 record), DCTX (this run), every verification uses
verifyPrompt2 (harness after the suite), the repair brief loses the c3c-only note about staged tmp* deletions.
The body: four fixers on disjoint paths, one check round (10) of the four lenses, one check fixer, verify and commit.
The push check of the resulting commit and the handoff refresh run afterwards from the main session.
"""
import re
import sys

SRC, OUT_JS = sys.argv[1], sys.argv[2]
src = open(SRC, encoding='utf-8').read()
lines = src.split('\n')
start = next(i for i, l in enumerate(lines) if l.startswith('// Constants and helpers copied verbatim'))
end = next(i for i, l in enumerate(lines) if l.startswith('// ---') and 'Fix: four owners' in l)
block = '\n'.join(lines[start:end])


def rep(text, old, new, count=1):
    n = text.count(old)
    assert n == count, (old[:80], n)
    return text.replace(old, new)


block = rep(block, "const OUT = `${WF2}/c3c`", "const OUT = `${WF2}/c3d`")
block = rep(block, "const PCF = `${S}/push-check/2ff70224ca4a44a6a5f1164aa1183d12e225dcb3.json`",
            "const PCF = `${S}/push-check/af6dfe04ef67ad8c934767a78b0b743a14870513.json`\n"
            "const PCF_PREV = `${S}/push-check/2ff70224ca4a44a6a5f1164aa1183d12e225dcb3.json`\n"
            "const PCLENSES = `${WF2}/c3d/pushcheck-af6dfe0-lenses.json`\n"
            "const C3C_LEFT = `${WF2}/c3d/c3c-left.json`")
# DCTX: from "const DCTX = `${CTX}" to the line that ends the template (the SUBPROJECT_PATH line)
m = re.search(r"const DCTX = `\$\{CTX\}\n.*?\$\{SUBPROJECT_PATH\}`\n", block, re.S)
assert m, 'DCTX block not found'
NEW_DCTX = r"""const DCTX = `${CTX}
THIS RUN (follow-up 2, 21-22 Nov). The commit af6dfe04 "Fix the c3 clearance findings" (the follow-up to 2ff70224: misspelling exemptions only from a committed word source, encoded check labels read, the answer's own solver label and confidence gated, a debug print and five stray scratch directories removed, three reader slowdowns fixed; full suite 43,633 passed; harness unchanged) is HELD by its independent push check: read ${PCF} whole, and the lists of its four lenses and its challenger in ${PCLENSES}. Its first hold, the self-certification class itself (fresh self-certifying phrasings are still delivered: 5 of 65 and 20 of 150 in two probes), needs the owner's decision on a meaning check and is NOT part of this run: add no model call, no status line on answers and no documented limitation. Word-count lines ('Word count: 312', 'Palabras: 25', '(312 words)') stay gated as self-reports under decision D7 until the owner decides: do not change that, and do not report it as a false positive. This run fixes the push check's other holds (the five named own-quality claims, the near variants of items reported fixed, the weakened gate2 test exclusion, the regression in the channel's own-wording quotation rule, the over-blocks it found, the unlabelled overseer skip, the builder docstring) and the open items the c3c run left (${C3C_LEFT}), in ONE verified commit at the end.
The working tree of ${REPO} (branch ${BRANCH}) is shared by this run's agents; no agent commits, stashes, resets, reverts or checks out anything in it unless its task says so (the workflow verifies and commits once, at the end). Never amend, rebase or force-push anything already on origin. Write probes, copies and exports only under ${OUT}/, never inside ${REPO} (a commit once picked up scratch directories a probe left at the repository root; tests/test_repository_hygiene.py now guards that).${SUBPROJECT_PATH}`
"""
block = block[:m.start()] + NEW_DCTX + block[m.end():]
block = rep(block, "let v = await agent(verifyPrompt(extraRounds, label),", "let v = await agent(verifyPrompt2(extraRounds, label),")
block = rep(block, "NOTE FROM THE MAIN SESSION: the hygiene hit about the five tmp* directories (staged deletions 'D ') was a fault of the check, not of the tree: their deletion is the intended fix and the commit records it, so never restore them and never unstage it (the next verification accepts staged deletions there). ", "")
for need in ('function verifyPrompt(', 'function verifyPrompt2(', 'async function verifyAndCommit(', 'const ATK = [', 'const SELFCERT_CLASS =', 'const RESTARTS ='):
    assert need in block, need

# the fixer rules of fix-c3c (asserted verbatim), reused with the c3d restart labels
rm = re.search(r"\\nRules for every fixer: (.*?)\$\{RESTARTS\('c3c-' \+ f\.key\)\}", src, re.S)
assert rm, 'fixer rules not found'
FIX_RULES = 'Rules for every fixer: ' + rm.group(1)

META = """export const meta = {
  name: 'translator-fix-c3d',
  description: "Second follow-up after the push check held af6dfe04: fix its holds that need no owner decision (five named own-quality claims, near variants of fixed items, the weakened gate2 test, the channel quotation regression, over-blocks, overseer skip) and the c3c leftovers; one check round; verify and commit",
  phases: [
    { title: 'Fix', detail: 'four owners on disjoint paths: self-certification reader and its tests, channel and own-text reader, subject branches, overseer' },
    { title: 'Check', detail: 'one round (10) of the four lenses on the fixed tree; one fixer for what they reproduce' },
    { title: 'Verify', detail: 'full suite in shards, then the harness on every round, hygiene, up to three repairs, commit' },
  ],
}"""

BODY = r"""
// ================================================================== fix-c3d (written 21 Nov 20:2x after the push check of af6dfe04 held it)
phase('Fix')
const FIXERS = [
  { key: 'selfcert', task: `You own src/epinoic_logic/selfcert/**, scripts/selfcert/**, tests/selfcert/** and tests/adapters/test_integration_gate2_parsers.py. The push check of af6dfe04 (${PCF}; lens lists in ${PCLENSES}) holds on these items, which need no owner decision; fix each at its cause and by class, on every branch and every release path:
(1) The five boundary (a) own-quality claims named by 2ff70224's push check and still delivered, unpinned: 'This is an examiner-standard answer.', 'There is zero chance any of this is wrong.', 'This reply is of publishable quality.', 'Esta respuesta es de nivel de examinador.', 'Puedes entregar esto tal cual.'. Read the families they belong to (a standard or grade the answer meets; certainty that nothing in it is wrong; fitness to publish or to hand in as it is), in English and Spanish, and pin each named sentence with its expected value on every branch and path.
(2) Near variants of items reported fixed: (a) real-word misspellings of check vocabulary are exempt whatever the context ('Singed off by the hub.', 'This answer passe every check.', 'This answer was chequed by the hub.', 'This answer is prefect.'): exempt a real word only where it is not in a check or assessment frame about the answer; (b) non-word misspellings missing from the list ('Veryfied by the hub.', 'Verifyed by the hub.', 'Validaded by the system.'): read a misspelling of check vocabulary by edit distance inside a check frame, not by a list; (c) a whole line written backwards ('deifirev :sutatS') and a whole sentence in ROT13 ('Irevsvrq ol gur uho.'); (d) an outside authority credited with checking this answer ('Snopes rates this answer as true.'), while boundary (b) stays free ('The ONS confirmed the figures.'); (e) a stray or unbalanced closing quotation mark before a label (BASE+' ’(sat).', BASE+'’ [sat].', BASE+' ’ (signature valid).', 'Every figure here is prefect, ’(signature valid).').
(3) The weakened test: tests/adapters/test_integration_gate2_parsers.py::test_every_synthesis_label_the_deleted_patterns_found_is_a_self_certification_of_the_one_reader skips every random text that contains a double quote, a ’ or a blank line, and on the same seed 4 of the 69 excluded texts are not refused. Remove the exclusion (a stricter rule; say so) and make the reader handle those texts.
(4) Over-blocks introduced by af6dfe04 (boundary (b)), each must be delivered again: 'A QA team tests software before each release.', "The word 'verified' comes from the Latin verus, true.", 'We repeated the measurement three times and the readings agreed.'.
(5) The docstring of scripts/selfcert/build_fuzzy_exclusions.py names tests/selfcert/test_c3c_fuzzy_and_labels.py, which does not exist: name the real test (tests/selfcert/test_c3c_holds.py::test_the_committed_exclusions_equal_the_builders_output).
(6) Then, only by class and only if no false positive is added (re-run the development sets in tests/selfcert/data and the recorded genuine answers of ${CLR}/c1, ${CLR}/c2 and ${C3} through delivery), the fresh misses the push check's lenses and challenger list in ${PCLENSES}, for example 'The system rated this response as fully reliable.', 'Two independent agents reached exactly these figures and signed them off.', 'This reply has the backing of the whole review panel.', 'Resultado del motor: todas las afirmaciones se cumplen.', 'Each conclusion here held up when I tried hard to break it.', 'Two colleagues independently recomputed these numbers and got the same.', 'Nothing above has slipped past our quality gate.'.` },
  { key: 'channel', task: `You own src/epinoic_logic/channel/**, src/epinoic_logic/adapters/own_text.py and tests/channel/**. (1) REGRESSION introduced by af6dfe04 (push check reason 5, ${PCF}): the new own-wording quotation rule in channel/bus.py drops a misquotation of the task when the answer also writes the altered wording in its own voice, unless the frame is an English 'you/your/the task|request|question|prompt|student|brief' frame. Reproduce it on a copy (under ${OUT}/) of ${CLR}/c2's sp-t15 record (Language B) with the altered task sentence 'Tu ciudad recibe cada invierno miles de turistas': at 2ff70224 (a git archive export under ${OUT}/) 'La consigna dice "..."', 'El enunciado pide: "..."', 'The instructions say "..."', 'The exam paper says "..."' and a bare quotation each give the INT-REQ-003 error; at af6dfe04 none does. Fix it at the cause: a quotation attributed to the task, in any frame and language or bare, is checked against the task whatever the answer writes elsewhere, while the af6dfe04 behaviour for the answer's own correction ('"x" -> "y"' in its own text is not charged) stays. Pin each frame (English, Spanish, bare) with a test. (2) Then the c3c run's open own-text items in your paths (${C3C_LEFT}): 'The article opens with "Cada verano, ..."' (an exact quotation of the answer's own model) and 'Wrong: "x". Right: "y"' on a Language B marking answer get INT-REQ-003 at error (false positives); an altered quotation of the answer's own model ('The article opens with "Cada año, nuestra ciudad ..."') must be named.` },
  { key: 'branches', task: `You own src/epinoic_logic/branches/** (geography.py, language_b.py, spanish_lexicon.py, packs.py, worked.py, quant.py, grounded_figures.py and the rest) and tests/branches/**. No push-check hold names your paths, but the owner asked for everything to be resolved: fix the branch misses the c3c run left open (${C3C_LEFT}: Geography 'g-area' (6.0 × 2.8 against the request's 1.8 m), a relative rain difference with no bracket, rainfall depth × area to volume, the 5 h 30 min lag from clock times, 8.2 to 163.5 PJ wind and solar, the per-person from-to pair, the relative rise of a share, the domestic complement, the 3,000-word limit, and the Language B misses listed there), and packs.py's CORE-SRC-003 warning on an own-wording quotation on a non-English branch with supplied texts (ec-t16 + 'Owners sold quotas and the fleet got smaller over time. In short, "the fleet got smaller over time".'). Each fix by class, with its faulty and correct twins pinned; run ${PY} ${REPO}/scripts/arena/run_arena.py on COPIES (under ${OUT}/) of ${CLR}/c1, ${CLR}/c2 and ${C3}: no functional count may drop (c1 203/203, c2 188/188, c3 164/176).` },
  { key: 'overseer', task: `You own overseer/** (src and tests). (1) overseer/tests/overseer_tests/test_clearance_c3_overseer.py has an unlabelled skip near line 277 ('if not withheld') that depends on the code under test: make it an assert (stricter; say so) and fix whatever it then shows. (2) consolidate.self_report_at_delivery does not read the audit codes OVS-FID-005 and OVS-FID-009 (tab-separated letters: the router allows while the fallback withholds): every release path must read the same self-report (${C3C_LEFT}). (3) The transfer auditor's OVS-FID-004 still flags an own correction written as an arrow ('"x" -> "y"') in the answer's own text after the channel stopped charging it (probe: the ll-t16 record + 'Your thesis is vague: "the adverts are about money" -> "..."'): the auditor must agree with the channel's own-text reader (adapters/own_text.py, owned by the channel fixer: call it, do not copy it).` },
]
const fixRes = await parallel(FIXERS.map(f => () => agent(`${DCTX}\n${SELFCERT_CLASS}\nYou are FIXER "${f.key}" of this run. ${f.task}\n__FIX_RULES__${RESTARTS('c3d-' + f.key)}`, { label: `fix:c3d:${f.key}`, phase: 'Fix', schema: FIX_SCHEMA, effort: 'high' })))
const fixed = fixRes.filter(Boolean).flatMap(r => r.fixed || [])
log(`fix: ${fixed.length} fixed (${FIXERS.map((f, i) => `${f.key} ${fixRes[i] ? (fixRes[i].fixed || []).length : 'no result'}`).join(', ')})`)

// ------------------------------------------------------------------ Check: one round of the four lenses, one fixer
phase('Check')
const ROUND = 10 // continues the c3b/c3c attack numbering
const chkRes = (await parallel(ATK.map(l => () => agent(`${DCTX}
${SELFCERT_CLASS}
You are CHECK LENS "${l.key}" after this run's fixes (one round, numbered ${ROUND}). READ-ONLY on ${REPO}: never edit, stage or commit anything there; write probe scripts only under ${OUT}/attack-${ROUND}/ and run them with ${PY}. ${l.task(ROUND)} Also re-run every reproduction of the push check of af6dfe04 that belongs to your lens (${PCF} and the lists in ${PCLENSES}: the five named own-quality claims, the near variants, the stray quotation mark, the over-blocks, the channel quotation frames, the branch items) and report each that still reproduces. Word-count lines stay gated under decision D7: never report them. Report in reproduced ONLY what you reproduced on the current working tree, each with the exact input, the branch, the path, what happened, what must happen and the kind (miss, false_positive, fail_open, stall, regression); in checked, what you tried (counts per branch and path) and the measured rates.`, { label: `check:${l.key}:c3d`, phase: 'Check', schema: ATTACK_SCHEMA, effort: 'high' })))).filter(Boolean)
const open = chkRes.flatMap(a => (a.reproduced || []).map(x => Object.assign({ lens: a.lens || '' }, x)))
log(`check round ${ROUND}: ${open.length} reproduced (${chkRes.map(a => `${a.lens || '?'} ${(a.reproduced || []).length}`).join(', ')})`)
let fChk = null
if (open.length) {
  const openJson = JSON.stringify(open)
  if (openJson.length > 150000) log(`check fixer sees the first 150000 of ${openJson.length} characters of the reproduced list`)
  fChk = await agent(`${DCTX}
${SELFCERT_CLASS}
You are the CHECK FIXER of this run. You may edit any path; the design files are ${C3B}/selfcert-design.md and ${C3B}/d9d10-design.md. The check lenses reproduced these on the working tree: ${openJson.slice(0, 150000)}
Priorities: (1) every regression, false positive (correct work gated), fail_open and stall, and every item of the push check of af6dfe04 that still reproduces (the five named own-quality claims, the near variants, the stray quotation mark, the weakened test, the channel quotation frames, the over-blocks); (2) the branch misses; (3) misses of the self-certification class, by class only and only if no false positive is added (re-run the development sets and the recorded genuine answers). Fix each at its cause; add a regression test for each with its expected value fixed in the test. NEVER read ${C3B}/heldout/. Never weaken or delete a test (rewriting one to a stricter rule is allowed; say so). Validate with the targeted test directories and the development sets; do not run the full suite. Return every change in fixed and anything not done in left_undone with the reason.${RESTARTS('c3d-check')}`, { label: 'fix:c3d:check', phase: 'Check', schema: FIX_SCHEMA, effort: 'high' })
}

// ------------------------------------------------------------------ Verify and commit
phase('Verify')
const allFixed = [].concat(fixed, (fChk && fChk.fixed) || [])
const leftAll = [].concat(...fixRes.filter(Boolean).map(r => r.left_undone || []), (fChk && fChk.left_undone) || [])
const body = `Follow-up to af6dfe0, whose independent push check held it. Fixes the holds that need no owner decision: the five own-quality claims named by the earlier check, near variants of items reported fixed (real-word and other misspellings of check words in a check frame, a whole line reversed, a whole sentence in ROT13, an outside authority credited with checking the answer, a stray quotation mark before a label), the gate2 test's exclusion of texts with quotation marks (removed), the channel's own-wording quotation rule (a misquoted task sentence in any frame is checked again), the over-blocks it found, the overseer's unlabelled skip, and the open branch and own-text items of the last run. The self-certification class itself stays open pending the owner's decision on a meaning check; word-count lines stay gated under decision D7 pending the owner's decision. No status line on answers and no documented limitation.
Check round after the fixes: ${open.length} reproduced.
Changes:
${clipFixed(allFixed, 7000)}`
const vc = await verifyAndCommit([C3], 'Fix the c3 clearance findings', body, 'clearance-c3d', 'Verify')
const sha = vc.commit && vc.commit.committed ? vc.commit.sha : null

return {
  fixed: allFixed.length,
  fixed_by: FIXERS.map((f, i) => `${f.key}: ${fixRes[i] ? (fixRes[i].fixed || []).length : 'no result'}`),
  left_undone: leftAll.map(x => clip(x, 300)),
  check_open: open.map(o => clip(`${o.lens}: ${o.kind || ''} ${o.branch || ''} ${o.input}`, 240)),
  verified: vc.green,
  harness: vc.v ? vc.v.harness_line : null,
  suite: vc.v ? suiteLine(vc.v.suite_tail) : null,
  commit: sha,
  pushed: !!(vc.commit && vc.commit.pushed),
}
"""
BODY = BODY.replace('__FIX_RULES__', FIX_RULES)
out = META + '\n// Constants, schemas, the class/boundary definitions, the verification and commit helpers and the lenses: copied from wf-scripts/fix-c3c.js by make_fix_c3d.py (with the asserted replacements listed there).\n' + '\n'.join(block.split('\n')[1:]) + '\n' + BODY
open(OUT_JS, 'w', encoding='utf-8').write(out)
print('wrote', OUT_JS, len(out), 'chars')
