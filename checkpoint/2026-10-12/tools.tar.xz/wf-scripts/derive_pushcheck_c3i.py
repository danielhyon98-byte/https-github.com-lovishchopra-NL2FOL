#!/usr/bin/env python3
"""Derive wf-scripts/make_pushcheck_c3i.py from make_pushcheck_c3h.py by asserted replacements (25 Nov).

Eleven held commits (84aff95c added); the context names what follow-up 7 (narrow, Geography table readings only) aims at,
taken from the push-check record of 84aff95c and the fixer tasks of fix-c3i, and the boundary lines as decided; the
critical-fixes, infected, weakened, branches-policy and readings-diff lenses name 84aff95c's items; labels and restart
files are c3i. Nothing in the lenses' standards, the challenger or the judge's hold rule is relaxed.

Usage: python3 -I derive_pushcheck_c3i.py wf-scripts/make_pushcheck_c3h.py wf-scripts/make_pushcheck_c3i.py
"""
import sys

SRC, OUT = sys.argv[1], sys.argv[2]
s = open(SRC, encoding='utf-8').read()


def rep(old, new, count=1):
    global s
    n = s.count(old)
    assert n == count, (old[:100], n)
    s = s.replace(old, new)


def span(start, end):
    i = s.index(start)
    j = s.index(end, i)
    return i, j


rep('"""Build wf-scripts/pushcheck-c3h.js: the independent push check of the fix-c3h follow-up commit (follow-up 6).\n',
    '"""Build wf-scripts/pushcheck-c3i.js: the independent push check of the fix-c3i follow-up commit (follow-up 7).\n\n'
    'Derived from make_pushcheck_c3h.py by derive_pushcheck_c3i.py (25 Nov): eleven held commits (84aff95c added), the context\n'
    'names what follow-up 7 (narrow, Geography table readings only) aims at and the boundary lines, and the lenses name\n'
    '84aff95c\'s items.\n')
rep("name: 'translator-pushcheck-c3h'", "name: 'translator-pushcheck-c3i'")
rep("Independent push check of the fix-c3h follow-up commit (args.sha)", "Independent push check of the fix-c3i follow-up commit (args.sha)")
rep("// ================================================================== Independent push check of follow-up 6 (pushcheck-c3h)",
    "// ================================================================== Independent push check of follow-up 7 (pushcheck-c3i)")
rep("const PREV = '67bc64ec336f87c641a83fd51eff8c8d521212f7'", "const PREV = '84aff95c1297c8826374801c159355b2de7c55ba'")
rep("'08c4a36b9d68885aac6bb81840d127c65a0ed409', PREV]",
    "'08c4a36b9d68885aac6bb81840d127c65a0ed409', '67bc64ec336f87c641a83fd51eff8c8d521212f7', PREV]")
rep("const PCO = `${WF2}/c3h/push-check`", "const PCO = `${WF2}/c3i/push-check`")

# the context paragraph
i, j = span('PUSH CHECK of ${SHA} (subject "Fix the c3 clearance findings": follow-up 6, after 67bc64ec).', ' Verify each of those claims yourself;')
old_pcx = s[i:j]
k = old_pcx.index('Its fixers were given these boundary lines')
boundary = old_pcx[k:].replace('taken from the records of the push checks of a9129c78, 08c4a36b and 67bc64ec',
                                'taken from the records of the push checks of a9129c78, 08c4a36b, 67bc64ec and 84aff95c')
assert 'and 84aff95c' in boundary
NEW_PCX = (
    'PUSH CHECK of ${SHA} (subject "Fix the c3 clearance findings": follow-up 7, after 84aff95c). It follows eleven HELD '
    'commits, oldest first: ${HELD_LIST}; read all eleven push checks whole (the last one, of 84aff95c, names what held it, and '
    'its lenses\' and challenger\'s lists are in ${WF2}/c3i/pushcheck-84aff95-lenses.json). The owner (16 Nov) asked for '
    'everything that holds them to be resolved: the self-certification class closed by meaning (no status line, no documented '
    'limitation), the POLICY_VERSION bump for eligibility rule 0, the Geography and Language B branches (D9/D10) and round '
    '10\'s open items; on 25 Nov the owner asked for development to continue until everything is right. The follow-ups '
    'af6dfe04, 2be42c48, a9129c78, 08c4a36b, 67bc64ec and 84aff95c fixed the holds of the commit before them that need no '
    'owner decision and were each held. This follow-up is NARROW: it changes only the Geography table readings '
    '(src/epinoic_logic/branches/geography.py, insertions.py, their README and tests/branches) and aims at the Geography '
    'holds of 84aff95c: a wrong figure shown as ENTAILED when a bracket or dash insertion holds a nested comparison (\'Coal '
    '(which, unlike natural gas, supplied about 9.3 GJ per person in 2025) declined.\'); a wrong figure in an insertion after '
    'the table\'s total-row phrase that lost its charge (\'Energy supply per person, at about 11.8 GJ in 2025, was high.\', '
    '\'Ostrel (about 38 GJ per person in 2025) imported more.\'); the label-colon form read against the total row (\'Coal: '
    'about 42 GJ per person in 2025.\'); and the c1/ge-t14 nested comparison (\'Site 2, which, unlike site 5, had a pedestrian '
    'count of 88, ...\'). Its rule: a figure is checked against the row its own clause names; a figure inside an insertion '
    'belongs to the noun the insertion attaches to; a noun inside a nested comparison never names the row; a label before a '
    'colon names the row; the total row named by its own phrase is the total row; where the row is not determined, the figure '
    'gets no check (never ENTAILED, never a charge on a correct twin). It changes no eligibility rule and makes no version '
    'bump, so the self-certification class, D-a and D-e stand as at 84aff95c: judge them as they stand. ' + boundary)
s = s[:i] + NEW_PCX + s[j:]

rep("as the judges of a9129c78, 08c4a36b and 67bc64ec recorded, a miss that the decided boundary already gates is a code defect whose hold does not depend on that decision",
    "as the judges of a9129c78, 08c4a36b, 67bc64ec and 84aff95c recorded, a miss that the decided boundary already gates is a code defect whose hold does not depend on that decision")
rep("as 'Nº de palabras: 87', 'Words used — 312' and 'Cuenta de palabras: 198' did at 67bc64ec)",
    "as 'Words in this response: 312' and 'Words used — 312 (excluding the title)' did at 84aff95c)")

# critical-fixes lens
rep("Check every item of the ten held checks' critical_open", "Check every item of the eleven held checks' critical_open")
rep("each with a reproduction that fails on the held commit 67bc64ec (or the earliest held commit",
    "each with a reproduction that fails on the held commit 84aff95c (or the earliest held commit")
i, j = span("include the regressions 67bc64ec introduced, each against the reading of 08c4a36b (", "and the replay worker")
NEW_REG = (
    "include the Geography items of 84aff95c's check against this follow-up's rule (on c2/ge-t15, where the record gives the "
    "true 2025 per-person figures as total 42.2 GJ, coal 11.8 GJ, oil 11.4 GJ and natural gas 9.3 GJ: 'Coal (which, unlike "
    "natural gas, supplied about 9.3 GJ per person in 2025) declined.' and its dash and square-bracket forms must not be "
    "ENTAILED and their correct 11.8 GJ twins must not be charged; 'Energy supply per person, at about 11.8 GJ in 2025, was "
    "high.', 'Energy supply, at about 38 GJ per person in 2025, rose.' and 'Ostrel (about 38 GJ per person in 2025) imported "
    "more.' must regain their COUNTEREXAMPLE with INT-SUBJ-004 and their correct 42 GJ twins must not be charged; 'Coal: about "
    "42 GJ per person in 2025.', 'Oil: roughly 42 GJ per head in 2025.' and 'Natural gas: 42 GJ per person in 2025, up from "
    "2005.' must not be ENTAILED and their correct twins must not be charged; on c1/ge-t14 'Site 2, which, unlike site 5, had a "
    "pedestrian count of 88, ...' must not be ENTAILED and its correct twin must not be charged), the fixes of 84aff95c that "
    "must stay fixed (the correction-pair key and the possibility frame gated as at 08c4a36b; the D-a year lines gated; the "
    "named D-e lines gated; 'Coal, which supplied about 42 GJ per person in 2025, declined.' and 'Oil (about 42 GJ per person "
    "in 2025) changed least.' with their COUNTEREXAMPLE; the Language B 'Incorrecto: ... Correcto: ...' pair on c1/sp-t14 with "
    "its COUNTEREXAMPLE plus INT-SUBJ-004), the own-verdict reading in one long report-opened and-joined sentence at about 380 "
    "characters and at 6, 8.1, 9.1, 12 and 20 KB (it must read True at every length, with selfcert and meta_notes agreeing), "
    "the credited evaluator pieces after N = 30, 63, 64, 65 and 500 benign examiner pieces (True at every N or fail closed with "
    "a named finding), the channel's blockquote check (an altered task sentence after 0, 63, 64 and 200 benign blockquote "
    "blocks, and inside one 2,321-character block, must each be named or fail closed with a named finding), ")
s = s[:i] + NEW_REG + s[j:]

# infected and weakened lenses
rep("and closely the diff 67bc64ec..${SHA}, for anything malicious", "and closely the diff 84aff95c..${SHA}, for anything malicious")
rep("and closely in 67bc64ec..${SHA}; for each decide", "and closely in 84aff95c..${SHA}; for each decide")
i, j = span("Pin moves expected in this follow-up, which are not weakenings when the new pin is exact:",
            "check in particular that no timing bound or timing helper changed in 67bc64ec..${SHA}.")
j += len("check in particular that no timing bound or timing helper changed in 67bc64ec..${SHA}.")
NEW_PINS = (
    "Pin moves expected in this follow-up, which are not weakenings when the new pin is exact and stricter: "
    "tests/branches/test_c3h_branches.py pins of the total-row insertion forms move from unchecked to the correct readings "
    "(the wrong twin COUNTEREXAMPLE with INT-SUBJ-004, the correct twin ENTAILED); no version pin moves. Report every pin that "
    "moves from gated to delivered, from a finding to no finding, or from checked to unchecked, and decide whether it hides a "
    "failure; check in particular that no timing bound or timing helper changed in 84aff95c..${SHA}.")
s = s[:i] + NEW_PINS + s[j:]

# branches-policy lens: the Geography grid and the version discipline
i, j = span("the row and column lookups of the Geography and Language B packs (only the subject noun phrase of the figure's own clause "
            "names a row or a column, and a figure inside an insertion", "sweep other rows and columns the same way,")
NEW_ROWS = (
    "the row and column lookups of the Geography and Language B packs under this follow-up's rule (build your OWN grid of "
    "fresh forms that git grep shows absent from the repository, on c2/ge-t15 and c1/ge-t14: every row and every site in each "
    "insertion form (relative clause, 'whose' clause, round and square bracket, dash pair, comma pair, 'at ...' phrase, -ing "
    "and -ed participle, apposition, label before a colon), with and without a nested comparison ('unlike X', 'compared with "
    "X', 'more than X', 'exceeding X', 'outweighing X', 'rather than X', 'as opposed to X', 'like X', 'than X', 'a diferencia "
    "de X', 'en comparación con X', 'más que X'), with the total row named by its own phrase and its variants, each with a "
    "faulty and a correct twin: every wrong figure shown as ENTAILED is critical, every correct figure charged is a defect, and "
    "every wrong figure left unchecked where 84aff95c or 67bc64ec charged it is a weakened check; report also the main-clause "
    "comparison without commas ('Coal unlike natural gas supplied about 9.3 GJ per person in 2025.', named by the commit as left "
    "open) and how the 'about' and 'roughly' tolerance treats a figure that matches a different row within it (11.4 GJ read as "
    "about 11.8 GJ), as an observation for the owner; the cases fixed before stay fixed (the mid-sentence subordinate clause "
    "'Energy supply per person, while coal declined, was about 11.8 GJ in 2025.' not ENTAILED; on c1/sp-t14 the undated "
    "reopening figure not ENTAILED; on c3/sp-t16 'El intercambio, según la consigna, duró dos semanas.' named); ")
s = s[:i] + NEW_ROWS + s[j:]
i, j = span("and the version discipline of eligibility rule 0 and the POLICY_VERSION (this follow-up bumps the versions for its rule "
            "changes:", "version.py and its history;")
j += len("version.py and its history;")
NEW_VER = (
    "and the version discipline of eligibility rule 0 and the POLICY_VERSION (this follow-up changes no eligibility rule and "
    "makes no version bump: check that git -C ${REPO} diff --name-only 84aff95c ${SHA} touches nothing under "
    "src/epinoic_logic/selfcert/, src/epinoic_logic/translate/, src/epinoic_logic/integration/ or src/epinoic_logic/version.py, "
    "that POLICY_VERSION stays 2026.11-v8, SELFCERT_RULES selfcert-4 and the contract 0.9, and that the kit checks pass with "
    "the repository's own tools; version.py and its history;")
s = s[:i] + NEW_VER + s[j:]

# readings-diff lens
rep("between the held commit 67bc64ec and ${SHA}:", "between the held commit 84aff95c and ${SHA}:")
rep("(name the item of 67bc64ec's push check,", "(name the item of 84aff95c's push check,")

# labels, restart files, judge
rep("RESTARTS('pushcheck-c3h-' + l.key)", "RESTARTS('pushcheck-c3i-' + l.key)")
rep("label: `push-check-lens:${l.key}:c3h`", "label: `push-check-lens:${l.key}:c3i`")
rep("RESTARTS('pushcheck-c3h-challenger')", "RESTARTS('pushcheck-c3i-challenger')")
rep("label: 'push-check-challenge:c3h'", "label: 'push-check-challenge:c3i'")
rep("label: 'push-check:c3h'", "label: 'push-check:c3i'")
rep("(every item of the ten held checks' critical_open,", "(every item of the eleven held checks' critical_open,")
rep("copied verbatim from wf-scripts/fix-c3c.js by make_pushcheck_c3h.py.", "copied verbatim from wf-scripts/fix-c3c.js by make_pushcheck_c3i.py.")

body = s.split('"""', 2)[2]
for bad in ('c3h', 'follow-up 6', 'ten held', 'ten push', 'held commit 67bc64ec', "67bc64ec's push check,", '67bc64ec..${SHA}',
            'bumps the versions for its rule'):
    assert bad not in body, bad
for t in (NEW_PCX, NEW_REG, NEW_ROWS, NEW_PINS, NEW_VER):
    assert '"""' not in t and '`' not in t
open(OUT, 'w', encoding='utf-8').write(s)
print('wrote', OUT, len(s), 'chars')
