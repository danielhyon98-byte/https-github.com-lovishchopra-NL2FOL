export const meta = {
  name: 'argdiag-security-fix',
  description: 'Argument diagnostics: make every regular expression and reader that the staged changes add linear (the quadratic space-grouped thousands reading first), with timing tests, then verify independently (nothing is committed)',
  phases: [
    { title: 'Fix', detail: 'one fixer: the reported quadratic reading, then a sweep of every pattern the staged diff adds' },
    { title: 'Verify', detail: 'security lens (adversarial timing of every added pattern, both trees) and regression lens (suite, corpora, arena unchanged)' },
  ],
}
