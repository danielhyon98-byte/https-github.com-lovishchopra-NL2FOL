#!/usr/bin/env python3
"""Build wf-scripts/fix-c3g.js: the fifth follow-up, after the push check of 08c4a36b (23 Nov).

Usage: python3 -I make_fix_c3g.py wf-scripts/fix-c3f.js wf-scripts/fix-c3g.js

Derived from the generated fix-c3f.js by asserted replacements only: the meta block, OUT (c3g), the push-check record
constants (PCF = the 08c4a36b record, PCF_PREV = the a9129c78 record, PCLENSES, C3F_LEFT), the THIS RUN paragraph of
DCTX, the FIXERS array (from c3g_fixers.py), every c3f label and restart file (c3g), the attack round (13), the names of
the previous record in the lens and check-fixer prompts, and the commit body. Everything else (schemas, the class and
boundary, the verification helpers, the held-out rule, the timing rule, the check fixer) is carried over verbatim.
"""
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from c3g_fixers import FIXERS, DCTX_RUN, COMMIT_BODY, KIT_TASK  # noqa: E402

SRC, OUT_JS = sys.argv[1], sys.argv[2]
s = open(SRC, encoding='utf-8').read()


def rep(text, old, new, count=1):
    n = text.count(old)
    assert n == count, (old[:90], n)
    return text.replace(old, new)


# meta
m = re.match(r"export const meta = \{.*?\n\}\n", s, re.S)
assert m, 'meta not found'
META = """export const meta = {
  name: 'translator-fix-c3g',
  description: "Fifth follow-up after the push check held 08c4a36b: fix its regressions and the items that need no owner decision, and the c3f leftovers that need none (the auditor's reading of own corrections, branch misses); one check round with a readings diff; the version bump; verify and commit",
  phases: [
    { title: 'Fix', detail: 'four owners on disjoint paths: self-certification reader and its tests, channel and quotation readers, subject branches, overseer' },
    { title: 'Check', detail: 'one round (13): phrasings, correct work, branches and a readings diff against HEAD, held-out lines reported by category only; one fixer for what they reproduce and the fixers leave' },
    { title: 'Version', detail: 'one KIT step after every fixer: the version bump for the rule changes of this run and the last, the kit regenerated with the repository tools' },
    { title: 'Verify', detail: 'full suite in shards, then the harness on every round, hygiene, up to three repairs, commit' },
  ],
}
"""
s = META + s[m.end():]

s = rep(s, "const OUT = `${WF2}/c3f`", "const OUT = `${WF2}/c3g`")
s = rep(s,
        "const PCF = `${S}/push-check/a9129c78de9fdcdb6d93a42a2e08ae413d7b1cd0.json`\n"
        "const PCF_PREV = `${S}/push-check/2be42c4808c0b23e9ea7a3db7992f7bd9863a545.json`\n"
        "const PCLENSES = `${WF2}/c3f/pushcheck-a9129c7-lenses.json`\n"
        "const C3E_LEFT = `${WF2}/c3f/c3e-left.json`",
        "const PCF = `${S}/push-check/08c4a36b9d68885aac6bb81840d127c65a0ed409.json`\n"
        "const PCF_PREV = `${S}/push-check/a9129c78de9fdcdb6d93a42a2e08ae413d7b1cd0.json`\n"
        "const PCLENSES = `${WF2}/c3g/pushcheck-08c4a36-lenses.json`\n"
        "const C3F_LEFT = `${WF2}/c3g/c3f-left.json`")
# THIS RUN paragraph: from 'THIS RUN (follow-up 4' to the line before 'The working tree of'
i = s.index('THIS RUN (follow-up 4, 23 Nov).')
j = s.index('\nThe working tree of ${REPO} (branch ${BRANCH}) is shared', i)
s = s[:i] + DCTX_RUN.strip('\n') + s[j:]
# FIXERS array
i = s.index('const FIXERS = [\n')
j = s.index('\n]\nconst fixRes = await parallel(FIXERS.map', i)
for k, t in FIXERS:
    assert '`' not in t, ('backtick in fixer task', k)
s = s[:i] + 'const FIXERS = [\n' + ',\n'.join("  { key: '%s', task: `%s` }" % (k, t.strip('\n')) for k, t in FIXERS) + s[j:]
# labels, restart files, round, previous record names
s = rep(s, "RESTARTS('c3f-' + f.key)", "RESTARTS('c3g-' + f.key)")
s = rep(s, "label: `fix:c3f:${f.key}`", "label: `fix:c3g:${f.key}`")
s = rep(s, "label: `check:${l.key}:c3f`", "label: `check:${l.key}:c3g`")
s = rep(s, "label: 'fix:c3f:check'", "label: 'fix:c3g:check'")
s = rep(s, "RESTARTS('c3f-check')", "RESTARTS('c3g-check')")
s = rep(s, "${OUT}/progress-c3f-*.md", "${OUT}/progress-c3g-*.md")
s = rep(s, "'clearance-c3f'", "'clearance-c3g'")
s = rep(s, "const ROUND = 12 // continues the attack numbering", "const ROUND = 13 // continues the attack numbering")
s = rep(s, "Also re-run every reproduction of the push check of a9129c78 that belongs to your lens", "Also re-run every reproduction of the push check of 08c4a36b that belongs to your lens")
s = rep(s, "and every item of the push check of a9129c78 that still reproduces", "and every item of the push check of 08c4a36b that still reproduces")
# commit body: replace the fixed text between 'const body = `' and '\nCheck round after the fixes'
i = s.index('const body = `')
j = s.index('\nCheck round after the fixes: ${open.length} reproduced.', i)
assert '`' not in COMMIT_BODY and '${' not in COMMIT_BODY
s = s[:i] + 'const body = `' + COMMIT_BODY.strip() + s[j:]
# KIT step: after the check fixer, before the verify phase; its fixed and left items join allFixed and leftAll
assert '`' not in KIT_TASK
assert set(re.findall(r'\$\{([^}]*)\}', KIT_TASK)) <= {'C3B', 'PCF', 'PY'}, set(re.findall(r'\$\{([^}]*)\}', KIT_TASK))
s = rep(s,
        "\n}\n\n// ------------------------------------------------------------------ Verify and commit\nphase('Verify')\n"
        "const allFixed = [].concat(fixed, (fChk && fChk.fixed) || [])\n"
        "const leftAll = [].concat(fixLeft, (fChk && fChk.left_undone) || [])\n",
        "\n}\n\n// ------------------------------------------------------------------ Version bump (one KIT step after every fixer)\n"
        "phase('Version')\n"
        "const fKit = await agent(`${DCTX}\n" + KIT_TASK.strip() + "\n${TIMING}${RESTARTS('c3g-kit')}`, "
        "{ label: 'fix:c3g:kit', phase: 'Version', schema: FIX_SCHEMA, effort: 'high' })\n"
        "log(`KIT step: ${fKit ? (fKit.fixed || []).length + ' changes, ' + (fKit.left_undone || []).length + ' left' : 'no result'}`)\n"
        "\n// ------------------------------------------------------------------ Verify and commit\nphase('Verify')\n"
        "const allFixed = [].concat(fixed, (fChk && fChk.fixed) || [], (fKit && fKit.fixed) || [])\n"
        "const leftAll = [].concat(fixLeft, (fChk && fChk.left_undone) || [], (fKit && fKit.left_undone) || [])\n")
s = rep(s, "// ================================================================== fix-c3f (written 23 Nov after the push check of a9129c78 held it)",
        "// ================================================================== fix-c3g (written 23 Nov after the push check of 08c4a36b)")
for bad in ('fix:c3f:', "'c3f-", 'clearance-c3f', 'progress-c3f', 'C3E_LEFT', 'ROUND = 12'):
    assert bad not in s, bad
open(OUT_JS, 'w', encoding='utf-8').write(s)
print('wrote', OUT_JS, len(s), 'chars')
