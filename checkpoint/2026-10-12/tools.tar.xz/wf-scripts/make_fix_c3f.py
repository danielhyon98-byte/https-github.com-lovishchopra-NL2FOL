#!/usr/bin/env python3
"""Build wf-scripts/fix-c3f.js: the fourth follow-up, after the push check of a9129c78 held it (23 Nov).

Usage: python3 -I make_fix_c3f.py wf-scripts/fix-c3e.js wf-scripts/fix-c3f.js

Copied from fix-c3e.js (asserted): the constants, schemas, the class/boundary definitions, verifyPrompt, verifyPrompt2,
covers/isGreen, verifyAndCommit and the ATK lenses (from the "// Constants, schemas" line up to the "fix-c3e (written"
marker). Replaced in the copy (asserted): OUT (c3f), PCF (the a9129c78 record), DCTX (this run).
The fixer tasks live in c3f_fixers.py (FIXERS, raw JS template text), written after the push-check record was read.
The body: four fixers on disjoint paths, one check round (12) of four lenses (phrasings, correct work, branches, readings
diff) under the held-out rule, one check fixer that also gets the fixers' left_undone, then verify and commit.
The push check of the resulting commit and the handoff refresh run afterwards from the main session.
"""
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from c3f_fixers import FIXERS, DCTX_RUN, COMMIT_BODY  # noqa: E402

SRC, OUT_JS = sys.argv[1], sys.argv[2]
src = open(SRC, encoding='utf-8').read()
lines = src.split('\n')
start = next(i for i, l in enumerate(lines) if l.startswith('// Constants, schemas, the class/boundary definitions'))
end = next(i for i, l in enumerate(lines) if l.startswith('// ===') and 'fix-c3e (written' in l)
block = '\n'.join(lines[start:end])


def rep(text, old, new, count=1):
    n = text.count(old)
    assert n == count, (old[:80], n)
    return text.replace(old, new)


block = rep(block, "const OUT = `${WF2}/c3e`", "const OUT = `${WF2}/c3f`")
block = rep(block,
            "const PCF = `${S}/push-check/2be42c4808c0b23e9ea7a3db7992f7bd9863a545.json`\n"
            "const PCF_PREV = `${S}/push-check/af6dfe04ef67ad8c934767a78b0b743a14870513.json`\n"
            "const PCLENSES = `${WF2}/c3e/pushcheck-2be42c4-lenses.json`\n"
            "const C3D_LEFT = `${WF2}/c3e/c3d-left.json`",
            "const PCF = `${S}/push-check/a9129c78de9fdcdb6d93a42a2e08ae413d7b1cd0.json`\n"
            "const PCF_PREV = `${S}/push-check/2be42c4808c0b23e9ea7a3db7992f7bd9863a545.json`\n"
            "const PCLENSES = `${WF2}/c3f/pushcheck-a9129c7-lenses.json`\n"
            "const C3E_LEFT = `${WF2}/c3f/c3e-left.json`")
m = re.search(r"const DCTX = `\$\{CTX\}\n.*?\$\{SUBPROJECT_PATH\}`\n", block, re.S)
assert m, 'DCTX block not found'
NEW_DCTX = "const DCTX = `${CTX}\n" + DCTX_RUN.strip('\n') + """
The working tree of ${REPO} (branch ${BRANCH}) is shared by this run's agents; no agent commits, stashes, resets, reverts or checks out anything in it unless its task says so (the workflow verifies and commits once, at the end). Never amend, rebase or force-push anything already on origin. Write probes, copies and exports only under ${OUT}/, never inside ${REPO} (tests/test_repository_hygiene.py guards the root).${SUBPROJECT_PATH}`
"""
block = block[:m.start()] + NEW_DCTX + block[m.end():]
for need in ('function verifyPrompt(', 'function verifyPrompt2(', 'async function verifyAndCommit(', 'const ATK = [', 'const SELFCERT_CLASS =', 'const RESTARTS =',
             "let v = await agent(verifyPrompt2(extraRounds, label),"):
    assert need in block, need
assert 'C3D_LEFT' not in block, 'C3D_LEFT still referenced in the copied block'

# the fixer rules of fix-c3e (asserted verbatim), reused with the c3f restart labels
rm = re.search(r"\\nRules for every fixer: (.*?)\$\{RESTARTS\('c3e-' \+ f\.key\)\}", src, re.S)
assert rm, 'fixer rules not found'
FIX_RULES = 'Rules for every fixer: ' + rm.group(1)
assert 'never read ${C3B}/heldout/' in FIX_RULES

META = """export const meta = {
  name: 'translator-fix-c3f',
  description: "Fourth follow-up after the push check held a9129c78: fix its regressions, fail-open readers and the items that need no owner decision, the replay worker that outlives its parent, and the c3e leftovers; one check round with a readings diff; verify and commit",
  phases: [
    { title: 'Fix', detail: 'four owners on disjoint paths: self-certification reader and its tests, channel and quotation readers, subject branches, overseer' },
    { title: 'Check', detail: 'one round (12): phrasings, correct work, branches and a readings diff against HEAD, held-out lines reported by category only; one fixer for what they reproduce and the fixers leave' },
    { title: 'Verify', detail: 'full suite in shards, then the harness on every round, hygiene, up to three repairs, commit' },
  ],
}"""

fixers_js = ',\n'.join("  { key: '%s', task: `%s` }" % (k, t.strip('\n')) for k, t in FIXERS)
for k, t in FIXERS:
    assert '`' not in t, ('backtick in fixer task', k)

BODY = r"""
// ================================================================== fix-c3f (written 23 Nov after the push check of a9129c78 held it)
// HELD-OUT RULE (23 Nov): in check round 11 the lenses quoted held-out lines in their reproduced lists, which reached the check
// fixer. From here on a held-out failure is reported by category and counts only (in checked), never quoted, and any reproduced
// item that names a held-out file is dropped (counted) before the check fixer sees the list.
const HELDOUT_RULE = `HELD-OUT RULE: ${C3B}/heldout/ is a blind measurement set. A held-out line that fails is reported ONLY in checked, by its category, branch, path and counts, never quoted and never in reproduced; where the same failure reproduces with a fresh sentence of your own, report that sentence in reproduced.`
const TIMING = `TIMING (the c3e verification failed twice on wall-clock bounds under the two-shard load): after your changes, run the wall-clock tests of every module you touched (grep the test tree for linear_time, in_seconds, median_time, PARSE_BOUND, CALL_BOUND, measure(, growth( and pytest.mark.timeout) and always tests/adapters_history/test_integration_gate2_chronology.py, tests/stem/test_integration_gate2_handoff.py, tests/selfcert/test_linear.py and tests/engine/test_stem_shapes.py, while a second pytest process runs tests/branches at the same time; any of them under 25% headroom is a finding: make the code faster at its cause with no change in any reading (never a bound, a timeout, a window or a test).`
phase('Fix')
const FIXERS = [
__FIXERS__
]
const fixRes = await parallel(FIXERS.map(f => () => agent(`${DCTX}\n${SELFCERT_CLASS}\nYou are FIXER "${f.key}" of this run. ${f.task}\n${TIMING}\n__FIX_RULES__${RESTARTS('c3f-' + f.key)}`, { label: `fix:c3f:${f.key}`, phase: 'Fix', schema: FIX_SCHEMA, effort: 'high' })))
const fixed = fixRes.filter(Boolean).flatMap(r => r.fixed || [])
log(`fix: ${fixed.length} fixed (${FIXERS.map((f, i) => `${f.key} ${fixRes[i] ? (fixRes[i].fixed || []).length : 'no result'}`).join(', ')})`)

// ------------------------------------------------------------------ Check: phrasings, correct work, branches and a readings diff; one fixer
phase('Check')
const ROUND = 12 // continues the attack numbering
const LENSES = ATK.filter(l => l.key !== 'paths').concat([{ key: 'readings-diff', task: r => `Compare every recorded answer's readings between HEAD (git -C ${REPO} archive HEAD into ${OUT}/attack-${r}/head/, run with that tree's src first on the path) and the working tree. For every record of ${CLR}/c1, ${CLR}/c2, ${C3} and ${ARENA}/r1 to r7 (on COPIES under ${OUT}/attack-${r}/), run the same pipeline on both trees and list every claim whose check status (ENTAILED, COUNTEREXAMPLE, NOT_ELIGIBLE and the rest), findings, receipt codes or delivery decision differ. Classify each difference as an intended fix (name the item of the push check or of this run it implements) or a regression (kind regression), and look hardest for a wrong figure that gains ENTAILED or loses a finding, and a correct figure that gains a COUNTEREXAMPLE or a finding.` }])
const chkRes = (await parallel(LENSES.map(l => () => agent(`${DCTX}
${SELFCERT_CLASS}
You are CHECK LENS "${l.key}" after this run's fixes (one round, numbered ${ROUND}). READ-ONLY on ${REPO}: never edit, stage or commit anything there; write probe scripts only under ${OUT}/attack-${ROUND}/ and run them with ${PY}. ${l.task(ROUND)} Also re-run every reproduction of the push check of a9129c78 that belongs to your lens (${PCF} and the lists in ${PCLENSES}) and report each that still reproduces. ${HELDOUT_RULE} Word-count lines (D7) and the mark-allocation pins stay as they are: never report them. Report in reproduced ONLY what you reproduced on the current working tree, each with the exact input, the branch, the path, what happened, what must happen and the kind (miss, false_positive, fail_open, stall, regression); in checked, what you tried (counts per branch and path) and the measured rates.`, { label: `check:${l.key}:c3f`, phase: 'Check', schema: ATTACK_SCHEMA, effort: 'high' })))).filter(Boolean)
const HELDOUT_RE = /held[- ]?out|heldout|(positive|negative)\.jsonl/i
const openAll = chkRes.flatMap(a => (a.reproduced || []).map(x => Object.assign({ lens: a.lens || '' }, x)))
const open = openAll.filter(x => !HELDOUT_RE.test(`${x.input || ''} ${x.path || ''} ${x.happened || ''}`))
const heldoutDropped = openAll.length - open.length
log(`check round ${ROUND}: ${open.length} reproduced (${chkRes.map(a => `${a.lens || '?'} ${(a.reproduced || []).length}`).join(', ')})${heldoutDropped ? `; ${heldoutDropped} naming a held-out file kept from the fixer` : ''}`)
const fixLeft = [].concat(...fixRes.filter(Boolean).map(r => r.left_undone || []))
let fChk = null
if (open.length || fixLeft.length) {
  const openJson = JSON.stringify(open)
  if (openJson.length > 150000) log(`check fixer sees the first 150000 of ${openJson.length} characters of the reproduced list`)
  const leftJson = JSON.stringify(fixLeft.map(x => clip(typeof x === 'string' ? x : JSON.stringify(x), 3000)))
  log(`check fixer gets ${open.length} reproduced items and ${fixLeft.length} fixer leftovers (${leftJson.length} characters)`)
  fChk = await agent(`${DCTX}
${SELFCERT_CLASS}
You are the CHECK FIXER of this run. You may edit any path; the design files are ${C3B}/selfcert-design.md and ${C3B}/d9d10-design.md. The check lenses reproduced these on the working tree: ${openJson.slice(0, 150000)}${heldoutDropped ? `\n(${heldoutDropped} further items named a held-out file and are kept from you under the held-out rule; their categories are in the lenses' checked text, which you do not get.)` : ''}
The four fixers of this run left these items (their left_undone, each clipped at 3000 characters; their progress files are ${OUT}/progress-c3f-*.md): ${leftJson}
Priorities: (1) every regression (above all a wrong result shown as checked or a correct one charged), fail_open and stall, every false positive (correct work gated), and every item of the push check of a9129c78 that still reproduces; (2) the fixers' leftovers that need no owner decision (leave the items a fixer marked as the owner's decision, pre-existing by design, or a meaning reading); (3) the branch misses; (4) misses of the self-certification class, by class only and only if no false positive is added (re-run the development sets and the recorded genuine answers). Fix each at its cause; add a regression test for each with its expected value fixed in the test. NEVER read ${C3B}/heldout/. Never weaken or delete a test (rewriting one to a stricter rule is allowed; say so). ${TIMING} Validate with the targeted test directories and the development sets; do not run the full suite. Return every change in fixed and anything not done in left_undone with the reason.${RESTARTS('c3f-check')}`, { label: 'fix:c3f:check', phase: 'Check', schema: FIX_SCHEMA, effort: 'high' })
}

// ------------------------------------------------------------------ Verify and commit
phase('Verify')
const allFixed = [].concat(fixed, (fChk && fChk.fixed) || [])
const leftAll = [].concat(fixLeft, (fChk && fChk.left_undone) || [])
const body = `__COMMIT_BODY__
Check round after the fixes: ${open.length} reproduced.
Changes:
${clipFixed(allFixed, 7000)}`
const vc = await verifyAndCommit([C3], 'Fix the c3 clearance findings', body, 'clearance-c3f', 'Verify')
const sha = vc.commit && vc.commit.committed ? vc.commit.sha : null

return {
  fixed: allFixed.length,
  fixed_by: FIXERS.map((f, i) => `${f.key}: ${fixRes[i] ? (fixRes[i].fixed || []).length : 'no result'}`),
  left_undone: leftAll.map(x => clip(x, 300)),
  check_open: open.map(o => clip(`${o.lens}: ${o.kind || ''} ${o.branch || ''} ${o.input}`, 240)),
  heldout_kept_from_fixer: heldoutDropped,
  verified: vc.green,
  harness: vc.v ? vc.v.harness_line : null,
  suite: vc.v ? suiteLine(vc.v.suite_tail) : null,
  commit: sha,
  pushed: !!(vc.commit && vc.commit.pushed),
}
"""
assert '`' not in COMMIT_BODY and '${' not in COMMIT_BODY
BODY = BODY.replace('__FIXERS__', fixers_js).replace('__FIX_RULES__', FIX_RULES).replace('__COMMIT_BODY__', COMMIT_BODY.strip())
assert '__' + 'FIXERS__' not in BODY and '__FIX_RULES__' not in BODY and '__COMMIT_BODY__' not in BODY
out = META + '\n// Constants, schemas, the class/boundary definitions, the verification and commit helpers and the lenses: copied from wf-scripts/fix-c3e.js by make_fix_c3f.py (with the asserted replacements listed there).\n' + '\n'.join(block.split('\n')[1:]) + '\n' + BODY
for bad in ('C3D_LEFT', "'c3e-' + f.key", 'fix:c3e:'):
    assert bad not in out, bad
open(OUT_JS, 'w', encoding='utf-8').write(out)
print('wrote', OUT_JS, len(out), 'chars')
