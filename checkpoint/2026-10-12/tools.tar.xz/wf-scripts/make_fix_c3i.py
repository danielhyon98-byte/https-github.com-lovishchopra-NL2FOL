#!/usr/bin/env python3
"""Build wf-scripts/fix-c3i.js: the seventh follow-up (NARROW, Geography table readings only), after the push check of
84aff95c (24 Nov).

Usage: python3 -I make_fix_c3i.py wf-scripts/fix-c3h.js wf-scripts/fix-c3i.js

Derived from the generated fix-c3h.js by asserted replacements only: the meta block, OUT (c3i), the push-check record
constants (PCF = the 84aff95c record, PCF_PREV = the 67bc64ec record, PCLENSES), the THIS RUN paragraphs of DCTX, the
FIXERS array (one owner, from c3i_fixers.py), the rules sentence of the fixers, the check lenses (a Geography grid lens and
the readings diff), the check fixer's priorities, the KIT task (no bump: checks only), every c3h label and restart file
(c3i), the attack round (15), the names of the previous record in the prompts, and the commit body. Everything else
(schemas, the class and boundary definitions, the verification helpers, the held-out rule, the timing rule) is carried
over verbatim.
"""
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from c3i_fixers import FIXERS, DCTX_RUN, COMMIT_BODY, KIT_TASK, FIXER_RULES, CHECK_PRIORITIES, GEO_LENS  # noqa: E402

SRC, OUT_JS = sys.argv[1], sys.argv[2]
s = open(SRC, encoding='utf-8').read()


def rep(text, old, new, count=1):
    n = text.count(old)
    assert n == count, (old[:100], n)
    return text.replace(old, new)


for name, t in [('DCTX_RUN', DCTX_RUN), ('COMMIT_BODY', COMMIT_BODY), ('KIT_TASK', KIT_TASK), ('FIXER_RULES', FIXER_RULES),
                ('CHECK_PRIORITIES', CHECK_PRIORITIES), ('GEO_LENS', GEO_LENS)] + [('fixer ' + k, t) for k, t in FIXERS]:
    assert '`' not in t, ('backtick in', name)
allowed = {'PCF', 'PCLENSES', 'C3B', 'CLR', 'C3', 'PY', 'REPO', 'OUT', 'TIMING', 'r'}
for name, t in [('DCTX_RUN', DCTX_RUN), ('KIT_TASK', KIT_TASK), ('FIXER_RULES', FIXER_RULES), ('CHECK_PRIORITIES', CHECK_PRIORITIES),
                ('GEO_LENS', GEO_LENS)] + [('fixer ' + k, t) for k, t in FIXERS]:
    used = set(re.findall(r'\$\{([^}]*)\}', t))
    assert used <= allowed, (name, used - allowed)
assert '${' not in COMMIT_BODY

# meta
m = re.match(r"export const meta = \{.*?\n\}\n", s, re.S)
assert m, 'meta not found'
META = """export const meta = {
  name: 'translator-fix-c3i',
  description: "Seventh follow-up (narrow, Geography table readings only) after the push check held 84aff95c: a nested comparison inside an insertion shown as ENTAILED, the lost charge after a total-row noun, the label-colon form and the ge-t14 nested comparison; one check round with a Geography grid and a readings diff; kit checks without a version bump; verify and commit",
  phases: [
    { title: 'Fix', detail: 'one owner: the subject branches (Geography table readings); the figure is read against the row its own clause names, or gets no check' },
    { title: 'Check', detail: 'one round (15): a fresh Geography grid and a readings diff against HEAD, held-out lines never read; one fixer for what they reproduce' },
    { title: 'Version', detail: 'one KIT step after every fixer: no version bump (no eligibility rule changes); the kit checks with the repository tools' },
    { title: 'Verify', detail: 'full suite in shards, then the harness on every round, hygiene, up to three repairs, commit' },
  ],
}
"""
s = META + s[m.end():]

s = rep(s, "const OUT = `${WF2}/c3h`", "const OUT = `${WF2}/c3i`")
s = rep(s,
        "const PCF = `${S}/push-check/67bc64ec336f87c641a83fd51eff8c8d521212f7.json`\n"
        "const PCF_PREV = `${S}/push-check/08c4a36b9d68885aac6bb81840d127c65a0ed409.json`\n"
        "const PCLENSES = `${WF2}/c3h/pushcheck-67bc64e-lenses.json`",
        "const PCF = `${S}/push-check/84aff95c1297c8826374801c159355b2de7c55ba.json`\n"
        "const PCF_PREV = `${S}/push-check/67bc64ec336f87c641a83fd51eff8c8d521212f7.json`\n"
        "const PCLENSES = `${WF2}/c3i/pushcheck-84aff95-lenses.json`")
# THIS RUN paragraphs: from 'THIS RUN (follow-up 6, 24 Nov; NARROW).' to the line before 'The working tree of'
i = s.index('THIS RUN (follow-up 6, 24 Nov; NARROW).')
j = s.index('\nThe working tree of ${REPO} (branch ${BRANCH}) is shared', i)
s = s[:i] + DCTX_RUN.strip('\n') + s[j:]
# FIXERS array
i = s.index('const FIXERS = [\n')
j = s.index('\n]\nconst fixRes = await parallel(FIXERS.map', i)
s = s[:i] + 'const FIXERS = [\n' + ',\n'.join("  { key: '%s', task: `%s` }" % (k, t.strip('\n')) for k, t in FIXERS) + s[j:]
# the fixers' rules sentence
i = s.index('Rules for every fixer: fix each item at its cause, FAILING CLOSED')
j = s.index("${RESTARTS('c3h-' + f.key)}", i)
s = s[:i] + FIXER_RULES.strip() + s[j:]
# labels, restart files, round, previous record names
s = rep(s, "RESTARTS('c3h-' + f.key)", "RESTARTS('c3i-' + f.key)")
s = rep(s, "label: `fix:c3h:${f.key}`", "label: `fix:c3i:${f.key}`")
s = rep(s, "label: `check:${l.key}:c3h`", "label: `check:${l.key}:c3i`")
s = rep(s, "label: 'fix:c3h:check'", "label: 'fix:c3i:check'")
s = rep(s, "RESTARTS('c3h-check')", "RESTARTS('c3i-check')")
s = rep(s, "${OUT}/progress-c3h-*.md", "${OUT}/progress-c3i-*.md")
s = rep(s, "'clearance-c3h'", "'clearance-c3i'")
s = rep(s, "label: 'fix:c3h:kit'", "label: 'fix:c3i:kit'")
s = rep(s, "RESTARTS('c3h-kit')", "RESTARTS('c3i-kit')")
s = rep(s, "const ROUND = 14 // continues the attack numbering", "const ROUND = 15 // continues the attack numbering")
s = rep(s, "Also re-run every reproduction of the push check of 67bc64ec that belongs to your lens",
        "Also re-run every reproduction of the push check of 84aff95c that belongs to your lens")
# the check lenses: a fresh Geography grid and the readings diff
s = rep(s, "const LENSES = ATK.filter(l => l.key === 'phrasings').concat([",
        "const LENSES = [{ key: 'geo-grid', task: r => `" + GEO_LENS + "` }].concat([")
# the check fixer: one fixer; Geography priorities
s = rep(s, "The two fixers of this run left these items", "The fixer of this run left these items")
i = s.index("Priorities: (1) every regression this run's changes introduced")
j = s.index("${RESTARTS('c3i-check')}", i)
s = s[:i] + CHECK_PRIORITIES.strip() + s[j:]
# the KIT step: checks only, no bump
i = s.index('You are the KIT step of this run')
j = s.index("\n${TIMING}${RESTARTS('c3i-kit')}", i)
s = s[:i] + KIT_TASK.strip() + s[j:]
# commit body: replace the fixed text between 'const body = `' and '\nCheck round after the fixes'
i = s.index('const body = `')
j = s.index('\nCheck round after the fixes: ${open.length} reproduced.', i)
s = s[:i] + 'const body = `' + COMMIT_BODY.strip() + s[j:]
s = rep(s, "// ================================================================== fix-c3h (written 24 Nov after the push check of 67bc64ec; narrow, fail closed)",
        "// ================================================================== fix-c3i (written 24 Nov after the push check of 84aff95c; narrow, Geography only)")
for bad in ('fix:c3h:', "'c3h-", 'clearance-c3h', 'progress-c3h', 'ROUND = 14', 'follow-up 6, 24 Nov', 'push check of 67bc64ec that',
            "l.key === 'phrasings'", 'The two fixers', '2026.11-v7', "'2026.11-v8' ->", 'selfcert-3 ->'):
    assert bad not in s, bad
open(OUT_JS, 'w', encoding='utf-8').write(s)
print('wrote', OUT_JS, len(s), 'chars')
