"""Build the phase-2 continuation (from the integration step) out of phase2-pipeline.js, so every prompt it keeps is the
pipeline's own. Usage: python3 -I make_phase2_cont.py <phase2-pipeline.js> <out.js>"""
import sys
src, out = sys.argv[1], sys.argv[2]
L = open(src).read().split('\n')
def rng(a, b):  # 1-indexed inclusive
    return L[a - 1:b]
def find(prefix, start=1):
    for i in range(start - 1, len(L)):
        if L[i].startswith(prefix):
            return i + 1
    raise SystemExit('not found: ' + prefix)
# boundaries checked against the file, not assumed
assert L[16].startswith("const REPO = "), L[16][:40]
merge_hdr = find('// ================================================================== Merge')
assert L[merge_hdr].startswith('const INT_IMPL'), L[merge_hdr][:40]
web = find("const WEBSITE_REPO = ")
preb = find("const PREB = ")
undone = find("const undoneOf = ")
rebuild_subject = find("const REBUILD_SUBJECT = ")
merges_def = find("const MERGES = [")
merges_list = find("const merges = []")
integ_hdr = find('// ================================================================== Integration gate')
opt_hdr = find('// ================================================================== Optimisation check')
clr_hdr = find('// ================================================================== Clearance (arena rounds 8-10)')
scal_hdr = find('// ================================================================== Scaling')
body = []
head = '\n'.join(rng(17, merge_hdr - 1))
_b = "fix: STR }, required: ['severity', 'file', 'summary', 'expected', 'actual', 'fix'] }"
assert head.count(_b) == 1
head = head.replace(_b, "fix: STR, critical: { type: 'boolean' } }, required: ['severity', 'file', 'summary', 'expected', 'actual', 'fix'] }")
body += head.split('\n')
body += rng(merge_hdr, web)
body += rng(preb, undone)
body += [L[rebuild_subject - 1]]
body += rng(merges_def, merges_list - 1)
body += ['''// ================================================================== Continuation (30 Oct)
// Every merge is committed on the development branch: the STEM and overseer builds (3adfd73), the round-7 handoff fixes (69ab213),
// the delivery rule (404aee2) and the argument diagnostics, ported onto the integrated translator (the merge of argdiag-final
// conflicted in 48 files; the owner chose a port in which the integrated behaviour wins every contradiction). This continuation
// starts at the integration step; its prompts are the pipeline's own.
const merges = (args && args.merges) || []
if (args && args.lastHarness) lastHarness = args.lastHarness
log('continuation from the integration step; argument diagnostics on the development branch at ' + String((args && args.argdiagSha) || '?').slice(0, 7) + '; last verified harness: ' + (lastHarness || 'read from git log'))''']
integ = rng(integ_hdr, opt_hdr - 1)
text = '\n'.join(integ)
def rep(t, old, new, count=1):
    n = t.count(old)
    assert n == count, (old[:80], n)
    return t.replace(old, new)
# Critical (Daniel 17 Oct ~14:10; KNOWLEDGE/02-PRIORITIES): the gate loop ends as soon as no critical issue is left.
text = rep(text, ".serious || 0) > 0", ".critical || 0) > 0", 2)
text = rep(text, "  const serious = bugs.filter(b => b.severity !== 'minor')\n",
           "  const serious = bugs.filter(b => b.severity !== 'minor')\n  const critical = bugs.filter(b => b.critical === true)\n")
text = rep(text, "gate = { round: g, missing, serious: serious.length, minor: bugs.length - serious.length, lenses: reports.map((r, i) => r ? { lens: ILENSES[i].key, passed: r.passed, bugs: (r.bugs || []).length, serious: (r.bugs || []).filter(b => b.severity !== 'minor').length } : { lens: ILENSES[i].key, missing: true }) }",
           "gate = { round: g, missing, critical: critical.length, serious: serious.length, minor: bugs.length - serious.length, lenses: reports.map((r, i) => r ? { lens: ILENSES[i].key, passed: r.passed, bugs: (r.bugs || []).length, serious: (r.bugs || []).filter(b => b.severity !== 'minor').length, critical: (r.bugs || []).filter(b => b.critical === true).length } : { lens: ILENSES[i].key, missing: true }) }")
text = rep(text, "log(`integration gate g${g}: ${serious.length} blocker/major, ${bugs.length - serious.length} minor${missing.length ? '; lenses missing: ' + missing.join(', ') : ''}`)\n  if (!serious.length && !missing.length) break\n",
           "log(`integration gate g${g}: ${critical.length} critical, ${serious.length} blocker/major, ${bugs.length - serious.length} minor${missing.length ? '; lenses missing: ' + missing.join(', ') : ''}`)\n")
# fix every finding of the round first, then stop when nothing critical is left
idx = text.index("    await verifyAndCommit([], `Integration: fix the integration-gate findings (round ${g})`")
end = text.index('\n  }\n', idx) + len('\n  }\n')
text = text[:end] + "  if (!critical.length && !missing.length) break\n" + text[end:]
text = rep(text, "if (gate && (gate.serious || gate.missing.length)) {\n  log('integration gate NOT clean after five rounds: round 8 does not start; the founder decides')",
           "if (gate && (gate.critical || gate.missing.length)) {\n  log('integration gate: a critical issue is still open after five rounds: round 8 does not start; the founder decides')")
text = rep(text, "log('integration gate clean: every component works as one system; round 8 starts')",
           "log('integration gate: no critical issue left' + (gate && gate.serious ? ' (' + gate.serious + ' blocker/major of the last round recorded as known defects)' : '') + '; the pre-round-8 push, then round 8')")
# the lens prompt asks for the critical mark (the helper workflows are generated from this script, so they ask the same)
text = rep(text, "passed=true only with no blocker and no major. A performance finding that changes no outcome is not a bug here: put it in measured with its numbers.\nBEFORE RETURNING",
           "passed=true only with no blocker and no major. A performance finding that changes no outcome is not a bug here: put it in measured with its numbers.\nMark a bug critical=true ONLY when it is critical to the infrastructure: (a) a security weakness (input that stalls or crashes the service, forged signatures, flags, diagnostics or verdicts accepted, a supplied text that instructs the system, secrets exposed); (b) a safety-boundary violation of the repository CLAUDE.md (a check weakened or silenced, a status upgraded, a non-success shown as success, model output evaluated, the IR allowlist widened, the signed binding inconsistent, a test weakened, skipped or deleted); (c) the infrastructure broken (the suite failing, a crash, a recorded arena round losing functional count, the service or CLI failing to start, an incompatible contract or schema change, the pack export failing). Detection quality (a miss, a false alarm, a wrong name, a corpus bar, an overseer threshold) is never critical; mark it critical=false whatever its severity.\nBEFORE RETURNING")
body += text.split('\n')
body += ['''// Daniel (17 Oct ~14:10): "once every task prior to round 8 testing is complete push updates to main repo regardless of bugs unless
// critical to infrastructure then continue with round 8 testing". Through the private publishers only (simulation first).
phase('Push')
const PUSH_STEPS = (what) => `Push ${what} to Bruno's repository now, through the private publisher only. Steps: (1) Run bash ${S}/presim.sh as ONE background command with the longest timeout (7200000 ms), its output written to a log file: it simulates the newest final development commit on exactly its code (40 to 60 minutes) and caches the result as ${S}/simcache/translator-<full sha>.txt (if another presim run holds its lock it exits at once; that run caches the same file). Ending your turn kills it, so NEVER end your turn while it runs: block with foreground loops such as until [ -s <the cache file> ]; do sleep 30; done (at most 9 minutes per call), repeated for up to 90 minutes. (2) If the file records SIMULATION OK, run bash ${S}/event_push.sh (it pushes through publish_final.sh with the same gates, bans and backup branch as the hourly push, and does nothing between hh:56 and hh:03, when the hourly push uploads it instead; in that case wait until hh:04 and run it again). (3) Confirm with git -C ${REPO} fetch -q epinoic verified-updates && git -C ${REPO} log -1 --format=%B FETCH_HEAD that the Source-Commit line names that commit. Never push any other way, never force; a refused push is reported, not retried another way. Return what was pushed (or why not) and the simulation line.`
const prePush = await agent(PUSH_STEPS(`the integrated translator (the newest final commit on ${BRANCH}: git -C ${REPO} log --format='%H %s' -15 ${BRANCH}; the newest commit whose subject starts with "Integration: ", "Argument diagnostics: " or "Delivery: ")`), { label: 'push:pre-r8', phase: 'Push', effort: 'low' })
log('pre-round-8 push: ' + String(prePush || 'no result').slice(0, 400))''']
body += rng(opt_hdr, clr_hdr - 1)
clr = '\n'.join(rng(clr_hdr, scal_hdr - 1))
# the round push uses the same steps (presim runs 40 to 60 minutes: a background command the agent waits for)
start = clr.index("      const pushed = await agent(`Push arena round ${8 + k - 1}'s verified fix commit")
stop = clr.index("{ label: `push:${round}`, phase: 'Clearance', effort: 'low' })", start)
clr = clr[:start] + "      const pushed = await agent(PUSH_STEPS(`arena round ${8 + k - 1}'s verified fix commit ${vc.commit.sha} (founder: immediately after each round's verified fixes)`), " + clr[stop:]
body += clr.split('\n')
body += ['return { merges, integration: gate, clearance, prePush: String(prePush || "").slice(0, 600) }']
meta = '''export const meta = {
  name: 'translator-phase2-cont',
  description: 'Phase 2 from the integration step: the overseer reads every code, the integration gate until no critical issue is left, the pre-round-8 push, arena round 8 with its fixes, push and prototype docs; then it stops for the handoff protocol',
  phases: [
    { title: 'Integrate', detail: 'the overseer reads every translator code and diagnostic; the integration gate (14 lenses in helper workflows; later rounds re-run only lenses with a critical finding) until no critical issue is left' },
    { title: 'Push', detail: 'the integrated translator to the main repository (simulation first), regardless of non-critical bugs' },
    { title: 'Optimize', detail: 'not run (Daniel, 17 Oct: no optimisation)' },
    { title: 'Clearance', detail: 'arena round 8 (c1) over all sixteen v4 specialists: Haiku specialists, translators, combinator and overseer agents; five overseer lenses; fixes; verified commit; push check and push; README; prototype docs; then stop' },
  ],
}
'''
open(out, 'w').write(meta + '\n'.join(body) + '\n')
print('wrote', out, len(body), 'lines')
