export const meta = {
  name: 'argdiag-accuracy-fix',
  description: 'Argument diagnostics: fix the remaining issues that hurt response accuracy (false alarms on correct answers that the committed code does not raise, and three common STEM misses), with bounded independent verification (nothing is committed)',
  phases: [
    { title: 'Fix', detail: 'one fixer: every listed false alarm made clean again on correct work, the three STEM misses named with clean controls' },
    { title: 'Verify', detail: 'items lens (each item, its twins and new variants on three trees) and global lens (corpora, arena, suite, timing, invariants)' },
  ],
}
