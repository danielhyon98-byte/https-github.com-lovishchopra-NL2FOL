export const meta = {
  name: 'stabilize-c3e',
  description: 'Speed up the slow paths that make the fix-c3e verification fail on wall-clock bounds (no bound relaxed, no reading changed), check under two-process load, then hand back to fix-c3e',
  phases: [
    { title: 'Stabilize', detail: 'snapshot the tree, profile the timing failures, speed up their hot paths with no change in any reading' },
    { title: 'Check', detail: 'independent re-measurement under two-process load and a readings diff on every recorded round' },
    { title: 'Fix', detail: 'only if the check finds a problem: one more stabilizer pass and one more check' },
  ],
}
const S = '/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad'
const REPO = '/home/user/https-github.com-lovishchopra-NL2FOL'
const PY = `${S}/z3venv/bin/python -I`
const OUT = `${S}/wf/phase2/c3e/stab`
const CLR = `${S}/clearance`
const ARENA = `${S}/arena`
const STR = { type: 'string' }
const STRS = { type: 'array', items: STR }
const STAB_SCHEMA = { type: 'object', properties: { changed: STRS, measurements: STRS, left: STRS, summary: STR }, required: ['changed', 'measurements', 'summary'] }
const CHECK_SCHEMA = { type: 'object', properties: { ok: { type: 'boolean' }, timing: STRS, readings_diff: STRS, tests: STRS, problems: STRS }, required: ['ok', 'timing', 'readings_diff', 'problems'] }
const RESTARTS = label => ` RESTARTS: the container can restart without warning, which stops you; a later run of this same task then starts afresh on the same working tree. So FIRST read ${OUT}/progress-${label}.md if it exists and continue from it (never start over, never revert earlier work); keep it current after each step.`

const CTX = `CONTEXT. ${REPO} (package epinoic_logic; overseer, flash-router and combinator sub-projects) holds the UNCOMMITTED work of the fix run "fix-c3e" (a follow-up fix round), which is paused while you work; it resumes afterwards and runs the full suite in two shards at once and the arena harness, then commits. Its verifications failed only on wall-clock bounds, all measured with two pytest processes running at once on this 4-CPU machine. Its second repair (22 Nov 20:00) already made three exact speedups in src/epinoic_logic/selfcert/encoded.py and reader.py (_alone() for _ALONE_RE, a separator pre-check before _KEY_RE, cheaper _line_transforms, the tick-pair check once per clause; each shown identical to the code it replaced; new tests/selfcert/test_c3e_repair_linear.py). What remains at risk, by the repair's own measurements:
(1) tests/adapters_history/test_integration_gate2_chronology.py::test_the_history_parser_reads_every_hostile_input_in_linear_time: 97 to 99 s ALONE against the 120 s pytest-timeout (it hit the timeout under two-process load before the repair); the remaining cost is spread over the self-certification per-sentence reading (_read_text_folded, _net_found, the normalise passes), reached from the History parser's is_note_sentence -> adapters/self_report.self_report_note -> selfcert.is_self_certification;
(2) tests/stem/test_integration_gate2_handoff.py::test_a_physics_answer_of_soft_wrapped_lines_crosses_the_audited_hub_in_seconds: now 16.0 to 16.7 s alone (HEAD 16.1 to 16.3 s) against 20 s; it reached 21.3 s under load before the repair;
(3) tests/engine/test_stem_shapes.py::test_median_time_per_shape_is_below_50_ms: rearrangement_root_pass median 51.4 ms against 50 ms under load (judged load-induced, unchanged);
(4) tests/integration/test_c2_hold_remedy2_round3_turn_check.py::test_the_real_port_refuses_a_round3_self_report[No errors found.-hi-s1]: the first clearance after the real overseer port connects takes 275 to 460 ms of wall time against its 250 ms pending wait (HEAD and tree alike), so a cold first turn ends as refuse_incomplete (KIT-DL-004) instead of refuse_integrity (KIT-DL-006); fail-closed but order-dependent (unchanged);
(5) tests/selfcert/test_linear.py::test_a_hostile_input_is_read_in_linear_time[repeated not]: ratio 6.3 against 6 under load in an earlier run (8 KiB 0.054 s, 32 KiB 0.34 s; about 4 alone);
(6) tests/adapters/test_verification_labels.py::test_a_long_run_of_check_marks_is_read_in_linear_time: fixed by the repair (1.23 to 1.34 s against 2.0 s); re-measure only.
Two of these were left as "load-induced", so the next verification could fail the same way. RULES (the repository's CLAUDE.md holds): NEVER relax, skip, xfail, deselect, re-time or delete a test, a bound, a timeout or a window, and never change what the code reads or decides (statuses, findings, receipt codes, delivery decisions, self-certification readings); make the code FASTER at the cause (profile first; cache pure functions, add cheap pre-filters before expensive scans, precompile patterns once, stop repeating work, make the cold path warm at construction without changing outcomes). The ORDER rule allows this: these are failing tests, not optimisation for its own sake. Never run the full suite or any stress test; never commit, stage, stash or reset; never touch HEAD. Python: ${PY}; run pytest from ${REPO} with -p no:cacheprovider. A background command longer than 30 minutes needs timeout 7200000.`

phase('Stabilize')
const st = await agent(`${CTX}
You are the STABILIZER. FIRST (only if ${OUT}/before-src does not exist yet): mkdir -p ${OUT}; copy the current working-tree sources to ${OUT}/before-src (cp -a ${REPO}/src ${OUT}/before-src/src and the same for overseer/src, flash-router/src, combinator/src) and save git -C ${REPO} diff > ${OUT}/before.patch, so the checker can compare readings before and after your changes. THEN: measure each of (1) to (6) alone and while a second pytest process runs another large test directory (for example tests/branches) at the same time (two processes, like the shards); profile each slow one (cProfile or the test's own timing) and find where the time goes; make it faster at the cause, preferring one fix that helps every path that reads text through the self-certification reader (the reader runs on every sentence of every answer). Targets, ALONE on this machine: (1) at most 85 s, (2) receive_s at most 15 s, (3) every shape median at most 35 ms, (4) the first clearance after the port connects well inside its 250 ms wait (for example warm the port's readers when it is constructed or connects, never by changing the wait) so the decision is the same cold or warm, (5) ratio at most 4.5, (6) unchanged; and each of (1) to (6) passes 3 runs in a row under the two-process load. Then sweep the other wall-clock tests (grep the test tree for linear_time, in_seconds, median_time, PARSE_BOUND, measure( and growth() and pytest.mark.timeout): list each with under 25% headroom alone and speed up those whose time goes through code this run changed or through the self-certification reader. After each change run the test directories it touches (tests/selfcert, tests/adapters, tests/adapters_history, tests/stem, tests/engine, tests/integration, tests/channel and the overseer tests that read self-reports) and make sure they pass. Report every change with file and function, and every measurement before and after (alone and under load).${RESTARTS('stabilizer')}`, { label: 'stabilize', phase: 'Stabilize', schema: STAB_SCHEMA, effort: 'high' })

const checkPrompt = (round) => `${CTX}
You are the independent CHECKER (round ${round}). The stabilizer reported: ${JSON.stringify(st || {}).slice(0, 12000)}
READ-ONLY on ${REPO} (write only under ${OUT}/check-${round}/). (a) TIMING: run each of (1) to (6) three times while a second pytest process runs tests/branches at the same time, and once alone; give every measurement against its bound; any failure, or under 15% headroom under load, is a problem. (b) READINGS: the code before the stabilizer is in ${OUT}/before-src (its src trees) and after is ${REPO}; for every recorded round (${CLR}/c1, ${CLR}/c2, ${CLR}/c3 and ${ARENA}/r1 to r7), copy the round twice under ${OUT}/check-${round}/ and run ${PY} ${REPO}/scripts/arena/run_arena.py on one copy with the before trees first on PYTHONPATH (use the before tree's scripts/arena if it differs; the scripts are unchanged by the stabilizer unless it says so) and on the other copy with the after trees; compare every claim's status, findings, receipt codes and delivery decision, and every functional count: any difference is a problem (timings and run ids aside). Also run the self-certification development sets (tests/selfcert/data) through selfcert.read on both trees: any reading that differs is a problem. Never read any held-out set. (c) TESTS: run the test directories the stabilizer touched and report the pass/fail lines. ok=true only if there is no problem. Return the measurements, the diff summary, the test lines and the problems.`
phase('Check')
let ck = await agent(checkPrompt(1), { label: 'check:1', phase: 'Check', schema: CHECK_SCHEMA, effort: 'high' })

let st2 = null
if (!ck || !ck.ok) {
  phase('Fix')
  st2 = await agent(`${CTX}
You are the STABILIZER, second pass. The independent check found these problems: ${JSON.stringify((ck && ck.problems) || ['the check did not complete']).slice(0, 20000)}
Fix each at its cause under the same rules (a reading that changed must be restored exactly; a bound that still fails needs a further speedup). Report every change and measurement.${RESTARTS('stabilizer-2')}`, { label: 'stabilize:2', phase: 'Fix', schema: STAB_SCHEMA, effort: 'high' })
  ck = await agent(checkPrompt(2), { label: 'check:2', phase: 'Fix', schema: CHECK_SCHEMA, effort: 'high' })
}

return { stabilizer: st, stabilizer2: st2, check_ok: !!(ck && ck.ok), check: ck }
