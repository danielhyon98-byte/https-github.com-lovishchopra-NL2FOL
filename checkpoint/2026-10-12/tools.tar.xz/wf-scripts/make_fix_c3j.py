#!/usr/bin/env python3
"""Build wf-scripts/fix-c3j.js: the meaning check, stage 1 (the label package and its frozen prompt; not wired), 25 Nov.

Usage: python3 -I make_fix_c3j.py wf-scripts/fix-c3i.js wf-scripts/fix-c3j.js

Derived from the generated fix-c3i.js by asserted replacements only: the meta block, OUT (c3j), the THIS RUN paragraphs
of DCTX, the FIXERS array (owners R2 and R3, from c3j_fixers.py), the rules sentence of the owners, the check lenses (an
adversarial lens and a design-conformance lens), the check-lens sentence about earlier push checks, the check fixer's
scope and priorities, the KIT task (identity pin, package data, kit checks; no version bump), every c3i label and restart
file (c3j), the attack round (16) and the commit body. Everything else (schemas, the class and boundary definitions, the
verification helpers, the held-out rule, the timing rule) is carried over verbatim.
"""
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from c3j_fixers import (FIXERS, DCTX_RUN, COMMIT_BODY, KIT_TASK, FIXER_RULES, CHECK_PRIORITIES, LABEL_ATTACK,  # noqa: E402
                        DESIGN_LENS)

SRC, OUT_JS = sys.argv[1], sys.argv[2]
s = open(SRC, encoding='utf-8').read()


def rep(text, old, new, count=1):
    n = text.count(old)
    assert n == count, (old[:100], n)
    return text.replace(old, new)


texts = [('DCTX_RUN', DCTX_RUN), ('KIT_TASK', KIT_TASK), ('FIXER_RULES', FIXER_RULES), ('CHECK_PRIORITIES', CHECK_PRIORITIES),
         ('LABEL_ATTACK', LABEL_ATTACK), ('DESIGN_LENS', DESIGN_LENS), ('COMMIT_BODY', COMMIT_BODY)] + [('owner ' + k, t) for k, t in FIXERS]
allowed = {'S', 'C3B', 'PY', 'REPO', 'OUT', 'TIMING', 'r', 'CLR', 'C3'}
for name, t in texts:
    assert '`' not in t, ('backtick in', name)
    used = set(re.findall(r'\$\{([^}]*)\}', t))
    assert used <= allowed, (name, used - allowed)
assert '${' not in COMMIT_BODY

m = re.match(r"export const meta = \{.*?\n\}\n", s, re.S)
assert m, 'meta not found'
META = """export const meta = {
  name: 'translator-fix-c3j',
  description: "Meaning check, stage 1, after the owner's yes to the block-only model label: the label package (input, keyed canaries, schema, strict validation with anchoring and exemptions, record, labellers, fakes, digest) and its frozen prompt, not yet wired; one check round; identity pin and kit checks without a version bump; verify and commit",
  phases: [
    { title: 'Fix', detail: 'two owners on disjoint paths: the label package and its tests (R2), the frozen prompt (R3)' },
    { title: 'Check', detail: 'one round (16): an adversarial lens and a design-conformance lens; one fixer for what they reproduce' },
    { title: 'Version', detail: 'one KIT step: the label identity pin, package data, kit checks; no version bump (nothing wired)' },
    { title: 'Verify', detail: 'full suite in shards, then the harness on every round, hygiene, up to three repairs, commit' },
  ],
}
"""
s = META + s[m.end():]

s = rep(s, "const OUT = `${WF2}/c3i`", "const OUT = `${WF2}/c3j`")
i = s.index('THIS RUN (follow-up 7, 24 Nov; NARROW, Geography only).')
j = s.index('\nThe working tree of ${REPO} (branch ${BRANCH}) is shared', i)
s = s[:i] + DCTX_RUN.strip('\n') + s[j:]
i = s.index('const FIXERS = [\n')
j = s.index('\n]\nconst fixRes = await parallel(FIXERS.map', i)
s = s[:i] + 'const FIXERS = [\n' + ',\n'.join("  { key: '%s', task: `%s` }" % (k, t.strip('\n')) for k, t in FIXERS) + s[j:]
i = s.index('Rules for every fixer: fix each item at its cause, as the remedy rule of this run says')
j = s.index("${RESTARTS('c3i-' + f.key)}", i)
s = s[:i] + FIXER_RULES.strip() + s[j:]
s = rep(s, "RESTARTS('c3i-' + f.key)", "RESTARTS('c3j-' + f.key)")
s = rep(s, "label: `fix:c3i:${f.key}`", "label: `fix:c3j:${f.key}`")
s = rep(s, "label: `check:${l.key}:c3i`", "label: `check:${l.key}:c3j`")
s = rep(s, "label: 'fix:c3i:check'", "label: 'fix:c3j:check'")
s = rep(s, "RESTARTS('c3i-check')", "RESTARTS('c3j-check')")
s = rep(s, "${OUT}/progress-c3i-*.md", "${OUT}/progress-c3j-*.md")
s = rep(s, "'clearance-c3i'", "'clearance-c3j'")
s = rep(s, "label: 'fix:c3i:kit'", "label: 'fix:c3j:kit'")
s = rep(s, "RESTARTS('c3i-kit')", "RESTARTS('c3j-kit')")
s = rep(s, "const ROUND = 15 // continues the attack numbering", "const ROUND = 16 // continues the attack numbering")
s = rep(s, "Also re-run every reproduction of the push check of 84aff95c that belongs to your lens (${PCF} and the lists in ${PCLENSES}) and report each that still reproduces.",
        "This stage changes no release path, so the earlier push checks' reproductions are not yours to re-run.")
i = s.index("const LENSES = [{ key: 'geo-grid', task: r => `")
j = s.index('\n', i)
s = s[:i] + "const LENSES = [{ key: 'label-attack', task: r => `" + LABEL_ATTACK + "` }, { key: 'design', task: r => `" + DESIGN_LENS + "` }]" + s[j:]
s = rep(s, "The fixer of this run left these items", "The two owners of this run left these items")
i = s.index('You are the CHECK FIXER of this run. You may edit any path; the design files are ')
j = s.index('\n', i)
old_line = s[i:j]
k = old_line.index('The check lenses reproduced these on the working tree:')
s = s[:i] + ("You are the CHECK FIXER of this run. You may edit only src/epinoic_logic/selfcert_label/** (never its frozen prompt.md) "
             "and tests/selfcert_label/**; the design is the memo named above. ") + old_line[k:] + s[j:]
i = s.index('Priorities: (1) every wrong figure shown as ENTAILED')
j = s.index("${RESTARTS('c3j-check')}", i)
s = s[:i] + CHECK_PRIORITIES.strip() + s[j:]
i = s.index('You are the KIT step of this run')
j = s.index("\n${TIMING}${RESTARTS('c3j-kit')}", i)
s = s[:i] + KIT_TASK.strip() + s[j:]
i = s.index('const body = `')
j = s.index('\nCheck round after the fixes: ${open.length} reproduced.', i)
s = s[:i] + 'const body = `' + COMMIT_BODY.strip() + s[j:]
s = rep(s, "// ================================================================== fix-c3i (written 24 Nov after the push check of 84aff95c; narrow, Geography only)",
        "// ================================================================== fix-c3j (written 25 Nov: meaning check, stage 1, after the owner's yes)")
for bad in ('fix:c3i:', "'c3i-", 'clearance-c3i', 'progress-c3i', 'ROUND = 15', 'follow-up 7, 24 Nov', 'geo-grid',
            'push check of 84aff95c that', 'The fixer of this run'):
    assert bad not in s, bad
open(OUT_JS, 'w', encoding='utf-8').write(s)
print('wrote', OUT_JS, len(s), 'chars')
