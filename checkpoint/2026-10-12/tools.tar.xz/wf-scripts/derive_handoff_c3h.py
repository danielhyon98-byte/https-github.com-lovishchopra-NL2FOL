#!/usr/bin/env python3
"""Derive wf-scripts/handoff-c3h.js from handoff-c3g.js by asserted replacements (24 Nov).

The refresh after the push check of 84aff95c (follow-up 6): PUB is the copy of the documents published on the morning of
24 November (docs/final-z3-handoff 84d17f4e), HDIR refresh-c3h, PREV 67bc64ec, the lens dump of 67bc64ec's push check,
and FACTS naming follow-up 6 as git and the verification show it. The content rules, the review and the greps are
carried over verbatim.

Usage: python3 -I derive_handoff_c3h.py wf-scripts/handoff-c3g.js wf-scripts/handoff-c3h.js
"""
import sys

SRC, OUT = sys.argv[1], sys.argv[2]
s = open(SRC, encoding='utf-8').read()


def rep(old, new, count=1):
    global s
    n = s.count(old)
    assert n == count, (old[:100], n)
    s = s.replace(old, new)


rep("name: 'handoff-refresh-c3g'", "name: 'handoff-refresh-c3h'")
rep("with the c3g commit (args.sha) and its push-check result", "with the c3h commit (args.sha) and its push-check result")
rep("copy the documents published on the evening of 23 Nov, then update every statement about the development line, the c3g commit and its push check",
    "copy the documents published on the morning of 24 Nov, then update every statement about the development line, the c3h commit and its push check")
rep("args.sha must be the full 40-hex sha of the c3g commit", "args.sha must be the full 40-hex sha of the c3h commit")
rep("const PUB = `${S}/handoff/filled-c3f`", "const PUB = `${S}/handoff/filled-c3g`")
rep("const HDIR = `${S}/handoff/refresh-c3g`", "const HDIR = `${S}/handoff/refresh-c3h`")
rep("const PREV = '08c4a36b9d68885aac6bb81840d127c65a0ed409'", "const PREV = '67bc64ec336f87c641a83fd51eff8c8d521212f7'")
rep("const PCLENSES_PREV = `${S}/wf/phase2/c3g/pushcheck-08c4a36-lenses.json`", "const PCLENSES_PREV = `${S}/wf/phase2/c3h/pushcheck-67bc64e-lenses.json`")

i = s.index('The documents published on the evening of 23 November (docs/final-z3-handoff 1040fa843db442392b0fb6556e2643b36dc01ba1)')
j = s.index(" the documents' version statements that describe the code", i)
old = s[i:j]
assert 'follow-up 5' in old and 'selfcert-3' in old and old.rstrip().endswith('accepted);'), old[-200:]
NEW = (
    'The documents published on the morning of 24 November (docs/final-z3-handoff 84d17f4ef8c3a662d7d2006bea07fa2cbc4cf59b) '
    'describe ${PREV} as HELD by its push check (${PCJ_PREV}) and a further follow-up on the items of that check that need no '
    'owner decision as not started. Since then the development branch received ${SHA} ("Fix the c3 clearance findings", '
    'follow-up 6, committed on 24 November: a narrow run that fails closed; read its commit message whole: what it addressed, '
    'the check round\'s count (16 reproduced), and the full-suite and harness numbers of its verification; its first full run '
    'failed two wall-clock timing tests under machine load (12.28 s against a 12.0 s bound, and a growth ratio of 6.29 against '
    '6), the repair changed no code and no bound, and the second run passed), and after it only a tests/README.md progress note. '
    'Its commit message says that correct lines the reverted exemptions had freed may be withheld again: say so where the '
    'documents describe what the follow-up changed. It also bumps the versions for its rule changes: read '
    'src/epinoic_logic/version.py (POLICY_VERSION and its history entry), src/epinoic_logic/selfcert/__init__.py '
    '(SELFCERT_RULES), src/epinoic_logic/integration/protocol.py (INTEGRATION_CONTRACT_VERSION) and integration/COMPATIBILITY.json '
    'at ${SHA} and state the versions exactly as git shows them (expected: policy 2026.11-v8, rules selfcert-4, contract 0.9, the '
    'kit regenerated, and only the new versions accepted);')
s = s[:i] + NEW + s[j:]

rep("('A1 A1', '∎', and now also the mark-scheme legend line '✓ = 1 mark for a correct method in the mark scheme.')",
    "('A1 A1', '∎' and the mark-scheme legend line '✓ = 1 mark for a correct method in the mark scheme.')")
rep("the 08c4a36 paragraph's successor (what ${SHA} addressed,", "the 67bc64e paragraph's successor (what ${SHA} addressed,")
rep("add the two open items from the follow-up's own report named above as the record agrees)",
    "add an open item for a further run only as the push-check record ${PCJ} supports it)")
rep("(this refresh supersedes the documents published on the evening of 23 November as 1040fa843db442392b0fb6556e2643b36dc01ba1)",
    "(this refresh supersedes the documents published on the morning of 24 November as 84d17f4ef8c3a662d7d2006bea07fa2cbc4cf59b)")
rep("label: 'handoff:update:c3g'", "label: 'handoff:update:c3h'")
rep("label: 'handoff:review:c3g'", "label: 'handoff:review:c3h'")

for bad in ('c3g', 'c3f', '1040fa84', 'follow-up 5', 'evening of 23', 'selfcert-3', '2026.11-v7', 'contract 0.8', '08c4a36 paragraph'):
    assert bad not in s.replace('filled-c3g', ''), bad
assert '`' not in NEW
open(OUT, 'w', encoding='utf-8').write(s)
print('wrote', OUT, len(s), 'chars')
