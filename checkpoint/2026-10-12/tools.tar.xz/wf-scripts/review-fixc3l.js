export const meta = {
  name: 'review-fix-c3l',
  description: 'Independent review of the stage 2b tooling commit: weakened or deleted tests, repository hygiene, safety boundaries; refute-first verification of each finding',
  phases: [
    { title: 'Review', detail: 'three lenses on the commit' },
    { title: 'Verify', detail: 'two refute-first verifiers per finding' },
  ],
}

const R = '/home/user/https-github.com-lovishchopra-NL2FOL'
const PYV = '/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/z3venv/bin/python'
const BASE = args && args.base
const HEAD = args && args.head
if (!BASE || !HEAD || !/^[0-9a-f]{40}$/.test(BASE) || !/^[0-9a-f]{40}$/.test(HEAD)) throw new Error('args.base and args.head must be full commit ids')

const COMMON = `Repository: ${R} (branch claude/z3-verification-engine-plan-nk3luq). The commit under review is ${HEAD}, the meaning-check
stage 2b tooling round: request keys free of the label version with serving by key and re-validation (CC 3(2), request format
selfcert-label-request/2), a cap of two label calls per answer (L3), fixes of the stage 2a review findings and open defects, the
recording and measurement tools under scripts/arena/ and overseer/scripts/, and one version bump (LABEL_VERSION selfcert-label-3,
POLICY_VERSION v10, integration contract 0.11, T17 re-pinned with its reason). Labels are recorded, never live. Its parent is
${BASE}. Read the diff with git (git diff ${BASE} ${HEAD} -- <paths>, git show ${HEAD}:<path>, git diff --numstat). Do NOT modify,
create or delete any file in the repository, and do not commit; write scratch files only under your own temporary directory.
You may run read-only commands, git, grep, and individual pytest files or tests with ${PYV} -B (never the whole suite) when you
need to confirm a behaviour. Never read a key file (*.key) or anything under a directory named heldout or ho-sealed. Report only
real defects with evidence; no style remarks.`

const SCHEMA = {
  type: 'object',
  properties: {
    findings: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          severity: { type: 'string', enum: ['blocking', 'major', 'minor'] },
          path: { type: 'string' },
          line: { type: 'integer' },
          title: { type: 'string' },
          evidence: { type: 'string' },
          why: { type: 'string' },
          fix: { type: 'string' },
        },
        required: ['severity', 'path', 'title', 'evidence', 'why', 'fix'],
      },
    },
    checked: { type: 'string' },
  },
  required: ['findings', 'checked'],
}

const LENSES = [
  { key: 'tests', prompt: `${COMMON}

Lens: TESTS NEVER WEAKENED OR DELETED (project rule). List every test file the commit changes or deletes (tests/**,
overseer/tests/**, combinator/tests/**, flash-router/tests/**, scripts/arena/test_*.py, every conftest.py): git diff --numstat
--diff-filter=MD ${BASE} ${HEAD}, and the renames with -M. Read EVERY deleted or modified line in them together with its
replacement. For each, decide: same meaning (renamed, moved, reformatted); a version, digest or request-format pin re-pinned
together with the bump it belongs to, with the same strictness and its reason stated in the test; a 2a rule rewritten to the new
serving rule exactly as the stage 2b plan's item D1.5 says (served only by an equal request key, re-validated under the current
package, both digests reported; refused on a key mismatch; unavailable on a reply that fails current validation), each with its
reason, no check vacuous; stricter; or WEAKENED (a looser bound or tolerance, an assertion removed or made conditional, an expected
value changed to agree with new behaviour that the test was written to forbid, a new skip, xfail, importorskip or deselect, a test
or parametrised case deleted, a fixture that makes a check vacuous, a broader exception accepted, a timeout raised without
cause). Report each weakening as a finding with the old and new lines quoted. In "checked", list every file you inspected and your
per-file verdict.` },
  { key: 'hygiene', prompt: `${COMMON}

Lens: REPOSITORY HYGIENE. In the ADDED lines of the whole diff (git diff ${BASE} ${HEAD}), in every new file and in the commit
message, look for: any model or vendor model name or identifier (for example haiku, sonnet, opus, fable, claude-, gpt-, gemini;
the commit message's two attribution trailer lines are required and are not findings); any session id or session URL outside
those trailers; any scratch or temporary path (/tmp/claude-0, scratchpad, /root/.claude, a workflow run id such as wf_...); any
e-mail address or personal name of the owner; any secret, key or token value (the public recording key named by the plan is
public and allowed); files that should not be committed (temporary directories, caches, __pycache__, .pyc, logs, large binaries,
editor files, copies of round data, measurement rows). Check that generated files agree with their sources: run
integration/tools/manifest.py --check (read its usage first) and say its exit status; check that integration/COMPATIBILITY.json,
the compat module and the pinned digests and versions the tests read are consistent (you may run tests/integration/test_manifest.py
and tests/contract/ with the venv). Report each problem with file and line.` },
  { key: 'safety', prompt: `${COMMON}

Lens: SAFETY BOUNDARIES of the project's CLAUDE.md, checked on the code this commit adds or changes (git diff --stat ${BASE}
${HEAD} lists it; above all src/epinoic_logic/selfcert_label/**, src/epinoic_logic/channel/**, src/epinoic_logic/branches/hub.py,
src/epinoic_logic/integration/**, overseer/src/epinoic_overseer/**, scripts/arena/*.py, integration/sim/*.py, overseer/scripts/*.py):
1. The label's model output is DATA: never eval/exec'd, never compiled, never reaches the IR, the compiler or the engine; only
   validated spans and states are used; a recorded reply is re-validated under the current package before it is served.
2. Non-success is never shown as success: a claim the label names, a withheld answer, an unavailable label, a record served under
   another key, a cap reached (L3: more than two label calls) or a missing/altered record never yields a success status or a success
   word on any release path or display; no status is raised.
3. Fail closed: the production default is the unconfigured labeller (withholds); fakes are refused outside development and sim; a
   reply that fails validation withholds; a request key mismatch is refused, never served.
4. No live provider call or network connection is added anywhere (tools and tests included); recorded labels only. The measurement
   tools print counts and ids, never row text or key bytes.
5. The scope statement (results prove properties of the encoding only) is kept wherever results are reported.
For each property, trace the code paths (file:line) and try to construct an input or configuration that breaks it. Report each
break as a finding with the path you traced.` },
]

const VERDICT = {
  type: 'object',
  properties: {
    real: { type: 'boolean' },
    severity: { type: 'string', enum: ['blocking', 'major', 'minor', 'none'] },
    reason: { type: 'string' },
  },
  required: ['real', 'severity', 'reason'],
}

const verifyOne = (f, i) => parallel([0, 1].map(k => () => agent(`${COMMON}

Try to REFUTE this review finding about commit ${HEAD}. Reproduce it from the code (open the files, run the specific test or a
small probe with the venv if useful). It is real only if the defect exists in ${HEAD} as described and matters under the project's
rules; if it is a legitimate change (for example a version re-pinned together with its bump, with the same strictness and its
reason), a misreading, or already handled elsewhere, it is not real. Default to real=false if you cannot confirm it.
Verifier ${k + 1} of 2.

Finding (${f.lens} lens, ${f.severity}): ${f.title}
Path: ${f.path}${f.line ? ':' + f.line : ''}
Evidence: ${f.evidence}
Why: ${f.why}
Proposed fix: ${f.fix}`, { label: `verify:${f.lens}:${i}:${k + 1}`, phase: 'Verify', schema: VERDICT })))
  .then(vs => {
    const ok = vs.filter(Boolean)
    const yes = ok.filter(v => v.real)
    return { ...f, votes: ok.map(v => ({ real: v.real, severity: v.severity, reason: v.reason })), confirmed: yes.length >= 1 && ok.length - yes.length < 2 }
  })

const perLens = await pipeline(
  LENSES,
  (l) => agent(l.prompt, { label: `review:${l.key}`, phase: 'Review', schema: SCHEMA })
    .then(r => ({ lens: l.key, ...(r || { findings: [], checked: 'no result' }) })),
  (r) => parallel((r.findings || []).map((f, i) => () => verifyOne({ ...f, lens: r.lens }, i)))
    .then(vs => ({ lens: r.lens, checked: r.checked, findings: vs.filter(Boolean) })),
)

const done = perLens.filter(Boolean)
const findings = done.flatMap(r => r.findings)
log(`${findings.length} findings verified; ${findings.filter(f => f.confirmed).length} confirmed`)
return {
  checked: done.map(r => ({ lens: r.lens, checked: r.checked })),
  findings,
  confirmed: findings.filter(f => f.confirmed),
}
