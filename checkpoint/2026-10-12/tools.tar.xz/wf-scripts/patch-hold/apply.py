import json, shutil, sys
S = '/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad'
F = S + '/wf-scripts/phase2-c2c3.js'
src = open(F).read()
assert 'holdRemedyC2' not in src, 'already patched'
shutil.copy(F, F + '.before-hold-remedy')
pc = json.load(open(S + '/dbg/pushcheck-c2-be91e89.json'))
assert pc['sha'] == 'be91e89ca5ad1a6ff42d6e35c20a2b7623855d13' and pc['hold'] is True and len(pc['critical_open']) == 1
crit = pc['critical_open'][0]
fix = crit[crit.index('Fix: ') + 5:] if 'Fix: ' in crit else ''
src_note = 'the push check of be91e89 (round 9): left undone, not a hold'
carry = [
  {"severity": "major", "file": "src/epinoic_logic/stem/** (the STEM probe cases named in the summary)", "summary": pc['suspicious'][2], "source": "the push check of be91e89 (round 9): still reproducing, not a hold"},
  {"severity": "minor", "file": "src/epinoic_logic/engine/** (W110/W111 handling)", "summary": "A W110/W111 COUNTEREXAMPLE is still counted as a refutation in places (round 9 left it undone).", "source": src_note},
  {"severity": "minor", "file": "src/epinoic_logic/branches/** (History branch roles)", "summary": "The History-branch roles of maa-t13 m2.5's stated condition (round 9 left it undone).", "source": src_note},
  {"severity": "minor", "file": "src/epinoic_logic/stem/** (number reading)", "summary": "Plain-space thousands (round 9 left it undone; see the round 9 fixers' notes).", "source": src_note},
  {"severity": "minor", "file": "overseer/src/epinoic_overseer/** (CORE-SRC-002)", "summary": "The CORE-SRC-002 severity (round 9 left it undone; see the round 9 fixers' notes).", "source": src_note},
  {"severity": "major", "file": "scripts/arena/** (run_arena mutations)", "summary": "Mutated claims are never translated by the harness (round 9 left it undone).", "source": src_note},
]
hold = {
  "held_sha": pc['sha'],
  "critical_open": pc['critical_open'],
  "detail": pc['reasons'][0],
  "also": [pc['suspicious'][1], pc['suspicious'][4]],
  "file": "overseer/src/epinoic_overseer/meta_notes.py (self_report_reading) and the delivery policy's fallback candidate; src/epinoic_logic/adapters/markdown.py (is_self_certification); src/epinoic_logic/branches/** (History, Economics); src/epinoic_logic/channel/bus.py (report_bidi_findings)",
  "fix": fix,
  "carry": carry,
}
top = open(S + '/wf-scripts/patch-hold/top.js').read().replace('__HOLD_C2_JSON__', json.dumps(hold, ensure_ascii=True))
anchor = "const clearance = [{ round: 'c1'"
assert src.count(anchor) == 1
src = src.replace(anchor, top + anchor)
old_ret = '  return { lines, undone }\n'
assert src.count(old_ret) == 1
src = src.replace(old_ret, '  return { lines, undone, fixedFull: fixes.flatMap(f => f.fixed || []) }\n')
dline = "  if (!design) { log(`${round}: no valid design; stopping the integrated rounds`); break }\n"
assert src.count(dline) == 1
src = src.replace(dline, dline + "  // 14 Nov: round 9's push-check hold is remedied once here, before round 10's agents run (see HOLD_C2 above).\n  if (k === 3 && HOLD_C2.critical_open.length) await holdRemedyC2()\n")
def second(s, old, new):
    i = s.index(old); j = s.index(old, i + len(old))
    assert s.count(old) == 2
    return s[:j] + new + s[j + len(old):]
old_body = "${fx.lines.join('\\n').slice(0, 6000)}\\nLeft undone: ${fx.undone.join('; ').slice(0, 2000)}"
src = second(src, old_body, "${clipFixed(fx.fixedFull, 6000)}\\nLeft undone: ${clipJoin(fx.undone, '; ', 2000)}")
old_pc = "hold=false only when neither applies. Write exactly the JSON you return to the file.`, { label: `push-check:${round}`, phase: 'Clearance', schema: PUSH_CHECK_SCHEMA, effort: 'high' })"
src = second(src, old_pc, "hold=false only when neither applies.${heldNote()} Write exactly the JSON you return to the file.`, { label: `push-check:${round}`, phase: 'Clearance', schema: PUSH_CHECK_SCHEMA2, effort: 'high' })")
open(F, 'w').write(src)
print('patched', len(src))
