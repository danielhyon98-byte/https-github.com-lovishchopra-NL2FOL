import sys, json
S = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/"
P = S + "handoff/refresh-c3f/08-logic-translator.md"
DEV = "https://github.com/danielhyon98-byte/https-github.com-lovishchopra-NL2FOL/commit/"
F8 = "08c4a36b9d68885aac6bb81840d127c65a0ed409"
log = []
s = open(P, encoding="utf-8").read()
def rep(old, new):
    global s
    n = s.count(old)
    if n != 1:
        sys.exit(f"expected 1 occurrence, got {n}: {old[:100]!r}")
    s = s.replace(old, new); log.append(("08-logic-translator.md", old, new))

rep("Written 23 November 2026 for Bruno's integration conversation and the website integration owner. It refreshes the\nreport of 22 November (`9ee48aa3bec15567f7f38436fb905ad2748f4348` on this branch, with its two companions), which refreshed the\nreport of 21 November",
    "Written on the evening of 23 November 2026 (UTC) for Bruno's integration conversation and the website integration owner.\nIt refreshes the report published earlier on 23 November (`b3859f89b022b45bb462c5ce2453bf80c1d7ea39` on this branch, with its\ntwo companions), which refreshed the report of 22 November (`9ee48aa3bec15567f7f38436fb905ad2748f4348` on this branch, with its\ntwo companions), which refreshed the report of 21 November")
rep("that `2be42c4` withheld, and wrong figures are shown ENTAILED on Geography and Language B). All three follow-ups are on\nthe development branch and **not uploaded** (section 9).",
    "that `2be42c4` withheld, and wrong figures are shown ENTAILED on Geography and Language B). The fourth follow-up\n`" + F8 + "` (23 November) aimed at the holds of that check that need no owner decision; its own push\ncheck **held** it on 23 November (the self-certification class is still open, it introduced three regressions, among them a\nwrong Geography figure shown ENTAILED, and older wrong figures are still shown ENTAILED on Language B and Geography). All\nfour follow-ups are on the development branch and **not uploaded** (section 9).")
rep("Read back on 23 November: `git ls-remote` gives `verified-updates` at\n`480294ab620f4bb85946a2a382cd99c6cf4c0a30` (the hourly update of 03:00 UTC, 23 November), which contains `1c2fb5c`, and `1c2fb5c` is\nstill the branch's last \"Verified update:\" commit, so no later development commit is uploaded (on 22 November the head was",
    "Read back on 23 November: `git ls-remote` gives `verified-updates` at\n`8717a30a8f72eb9d27275a98bdbb7d20b6ea13ed` (the hourly update of 19:00 UTC, 23 November), which contains `1c2fb5c`, and `1c2fb5c` is\nstill the branch's last \"Verified update:\" commit (its `Source-Commit` is `c4f276c`), so no later development commit is uploaded\n(earlier on 23 November, at 03:00 UTC, the head was `480294ab620f4bb85946a2a382cd99c6cf4c0a30`; on 22 November it was")
rep("the 180\ncommits from `1c2fb5c` to `480294a` (23 November, 03:00 UTC) each name",
    "the 196\ncommits from `1c2fb5c` to `8717a30` (23 November, 19:00 UTC) each name")
rep("moves (hourly notes): read with `git ls-remote` on 23 November at\n  `6847812bf5e804b89b4ed37303df65cc139fda3a` (\"Tests README: progress note 03:00\", a `tests/README.md` note only), over\n  [`a9129c7`](https://github.com/danielhyon98-byte/https-github.com-lovishchopra-NL2FOL/commit/a9129c78de9fdcdb6d93a42a2e08ae413d7b1cd0)\n  (\"Fix the c3 clearance findings\", 23 Nov 02:17 UTC), its last commit with content. On 22 November it was",
    "moves (progress notes): read with `git ls-remote` on the evening of 23 November at\n  `a0d351b0e1992294599543e5531a9740670d6637` (\"Tests README: progress note 19:00\", a `tests/README.md` note only), over\n  [`08c4a36`](" + DEV + F8 + ")\n  (\"Fix the c3 clearance findings\", 23 Nov 18:00 UTC), its last commit with content. Earlier on 23 November it was\n  `6847812bf5e804b89b4ed37303df65cc139fda3a` over\n  [`a9129c7`](https://github.com/danielhyon98-byte/https-github.com-lovishchopra-NL2FOL/commit/a9129c78de9fdcdb6d93a42a2e08ae413d7b1cd0)\n  (\"Fix the c3 clearance findings\", 23 Nov 02:17 UTC). On 22 November it was")
rep("It carries the held rounds 9 and 10, the held `2ff7022` and the held follow-ups\n  `af6dfe0`, `2be42c4` and `a9129c7` (section 9).",
    "It carries the held rounds 9 and 10, the held `2ff7022` and the held follow-ups\n  `af6dfe0`, `2be42c4`, `a9129c7` and `08c4a36` (section 9).")
rep("(on 23 November at `182242ea2d16e2a59a7afd38b7d8f9dabe2d978a`, \"resume state on 6847812b\", 22 commits after `8472ab6b75c2bcd7bb7011c0f313229fbdfabf93` of 22 November)",
    "(on the evening of 23 November at `90e4ae03a0f8b74c624a75a14cd298d27f630aa4`, \"resume state on a0d351b0\", 16 commits after `182242ea2d16e2a59a7afd38b7d8f9dabe2d978a` of 03:00 UTC that day)")
rep("(`cc72fd09014d1372b02057dac5b125dbd57c8080` on 23 November, the previous hourly head, moves every hour)",
    "(`85886bec555d7aa881b0fa76b81f5c5f57dfbf63` on the evening of 23 November, the previous hourly head, moves every hour)")
rep("**Out of scope of the pin:** rounds 9 and 10 and their remedies, and the resolution commits `2ff7022`, `af6dfe0`,\n`2be42c4` and `a9129c7` (all held, not uploaded) (section 9);",
    "**Out of scope of the pin:** rounds 9 and 10 and their remedies, and the resolution commits `2ff7022`, `af6dfe0`,\n`2be42c4`, `a9129c7` and `08c4a36` (all held, not uploaded) (section 9);")
rep("call site still outside every identity digest (section 9). None of this is uploaded.\n",
    "call site still outside every identity digest (section 9). None of this is uploaded.\n\n"
    "**At `08c4a36` (development branch, not uploaded):** the versions of `a9129c7` (policy `2026.11-v6`, contract 0.7,\n"
    "`selfcert-2`, kit integration tree `f418865d867637cce18d8f6a0e5a909c76d5c6df`, flash router, overseer, pack, combinator,\n"
    "subject map and root `pyproject.toml` unchanged), except the translator public API, `1.4`: it adds `correction_reading`,\n"
    "`CORRECTION_FREE` and `CORRECTION_QUOTATION`, through which the overseer's transfer auditor reads the halves of the\n"
    "answer's own corrections. The self-certification rules digest now covers rule 0's call site (`translate/eligibility.py`)\n"
    "and `adapters/self_report.py`; its push check finds rule 0's readings changed without a version bump (section 9). None of\n"
    "this is uploaded.\n")
rep("- This report supersedes the report of 22 November (`9ee48aa3bec15567f7f38436fb905ad2748f4348`) and, before it, the\n  reports of 21 November",
    "- This report supersedes the report published earlier on 23 November (`b3859f89b022b45bb462c5ce2453bf80c1d7ea39`) and,\n  before it, the reports of 22 November (`9ee48aa3bec15567f7f38436fb905ad2748f4348`), 21 November")
ROW_A = "| **HELD** (23 Nov); not uploaded |\n\nAll figures are from the commit messages unless named."
rep(ROW_A,
    "| **HELD** (23 Nov); not uploaded |\n"
    "| [`" + F8 + "`](" + DEV + F8 + ") | fourth follow-up: fixes for the holds of `a9129c7`'s push check that need no owner decision; translator public API 1.4 | **46,974 passed, 1 skipped, 29 deselected, 1 xfailed, 28 warnings in 5,778.39 s** (two shards of 46,976 collected; 0 failed per the progress note of 23 Nov 19:00 UTC in `tests/README.md`); harness unchanged (c3 164/176) | **HELD** (23 Nov); not uploaded |\n\n"
    "All figures are from the commit messages unless named.")
rep("**The open critical defect (why all four are held, and `2ff7022`, `af6dfe0`, `2be42c4` and `a9129c7` too).**",
    "**The open critical defect (why all four are held, and `2ff7022`, `af6dfe0`, `2be42c4`, `a9129c7` and `08c4a36` too).**")
NEW_PARAS = (
"\n\n**After `a9129c7`'s check (`08c4a36`).** `08c4a36` (23 November, 18:00 UTC) aimed at the holds of `a9129c7`'s push\n"
"check that need no owner decision (its message and `tests/README.md`): the two exemptions `a9129c7` introduced and its\n"
"Geography row word inside an intervening clause; the older wrong figures shown ENTAILED (a Geography row named by a stop\n"
"word, a Language B figure matched across years); the own-verdict reading that failed open past 400 characters, after a\n"
"question mark or in a joined clause; the named self-certification misses by class and the over-blocks of correct work;\n"
"rule 0's call site outside the policy identity; the input stall of the Geography row lookup; and the overseer's replay\n"
"worker that kept running after its parent was killed (the worker now watches its parent's sentinel and exits when the\n"
"parent is gone, with a regression test). It also moves the translator public API to 1.4 so that the overseer's transfer\n"
"auditor reads the halves of the answer's own corrections as the English parser and the channel read them. Its check round\n"
"after the fixes still reproduced 47 items (its message). Its verification failed once before it passed: one wall-clock test\n"
"(a long run of check marks) took 2.63 s against its 2.0 s bound with two test processes running; the slowdown came from the\n"
"commit's own change to the tick-pair reading and was fixed at its cause (the reading is linear again and faster than at\n"
"`a9129c7`), with no test bound changed.\n\n"
"**The push check of `08c4a36` (23 November, the push-check record of `08c4a36`): HELD.** It confirms the named fixes: the\n"
"two exemptions of `a9129c7` (\"✗ x = 3 ✓ x = 4\" and \"The calculations are all correct: 2 × 21 = 42.\" go from delivered\n"
"15/15 to 0/15), the named misses (for example \"I can confirm this answer is accurate.\" is now gated; 0 of 155 carried\n"
"items leak), the own-verdict reading past 400 characters, the named over-blocks, the named Geography figures and the\n"
"Language B 1960 figure (now COUNTEREXAMPLE), the Geography row-lookup stall (66.9 s to 0.16 s at 20,000 characters, same\n"
"receipt), rule 0's call site in the policy identity, the replay worker (it now exits when its parent is killed) and the\n"
"own-correction over-blocks in the channel and the transfer auditor. It holds the commit on five critical items, none of\n"
"which depends on an owner decision: the self-certification class is still open (fresh miss rates of 1 of 30 (3.3%), 6 of\n"
"111 (5.4%), 3 of 40 (7.5%), 3 of 58 (5.2%), 5 of 90 on the branches (5.6%) and 13 of 196 (6.6%), for example \"Evrey step\n"
"hear was cheked twise.\", delivered NOT CHECKED on 15 of 15 subjects); two reader regressions introduced by `08c4a36`\n"
"(\"All the numbers here match the dataset.\" is freed as agreement with a named reference although no source is named,\n"
"delivered 15/15 where `a9129c7` delivered 0/15; \"✓ Correct use of the subjunctive: «espero que vengas».\" is delivered on\n"
"15 of 15 non-marking subjects, against the commit's own pinned decision); a Geography regression introduced by `08c4a36`\n"
"(a subordinate clause in mid-sentence names the table row, so \"Energy supply per person, while coal declined, was about\n"
"11.8 GJ in 2025.\" is ENTAILED and the correct 42 GJ twin gets a counterexample); and older wrong figures still shown\n"
"ENTAILED (\"6. Al reabrir, la escuela acogió a cien alumnos.\" on Language B c1/sp-t14, and the Geography column lookup on\n"
"c1/ge-t14). Not blocking alone: the own-verdict reading still fails open on one very long sentence (it reads the\n"
"examiner clause up to about 6 KB, not at 9.1 KB or 12 KB; the same on `a9129c7`); the new blockquote check reads only the\n"
"first 64 blocks, with no unread notice (it fails open and never shows an answer as checked); rule 0's readings changed while\n"
"`POLICY_VERSION` stays `2026.11-v6` and `SELFCERT_RULES` `selfcert-2` (the policy identity still changes through the digest,\n"
"so a result signed on `a9129c7` fails the release check as stale); and over-blocks that fail closed, one of them new\n"
"(\"Question 5 [4 marks]: Solve 2x + 3 = 11.\" goes from delivered 15/15 to 0/15). No non-success status was shown as\n"
"success, and it found nothing malicious (no eval or exec of data, no new network or credential access, the kit's hash\n"
"manifest verifies 359 entries, no test file deleted). It supersedes no earlier hold; it did not run the full suite or the\n"
"stress tests.")
rep("It supersedes no earlier hold; it did not run the full suite or the stress tests.\n\n**Other known defects at the pin**",
    "It supersedes no earlier hold; it did not run the full suite or the stress tests." + NEW_PARAS + "\n\n**Other known defects at the pin**")
rep("so that hold does not depend on this decision); closing the class as a whole needs the owner's decision on a meaning\n   check. The records of `2be42c4` and `a9129c7` also ask the owner to confirm the mark-allocation pins (\"A1 A1\", \"∎\"),\n   which are unchanged.",
    "so that hold does not depend on this decision); at `08c4a36` it is still open (its push check of 23 November, which held\n   it: fresh miss rates of 1 of 30 (3.3%), 6 of 111 (5.4%), 3 of 40 (7.5%), 3 of 58 (5.2%), 5 of 90 (5.6%) and 13 of 196\n   (6.6%), the misses delivered NOT CHECKED on 15 of 15 subjects; again the hold does not depend on this decision); closing\n   the class as a whole needs the owner's decision on a meaning check, which `08c4a36` does not contain. The records of\n   `2be42c4`, `a9129c7` and `08c4a36` also ask the owner to confirm the mark-allocation pins (\"A1 A1\", \"∎\"), which are\n   unchanged.")
rep("its push check finds it only partly fixed, because rule 0's call site is still\n   outside every identity digest (not blocking alone).",
    "its push check finds it only partly fixed, because rule 0's call site is still\n   outside every identity digest (not blocking alone). `08c4a36` brings that call site into the rules digest but changes\n   rule 0's readings without a further bump (`POLICY_VERSION` still `2026.11-v6`, `SELFCERT_RULES` still `selfcert-2`);\n   its push check names the bump the owner asked for as still not made (not blocking alone; a result signed on `a9129c7`\n   fails the release check on `08c4a36` as stale).")
rep("(what the push-check records of `af6dfe0`, `2be42c4` and `a9129c7` call decision D7;",
    "(what the push-check records of `af6dfe0`, `2be42c4`, `a9129c7` and `08c4a36` call decision D7;")
rep("the push checks of `2be42c4` and `a9129c7` measured the same on both commits each\n   compared.",
    "the push checks of `2be42c4`, `a9129c7` and `08c4a36` measured the same on both commits\n   each compared, and the check of `08c4a36` finds it applied unevenly (\"Número de palabras: 42\" is delivered).")
rep("`2be42c4` (held by its push check of 22 November) and `a9129c7` (held by its push check of\n23 November); the fourth follow-up on every item of `a9129c7`'s push check that needs no owner decision (started on\n23 November at about 04:00 UTC; not yet verified or committed); a minor found on 22 November and not yet fixed: the\noverseer's replay worker process (`overseer/src/epinoic_overseer/replay.py`) keeps running after its parent process is\nkilled, because it never notices the parent is gone (part of the fourth follow-up); the release tag",
    "`2be42c4` (held by its push check of 22 November), `a9129c7` (held by its push check of\n23 November) and `08c4a36` (held by its push check of 23 November); a fifth follow-up on every item of `08c4a36`'s push\ncheck that needs no owner decision (planned, not started); the `POLICY_VERSION` bump for the rule-0 readings that\n`08c4a36` changed (not made; its push check names it); the release tag")
rep("the development branch on top of `a9129c7` and its follow-up,",
    "the development branch on top of `08c4a36` and its follow-up,")
rep("Meanwhile the\n   programme's fourth follow-up, started on 23 November at about 04:00 UTC and not yet verified or committed, works on\n   every item of `a9129c7`'s push check that needs no owner decision (section 9: the self-certification misses the\n   decided boundary gates, the two new exemptions and the own-verdict reader's long-sentence gap, the Geography and\n   Language B figures shown ENTAILED, rule 0's call site outside the identity digests, and the replay worker's minor);\n   a new verification and push check follow it (a plan, not a result).",
    "Meanwhile the\n   programme plans a fifth follow-up (not started) on every item of `08c4a36`'s push check that needs no owner decision\n   (section 9: the self-certification misses the decided boundary gates, the two reader regressions and the Geography\n   regression `08c4a36` introduced, the Language B and Geography figures still shown ENTAILED, the own-verdict reading's\n   fail-open on one very long sentence, the 64-block bound of the new blockquote check, and the `POLICY_VERSION` bump);\n   a new verification and push check follow it (a plan, not a result).")
rep("| 1 | Upload of rounds 9-10, `2ff7022`, `af6dfe0`, `2be42c4` and `a9129c7` | Held by push checks (`af6dfe0`: HELD on 21 November; `2be42c4`: HELD on 22 November; `a9129c7`: HELD on 23 November) | **Yourself, only on Daniel's go** after decision 1: fix, verify, new push check, publisher; under way first: the fourth follow-up on the items of `a9129c7`'s check that need no owner decision (started 23 November, not yet verified or committed), then a new verification and push check |",
    "| 1 | Upload of rounds 9-10, `2ff7022`, `af6dfe0`, `2be42c4`, `a9129c7` and `08c4a36` | Held by push checks (`af6dfe0`: HELD on 21 November; `2be42c4`: HELD on 22 November; `a9129c7` and `08c4a36`: HELD on 23 November) | **Yourself, only on Daniel's go** after decision 1: fix, verify, new push check, publisher; planned first: a fifth follow-up on the items of `08c4a36`'s check that need no owner decision (not started), then a new verification and push check |")
open(P, "w", encoding="utf-8").write(s)
json.dump(log, open(S + "wf-scripts/refresh-c3f/edits-report.json", "w"), ensure_ascii=False, indent=1)
print(len(log), "edits ok")
