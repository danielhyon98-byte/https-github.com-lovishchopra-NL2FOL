import sys, json
D = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/handoff/refresh-c3f/"
DEV = "https://github.com/danielhyon98-byte/https-github.com-lovishchopra-NL2FOL/commit/"
F8 = "08c4a36b9d68885aac6bb81840d127c65a0ed409"
log = []
def apply(name, pairs):
    p = D + name
    s = open(p, encoding="utf-8").read()
    for old, new in pairs:
        n = s.count(old)
        if n != 1:
            sys.exit(f"{name}: expected 1 occurrence, got {n}: {old[:90]!r}")
        s = s.replace(old, new)
        log.append((name, old, new))
    open(p, "w", encoding="utf-8").write(s)

HOLD_SENT = (f"The fourth follow-up `{F8}` (23 November; 46,974 passed, 1 skipped, 1 expected failure, 0 failed; translator public "
             "API 1.4, policy and contract unchanged), aimed at that check's items that need no owner decision, was also **HELD** by "
             "its own push check on 23 November: the self-certification class is still open (fresh phrasings missed at 3.3% to 7.5% "
             "in six probes), it introduced three regressions (an unnamed \"the dataset\" read as a named reference, a tick-mark "
             "approval freed outside marking tasks, and a wrong Geography figure shown ENTAILED), and older wrong figures are still "
             "shown ENTAILED on Language B and Geography; it found nothing malicious, and it is not uploaded.")

# ---------------- Bruno ----------------
apply("08-instructions-for-bruno.md", [
 ("Written 23 November 2026 for Bruno, from Daniel's programme; it refreshes the note of 22 November, which refreshed the\nnote of 21 November,",
  "Written on the evening of 23 November 2026 (UTC) for Bruno, from Daniel's programme; it refreshes the note published earlier\non 23 November (`b3859f89b022b45bb462c5ce2453bf80c1d7ea39` on `docs/final-z3-handoff`), which refreshed the note of\n22 November, which refreshed the note of 21 November,"),
 ("and wrong figures are shown ENTAILED on Geography and Language B; it found nothing malicious, and it is not uploaded. Nothing new has been uploaded, so nothing changes",
  "and wrong figures are shown ENTAILED on Geography and Language B; it found nothing malicious, and it is not uploaded. " + HOLD_SENT + " Nothing new has been uploaded, so nothing changes"),
 ("`2ff7022`, `af6dfe0` and `2be42c4` carry contract 0.6 and policy `2026.11-v5`, and the latest,\n   `a9129c7`, contract 0.7 and policy `2026.11-v6`.",
  "`2ff7022`, `af6dfe0` and `2be42c4` carry contract 0.6 and policy `2026.11-v5`, and `a9129c7`\n   and the latest, `08c4a36`, contract 0.7 and policy `2026.11-v6`."),
 ("(the push check of `a9129c7` measured fresh phrasings missed at 2.7%, 6.25%, 6.7%, 8.0% and 15%; it holds that commit\non misses the decided boundary already gates, so that hold does not depend on this decision);",
  "(the push check of `08c4a36` measured fresh phrasings missed at 3.3%, 5.2%, 5.4%, 5.6%, 6.6% and 7.5%, after 2.7% to 15%\nat `a9129c7`; it holds that commit on misses the decided boundary already gates, so that hold does not depend on this\ndecision);"),
 ("contract 0.6; `a9129c7` moves on to `2026.11-v6` and contract 0.7).",
  "contract 0.6; `a9129c7` moves on to `2026.11-v6` and contract 0.7; `08c4a36` changes rule 0's readings again without a\nfurther bump, which its push check names as not yet made, not blocking alone)."),
 ("(5) what the push\nchecks of `af6dfe0`, `2be42c4` and `a9129c7` call decision D7 (its name;",
  "(5) what the push\nchecks of `af6dfe0`, `2be42c4`, `a9129c7` and `08c4a36` call decision D7 (its name;"),
 ("which over-blocks correct work whenever a task asks for a\nword count; keeping or changing that is the owner's call.",
  "which over-blocks correct work whenever a task asks for a\nword count (the check of `08c4a36` also finds it applied unevenly: \"Número de palabras: 42\" is delivered); keeping or\nchanging that is the owner's call."),
 ("`af6dfe0`, `2be42c4` and `a9129c7` (held by their push checks of 21, 22 and 23 November, section 2); a fourth follow-up\non the items of `a9129c7`'s check that need no owner decision (started on 23 November, not yet verified or committed);",
  "`af6dfe0`, `2be42c4`, `a9129c7` and `08c4a36` (held by their push checks of 21, 22 and 23 November, section 2); a fifth\nfollow-up on the items of `08c4a36`'s check that need no owner decision (planned, not started); the `POLICY_VERSION`\nbump for the rule-0 readings `08c4a36` changed (not made);"),
])

# ---------------- Website ----------------
apply("08-logic-translator-website-launch.md", [
 ("Written 23 November 2026 from `git` reads of that day and the owner's preflight update of 25 October, which remains the\nagents' launch state. It refreshes the version of 22 November, which refreshed",
  "Written on the evening of 23 November 2026 (UTC) from `git` reads of that day and the owner's preflight update of\n25 October, which remains the agents' launch state. It refreshes the version published earlier on 23 November\n(`b3859f89b022b45bb462c5ce2453bf80c1d7ea39`), which refreshed the version of 22 November, which refreshed"),
 ("and wrong figures are shown ENTAILED on Geography and Language B; it found nothing malicious, and it is not uploaded. In this release **FORMALLY CHECKED is withheld for every answer**.",
  "and wrong figures are shown ENTAILED on Geography and Language B; it found nothing malicious, and it is not uploaded. " + HOLD_SENT + " In this release **FORMALLY CHECKED is withheld for every answer**."),
 ("the held `2ff7022` and its held follow-ups `af6dfe0`, `2be42c4` and `a9129c7` (`a9129c7` is the last commit with content, 23 Nov 02:17 UTC; the head moves hourly with progress notes, on 23 Nov at the 03:00 UTC note `6847812bf5e804b89b4ed37303df65cc139fda3a`)",
  "the held `2ff7022` and its held follow-ups `af6dfe0`, `2be42c4`, `a9129c7` and `08c4a36` (`08c4a36` is the last commit with content, 23 Nov 18:00 UTC; the head moves with progress notes, on 23 Nov at the 19:00 UTC note `a0d351b0e1992294599543e5531a9740670d6637`)"),
 ("translator public API 1.3, with the same flash router, pack\nand subject map; IR, engine and translator stay 1.0 / 0.4.0 / 0.4.0.",
  "translator public API 1.3, with the same flash router, pack\nand subject map; `08c4a36` keeps all of these except the translator public API, now 1.4; IR, engine and translator stay\n1.0 / 0.4.0 / 0.4.0."),
 ("and on the follow-ups\n`af6dfe0`, `2be42c4` and `a9129c7` (their push checks of 21, 22 and 23 November, which held them)",
  "and on the follow-ups\n`af6dfe0`, `2be42c4`, `a9129c7` and `08c4a36` (their push checks of 21, 22 and 23 November, which held them)"),
 ("and wrong figures shown ENTAILED on Geography and Language B; nothing malicious). **Under way, by the programme (a plan, not a result):** a fourth follow-up on the items of `a9129c7`'s check that need no owner decision (started 23 November, not yet verified or committed), followed by a new verification and push check.",
  "and wrong figures shown ENTAILED on Geography and Language B; nothing malicious). **Done, not uploaded, held by its push check (23 November):** `08c4a36` (aimed at `a9129c7`'s items that need no owner decision; its check confirms most named fixes, the overseer's replay worker among them, and finds the self-certification class still open, three regressions it introduced (an unnamed \"the dataset\" read as a named reference, a tick-mark approval freed outside marking tasks, a wrong Geography figure shown ENTAILED) and older wrong figures still shown ENTAILED on Language B and Geography; nothing malicious). **Planned, by the programme (a plan, not a result):** a fifth follow-up on the items of `08c4a36`'s check that need no owner decision (not started), followed by a new verification and push check."),
 ("`a9129c7` (held by its push check of\n  23 November; not uploaded; 46,348 passed, 1 skipped, 1 xfailed, 0 failed), until the fourth follow-up on the items of\n  `a9129c7`'s check that need no owner decision (started 23 November, not yet verified or committed) and Daniel's\n  decision",
  "`a9129c7` (held by its push check of\n  23 November; not uploaded; 46,348 passed, 1 skipped, 1 xfailed, 0 failed) and `08c4a36` (held by its push check of\n  23 November; not uploaded; 46,974 passed, 1 skipped, 1 xfailed, 0 failed), until a fifth follow-up on the items of\n  `08c4a36`'s check that need no owner decision (planned, not started) and Daniel's\n  decision"),
 ("- **Superseded:** the version of this file of 22 November (`9ee48aa3bec15567f7f38436fb905ad2748f4348`, same pin), the",
  "- **Superseded:** the version of this file published earlier on 23 November\n  (`b3859f89b022b45bb462c5ce2453bf80c1d7ea39`, same pin), the version of 22 November\n  (`9ee48aa3bec15567f7f38436fb905ad2748f4348`, same pin), the"),
])
json.dump(log, open("/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/wf-scripts/refresh-c3f/edits-bw.json", "w"), ensure_ascii=False, indent=1)
print(len(log), "edits ok")
