export const meta = {
  name: 'handoff-refresh-c3d',
  description: 'Refresh the three published handoff documents with the c3d commit 2be42c48 and its push-check result, then review them independently',
  phases: [
    { title: 'Update', detail: 'copy the published 21 Nov documents, then update every statement about the development line, 2be42c48 and its push check' },
    { title: 'Review', detail: 'check every changed statement against the push-check records and git; publisher content greps; fix in place' },
  ],
}
const S = '/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad'
const REPO = '/home/user/https-github.com-lovishchopra-NL2FOL'
const PUB = `${S}/handoff/filled-21nov`
const HDIR = `${S}/handoff/refresh-22nov`
const SHA = '2be42c4808c0b23e9ea7a3db7992f7bd9863a545'
const PCJ = `${S}/push-check/${SHA}.json`
const PCJ_PREV = `${S}/push-check/af6dfe04ef67ad8c934767a78b0b743a14870513.json`
const STR = { type: 'string' }
const STRS = { type: 'array', items: STR }
const RULES = `Content rules (the publisher refuses otherwise): no model name, no session id or link, no local path (/tmp, /root, /home), no placeholder of the form {{NAME}}; full commit SHAs at a commit's first mention in each document; plain words; measured numbers only, never invented; every new statement must be supported by the push-check records, git or tests/README.md. Documents only: never push, never edit ${REPO}'s working tree, never touch ${PUB}.`
const FACTS = `FACTS (check each against git -C ${REPO} log/show, the push-check records and tests/README.md): the code uploaded to Bruno's repository is still c4f276ca060909e1e7d26c2ed403a6726c50eb2c (last "Verified update:" commit 1c2fb5cd0b64dafdea25ce9471d533afbbbde08b; the hourly updates since carry no new final code; read the current verified-updates head with git ls-remote epinoic). The documents published on 21 November (docs/final-z3-handoff 82981fee7406517c297e043ace9bffa9c32c0746) describe af6dfe04 as HELD by its push check (${PCJ_PREV}). Since then the development branch received ${SHA} ("Fix the c3 clearance findings", follow-up 2, 22 Nov about 04:32 UTC; read its commit message whole: what it fixed, the check round's numbers, full suite 45,120 passed, 1 skipped, 29 deselected, 1 xfailed, 0 failed, two shards of 45,122 collected; harness unchanged, c3 164/176) and after it only tests/README.md progress notes. Its independent push check is recorded in ${PCJ} (read it whole: hold, reasons, critical_open, suspicious, supersedes).`
const UPD_SCHEMA = { type: 'object', properties: { changes: STRS, summary: STR }, required: ['changes'] }
const REV_SCHEMA = { type: 'object', properties: { ok: { type: 'boolean' }, issues: STRS, fixed: STRS }, required: ['ok', 'issues'] }

phase('Update')
const up = await agent(`HANDOFF REFRESH (documents only). mkdir -p ${HDIR} and copy the three published documents from ${PUB}/ (08-logic-translator.md, 08-logic-translator-website-launch.md, 08-instructions-for-bruno.md) into ${HDIR}/, then update the copies in place. ${FACTS}
Update every statement that the new commit and its push check change: the dates and "written on" lines (22 November), the development-branch head and its last commit with content, the report's section 9 table (a row for ${SHA} with its suite numbers and its push-check status), the af6dfe0 paragraph's successor (what ${SHA} addressed, and what its push check found, in proportion: one sentence in the website and Bruno documents, a short paragraph in the report), the decisions (decision 1 stays the owner's meaning check: give the new measured rates from ${PCJ}; decision 5, word counts under D7, stays open unless the record says otherwise), the 'Not done' and next-step lists (if the push check holds, the next step is the owner's decision on a meaning check, plus any item the record names that needs no owner decision), and the supersedes line (this refresh supersedes the documents of 21 November, 82981fee7406517c297e043ace9bffa9c32c0746). Keep the structure, the headings and every statement that is still true. Never say a commit passed, cleared or was uploaded unless the record and git say so. ${RULES} Return every change (old statement -> new).`, { label: 'handoff:update:c3d', phase: 'Update', schema: UPD_SCHEMA, effort: 'high' })

phase('Review')
const rv = await agent(`HANDOFF REVIEW. The three documents in ${HDIR}/ were refreshed from the published versions in ${PUB}/ with the commit ${SHA} and its push check. Changes reported by the writer: ${JSON.stringify((up && up.changes) || []).slice(0, 20000)}
${FACTS}
Check every statement that differs from ${PUB}/ (diff each file) against the records ${PCJ} and ${PCJ_PREV} (read them whole), git -C ${REPO} log/show/ls-remote, tests/README.md and integration/DECISIONS.md; every number must appear in a record, in git or in tests/README.md. Nothing may say ${SHA} passed, cleared or was uploaded unless the record and git say so. Apply the publisher's content rules: grep -n -i -E '/tmp/|/root/|/home/|session_0|claude\\.ai/code|\\bopus\\b|\\bsonnet\\b|\\bhaiku\\b|\\bfable\\b|claude-(opus|sonnet|haiku|fable)' and grep -n -E '\\{\\{[A-Z_]+\\}\\}' over the three files must print nothing. Fix any wrong, unsupported or rule-breaking statement in place in ${HDIR}/ (never touch ${REPO} or ${PUB}). ok=true only if, after your fixes, every changed statement is supported and both greps print nothing. ${RULES} Return ok, the issues found and what you fixed.`, { label: 'handoff:review:c3d', phase: 'Review', schema: REV_SCHEMA, effort: 'high' })

return { changes: (up && up.changes) || [], review_ok: rv && rv.ok, review_issues: (rv && rv.issues) || [], review_fixed: (rv && rv.fixed) || [] }
