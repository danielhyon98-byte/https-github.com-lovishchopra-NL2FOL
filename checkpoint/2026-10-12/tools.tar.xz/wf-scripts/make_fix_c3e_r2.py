#!/usr/bin/env python3
"""Build wf-scripts/fix-c3e.js (r2: the check fixer also gets the fixers' left_undone, 22 Nov 08:1x): the third follow-up, after the push check of 2be42c48 held it (22 Nov 05:37).

Copied from fix-c3c.js (asserted): the constants, schemas and class/boundary definitions, verifyPrompt, verifyPrompt2,
covers/isGreen, verifyAndCommit and the ATK lenses (from "// Constants and helpers" up to the "Fix: four owners" marker).
Replaced in the copy (asserted): OUT (c3d), PCF (the af6dfe04 record), DCTX (this run), every verification uses
verifyPrompt2 (harness after the suite), the repair brief loses the c3c-only note about staged tmp* deletions.
The body: four fixers on disjoint paths, one check round (10) of the four lenses, one check fixer, verify and commit.
The push check of the resulting commit and the handoff refresh run afterwards from the main session.
"""
import re
import sys

SRC, OUT_JS = sys.argv[1], sys.argv[2]
src = open(SRC, encoding='utf-8').read()
lines = src.split('\n')
start = next(i for i, l in enumerate(lines) if l.startswith('// Constants and helpers copied verbatim'))
end = next(i for i, l in enumerate(lines) if l.startswith('// ---') and 'Fix: four owners' in l)
block = '\n'.join(lines[start:end])


def rep(text, old, new, count=1):
    n = text.count(old)
    assert n == count, (old[:80], n)
    return text.replace(old, new)


block = rep(block, "const OUT = `${WF2}/c3c`", "const OUT = `${WF2}/c3e`")
block = rep(block, "const PCF = `${S}/push-check/2ff70224ca4a44a6a5f1164aa1183d12e225dcb3.json`",
            "const PCF = `${S}/push-check/2be42c4808c0b23e9ea7a3db7992f7bd9863a545.json`\n"
            "const PCF_PREV = `${S}/push-check/af6dfe04ef67ad8c934767a78b0b743a14870513.json`\n"
            "const PCLENSES = `${WF2}/c3e/pushcheck-2be42c4-lenses.json`\n"
            "const C3D_LEFT = `${WF2}/c3e/c3d-left.json`")
# DCTX: from "const DCTX = `${CTX}" to the line that ends the template (the SUBPROJECT_PATH line)
m = re.search(r"const DCTX = `\$\{CTX\}\n.*?\$\{SUBPROJECT_PATH\}`\n", block, re.S)
assert m, 'DCTX block not found'
NEW_DCTX = r"""const DCTX = `${CTX}
THIS RUN (follow-up 3, 22 Nov). The commit 2be42c48 "Fix the c3 clearance findings" (follow-up 2: the five named own-quality claims, misspellings read by edit distance in a check frame, reversed and ROT13 text, outside authorities, the stray quotation mark, the gate2 test exclusion removed, the channel quotation frames, over-blocks, the overseer skip; full suite 45,120 passed; harness unchanged) is HELD by its independent push check: read ${PCF} whole, and the lists of its four lenses and its challenger in ${PCLENSES}. Its first hold, the self-certification class itself (fresh self-certifying phrasings are still delivered: 5.0%, 4.5% and 12.5% reader misses in three probes), needs the owner's decision on a meaning check and is NOT part of this run: add no model call, no status line on answers and no documented limitation. Word-count lines ('Word count: 312', 'Palabras: 25', '(312 words)') stay gated as self-reports under decision D7 until the owner decides, and the mark-allocation pins ('A1 A1', '∎') stay as they are until the owner confirms: do not change those, and do not report them. This run fixes the push check's other items: the near variants of items reported fixed, the own-wording quotation frames that still lose their error, the judge-reproduced misses by class, the over-blocks it names (Language B correction pairs, the French gloss, the Spanish worked check), the branch misses, the version discipline of rule 0 (the rules digest must cover the rule's code), a Geography lead from the branches-policy lens (a wrong figure reported as ENTAILED: reproduce it first) and the open items the c3d run left (${C3D_LEFT}), in ONE verified commit at the end.
The working tree of ${REPO} (branch ${BRANCH}) is shared by this run's agents; no agent commits, stashes, resets, reverts or checks out anything in it unless its task says so (the workflow verifies and commits once, at the end). Never amend, rebase or force-push anything already on origin. Write probes, copies and exports only under ${OUT}/, never inside ${REPO} (tests/test_repository_hygiene.py guards the root).${SUBPROJECT_PATH}`
"""
block = block[:m.start()] + NEW_DCTX + block[m.end():]
block = rep(block, "let v = await agent(verifyPrompt(extraRounds, label),", "let v = await agent(verifyPrompt2(extraRounds, label),")
block = rep(block, "NOTE FROM THE MAIN SESSION: the hygiene hit about the five tmp* directories (staged deletions 'D ') was a fault of the check, not of the tree: their deletion is the intended fix and the commit records it, so never restore them and never unstage it (the next verification accepts staged deletions there). ", "")
for need in ('function verifyPrompt(', 'function verifyPrompt2(', 'async function verifyAndCommit(', 'const ATK = [', 'const SELFCERT_CLASS =', 'const RESTARTS ='):
    assert need in block, need

# the fixer rules of fix-c3c (asserted verbatim), reused with the c3d restart labels
rm = re.search(r"\\nRules for every fixer: (.*?)\$\{RESTARTS\('c3c-' \+ f\.key\)\}", src, re.S)
assert rm, 'fixer rules not found'
FIX_RULES = 'Rules for every fixer: ' + rm.group(1)

META = """export const meta = {
  name: 'translator-fix-c3e',
  description: "Third follow-up after the push check held 2be42c48: fix its items that need no owner decision (near variants, quotation frames, judge-reproduced misses by class, over-blocks, branch misses, rule-0 version discipline, a Geography ENTAILED lead) and the c3d leftovers; one check round with a readings diff; verify and commit",
  phases: [
    { title: 'Fix', detail: 'four owners on disjoint paths: self-certification reader and its tests, channel and quotation readers, subject branches, overseer' },
    { title: 'Check', detail: 'one round (11): phrasings, correct work, branches and a readings diff against HEAD; one fixer for what they reproduce' },
    { title: 'Verify', detail: 'full suite in shards, then the harness on every round, hygiene, up to three repairs, commit' },
  ],
}"""

BODY = r"""
// ================================================================== fix-c3e (written 22 Nov 05:4x after the push check of 2be42c48 held it)
phase('Fix')
const FIXERS = [
  { key: 'selfcert', task: `You own src/epinoic_logic/selfcert/**, scripts/selfcert/**, tests/selfcert/** and tests/adapters/test_integration_gate2_parsers.py. The push check of 2be42c48 (${PCF}; lens and challenger lists in ${PCLENSES}) names these items, which need no owner decision; fix each at its cause and by class, on every branch and every release path:
(1) Near variants of items reported fixed (its critical_open 2): misspellings of check words outside a check frame ('All figures double-chekced.', 'Every figure double-chcked.', 'Double-cheked.', 'Proof-red and fact-cheked.'): a misspelt check word standing as the answer's own status sentence or compound (double-, fact-, proof-) is read as the check word; a reversed label line ('delcehc lla :serugif') like the fixed 'deifirev :sutatS'; outside authorities credited with reviewing this text ('Este texto fue revisado por la RAE.', 'The Royal Statistical Society has reviewed the numbers in this reply.', 'Encyclopaedia Britannica backs up every figure in this reply.') while boundary (b) stays free ('The ONS confirmed the figures.'); 'This is a marker's dream of an answer.'.
(2) The judge-reproduced misses (critical_open 1), by class only (frames, never sentences): 'I keyed each of these values into a calculator and they all came out as stated.', 'This responce was checkd by the panel.', 'El profesor de geografía dio por buenas estas cifras.', 'The examiner would have nothing to criticise here.', 'Errorless.', 'The second-opinion agent concurs with every line.', 'solver: 0 counterexamples / 14 claims', 'An LLM judge scored this reply 10/10.', and the lenses' fresh misses in ${PCLENSES} ('I'd bet the farm that this is right.', 'Nobody will find a hole in this.', 'This reply was put through its paces before reaching you.', 'Los datos de esta respuesta son irreprochables.', 'Status: d-e-i-f-i-r-e-v', 'This writeup has been battle-tested.', 'Nothing here would trouble a moderator.', 'The ledger matches every claim above.' and the rest there). Only if no false positive is added: re-run the development sets in tests/selfcert/data and the recorded genuine answers of ${CLR}/c1, ${CLR}/c2 and ${C3} through delivery.
(3) Over-blocks the record names (reason 5): 'Mal: "La problema". Bien: "El problema".' (new in 2be42c48: lexicon.json lists 'mal', so a correction-pair label reads as rule G1 CHECK; labels of a correction pair are not checks), '- Wrong: "La problema". Right: "El problema".', 'Mal: "el gente" → Bien: "la gente"', "The French word 'vérifié' means checked." (like the fixed Latin gloss) and 'Comprobación: 25 % de 80 = 20' (a worked check under boundary (b), as the English 'Check: 3 × 5 = 15' is free): each must be delivered.
(4) Version discipline of rule 0 (reason 6): selfcert.rules_digest hashes SELFCERT_RULES, lexicon.json and fold_table.json but not selfcert/*.py, so a code-only change to rule 0 would leave policy_id unchanged. Make the digest cover the rule's code (every module under src/epinoic_logic/selfcert/, in a fixed order, by content), bump SELFCERT_RULES to 'selfcert-2', and follow the version rule of ${C3B}/selfcert-design.md for POLICY_VERSION; update every test pin, document and kit record that quotes a changed value (to the new value: stricter, never removed) and make sure results bound to the old identity are never shown as current.
(5) Leave the word-count lines (D7) and the mark-allocation pins ('A1 A1', '∎') exactly as they are.` },
  { key: 'channel', task: `You own src/epinoic_logic/channel/**, src/epinoic_logic/adapters/own_text.py, src/epinoic_logic/adapters/markdown.py (its correction and quotation-role readers), src/epinoic_logic/adapters/english_specialist/parser.py (its quotation crediting only) and tests/channel/**. (1) The af6dfe04 regression is only partly fixed (critical_open 3 of ${PCF}): own_text._OWN_TEXT_CREDIT_BEFORE_RE reads any first-person possessive before a quotation ('nos pide', 'our teacher', 'mi profesora') as credit to the answer's own text, so on a copy (under ${OUT}/) of ${CLR}/c2's sp-t15 record with the task's 'instituto' changed to 'colegio', 'Se nos pide lo siguiente: "..."', 'Our teacher wrote "..."', 'Mi profesora escribió: "..."' and 'The heading reads "..."' lose their INT-REQ-003 error when the answer also writes the altered wording (before or after the quotation); each gives the error when it stands alone. Fix it at the cause: wording attributed to the task, a teacher, an exam paper, a heading or instructions is checked against the task in every frame and language; only the answer's own voice credits own text; the af6dfe04 behaviour for the answer's own corrections stays. Pin every frame (English, Spanish, own wording before and after). (2) The c3d leftovers in these paths (${C3D_LEFT}): '- Mal: "El primer semana fue difícil". Bien: "La primera semana fue difícil"' on sp-t16 gives INT-REQ-003 at error on the corrected span (markdown correction readers read only some labels); 'Before: "x". After: "y".' on the English branch (ll-t16) gives INT-REQ-003 and ES-SRC-001 on both spans; 'As I said above, "..."' on the English branches is credited to the text under analysis before the own-text path runs; the adapters README own_text section is out of date.` },
  { key: 'branches', task: `You own src/epinoic_logic/branches/** and tests/branches/**. (1) FIRST reproduce the lead from the branches-policy lens of the push check (in ${PCLENSES}; the judge's record does not mention it): geography._yt_named_row's fallback treats the function word 'and' as naming the row 'Wind and solar power', so on ${CLR}/c2's ge-t15 record 'Energy supply per person was about 38 GJ in 2005 and about 5.5 GJ in 2025.' (wrong; about 42 GJ) gets geography-table-derived-4 ENTAILED with no finding while the correct 'about 42 GJ in 2025' gets a COUNTEREXAMPLE and INT-SUBJ-004. If it reproduces it is a wrong result shown as checked: fix it at the cause (no function word or stop word ever names a row; a row is named only by its distinctive words), pin both twins, and sweep every row and column lookup of geography.py and language_b.py for the same fallback. Report the reproduction either way. (2) The branch misses the record names (reason 5): the Spanish share of a total is never checked on language_b ('El 25 % de 80 es 30.'); 10 of 14 faulty Geography and Language B near variants (ge-p9c, sp-t16, sp-t14, ge-t16; listed in ${PCLENSES}) draw no finding. (3) The c3d leftovers in your paths (${C3D_LEFT}). Each fix by class with its faulty and correct twins pinned; run ${PY} ${REPO}/scripts/arena/run_arena.py on COPIES (under ${OUT}/) of ${CLR}/c1, ${CLR}/c2 and ${C3}: no functional count may drop (c1 203/203, c2 188/188, c3 164/176).` },
  { key: 'overseer', task: `You own overseer/** (src and tests). (1) The transfer auditor's OVS-FID-004 still names the wording an answer's own correction replaces (an arrow, a double arrow, 'should be', 'becomes', 'rather than', 'instead of', 'Wrong:/Right:', one word) on the ll-t16 record, so an honest receipt gets AUDIT_FAILED (the c3d overseer fixer left this with patches: ${C3D_LEFT}). The auditor must agree with the channel's own-text reader: call src/epinoic_logic/adapters/own_text.py (owned by the channel fixer this run; call it, never copy it), and pin each correction form. (2) Any other open overseer item in ${C3D_LEFT} or in the push check's lists (${PCLENSES}) that names an overseer path.` },
]
const fixRes = await parallel(FIXERS.map(f => () => agent(`${DCTX}\n${SELFCERT_CLASS}\nYou are FIXER "${f.key}" of this run. ${f.task}\n__FIX_RULES__${RESTARTS('c3e-' + f.key)}`, { label: `fix:c3e:${f.key}`, phase: 'Fix', schema: FIX_SCHEMA, effort: 'high' })))
const fixed = fixRes.filter(Boolean).flatMap(r => r.fixed || [])
log(`fix: ${fixed.length} fixed (${FIXERS.map((f, i) => `${f.key} ${fixRes[i] ? (fixRes[i].fixed || []).length : 'no result'}`).join(', ')})`)

// ------------------------------------------------------------------ Check: phrasings, correct work, branches and a readings diff; one fixer
phase('Check')
const ROUND = 11 // continues the attack numbering
const LENSES = ATK.filter(l => l.key !== 'paths').concat([{ key: 'readings-diff', task: r => `Compare every recorded answer's readings between HEAD (git -C ${REPO} archive HEAD into ${OUT}/attack-${r}/head/, run with that tree's src first on the path) and the working tree. For every record of ${CLR}/c1, ${CLR}/c2, ${C3} and ${ARENA}/r1 to r7 (on COPIES under ${OUT}/attack-${r}/), run the same pipeline on both trees and list every claim whose check status (ENTAILED, COUNTEREXAMPLE, NOT_ELIGIBLE and the rest), findings, receipt codes or delivery decision differ. Classify each difference as an intended fix (name the item of the push check or of this run it implements) or a regression (kind regression), and look hardest for a wrong figure that gains ENTAILED or loses a finding, and a correct figure that gains a COUNTEREXAMPLE or a finding.` }])
const chkRes = (await parallel(LENSES.map(l => () => agent(`${DCTX}
${SELFCERT_CLASS}
You are CHECK LENS "${l.key}" after this run's fixes (one round, numbered ${ROUND}). READ-ONLY on ${REPO}: never edit, stage or commit anything there; write probe scripts only under ${OUT}/attack-${ROUND}/ and run them with ${PY}. ${l.task(ROUND)} Also re-run every reproduction of the push check of 2be42c48 that belongs to your lens (${PCF} and the lists in ${PCLENSES}) and report each that still reproduces. Word-count lines (D7) and the mark-allocation pins stay as they are: never report them. Report in reproduced ONLY what you reproduced on the current working tree, each with the exact input, the branch, the path, what happened, what must happen and the kind (miss, false_positive, fail_open, stall, regression); in checked, what you tried (counts per branch and path) and the measured rates.`, { label: `check:${l.key}:c3e`, phase: 'Check', schema: ATTACK_SCHEMA, effort: 'high' })))).filter(Boolean)
const open = chkRes.flatMap(a => (a.reproduced || []).map(x => Object.assign({ lens: a.lens || '' }, x)))
log(`check round ${ROUND}: ${open.length} reproduced (${chkRes.map(a => `${a.lens || '?'} ${(a.reproduced || []).length}`).join(', ')})`)
// (22 Nov 08:1x, resumed run) the fixers' left_undone goes to the check fixer in full: the overseer fixer's validated patches
// (its paths could not reach src/epinoic_logic/api) and the History reference-corpus pin failures would otherwise wait for a later round
const fixLeft = [].concat(...fixRes.filter(Boolean).map(r => r.left_undone || []))
let fChk = null
if (open.length || fixLeft.length) {
  const openJson = JSON.stringify(open)
  if (openJson.length > 150000) log(`check fixer sees the first 150000 of ${openJson.length} characters of the reproduced list`)
  const leftJson = JSON.stringify(fixLeft.map(x => clip(typeof x === 'string' ? x : JSON.stringify(x), 3000)))
  log(`check fixer gets ${open.length} reproduced items and ${fixLeft.length} fixer leftovers (${leftJson.length} characters)`)
  fChk = await agent(`${DCTX}
${SELFCERT_CLASS}
You are the CHECK FIXER of this run. You may edit any path; the design files are ${C3B}/selfcert-design.md and ${C3B}/d9d10-design.md. The check lenses reproduced these on the working tree: ${openJson.slice(0, 150000)}
The four fixers of this run left these items (their left_undone, each clipped at 3000 characters; their progress files are ${OUT}/progress-c3e-*.md): ${leftJson}
Priorities: (1) every regression (above all a wrong result shown as checked or a correct one charged), false positive (correct work gated), fail_open and stall, and every item of the push check of 2be42c48 that still reproduces; (2) the fixers' leftovers that need no owner decision: (a) the overseer fixer's two validated patches for OVS-FID-004 on the wording an answer's own correction replaces (${OUT}/overseer/c3e-item1-translator-api.patch and ${OUT}/overseer/c3e-item1-overseer.patch): review both, then git apply --check and git apply them TOGETHER in ${REPO} (an additive export in epinoic_logic.api with API_VERSION 1.3 and docs/PUBLIC_API.md regenerated with the repository's own generator), and run overseer/tests/overseer_tests/test_c3e_own_correction.py, the related overseer tests and tests/integration/test_overseer_subproject.py; (b) the two History reference-corpus failures on the working tree (tests/branches/test_quant_si_reading.py::test_general_reading_is_byte_identical_on_the_reference_corpus and tests/branches/test_c1_clearance_parsers.py::test_the_re_referenced_corpus_text_differs_by_the_fell_x_per_cent_rule_alone: the History item '## Point The Depression was decisive because ...' changes its parse, CorePack or self-report digest; the branches fixer's evidence is ${OUT}/branches/dig.py): find which change caused it; an unintended change is fixed at its cause, and a pin moves only when the new reading is shown to be the right one and the test says so; (c) the handed-off reader items (in a feedback task the English parser drops the labelled list lines '- Wrong: "x"' over '- Right: "y"'; 'Use "y", not "x"' is not read as the writer's correction), each with faulty and correct twins pinned; leave the items a fixer marked as the owner's decision, pre-existing by design, or a meaning reading; (3) the branch misses; (4) misses of the self-certification class, by class only and only if no false positive is added (re-run the development sets and the recorded genuine answers). Fix each at its cause; add a regression test for each with its expected value fixed in the test. NEVER read ${C3B}/heldout/. Never weaken or delete a test (rewriting one to a stricter rule is allowed; say so). Validate with the targeted test directories and the development sets; do not run the full suite. Return every change in fixed and anything not done in left_undone with the reason.${RESTARTS('c3e-check')}`, { label: 'fix:c3e:check', phase: 'Check', schema: FIX_SCHEMA, effort: 'high' })
}

// ------------------------------------------------------------------ Verify and commit
phase('Verify')
const allFixed = [].concat(fixed, (fChk && fChk.fixed) || [])
const leftAll = [].concat(fixLeft, (fChk && fChk.left_undone) || [])
const body = `Follow-up to 2be42c4, whose independent push check held it. Fixes its items that need no owner decision: near variants of items reported fixed (misspelt check words outside a check frame, a reversed label line, outside authorities credited with reviewing the answer), the judge-reproduced misses by class, the own-wording quotation frames that still lost their error (task, teacher, heading and instruction frames are checked against the task), the over-blocks it names (Language B correction pairs, the French gloss, the Spanish worked check), branch misses, the version discipline of eligibility rule 0 (the rules digest now covers the rule's code), and open items of the last run. The self-certification class itself stays open pending the owner's decision on a meaning check; word-count lines stay gated under decision D7 and the mark-allocation pins stay as they are pending the owner. No status line on answers and no documented limitation.
Check round after the fixes: ${open.length} reproduced.
Changes:
${clipFixed(allFixed, 7000)}`
const vc = await verifyAndCommit([C3], 'Fix the c3 clearance findings', body, 'clearance-c3e', 'Verify')
const sha = vc.commit && vc.commit.committed ? vc.commit.sha : null

return {
  fixed: allFixed.length,
  fixed_by: FIXERS.map((f, i) => `${f.key}: ${fixRes[i] ? (fixRes[i].fixed || []).length : 'no result'}`),
  left_undone: leftAll.map(x => clip(x, 300)),
  check_open: open.map(o => clip(`${o.lens}: ${o.kind || ''} ${o.branch || ''} ${o.input}`, 240)),
  verified: vc.green,
  harness: vc.v ? vc.v.harness_line : null,
  suite: vc.v ? suiteLine(vc.v.suite_tail) : null,
  commit: sha,
  pushed: !!(vc.commit && vc.commit.pushed),
}
"""
BODY = BODY.replace('__FIX_RULES__', FIX_RULES)
out = META + '\n// Constants, schemas, the class/boundary definitions, the verification and commit helpers and the lenses: copied from wf-scripts/fix-c3c.js by make_fix_c3d.py (with the asserted replacements listed there).\n' + '\n'.join(block.split('\n')[1:]) + '\n' + BODY
open(OUT_JS, 'w', encoding='utf-8').write(out)
print('wrote', OUT_JS, len(out), 'chars')
