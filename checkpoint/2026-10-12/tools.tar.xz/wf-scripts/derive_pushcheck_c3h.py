#!/usr/bin/env python3
"""Derive wf-scripts/make_pushcheck_c3h.py from make_pushcheck_c3g.py by asserted replacements (24 Nov).

Ten held commits (67bc64ec added); the context names what follow-up 6 (narrow, fail closed) aims at, taken from the
push-check record of 67bc64ec and the fixer tasks of fix-c3h, and the boundary lines its fixers were given; the
critical-fixes, infected, weakened, branches-policy and readings-diff lenses name 67bc64ec's items; labels and restart
files are c3h. Nothing in the lenses' standards, the challenger or the judge's hold rule is relaxed.

Usage: python3 -I derive_pushcheck_c3h.py wf-scripts/make_pushcheck_c3g.py wf-scripts/make_pushcheck_c3h.py
"""
import sys

SRC, OUT = sys.argv[1], sys.argv[2]
s = open(SRC, encoding='utf-8').read()


def rep(old, new, count=1):
    global s
    n = s.count(old)
    assert n == count, (old[:100], n)
    s = s.replace(old, new)


rep('"""Build wf-scripts/pushcheck-c3g.js: the independent push check of the fix-c3g follow-up commit (follow-up 5).\n',
    '"""Build wf-scripts/pushcheck-c3h.js: the independent push check of the fix-c3h follow-up commit (follow-up 6).\n\n'
    'Derived from make_pushcheck_c3g.py by derive_pushcheck_c3h.py (24 Nov): ten held commits (67bc64ec added), the context\n'
    'names what follow-up 6 (narrow, fail closed) aims at and the boundary lines its fixers were given, and the lenses name\n'
    '67bc64ec\'s items.\n')
rep("name: 'translator-pushcheck-c3g'", "name: 'translator-pushcheck-c3h'")
rep("Independent push check of the fix-c3g follow-up commit (args.sha)", "Independent push check of the fix-c3h follow-up commit (args.sha)")
rep("// ================================================================== Independent push check of follow-up 5 (pushcheck-c3g)",
    "// ================================================================== Independent push check of follow-up 6 (pushcheck-c3h)")
rep("const PREV = '08c4a36b9d68885aac6bb81840d127c65a0ed409'", "const PREV = '67bc64ec336f87c641a83fd51eff8c8d521212f7'")
rep("'a9129c78de9fdcdb6d93a42a2e08ae413d7b1cd0', PREV]",
    "'a9129c78de9fdcdb6d93a42a2e08ae413d7b1cd0', '08c4a36b9d68885aac6bb81840d127c65a0ed409', PREV]")
rep("const PCO = `${WF2}/c3g/push-check`", "const PCO = `${WF2}/c3h/push-check`")

# the context paragraph: what this follow-up aims at
i = s.index('PUSH CHECK of ${SHA} (subject "Fix the c3 clearance findings": follow-up 5, after 08c4a36b).')
j = s.index(' Verify each of those claims yourself;', i)
NEW_PCX = (
    'PUSH CHECK of ${SHA} (subject "Fix the c3 clearance findings": follow-up 6, after 67bc64ec). It follows ten HELD commits, '
    'oldest first: ${HELD_LIST}; read all ten push checks whole (the last one, of 67bc64ec, names what held it, and its lenses\' '
    'and challenger\'s lists are in ${WF2}/c3h/pushcheck-67bc64e-lenses.json). The owner (16 Nov) asked for everything that holds '
    'them to be resolved: the self-certification class closed by meaning (no status line, no documented limitation), the '
    'POLICY_VERSION bump for eligibility rule 0, the Geography and Language B branches (D9/D10) and round 10\'s open items. The '
    'follow-ups af6dfe04, 2be42c48, a9129c78, 08c4a36b and 67bc64ec fixed the holds of the commit before them that need no owner '
    'decision and were each held. This follow-up is NARROW and was run under a fail-closed remedy rule: it aims only at the holds '
    'of 67bc64ec that need no owner decision and that 67bc64ec introduced or left failing open; it does not widen the '
    'self-certification reader for new misses, fix over-blocks or take up leftovers of earlier runs. Its aims: the wrong Geography '
    'figure 67bc64ec shows as ENTAILED (on c2/ge-t15 \'Coal, which supplied about 42 GJ per person in 2025, declined.\' ENTAILED '
    'and its correct 11.8 GJ twin charged), with the pre-existing forms of the same insertion class (\'Oil (about 42 GJ per person '
    'in 2025) changed least.\', a dash pair, an \'at ...\' phrase, a participle phrase, a \'whose\' clause), where a figure inside '
    'an insertion is read against the noun the insertion attaches to or gets no check; the gate regressions 67bc64ec introduced, '
    'reverted to the reading of 08c4a36b (the correction-pair key on the answer\'s own values: \'Wrong: x = 3. Right: x = 4.\', '
    '\'Wrong: 1918. Right: 1919.\', \'Mal: x = 5. Bien: x = 7.\'; the possibility frame: \'Every figure in this answer can be '
    'confirmed.\', \'Everything in this response can be verified.\'); the fail-open readings (one long report-opened and-joined '
    'sentence around \', which the examiner graded as flawless,\' from 8.1 KB and the Keynes-opened form from 9.1 KB; '
    'reader._credit_pieces stopping after 64 evaluator pieces with no notice); the D-a year leak (\'The values in this answer agree '
    'with the 2022 dataset.\', \'All the numbers here match the 2021 dataset.\', \'Todas las cifras coinciden con la encuesta de '
    '2019.\'); D-e (\'Nº de palabras: 87\', \'Words used — 312\', \'Cuenta de palabras: 198\'); the Language B year and count '
    'checks lost on labelled correction lines (on c1/sp-t14 \'Incorrecto: la escuela cerró en 1990. Correcto: la escuela cerró '
    'en 1975.\'); and the version bump for these rule changes (POLICY_VERSION 2026.11-v8, SELFCERT_RULES selfcert-4, contract 0.9, '
    'the kit regenerated with the repository\'s tools). The remedy rule accepted that a correct line an exemption of 67bc64ec had '
    'freed may be withheld again (for example \'If the reader wishes, the values can be confirmed with a calculator.\'): report '
    'every such line with its rate, and decide under the hold rule below whether it holds. Its fixers were given these boundary '
    'lines, taken from the records of the push checks of a9129c78, 08c4a36b and 67bc64ec, as decided: (D-a) agreement of the '
    'answer\'s figures with a data source is boundary (b) only when the source is named or a value it gives is stated; an unnamed '
    '"the dataset", "the census" or "the survey" with no stated value is an own-scope verification claim and is gated, and a year, '
    'a date or a number alone never names a source (\'the 2021 dataset\' is unnamed; \'the ONS 2021 dataset\' is named); (D-b) a '
    'tick or approval on language use is free only in a marking or feedback task; (D-c) a restated question with its mark '
    'allocation is task text and free; (D-d) a neutral check key or a tick right after a computation frees only the computation it '
    'shows, and a verdict wider than that computation, or one that credits an evaluator, is a self-report; (D-e) decision D7 is '
    'applied evenly to every word-count form. Judge the code against these lines as decided; if you think a line itself is wrongly '
    'decided, say so as a separate observation for the owner.')
s = s[:i] + NEW_PCX + s[j:]

rep("as the judges of a9129c78 and 08c4a36b recorded, a miss that the decided boundary already gates is a code defect whose hold does not depend on that decision",
    "as the judges of a9129c78, 08c4a36b and 67bc64ec recorded, a miss that the decided boundary already gates is a code defect whose hold does not depend on that decision")
rep("this follow-up applies D7 evenly, so report any word-count form that still escapes it, such as 'Número de palabras: 42' did)",
    "this follow-up applies D7 evenly, so report any word-count form that still escapes it, as 'Nº de palabras: 87', 'Words used "
    "— 312' and 'Cuenta de palabras: 198' did at 67bc64ec)")
rep("and the mark-allocation pins ('A1 A1', '∎'), which stay as they are pending the owner's confirmation.",
    "and the mark-allocation pins ('A1 A1', '∎', and the mark-scheme legend '✓ = 1 mark for a correct method in the mark "
    "scheme.'), which stay as they are pending the owner's confirmation.")

# critical-fixes lens
rep("Check every item of the nine held checks' critical_open", "Check every item of the ten held checks' critical_open")
rep("each with a reproduction that fails on the held commit 08c4a36b (or the earliest held commit",
    "each with a reproduction that fails on the held commit 67bc64ec (or the earliest held commit")
i = s.index("include the regressions 08c4a36b introduced against their boundary lines (")
j = s.index("and the replay worker", i)
NEW_REG = (
    "include the regressions 67bc64ec introduced, each against the reading of 08c4a36b (the correction-pair key on the answer's "
    "own values: 'Wrong: x = 3. Right: x = 4.', 'Wrong: 1918. Right: 1919.' and 'Mal: x = 5. Bien: x = 7.' are gated, while the "
    "quoted language pair 'Wrong: \"I has went\". Right: \"I have gone\".' stays free; the possibility frame: 'Every figure in "
    "this answer can be confirmed.' and 'Everything in this response can be verified.' are gated), the D-a and D-e lines (an "
    "unnamed source with a year, 'The values in this answer agree with the 2022 dataset.', 'All the numbers here match the 2021 "
    "dataset.', 'Every figure here matches the 2019 report.' and 'Todas las cifras coinciden con la encuesta de 2019.', is gated, "
    "while a named source or a stated value, 'The ONS confirmed the figures.', 'This matches the ONS 2021 dataset.' or 'This "
    "matches the census figure of 4.2 million.', stays free; 'Nº de palabras: 87', 'Words used — 312' and 'Cuenta de palabras: "
    "198' read as D7 reads 'Palabras: 25'), the fixes of 67bc64ec that must stay fixed ('All the numbers here match the "
    "dataset.' gated; '✓ Correct use of the subjunctive: «espero que vengas».' free only in a marking or feedback task; "
    "'Question 5 [4 marks]: Solve 2x + 3 = 11.', 'Prueba: si la base es 60, el 50 % es 30.' and 'This calculation checks out: 8 × "
    "9 = 72.' delivered: report any of them withheld again), the own-verdict reading in one long and-joined sentence opened by a "
    "report ('Taylor argued that ...' with ', which a second agent checked line by line,' or ', all verified by the hub,', and "
    "'Keynes wrote that the Treaty of Versailles was signed in 1919 and ...' with ', which the examiner graded as flawless,') at "
    "about 380 characters and at 6, 8.1, 9.1, 12 and 20 KB (it must read True at every length, with selfcert and meta_notes "
    "agreeing), the credited evaluator pieces (a credited check after N = 30, 63, 64, 65 and 500 benign examiner pieces must read "
    "True at every N or fail closed with a named finding), the channel's blockquote check (an altered task sentence after 0, 63, "
    "64 and 200 benign blockquote blocks, and inside one 2,321-character block, must each be named or fail closed with a named "
    "finding), ")
s = s[:i] + NEW_REG + s[j:]

# infected and weakened lenses
rep("and closely the diff 08c4a36b..${SHA}, for anything malicious", "and closely the diff 67bc64ec..${SHA}, for anything malicious")
rep("and closely in 08c4a36b..${SHA}; for each decide", "and closely in 67bc64ec..${SHA}; for each decide")
rep("Two pin moves are expected in this follow-up and are not weakenings when the new pin is exact: the OVER_BLOCKS pins of 'Every "
    "figure here matches the census.' and 'Las cifras coinciden con el censo.' move to gated (a stricter rewrite under boundary "
    "line D-a), and the version pins move to 2026.11-v7, selfcert-3 and contract 0.8.",
    "Pin moves expected in this follow-up, which are not weakenings when the new pin is exact: the correction-pair forms on the "
    "answer's own values and the two possibility-frame assurances move to gated (reverts to the reading of 08c4a36b), and a "
    "correct line those exemptions had freed may move to withheld (fail closed: report it); the year-named sources and the "
    "word-count forms move to gated; the Geography insertion figures move from ENTAILED to a COUNTEREXAMPLE or no check; the "
    "Language B labelled correction line regains its checks; and the version pins move to 2026.11-v8, selfcert-4 and contract "
    "0.9. Report every pin that moves from gated to delivered, from a finding to no finding, or from checked to unchecked, and "
    "decide whether it hides a failure; check in particular that no timing bound or timing helper changed in 67bc64ec..${SHA}.")

# branches-policy lens: the row and column lookups, the Language B labelled lines, the version bump
i = s.index("the row and column lookups of the Geography and Language B packs (only the subject noun phrase of the figure's own clause names a row or a column;")
j = s.index("sweep other rows and columns the same way,", i)
NEW_ROWS = (
    "the row and column lookups of the Geography and Language B packs (only the subject noun phrase of the figure's own clause "
    "names a row or a column, and a figure inside an insertion (a relative clause, a bracket, a dash pair, an 'at ...' phrase, a "
    "participle phrase or a 'whose' clause) belongs to the noun the insertion attaches to and is checked against that noun's row, "
    "or gets no check when that row is not determined: never ENTAILED and never a charge on a correct twin; on c2/ge-t15 (true "
    "2025 per-person figures: total 42.2 GJ, coal 11.8 GJ) 'Coal, which supplied about 42 GJ per person in 2025, declined.', "
    "'Oil (about 42 GJ per person in 2025) changed least.', 'Coal — about 42 GJ per person in 2025 — mattered.' and 'Natural gas, "
    "at about 42 GJ per person in 2025, mattered.' must not be ENTAILED, and the correct coal twin ('Coal, which supplied about "
    "11.8 GJ per person in 2025, declined.') must not draw a COUNTEREXAMPLE or a finding; build the grid yourself (each insertion "
    "form for every row, faulty and correct twins, on ge-t15 and ge-t14): every wrong cell gets a COUNTEREXAMPLE or no check and "
    "every correct cell no finding; the cases fixed before stay fixed (on c2/ge-t15 'Energy supply per person, while coal "
    "declined, was about 11.8 GJ in 2025.' is not ENTAILED and its 42 GJ twin is clean, as are 'with natural growth', 'as nuclear "
    "capacity grew', 'despite oil prices', 'after coal declined' and \"Each person's share of energy supply was about 22.8 GJ in "
    "2025.\"; on c1/ge-t14 'The pedestrian count, as retail use fell, was 60 at site 4.' (true 97) and 'At site 2 the EQS, with "
    "pedestrian numbers high, was 186.' (true 22) are not ENTAILED and their correct twins are clean; on c1/sp-t14 the school "
    "reopened with catorce alumnos and 'más de cien' is the 1960 figure, so '6. Al reabrir, la escuela acogió a cien alumnos.' "
    "and its variants are not ENTAILED, a check that accepts either of two differing figures is no check, and '6. En 1960 la "
    "escuela tenía catorce alumnos.' stays not ENTAILED; on c3/sp-t16 the faulty 'El intercambio, según la consigna, duró dos "
    "semanas.' is named with its correct twin clean); the Language B labelled correction lines (on c1/sp-t14 'Incorrecto: la "
    "escuela cerró en 1990. Correcto: la escuela cerró en 1975.' must regain the year checks it had at 08c4a36b, two "
    "COUNTEREXAMPLEs plus INT-SUBJ-004: the label pair decides only which half is the writer's correction, never whether its "
    "figures are checked; its correct twin must not be charged, and the correction-count fix of 67bc64ec stays); ")
s = s[:i] + NEW_ROWS + s[j:]
rep("super-linear growth is a stall)",
    "super-linear growth is a stall; time branches/insertions.py and the Language B labelled-line reading the same way on nested "
    "and repeated insertions and labels up to 200 kB)")
rep("and the version discipline of eligibility rule 0 and the POLICY_VERSION (this follow-up makes the bump the last two checks "
    "found missing: POLICY_VERSION 2026.11-v7 with its history entry, SELFCERT_RULES selfcert-3, the contract 0.8 under "
    "docs/integration-contract.md section 11, integration/COMPATIBILITY.json accepting only the new versions, and the kit "
    "regenerated with the repository's own tools: check each, and that a result signed at 08c4a36b is refused by release_check "
    "as stale at ${SHA} and never displayed as a verdict; version.py and its history;",
    "and the version discipline of eligibility rule 0 and the POLICY_VERSION (this follow-up bumps the versions for its rule "
    "changes: POLICY_VERSION 2026.11-v8 with its history entry, SELFCERT_RULES selfcert-4, the contract 0.9 under "
    "docs/integration-contract.md section 11, integration/COMPATIBILITY.json accepting only the new versions, and the kit "
    "regenerated with the repository's own tools: check each, and that a result signed at 67bc64ec (policy 2026.11-v7) is "
    "refused by release_check as stale at ${SHA} and never displayed as a verdict; version.py and its history;")

# readings-diff lens
rep("between the held commit 08c4a36b and ${SHA}:", "between the held commit 67bc64ec and ${SHA}:")
rep("(name the item of 08c4a36b's push check,", "(name the item of 67bc64ec's push check,")

# labels, restart files, judge
rep("RESTARTS('pushcheck-c3g-' + l.key)", "RESTARTS('pushcheck-c3h-' + l.key)")
rep("label: `push-check-lens:${l.key}:c3g`", "label: `push-check-lens:${l.key}:c3h`")
rep("RESTARTS('pushcheck-c3g-challenger')", "RESTARTS('pushcheck-c3h-challenger')")
rep("label: 'push-check-challenge:c3g'", "label: 'push-check-challenge:c3h'")
rep("label: 'push-check:c3g'", "label: 'push-check:c3h'")
rep("(every item of the nine held checks' critical_open,", "(every item of the ten held checks' critical_open,")
rep("copied verbatim from wf-scripts/fix-c3c.js by make_pushcheck_c3g.py.", "copied verbatim from wf-scripts/fix-c3c.js by make_pushcheck_c3h.py.")

body = s.split('"""', 2)[2]
for bad in ('c3g', 'follow-up 5', 'nine held', 'nine push', '08c4a36b introduced', '2026.11-v7 with its history', 'selfcert-3, the contract',
            'contract 0.8', 'held commit 08c4a36b'):
    assert bad not in body, bad
assert '"""' not in NEW_PCX + NEW_ROWS + NEW_REG
open(OUT, 'w', encoding='utf-8').write(s)
print('wrote', OUT, len(s), 'chars')
