export const meta = {
  name: 'argdiag-regression-closure',
  description: 'Argument diagnostics after its last repair round: classify every open issue against the committed base, close only the regressions and security issues the staged changes introduced, verify differentially (nothing is committed)',
  phases: [
    { title: 'Triage', detail: 'run every round-6 issue and the repair-5 false alarms on the committed base and on the staged tree: regression, security, gap, improved or not reproduced' },
    { title: 'Close', detail: 'fix every regression and security issue at its cause (narrow or revert the new reading); measure once' },
    { title: 'Verify', detail: 'differential lens (staged against base on every repro, both corpora, the arena receipts and new probes) and the invariants lens' },
  ],
}
