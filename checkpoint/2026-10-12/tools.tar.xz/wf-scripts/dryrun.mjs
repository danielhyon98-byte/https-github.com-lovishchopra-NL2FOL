// offline dry run: stub agent()/parallel(); print each agent's label and prompt (or a slice)
import fs from 'fs'
const src = fs.readFileSync(process.argv[2], 'utf8').replace(/^export const meta/m, 'const meta')
const args = JSON.parse(process.argv[3] || '{}')
const show = process.argv[4] || ''
const prompts = []
const agent = async (p, o) => { prompts.push([o && o.label, p]); return { lens: (o && o.label) || '', hold_recommended: true, items: ['i'], critical_open: ['c1 from ' + ((o && o.label) || '')], hold: true, reasons: ['r'], supersedes: [], accounted: ['a'] } }
const parallel = async ts => Promise.all(ts.map(t => t()))
const f = new Function('agent', 'parallel', 'pipeline', 'phase', 'log', 'args', 'budget', 'workflow', `return (async () => {\n${src}\n})()`)
const r = await f(agent, parallel, null, () => {}, m => console.log('LOG', m), args, { total: null }, null)
for (const [l, p] of prompts) { console.log('=== ' + l + ' (' + p.length + ' chars)'); if (show && l && l.includes(show)) console.log(p) }
console.log('RETURN', JSON.stringify(r).slice(0, 800))
