export const meta = {
  name: 'c3l-s5',
  description: 'Stage 2b S5: scratch glue part 2 (five tools with their fixed tests), independent review and fix, then the dry run with the committed tools and faithful replies, and an independent check',
  phases: [
    { title: 'Glue', detail: 'one writer: faithful_replies, merge_gate, usage_fit, heldout_step, make_report' },
    { title: 'Review', detail: 'independent review; fixer if needed (at most two rounds)' },
    { title: 'Dry run', detail: 'one operator, scripts only, no recording agent' },
    { title: 'Check', detail: 'one independent check' },
  ],
}

const S = '/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad'
const MC = `${S}/wf/phase2/meaning-check`
const C = `${S}/wf/phase2/c3l`
const PY = `${S}/z3venv/bin/python -I`
const R = '/home/user/https-github.com-lovishchopra-NL2FOL'
const WF = '/root/.claude/projects/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/subagents/workflows'
const COMMIT = args && args.commit
if (!COMMIT || !/^[0-9a-f]{40}$/.test(COMMIT)) throw new Error('args.commit must be the full fix-c3l commit id')

const COMMON = `Stage 2b of the meaning check (plan ${MC}/stage2b-plan.md). Read the rulings ${MC}/stage2b-rulings.md in full first
(R-1 to R-20). C = ${C}; R = ${R} (the repository checkout); python: ${PY} -B (repository tools run from R). The fix-c3l commit
is ${COMMIT}. Scratch tools and their tests: ${C}/tools and ${C}/tools/tests (run them with ${PY} -B -m pytest -q
${C}/tools/tests -p no:cacheprovider).
Rules:
- Never modify anything under R (only read-only git). Preconditions (ruling R-19): git -C R diff --name-only ${COMMIT} HEAD and
  git -C R status --short --untracked-files=no list nothing or only tests/README.md; otherwise stop and say so.
- Never open, list, count or glob ${S}/wf/phase2/c3b/heldout/ or ${C}/ho-sealed/ or any held-out-suspect file (plan D13 names).
  heldout_step.py is written and tested on synthetic stand-in data in a temporary directory only; it is never run on the real
  held-out set (that is S14, M-HO).
- NEVER run a recursive command (grep -r, find, ls -R, du, rsync, glob with **, os.walk, rglob) over ${S}/wf or any parent of the
  held-out directory; name files and directories explicitly.
- No agent reads a key file (plan D2): never cat, print, copy or open ${C}/keys/*.key; pass --key-file to the tools that take it.
  No tool you write prints key bytes.
- Never launch a workflow or an agent, never send a message, never write under /root/.claude/, never run the repository suite,
  run_arena or any provider call; no network connection.
- Print and return counts and ids only, never a row's text or a reply's text; files holding text are mode 0600.`

const GLUE = `${COMMON}

Write the part-2 scratch glue of plan section 3.5 (the table "Part 2 (S5)"), against the committed tools at ${COMMIT}:
faithful_replies.py, merge_gate.py (interface I14), usage_fit.py (section 9.3), heldout_step.py (section 8.5 and D12: prepare,
extract, bind, retries, measure and gate; counts only; on any error an error class and counts) and make_report.py (section 8.6),
each in ${C}/tools with its fixed tests in ${C}/tools/tests: every fixed test the table names, exactly as worded, plus tests of
each tool's error paths. Read first: plan 3.5 (both parts), I14, 8.5, 8.6, 9.3, D2, D12, D19, Appendix C; the committed tools they
call or mirror (scripts/arena/bind_labels.py, list_row_labels.py, convert_rows.py, measure_labels.py, label_freeze.py,
overseer/scripts/gate_paths.py, integration/sim/gate_service_turn.py), read at ${COMMIT}; and the part-1 glue (s0b_common.py,
keygen.py, keyscan.py, parse_rows.py) for its conventions. heldout_step.py's measure command must equal 8.5 step 4's flag for
flag. Also, by ruling R-20.1: the recording glue binds a reply to request key K only when the bytes of the input file the
recorder received (verified from its transcript by parse_rows) equal the listing's rendered request for K; add that check
where the glue writes replies for binding (parse_rows.py's recorder mode or the tool that writes C/replies), refusing a planted
misfile (a reply whose input file belongs to another key) for a re-ask, with a fixed test. Run the whole scratch test suite at
the end; every test must pass. Return at most 20 lines: the files written, the tests
per tool, the suite's counts, anything the plan left open and how you settled it.`

const REVIEW = (prev) => `${COMMON}

REVIEW (edit nothing) the part-2 glue just written in ${C}/tools against plan 3.5's table "Part 2 (S5)", I14, 8.5, 8.6, 9.3, D2
and D12. Check: every fixed test of the table is present, matches its wording and cannot pass vacuously; heldout_step.py prints
counts only (no row text in stdout or stderr, also on errors), writes only inside its sealed directory, and builds 8.5 step 4's
measure command flag for flag; merge_gate.py outputs ids and counts only (--counts-only: counts only) and counts a row withheld on
one path and allowed on another as a disagreement; usage_fit.py's rate and band match a hand computation; faithful_replies.py
answers with ReaderBackedLabeller; no tool reads or prints key bytes or opens a connection; the error paths are tested. Run the
scratch suite. Writer's summary: <<<${prev}>>>
Return JSON only: {"findings":[{"severity":"blocking|major|minor","tool":"...","what":"...","evidence":"...","fix":"..."}],"suite":"..."}`

const FIX = (findings) => `${COMMON}

FIX these review findings in the part-2 glue (${C}/tools and ${C}/tools/tests only), each with a test that fails before the fix
where one can; then run the whole scratch suite (every test must pass). Findings: <<<${findings}>>>
Return at most 15 lines: each finding fixed or why not, and the suite's counts.`

const DRY = `${COMMON}

The S5 DRY RUN (plan S5 row, 3.5's last paragraph, D19, 6.6, 6.13; no recording agent). Write everything under ${C}/dryrun/ and
record every command, exit code and count in ${C}/dryrun/S5.md.
0. Preconditions; scripts/arena/label_freeze.py --check ${C}/freeze.json must exit 0 (any other exit: stop and report it).
1. List the dev gate with the committed tools as 6.13 says (convert_rows.py --alone on tests/selfcert/data/dev-{positive,negative}.jsonl;
   list_row_labels.py --only-reader-passes --key-file ${C}/keys/measure.key), into ${C}/dryrun/requests/dev_gate/: report the
   requests listed (6.13 expects 213, the negatives) and the reader-refused rows.
2. faithful_replies.py answers those rendered requests; bind_labels.py binds them as 6.6 shows, into ${C}/dryrun/labels/dev_gate/
   (the dry run's own model digest and adapter as the tools require for faithful replies; say which).
3. Run overseer/scripts/gate_paths.py (paths 1-6) and integration/sim/gate_service_turn.py (path 7) on those rows twice: with
   --labeller recorded over the bound labels, and with --labeller faithful; write each run's --states files; merge each with
   merge_gate.py. Required: 0 not-recorded on every path; the recorded run's per-path counts equal the faithful run's; 0 path
   disagreements between the two runs row by row. Per-path denominators as D19 states them for these rows.
4. Replay: the bound labels served and re-validated equal the faithful replies, request key by request key (count of equal,
   differing, missing).
5. Ruling R-20.1: plant one misfiled reply (a faithful reply whose input file belongs to another request key) in a copy of the
   replies and confirm the glue refuses to bind it (named for a re-ask) while every other reply binds.
Return at most 20 lines: preconditions, the listing, the binding, the per-path table for both runs, the replay comparison and
every problem.`

const CHECK = (dry) => `${COMMON}

CHECK of the S5 dry run (edit nothing outside your own scratch directory ${C}/dryrun/check/). Independently: the preconditions and
label_freeze.py --check; recount the dev-gate listing from ${C}/dryrun/requests/dev_gate (requests, keys distinct); re-run the two
gate scripts' recorded runs into your scratch directory and compare their states with the operator's row by row; recompute the
per-path counts and denominators from the states files with code of your own; confirm 0 not-recorded on every path and the replay
comparison; run ${C}/tools/keyscan.py over ${C}/dryrun (it reads the key itself and prints only "found" or "not found"; you never
open the key file); and read the operator's transcript (the agent-*.jsonl beside the journal.jsonl
under ${WF} whose journal names the label operator:s5): no recursive command over ${S}/wf, no held-out path, no key file opened,
nothing written under R. Operator summary: <<<${dry}>>>
Return at most 15 lines: each problem with evidence, or "no problem" per item.`

phase('Glue')
const glue = await agent(GLUE, { label: 'glue:s5', phase: 'Glue' })

phase('Review')
let last = glue
const reviews = []
let blocked = null
for (let round = 1; round <= 3; round++) {
  const rv = await agent(REVIEW(last), { label: `review:s5:${round}`, phase: 'Review' })
  reviews.push(rv)
  let parsed = null
  try { parsed = JSON.parse(String(rv).slice(String(rv).indexOf('{'), String(rv).lastIndexOf('}') + 1)) } catch (e) { parsed = null }
  const open = parsed && Array.isArray(parsed.findings) ? parsed.findings.filter(f => round === 1 || f.severity !== 'minor') : null
  if (open && open.length === 0) break
  if (round === 3) { blocked = rv; break }
  last = await agent(FIX(open ? JSON.stringify(open) : String(rv)), { label: `fix:s5:${round}`, phase: 'Review' })
}
if (blocked) {
  log('review still open after two fixes: the dry run is not run')
  return { glue, reviews, last, blocked }
}

phase('Dry run')
const dry = await agent(DRY, { label: 'operator:s5', phase: 'Dry run' })

phase('Check')
const chk = await agent(CHECK(dry), { label: 'check:s5', phase: 'Check' })

return { glue, reviews, last, dry, chk }
