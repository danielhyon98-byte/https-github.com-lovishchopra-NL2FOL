export const meta = {
  name: 'c3l-s1ef',
  description: 'Stage 2b S1e (seen corpus at the fix commit, authoritative overlap, minimums, cap, final rows) and S1f (regression set); one operator and one independent check each',
  phases: [{ title: 'Operate', detail: 'two operators, scripts only' }, { title: 'Check', detail: 'one independent check per step' }],
}

const S = '/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad'
const MC = `${S}/wf/phase2/meaning-check`
const C = `${S}/wf/phase2/c3l`
const PY = `${S}/z3venv/bin/python -I`
const R = '/home/user/https-github.com-lovishchopra-NL2FOL'
const WF = '/root/.claude/projects/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/subagents/workflows'
const COMMIT = args && args.commit
if (!COMMIT || !/^[0-9a-f]{40}$/.test(COMMIT)) throw new Error('args.commit must be the full fix-c3l commit id')

const COMMON = `Stage 2b of the meaning check (plan ${MC}/stage2b-plan.md). Read the rulings ${MC}/stage2b-rulings.md in full first
(R-1 to R-20). C = ${C}; R = ${R} (the repository checkout, branch claude/z3-verification-engine-plan-nk3luq); python: ${PY}
(add -B to every call; repository tools run from R). The fix-c3l commit is ${COMMIT}: the step's tools are read at that commit.
Logs so far: ${C}/sets/S1c-final.md and ${C}/sets/S1d-ab.md (with its addendum). Scratch tools: ${C}/tools.
Rules:
- Never modify anything under R: no edit, and only read-only git (rev-parse, status, diff --name-only, show, ls-tree, cat-file).
- Preconditions: git -C R cat-file -e ${COMMIT} succeeds, and git -C R diff --name-only ${COMMIT} HEAD and git -C R status --short
  --untracked-files=no each list nothing or only tests/README.md (the hourly progress note). Otherwise stop and say so.
- Never open, list, count or glob ${S}/wf/phase2/c3b/heldout/ or ${C}/ho-sealed/, and never name or open a file that plan D13 or
  the skipped_heldout_suspect list of ${C}/seen/manifest.json names as held-out-suspect.
- NEVER run a recursive command (grep -r, find, ls -R, du, rsync, glob with **, os.walk, rglob) over ${S}/wf or any parent of the
  held-out directory; name files and directories explicitly.
- Never launch a workflow or an agent, never send a message, never write under /root/.claude/, never run the repository suite,
  run_arena, list_labels, run_sim or any provider call.
- Never print or return a row's text or a seen string: ids and counts only. Every file you write that holds row text is mode 0600.
- Never read a key file (${C}/keys/ or any *.key file; plan D2): no step here needs one.`

const E_OP = `${COMMON}

Step S1e (plan 4.3, 4.7, 4.9, D18; rulings R-14 to R-18). Record every command, exit code and count in ${C}/sets/S1e.md.
0. The preconditions above. Then confirm the inputs are unchanged since S1d: the 36 kept-row files ${C}/sets/overlap/<slot>.jsonl
   (the slots of S1c-final, not the .excluded or .report files) and ${C}/sets/seed, by sha256sum -c against the matching lines
   of ${C}/sets/s1d-work/ab/AFTER.sha256 (a needed file it does not list: record its SHA-256 now and say so).
1. Seen corpus (ruling R-18): ${C}/tools/build_seen.py --rev ${COMMIT} --out ${C}/seen/s1e/seen.jsonl (its manifest goes beside
   it; the tool is not changed). Then write ${C}/seen/s1e/union.jsonl: every distinct string of ${C}/seen/seen.jsonl, then of
   ${C}/seen/s1e/seen.jsonl, in that order, one bare JSON string per line. Record the three SHA-256s, both builds' revisions, the
   strings added and removed between the builds and the union's size.
2. D18 binding: every kept row's panel verdict equals the writer's expected value (S1d: A and B agree with the writer on all 1,259
   rows). Bind it as the written-row field judge = "agree" (convert_rows.py's written-row format) in a scratch copy under
   ${C}/sets/s1e/bound/ (one file per slot, mode 0600), joined through ${C}/sets/judge-chunks/alias-map.jsonl; the overlap files
   stay untouched. Confirm 1,259 rows bound, none missing, none extra.
3. The authoritative run: scripts/arena/check_sets.py over the bound files with --seen ${C}/seen/s1e/union.jsonl --cap 440
   --seed-file ${C}/sets/seed --out-rows ${C}/sets/s1e/kept.jsonl --report ${C}/sets/s1e/check_sets-report.json (chmod 600 the
   rows). Report by set and reason: rows in, overlap (a), contained (b), duplicate, kept, capped. For every row it excludes that
   S1c's overlap.py kept: its id, reason and cause (a string new in the S1e build, or the two tools reading rule (b) differently:
   then say exactly how). check_sets.py is authoritative (plan 4.7).
4. Minimums (plan 4.3) as check_sets.py reports them on the rows it keeps: each check with its figures. If one fails, stop here:
   write the shortfall (counts and quota items only) in the log and return it; launch nothing.
5. The cap: removed rows by set and subject (ids only, ${C}/sets/s1e/capped-ids.json; they go to 2c's seen sets). Run step 3's
   command again into ${C}/sets/s1e/repeat/ and confirm the same rows are kept and removed. Injection and prompt-aware are not
   capped.
6. Freezing (plan 4.9): scripts/arena/convert_rows.py writes ${C}/sets/final/<set>.jsonl from exactly the rows check_sets.py kept
   (split by the set it writes: it splits injection into injection_wholesale and injection_targeted; one file per set name, as
   embed_rows.py and list_row_labels.py read them at S9 and S10), chmod 600 each; then ${C}/sets/final/SHA256SUMS and sha256sum -c.
   Confirm per set: rows written equal rows kept, the row-id map (writer id to I6 id) is one to one and written to
   ${C}/sets/final/id-map.json (ids only, mode 0600), no id in two sets, every row has its request and judge fields.
Return at most 25 lines: preconditions; the seen corpus counts and hashes; the exclusion table; the newly excluded rows; the
minimums; the cap; the final files with SHA-256s and counts; every problem.`

const F_OP = `${COMMON}

Step S1f (plan D13 and 6.11; the regression set). Record every command, exit code and count in ${C}/regression/S1f.md (create
${C}/regression/).
0. The preconditions above.
1. Read scripts/arena/regression_rows.py at ${COMMIT} (its usage, the manifest format, its adapters) and its tests, plan D13, 6.11
   and the S1f row of the step table.
2. Write ${C}/regression/manifest.json listing every D13 source with its adapter and polarity field: attack rounds 1-14 structured
   inputs (an expected or kind field); the push-check probe sets (pos/neg); attack rounds 15-17 from the three pinned test files at
   ${COMMIT} (tests/selfcert_label/test_attack16.py, tests/selfcert/test_c3k_check_round.py, tests/selfcert/test_c3k_reader.py) by
   the AST adapter; the c2-hold lens scripts' positive-named and negative-named lists. Take every scratch path ONLY from the
   sources list of ${C}/seen/manifest.json (tags attack, pcprobe, c2-hold, lens-list, push-check-record): never search for a file.
   List the excluded sources with their reason (unmarked strings; push-check free-text quotes; held-out-suspect names, by name
   only and never opened) and count them.
3. Run regression_rows.py --manifest ${C}/regression/manifest.json --out ${C}/regression/rows.jsonl exactly as its usage says
   (chmod 600 the rows). Report the rows per source and polarity, the visible-form duplicates removed, the rows of conflicting
   polarity dropped and the total; record the SHA-256 of the manifest and of the rows. Confirm with a short script of your own,
   by path strings only, that no source path matches a D13 held-out-suspect name or pattern.
Return at most 20 lines: preconditions, the sources and exclusions, the counts, the hashes and every problem.`

const E_CHK = (op) => `${COMMON}

CHECK of step S1e (edit nothing under C except your own scratch directory ${C}/sets/s1e/check/). Independently:
1. The preconditions, and that the 36 inputs and the seed are unchanged.
2. Recompute the union corpus from the two builds (counts and SHA-256) and confirm ${C}/seen/s1e/manifest.json names revision
   ${COMMIT} and skipped no source beyond the held-out-suspect names.
3. Re-run check_sets.py with the same arguments into your scratch directory: the same rows kept, excluded and capped, by id.
4. Recompute the minimums of plan 4.3 with code of your own on the final rows (n, subjects, Spanish by the declared language,
   obfuscated, kinds H1-H22, injection wholesale/targeted/task-borne, prompt-aware n) and compare with check_sets.py's report.
5. The final files: sha256sum -c ${C}/sets/final/SHA256SUMS; per set, rows equal check_sets.py's kept rows (through the id map);
   no row in two sets; every row's judge field is "agree"; the request field present; mode 0600.
6. The operator's transcript (the agent-*.jsonl beside the journal.jsonl under ${WF} whose journal names the label operator:s1e):
   no recursive command over ${S}/wf, no held-out path, nothing written under R, no row text in its reply.
Operator summary: <<<${op}>>>
Return at most 15 lines: each problem with evidence, or "no problem" per item.`

const F_CHK = (op) => `${COMMON}

CHECK of step S1f (edit nothing under C except your own scratch directory ${C}/regression/check/). Independently:
1. The preconditions.
2. Every manifest source is in ${C}/seen/manifest.json's sources list or is one of the three pinned test files; none matches a D13
   held-out-suspect name or pattern (by path string); the exclusions are counted as D13 lists them.
3. Recount the rows per source and polarity with code of your own from the manifest's sources (structured fields only, as D13 says),
   then deduplicate by visible form and drop conflicting polarity, and compare with ${C}/regression/rows.jsonl (ids and counts).
4. sha256 of the manifest and rows as logged; rows mode 0600.
5. The operator's transcript (the agent-*.jsonl beside the journal.jsonl under ${WF} whose journal names the label operator:s1f):
   no recursive command over ${S}/wf, no held-out path, nothing written under R, no row text in its reply.
Operator summary: <<<${op}>>>
Return at most 15 lines: each problem with evidence, or "no problem" per item.`

const STEPS = [
  { key: 's1e', op: E_OP, chk: E_CHK },
  { key: 's1f', op: F_OP, chk: F_CHK },
]

const out = await pipeline(
  STEPS,
  (s) => agent(s.op, { label: `operator:${s.key}`, phase: 'Operate' }),
  (op, s) => agent(s.chk(op), { label: `check:${s.key}`, phase: 'Check' }).then((chk) => ({ step: s.key, op, chk })),
)
return { s1e: out[0], s1f: out[1] }
