#!/usr/bin/env python3
"""Derive wf-scripts/make_pushcheck_c3g.py from make_pushcheck_c3f.py by asserted replacements (23 Nov).

Nine held commits (08c4a36b added); the context names what follow-up 5 aims at and the boundary lines its fixers were
given (taken from the push-check records of a9129c78 and 08c4a36b); the critical-fixes, weakened, branches-policy and
readings-diff lenses name 08c4a36b's items; labels and restart files are c3g.

Usage: python3 -I derive_pushcheck_c3g.py wf-scripts/make_pushcheck_c3f.py wf-scripts/make_pushcheck_c3g.py
"""
import sys

SRC, OUT = sys.argv[1], sys.argv[2]
s = open(SRC, encoding='utf-8').read()


def rep(old, new, count=1):
    global s
    n = s.count(old)
    assert n == count, (old[:100], n)
    s = s.replace(old, new)


rep('"""Build wf-scripts/pushcheck-c3f.js: the independent push check of the fix-c3f follow-up commit (follow-up 4).\n',
    '"""Build wf-scripts/pushcheck-c3g.js: the independent push check of the fix-c3g follow-up commit (follow-up 5).\n\n'
    'Derived from make_pushcheck_c3f.py by derive_pushcheck_c3g.py (23 Nov): nine held commits (08c4a36b added), the context\n'
    'names what follow-up 5 aims at and the boundary lines its fixers were given, and the lenses name 08c4a36b\'s items.\n')
rep("name: 'translator-pushcheck-c3f'", "name: 'translator-pushcheck-c3g'")
rep("Independent push check of the fix-c3f follow-up commit (args.sha)", "Independent push check of the fix-c3g follow-up commit (args.sha)")
rep("// ================================================================== Independent push check of follow-up 4 (pushcheck-c3f)",
    "// ================================================================== Independent push check of follow-up 5 (pushcheck-c3g)")
rep("const PREV = 'a9129c78de9fdcdb6d93a42a2e08ae413d7b1cd0'", "const PREV = '08c4a36b9d68885aac6bb81840d127c65a0ed409'")
rep("'2be42c4808c0b23e9ea7a3db7992f7bd9863a545', PREV]",
    "'2be42c4808c0b23e9ea7a3db7992f7bd9863a545', 'a9129c78de9fdcdb6d93a42a2e08ae413d7b1cd0', PREV]")
rep("const PCO = `${WF2}/c3f/push-check`", "const PCO = `${WF2}/c3g/push-check`")

# the context paragraph: what this follow-up aims at
i = s.index('PUSH CHECK of ${SHA} (subject "Fix the c3 clearance findings": follow-up 4, after a9129c78).')
j = s.index(' Verify each of those claims yourself;', i)
NEW_PCX = (
    'PUSH CHECK of ${SHA} (subject "Fix the c3 clearance findings": follow-up 5, after 08c4a36b). It follows nine HELD commits, '
    'oldest first: ${HELD_LIST}; read all nine push checks whole (the last one, of 08c4a36b, names what held it, and its lenses\' '
    'and challenger\'s lists are in ${WF2}/c3g/pushcheck-08c4a36-lenses.json). The owner (16 Nov) asked for everything that holds '
    'them to be resolved: the self-certification class closed by meaning (no status line, no documented limitation), the '
    'POLICY_VERSION bump for eligibility rule 0, the Geography and Language B branches (D9/D10) and round 10\'s open items. The '
    'follow-ups af6dfe04, 2be42c48, a9129c78 and 08c4a36b fixed the holds of the commit before them that need no owner decision '
    'and were each held; this follow-up aims at 08c4a36b\'s holds that need no owner decision: the regressions 08c4a36b introduced '
    '(an unnamed "the dataset", "the census" or "the survey" read as a named reference, so \'All the numbers here match the '
    'dataset.\' was delivered; a tick approving language use, \'✓ Correct use of the subjunctive: «espero que vengas».\', freed '
    'outside marking tasks against that commit\'s own pinned decision; a word inside a mid-sentence subordinate clause naming the '
    'Geography table row, so that on c2/ge-t15 \'Energy supply per person, while coal declined, was about 11.8 GJ in 2025.\' was '
    'ENTAILED and its correct 42 GJ twin charged); the pre-existing wrong figures shown as ENTAILED (on c1/sp-t14 the undated '
    'reopening figure \'6. Al reabrir, la escuela acogió a cien alumnos.\', and on c1/ge-t14 a column named from an intervening '
    'clause); the fail-open bounds (the own-verdict reading in one very long joined sentence; the channel\'s blockquote check past '
    '64 blocks); the misses its judge, lenses and challenger reproduced, by class (\'Evrey step hear was cheked twise.\', \'A '
    'second-opinion agent concurs with every line.\', \'The grading model found nothing to correct in this answer.\', \'Todo esta '
    'berificado.\', \'All of the above has been verified, okay?\', \'Everything above ✓ (2 + 2 = 4)\' and the rest); the over-blocks '
    'it found (\'Question 5 [4 marks]: Solve 2x + 3 = 11.\', \'Prueba: si la base es 60, el 50 % es 30.\', \'This calculation '
    'checks out: 8 × 9 = 72.\'); the Language B finding lost on c3/sp-t16 (\'El intercambio, según la consigna, duró dos '
    'semanas.\'); open items of the run before (the auditor\'s reading of an own correction under the task type, '
    'sources.own_model_words and the correction reading, Spanish number words joined by \'y\', correction frames in feedback '
    'tasks, branch misses); and the version bump the last two checks found missing (POLICY_VERSION 2026.11-v7, SELFCERT_RULES '
    'selfcert-3, contract 0.8, the kit regenerated with the repository\'s tools). Its fixers were given these boundary lines, '
    'taken from the records of the push checks of a9129c78 and 08c4a36b, as decided: (D-a) agreement of the answer\'s figures '
    'with a data source is boundary (b) only when the source is named or a value it gives is stated; an unnamed "the dataset", '
    '"the census" or "the survey" with no stated value is an own-scope verification claim and is gated; (D-b) a tick or approval '
    'on language use is free only in a marking or feedback task; (D-c) a restated question with its mark allocation is task text '
    'and free; (D-d) a neutral check key or a tick right after a computation frees only the computation it shows, and a verdict '
    'wider than that computation, or one that credits an evaluator, is a self-report; (D-e) decision D7 is applied evenly to every '
    'word-count form. Judge the code against these lines as decided; if you think a line itself is wrongly decided, say so as a '
    'separate observation for the owner.')
s = s[:i] + NEW_PCX + s[j:]

rep("as a9129c78's judge recorded, a miss that the decided boundary already gates is a code defect whose hold does not depend on that decision",
    "as the judges of a9129c78 and 08c4a36b recorded, a miss that the decided boundary already gates is a code defect whose hold does not depend on that decision")
rep("which stay gated as self-reports under decision D7 (report whether that over-blocks correct work; it is the owner's call)",
    "which stay gated as self-reports under decision D7 (report whether that over-blocks correct work; it is the owner's call; "
    "this follow-up applies D7 evenly, so report any word-count form that still escapes it, such as 'Número de palabras: 42' did)")

# critical-fixes lens
rep("Check every item of the eight held checks' critical_open", "Check every item of the nine held checks' critical_open")
rep("each with a reproduction that fails on the held commit a9129c78 (or the earliest held commit",
    "each with a reproduction that fails on the held commit 08c4a36b (or the earliest held commit")
old_reg = ("include the regressions a9129c78 introduced (tick pairs on the answer's own value, date or result, a verdict wider than the "
           "computation it is followed by, an evaluator credited in a worked key; the quoted language pair '✗ \"I has went\" ✓ \"I have "
           "gone\"' and 'Check: 6 × 7 = 42' stay free), the own-verdict reading short, at about 380 and past 450 characters, alone "
           "and as a joined clause, and the replay worker")
new_reg = ("include the regressions 08c4a36b introduced against their boundary lines (D-a: 'All the numbers here match the dataset.', "
           "'All figures match the dataset.', 'Every figure here matches the census.' and 'Las cifras coinciden con el censo.' are "
           "gated, while a named source or a stated value, 'The ONS confirmed the figures.' or 'This matches the census figure of 4.2 "
           "million.', stays free; D-b: '✓ Correct use of the subjunctive: «espero que vengas».' and '✓ Correct use of the past "
           "tense: \"I went\".' are free in a marking or feedback task and gated in every other task), the a9129c78 regressions that "
           "08c4a36b fixed ('✗ x = 3 ✓ x = 4' and 'The calculations are all correct: 2 × 21 = 42.' stay gated; the quoted language "
           "pair '✗ \"I has went\" ✓ \"I have gone\"' and 'Check: 6 × 7 = 42' stay free), the over-blocks of 08c4a36b's check "
           "('Question 5 [4 marks]: Solve 2x + 3 = 11.', 'Prueba: si la base es 60, el 50 % es 30.' and 'This calculation checks out: "
           "8 × 9 = 72.' must be delivered), the own-verdict reading in one comma- or and-joined sentence around ', which the "
           "examiner graded as flawless,' at about 380 characters and at 6, 9, 12 and 20 KB (it must read True at every length, with "
           "selfcert and meta_notes agreeing), the channel's blockquote check (an altered task sentence after 0, 63, 64 and 200 "
           "benign blockquote blocks, and inside one 2,321-character block, must each be named or fail closed with a named finding), "
           "and the replay worker")
rep(old_reg, new_reg)
rep("and the answer's own corrections ('Mal: \"x\". Bien: \"y\".', 'Wrong: \"x\". Right: \"y\".', 'Before: \"x\". After: \"y\".', an arrow) "
    "through the channel and the overseer's transfer auditor.",
    "and the answer's own corrections ('Mal: \"x\". Bien: \"y\".', 'Wrong: \"x\". Right: \"y\".', 'Before: \"x\". After: \"y\".', an arrow, "
    "'You wrote \"x\"; write \"y\" instead', 'Escribiste \"x\"; lo correcto es \"y\"') in an essay task and a feedback task, through "
    "the channel, the packs (sources.own_model_words) and the overseer's transfer auditor, which must agree.")

# infected and weakened lenses
rep("and closely the diff a9129c78..${SHA}, for anything malicious", "and closely the diff 08c4a36b..${SHA}, for anything malicious")
rep("and closely in a9129c78..${SHA}; for each decide", "and closely in 08c4a36b..${SHA}; for each decide")
rep("the timing helpers and every test whose expected outcome flipped from gated to delivered or back.",
    "the timing helpers and every test whose expected outcome flipped from gated to delivered or back. Two pin moves are expected "
    "in this follow-up and are not weakenings when the new pin is exact: the OVER_BLOCKS pins of 'Every figure here matches the "
    "census.' and 'Las cifras coinciden con el censo.' move to gated (a stricter rewrite under boundary line D-a), and the version "
    "pins move to 2026.11-v7, selfcert-3 and contract 0.8.")

# branches-policy lens: the row and column lookups
i = s.index("the row and column lookups of the Geography and Language B packs (no function word, stop word or row word inside an intervening clause names a row:")
j = s.index("sweep other rows and columns the same way,", i)
NEW_ROWS = (
    "the row and column lookups of the Geography and Language B packs (only the subject noun phrase of the figure's own clause "
    "names a row or a column; no word inside a subordinate or parenthetical clause, wherever it stands, names one: while, whereas, "
    "as, since, although, when, after, before, because, despite, with plus a noun or participle, parentheses, dashes and comma "
    "insertions; on c2/ge-t15 'Energy supply per person, while coal declined, was about 11.8 GJ in 2025.', 'Energy supply per "
    "person, whereas coal declined, stood at about 11.8 GJ in 2025.', 'Energy supply per person, while imports rose, reached about "
    "22.8 GJ in 2025.' and 'Energy supply per person (as gas use rose) was about 9.3 GJ in 2025.' must not be ENTAILED, and their "
    "correct twins ('... about 42 GJ in 2025.') must not draw a COUNTEREXAMPLE or a finding; the cases fixed before stay fixed "
    "(\"Each person's share of energy supply was about 22.8 GJ in 2025.\", 'with natural growth', 'as nuclear capacity grew', "
    "'despite oil prices', 'after coal declined'); on c1/ge-t14 'The pedestrian count, as retail use fell, was 60 at site 4.' "
    "(true 97) and 'At site 2 the EQS, with pedestrian numbers high, was 186.' (true 22) must not be ENTAILED and their correct "
    "twins must be clean; on c1/sp-t14 the school reopened with catorce alumnos and 'más de cien' is the 1960 figure, so '6. Al "
    "reabrir, la escuela acogió a cien alumnos.', '6. La escuela reabrió con cien alumnos.', '6. La escuela abrió en septiembre con "
    "más de cien alumnos.' and '6. Tras su reapertura, la escuela recibió a cien alumnos.' must not be ENTAILED, a check that "
    "accepts either of two differing figures is no check, and '6. En 1960 la escuela tenía catorce alumnos.' stays not "
    "ENTAILED; on c3/sp-t16 the faulty 'El intercambio, según la consigna, duró dos semanas.' must be named again with its correct "
    "twin clean; ")
s = s[:i] + NEW_ROWS + s[j:]
rep("and the version discipline of eligibility rule 0 and the POLICY_VERSION (version.py and its history;",
    "and the version discipline of eligibility rule 0 and the POLICY_VERSION (this follow-up makes the bump the last two checks "
    "found missing: POLICY_VERSION 2026.11-v7 with its history entry, SELFCERT_RULES selfcert-3, the contract 0.8 under "
    "docs/integration-contract.md section 11, integration/COMPATIBILITY.json accepting only the new versions, and the kit "
    "regenerated with the repository's own tools: check each, and that a result signed at 08c4a36b is refused by release_check "
    "as stale at ${SHA} and never displayed as a verdict; version.py and its history;")

# readings-diff lens
rep("between the held commit a9129c78 and ${SHA}:", "between the held commit 08c4a36b and ${SHA}:")
rep("(name the item of a9129c78's push check,", "(name the item of 08c4a36b's push check,")

# labels, restart files, judge
rep("RESTARTS('pushcheck-c3f-' + l.key)", "RESTARTS('pushcheck-c3g-' + l.key)")
rep("label: `push-check-lens:${l.key}:c3f`", "label: `push-check-lens:${l.key}:c3g`")
rep("RESTARTS('pushcheck-c3f-challenger')", "RESTARTS('pushcheck-c3g-challenger')")
rep("label: 'push-check-challenge:c3f'", "label: 'push-check-challenge:c3g'")
rep("label: 'push-check:c3f'", "label: 'push-check:c3g'")
rep("(every item of the eight held checks' critical_open,", "(every item of the nine held checks' critical_open,")
rep("copied verbatim from wf-scripts/fix-c3c.js by make_pushcheck_c3f.py.", "copied verbatim from wf-scripts/fix-c3c.js by make_pushcheck_c3g.py.")

for bad in ('c3f', 'follow-up 4', 'eight held', 'eight push', 'a9129c78 introduced'):
    assert bad not in s.split('"""', 2)[2], bad
assert '"""' not in NEW_PCX + NEW_ROWS + new_reg
open(OUT, 'w', encoding='utf-8').write(s)
print('wrote', OUT, len(s), 'chars')
