#!/usr/bin/env python3
"""Build wf-scripts/fix-c3k.js: the meaning check, stage 2a (wiring with the faithful fake, the reader's stage-2 changes,
the arena's label tools and the version bump; no recording, no measurement), 25 Nov; REVISED 25 Nov 19:xx after the
independent review of the script (wf/phase2/c3k/review).

Usage: python3 -I make_fix_c3k.py wf-scripts/fix-c3j.js wf-scripts/fix-c3k.js

Derived from the generated fix-c3j.js by asserted replacements only: the meta block, OUT (c3k), the THIS RUN paragraphs
of DCTX (with the run's ORDER and INTERFACES), the FIXERS array (owners R2, R1, R4, R5, R7, R6 and R3, from c3k_fixers.py)
run in WAVES (R2 alone; R1 + R4; R5 + R7; R6 + R3) instead of one parallel call, the rules sentence of the owners, the
class's boundary (b) sentence on named references (refined by decision 5), the check lenses (an adversarial release-path
lens and a design-conformance lens), the check-lens sentence about earlier push checks, the check fixer's scope and
priorities, the KIT task (R8), the verify prompt (the harness with the faithful labeller; the suite started detached and
its wait loop stopping when the process exits; the measured duration), the repair text (never the frozen prompt; redo the
KIT pins a repair moves; decision 5 narrowed, never removed), every c3j label and restart file (c3k), the attack round
(17), the commit body and a scrubbed 'not done' list appended to it. Everything else (schemas, the class and boundary
definitions, the verification helpers, the held-out rule, the timing rule) is carried over verbatim.
"""
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from c3k_fixers import (FIXERS, DCTX_RUN, COMMIT_BODY, KIT_TASK, FIXER_RULES, CHECK_PRIORITIES, PATHS_LENS,  # noqa: E402
                        DESIGN_LENS)

SRC, OUT_JS = sys.argv[1], sys.argv[2]
s = open(SRC, encoding='utf-8').read()


def rep(text, old, new, count=1):
    n = text.count(old)
    assert n == count, (old[:100], n)
    return text.replace(old, new)


texts = [('DCTX_RUN', DCTX_RUN), ('KIT_TASK', KIT_TASK), ('FIXER_RULES', FIXER_RULES), ('CHECK_PRIORITIES', CHECK_PRIORITIES),
         ('PATHS_LENS', PATHS_LENS), ('DESIGN_LENS', DESIGN_LENS), ('COMMIT_BODY', COMMIT_BODY)] + [('owner ' + k, t) for k, t in FIXERS]
allowed = {'S', 'C3B', 'PY', 'REPO', 'OUT', 'TIMING', 'r', 'CLR', 'C3'}
for name, t in texts:
    assert '`' not in t, ('backtick in', name)
    used = set(re.findall(r'\$\{([^}]*)\}', t))
    assert used <= allowed, (name, used - allowed)
    assert not re.search(r'(?<!\$)\{[A-Za-z_]+\}', t), ('bare brace placeholder in', name)
assert '${' not in COMMIT_BODY
KEYS = [k for k, _ in FIXERS]
assert KEYS == ['label', 'reader', 'channel', 'service', 'arena', 'overseer', 'prompt'], KEYS
WAVES = [['label'], ['reader', 'channel'], ['service', 'arena'], ['overseer', 'prompt']]
assert sorted(k for w in WAVES for k in w) == sorted(KEYS)
for bad in ('a7c3c8b5', 'claude-0', 'session_01', 'Opus', 'Haiku', 'Sonnet', 'API 1.3', '0.7 -> 0.8', 'contract 0.8', 'docs/STATUS.md'):
    for name, t in texts:
        assert bad not in t, (bad, name)

m = re.match(r"export const meta = \{.*?\n\}\n", s, re.S)
assert m, 'meta not found'
META = """export const meta = {
  name: 'translator-fix-c3k',
  description: "Meaning check, stage 2a: wire the block-only label into every release path with the faithful fake for existing tests (service step 4, hub and channel, the overseer's gate and delivery paths, displays, the arena), the reader's stage-2 changes including decision 5 and the DIRECTIVE companion test, the arena's label tools, and the version bump; no recording and no measurement; one check round; verify (harness in wiring-parity mode) and commit",
  phases: [
    { title: 'Fix', detail: 'seven owners on disjoint paths in four waves: the label package and test fixtures (R2) alone; reader and public API (R1) with channel, hub and display (R4); service and protocol (R5) with arena tools (R7); overseer and sub-project tests (R6) with the prompt revision (R3)' },
    { title: 'Check', detail: 'one round (17): an adversarial release-path lens and a design-conformance lens; one fixer for what they reproduce' },
    { title: 'Version', detail: 'one KIT step (R8): POLICY_VERSION and the manifest entry, the label identity and pack pins, kit regeneration, contract document, version pins' },
    { title: 'Verify', detail: 'full suite in shards (detached), then the harness on every round with the faithful labeller (wiring parity: must equal the baseline), hygiene, up to three repairs, commit' },
  ],
}
"""
s = META + s[m.end():]

s = rep(s, "const OUT = `${WF2}/c3j`", "const OUT = `${WF2}/c3k`")
# THIS RUN paragraphs: from the stage-1 paragraph to the line before 'The working tree of'
i = s.index('THIS RUN (meaning check, stage 1; 25 Nov).')
j = s.index('\nThe working tree of ${REPO} (branch ${BRANCH}) is shared', i)
s = s[:i] + DCTX_RUN.strip('\n') + s[j:]
# the class's boundary (b) sentence on named references, refined by decision 5
s = rep(s, "agreement of the answer's values with a named subject-matter reference ('consistent with Newton's second law', 'matches the ONS figure of 4.2%'), which is a material claim translated and checked like any other.",
        "agreement of the answer's values with a named subject-matter reference that has content of its own, such as a law, a theorem or a stated figure ('consistent with Newton's second law', 'matches the ONS figure of 4.2%'), which is a material claim translated and checked like any other. Decision 5 of this run refines this: agreement with a named source or dataset that states no value ('The values agree with the XQ dataset.', 'Our totals match the census.') is gated.")
# FIXERS array
i = s.index('const FIXERS = [\n')
j = s.index('\n]\nconst fixRes = await parallel(FIXERS.map', i)
s = s[:i] + 'const FIXERS = [\n' + ',\n'.join("  { key: '%s', task: `%s` }" % (k, t.strip('\n')) for k, t in FIXERS) + s[j:]
# the owners' rules sentence
i = s.index('Rules for every owner: build each part exactly as the memo specifies')
j = s.index("${RESTARTS('c3j-' + f.key)}", i)
s = s[:i] + FIXER_RULES.strip() + s[j:]
# labels, restart files, round
s = rep(s, "RESTARTS('c3j-' + f.key)", "RESTARTS('c3k-' + f.key)")
s = rep(s, "label: `fix:c3j:${f.key}`", "label: `fix:c3k:${f.key}`")
# the owners run in waves (two agents at a time on this machine; R2's fixtures and the API before their users)
s = rep(s, "const fixRes = await parallel(FIXERS.map(f => () => agent(", "const runFixer = f => agent(")
WAVES_JS = ("\nconst WAVES = " + repr(WAVES).replace("'", "'") + "\n"
            "const fixByKey = {}\n"
            "for (const w of WAVES) {\n"
            "  const rs = await parallel(w.map(k => () => runFixer(FIXERS.find(f => f.key === k))))\n"
            "  w.forEach((k, i) => { fixByKey[k] = rs[i] })\n"
            "  log(`fix wave ${w.join(' + ')}: ${w.map(k => `${k} ${fixByKey[k] ? (fixByKey[k].fixed || []).length + ' fixed' : 'no result'}`).join(', ')}`)\n"
            "}\n"
            "const fixRes = FIXERS.map(f => fixByKey[f.key] || null)")
s = rep(s, "{ label: `fix:c3k:${f.key}`, phase: 'Fix', schema: FIX_SCHEMA, effort: 'high' })))",
        "{ label: `fix:c3k:${f.key}`, phase: 'Fix', schema: FIX_SCHEMA, effort: 'high' })" + WAVES_JS)
s = rep(s, "label: `check:${l.key}:c3j`", "label: `check:${l.key}:c3k`")
s = rep(s, "label: 'fix:c3j:check'", "label: 'fix:c3k:check'")
s = rep(s, "RESTARTS('c3j-check')", "RESTARTS('c3k-check')")
s = rep(s, "${OUT}/progress-c3j-*.md", "${OUT}/progress-c3k-*.md")
s = rep(s, "'clearance-c3j'", "'clearance-c3k'")
s = rep(s, "label: 'fix:c3j:kit'", "label: 'fix:c3k:kit'")
s = rep(s, "RESTARTS('c3j-kit')", "RESTARTS('c3k-kit')")
s = rep(s, "const ROUND = 16 // continues the attack numbering", "const ROUND = 17 // continues the attack numbering")
s = rep(s, "This stage changes no release path, so the earlier push checks' reproductions are not yours to re-run.",
        "The earlier push checks' reproductions belong to the push check of stage 2c, not to you.")
# the check lenses
i = s.index("const LENSES = [{ key: 'label-attack', task: r => `")
j = s.index('\n', i)
s = s[:i] + "const LENSES = [{ key: 'paths', task: r => `" + PATHS_LENS + "` }, { key: 'design', task: r => `" + DESIGN_LENS + "` }]" + s[j:]
s = rep(s, "The two owners of this run left these items", "The owners of this run left these items")
# the check fixer's scope
i = s.index('You are the CHECK FIXER of this run. You may edit only src/epinoic_logic/selfcert_label/** (never its frozen prompt.md) ')
j = s.index('The check lenses reproduced these on the working tree:', i)
s = s[:i] + ("You are the CHECK FIXER of this run. You may edit any path except the frozen prompt and the KIT step's files and pins "
             "(see the priorities below); the design is the memo named above and the INTERFACES of this run. ") + s[j:]
i = s.index("Priorities: (1) every fail_open (a path to 'none_named', a skipped sentence, or label text reaching anything but the raw reply)")
j = s.index("${RESTARTS('c3k-check')}", i)
s = s[:i] + CHECK_PRIORITIES.strip() + s[j:]
# the KIT step (R8)
i = s.index('You are the KIT step of this run')
j = s.index("\n${TIMING}${RESTARTS('c3k-kit')}", i)
s = s[:i] + KIT_TASK.strip() + s[j:]
# the verify prompt: the suite detached (a slower shard than 2 hours must not be killed), its measured duration, a wait
# loop that stops when the process exits, and the harness with the faithful labeller (wiring parity)
s = rep(s, "then start ONE background command with the longest timeout (7200000 ms): cd ${REPO} && bash ${S}/suite_shards.sh ${REPO} ${WF2}/rounds-copy \"${PY}\" 3 ${logdir} > ${logdir}.out 2>&1 (one collection,",
        "then start it DETACHED, so that no tool time limit can stop it: rm -f ${logdir}.done; setsid nohup bash -c 'cd ${REPO} && bash ${S}/suite_shards.sh ${REPO} ${WF2}/rounds-copy \"${PY}\" 3 ${logdir}; echo exit $? > ${logdir}.done' > ${logdir}.out 2>&1 < /dev/null & (one collection,")
s = rep(s, "It takes about 50 minutes. Ending your turn kills it, so NEVER end your turn while it runs: block with foreground calls such as until grep -qE 'shards of [0-9]+ collected|collection failed' ${logdir}.out; do sleep 30; done (at most 9 minutes per call), repeated until the aggregate line is there.",
        "It took about 80 minutes at the last commit and can take longer now. NEVER end your turn while it runs (its result is the one you return): block with foreground calls such as until grep -qE 'shards of [0-9]+ collected|collection failed' ${logdir}.out || [ -f ${logdir}.done ]; do sleep 30; done (at most 9 minutes per call), repeated until the aggregate line is there or ${logdir}.done exists; if it exists without the aggregate line, report suite_passed=false with the last lines of each shard log.")
s = rep(s, "${PY} ${REPO}/scripts/arena/run_arena.py <dir>; give harness_line",
        "${PY} ${REPO}/scripts/arena/run_arena.py --labeller faithful <dir> (the faithful labeller makes this a wiring-parity "
        "run: no label is recorded in this stage, so the arena's default would withhold every answer the reader passes; under "
        "the faithful fake every delivery decision must equal the baseline); give harness_line")
# the repair text: never the frozen prompt; a repair that moves a KIT-owned pin redoes it; decision 5 narrowed, never removed
s = rep(s, "You may edit any path. Make the suite green",
        "You may edit any path except src/epinoic_logic/selfcert_label/prompt.md (frozen). If your change moves label_digest() "
        "(any file under src/epinoic_logic/selfcert/ or src/epinoic_logic/selfcert_label/), the overseer pack's digest, or any file "
        "integration/MANIFEST.sha256 lists, redo the KIT step's part for it in the same repair: re-pin selfcert-label-2 (not yet "
        "committed) with the new digest in tests/selfcert_label/test_identity.py and in policy_manifest() and tests/engine, re-pin the "
        "pack digest in src/epinoic_logic/integration/overseer_port.py, and regenerate COMPATIBILITY.json, compat.py and "
        "MANIFEST.sha256 with integration/tools in the rule's order, then run their --check commands; prefer a fix outside the "
        "covered files. A harness drop caused by decision 5 on a genuine answer is fixed by narrowing the rule to this run's "
        "statement of decision 5, never by removing decision 5. Make the suite green")
# commit body, and a scrubbed list of what was not done (no local path, model name or session id reaches the repository)
i = s.index('const body = `')
j = s.index('\nCheck round after the fixes: ${open.length} reproduced.', i)
s = s[:i] + 'const body = `' + COMMIT_BODY.strip() + s[j:]
s = rep(s, "const clip = (s, n) => { s = String(s == null ? '' : s); return s.length <= n ? s : s.slice(0, n) + '…' }",
        "const clip = (s, n) => { s = String(s == null ? '' : s); return s.length <= n ? s : s.slice(0, n) + '…' }\n"
        "const scrub = t => String(t).replace(/(?<![\\w.-])\\/(tmp|root|home)\\/[^\\s'\",;)]*/g, '[local path]').replace(/claude-(opus|haiku|sonnet|fable)[\\w.-]*/gi, '[model]').replace(/\\b(Opus|Haiku|Sonnet|Fable) \\d[\\d.]*/g, '[model]').replace(/session_01[0-9A-Za-z]{10,}/g, '[session]').replace(/a7c3c8b5[\\w-]*/g, '[id]')")
s = rep(s, "Changes:\n${clipFixed(allFixed, 7000)}`",
        "Changes:\n${scrub(clipFixed(allFixed, 6000))}\nNot done in this commit (the owners', the check fixer's and the kit step's own reports): "
        "${scrub(clip(leftAll.filter(x => !/KIT-owned pin/.test(typeof x === 'string' ? x : JSON.stringify(x))).map(x => typeof x === 'string' ? x : JSON.stringify(x)).join(' | '), 2500)) || 'none'}`")
s = rep(s, "// ================================================================== fix-c3j (written 25 Nov: meaning check, stage 1, after the owner's yes)",
        "// ================================================================== fix-c3k (written 25 Nov: meaning check, stage 2a, wiring with the faithful fake; revised after review)")
for bad in ('fix:c3j:', "'c3j-", 'clearance-c3j', 'progress-c3j', 'ROUND = 16', 'stage 1; 25 Nov', 'label-attack',
            'This stage changes no release path', 'The two owners of this run', 'You may edit only src/epinoic_logic/selfcert_label',
            'run_arena.py <dir>;', 'It takes about 50 minutes', 'start ONE background command with the longest timeout',
            'await parallel(FIXERS.map', "('consistent with Newton's second law', 'matches the ONS figure of 4.2%'), which is a material claim translated and checked like any other.\""):
    assert bad not in s, bad
assert s.count('--labeller faithful') >= 2 and s.count('runFixer(') == 1 and 'const WAVES = ' in s
assert 'kill -0' not in s and '${logdir}.done' in s and '.pid' not in s
open(OUT_JS, 'w', encoding='utf-8').write(s)
print('wrote', OUT_JS, len(s), 'chars')
