#!/usr/bin/env python3
"""Build wf-scripts/fix-c3k.js: the meaning check, stage 2a (wiring with the faithful fake, the reader's stage-2 changes,
the arena's label tools and the version bump; no recording, no measurement), 25 Nov.

Usage: python3 -I make_fix_c3k.py wf-scripts/fix-c3j.js wf-scripts/fix-c3k.js

Derived from the generated fix-c3j.js by asserted replacements only: the meta block, OUT (c3k), the THIS RUN paragraphs
of DCTX (with the run's INTERFACES), the FIXERS array (owners R2, R1, R4, R6, R5, R7 and R3, from c3k_fixers.py, in that
start order: the workflow runs at most two agents at a time on this machine), the rules sentence of the owners, the check
lenses (an adversarial release-path lens and a design-conformance lens), the check-lens sentence about earlier push
checks, the check fixer's scope and priorities, the KIT task (R8: the version bump and kit regeneration), the verify
prompt's harness command (the faithful labeller: a wiring-parity run that must equal the baseline), every c3j label and
restart file (c3k), the attack round (17) and the commit body. Everything else (schemas, the class and boundary
definitions, the verification helpers, the held-out rule, the timing rule) is carried over verbatim.
"""
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from c3k_fixers import (FIXERS, DCTX_RUN, COMMIT_BODY, KIT_TASK, FIXER_RULES, CHECK_PRIORITIES, PATHS_LENS,  # noqa: E402
                        DESIGN_LENS)

SRC, OUT_JS = sys.argv[1], sys.argv[2]
s = open(SRC, encoding='utf-8').read()


def rep(text, old, new, count=1):
    n = text.count(old)
    assert n == count, (old[:100], n)
    return text.replace(old, new)


texts = [('DCTX_RUN', DCTX_RUN), ('KIT_TASK', KIT_TASK), ('FIXER_RULES', FIXER_RULES), ('CHECK_PRIORITIES', CHECK_PRIORITIES),
         ('PATHS_LENS', PATHS_LENS), ('DESIGN_LENS', DESIGN_LENS), ('COMMIT_BODY', COMMIT_BODY)] + [('owner ' + k, t) for k, t in FIXERS]
allowed = {'S', 'C3B', 'PY', 'REPO', 'OUT', 'TIMING', 'r', 'CLR', 'C3'}
for name, t in texts:
    assert '`' not in t, ('backtick in', name)
    used = set(re.findall(r'\$\{([^}]*)\}', t))
    assert used <= allowed, (name, used - allowed)
    assert not re.search(r'(?<!\$)\{[A-Za-z_]+\}', t.replace('{version, digest, required: true}', '').replace('{recorded,faithful,unconfigured}', '')
                         .replace('{quote, category}', '')), ('bare brace placeholder in', name)
assert '${' not in COMMIT_BODY
# the owners in their start order, and no path owned twice among the R-owners' first sentences
assert [k for k, _ in FIXERS] == ['label', 'reader', 'channel', 'overseer', 'service', 'arena', 'prompt'], [k for k, _ in FIXERS]
for bad in ('a7c3c8b5', 'claude-0', 'session_01', 'Opus', 'Haiku', 'Sonnet'):
    for name, t in texts:
        assert bad not in t, (bad, name)

m = re.match(r"export const meta = \{.*?\n\}\n", s, re.S)
assert m, 'meta not found'
META = """export const meta = {
  name: 'translator-fix-c3k',
  description: "Meaning check, stage 2a: wire the block-only label into every release path with the faithful fake for existing tests (service step 4, hub and channel, the overseer's gate and delivery paths, displays, the arena), the reader's stage-2 changes including decision 5 and the DIRECTIVE companion test, the arena's label tools, and the version bump; no recording and no measurement; one check round; verify (harness in wiring-parity mode) and commit",
  phases: [
    { title: 'Fix', detail: 'seven owners on disjoint paths, two at a time: label package and test fixtures (R2), reader (R1), channel/hub/display (R4), overseer and sub-project tests (R6), service and protocol (R5), arena tools (R7), prompt revision (R3)' },
    { title: 'Check', detail: 'one round (17): an adversarial release-path lens and a design-conformance lens; one fixer for what they reproduce' },
    { title: 'Version', detail: 'one KIT step (R8): POLICY_VERSION and the manifest entry, the label identity pin, the pack digest pin, kit regeneration, status' },
    { title: 'Verify', detail: 'full suite in shards, then the harness on every round with the faithful labeller (wiring parity: must equal the baseline), hygiene, up to three repairs, commit' },
  ],
}
"""
s = META + s[m.end():]

s = rep(s, "const OUT = `${WF2}/c3j`", "const OUT = `${WF2}/c3k`")
# THIS RUN paragraphs: from the stage-1 paragraph to the line before 'The working tree of'
i = s.index('THIS RUN (meaning check, stage 1; 25 Nov).')
j = s.index('\nThe working tree of ${REPO} (branch ${BRANCH}) is shared', i)
s = s[:i] + DCTX_RUN.strip('\n') + s[j:]
# FIXERS array
i = s.index('const FIXERS = [\n')
j = s.index('\n]\nconst fixRes = await parallel(FIXERS.map', i)
s = s[:i] + 'const FIXERS = [\n' + ',\n'.join("  { key: '%s', task: `%s` }" % (k, t.strip('\n')) for k, t in FIXERS) + s[j:]
# the owners' rules sentence
i = s.index('Rules for every owner: build each part exactly as the memo specifies')
j = s.index("${RESTARTS('c3j-' + f.key)}", i)
s = s[:i] + FIXER_RULES.strip() + s[j:]
# labels, restart files, round
s = rep(s, "RESTARTS('c3j-' + f.key)", "RESTARTS('c3k-' + f.key)")
s = rep(s, "label: `fix:c3j:${f.key}`", "label: `fix:c3k:${f.key}`")
s = rep(s, "label: `check:${l.key}:c3j`", "label: `check:${l.key}:c3k`")
s = rep(s, "label: 'fix:c3j:check'", "label: 'fix:c3k:check'")
s = rep(s, "RESTARTS('c3j-check')", "RESTARTS('c3k-check')")
s = rep(s, "${OUT}/progress-c3j-*.md", "${OUT}/progress-c3k-*.md")
s = rep(s, "'clearance-c3j'", "'clearance-c3k'")
s = rep(s, "label: 'fix:c3j:kit'", "label: 'fix:c3k:kit'")
s = rep(s, "RESTARTS('c3j-kit')", "RESTARTS('c3k-kit')")
s = rep(s, "const ROUND = 16 // continues the attack numbering", "const ROUND = 17 // continues the attack numbering")
s = rep(s, "This stage changes no release path, so the earlier push checks' reproductions are not yours to re-run.",
        "The earlier push checks' reproductions belong to the push check of stage 2c, not to you.")
# the check lenses
i = s.index("const LENSES = [{ key: 'label-attack', task: r => `")
j = s.index('\n', i)
s = s[:i] + "const LENSES = [{ key: 'paths', task: r => `" + PATHS_LENS + "` }, { key: 'design', task: r => `" + DESIGN_LENS + "` }]" + s[j:]
s = rep(s, "The two owners of this run left these items", "The owners of this run left these items")
# the check fixer's scope
i = s.index('You are the CHECK FIXER of this run. You may edit only src/epinoic_logic/selfcert_label/** (never its frozen prompt.md) ')
j = s.index('The check lenses reproduced these on the working tree:', i)
s = s[:i] + ("You are the CHECK FIXER of this run. You may edit any path except the frozen prompt and the KIT step's files (see "
             "the priorities below); the design is the memo named above and the INTERFACES of this run. ") + s[j:]
i = s.index("Priorities: (1) every fail_open (a path to 'none_named', a skipped sentence, or label text reaching anything but the raw reply)")
j = s.index("${RESTARTS('c3k-check')}", i)
s = s[:i] + CHECK_PRIORITIES.strip() + s[j:]
# the KIT step (R8)
i = s.index('You are the KIT step of this run')
j = s.index("\n${TIMING}${RESTARTS('c3k-kit')}", i)
s = s[:i] + KIT_TASK.strip() + s[j:]
# the verify prompt's harness: the faithful labeller (wiring parity)
s = rep(s, "${PY} ${REPO}/scripts/arena/run_arena.py <dir>; give harness_line",
        "${PY} ${REPO}/scripts/arena/run_arena.py --labeller faithful <dir> (the faithful labeller makes this a wiring-parity "
        "run: no label is recorded in this stage, so the arena's default would withhold every answer the reader passes; under "
        "the faithful fake every delivery decision must equal the baseline); give harness_line")
# commit body
i = s.index('const body = `')
j = s.index('\nCheck round after the fixes: ${open.length} reproduced.', i)
s = s[:i] + 'const body = `' + COMMIT_BODY.strip() + s[j:]
s = rep(s, "// ================================================================== fix-c3j (written 25 Nov: meaning check, stage 1, after the owner's yes)",
        "// ================================================================== fix-c3k (written 25 Nov: meaning check, stage 2a, wiring with the faithful fake)")
for bad in ('fix:c3j:', "'c3j-", 'clearance-c3j', 'progress-c3j', 'ROUND = 16', 'stage 1; 25 Nov', 'label-attack',
            'This stage changes no release path', 'The two owners of this run', 'You may edit only src/epinoic_logic/selfcert_label',
            'run_arena.py <dir>;'):
    assert bad not in s, bad
assert s.count('--labeller faithful') >= 2
open(OUT_JS, 'w', encoding='utf-8').write(s)
print('wrote', OUT_JS, len(s), 'chars')
