#!/usr/bin/env python3
"""Build wf-scripts/fix-c3c.js from fix-c3c-body.js plus blocks copied verbatim from resolve-c3b.js (asserted)."""
import sys
S = '/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/wf-scripts'
src = open(f'{S}/resolve-c3b.js', encoding='utf-8').read().split('\n')
body = open(f'{S}/fix-c3c-body.js', encoding='utf-8').read()
L = lambda a, b: src[a - 1:b]  # 1-based inclusive
consts = L(15, 41)
assert consts[0].startswith('const REPO = ') and consts[-1].startswith('const SUBPROJECT_PATH = '), (consts[0][:40], consts[-1][:40])
cls = L(67, 72)
assert cls[0].startswith('const SELFCERT_CLASS = `THE CLASS') and cls[-1].startswith('const RESTARTS = label =>'), (cls[0][:40], cls[-1][:40])
ver = L(79, 101)
assert ver[0].startswith('// ------------------------------------------------------------------ verification') and ver[-1] == '}', (ver[0][:60], ver[-1])
ver = '\n'.join(ver)
old_h = "hygiene_ok is false otherwise, with hygiene_detail naming each hit. Return the result.`"
assert ver.count(old_h) == 1
ver = ver.replace(old_h, "Also git -C ${REPO} ls-files -- 'tmp*' and git -C ${REPO} status --porcelain --untracked-files=normal -- 'tmp*' must print nothing (no scratch directory of Python's tempfile naming at the repository root, tracked or untracked). hygiene_ok is false otherwise, with hygiene_detail naming each hit. Return the result.`")
assert ver.count('for (let k = 1; k <= 2 && !isGreen(v, extraRounds) && v; k++) {') == 1
ver = ver.replace('for (let k = 1; k <= 2 && !isGreen(v, extraRounds) && v; k++) {', 'for (let k = 1; k <= 3 && !isGreen(v, extraRounds) && v; k++) {')
old_c = "In ${REPO} on branch ${BRANCH}: run git status --short; if nothing changed return committed=false, pushed=false. Otherwise git add -A"
assert ver.count(old_c) == 1
ver = ver.replace(old_c, "In ${REPO} on branch ${BRANCH}: run git status --short; if nothing changed return committed=false, pushed=false. Run git status --porcelain --untracked-files=normal: if any untracked entry is a scratch artefact (tmp*, *.log, *.zip, a probe, an export or a copy) rather than source, tests or documentation, do NOT commit: return committed=false, pushed=false and name the entries in sha. Otherwise git add -A")
atk = L(187, 192)
assert atk[0] == 'const ATK = [' and atk[-1] == ']', (atk[0], atk[-1])
atk = '\n'.join(atk)
n1 = atk.count('${OUT}/heldout/'); n2 = atk.count('${OUT}/leftovers.json')
assert n1 == 3 and n2 == 1, (n1, n2)
atk = atk.replace('${OUT}/heldout/', '${C3B}/heldout/').replace('${OUT}/leftovers.json', '${C3B}/leftovers.json')
marker = '// ------------------------------------------------------------------ Fix: four owners on disjoint paths'
assert body.count(marker) == 1
pre, post = body.split(marker)
meta = '''export const meta = {
  name: 'translator-fix-c3c',
  description: "Follow-up after the c3b push check held 2ff7022: fix its holds that need no owner decision (misspelling exemptions, encoded labels and the README limitation, the answer's own solver label and confidence, the debug print, the stray scratch directories) and round 8's open regressions, over-blocks and branch misses; one round of check lenses; verify and commit; draft and review the handoff refresh",
  phases: [
    { title: 'Fix', detail: 'four owners on disjoint paths: self-certification reader and data, repository hygiene, Geography and Language B, own-text reader' },
    { title: 'Check', detail: 'one round of the four lenses on the fixed tree; one fixer for what they reproduce' },
    { title: 'Verify', detail: 'full suite in shards, harness on every round, hygiene incl. stray directories, up to three repairs, commit' },
    { title: 'Handoff', detail: 'the three handoff documents refreshed and reviewed (published by the main session)' },
  ],
}
// Constants and helpers copied verbatim from wf-scripts/resolve-c3b.js (asserted by make_fix_c3c.py).'''
out = '\n'.join([meta] + consts) + '\n\n' + pre.rstrip('\n') + '\n\n' + '\n'.join(cls) + '\n\n' + ver + '\n\n' + atk + '\n\n' + marker + post
open(f'{S}/fix-c3c.js', 'w', encoding='utf-8').write(out)
print('wrote fix-c3c.js', len(out))
