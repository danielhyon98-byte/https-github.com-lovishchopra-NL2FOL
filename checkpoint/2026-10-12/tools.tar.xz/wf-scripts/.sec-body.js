
// ------------------------------------------------------------------ Security fix (24 Oct, after regression close round 3)
const IT = `${R}/.worktrees/argdiag-integ`
const RG = WF + '/regr'
const BT = RG + '/base-tree'
const SF = WF + '/secfix'
const ISSUE = { type: 'object', properties: { id: STR, area: STR, severity: { type: 'string', enum: ['high', 'medium', 'low'] }, problem: STR, evidence: STR }, required: ['id', 'area', 'severity', 'problem'] }
const VER = { type: 'object', properties: { ok: { type: 'boolean' }, measured: STR, issues: { type: 'array', items: ISSUE } }, required: ['ok', 'measured', 'issues'] }
const FIX = { type: 'object', properties: { staged: { type: 'boolean' }, suite: STR, patterns_checked: STR, fixed: STRS, timing: STRS, corpus_dev: STR, corpus_holdout: STR, arena: STRS, left: STRS }, required: ['staged', 'suite', 'patterns_checked', 'fixed', 'timing', 'left'] }
const TREES = `TREES. The committed base is 7991e8b (the worktree HEAD), exported read-only to ${BT}. The staged tree is the index of ${IT} (git -C ${IT} diff --cached HEAD); its state before this step is the local ref argdiag-close3-snapshot (tree 1e770e3d). Run a tree's code with PYTHONPATH=<tree>/src ${VPY} and check which tree is imported; for a fresh copy of the current staged tree use git -C ${IT} checkout-index -a --prefix=<new empty folder>/. The last measured outputs of the staged tree are under ${RG}/close-3/ (suite, corpora, arena) and the last verification is in ${WF}/verify-r3/diff/result.json and ${WF}/verify-r3/invariants/result.json.`
const SCOPE = `SCOPE: security only. Change only what makes a pattern or reader super-linear (or unbounded), and keep every outcome identical: the corpora, the arena receipts and the suite must give exactly what the close-3 measurement gave (except time). Do not touch any other finding of the verification (the false-alarm items DIFF3-01 to DIFF3-08, DV2-03, DV2-05, DV2-08 stay as recorded known defects; DV2-07, the extra verification work the base never does, also stays: record its measured cost, do not cut verification). Never weaken a test; never change a pinned outcome.`
const fixPrompt = (k, extra) => `${CTX}
${TREES}
YOU ARE THE FIXER (security round ${k}). ${SCOPE}
(1) SEC-1 (from ${WF}/verify-r3/invariants/result.json): the thousands-group alternative \\d{1,3}(?:[  ]\\d{3})+ added by the staged diff makes reading figures quadratic on a long run of space-grouped digits (each group is a new match start that rescans to the end of the run). Make it linear (one pass over a digit run, or a guard that a match cannot start inside a run already consumed), with the same matches as now on every input of the corpora, the arena and the suite.
(2) SWEEP: list every regular expression and every reader loop that the staged diff adds or changes under src/ (git -C ${IT} diff --cached HEAD -- src). For each, build adversarial inputs that target its worst case (long runs of the characters its quantifiers repeat, nested or overlapping optional groups, many quotes, many sentences, many figures, inputs up to the 400,000-character response bound) and time it at three sizes on a fresh copy of the staged tree and on ${BT}; a pattern whose time grows faster than linearly, or that takes more than 1 s on a bounded input where the base takes under 0.1 s, is fixed the same way. Write the list with each pattern's measured times to ${SF}/round-${k}/patterns.md.
(3) Each fix gets a timing regression test that fails on the old pattern (growth ratio between two sizes, not a wall-clock bound that load can break) and an equality test that the matches are unchanged on representative inputs.
${extra}
Measure ONCE at the end on a fresh copy: the full suite; both corpora (${COR}/run_corpus.py, --cases ${COR}/dev and ${COR}/holdout, into ${SF}/round-${k}/corpus-dev and corpus-holdout) compared case by case with ${RG}/close-3/; every arena round on fresh copies into ${SF}/round-${k}/arena with the receipts compared answer by answer to ${RG}/close-3/arena (no difference allowed). Update docs/ARGUMENT_DIAGNOSTICS.md (security section: what was super-linear, the fix, the measured times). Stage with git add -A in ${IT} (never commit). Return staged, suite, patterns_checked (how many patterns, how many fixed), fixed, timing lines (pattern: sizes and times before and after), both corpus summaries, arena lines and left.`
const SEC = `LENS: SECURITY. Independently of the fixer's list, enumerate every regular expression and reader loop the staged diff adds or changes under src/ (git -C ${IT} diff --cached HEAD -- src), and for each build your OWN adversarial inputs for its worst case (repeated characters its quantifiers accept, overlapping optional groups, long runs of digits with spaces, commas or thin spaces, many quotation marks, many sentences or figures, nested brackets, up to the 400,000-character response bound). Time each at three sizes on a fresh copy of the staged tree and on ${BT}. An issue (high) for every pattern whose time grows faster than linearly or that takes more than 1 s on a bounded input where the base takes under 0.1 s; include the input generator and the times. Also run the whole hub on the five slowest inputs you find and report the end-to-end times on both trees. ok only with no high issue.`
const REG = `LENS: NO CHANGE IN OUTCOMES. On a fresh copy of the staged tree: the full suite (report any failure; a timing test that fails only under load must pass when re-run alone, say so); both corpora compared case by case with ${RG}/close-3/corpus-dev and corpus-holdout (any verdict, name or releasability that differs is an issue, high); every arena round on fresh copies compared answer by answer with ${RG}/close-3/arena (any receipt that differs is an issue, high); read git -C ${IT} diff --cached of the files changed since argdiag-close3-snapshot (git -C ${IT} diff argdiag-close3-snapshot -- . compares the snapshot with the worktree; use git diff --cached against the snapshot's tree for the index) and confirm that only patterns, readers, their tests and the docs changed and that no test was weakened. ok only with no issue.`
const VLENSES = [{ key: 'security', prompt: SEC }, { key: 'outcomes', prompt: REG }]
const verifyPrompt = (l, k) => `${CTX}
YOU ARE AN INDEPENDENT VERIFIER (read-only on ${IT}, ${R} and ${BT}: never modify a checkout, index or branch; work in ${SF}/verify-${k}/${l.key}/). ${TREES}
Try to find what is still wrong; default to reporting a doubt as an issue with its evidence.
${l.prompt}`
const short = (x, n) => String(x || '').slice(0, n)
let fix = null, vs = null, open = []
const history = []
for (let k = 1; k <= 2; k++) {
  phase('Fix')
  const extra = k === 1 ? '' : `THIS IS SECURITY ROUND ${k}. The independent verifiers of round ${k - 1} found these issues (their inputs and times are in ${SF}/verify-${k - 1}/): ${JSON.stringify(open.map(x => ({ lens: x.lens, id: x.id, severity: x.severity, area: short(x.area, 300), problem: short(x.problem, 1500), evidence: short(x.evidence, 1500) })))}. An earlier attempt at this round may have been stopped part-way, so ${IT} may already hold some of its edits: inspect them, keep what is correct and finish the rest.`
  fix = await agent(fixPrompt(k, extra), { label: `secfix:${k}`, phase: 'Fix', schema: FIX, effort: 'max' })
  if (!fix || !fix.staged) break
  phase('Verify')
  vs = await parallel(VLENSES.map(l => () => agent(verifyPrompt(l, k), { label: `secverify:${l.key}:${k}`, phase: 'Verify', schema: VER, effort: 'high' })))
  history.push(vs.map((v, i) => v ? { lens: VLENSES[i].key, ok: v.ok, measured: short(v.measured, 1500), issues: v.issues.map(x => `${x.severity} ${x.id}: ${short(x.problem, 200)}`) } : { lens: VLENSES[i].key, ok: false, measured: 'verifier failed' }))
  open = vs.flatMap((v, i) => v ? v.issues.filter(x => x.severity === 'high').map(x => ({ lens: VLENSES[i].key, ...x })) : [{ lens: VLENSES[i].key, id: 'verifier-failed', area: 'verification', severity: 'high', problem: 'the verifier did not return; re-measure this lens' }])
  if (!open.length) break
}
return { fix, history, verify: vs, open, ok: !!(fix && fix.staged && vs && !open.length) }
