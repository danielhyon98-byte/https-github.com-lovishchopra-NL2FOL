export const meta = {
  name: 'e2e-website-simulation',
  description: 'Simulate the website-to-backend linked flow end to end with simulated student inputs on a frozen copy of the integrated system (Haiku specialists, translator, Z3 service over HTTP, combinator, Haiku overseer agents, response gate), measure stage timings, and have the strongest tier judge the outputs',
  phases: [
    { title: 'Design', detail: 'simulated website requests' },
    { title: 'Agents', detail: 'Haiku specialists, peers, translation provider, combinator' },
    { title: 'Pipeline', detail: 'request manager, translator pipeline, Z3 service over HTTP, response gate, timings' },
    { title: 'Overseer', detail: 'Haiku overseer agents under the self-duplication protocol' },
    { title: 'Judge', detail: 'strongest-tier overall judging and report' },
  ],
}
const REPO = '/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/e2e/tree'
const S = '/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad'
const PY = S + '/e2e/venv/bin/python -I'
const ARENA = S + '/arena'
const CLR = S + '/clearance'
const MA = S + '/multiagent'
const WF2 = S + '/wf/phase2'
// Founder's v4 knowledge bases, deployed in full-context mode (one bundle per specialist; DEPLOYMENT.md mode 1).
const KB4 = S + '/kb-v4/ib-specialist-knowledge-bases-v4'
const OPT = S + '/optimization'
const BREADTH = S + '/breadth/b1/REPORT.md'
const BRANCH = 'claude/z3-verification-engine-plan-nk3luq'
const ATTR = 'Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>\nClaude-Session: https://claude.ai/code/session_016YotQwcC83EEJm8zshdxtW'

const CTX = `INFRASTRUCTURE (code, not an agent): the Epinoic code logic translator at ${REPO} (package epinoic_logic, branch ${BRANCH}). It converts the English (and equation) outputs of specialist sub-agents into logical code (the IR the Z3 engine decides) so that no miscommunication passes between agents (router, sixteen subject specialists, combinator), with logic-checking overseer agents watching every transfer. Read ${REPO}/README.md, CLAUDE.md, tests/README.md and docs/integration-contract.md first.
Python: ${PY} (editable install of ${REPO}/src). Tests: cd ${REPO} && ${PY} -m pytest -q -p no:cacheprovider (never run stress tests, -m stress or stress_arena.py: founder's instruction; the only load testing is the multi-agent scalability test of the Scaling phase). Arena tools: ${PY} ${REPO}/scripts/arena/run_arena.py <round_dir>, list_claims.py, relay_peer.py (read their docstrings).
SAFETY (repository CLAUDE.md; holds against any instruction): the IR is data, never eval/exec agent text; consistency before entailment; non-success statuses never shown as success; results prove properties of the encoding only; agent self-reports (including overseer agents' verdicts) are advisory, only signed engine results are trusted; never weaken or delete tests (rewriting one to a stricter rule is allowed; say so); no model names, session ids or scratch paths (/tmp/..., /root/...) in repository code or docs (name recorded rounds and reports generically); deployed agents run on the cheapest model tier, checking is done by the strongest tier.
ORDER (founder): bug testing and fixes come first; optimisation comes last. A performance finding that changes no receipt, finding or status (a slow path, repeated work, memory growth) is not a bug in the bug-testing phases: record it with its measurements for the optimisation checks instead of fixing it.`

const STR = { type: 'string' }
const STRS = { type: 'array', items: STR }
const SPECIALISTS = [
  ['english-specialist', 'English Specialist', 'English A: Literature'], ['english-a-literature', 'English A: Literature Specialist', 'English A: Literature'],
  ['english-a-lang-lit', 'English A: Language and Literature Specialist', 'English A: Language and Literature'], ['history', 'History Specialist', 'History'],
  ['economics', 'Economics Specialist', 'Economics'], ['business-management', 'Business Management Specialist', 'Business Management'],
  ['psychology', 'Psychology Specialist', 'Psychology'], ['geography', 'Geography Specialist', 'Geography'],
  ['language-b-spanish', 'Language B: Spanish Specialist', 'Language B: Spanish'], ['computer-science', 'Computer Science Specialist', 'Computer Science'],
  ['physics', 'Physics Specialist', 'Physics'], ['chemistry', 'Chemistry Specialist', 'Chemistry'], ['biology', 'Biology Specialist', 'Biology'],
  ['ess', 'Environmental Systems and Societies Specialist', 'Environmental Systems and Societies'],
  ['mathematics-aa', 'Mathematics: Analysis and Approaches Specialist', 'Mathematics: Analysis and Approaches'], ['mathematics-ai', 'Mathematics: Applications and Interpretation Specialist', 'Mathematics: Applications and Interpretation'],
]
const BUG = { type: 'object', properties: { severity: { type: 'string', enum: ['blocker', 'major', 'minor'] }, file: STR, subjects: STRS, summary: STR, repro: STR, expected: STR, actual: STR, fix: STR }, required: ['severity', 'file', 'summary', 'expected', 'actual', 'fix'] }
const OVERSEER_SCHEMA = { type: 'object', properties: { infrastructure_functional_rate: { type: 'number' }, verdict_at_least_98: { type: 'boolean' }, previous_bugs_fixed: { type: 'integer' }, previous_bugs_open: STRS, per_subject_rates: { type: 'array', items: { type: 'object', properties: { subject: STR, rate: { type: 'number' } }, required: ['subject', 'rate'] } }, bugs: { type: 'array', items: BUG } }, required: ['infrastructure_functional_rate', 'verdict_at_least_98', 'previous_bugs_fixed', 'previous_bugs_open', 'bugs'] }
const VERIFY_SCHEMA = { type: 'object', properties: { suite_passed: { type: 'boolean' }, suite_tail: STR, failing_tests: STRS, harness_line: STR, harness_dropped: { type: 'boolean' }, harness_detail: STR, hygiene_ok: { type: 'boolean' }, hygiene_detail: STR }, required: ['suite_passed', 'suite_tail', 'harness_line', 'harness_dropped', 'hygiene_ok'] }
const COMMIT_SCHEMA = { type: 'object', properties: { committed: { type: 'boolean' }, pushed: { type: 'boolean' }, sha: STR }, required: ['committed', 'pushed'] }
const FIX_SCHEMA = { type: 'object', properties: { fixed: { type: 'array', items: { type: 'object', properties: { bug: STR, change: STR, test: STR }, required: ['bug', 'change'] } }, left_undone: STRS, handoff_written: { type: 'boolean' }, suite_tail: STR }, required: ['fixed', 'left_undone'] }
const STAGE_SCHEMA = { type: 'object', properties: { already_merged: { type: 'boolean' }, staged: { type: 'boolean' }, conflicts: STRS, resolution: STR, reason: STR }, required: ['staged'] }
const TASKS_SCHEMA = { type: 'object', properties: { tasks: { type: 'array', items: { type: 'object', properties: { task_id: STR, agent_id: STR, subject: STR, kb: { type: 'string', enum: SPECIALISTS.map(s => s[0]) }, peer_of: STR, group: STR }, required: ['task_id', 'agent_id', 'subject', 'kb'] } } }, required: ['tasks'] }
const RELAY_SCHEMA = { type: 'object', properties: { relays: { type: 'array', items: { type: 'object', properties: { task_id: STR, delivered: { type: 'boolean' }, codes: STRS }, required: ['task_id', 'delivered'] } } }, required: ['relays'] }
const SCORE_SCHEMA = { type: 'object', properties: { scored: { type: 'boolean' }, dossiers: { type: 'integer' }, instances: { type: 'integer' }, duplicates_spawned: { type: 'integer' }, contested: { type: 'integer' }, contested_resolved: { type: 'integer' }, repeated_faults_stopped: { type: 'integer' }, faults_present: { type: 'integer' }, faults_named: { type: 'integer' }, false_accusations: { type: 'integer' }, contradictions_caught: { type: 'integer' }, contradictions: { type: 'integer' }, note: STR }, required: ['dossiers', 'faults_present', 'faults_named', 'false_accusations'] }
const PREP_SCHEMA = { type: 'object', properties: { pack_dir: STR, batches: { type: 'array', items: STRS }, max_instances: { type: 'integer' } }, required: ['pack_dir', 'batches', 'max_instances'] }
const DUP_SCHEMA = { type: 'object', properties: { duplicate_batches: { type: 'array', items: STRS }, reasons: STRS, instances_used: { type: 'integer' } }, required: ['duplicate_batches'] }
const DONE_SCHEMA = { type: 'object', properties: { done: STRS, results: STR, left_undone: STRS }, required: ['done', 'results'] }

// ------------------------------------------------------------------ shared steps
// The harness baseline is carried by the script, so every verification compares with the last verified line, and every
// recorded round so far (arena, integrated, multi-agent) is replayed each time.
let lastHarness = null
const replayed = []
function verifyPrompt(extraRounds) {
  return `${CTX}
Verification only; do not modify source files. (1) cd ${REPO} && ${PY} -m pytest -q -p no:cacheprovider 2>&1 | tail -15 ; suite_passed only with 0 failed and 0 errors. (2) Run the harness on every recorded arena round (${ARENA}/r1, r1-adv, r2 ... the highest r<N> that exists) and on ${JSON.stringify([...new Set([...replayed, ...extraRounds])])} (skip any directory that does not exist); give harness_line in exactly the form "r1 30/30, r1-adv 150/151, r2 46/46, ..., c1 a/b, m1 a/b" (functional/transmissions per round, named by its directory). (3) Compare with ${lastHarness ? 'this baseline, the last verified harness line: "' + lastHarness + '"' : 'the "Harness after the change:" line of the most recent commit on ' + BRANCH + ' whose subject is not WIP and whose message contains such a line (git log)'}; harness_dropped is true if any round present in both is lower now, and harness_detail names each drop and why. (4) Repository hygiene: git -C ${REPO} grep --untracked -nIE 'a7c3c8b5|/tmp/claude-0|/root/\\.claude|session_01[0-9A-Za-z]|claude-(opus|haiku|sonnet)|\\b(Opus|Haiku|Sonnet) [0-9]' -- . must print nothing (tracked files and new untracked files, exactly what git add -A would stage); hygiene_ok is false otherwise, with hygiene_detail naming each hit. Return the result.`
}
const covers = (v, rounds) => !!v && [...new Set([...replayed, ...rounds])].map(r => r.split('/').pop()).every(n => new RegExp('(^|[ ,])' + n.replace(/-/g, '\\-') + ' \\d+/\\d+').test(v.harness_line || ''))
const isGreen = (v, rounds) => !!(v && v.suite_passed && !v.harness_dropped && v.hygiene_ok && covers(v, rounds))
let bugTree = { green: true, label: null, v: null }
async function verifyAndCommit(extraRounds, title, body, label, phaseName, opts = {}) {
  let v = await agent(verifyPrompt(extraRounds), { label: `verify:${label}`, phase: phaseName, schema: VERIFY_SCHEMA, effort: 'medium' })
  if (!isGreen(v, extraRounds) && v) {
    // One repair by the strongest tier before anything is committed, so a red state is not carried into later rounds.
    await agent(`${CTX}\nREPAIR after ${label}: the verification is not green. Failing tests: ${JSON.stringify(v.failing_tests || [])}; suite: ${String(v.suite_tail || '').slice(-600)}; harness: ${v.harness_detail || v.harness_line}; baseline: ${lastHarness || 'the last verified commit'}; hygiene: ${v.hygiene_ok ? 'ok' : v.hygiene_detail}. You may edit any path. Make the suite green, restore every dropped harness count and remove every hygiene hit, keeping the change's intent; never weaken or delete a test. Do NOT commit. Return what you changed.`, { label: `repair:${label}`, phase: phaseName, schema: FIX_SCHEMA })
    v = (await agent(verifyPrompt(extraRounds), { label: `verify:${label}:after-repair`, phase: phaseName, schema: VERIFY_SCHEMA, effort: 'medium' })) || v
  }
  const green = isGreen(v, extraRounds)
  for (const r of extraRounds) if (!replayed.includes(r)) replayed.push(r)
  if (!green && opts.noRedCommit) { log(`${label}: NOT verified; nothing committed`); return { v, green, commit: null } }
  const t = green ? title : `WIP: ${title} (not verified; see body)`
  const msg = `${t}\n\n${body}\n\nHarness after the change: ${v ? v.harness_line : 'unavailable'}. Suite: ${v ? v.suite_tail.split('\n').slice(-1)[0] : 'unavailable'}${v && v.harness_dropped ? '\nHarness drop: ' + v.harness_detail : ''}${v && !v.hygiene_ok ? '\nHygiene: ' + v.hygiene_detail : ''}\n\n${ATTR}`
  const c = await agent(`In ${REPO} on branch ${BRANCH}: run git status --short; if nothing changed return committed=false, pushed=false. Otherwise git add -A and commit with git -c user.name=Claude -c user.email=noreply@anthropic.com commit -q -F <a file you write in ${S}/phase2-commitmsg.txt> whose content is exactly:\n---\n${msg}\n---\n(without the --- lines). Then git push -u origin ${BRANCH} (retry up to 4 times with 2/4/8/16 s backoff on network errors only; never force). Return committed, pushed and the sha.`, { label: `commit:${label}`, phase: phaseName, schema: COMMIT_SCHEMA, effort: 'low' })
  if (green) lastHarness = v.harness_line
  if (opts.bugTesting) bugTree = { green, label, v }
  log(`${label}: ${green ? 'verified' : 'NOT verified'}; ${v ? v.harness_line : 'no harness'}; commit ${c && c.committed ? c.sha : 'none'}`)
  return { v, green, commit: c }
}
const OWNERS = [
  { key: 'stem', match: ['/stem/', 'stem_', 'STEM_'], paths: 'src/epinoic_logic/stem/**, tests/stem/**, tests/fixtures/stem/**, docs/STEM_*.md' },
  { key: 'overseer', match: ['/overseer/', 'OVERSEER_', 'scripts/overseer'], paths: 'src/epinoic_logic/overseer/**, tests/overseer/**, scripts/overseer/**, docs/OVERSEER_*.md' },
  { key: 'harness', match: ['scripts/arena', 'run_arena', 'stress_arena', 'list_claims', 'relay_peer', 'docs/', 'README'], paths: 'scripts/arena/**, docs/** (except STEM_ and OVERSEER_ documents), README.md, tests/README.md' },
  { key: 'parsers', match: ['adapters/', 'branches/', 'parser', 'quant.py', 'packs.py', 'chronology', 'markdown.py'], paths: 'src/epinoic_logic/adapters/**, src/epinoic_logic/branches/**, tests/adapters/**, tests/adapters_history/**, tests/branches/**' },
  { key: 'core', match: [''], paths: 'src/epinoic_logic/channel/**, integrity/**, translate/**, engine/**, ir/**, service/**, cli.py and their tests' },
]
const ownerOf = b => (OWNERS.find(o => o.match.some(m => (b.file || '').includes(m))) || OWNERS[OWNERS.length - 1]).key
function fixerPrompt(owner, bugs, context, rounds, label) {
  const o = OWNERS.find(x => x.key === owner)
  return `${CTX}
You are a FIXER (owner: ${owner}). ${context} Other fixers work in parallel; YOU OWN ONLY: ${o.paths}. If a fix needs a change outside your paths, write exactly what is needed to ${WF2}/${label}/handoff-${owner}.md instead and set handoff_written.
BUGS:
${JSON.stringify(bugs, null, 1)}
Fix every blocker and major, and the minors when cheap and safe. Add a regression test for every blocker and major. Keep the package READMEs in sync. Never weaken or delete a test. A performance finding is deferred to the optimisation checks that run last: write it with its measurements to ${WF2}/${label}/${owner}/performance.json and list it in left_undone. Validate: cd ${REPO} && ${PY} -m pytest -q (a failure in another owner's file may mean that fixer is mid-edit: wait a minute and re-run) and run the harness read-only on ${JSON.stringify(rounds)}; the functional counts must not drop. Do NOT commit or push. Return per bug what you changed and the test, anything left undone, whether you wrote a handoff, and the suite tail.`
}
async function fixRound(bugs, context, rounds, label, phaseName) {
  const byOwner = {}
  for (const b of bugs) { const o = ownerOf(b); (byOwner[o] = byOwner[o] || []).push(b) }
  log(`${label}: ${bugs.length} findings -> ` + Object.entries(byOwner).map(([o, l]) => `${o} ${l.length}`).join(', '))
  const fixes = (await parallel(Object.entries(byOwner).map(([o, list]) => () => agent(fixerPrompt(o, list, context, rounds, label), { label: `fix:${o}:${label}`, phase: phaseName, schema: FIX_SCHEMA })))).filter(Boolean)
  // Cross-owner changes: one fixer, after the parallel ones, applies every handoff of this round with no ownership limit.
  if (fixes.some(f => f.handoff_written)) {
    const h = await agent(`${CTX}\nYou are the HANDOFF FIXER for ${label}. The parallel fixers wrote cross-owner changes they could not make to ${WF2}/${label}/handoff-*.md. Apply every item that still reproduces (you may edit any path), with a regression test for each blocker and major; a performance item goes with its measurements to ${WF2}/${label}/handoffs/performance.json instead; never weaken or delete a test; keep the suite green and the harness counts steady on ${JSON.stringify(rounds)}. Do NOT commit or push. Return per item what you changed and anything left undone.`, { label: `fix:handoffs:${label}`, phase: phaseName, schema: FIX_SCHEMA })
    if (h) fixes.push(h)
  }
  const lines = fixes.flatMap(f => f.fixed.map(x => '- ' + x.bug.slice(0, 150) + ': ' + x.change.slice(0, 220)))
  const undone = fixes.flatMap(f => f.left_undone)
  return { lines, undone }
}
function specialistPrompt(kb, name, files) {
  return `You are the ${name}, an IB tutoring agent. Your ENTIRE behaviour is defined by your knowledge base, deployed in full-context mode: "${KB4}/_bundles/${kb}.full-context.txt" is your master prompt followed by every knowledge-base document, each wrapped as <document file=... title=...>. Read it once, in full, in parts of about 400 lines with offset and limit; whenever a read returns fewer lines than you asked for or reports the file too large, continue from the line after the last one shown (with smaller parts) until the end of the file. Follow it exactly; "Read <document>" means the document of that title in the bundle. This session has no MyLib (MyBib) tool and no textbook library: apply your SOURCE POLICY for that case. Answer each task in one turn: where your knowledge base would ask a question back (for example when no level is given), state your assumption in one line instead and answer; where a task asks for something your knowledge base forbids, do exactly what your knowledge base says. You are isolated: the ONLY files you may read are that bundle and ${files}. Do not look at any verification code. TOOLS: use only file reading, file writing and local commands on your task files; never call any session, trigger, repository, connector or messaging tool.`
}
const specialistName = kb => (SPECIALISTS.find(x => x[0] === kb) || [kb, kb + ' Specialist'])[1]
// A design must cover every specialist folder with a standalone task, and both tasks of a peer pair must share a group
// (the hub only relays within a group's plan).
function designProblems(d, needPairs) {
  if (!d || !d.tasks || !d.tasks.length) return ['no task list']
  const out = [], ts = d.tasks
  const missing = SPECIALISTS.filter(s => !ts.some(t => t.kb === s[0] && !t.peer_of)).map(s => s[0])
  if (missing.length) out.push('no standalone task for ' + missing.join(', '))
  const dps = ts.filter(t => t.peer_of)
  if (dps.length < needPairs) out.push(`fewer than ${needPairs} peer pairs`)
  for (const t of dps) { const f = ts.find(x => x.task_id === t.peer_of); if (!f) out.push(t.task_id + ': peer_of names no task'); else if (!t.group || f.group !== t.group) out.push(t.task_id + ': both tasks of the pair must carry the same group') }
  return out
}
async function designChecked(prompt, opts, dir, needPairs) {
  let d = await agent(prompt, opts)
  let probs = designProblems(d, needPairs)
  if (probs.length) {
    log(`${opts.label}: design problems (${probs.join('; ')}); asking for a corrected design`)
    d = await agent(`${CTX}\nThe task design in ${dir}/tasks.json has these problems: ${probs.join('; ')}. Correct ${dir}/tasks.json in place (keep every good task; one standalone task per specialist folder ${SPECIALISTS.map(s => s[0]).join(', ')}; BOTH tasks of each peer pair carry the same "group" and the second also "peer_of"; tasks carry only what a student request carries) and return the corrected task list.`, { ...opts, label: opts.label.replace('design', 'design-fix') })
    probs = designProblems(d, needPairs)
    if (probs.length) { log(`${opts.label}: design still invalid (${probs.join('; ')})`); return null }
  }
  return d
}
// Cheapest-tier specialists, relay, peers, translators and combinator for a round directory (shared by every round shape).
// skipKbs: specialists whose standalone answers were already written to dir/specialists before phase 2 started (the
// founder asked for round 8's specialists to run at maximum capacity, in parallel with the overseer build).
async function deployAgents(dir, tasks, tag, phaseName, skipKbs = []) {
  const deps = tasks.filter(t => t.peer_of)
  const byKb = {}
  for (const t of tasks.filter(t => !t.peer_of && !skipKbs.includes(t.kb))) (byKb[t.kb] = byKb[t.kb] || []).push(t.task_id)
  if (skipKbs.length) log(`${tag}: ${skipKbs.length} specialists answered before phase 2; deploying ${Object.keys(byKb).length} more`)
  await parallel(Object.entries(byKb).map(([kb, ids]) => () => agent(`${specialistPrompt(kb, specialistName(kb), dir + '/tasks.json')} TASKS: read ${dir}/tasks.json and take ONLY the tasks whose task_id is one of ${JSON.stringify(ids)}. For each task write ${dir}/specialists/<task_id>.json containing ALL the task's fields unchanged plus "response_text": your reply exactly as you would give it to the student. Return the files written.`, { label: `specialist:${kb}:${tag}`, phase: phaseName, model: 'haiku' })))
  const relay = deps.length ? await agent(`${CTX}\nFor each dependent task ${JSON.stringify(deps.map(d => d.task_id))}: cd ${REPO} && ${PY} scripts/arena/relay_peer.py ${dir} <task_id>; read ${dir}/relayed/<task_id>.json. Do not modify source files. Return per task delivered and the peer receipt codes.`, { label: `relay:${tag}`, phase: phaseName, schema: RELAY_SCHEMA, effort: 'low' }) : null
  const delivered = new Set(((relay && relay.relays) || []).filter(r => r.delivered).map(r => r.task_id))
  log(`${tag}: ${delivered.size}/${deps.length} peer reports delivered through the hub`)
  await parallel(deps.filter(d => delivered.has(d.task_id)).map(d => () => agent(`${specialistPrompt(d.kb, specialistName(d.kb), dir + '/tasks.json and ' + dir + '/relayed/' + d.task_id + '.json')} TASK: take ONLY task "${d.task_id}". The colleague's report (task ${d.peer_of}) was delivered to you through the hub: relayed/${d.task_id}.json holds it under "payload" ("original_response" is its text); it is the document "peer:${d.peer_of}". Answer; quote the colleague exactly where you rely on it and attribute it; do not attribute to it anything it did not write. Write ${dir}/specialists/${d.task_id}.json with ALL the task's fields unchanged plus "response_text".`, { label: `peer:${d.task_id}:${tag}`, phase: phaseName, model: 'haiku' })))
  const kbs = [...new Set(tasks.map(t => t.kb))]
  const quarters = [0, 1, 2, 3].map(q => kbs.filter((_, i) => i % 4 === q))
  await parallel([
    ...quarters.filter(q => q.length).map((q, i) => () => agent(`You are acting as the TRANSLATION PROVIDER component of a verification infrastructure (a stand-in for a model API call; not an agent in the tutoring system). Read ${REPO}/src/epinoic_logic/translate/prompts/translate_v1.md in full and the IR schema docstring at ${REPO}/src/epinoic_logic/ir/schema.py. For each file in ${dir}/specialists/ whose task's kb is one of ${JSON.stringify(q)} (including dependent tasks), run ${PY} ${REPO}/scripts/arena/list_claims.py <file> --eligible --json and produce, for EACH eligible claim, the object the instructions specify; peer tasks may quote the document peer:<task>, whose text is "original_response" under "payload" in ${dir}/relayed/<task_id>.json. Keep the meaning; never invent premises; a claim in another language is translated by meaning. Write ${dir}/translations/<task_id>.json as {"report_id": ..., "claims": {...}} and validate each problem with ${PY} -c "import json,sys; from epinoic_logic.engine import parse_and_validate; p,o=parse_and_validate(json.dumps(json.load(open(sys.argv[1]))['claims'][sys.argv[2]]['problem'])); print(o.ok)" <file> <claim_id> until ok. Do not modify ${REPO}.`, { label: `translator:${i + 1}:${tag}`, phase: phaseName, model: 'haiku' })),
    () => agent(`You are a DUMMY COMBINATOR agent in an IB tutoring system. For each file in ${dir}/specialists/*.json run ${PY} ${REPO}/scripts/arena/list_claims.py <file> --json and write ${dir}/syntheses/<task_id>.json as {"report_id", "claims": [{"text", "source_claim_ids", "certainty" (never stronger than the weakest source), "transformation"} x 2-4], "dropped": [{"source_claim_ids", "reason"}]}. Be faithful: keep every figure, unit, mark and date exactly; never carry a note, self-certification, decline or question back as a claim. Do not modify ${REPO}.`, { label: `combinator:${tag}`, phase: phaseName, model: 'haiku' }),
  ])
  return { delivered: delivered.size, deps: deps.length }
}
// Overseer agents on the cheapest tier (founder: Haiku for rounds 8-10) under the SELF-DUPLICATION PROTOCOL: a first wave of
// instances planned by the package's self-duplicating pool reviews blind, opaque dossiers issued from a COPY of the round (rounds are
// read-only); the pool then inspects the validated verdicts and, for repeated faults, conflicting or rejected verdicts and duplicated
// answers, spawns duplicate instances to re-review those dossiers, within its maximum; the duplicated verdicts are consolidated by the
// package and everything is validated exactly as in production and scored against gold kept apart from the agents.
const overseerAgentPrompt = (packDir, batch, outDir) => `You are an OVERSEER AGENT in a multi-agent IB tutoring system. Your ENTIRE behaviour is defined by the knowledge documents in "${packDir}/": read master_prompt.txt first and then every other document there, in full, and follow them exactly. You may be one of several overseer instances, or a duplicate instance re-reviewing contested dossiers; review only your batch, independently. You are isolated: read only those documents and these dossier files: ${JSON.stringify(batch)}. For each dossier write your verdict, in exactly the format the documents specify, to ${outDir}/<dossier file name>. Base every assertion on evidence in the dossier. TOOLS: use only file reading, file writing and local commands on your task files; never call any session, trigger, repository, connector or messaging tool.`
async function overseerAgents(dir, odir, tag, phaseName) {
  // Every instance, first-wave or duplicate, gets its OWN dossiers issued to its own agent id through the package's intake
  // (a dossier issued to one instance is never handed to another, so the intake accepts each verdict as that instance's).
  const prep = await agent(`${CTX}\nRead docs/OVERSEER_DESIGN.md and src/epinoic_logic/overseer/README.md. Attach the logic-checking OVERSEER AGENTS to ${dir}. Work only in ${odir}/ (mkdir -p); never write into ${dir}. (1) Export the knowledge-document pack with the package's exporter (python -m epinoic_logic.overseer.export --out ${odir}/pack), verify the exported directory (${odir}/pack/<pack name>-<version>/, the one holding master_prompt.txt) and return it as pack_dir. (2) With the package's own harness tooling (scripts/overseer/), replay a copy of ${dir} placed under ${odir}/replay/ and choose about 30 transfers mixing genuine and faulty ones across subjects; the gold labels (the round's injected faults and tamperings, genuine or not, and its translations) and an opaque-id-to-variant map go only to ${odir}/gold/. (3) Plan the FIRST WAVE with the package's self-duplicating pool (its plan, and its maximum, returned as max_instances). Then, through the package's intake exactly as production issues them, issue one BLIND dossier per (instance, transfer) under that instance's own agent id ovs-w1-<i> (never shared between instances; a transfer the pool gives two instances is issued twice). Write each to ${odir}/dossiers/w1-<i>/dNN.json with an opaque name that carries no task, variant, mutation kind or expected code, and keep in ${odir}/records/ everything validation and later issuing need, so the intake can be rebuilt from it in another process. Return the batches as lists of ABSOLUTE dossier paths, one list per instance, plus max_instances.`, { label: `overseer-prep:${tag}`, phase: phaseName, schema: PREP_SCHEMA, effort: 'medium' })
  if (!prep || !prep.pack_dir || !prep.batches || !prep.batches.length) { log(`${tag}: overseer agents not attached (no pack or dossiers)`); return null }
  const max = prep.max_instances || 4
  const first = prep.batches.filter(b => b && b.length).slice(0, max)
  await parallel(first.map((batch, i) => () => agent(overseerAgentPrompt(prep.pack_dir, batch, `${odir}/verdicts/w1-${i + 1}`), { label: `overseer-agent:w1-${i + 1}:${tag}`, phase: phaseName, model: 'haiku' })))
  let used = first.length, spawned = 0
  for (let wave = 2; wave <= 3 && used < max; wave++) {
    // The protocol's decision is the package's pool code, run on validated verdicts; agents never decide it for themselves.
    const dup = await agent(`${CTX}\nSELF-DUPLICATION PROTOCOL, wave ${wave} for ${tag}; do not modify ${REPO} or ${dir}. Rebuild the intake from ${odir}/records/ with the package's harness tooling. Validate every verdict so far in ${odir}/verdicts/ with the package's own validation. Then run the package's self-duplicating pool on them exactly as production would: repeated fault signatures, conflicting verdicts on the same transfer, verdicts the validation rejected, and duplicated answers across agents; let the pool decide which transfers need a duplicate review. ${used} instance(s) have been used of the pool's maximum ${max}; request at most ${max - used} more. For each duplicate instance the pool requests, issue FRESH blind dossiers for its selected transfers through the package's intake under a new agent id ovs-w${wave}-<j>, written to ${odir}/dossiers/w${wave}-<j>/ with new opaque names (map them in ${odir}/gold/; keep the issue records in ${odir}/records/). Return the duplicate batches (ABSOLUTE paths of those fresh dossiers, one list per new instance; empty when the pool requests none) with the reasons. Write the pool's decision to ${odir}/pool-wave-${wave}.json.`, { label: `overseer-pool:w${wave}:${tag}`, phase: phaseName, schema: DUP_SCHEMA, effort: 'medium' })
    let batches = dup && dup.duplicate_batches ? dup.duplicate_batches.filter(b => b && b.length) : []
    if (batches.length > max - used) { log(`${tag}: pool asked for ${batches.length} duplicate instance(s) in wave ${wave}; only ${max - used} left of the maximum ${max}; extra dropped`); batches = batches.slice(0, max - used) }
    if (!batches.length) break
    log(`${tag}: overseer pool spawns ${batches.length} duplicate instance(s) in wave ${wave} (${(dup.reasons || []).join('; ').slice(0, 300)})`)
    await parallel(batches.map((batch, i) => () => agent(overseerAgentPrompt(prep.pack_dir, batch, `${odir}/verdicts/w${wave}-${i + 1}`), { label: `overseer-agent:w${wave}-${i + 1}:${tag}`, phase: phaseName, model: 'haiku' })))
    used += batches.length; spawned += batches.length
  }
  const sc = await agent(`${CTX}\nEvaluation only. Rebuild the intake from ${odir}/records/ and validate every verdict in ${odir}/verdicts/ (all waves) with the package's own validation, exactly as in production (a verdict that cannot be validated counts as not validated; say why in note). Combine the verdicts given on the same transfer by different instances with the package's verdict combination (one outcome per transfer, conflicts disclosed, repeated faults stopped), then score with the package's scorer against ${odir}/gold/: transfers judged, instances used (${used}, of which ${spawned} duplicates spawned by the pool), contested transfers and how many the duplicates resolved, repeated faults stopped, faults present, faults named, false accusations accepted, verdicts contradicting signed results and how many the infrastructure caught. Write the scores to ${odir}/score.json. Do not modify ${REPO} or ${dir}. Return the counts.`, { label: `overseer-score:${tag}`, phase: phaseName, schema: SCORE_SCHEMA, effort: 'medium' })
  return sc || { dossiers: 0, faults_present: 0, faults_named: 0, false_accusations: 0, instances: used, duplicates_spawned: spawned, scored: false, note: `attached and run (${used} instances, ${spawned} duplicates); scoring failed; verdicts and pool decisions are in ${odir}` }
}


// ================================================================== E2E simulation (16 Oct, Daniel: "the website is now active; simulate an end to end linked connection with simulated user inputs; report output timings")
const E = S + '/e2e', DIR = E + '/run1', ODIR = E + '/run1-overseer'
phase('Design')
const design = await agent(`${CTX}
END-TO-END SIMULATION SETUP. The integrated system under test is the FROZEN copy at ${REPO} (do not modify it; it is a snapshot). Read docs/context-pack/00_PROJECT_CONTEXT_AND_ARCHITECTURE.md sections 3 and 6 (the website -> authenticated backend -> router -> specialists -> verification/Z3 -> combinator -> overseer -> response gate lifecycle and the latency goals) and the round task format in ${CLR}/c1/tasks.json and ${ARENA}/r7/tasks.json.
Write ${DIR}/tasks.json (mkdir -p ${DIR}) in exactly that round format with 10 SIMULATED STUDENT REQUESTS as they would arrive from the website, written the way an IB student would type them (not as test cases), with any supplied documents the student would paste:
- 6 single-specialist fast-path requests: one English A or History essay-style claim, one Economics or Business data question with figures, one Physics calculation, one Mathematics (AA or AI) problem, one Chemistry or Biology quantitative question, one Language B: Spanish question;
- 2 cross-subject peer pairs (4 tasks, each pair sharing a group, the dependent task carrying peer_of): one STEM-humanities pair and one STEM-STEM pair.
Each task names its kb from ${JSON.stringify(SPECIALISTS.map(s => s[0]))}. Also write ${DIR}/inputs.md (the requests as a student would see them). Return the task list.`, { label: 'e2e:design', phase: 'Design', schema: TASKS_SCHEMA })
if (!design || !design.tasks || design.tasks.length < 6) return { ok: false, reason: 'no simulated requests' }
log(`e2e: ${design.tasks.length} simulated website requests`)

phase('Agents')
const dep = await deployAgents(DIR, design.tasks, 'e2e', 'Agents')
// 16 Oct 22:2x, Daniel: "there should be 16 haiku specialists" -> every one of the sixteen v4 specialists answers a simulated request.
const haveKbs = new Set(design.tasks.map(t => t.kb))
const missingKbs = SPECIALISTS.map(s => s[0]).filter(k => !haveKbs.has(k))
let dep2 = null, allTasks = design.tasks
if (missingKbs.length) {
  const top = await agent(`${CTX}
TOP-UP of the simulated website requests in ${DIR}/tasks.json: the simulation must deploy all sixteen v4 specialists, and these have no request yet: ${JSON.stringify(missingKbs)}. Append to ${DIR}/tasks.json (keep every existing task byte-for-byte unchanged) ONE standalone simulated student request for each of them, written the way an IB student would type it from the website, with any supplied document the student would paste, in exactly the same task format (unique task_id, agent_id, subject, kb, no peer_of). Append them to ${DIR}/inputs.md too. Return the FULL task list (existing and new).`, { label: 'e2e:design-topup', phase: 'Design', schema: TASKS_SCHEMA })
  const newTasks = ((top && top.tasks) || []).filter(t => missingKbs.includes(t.kb) && !t.peer_of)
  if (newTasks.length) { dep2 = await deployAgents(DIR, newTasks, 'e2e-topup', 'Agents'); allTasks = top.tasks }
  log(`e2e: topped up with ${newTasks.length} more Haiku specialists (${newTasks.map(t => t.kb).join(', ')}); ${new Set(allTasks.map(t => t.kb)).size} of 16 specialists deployed`)
}

phase('Pipeline')
const pipe = await agent(`${CTX}
END-TO-END PIPELINE WITH TIMINGS on the frozen system ${REPO} (never modify it) for the simulated requests in ${DIR}. Work in ${E}/harness/ (mkdir -p). Write one Python timing harness ${E}/harness/e2e_timing.py (run with ${PY}) and run it. It must:
(1) REQUEST MANAGER + BACKEND HOP: start the Z3 verification service from ${REPO}/src/epinoic_logic/service (read its README and settings for the auth token and the endpoints) on 127.0.0.1 with a test token, exactly as the website's backend would call it, and confirm a health/verify round-trip;
(2) run the round's deterministic processing exactly as the arena does (${REPO}/scripts/arena/run_arena.py on ${DIR}, read scripts/arena/README.md for the invocation), timing it per task where the tooling allows and in total otherwise;
(3) for every translated claim's IR problem the pipeline delivered, send it to the running service over HTTP and record per-call latency (p50/p95/max) and status; confirm the HTTP results equal the in-process results;
(4) apply the response gate per request (what the student would be shown: verified only when every required check passed; unresolved stays unresolved; nothing unverified labelled verified; the delivery rule: four-minute translation budget, then the most accurate candidate, delivered only above 90% accuracy, never labelled checked) and record each request's final display status;
(5) write ${E}/harness/timings.json with, per task: stage timings in seconds for request validation, routing (the task's kb assignment), deterministic channel/translator processing, Z3 engine (in-process and over HTTP), response gate, and the request's total deterministic time; plus totals and the service's p50/p95/max; and ${E}/harness/gate.json with each request's displayed outcome.
Stop the service at the end. Report any error, crash, timeout or inconsistency you hit as a bug with its exact repro. Return done, results (the key numbers) and left_undone.`, { label: 'e2e:pipeline', phase: 'Pipeline', schema: DONE_SCHEMA })

phase('Overseer')
const ov = await overseerAgents(DIR, ODIR, 'e2e', 'Overseer')

phase('Judge')
const judge = await agent(`${CTX}
OVERALL JUDGING of the end-to-end simulation (you are the strongest-tier judge; the specialists, translation provider, combinator and overseer agents ran on the cheapest tier). Read ${DIR}/inputs.md, ${DIR}/tasks.json, every specialist answer in ${DIR}/specialists/, relayed peer reports, ${DIR}/translations/, ${DIR}/syntheses/, the round results the arena wrote in ${DIR}, the overseer agents' verdicts and score in ${ODIR}/, ${E}/harness/timings.json and ${E}/harness/gate.json. Judge per request: is the specialist answer correct and appropriate for an IB student; did the translation encode what was claimed; are the Z3 verdicts right; did the overseer agents catch real problems without false accusations; is what the student would be shown correct, with nothing unverified shown as verified? List every error, bug, mistake and optimisation issue (severity, where, evidence, suggested fix). Write ${E}/E2E_REPORT.md with: the requests, per-request outcome, accuracy, the stage timings table from timings.json, the bugs list, and the scope statement (a simulation on a frozen local copy; no live website or deployed service was contacted). Return done, results (accuracy, counts by severity, the slowest stages) and left_undone.`, { label: 'e2e:judge', phase: 'Judge', schema: DONE_SCHEMA })
return { tasks: allTasks.length, specialists: new Set(allTasks.map(t => t.kb)).size, deploy: dep, topup: dep2, pipeline: pipe, overseer: ov, judge }
