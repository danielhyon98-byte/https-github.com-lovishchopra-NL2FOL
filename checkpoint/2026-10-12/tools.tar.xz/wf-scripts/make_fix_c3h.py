#!/usr/bin/env python3
"""Build wf-scripts/fix-c3h.js: the sixth follow-up (NARROW, fail closed), after the push check of 67bc64ec (24 Nov).

Usage: python3 -I make_fix_c3h.py wf-scripts/fix-c3g.js wf-scripts/fix-c3h.js

Derived from the generated fix-c3g.js by asserted replacements only: the meta block, OUT (c3h), the push-check record
constants (PCF = the 67bc64ec record, PCF_PREV = the 08c4a36b record, PCLENSES), the THIS RUN paragraph of DCTX, the
FIXERS array (two owners, from c3h_fixers.py), the rules sentence of the fixers, the check lenses (fresh phrasings and the
readings diff only), the check fixer's priorities (regressions and fail-open items only, failing closed), the KIT task
(the bump to 2026.11-v8, selfcert-4, contract 0.9), every c3g label and restart file (c3h), the attack round (14), the
names of the previous record in the prompts, and the commit body. Everything else (schemas, the class and boundary, the
verification helpers, the held-out rule, the timing rule) is carried over verbatim.
"""
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from c3h_fixers import FIXERS, DCTX_RUN, COMMIT_BODY, KIT_TASK, FIXER_RULES, CHECK_PRIORITIES  # noqa: E402

SRC, OUT_JS = sys.argv[1], sys.argv[2]
s = open(SRC, encoding='utf-8').read()


def rep(text, old, new, count=1):
    n = text.count(old)
    assert n == count, (old[:100], n)
    return text.replace(old, new)


# meta
m = re.match(r"export const meta = \{.*?\n\}\n", s, re.S)
assert m, 'meta not found'
META = """export const meta = {
  name: 'translator-fix-c3h',
  description: "Sixth follow-up (narrow, fail closed) after the push check held 67bc64ec: fix the regressions it introduced, the wrong Geography figure shown as ENTAILED, the fail-open bounds, the D-a year leak, the D-e forms and the Language B year check; one check round with a readings diff; the version bump; verify and commit",
  phases: [
    { title: 'Fix', detail: 'two owners on disjoint paths: self-certification reader and its tests, subject branches; every remedy fails closed' },
    { title: 'Check', detail: 'one round (14): fresh phrasings and a readings diff against HEAD, held-out lines reported by category only; one fixer for regressions and fail-open items only' },
    { title: 'Version', detail: 'one KIT step after every fixer: the version bump for the rule changes of this run, the kit regenerated with the repository tools' },
    { title: 'Verify', detail: 'full suite in shards, then the harness on every round, hygiene, up to three repairs, commit' },
  ],
}
"""
s = META + s[m.end():]

s = rep(s, "const OUT = `${WF2}/c3g`", "const OUT = `${WF2}/c3h`")
s = rep(s,
        "const PCF = `${S}/push-check/08c4a36b9d68885aac6bb81840d127c65a0ed409.json`\n"
        "const PCF_PREV = `${S}/push-check/a9129c78de9fdcdb6d93a42a2e08ae413d7b1cd0.json`\n"
        "const PCLENSES = `${WF2}/c3g/pushcheck-08c4a36-lenses.json`\n"
        "const C3F_LEFT = `${WF2}/c3g/c3f-left.json`",
        "const PCF = `${S}/push-check/67bc64ec336f87c641a83fd51eff8c8d521212f7.json`\n"
        "const PCF_PREV = `${S}/push-check/08c4a36b9d68885aac6bb81840d127c65a0ed409.json`\n"
        "const PCLENSES = `${WF2}/c3h/pushcheck-67bc64e-lenses.json`")
# THIS RUN paragraph: from 'THIS RUN (follow-up 5' to the line before 'The working tree of'
i = s.index('THIS RUN (follow-up 5, 23 Nov).')
j = s.index('\nThe working tree of ${REPO} (branch ${BRANCH}) is shared', i)
s = s[:i] + DCTX_RUN.strip('\n') + s[j:]
# FIXERS array
i = s.index('const FIXERS = [\n')
j = s.index('\n]\nconst fixRes = await parallel(FIXERS.map', i)
s = s[:i] + 'const FIXERS = [\n' + ',\n'.join("  { key: '%s', task: `%s` }" % (k, t.strip('\n')) for k, t in FIXERS) + s[j:]
# the fixers' rules sentence
i = s.index('Rules for every fixer: fix each item at its cause and by class')
j = s.index("${RESTARTS('c3g-' + f.key)}", i)
s = s[:i] + FIXER_RULES.strip() + s[j:]
# labels, restart files, round, previous record names
s = rep(s, "RESTARTS('c3g-' + f.key)", "RESTARTS('c3h-' + f.key)")
s = rep(s, "label: `fix:c3g:${f.key}`", "label: `fix:c3h:${f.key}`")
s = rep(s, "label: `check:${l.key}:c3g`", "label: `check:${l.key}:c3h`")
s = rep(s, "label: 'fix:c3g:check'", "label: 'fix:c3h:check'")
s = rep(s, "RESTARTS('c3g-check')", "RESTARTS('c3h-check')")
s = rep(s, "${OUT}/progress-c3g-*.md", "${OUT}/progress-c3h-*.md")
s = rep(s, "'clearance-c3g'", "'clearance-c3h'")
s = rep(s, "label: 'fix:c3g:kit'", "label: 'fix:c3h:kit'")
s = rep(s, "RESTARTS('c3g-kit')", "RESTARTS('c3h-kit')")
s = rep(s, "const ROUND = 13 // continues the attack numbering", "const ROUND = 14 // continues the attack numbering")
s = rep(s, "Also re-run every reproduction of the push check of 08c4a36b that belongs to your lens",
        "Also re-run every reproduction of the push check of 67bc64ec that belongs to your lens")
# the check lenses: fresh phrasings and the readings diff only (a narrow run; over-blocks may return by design)
s = rep(s, "const LENSES = ATK.filter(l => l.key !== 'paths')", "const LENSES = ATK.filter(l => l.key === 'phrasings')")
# the check fixer: two fixers; priorities for regressions and fail-open items only
s = rep(s, "The four fixers of this run left these items", "The two fixers of this run left these items")
i = s.index('Priorities: (1) every regression (above all a wrong result shown as checked or a correct one charged)')
j = s.index("${RESTARTS('c3h-check')}", i)
s = s[:i] + CHECK_PRIORITIES.strip() + s[j:]
# the KIT step
i = s.index('You are the KIT step of this run')
j = s.index("\n${TIMING}${RESTARTS('c3h-kit')}", i)
assert '`' not in KIT_TASK
assert set(re.findall(r'\$\{([^}]*)\}', KIT_TASK)) <= {'C3B', 'PCF', 'PY'}, set(re.findall(r'\$\{([^}]*)\}', KIT_TASK))
s = s[:i] + KIT_TASK.strip() + s[j:]
# commit body: replace the fixed text between 'const body = `' and '\nCheck round after the fixes'
i = s.index('const body = `')
j = s.index('\nCheck round after the fixes: ${open.length} reproduced.', i)
assert '`' not in COMMIT_BODY and '${' not in COMMIT_BODY
s = s[:i] + 'const body = `' + COMMIT_BODY.strip() + s[j:]
s = rep(s, "// ================================================================== fix-c3g (written 23 Nov after the push check of 08c4a36b)",
        "// ================================================================== fix-c3h (written 24 Nov after the push check of 67bc64ec; narrow, fail closed)")
for bad in ('fix:c3g:', "'c3g-", 'clearance-c3g', 'progress-c3g', 'C3F_LEFT', 'ROUND = 13', 'follow-up 5, 23 Nov', 'push check of 08c4a36b that',
            '2026.11-v6', "'2026.11-v7' -> '2026.11-v7'"):
    assert bad not in s, bad
open(OUT_JS, 'w', encoding='utf-8').write(s)
print('wrote', OUT_JS, len(s), 'chars')
