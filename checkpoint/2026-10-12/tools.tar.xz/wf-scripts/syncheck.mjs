// syntax check only: wrap the body in an async function (top-level return/await are legal in workflow scripts)
import fs from 'fs'
const src = fs.readFileSync(process.argv[2], 'utf8').replace(/^export const meta/m, 'const meta')
try { new Function('agent', 'parallel', 'pipeline', 'phase', 'log', 'args', 'budget', 'workflow', `return (async () => {\n${src}\n})()`); console.log('syntax ok') } catch (e) { console.log('SYNTAX ERROR', e.message) }
