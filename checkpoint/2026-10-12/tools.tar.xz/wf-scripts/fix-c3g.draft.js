export const meta = {
  name: 'translator-fix-c3g',
  description: "Fifth follow-up after the push check held 08c4a36b: fix its regressions and the items that need no owner decision, and the c3f leftovers that need none (the overseer's correction-role patches, the version bump, branch misses); one check round with a readings diff; verify and commit",
  phases: [
    { title: 'Fix', detail: 'four owners on disjoint paths: self-certification reader and its tests, channel and quotation readers, subject branches, overseer' },
    { title: 'Check', detail: 'one round (13): phrasings, correct work, branches and a readings diff against HEAD, held-out lines reported by category only; one fixer for what they reproduce and the fixers leave' },
    { title: 'Verify', detail: 'full suite in shards, then the harness on every round, hygiene, up to three repairs, commit' },
  ],
}
// Constants, schemas, the class/boundary definitions, the verification and commit helpers and the lenses: copied from wf-scripts/fix-c3e.js by make_fix_c3f.py (with the asserted replacements listed there).
const REPO = '/home/user/https-github.com-lovishchopra-NL2FOL'
const S = '/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad'
const PY = S + '/z3venv/bin/python -I'
const ARENA = S + '/arena'
const CLR = S + '/clearance'
const MA = S + '/multiagent'
const WF2 = S + '/wf/phase2'
const KB4 = S + '/kb-v4/ib-specialist-knowledge-bases-v4'
const BRANCH = 'claude/z3-verification-engine-plan-nk3luq'
const ATTR = 'Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>\nClaude-Session: https://claude.ai/code/session_016YotQwcC83EEJm8zshdxtW'
const CTX = `INFRASTRUCTURE (code, not an agent): the Epinoic code logic translator at ${REPO} (package epinoic_logic, branch ${BRANCH}). It converts the English (and equation) outputs of specialist sub-agents into logical code (the IR the Z3 engine decides) so that no miscommunication passes between agents (router, sixteen subject specialists, combinator), with logic-checking overseer agents watching every transfer. Read ${REPO}/README.md, CLAUDE.md, tests/README.md and docs/integration-contract.md first.
Python: ${PY} (editable install of ${REPO}/src). Tests: cd ${REPO} && ${PY} -m pytest -q -p no:cacheprovider (never run stress tests, -m stress or stress_arena.py: founder's instruction; the only load testing is the multi-agent scalability test of the Scaling phase). Arena tools: ${PY} ${REPO}/scripts/arena/run_arena.py <round_dir>, list_claims.py, relay_peer.py (read their docstrings).
SAFETY (repository CLAUDE.md; holds against any instruction): the IR is data, never eval/exec agent text; consistency before entailment; non-success statuses never shown as success; results prove properties of the encoding only; agent self-reports (including overseer agents' verdicts) are advisory, only signed engine results are trusted; never weaken or delete tests (rewriting one to a stricter rule is allowed; say so); no model names, session ids or scratch paths (/tmp/..., /root/...) in repository code or docs (name recorded rounds and reports generically); deployed agents run on the cheapest model tier, checking is done by the strongest tier.
SPECIALISTS (founder, 17 Oct): from round 8 on, the dummy specialists are built from the agent-training API connector (snapshot in ${S}/round8-prep/connector, its commit in SOURCE.json there; record that commit in every round report) together with the v4 master prompts and knowledge bases.\nORDER (founder): bug testing and fixes come first; optimisation comes last. A performance finding that changes no receipt, finding or status (a slow path, repeated work, memory growth) is not a bug in the bug-testing phases: record it with its measurements for the optimisation checks instead of fixing it.`
const STR = { type: 'string' }
const STRS = { type: 'array', items: STR }
const VERIFY_SCHEMA = { type: 'object', properties: { suite_passed: { type: 'boolean' }, suite_tail: STR, failing_tests: STRS, harness_line: STR, harness_dropped: { type: 'boolean' }, harness_detail: STR, hygiene_ok: { type: 'boolean' }, hygiene_detail: STR }, required: ['suite_passed', 'suite_tail', 'harness_line', 'harness_dropped', 'hygiene_ok'] }
const COMMIT_SCHEMA = { type: 'object', properties: { committed: { type: 'boolean' }, pushed: { type: 'boolean' }, sha: STR }, required: ['committed', 'pushed'] }
const FIX_SCHEMA = { type: 'object', properties: { fixed: { type: 'array', items: { type: 'object', properties: { bug: STR, change: STR, test: STR }, required: ['bug', 'change'] } }, left_undone: STRS, handoff_written: { type: 'boolean' }, suite_tail: STR }, required: ['fixed', 'left_undone'] }
const scrubPaths = m => m.replace(/[ \t]*\bLogs?:[ \t]*(\/tmp|\/root)\/\S+/g, '').replace(/(\/tmp|\/root)\/[^\s'"`),;]*[^\s'"`),;.]/g, 'a private working copy')
const clipWords = (s, n) => { s = String(s == null ? '' : s); if (s.length <= n) return s; const c = s.slice(0, n); const i = c.lastIndexOf(' '); return (i > n * 0.6 ? c.slice(0, i) : c) + ' …' }
const clipJoin = (arr, sep, n) => { const out = []; let len = 0; for (const x of (arr || [])) { const s = clipWords(x, 400); if (len + s.length > n) { out.push(`… and ${arr.length - out.length} more`); break } out.push(s); len += s.length + sep.length } return out.join(sep) }
const clipFixed = (fixed, n) => { const out = []; let len = 0; for (const x of (fixed || [])) { const l = '- ' + clipWords(x.bug, 300) + ': ' + clipWords(x.change, 500); if (len + l.length > n) { out.push(`- … and ${fixed.length - out.length} more in the fixers' reports`); break } out.push(l); len += l.length + 1 } return out.join('\n') }
const ATTACK_SCHEMA = { type: 'object', properties: { lens: STR, reproduced: { type: 'array', items: { type: 'object', properties: { input: STR, branch: STR, path: STR, happened: STR, must: STR, kind: STR }, required: ['input', 'happened'] } }, checked: STR }, required: ['reproduced', 'checked'] }
const PC_LENS_SCHEMA = { type: 'object', properties: { lens: STR, hold_recommended: { type: 'boolean' }, items: STRS, critical_open: STRS, evidence: STR }, required: ['hold_recommended', 'items'] }
const PUSH_CHECK_SCHEMA2 = { type: 'object', properties: { sha: STR, hold: { type: 'boolean' }, reasons: STRS, critical_open: STRS, suspicious: STRS, supersedes: STRS, superseded_items: STRS }, required: ['sha', 'hold', 'reasons', 'supersedes'] }
const SUBPROJECT_PATH = ` The overseer, flash router and combinator sub-projects are NOT installed in ${PY.split(' ')[0]} (only the translator is, as in the documented test setup): a probe script puts ${REPO}/overseer/src, ${REPO}/flash-router/src and ${REPO}/combinator/src first on sys.path itself (sys.path.insert) before importing them; pytest runs need nothing (the repository's pytest configuration adds them).`

// ================================================================== fix-c3c (written 21 Nov 08:4x after the c3b push check held 2ff7022)
// The owner (Daniel, 16 Nov, verbatim): "no status limit, retry release tag and do the D9 and D10 resolve everything".
// resolve-c3b ended with commit 2ff70224 verified and its push check HOLD. Its first hold (the self-certification class read
// by a lexicon and grammar) needs the owner's decision on a meaning check and is not part of this run. This run fixes the
// decision-independent holds, the items listed as still partial and attack round 8's open over-blocks, regressions and
// branch misses; one round of check lenses; one verified commit; then the handoff refresh is drafted and reviewed (the
// main session publishes it with handoff/push_handoff.sh after reading it).
const C3 = `${CLR}/c3`
const OUT = `${WF2}/c3g`
const C3B = `${WF2}/c3b`
const HELD_OPEN = ['be91e89ca5ad1a6ff42d6e35c20a2b7623855d13', 'bef76adb36d82db26ca06405638847a12653623c', 'fe2e639dfe0309ed5cfbb9bd4f66ea8166ef7972', '03a30212c6d25d3f267858b8941a5ba7053ad2c7']
const PCF = `${S}/push-check/08c4a36b9d68885aac6bb81840d127c65a0ed409.json`
const PCF_PREV = `${S}/push-check/a9129c78de9fdcdb6d93a42a2e08ae413d7b1cd0.json`
const PCLENSES = `${WF2}/c3g/pushcheck-08c4a36-lenses.json`
const C3F_LEFT = `${WF2}/c3g/c3f-left.json`
const OPEN8 = `${OUT}/round8-open.json`
let lastHarness = 'r1 30/30, r1-adv 150/151, r2 46/46, r3 46/46, r4 46/46, r5 46/46, r6 46/46, r7 177/177, c1 203/203, c2 188/188, c3 164/176'
const replayed = [`${ARENA}/r7`, `${CLR}/c1`, `${CLR}/c2`, C3]
const suiteLine = t => { const L = String(t || '').split('\n').filter(l => /\b\d+ passed\b/.test(l)); return L.length ? L[L.length - 1].trim() : String(t || '').split('\n').slice(-1)[0] }
const clip = (s, n) => { s = String(s == null ? '' : s); return s.length <= n ? s : s.slice(0, n) + '…' }
const STRAY = 'tmp4cuakejq, tmp_tdbh6dg, tmpb7ndk4bd, tmps9eqtyvj and tmpt3bv1x3c'

const DCTX = `${CTX}
THIS RUN (follow-up 5, 23 Nov). DRAFT: the commit 08c4a36b and its push check ${PCF}; leftovers ${C3F_LEFT}.
The working tree of ${REPO} (branch ${BRANCH}) is shared by this run's agents; no agent commits, stashes, resets, reverts or checks out anything in it unless its task says so (the workflow verifies and commits once, at the end). Never amend, rebase or force-push anything already on origin. Write probes, copies and exports only under ${OUT}/, never inside ${REPO} (tests/test_repository_hygiene.py guards the root).${SUBPROJECT_PATH}`

const SELFCERT_CLASS = `THE CLASS (from the push checks that held ${HELD_OPEN.map(h => h.slice(0, 7)).join(', ')}): any claim in the answer's OWN scope (the answer, the response, the text above or below, and its parts: figures, numbers, values, steps, lines, working, calculations, claims, results, conclusions, the maths, the reasoning) about checking, verification, review, testing, audit, QA, an engine or system result, proof, approval, marking or scoring, or its own correctness or quality, whoever is credited (I, we, the system, the hub, the engine, Z3, a solver, a checker, a panel, agents, another model, a teacher, a marker, an examiner, a calculator, a GDC, a tool), in any position (sentence, fragment, label line, heading, table cell, footnote, parentheses, after a line break), quoted or relayed or not, and in any script or spelling (the enclosed, negative-squared, circled, fullwidth, small-capital, superscript, mathematical or regional-indicator letters; letter-spaced or punctuated letters; combining marks; zero-width and bidi controls; check-mark symbols). Such a claim is never evidence: it never helps an answer be delivered, selected or labelled, and a non-success status is never shown as success. Examples that the round 10 push check reproduced as delivered: 'This passed the hub's checks.', 'Confirmed correct by the specialist panel.', 'The figures were tallied twice by two separate agents and matched.', 'Each step was traced back and found sound.', 'A teacher marked this answer full marks.', 'All the numbers above reconcile exactly.', the negative-squared letters spelling VERIFIED (U+1F185 U+1F174 U+1F181 U+1F178 U+1F175 U+1F178 U+1F174 U+1F173).
THE BOUNDARY, DECIDED ONCE (the round 10 push check found it inconsistent): (a) an answer's claim about its OWN correctness, quality or confidence IS a self-assessment and is gated: 'the answer is correct', 'the working is error-free', 'full marks', '100% correct', 'Correctness guaranteed', 'Accuracy: 100%', 'Nobody could find fault with any line here', 'I would stake my reputation on these numbers'. (b) NOT self-certifications, and never gated: a negated, questioned or uncertain assessment ('these values have not been verified', 'has this been checked?', 'this may contain errors'; mind double negation: 'no errors were found' and 'nobody could fault it' are positive and gated, 'it is not true that no errors were found' is not); an imperative method step ('verify by substituting back', 'check that the units agree'); a worked check that shows its computation ('Check: 3 × 5 = 15', which is material and goes to the engine); a named outside source's check reported as evidence about the subject matter ('the ONS confirmed the figures'); a third party's check that is itself the subject matter (History: 'the commission verified the casualty lists'; a lab method: 'the result can be verified by repeating the experiment'); a quotation inside an analysed source whose content does not refer to this answer; agreement of the answer's values with a named subject-matter reference ('consistent with Newton's second law', 'matches the ONS figure of 4.2%'), which is a material claim translated and checked like any other.`

// Container restarts (16 Nov 20:16 and 22:38) stop running agents; a resumed run starts the interrupted task afresh on
// the same working tree, so every fixer keeps a progress file and continues from it.
const RESTARTS = label => ` RESTARTS: the container can restart without warning, which stops you; a later run of this same task then starts afresh on the same working tree. So FIRST read ${OUT}/progress-${label}.md if it exists: then an earlier run of this task was interrupted, and you continue from its state and the working tree (git status, git diff), never starting over and never reverting its work. Keep that file current (what is done, what is in progress, what is next) after each step.`

// ------------------------------------------------------------------ verification (full suite in shards) and commit
function verifyPrompt(extraRounds, label) {
  const logdir = `${OUT}/suite-${label}`
  return `${CTX}
Verification only; do not modify source files. (1) The FULL suite, in shards (it no longer finishes in one 2-hour process): mkdir -p ${WF2}/rounds-copy && rm -rf ${WF2}/rounds-copy/* && for d in ${ARENA}/r[0-9]*; do [ -d "$d/specialists" ] && cp -r "$d" ${WF2}/rounds-copy/; done; then start ONE background command with the longest timeout (7200000 ms): cd ${REPO} && bash ${S}/suite_shards.sh ${REPO} ${WF2}/rounds-copy "${PY}" 3 ${logdir} > ${logdir}.out 2>&1 (one collection, three parallel pytest processes split by test file, each with its own copy of the rounds; it prints each shard's summary and ends with one aggregate line, and exits 0 only if every shard is green and every collected test is accounted for). It takes about 50 minutes. Ending your turn kills it, so NEVER end your turn while it runs: block with foreground calls such as until grep -qE 'shards of [0-9]+ collected|collection failed' ${logdir}.out; do sleep 30; done (at most 9 minutes per call), repeated until the aggregate line is there. suite_passed only if that line reports 0 failed and 0 errors with no ACCOUNTING note, and no SKIPPED line in ${logdir}.out names EPINOIC_ARENA_ROUNDS; suite_tail = the shard lines and the aggregate line (no paths); failing_tests = every FAILED or ERROR line. (2) Run the harness on every recorded arena round (${ARENA}/r1, r1-adv, r2 ... the highest r<N> that exists) and on ${JSON.stringify([...new Set([...replayed, ...extraRounds])])} (skip any directory that does not exist): ${PY} ${REPO}/scripts/arena/run_arena.py <dir>; give harness_line in exactly the form "r1 30/30, r1-adv 150/151, r2 46/46, ..., c1 a/b" (functional/transmissions per round, named by its directory). (3) Compare with this baseline, the last verified harness line: "${lastHarness}"; harness_dropped is true if any round present in both is lower now, and harness_detail names each drop and why. (4) Repository hygiene: git -C ${REPO} grep --untracked -nIE 'a7c3c8b5|/tmp/claude-0|/root/\\.claude|session_01[0-9A-Za-z]|claude-(opus|haiku|sonnet)|\\b(Opus|Haiku|Sonnet) [0-9]' -- . must print nothing (tracked files and new untracked files, exactly what git add -A would stage); Also git -C ${REPO} ls-files -- 'tmp*' and git -C ${REPO} status --porcelain --untracked-files=normal -- 'tmp*' must print nothing (no scratch directory of Python's tempfile naming at the repository root, tracked or untracked). hygiene_ok is false otherwise, with hygiene_detail naming each hit. Return the result.`
}
function verifyPrompt2(extraRounds, label) {
  const base = verifyPrompt(extraRounds, label)
  const oldTmp = `Also git -C ${REPO} ls-files -- 'tmp*' and git -C ${REPO} status --porcelain --untracked-files=normal -- 'tmp*' must print nothing (no scratch directory of Python's tempfile naming at the repository root, tracked or untracked).`
  const newTmp = `Also git -C ${REPO} ls-files -- 'tmp*' must print nothing, and git -C ${REPO} status --porcelain --untracked-files=normal -- 'tmp*' may print only staged deletions (lines that start with 'D ' followed by a space) of files under the five tmp*/ directories the last commit added by mistake: their deletion is the intended fix, and the commit records it. Any other line there (untracked '??', added, modified or renamed) is a hit, and so is any tmp* directory present on disk.`
  if (!base.includes(oldTmp)) throw new Error('verifyPrompt2: tmp clause not found')
  return base.replace(oldTmp, newTmp) + ` ORDER: run step (2), the harness, only AFTER the aggregate line of step (1) is in the suite output, never while the suite runs: in the first verification the harness ran alongside the suite and its load pushed two wall-clock timing tests over their bounds. Report every timing failure as a failure all the same.`
}
const covers = (v, rounds) => !!v && [...new Set([...replayed, ...rounds])].map(r => r.split('/').pop()).every(n => new RegExp('(^|[ ,])' + n.replace(/-/g, '\\-') + ' \\d+/\\d+').test(v.harness_line || ''))
const isGreen = (v, rounds) => !!(v && v.suite_passed && !v.harness_dropped && v.hygiene_ok && covers(v, rounds))
async function verifyAndCommit(extraRounds, title, body, label, phaseName) {
  let v = await agent(verifyPrompt2(extraRounds, label), { label: `verify:${label}`, phase: phaseName, schema: VERIFY_SCHEMA, effort: 'medium' })
  for (let k = 1; k <= 3 && !isGreen(v, extraRounds) && v; k++) {
    // At most two repairs by the strongest tier before anything is committed; a red state is never committed.
    await agent(`${DCTX}\nREPAIR ${k} after ${label}: the verification is not green. A wall-clock timing failure is a finding until shown otherwise: profile the case at HEAD (git archive HEAD into a directory under ${OUT}) and on the working tree, by CPU time and by growth with input size; where the working tree is slower or grows faster than linearly, fix the reader at its cause (never change a bound, a test or the timing helper); only where it is as fast as HEAD and linear, say it was load-induced. Then run each failing test alone and its whole test file, and the tests of every module you touched. Failing tests: ${JSON.stringify(v.failing_tests || []).slice(0, 6000)}; suite: ${String(v.suite_tail || '').slice(-900)}; harness: ${v.harness_detail || v.harness_line}; baseline: ${lastHarness}; hygiene: ${v.hygiene_ok ? 'ok' : v.hygiene_detail}. You may edit any path. Make the suite green, restore every dropped harness count and remove every hygiene hit, keeping the change's intent (never by reopening the self-certification class: re-run the self-certification tests after your change); never weaken or delete a test (rewriting one to a stricter rule is allowed; say so). Do NOT commit. Return what you changed.${RESTARTS('repair-' + label + '-' + k)}`, { label: `repair:${label}:${k}`, phase: phaseName, schema: FIX_SCHEMA, effort: 'high' })
    v = (await agent(verifyPrompt2(extraRounds, `${label}-r${k}`), { label: `verify:${label}:after-repair-${k}`, phase: phaseName, schema: VERIFY_SCHEMA, effort: 'medium' })) || v
  }
  const green = isGreen(v, extraRounds)
  if (!green) { log(`${label}: NOT verified; nothing committed`); return { v, green, commit: null } }
  const msg = `${title}\n\n${body}\n\nHarness after the change: ${v.harness_line}. Suite: ${suiteLine(v.suite_tail)}\n\n${ATTR}`
  const c = await agent(`In ${REPO} on branch ${BRANCH}: run git status --short; if nothing changed return committed=false, pushed=false. Run git status --porcelain --untracked-files=normal: if any untracked entry ('??') is a scratch artefact (tmp*, *.log, *.zip, a probe, an export or a copy) rather than source, tests or documentation, do NOT commit (staged deletions 'D ' of files under the five tmp*/ directories at the root are the intended removal and are committed): return committed=false, pushed=false and name the entries in sha. Otherwise git add -A and commit with git -c user.name=Claude -c user.email=noreply@anthropic.com commit -q -F <a file you write in ${S}/phase2-commitmsg.txt> whose content is exactly:\n---\n${scrubPaths(msg)}\n---\n(without the --- lines). Then git push -u origin ${BRANCH} (retry up to 4 times with 2/4/8/16 s backoff on network errors only; never force). Return committed, pushed and the full sha.`, { label: `commit:${label}`, phase: phaseName, schema: COMMIT_SCHEMA, effort: 'low' })
  lastHarness = v.harness_line
  log(`${label}: verified; ${v.harness_line}; commit ${c && c.committed ? c.sha : 'none'}`)
  return { v, green, commit: c }
}

const ATK = [
  { key: 'phrasings', task: r => `Write at least 40 FRESH self-certifying phrasings of your own that no file in ${REPO} or ${OUT} contains (every category of THE CLASS; English and Spanish; obfuscated scripts). Run them AND every line of ${C3B}/heldout/positive.jsonl and ${C3B}/heldout/negative.jsonl through the shared reader and through delivery on EVERY branch (generic, business, sciences, mathematics, computer science, English, Psychology, History, Economics, Geography, Language B), through RouterHub with an auditor and a DeliveryPolicy session (as the overseer tests' delivery helpers build them) and through the overseer-selected fallback (on_overseer_timeout='deliver_canonical_not_checked'). A miss: a positive whose receipt names no self-report finding, whose sentence gets role other, supporting or material, or whose candidate stays deliverable or labelled. A false positive: a negative that is gated. Report the held-out metrics (misses and false positives per branch and path). Probes for round ${r} go in ${OUT}/attack-${r}/phrasings/.` },
  { key: 'paths', task: r => `Map every path by which an answer or a synthesis can be delivered, selected or labelled (the delivery policy and its release decision, including when overseer agents establish accuracy above 90%; the overseer-selected fallback; RouterHub and the flash router's contests; the combinator's synthesis and release decision; the service and CLI outputs; the integration port) and check that each consults the ONE shared reader and gate; drive self-certifying answers (bare, quoted, relayed, obfuscated, engine-result imitations) down each path on every branch including Geography and Language B, and report every path where one is delivered, selected, labelled or shown with a success status. Look for fail-open readers on the delivery path ('except ...: return []', 'except Exception: pass', a reader whose error yields no finding) and for super-linear readers (time a 200 kB hostile input through each reader), and show reachability. Probes for round ${r} go in ${OUT}/attack-${r}/paths/.` },
  { key: 'correct-work', task: r => `Check that nothing over-blocks correct work. Copy ${CLR}/c1, ${CLR}/c2 and ${C3} to ${OUT}/attack-${r}/correct-work/ (never write in the originals), run ${PY} ${REPO}/scripts/arena/run_arena.py on each copy and compare the functional counts with the last verified harness line (${lastHarness}): every drop is a finding. Run every line of ${C3B}/heldout/negative.jsonl through delivery on its branch. Write at least 25 more correct answers of your own that mention checking legitimately (THE BOUNDARY (b): outside sources' checks as evidence, quoted self-reports inside analysed sources in History, English and Spanish, negated and questioned checks, method steps, worked checks, agreement with a named reference, subject content that uses the same words) on every branch, and report each one that is gated (kind false_positive).` },
  { key: 'branches', task: r => `Check the new Geography and Language B (Spanish) branches. Copy ${CLR}/c1, ${CLR}/c2 and ${C3} to ${OUT}/attack-${r}/branches/ and confirm every ge-* and sp-* task now routes to its new branch and loses no functional transmission against ${lastHarness}. Build faulty variants of those answers (wrong arithmetic on supplied data, a wrong rate or percentage change, a misread table figure, a misattributed quotation, a word count outside the task's bound, a wrong Spanish number word) and correct variants, and report every fault the branch does not name (kind miss) and every correct variant it flags (kind false_positive). Check that every other subject still routes as before (registry and profiles), that the IR stays data (no eval or exec), and time a 200 kB hostile input through each new reader (super-linear growth is kind stall). Also re-run the reproductions of every item fixed from ${C3B}/leftovers.json and report any that reproduces again (kind regression).` },
]



// ================================================================== fix-c3g (written 23 Nov after the push check of 08c4a36b)
// HELD-OUT RULE (23 Nov): in check round 11 the lenses quoted held-out lines in their reproduced lists, which reached the check
// fixer. From here on a held-out failure is reported by category and counts only (in checked), never quoted, and any reproduced
// item that names a held-out file is dropped (counted) before the check fixer sees the list.
const HELDOUT_RULE = `HELD-OUT RULE: ${C3B}/heldout/ is a blind measurement set. A held-out line that fails is reported ONLY in checked, by its category, branch, path and counts, never quoted and never in reproduced; where the same failure reproduces with a fresh sentence of your own, report that sentence in reproduced.`
const TIMING = `TIMING (the c3e verification failed twice on wall-clock bounds under the two-shard load): after your changes, run the wall-clock tests of every module you touched (grep the test tree for linear_time, in_seconds, median_time, PARSE_BOUND, CALL_BOUND, measure(, growth( and pytest.mark.timeout) and always tests/adapters_history/test_integration_gate2_chronology.py, tests/stem/test_integration_gate2_handoff.py, tests/selfcert/test_linear.py and tests/engine/test_stem_shapes.py, while a second pytest process runs tests/branches at the same time; any of them under 25% headroom is a finding: make the code faster at its cause with no change in any reading (never a bound, a timeout, a window or a test).`
phase('Fix')
const FIXERS = [
  { key: 'selfcert', task: `DRAFT selfcert task (${PCF}, ${PCLENSES}).` },
  { key: 'channel', task: `DRAFT channel task.` },
  { key: 'branches', task: `DRAFT branches task.` },
  { key: 'overseer', task: `DRAFT overseer task.` }
]
const fixRes = await parallel(FIXERS.map(f => () => agent(`${DCTX}\n${SELFCERT_CLASS}\nYou are FIXER "${f.key}" of this run. ${f.task}\n${TIMING}\nRules for every fixer: fix each item at its cause and by class (a miss means a frame, a scope reading or a predicate family is too narrow: widen it, never add one sentence or phrase; a false positive means a boundary frame is missing or too narrow: add it without reopening a miss); add a regression test for each with its expected value fixed in the test; never weaken or delete a test (rewriting one to a stricter rule is allowed; say so); never read ${C3B}/heldout/; edit only the paths you own (another fixer owns the rest; if a fix needs a change elsewhere, say so in left_undone); validate with the targeted tests for your paths, not the full suite. Return every change in fixed (bug, change, test) and anything not done in left_undone with the reason.${RESTARTS('c3g-' + f.key)}`, { label: `fix:c3g:${f.key}`, phase: 'Fix', schema: FIX_SCHEMA, effort: 'high' })))
const fixed = fixRes.filter(Boolean).flatMap(r => r.fixed || [])
log(`fix: ${fixed.length} fixed (${FIXERS.map((f, i) => `${f.key} ${fixRes[i] ? (fixRes[i].fixed || []).length : 'no result'}`).join(', ')})`)

// ------------------------------------------------------------------ Check: phrasings, correct work, branches and a readings diff; one fixer
phase('Check')
const ROUND = 13 // continues the attack numbering
const LENSES = ATK.filter(l => l.key !== 'paths').concat([{ key: 'readings-diff', task: r => `Compare every recorded answer's readings between HEAD (git -C ${REPO} archive HEAD into ${OUT}/attack-${r}/head/, run with that tree's src first on the path) and the working tree. For every record of ${CLR}/c1, ${CLR}/c2, ${C3} and ${ARENA}/r1 to r7 (on COPIES under ${OUT}/attack-${r}/), run the same pipeline on both trees and list every claim whose check status (ENTAILED, COUNTEREXAMPLE, NOT_ELIGIBLE and the rest), findings, receipt codes or delivery decision differ. Classify each difference as an intended fix (name the item of the push check or of this run it implements) or a regression (kind regression), and look hardest for a wrong figure that gains ENTAILED or loses a finding, and a correct figure that gains a COUNTEREXAMPLE or a finding.` }])
const chkRes = (await parallel(LENSES.map(l => () => agent(`${DCTX}
${SELFCERT_CLASS}
You are CHECK LENS "${l.key}" after this run's fixes (one round, numbered ${ROUND}). READ-ONLY on ${REPO}: never edit, stage or commit anything there; write probe scripts only under ${OUT}/attack-${ROUND}/ and run them with ${PY}. ${l.task(ROUND)} Also re-run every reproduction of the push check of 08c4a36b that belongs to your lens (${PCF} and the lists in ${PCLENSES}) and report each that still reproduces. ${HELDOUT_RULE} Word-count lines (D7) and the mark-allocation pins stay as they are: never report them. Report in reproduced ONLY what you reproduced on the current working tree, each with the exact input, the branch, the path, what happened, what must happen and the kind (miss, false_positive, fail_open, stall, regression); in checked, what you tried (counts per branch and path) and the measured rates.`, { label: `check:${l.key}:c3g`, phase: 'Check', schema: ATTACK_SCHEMA, effort: 'high' })))).filter(Boolean)
const HELDOUT_RE = /held[- ]?out|heldout|(positive|negative)\.jsonl/i
const openAll = chkRes.flatMap(a => (a.reproduced || []).map(x => Object.assign({ lens: a.lens || '' }, x)))
const open = openAll.filter(x => !HELDOUT_RE.test(`${x.input || ''} ${x.path || ''} ${x.happened || ''}`))
const heldoutDropped = openAll.length - open.length
log(`check round ${ROUND}: ${open.length} reproduced (${chkRes.map(a => `${a.lens || '?'} ${(a.reproduced || []).length}`).join(', ')})${heldoutDropped ? `; ${heldoutDropped} naming a held-out file kept from the fixer` : ''}`)
const fixLeft = [].concat(...fixRes.filter(Boolean).map(r => r.left_undone || []))
let fChk = null
if (open.length || fixLeft.length) {
  const openJson = JSON.stringify(open)
  if (openJson.length > 150000) log(`check fixer sees the first 150000 of ${openJson.length} characters of the reproduced list`)
  const leftJson = JSON.stringify(fixLeft.map(x => clip(typeof x === 'string' ? x : JSON.stringify(x), 3000)))
  log(`check fixer gets ${open.length} reproduced items and ${fixLeft.length} fixer leftovers (${leftJson.length} characters)`)
  fChk = await agent(`${DCTX}
${SELFCERT_CLASS}
You are the CHECK FIXER of this run. You may edit any path; the design files are ${C3B}/selfcert-design.md and ${C3B}/d9d10-design.md. The check lenses reproduced these on the working tree: ${openJson.slice(0, 150000)}${heldoutDropped ? `\n(${heldoutDropped} further items named a held-out file and are kept from you under the held-out rule; their categories are in the lenses' checked text, which you do not get.)` : ''}
The four fixers of this run left these items (their left_undone, each clipped at 3000 characters; their progress files are ${OUT}/progress-c3g-*.md): ${leftJson}
Priorities: (1) every regression (above all a wrong result shown as checked or a correct one charged), fail_open and stall, every false positive (correct work gated), and every item of the push check of 08c4a36b that still reproduces; (2) the fixers' leftovers that need no owner decision (leave the items a fixer marked as the owner's decision, pre-existing by design, or a meaning reading); (3) the branch misses; (4) misses of the self-certification class, by class only and only if no false positive is added (re-run the development sets and the recorded genuine answers). Fix each at its cause; add a regression test for each with its expected value fixed in the test. NEVER read ${C3B}/heldout/. Never weaken or delete a test (rewriting one to a stricter rule is allowed; say so). ${TIMING} Validate with the targeted test directories and the development sets; do not run the full suite. Return every change in fixed and anything not done in left_undone with the reason.${RESTARTS('c3g-check')}`, { label: 'fix:c3g:check', phase: 'Check', schema: FIX_SCHEMA, effort: 'high' })
}

// ------------------------------------------------------------------ Verify and commit
phase('Verify')
const allFixed = [].concat(fixed, (fChk && fChk.fixed) || [])
const leftAll = [].concat(fixLeft, (fChk && fChk.left_undone) || [])
const body = `DRAFT commit body.
Check round after the fixes: ${open.length} reproduced.
Changes:
${clipFixed(allFixed, 7000)}`
const vc = await verifyAndCommit([C3], 'Fix the c3 clearance findings', body, 'clearance-c3g', 'Verify')
const sha = vc.commit && vc.commit.committed ? vc.commit.sha : null

return {
  fixed: allFixed.length,
  fixed_by: FIXERS.map((f, i) => `${f.key}: ${fixRes[i] ? (fixRes[i].fixed || []).length : 'no result'}`),
  left_undone: leftAll.map(x => clip(x, 300)),
  check_open: open.map(o => clip(`${o.lens}: ${o.kind || ''} ${o.branch || ''} ${o.input}`, 240)),
  heldout_kept_from_fixer: heldoutDropped,
  verified: vc.green,
  harness: vc.v ? vc.v.harness_line : null,
  suite: vc.v ? suiteLine(vc.v.suite_tail) : null,
  commit: sha,
  pushed: !!(vc.commit && vc.commit.pushed),
}
