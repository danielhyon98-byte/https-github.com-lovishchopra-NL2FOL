#!/usr/bin/env bash
# Detached re-run (9 Nov) of the upload simulation of c4f276c after the first run was stopped at the 2-hour limit for
# background commands. Its suite had finished: every test passed except one time bound under CPU contention, which then
# passed alone at exactly this tree (evidence: sim-evidence/c4f276c-suite.txt), so the suite is skipped here
# (SIM_SKIP_SUITE=1). Harness floors: c4f276c's own record (r1, r1-adv, r2-r7, c1). Caches exactly as presim.sh does.
# Uploads nothing: the gate install (install_gate_208.sh) and event_push.sh are run by hand after it.
set -uo pipefail
S=/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad
T=c4f276ca060909e1e7d26c2ed403a6726c50eb2c
F=$S/simcache/translator-$T.txt
echo "start $(date -u +%H:%M:%S)"
exec 8>"$S/.presim.lock"; flock 8
SIM_SKIP_SUITE=1 bash "$S/simulate.sh" translator "$T" "$T" > "$F.tmp" 2>&1
if [ "$(grep -c '^SIMULATION ' "$F.tmp")" -gt 0 ]; then date -u +%H:%M:%S >> "$F.tmp"; mv "$F.tmp" "$F"; else echo "simulation did not finish"; fi
flock -u 8; exec 8>&-
echo "simulation $(date -u +%H:%M:%S): $(grep '^SIMULATION ' "$F" 2>/dev/null | tail -1)"
echo "done $(date -u +%H:%M:%S)"
