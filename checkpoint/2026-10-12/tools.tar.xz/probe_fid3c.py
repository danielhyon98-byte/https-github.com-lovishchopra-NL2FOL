from epinoic_logic.branches import RouterHub
from epinoic_logic.engine import SolverConfig
from epinoic_logic.integrity import WorkPlan
from epinoic_logic.overseer.checks import fidelity as F
from epinoic_logic.integrity import ledger
text = "The figure is " + "one hundred and " * 300 + "five."
hub = RouterHub(signing_key=b"k" * 32, key_id="hub", config=SolverConfig(timeout_ms=8000, memory_max_mb=None))
hub.open_task(WorkPlan(plan_id="p", request_id="q", task_id="t", subject="Economics", task_type="short_answer", selected_agent_ids=["economics-specialist"]))
m, _, _ = hub.dispatch("t", "economics-specialist", "Answer the question.")
msg, rc = hub.receive("t", m.message_id, text, agent_id="economics-specialist", report_id="r1")
rep = msg.payload
claims = rep["claims"] if isinstance(rep, dict) else rep.claims
claims = [type("C", (), {"claim_id": c["claim_id"], "claim_text": c["claim_text"]})() if isinstance(c, dict) else c for c in claims]
for c in claims[:3]:
    t = c.claim_text
    print(c.claim_id, len(t), repr(t[-40:]))
    u = F.uncut_text(t)
    print("  uncut tail:", repr(u[-40:]))
    print("  claim figures tail:", sorted(ledger.figure_spellings(u))[:6] if hasattr(ledger, "figure_spellings") else "n/a")
