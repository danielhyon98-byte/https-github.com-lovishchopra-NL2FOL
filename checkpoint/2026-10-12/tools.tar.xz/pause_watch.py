"""Exit when the workflow journal shows a commit:* agent that started after launch has a result."""
import json, sys, time, os
journal, task_out = sys.argv[1], sys.argv[2]
def entries():
    out = []
    with open(journal) as f:
        for line in f:
            try: out.append(json.loads(line))
            except Exception: pass
    return out
start = len(entries())
while True:
    e = entries()
    new = e[start:]
    commits = {x['agentId'] for x in new if x.get('type') == 'started' and str(x.get('label', '')).startswith('commit:')}
    done = [x for x in new if x.get('type') == 'result' and x.get('agentId') in commits]
    if done:
        last = [x for x in new if x.get('type') == 'started'][-1]
        print('PAUSE_POINT', time.strftime('%H:%M:%S'), 'committed; latest started:', last.get('label'))
        break
    if os.path.exists(task_out) and os.path.getsize(task_out) > 0:
        print('WORKFLOW_ENDED', time.strftime('%H:%M:%S')); break
    time.sleep(2)
