import re, sys
p = "src/epinoic_logic/branches/quant.py"
s = open(p, encoding="utf-8").read()
old = s[s.index("            why = _amount_pair(whole, part)\n            if why:\n                undecided.append(QuantUndecided(pi, si + 1, sent.strip(), phrase, why))\n                continue\n            wv, pv = _frac(whole.num, whole.unit), _frac(part.num, part.unit)"):s.index("        # 'about $2 billion more than France': the difference between two named parties' figures in the paragraph")]
new = '''            spec, why = _share_spec(clause, whole, part, m.group("frac"), m.group("pn"), m.group("q"), tolerance, phrase, basis)
            if spec is not None:
                specs.append(spec)
            elif why:
                undecided.append(QuantUndecided(pi, si + 1, sent.strip(), phrase, why))
        # '356 of the 535 seats, about three-quarters' / '..., about 75 per cent': a share of the whole named right before it
        for m in (_N_OF_M_SHARE_RE.finditer(clause) if " of " in clause else ()):
            part, whole = _share_fig(m, "p"), _share_fig(m, "w")
            if _year_like(part.num, part.unit or part.cur) or _year_like(whole.num, whole.unit or whole.cur):
                continue
            phrase = " ".join(m.group(0).split()).strip(" ,(")
            spec, why = _share_spec(clause, whole, part, m.group("frac"), m.group("pn"), m.group("q"), tolerance, phrase, "the part and the whole stated as 'N of the M'")
            if spec is not None:
                specs.append(spec)
            elif why:
                undecided.append(QuantUndecided(pi, si + 1, sent.strip(), phrase, why))
'''
assert old
s = s.replace(old, new, 1)
open(p, "w", encoding="utf-8").write(s)
