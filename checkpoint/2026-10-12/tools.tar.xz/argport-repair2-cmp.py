import sys,re
R={'missed':0,'caught_unnamed':1,'named':2,'false_alarm':0,'control_clean':1}
def load(p):
    d={}
    for l in open(p):
        parts=l.split()
        if len(parts)>=4 and parts[3] in R: d[parts[0]]=parts[3]
    return d
doc=open(sys.argv[1]).read()
for c in ['dev','holdout','holdout2']:
    F=load(f'port-verify/c1/corpus-c219b4f-{c}.log'); B=load(f'port-verify/c1/corpus-5990526-{c}.log'); P=load(f'port-verify/c2/corpus-{c}.log')
    for k in sorted(P):
        if k in F and R[P[k]]<R[F[k]]:
            print(c,k,'feat',F[k],'base',B.get(k),'port',P[k],'DOC' if k in doc else 'NOT-IN-DOC')
        if k in B and R[P[k]]<R[B[k]]: print('WORSE THAN BASE',c,k)
