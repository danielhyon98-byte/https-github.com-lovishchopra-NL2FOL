import sys,time,cProfile,pstats
from epinoic_logic import selfcert
selfcert.read('warm')
n=32768
t="x = 5" + " (A1)" * (n // 5) + " z "
selfcert.empty_caches() if hasattr(selfcert,'empty_caches') else None
cProfile.run('selfcert.read(t)',sys.argv[0]+'.out')
pstats.Stats(sys.argv[0]+'.out').sort_stats('tottime').print_stats(25)
