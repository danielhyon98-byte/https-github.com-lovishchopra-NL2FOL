import json,sys
d=json.load(sys.stdin)
print("REPORT", d.get("report_id"), d.get("group"))
for c in d["claims"]:
    print(f'{c["claim_id"]} | {c["role"]} | {c["materiality"]} | {c["certainty"]} | {c["text"]}')
