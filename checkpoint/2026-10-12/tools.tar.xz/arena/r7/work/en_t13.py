import sys, json
sys.path.insert(0, '/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/arena/r7/work')
from irlib import *
d, C = load('en-t13')
req = d['request_id']
READ = ("Read as the specialist's own argument. Evidence atoms are verbatim quotations from doc-shed; "
        "each interpretive step is an implies premise whose antecedent is the conjunction of the claims it cites as support "
        "(joint support). Certainty is the specialist's stated certainty (probable). The check tests whether the stated links "
        "carry the point; it does not judge the poem reading.")
out = {}
for t in ['p2-point', 'p3-point', 'p4-point', 'p1-s01', 'p1-s02']:
    syms, prems, conc, gl = chain(t, C, {})
    pr = problem('en-t13-' + t, req, t, syms, prems, conc,
                 notes="Encodes the specialist's support graph for claim " + t + " only; no premises added beyond the specialist's stated supports.")
    out[t] = result(pr, READ + " Claim encoded: " + C[t]['text'], gl)
json.dump({"report_id": d['report_id'], "claims": out}, open(W + '/../translations/en-t13.json', 'w'), indent=1, ensure_ascii=False)
print('wrote', list(out))
