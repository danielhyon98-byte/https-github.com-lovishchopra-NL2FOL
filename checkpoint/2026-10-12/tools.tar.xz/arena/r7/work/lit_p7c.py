import sys, json
sys.path.insert(0, '/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/arena/r7/work')
from irlib2 import *
d, C = load('lit-p7c')
req = d['request_id']
FLAG = ("MISATTRIBUTED_QUOTE", "Two quotations are attributed in the claim to the History specialist (peer:hi-p7c), but their words are located only in the poem (doc-bernauer). They are encoded against the poem, where they are verbatim.", ["Encode against peer:hi-p7c (the words are not located there)", "Encode against doc-bernauer where they are verbatim (as encoded)"])
READ = ("Read as the specialist's own argument. Quotations are verbatim spans of doc-bernauer or of the relayed History report (peer:hi-p7c), located by the parser. "
        "Each interpretive or device step is an implies premise whose antecedent is the conjunction of its cited supports (joint support). "
        "Unsupported interpretive steps are asserted as specialist inferences at the stated certainty.")
out = {}
for t in ['p1-point', 'p1-s10']:
    syms, prems, cc, gl = chain2(t, C, {})
    pr = problem('lit-p7c-' + t, req, t, syms, prems, cc, notes="Encodes the specialist's support graph for claim " + t + " only.")
    out[t] = result(pr, READ + " Claim: " + C[t]['text'], gl, [FLAG])
json.dump({"report_id": d['report_id'], "claims": out}, open('/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/arena/r7/translations/lit-p7c.json', 'w'), indent=1, ensure_ascii=False)
print('wrote', sorted(out))
