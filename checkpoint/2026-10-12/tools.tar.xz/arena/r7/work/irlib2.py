"""Extended chain builder (scratch; not part of the repository)."""
from irlib import *

def chain2(target, C, mean, arith=None, kinds=None, pre_syms=None, pre_prems=None):
    arith = arith or {}
    kinds = kinds or {}
    order, seen = [], set()
    def dfs(n):
        if n in seen:
            return
        seen.add(n)
        for s_ in C[n]['supporting_claim_ids']:
            dfs(s_)
        order.append(n)
    dfs(target)
    symbols = list(pre_syms or [])
    premises = list(pre_prems or [])
    inline = {}
    gl = []
    for n in order:
        c = C[n]
        mat = c['materiality']
        cert = c['certainty']
        g = mean.get(n, c['text'])
        sup = c['supporting_claim_ids']
        if n in arith:
            expr, label, kind = arith[n]
            inline[n] = expr
            if n != target:
                premises.append(prem('C-' + n, expr, label, grd(kind, [], cert), mat))
            continue
        located = [r for r in c['source_refs'] if r.get('located') and r.get('excerpt')]
        qrefs = [ref(r['document_id'], r['excerpt']) for r in located]
        parts = [inline[x] if x in inline else V(nm(x)) for x in sup]
        s = nm(n)
        if located and not sup:
            symbols.append(sym(s, "Bool", g, grd('quotation', qrefs, cert)))
            gl.append((s, g))
            premises.append(prem('E-' + n, V(s), g, grd('quotation', qrefs, cert), mat))
            continue
        if located and sup:
            symbols.append(sym(s, "Bool", g, grd('specialist_inference', [], cert)))
            gl.append((s, g))
            q = s + '_q'
            symbols.append(sym(q, "Bool", "text quoted for: " + g, grd('quotation', qrefs, cert)))
            premises.append(prem('E-' + n, V(q), "quoted text cited for: " + g, grd('quotation', qrefs, cert), mat))
            premises.append(prem('L-' + n, IMP(AND(V(q), *parts), V(s)), "the specialist's stated support for: " + g,
                                 grd('specialist_inference', [], cert), mat))
            continue
        if sup:
            symbols.append(sym(s, "Bool", g, grd('specialist_inference', [], cert)))
            gl.append((s, g))
            lhs = AND(*parts) if len(parts) > 1 else parts[0]
            premises.append(prem('L-' + n, IMP(lhs, V(s)), "the specialist's stated support for: " + g,
                                 grd('specialist_inference', [], cert), mat))
            continue
        k = kinds.get(n, 'specialist_inference') if n != target else 'specialist_inference'
        symbols.append(sym(s, "Bool", g, grd(k, [], cert)))
        gl.append((s, g))
        if n != target:
            premises.append(prem('A-' + n, V(s), g, grd(k, [], cert), mat))
    if target in arith:
        concl_expr = arith[target][0]
    else:
        concl_expr = V(nm(target))
    tg = mean.get(target, C[target]['text'])
    cc = concl(target, concl_expr, tg, grd('specialist_inference', [], C[target]['certainty']))
    return symbols, premises, cc, gl
