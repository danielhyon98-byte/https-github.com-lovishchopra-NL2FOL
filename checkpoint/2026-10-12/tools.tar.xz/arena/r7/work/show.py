import json,sys
for t in sys.argv[1:]:
    d=json.load(open(t+'.all.json'))
    print('=====',t,'report_id=',d['report_id'],'request_id=',d['request_id'],'branch=',d['branch'],'n=',len(d['claims']))
    for c in d['claims']:
        refs=[(r['document_id'], r.get('excerpt'), r['located']) for r in c['source_refs']]
        print(f"[{c['claim_id']}] role={c['role']} mat={c['materiality']} cert={c['certainty']} ELIG={c['eligible']} cls={c['eligibility_class']} sup={c['supporting_claim_ids']}")
        print('   TEXT:',c['text'])
        for r in refs: print('   REF:',r)
        for a in c['assumptions']: print('   ASSUMP:',a)
        if c['advisory_verification_status']: print('   SELF:',c['advisory_verification_status'])
