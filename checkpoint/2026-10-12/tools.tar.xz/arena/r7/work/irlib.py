"""Helpers for writing Epinoic IR 1.0 problems (translator scratch work; not part of the repository)."""
import json, re, copy
W = '/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/arena/r7/work'

def load(task):
    d = json.load(open(f'{W}/{task}.all.json'))
    return d, {c['claim_id']: c for c in d['claims']}

def V(n): return {"op": "var", "name": n}
def B(v): return {"op": "bool", "value": bool(v)}
def I(v): return {"op": "int", "value": str(v)}
def R(v): return {"op": "real", "value": str(v)}
def AND(*a): return {"op": "and", "args": list(a)} if len(a) > 1 else a[0]
def OR(*a): return {"op": "or", "args": list(a)} if len(a) > 1 else a[0]
def NOT(a): return {"op": "not", "arg": a}
def IMP(l, r): return {"op": "implies", "left": l, "right": r}
def IFF(l, r): return {"op": "iff", "left": l, "right": r}
def EQ(l, r): return {"op": "eq", "left": l, "right": r}
def NE(l, r): return {"op": "ne", "left": l, "right": r}
def LT(l, r): return {"op": "lt", "left": l, "right": r}
def LE(l, r): return {"op": "le", "left": l, "right": r}
def GT(l, r): return {"op": "gt", "left": l, "right": r}
def GE(l, r): return {"op": "ge", "left": l, "right": r}
def ADD(*a): return {"op": "add", "args": list(a)}
def MUL(*a): return {"op": "mul", "args": list(a)}
def SUB(l, r): return {"op": "sub", "left": l, "right": r}
def NEG(a): return {"op": "neg", "arg": a}
def DIV(l, r): return {"op": "div", "left": l, "right": r}
def TOREAL(a): return {"op": "to_real", "arg": a}

def ref(doc, excerpt=None, locator=None):
    r = {"document_id": doc}
    if excerpt is not None: r["excerpt"] = excerpt
    if locator: r["locator"] = locator
    return r

def grd(kind, refs=None, certainty="established", note=None):
    g = {"kind": kind, "source_refs": refs or [], "certainty": certainty}
    if note: g["note"] = note[:1000]
    return g

def sym(name, sort, meaning, grounding=None):
    s = {"name": name, "sort": sort, "meaning": meaning[:1000]}
    if grounding: s["grounding"] = grounding
    return s

def prem(pid, expr, label, grounding=None, materiality="material"):
    p = {"id": pid, "expr": expr, "label": label[:1000], "materiality": materiality}
    if grounding: p["grounding"] = grounding
    return p

def concl(cid, expr, label, grounding=None):
    c = {"id": cid, "expr": expr, "label": label[:1000], "materiality": "material"}
    if grounding: c["grounding"] = grounding
    return c

def problem(problem_id, req, claim_id, symbols, premises, conclusion, notes=None):
    p = {"ir_version": "1.0", "problem_id": problem_id, "request_id": req, "claim_id": claim_id,
         "query": "entailment", "symbols": symbols, "premises": premises, "conclusion": conclusion}
    if notes: p["notes"] = notes[:4000]
    return p

def result(problem_obj, reading, glossary, flags=None, unsupported=None):
    """glossary: list of (symbol, meaning). flags: list of (code, message, [alternatives])."""
    fl = [{"code": c, "message": m, "alternatives": a} for (c, m, a) in (flags or [])]
    return {"problem": problem_obj,
            "interpretation": {"reading": reading,
                               "glossary": [{"symbol": s, "meaning": m[:1000], "grounding": None} for s, m in glossary],
                               "ambiguity_flags": fl},
            "ambiguous": bool(fl),
            "unsupported_reason": unsupported}

def unsupported(claim_id, reason, req):
    return {"problem": None,
            "interpretation": {"reading": reason, "glossary": [], "ambiguity_flags": []},
            "ambiguous": False, "unsupported_reason": reason}

def nm(cid):
    return 's_' + re.sub(r'[^a-z0-9]+', '_', cid.lower()).strip('_')

def chain(target, C, mean, arith=None, pre_syms=None, pre_prems=None, tgt_ground=None):
    """Encode the specialist's support graph below `target` (claim id).
    C: claim id -> parsed claim record. mean: claim id -> English gloss (overrides claim text).
    arith: claim id -> (expr, label, grounding_kind) for quantitative nodes, asserted as premises
    (or, for the target, used as the conclusion expression).
    Quotation nodes (located source refs) are asserted by quotation; other supported nodes are
    implications from the conjunction of their supports; unsupported non-quotation nodes are
    asserted as specialist inferences."""
    arith = arith or {}
    order, seen = [], set()
    def dfs(n):
        if n in seen: return
        seen.add(n)
        for s in C[n]['supporting_claim_ids']:
            dfs(s)
        order.append(n)
    dfs(target)
    symbols = list(pre_syms or [])
    premises = list(pre_prems or [])
    inline = {}
    glossary = []
    for n in order:
        c = C[n]
        mat = c['materiality']
        cert = c['certainty']
        gloss = mean.get(n, c['text'])
        sup = c['supporting_claim_ids']
        if n in arith:
            expr, label, kind = arith[n]
            inline[n] = expr
            if n != target:
                premises.append(prem('C-' + n, expr, label, grd(kind, [], cert), mat))
            continue
        located = [r for r in c['source_refs'] if r.get('located') and r.get('excerpt')]
        if located and not sup:
            s = nm(n)
            symbols.append(sym(s, "Bool", gloss, grd("quotation", [ref(r['document_id'], r['excerpt']) for r in located], cert)))
            glossary.append((s, gloss))
            premises.append(prem('E-' + n, V(s), gloss, grd("quotation", [ref(r['document_id'], r['excerpt']) for r in located], cert), mat))
            continue
        s = nm(n)
        symbols.append(sym(s, "Bool", gloss, grd("specialist_inference", [], cert)))
        glossary.append((s, gloss))
        if sup:
            parts = [inline[x] if x in inline else V(nm(x)) for x in sup]
            if n == target: pass
            premises.append(prem('L-' + n, IMP(AND(*parts), V(s)) if len(parts) > 1 else IMP(parts[0], V(s)),
                                 "the specialist's stated support for: " + gloss, grd("specialist_inference", [], cert), mat))
        elif n != target:
            premises.append(prem('A-' + n, V(s), gloss, grd("specialist_inference", [], cert), mat))
    if target in arith:
        concl_expr = arith[target][0]
    else:
        concl_expr = V(nm(target))
    tcert = C[target]['certainty']
    conclusion = concl(target, concl_expr, mean.get(target, C[target]['text']), tgt_ground or grd("specialist_inference", [], tcert))
    return symbols, premises, conclusion, glossary
