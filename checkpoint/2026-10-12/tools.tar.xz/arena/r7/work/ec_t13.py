import sys, json
sys.path.insert(0, '/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/arena/r7/work')
from irlib2 import *
d, C = load('ec-t13')
req = d['request_id']
out = {}
ROUND = ("rounded", "The claim gives a value rounded to a fixed number of decimal places (for example 0.1190 or 0.1429) or a percentage to two places. The literal comparison is encoded as written; the exact quotient differs from the rounded figure, so the equality is false under exact arithmetic. A tolerance is not stated in the task, so none is encoded.", ["Literal equality with the rounded figure (as encoded)", "Rounded-to-stated-places equality (needs a stated tolerance or rounding rule)"])
def marks(cid, n, part):
    m = 'marks_' + part
    syms = [sym(m, "Int", "marks allocated to part (" + part + ") of the question")]
    pre = [prem('T-' + cid, EQ(V(m), I(n)), "part (" + part + ") carries " + str(n) + " marks",
                grd("task_setting", [], "established"), "material")]
    concl_ = concl(cid, EQ(V(m), I(n)), C[cid]['text'], grd("task_setting", [], "established"))
    pr = problem('ec-t13-' + cid, req, cid, syms, pre, concl_,
                 notes="Mark allocation transcribed from the question paper; no arithmetic.")
    return result(pr, "The claim restates the mark allocation printed beside part (" + part + ") of the question. Encoded as a task_setting premise and the same equality as the conclusion, so the check tests transcription only.",
                  [(m, "marks allocated to part (" + part + ")")])

out['g1.1'] = marks('g1.1', 2, 'i')
out['g3.1'] = marks('g3.1', 4, 'ii')

# value symbols for the krona conversion (Table 1 rates)
VAL_SYMS = [sym('v22', "Real", "value of one krona in US$, 2022 (1 / 8.40)"), sym('v25', "Real", "value of one krona in US$, 2025 (1 / 7.00)"), sym('pct', "Real", "percentage change in the krona's value, 2022 to 2025 (in per cent)")]
F_22 = EQ(V('v22'), DIV(R("1"), R("8.40")))
F_25 = EQ(V('v25'), DIV(R("1"), R("7.00")))
G22 = AND(F_22, F_25)
D22 = EQ(V('v22'), DIV(R("1"), R("8.40")))
D25 = EQ(V('v25'), DIV(R("1"), R("7.00")))
DP = EQ(V('pct'), MUL(SUB(DIV(R("8.40"), R("7.00")), R("1")), R("100")))
R22 = EQ(V('v22'), R("0.1190"))
R25 = EQ(V('v25'), R("0.1429"))
RP = EQ(V('pct'), R("20.00"))
G23 = AND(D22, D25, DP, R22, R25, RP)
ARITH = {'g2.2': (G22, C['g2.2']['text'], 'arithmetic_fact'), 'g2.3': (G23, C['g2.3']['text'], 'arithmetic_fact')}
M = {'g2.2': "Table 1 quotes the rate as krona per US$, so the value of one krona in US$ is 1 / exchange rate (2022: 1/8.40; 2025: 1/7.00).",
     'g2.3': "2022 value 1/8.40 = 0.1190; 2025 value 1/7.00 = 0.1429; percentage change via 8.40/7.00 - 1 = 0.20, i.e. a 20.00% appreciation of the krona."}
K = {'g5.2': 'supplied_text'}

# target g2.2 (no supports): conclusion is the instance formula; no uncited premise is added
syms, prems, cc, gl = chain2('g2.2', C, M, arith=ARITH, pre_syms=VAL_SYMS)
pr = problem('ec-t13-g2.2', req, 'g2.2', syms, prems, cc, notes="Formula instantiated for the two Table 1 rates.")
out['g2.2'] = result(pr, "Encodes the conversion formula instantiated at the two Table 1 rates (8.40 and 7.00 krona per US$). The claim's premise (the table quotes krona per US$) is stated in the claim but not cited, so it is not encoded; the conclusion is therefore not entailed by the table alone.",
                     [('v22', 'value of one krona in US$, 2022'), ('v25', 'value of one krona in US$, 2025')],
                     [("UNCITED_FACT", "The conversion relies on the table quoting the rate as krona per US$. The specialist does not cite that convention, so it is not added as a premise.", ["Add the table convention as a supplied-text premise (changes the verdict)", "Leave it out (as encoded)"]), ROUND])

# target g2.3: exact operations are premises; the stated rounded results are the conclusion
syms = list(VAL_SYMS)
pre = [prem('D-22', D22, "1 / 8.40 (exact operation)", grd("arithmetic_fact", [], "established"), "supporting"),
       prem('D-25', D25, "1 / 7.00 (exact operation)", grd("arithmetic_fact", [], "established"), "supporting"),
       prem('D-pct', DP, "(8.40 / 7.00 - 1) x 100 (exact operation)", grd("arithmetic_fact", [], "established"), "supporting")]
cc = concl('g2.3', AND(R22, R25, RP), C['g2.3']['text'], grd("specialist_inference", [], "probable"))
pr = problem('ec-t13-g2.3', req, 'g2.3', syms, pre, cc, notes="Exact operations as premises; the specialist's stated rounded results as the conclusion.")
out['g2.3'] = result(pr, "Exact operations (1/8.40, 1/7.00, (8.40/7.00 - 1) x 100) are premises. The conclusion is the specialist's stated results as written: 0.1190, 0.1429 and 20.00. The first two are rounded, so the literal equality is false under exact arithmetic; the percentage result is exact.",
                     [('v22', 'value of one krona in US$, 2022'), ('v25', 'value of one krona in US$, 2025'), ('pct', 'percentage change')], [ROUND])

# target g2.1: supports are the two arithmetic steps
syms, prems, cc, gl = chain2('g2.1', C, M, arith=ARITH, pre_syms=VAL_SYMS)
pr = problem('ec-t13-g2.1', req, 'g2.1', syms, prems, cc, notes="Specialist's support graph: g2.2 and g2.3 jointly support g2.1.")
out['g2.1'] = result(pr, "The measure is read as the specialist's own chain: the value formula (g2.2) and the stated working (g2.3) jointly support the measure. Both are encoded as asserted arithmetic premises, so the rounded decimals in g2.3 make the premise set inconsistent under exact arithmetic.",
                     [('v22', 'value of one krona in US$, 2022'), ('v25', 'value of one krona in US$, 2025')], [ROUND])

# target g4.1: diagram description; no supports and nothing cited
D_syms = [sym(n, "Real", m) for n, m in [('p1', 'price of 1 krona, initial equilibrium'), ('p2', 'price of 1 krona, new equilibrium'), ('q1', 'quantity of krona, initial equilibrium'), ('q2', 'quantity of krona, new equilibrium')]]
concl_ = concl('g4.1', AND(GT(V('p2'), V('p1')), GT(V('q2'), V('q1'))), "The diagram shows P2 above P1 and Q2 above Q1 (new equilibrium above initial).", grd("specialist_inference", [], "established"))
pr = problem('ec-t13-g4.1', req, 'g4.1', D_syms, [], concl_, notes="Diagram description; the diagram itself is not supplied.")
out['g4.1'] = result(pr, "Encodes only the equilibrium comparison stated in the diagram description. The diagram's supply and demand shapes and the demand shift are not cited as supports, and no economic rule linking a rightward demand shift and upward supply to higher price and quantity is stated, so the conclusion is not entailed.",
                     [('p1', 'price of 1 krona, initial'), ('p2', 'price of 1 krona, new'), ('q1', 'quantity, initial'), ('q2', 'quantity, new')],
                     [("MISSING_RULE", "The claim does not state the rule that links the demand shift and supply shape to higher price and quantity. The rule is not added.", ["Add the standard shift rule as general knowledge (changes the verdict)", "Leave it out (as encoded)"])])

# target g5.2: paragraph report with no supports and no citation
syms, prems, cc, gl = chain2('g5.2', C, M, kinds=K)
pr = problem('ec-t13-g5.2', req, 'g5.2', syms, prems, cc, notes="No supports and no citation in the specialist report.")
out['g5.2'] = result(pr, "The claim reports what paragraph 2 says. The words are verbatim in paragraph 2 ('Higher interest rates attracted financial capital from abroad'), but the specialist cites no excerpt, so no quotation is added and the conclusion is not entailed.",
                     [('s_g5_2', C['g5.2']['text'])],
                     [("UNCITED_TEXT", "The claim is a text-report with no excerpt cited. The matching words exist in paragraph 2 but are not added as a premise.", ["Ground by quotation from paragraph 2 (changes the verdict)", "Leave ungrounded (as encoded)"])])

# target g5.3: judgement with no supports
syms, prems, cc, gl = chain2('g5.3', C, M, kinds=K)
pr = problem('ec-t13-g5.3', req, 'g5.3', syms, prems, cc, notes="No supports in the specialist report.")
out['g5.3'] = result(pr, "The claim is the specialist's statement that foreign investors must buy krona, so demand shifts right. No support is cited, so nothing is asserted to entail it and the conclusion is not entailed.",
                     [('s_g5_3', C['g5.3']['text'])])

# target g5.1: supports g5.2 to g5.5 (paragraph-1 rate fact is uncited and not encoded)
syms, prems, cc, gl = chain2('g5.1', C, M, kinds={'g5.2': 'supplied_text'})
pr = problem('ec-t13-g5.1', req, 'g5.1', syms, prems, cc, notes="Support graph of g5.1 as parsed; the paragraph-1 rate fact is not a support.")
out['g5.1'] = result(pr, "Read as the specialist's own argument: its four supports (paragraph 2 report, demand shift, shift-versus-movement note, appreciation step) jointly support the claim. The opening rate fact is not among the supports and is not encoded.",
                     [(s, m) for s, m in gl],
                     [("UNCITED_FACT", "The claim opens with the policy rate rising from 1.50 to 4.75 per cent (paragraph 1, verbatim in the text). That fact is not among its supports, so it is not encoded. Encoding it would change the entailment.", ["Add the rate fact as a quotation premise (changes the verdict)", "Leave it out (as encoded)"])])

json.dump({"report_id": d['report_id'], "claims": out}, open('/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/arena/r7/translations/ec-t13.json', 'w'), indent=1, ensure_ascii=False)
print('wrote', sorted(out))
