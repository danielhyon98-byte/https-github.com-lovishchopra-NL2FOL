import sys, json
sys.path.insert(0, '/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/arena/r7/work')
from irlib2 import *
d, C = load('maa-p7b')
req = d['request_id']
OUT = {}
EXP = "IR 1.0 has no exponential or logarithm and no quantification over time. "
def unsup(cid, reason):
    OUT[cid] = {"problem": None,
                "interpretation": {"reading": reason, "glossary": [], "ambiguity_flags": []},
                "ambiguous": False, "unsupported_reason": reason}
unsup('g1.1', EXP + "The claim is the functional form C(t) = C0 e^(-kt) for all t, which needs an exponential term and quantification over t, so it cannot be encoded.")
unsup('g2.1', EXP + "The value k = (ln 2)/8 needs a logarithm, so the derivation of k cannot be encoded without approximating it.")
unsup('g3.1', EXP + "The claim is the header for part (b) whose content is the half-life derived with ln 2 (g3.2). That derivation needs a logarithm and a non-linear product of two non-constant terms.")
unsup('g3.2', EXP + "The half-life T = ln 2 / k = 8 needs logarithms and a division by a non-constant term (k), which are outside the allowlist.")
unsup('g4.1', EXP + "The solution of C(t) < 50 needs exponentials and an inequality over t, which cannot be encoded.")
unsup('g4.2', EXP + "The claim that the rate stays below 50 for every later time is a universal statement over time, which IR 1.0 does not allow.")
unsup('g5.1', EXP + "The claim takes the logarithm of the model (ln C = ln C0 - kt) and reads its gradient, which needs logarithms.")
unsup('g5.2', EXP + "The gradient -(ln 2)/8 needs a logarithm.")
unsup('g7.1', EXP + "The cross-check involves lambda = 0.693/8.0 agreeing with (ln 2)/8 and a half-life check; the second part needs a logarithm, and dropping it would change the claim.")
unsup('g8.1', EXP + "The worst-case half-lives 8 ln 2 / ln(1568/816) and 8 ln 2 / ln(1632/784) need logarithms.")
unsup('g8.2', EXP + "The comparison depends on the worst-case half-lives (about 8.5 h and 7.6 h), which need logarithms.")
unsup('g9.1', "The claim states that no textbook library or MyLib was available in this session. It is a statement about the answerer's resources, not a proposition about the supplied material or task, so there is nothing to encode in IR 1.0.")
# g1.2: the two quoted corrected count rates, C0 = 1600 and C(8) = 800
DOC_PEER = 'peer:ph-p7b'
q0 = sym('q0', "Bool", "quoted: t = 0 h: 1620 - 20 = 1600 counts per minute, so C0 = 1600", grd("quotation", [ref(DOC_PEER, "t = 0 h: 1620 − 20 = 1600 ± 32 counts min⁻¹")]))
q8 = sym('q8', "Bool", "quoted: t = 8 h: 820 - 20 = 800 counts per minute, so C(8) = 800", grd("quotation", [ref(DOC_PEER, "t = 8 h: 820 − 20 = 800 ± 16 counts min⁻¹")]))
c0 = sym('c0', "Real", "corrected count rate at t = 0 (C0, counts per minute)")
c8 = sym('c8', "Real", "corrected count rate at t = 8 h (counts per minute)")
pre = [prem('E-q0', V('q0'), "the Physics report quotes the t = 0 corrected rate", grd("quotation", [ref(DOC_PEER, "t = 0 h: 1620 − 20 = 1600 ± 32 counts min⁻¹")]), "supporting"),
       prem('E-q8', V('q8'), "the Physics report quotes the t = 8 corrected rate", grd("quotation", [ref(DOC_PEER, "t = 8 h: 820 − 20 = 800 ± 16 counts min⁻¹")]), "supporting"),
       prem('L-q0', IMP(V('q0'), EQ(SUB(R("1620"), R("20")), V('c0'))), "1620 - 20 = 1600, so C0 = 1600", grd("arithmetic_fact", [], "established"), "supporting"),
       prem('L-q8', IMP(V('q8'), EQ(SUB(R("820"), R("20")), V('c8'))), "820 - 20 = 800, so C(8) = 800", grd("arithmetic_fact", [], "established"), "supporting")]
cc = concl('g1.2', AND(EQ(V('c0'), R("1600")), EQ(V('c8'), R("800"))), C['g1.2']['text'], grd("quotation", [ref(DOC_PEER)]))
OUT['g1.2'] = result(problem('maa-p7b-g1.2', req, 'g1.2', [q0, q8, c0, c8], pre, cc, notes="Values quoted from the Physics report (peer:ph-p7b)."),
                     "Encodes the two corrected count rates quoted from the Physics report: t = 0 gives 1620 - 20 = 1600 (C0), and t = 8 gives 820 - 20 = 800 (C(8)). The quotations are located verbatim in the relayed report, and the subtraction is exact.",
                     [('q0', 'quoted t = 0 rate'), ('q8', 'quoted t = 8 rate'), ('c0', 'C0'), ('c8', 'C(8)')])
# g7.2: the quoted halving sequence; the matching with an 8-hour half-life is uncited
q72 = sym('q72', "Bool", "quoted: the corrected rate halves each time: 1600 to 800, 800 to 400, 400 to 200 counts per minute", grd("quotation", [ref(DOC_PEER, "The corrected rate halves each time: 1600 to 800 counts min⁻¹ between 0 and 8 h, 800 to 400 between 8 and 16 h, and 400 to 200 between 16 and 24 h.")]))
m8 = sym('m8', "Bool", "the halving sequence matches an 8-hour half-life", grd("specialist_inference", [], "established"))
pre = [prem('E-q72', V('q72'), "the Physics report states the halving sequence", grd("quotation", [ref(DOC_PEER, "The corrected rate halves each time: 1600 to 800 counts min⁻¹ between 0 and 8 h, 800 to 400 between 8 and 16 h, and 400 to 200 between 16 and 24 h.")]), "supporting")]
cc = concl('g7.2', AND(V('q72'), AND(EQ(MUL(R("0.5"), R("1600")), R("800")), EQ(MUL(R("0.5"), R("800")), R("400")), EQ(MUL(R("0.5"), R("400")), R("200"))), V('m8')), C['g7.2']['text'], grd("quotation", [ref(DOC_PEER)]))
OUT['g7.2'] = result(problem('maa-p7b-g7.2', req, 'g7.2', [q72, m8], pre, cc, notes="Quoted halving sequence; the match to an 8-hour half-life is not cited."),
                     "Encodes the quoted halving sequence (each value is half the previous one, which holds exactly) and the claim's statement that this matches an 8-hour half-life. The match is the specialist's own judgement with no cited derivation, so the conclusion is not entailed.",
                     [('q72', 'quoted halving sequence'), ('m8', 'halving matches an 8-hour half-life')],
                     [("UNCITED_MATCH", "The step from the halving sequence to an 8-hour half-life needs the exponential model, which IR 1.0 cannot state. The match is not added as a premise.", ["Accept the match as the specialist's inference (changes the verdict)", "Leave it uncited (as encoded)"])])
json.dump({"report_id": d['report_id'], "claims": OUT}, open('/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/arena/r7/translations/maa-p7b.json', 'w'), indent=1, ensure_ascii=False)
print('wrote', sorted(OUT))
