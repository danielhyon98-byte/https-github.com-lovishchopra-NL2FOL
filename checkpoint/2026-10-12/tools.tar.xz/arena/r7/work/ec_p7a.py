import sys, json
sys.path.insert(0, '/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/arena/r7/work')
from irlib2 import *
d, C = load('ec-p7a')
req = d['request_id']
DOC = 'doc-varenland'
BS = [sym('p24', "Real", "price paid by consumers, 2024 ($ per litre, Table 1)"), sym('pc25', "Real", "price paid by consumers, 2025 ($ per litre, Table 1)"),
      sym('q24', "Real", "quantity sold, 2024 (million litres, Table 1)"), sym('q25', "Real", "quantity sold, 2025 (million litres, Table 1)"),
      sym('tax25', "Real", "tax per litre, 2025 ($, stated in the text and Table 1)")]
BP = [prem('T-p24', EQ(V('p24'), R("1.60")), "2024 price paid by consumers is $1.60 per litre", grd("supplied_text", [ref(DOC)]), "supporting"),
      prem('T-pc25', EQ(V('pc25'), R("1.90")), "2025 price paid by consumers is $1.90 per litre", grd("supplied_text", [ref(DOC)]), "supporting"),
      prem('T-q24', EQ(V('q24'), R("120")), "2024 quantity sold is 120 million litres", grd("supplied_text", [ref(DOC)]), "supporting"),
      prem('T-q25', EQ(V('q25'), R("105")), "2025 quantity sold is 105 million litres", grd("supplied_text", [ref(DOC)]), "supporting"),
      prem('T-tax25', EQ(V('tax25'), R("0.40")), "tax of $0.40 per litre from 1 January 2025", grd("supplied_text", [ref(DOC)]), "supporting")]
ANCH = EQ(V('q25'), R("105"))
ROUND = ("ROUNDED_LITERAL", "The claim gives a rounded result (for example -0.67 or -17.97). The literal equality is encoded; the exact quotient differs from the rounded figure. No tolerance or rounding rule is stated in the task.", ["Literal equality with the rounded figure (as encoded)", "Equality to the stated places (needs a rounding rule)"])
def ar(expr):
    return AND(ANCH, *expr) if isinstance(expr, list) else AND(ANCH, expr)
EX = {}
EX['g2.2'] = (ar([EQ(MUL(DIV(SUB(R("105"), R("120")), R("120")), R("100")), R("-12.50")),
                  EQ(MUL(DIV(SUB(R("1.90"), R("1.60")), R("1.60")), R("100")), R("18.75")),
                  EQ(DIV(R("-12.50"), R("18.75")), R("-0.67"))]), C['g2.2']['text'], 'arithmetic_fact')
EX['g4.2'] = (ar(EQ(MUL(R("0.40"), R("105")), R("42"))), C['g4.2']['text'], 'arithmetic_fact')
EX['g4.1'] = (ar(EQ(MUL(R("0.40"), R("105")), R("42"))), C['g4.1']['text'], 'arithmetic_fact')
EX['g6.2'] = (ar([EQ(SUB(R("1.90"), R("0.40")), R("1.50")), EQ(SUB(R("1.90"), R("1.60")), R("0.30")), EQ(MUL(R("0.30"), R("105")), R("31.50")),
                  EQ(SUB(R("1.60"), R("1.50")), R("0.10")), EQ(MUL(R("0.10"), R("105")), R("10.50")), EQ(ADD(R("31.50"), R("10.50")), R("42.00"))]), C['g6.2']['text'], 'arithmetic_fact')
EX['g6.3'] = (ar([EQ(SUB(R("1.90"), R("1.60")), R("0.30")), EQ(SUB(R("1.60"), R("1.50")), R("0.10")), EQ(MUL(DIV(R("31.50"), R("42")), R("100")), R("75")), EQ(MUL(DIV(R("10.50"), R("42")), R("100")), R("25"))]), C['g6.3']['text'], 'arithmetic_fact')
EX['g8.2'] = (ar([EQ(MUL(R("1.60"), R("120")), R("192.00")), EQ(MUL(R("1.50"), R("105")), R("157.50")), EQ(SUB(R("157.50"), R("192.00")), R("-34.50")),
                  EQ(MUL(DIV(R("-34.50"), R("192.00")), R("100")), R("-17.97")), EQ(MUL(R("1.90"), R("105")), R("199.50")), EQ(ADD(R("157.50"), R("42.00")), R("199.50"))]), C['g8.2']['text'], 'arithmetic_fact')
EX['g8.3'] = (ar([EQ(SUB(R("157.50"), R("192.00")), R("-34.50")), EQ(MUL(DIV(R("-34.50"), R("192.00")), R("100")), R("-17.97"))]), C['g8.3']['text'], 'arithmetic_fact')
EX['g10.1'] = (AND(EQ(V('p24'), R("1.60")), EQ(V('q24'), R("120")), EQ(SUB(R("1.90"), R("1.60")), R("0.30")), EQ(SUB(R("1.60"), R("1.50")), R("0.10")),
                   EQ(MUL(R("0.30"), R("105")), R("31.50")), EQ(MUL(R("0.10"), R("105")), R("10.50")), EQ(SUB(R("1.90"), R("1.50")), R("0.40")), ANCH), C['g10.1']['text'], 'arithmetic_fact')
EX['g11.2'] = (AND(EQ(V('pc25'), R("1.90")), EQ(SUB(R("1.90"), R("0.40")), R("1.50")), EQ(V('q25'), R("105")), ANCH), C['g11.2']['text'], 'arithmetic_fact')
M = {'g2.1': "Measure: price elasticity of demand for sugar-sweetened drinks, 2024 to 2025, using the price paid by consumers.",
     'g2.3': "Demand is price inelastic, because its absolute value, 0.67, is less than 1.",
     'g6.1': "Measure: tax burden per litre and in total, 2025, for consumers and for producers.",
     'g8.1': "Measure: producers' revenue after tax = price received by producers x quantity sold.",
     'g11.1': "Consumers bear most of the tax because demand is relatively price inelastic (PED -0.67 implies quantity falls by proportionally less than price rises: 12.50% against 18.75%)."}
MARKS = {'g1.1': (2, 'i'), 'g3.1': (1, 'ii'), 'g5.1': (2, 'iii'), 'g7.1': (2, 'iv'), 'g9.1': (3, 'v')}
OUT = {}
def marks(cid):
    n, part = MARKS[cid]
    m = 'marks_' + part
    syms = [sym(m, "Int", "marks allocated to part (" + part + ") of the question")]
    pre = [prem('T-' + cid, EQ(V(m), I(n)), "part (" + part + ") carries " + str(n) + " marks", grd("task_setting", [], "established"))]
    c = concl(cid, EQ(V(m), I(n)), C[cid]['text'], grd("task_setting", [], "established"))
    pr = problem('ec-p7a-' + cid, req, cid, syms, pre, c, notes="Mark allocation transcribed from the question.")
    return result(pr, "The claim restates the mark allocation printed beside part (" + part + "). Encoded as a task_setting premise and the same equality as conclusion; checks transcription only.", [(m, 'marks for part ' + part)])
for cid in MARKS: OUT[cid] = marks(cid)
# g2.2: arithmetic target (rounded PED is the non-entailed element)
syms, prems, cc, gl = chain2('g2.2', C, M, arith={'g2.2': EX['g2.2']}, pre_syms=BS, pre_prems=BP)
OUT['g2.2'] = result(problem('ec-p7a-g2.2', req, 'g2.2', syms, prems, cc, notes="Literal arithmetic of PED with Table 1 data."),
                     "Encodes the stated working (percentage changes -12.50% and 18.75%, both exact) and the stated PED of -0.67. The exact PED is -12.50/18.75 = -2/3, so the rounded literal is not entailed.",
                     [('p24', 'price 2024'), ('q25', 'quantity 2025')], [ROUND])
# g2.3: magnitude comparison plus the claimed inelasticity (the link is not cited)
s23 = sym('s_g2_3', "Bool", M['g2.3'], grd("specialist_inference", [], "established"))
c23 = concl('g2.3', AND(LT(R("0.67"), R("1")), V('s_g2_3')), C['g2.3']['text'], grd("specialist_inference", [], "established"))
OUT['g2.3'] = result(problem('ec-p7a-g2.3', req, 'g2.3', BS + [s23], BP, c23, notes="Magnitude check; inelastic conclusion uncited."),
                     "Encodes the magnitude comparison 0.67 < 1 and the claimed inelasticity. The claim gives no citation for the inference from |PED| < 1 to inelastic demand, so the inelasticity conjunct is not entailed.",
                     [('s_g2_3', 'demand is price inelastic')],
                     [("UNCITED_LINK", "The step from |PED| < 1 to inelastic demand is the claim's own 'because' and is not cited as a support; it is not added as a premise.", ["Add the |PED| < 1 definition as a specialist inference (changes the verdict)", "Leave it uncited (as encoded)"])])
# g2.1: measure, supported by the arithmetic g2.2 and the inelasticity claim g2.3
syms, prems, cc, gl = chain2('g2.1', C, M, arith={'g2.2': EX['g2.2']}, pre_syms=BS, pre_prems=BP)
OUT['g2.1'] = result(problem('ec-p7a-g2.1', req, 'g2.1', syms, prems, cc, notes="Support graph: g2.2 (arithmetic) and g2.3 (asserted)."),
                     "Read as the specialist's own chain: the PED working (g2.2) and the inelasticity statement (g2.3) jointly support the measure. The rounded -0.67 is asserted as a premise, so the premise set is inconsistent under exact arithmetic.",
                     gl, [ROUND])
# g4.2 and g4.1: tax revenue
for cid in ['g4.2', 'g4.1']:
    syms, prems, cc, gl = chain2(cid, C, M, arith={'g4.2': EX['g4.2'], 'g4.1': EX['g4.1']}, pre_syms=BS, pre_prems=BP)
    OUT[cid] = result(problem('ec-p7a-' + cid, req, cid, syms, prems, cc, notes="Tax revenue 2025 = 0.40 x 105."),
                      "The stated tax revenue equals $0.40 times the 2025 quantity of 105 million litres, giving $42 million per year. The arithmetic is exact.",
                      gl)
# g6.2, g6.3 arithmetic; g6.1 measure supported by both
for cid in ['g6.2', 'g6.3']:
    syms, prems, cc, gl = chain2(cid, C, M, arith={'g6.2': EX['g6.2'], 'g6.3': EX['g6.3']}, pre_syms=BS, pre_prems=BP)
    OUT[cid] = result(problem('ec-p7a-' + cid, req, cid, syms, prems, cc, notes="Burden arithmetic from Table 1 and the 2025 tax."),
                      "Exact burden arithmetic: consumers bear $0.30 per litre ($31.50 million), producers $0.10 per litre ($10.50 million), summing to the $42 million revenue.", gl)
syms, prems, cc, gl = chain2('g6.1', C, M, arith={'g6.2': EX['g6.2'], 'g6.3': EX['g6.3']}, pre_syms=BS, pre_prems=BP)
OUT['g6.1'] = result(problem('ec-p7a-g6.1', req, 'g6.1', syms, prems, cc, notes="Measure supported by g6.2 and g6.3."),
                     "The measure is read as the specialist's own chain: the burden arithmetic (g6.2) and the shares (g6.3) jointly support the measure.", gl)
# g8.2, g8.3 arithmetic; g8.1 measure
for cid in ['g8.2', 'g8.3']:
    syms, prems, cc, gl = chain2(cid, C, M, arith={'g8.2': EX['g8.2'], 'g8.3': EX['g8.3']}, pre_syms=BS, pre_prems=BP)
    OUT[cid] = result(problem('ec-p7a-' + cid, req, cid, syms, prems, cc, notes="Producers' revenue arithmetic."),
                      "Exact revenue arithmetic: $192.00 million (2024), $157.50 million (2025), change -$34.50 million. The percentage -17.97% is the rounded value of -17.96875%; the literal equality is encoded.",
                      [(s, m) for s, m in gl], [ROUND])
syms, prems, cc, gl = chain2('g8.1', C, M, arith={'g8.2': EX['g8.2'], 'g8.3': EX['g8.3']}, pre_syms=BS, pre_prems=BP)
OUT['g8.1'] = result(problem('ec-p7a-g8.1', req, 'g8.1', syms, prems, cc, notes="Measure supported by g8.2 and g8.3."),
                     "The measure is read as the specialist's own chain (g8.2 and g8.3 jointly support it). The rounded percentage in g8.2 and g8.3 is asserted as a premise, so the premise set is inconsistent under exact arithmetic.", gl, [ROUND])
# g10.1 diagram description (arithmetic target)
syms, prems, cc, gl = chain2('g10.1', C, M, arith={'g10.1': EX['g10.1']}, pre_syms=BS, pre_prems=BP)
OUT['g10.1'] = result(problem('ec-p7a-g10.1', req, 'g10.1', syms, prems, cc, notes="Diagram description as numeric facts."),
                      "Encodes the numerical content of the diagram description (prices, quantity, and the two burden rectangles). The diagram's curve shapes are not encoded.", gl,
                      [("DIAGRAM_SHAPES", "The shapes and shifts of the curves are not encoded as IR facts; only the numbers in the description are.", ["Encode the shift as a Bool premise (not supplied)", "Leave shapes out (as encoded)"])])
# g11.2 arithmetic target; g11.1 point
syms, prems, cc, gl = chain2('g11.2', C, M, arith={'g11.2': EX['g11.2']}, pre_syms=BS, pre_prems=BP)
OUT['g11.2'] = result(problem('ec-p7a-g11.2', req, 'g11.2', syms, prems, cc, notes="Diagram equilibrium values."),
                      "Encodes the diagram's equilibrium values: consumers pay $1.90, producers keep $1.50, at 105 million litres.", gl)
syms, prems, cc, gl = chain2('g11.1', C, M, arith={'g11.2': EX['g11.2']}, pre_syms=BS, pre_prems=BP)
OUT['g11.1'] = result(problem('ec-p7a-g11.1', req, 'g11.1', syms, prems, cc, notes="Support graph of g11.1 as parsed."),
                      "Read as the specialist's own argument: the diagram equilibrium (g11.2), the burden split (g11.3) and the caveat about supply (g11.4) jointly support the claim. The inference from PED to the burden split is not cited and is not encoded.",
                      gl, [("UNCITED_LINK", "The claim relies on demand inelasticity explaining the split. That link is the specialist's own and is not cited as a support; it is not added.", ["Add the elasticity-to-burden rule as a specialist inference (changes the verdict)", "Leave it out (as encoded)"])])
json.dump({"report_id": d['report_id'], "claims": OUT}, open('/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/arena/r7/translations/ec-p7a.json', 'w'), indent=1, ensure_ascii=False)
print('wrote', sorted(OUT))
