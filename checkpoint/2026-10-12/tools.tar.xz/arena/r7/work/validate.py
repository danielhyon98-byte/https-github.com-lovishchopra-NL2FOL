import json, glob, os
RANK = {"possible": 0, "probable": 1, "established": 2}
ok = True
for f in sorted(glob.glob("work/lc/*.json")):
    tid = os.path.basename(f)[:-5]
    lc = json.load(open(f))
    syn_path = f"syntheses/{tid}.json"
    syn = json.load(open(syn_path))
    claims_by_id = {c["claim_id"]: c for c in lc["claims"]}
    problems = []
    if syn["report_id"] != lc["report_id"]:
        problems.append(f"report_id mismatch {syn['report_id']} vs {lc['report_id']}")
    n = len(syn["claims"])
    if not (2 <= n <= 4):
        problems.append(f"claim count {n}")
    used = set()
    for s in syn["claims"]:
        if s["transformation"] not in ("carried", "paraphrased", "merged", "narrowed"):
            problems.append(f"bad transformation {s['transformation']}")
        if s["certainty"] not in RANK:
            problems.append(f"bad certainty {s['certainty']}")
        if not s["source_claim_ids"]:
            problems.append("no sources")
        mins = []
        for sid in s["source_claim_ids"]:
            used.add(sid)
            if sid not in claims_by_id:
                problems.append(f"unknown source {sid}")
                continue
            mins.append(claims_by_id[sid]["certainty"])
        if mins:
            weakest = min(mins, key=lambda x: RANK[x])
            if RANK[s["certainty"]] > RANK[weakest]:
                problems.append(f"certainty {s['certainty']} stronger than weakest source {weakest} in {s['source_claim_ids']}")
        if not s["text"].strip() or "\n" in s["text"]:
            problems.append("bad text")
    dropped_ids = set()
    for d in syn["dropped"]:
        if not d.get("reason"):
            problems.append("dropped without reason")
        for sid in d["source_claim_ids"]:
            dropped_ids.add(sid)
            if sid not in claims_by_id:
                problems.append(f"unknown dropped id {sid}")
    material = [c["claim_id"] for c in lc["claims"] if c["materiality"] != "supporting"]
    missing = [m for m in material if m not in used and m not in dropped_ids]
    if missing:
        problems.append(f"material not covered: {missing}")
    extra_dropped_nonmaterial = [d for d in dropped_ids if claims_by_id.get(d, {}).get("materiality") == "supporting"]
    if extra_dropped_nonmaterial:
        problems.append(f"dropped non-material ids: {extra_dropped_nonmaterial}")
    both = [m for m in material if m in used and m in dropped_ids]
    if both:
        problems.append(f"both used and dropped: {both}")
    print(tid, "OK" if not problems else "PROBLEMS: " + "; ".join(problems), f"claims={n} material={len(material)} dropped={sorted(dropped_ids)}")
    ok = ok and not problems
print("ALL OK" if ok else "SEE PROBLEMS")
