import json, subprocess, sys
R = '/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/arena/r7'
PY = '/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/z3venv/bin/python'
REPO = '/home/user/https-github.com-lovishchopra-NL2FOL'
tasks = ['en-t13', 'ec-t13', 'sp-t13', 'bi-t13', 'ec-p7a', 'bm-p7a', 'maa-p7b', 'lit-p7c']
summary = {}
for t in tasks:
    el = json.load(open(f'{R}/work/{t}.claims.json'))
    want = sorted(c['claim_id'] for c in el['claims'])
    tr = json.load(open(f'{R}/translations/{t}.json'))
    got = sorted(tr['claims'])
    assert tr['report_id'] == el['report_id'], (t, 'report_id')
    missing = sorted(set(want) - set(got)); extra = sorted(set(got) - set(want))
    ok_n = nul = bad = 0
    for cid, obj in tr['claims'].items():
        p = obj['problem']
        if p is None:
            nul += 1
            assert obj['unsupported_reason'], (t, cid)
            continue
        assert p['claim_id'] == cid and p['request_id'] == el['request_id'], (t, cid, 'ids')
        r = subprocess.run([PY, '-I', '-c', 'import json,sys; from epinoic_logic.engine import parse_and_validate; p,o=parse_and_validate(json.dumps(json.load(open(sys.argv[1]))["claims"][sys.argv[2]]["problem"])); print(o.ok)', f'{R}/translations/{t}.json', cid],
                           cwd=REPO, capture_output=True, text=True, env={'PYTHONDONTWRITEBYTECODE': '1', 'PATH': '/usr/bin:/bin'})
        if r.stdout.strip() == 'True': ok_n += 1
        else: bad += 1; print('FAIL', t, cid, r.stdout, r.stderr[-300:])
    summary[t] = dict(eligible=len(want), translated=len(got), missing=missing, extra=extra, valid=ok_n, null_unsupported=nul, failed=bad)
for t, s in summary.items(): print(t, s)
