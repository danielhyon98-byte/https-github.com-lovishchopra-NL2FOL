import sys, json, copy
sys.path.insert(0, '/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/arena/r7/work')
from irlib2 import *
d, C = load('bi-t13')
req = d['request_id']
DOC = 'doc-resp'
TAB = {10: 18, 15: 27, 20: 40, 25: 58, 30: 80, 35: 92, 40: 61}
T_SYMS = [sym('t%d' % k, "Real", "mean oxygen uptake at %d C (mm3 per g per hour), Table" % k) for k in TAB]
T_PREMS = [prem('T-t%d' % k, EQ(V('t%d' % k), R(str(v))), "oxygen uptake at %d C is %d mm3 per g per hour (Table)" % (k, v),
                grd("supplied_text", [ref(DOC)], "established"), "supporting") for k, v in TAB.items()]
def t(k): return V('t%d' % k)
def dif(a, b): return SUB(t(b), t(a))   # rise from a to b
OUT = {}
M = {}
pct = [sym('pct', "Real", "percentage increase in oxygen uptake between 20 C and 30 C (per cent)")]
CD = [prem('D-pct', EQ(MUL(V('pct'), R("40")), MUL(SUB(t(30), t(20)), R("100"))),
           "percentage increase = (80 - 40) / 40 x 100, written as pct x 40 = (t30 - t20) x 100 (40 is the 20 C value)",
           grd("arithmetic_fact", [], "established"), "material")]
# g2.1: the percentage calculation
concl_ = concl('g2.1', EQ(V('pct'), R("100")), C['g2.1']['text'], grd("arithmetic_fact", [], "established"))
pr = problem('bi-t13-g2.1', req, 'g2.1', pct + T_SYMS, T_PREMS + CD, concl_, notes="Percentage increase from the table at 20 C and 30 C.")
OUT['g2.1'] = result(pr, "Read as the specialist's calculation of the percentage increase from 40 (20 C) to 80 (30 C). The division by 40 is written as multiplication by 40 in the IR (x / 40 = y iff x = 40 y). The claim gives 100 per cent exactly.",
                     [('pct', 'percentage increase'), ('t20', 'uptake at 20 C'), ('t30', 'uptake at 30 C')])

# g3.3: rises at the stated intervals, compared with every other rise in the table
conc_g33 = AND(EQ(dif(25, 30), R("22")), EQ(dif(30, 35), R("12")),
               GT(dif(25, 30), dif(10, 15)), GT(dif(25, 30), dif(15, 20)), GT(dif(25, 30), dif(20, 25)), GT(dif(25, 30), dif(30, 35)))
concl_ = concl('g3.3', conc_g33, C['g3.3']['text'], grd("arithmetic_fact", [], "established"))
pr = problem('bi-t13-g3.3', req, 'g3.3', T_SYMS, T_PREMS, concl_, notes="Rises between table temperatures.")
OUT['g3.3'] = result(pr, "Encodes the stated rises (58 to 80 = +22; 80 to 92 = +12) and checks that the 25-30 C rise is the largest rise among the table intervals.",
                     [('t%d' % k, 'uptake at %d C' % k) for k in TAB])

# g4.3: uptake drop 92 to 61; the mechanism is stated but not cited
m_few = sym('m_fewer', "Bool", "fewer enzyme-substrate complexes form, so the rate of aerobic respiration falls (mechanism stated, not cited)", grd("specialist_inference", [], "probable"))
conc_g43 = AND(V('m_fewer'), EQ(t(35), R("92")), EQ(t(40), R("61")))
concl_ = concl('g4.3', conc_g43, C['g4.3']['text'], grd("specialist_inference", [], "probable"))
pr = problem('bi-t13-g4.3', req, 'g4.3', [m_few] + T_SYMS, T_PREMS, concl_, notes="Numbers from the table; mechanism left uncited.")
OUT['g4.3'] = result(pr, "Encodes the drop in oxygen uptake from 92 to 61 mm3 per g per hour (table values at 35 C and 40 C) together with the stated mechanism. The mechanism is not cited, so the conjunction is not entailed.",
                     [('m_fewer', 'fewer enzyme-substrate complexes form and the rate falls')],
                     [("UNCITED_MECHANISM", "The mechanism (fewer complexes so the rate falls) has no citation and no support in the specialist report. It is not added as a premise.", ["Add the enzyme-substrate mechanism as a specialist inference (changes the verdict)", "Leave it uncited (as encoded)"])])

# g3.1 (point b): literal claim; its cited support g3.3 is asserted as an arithmetic premise
rise_chain = AND(*[LT(t(a), t(b)) for a, b in [(10, 15), (15, 20), (20, 25), (25, 30), (30, 35)]])
conc_g31 = AND(EQ(t(10), R("18")), EQ(t(35), R("92")), rise_chain)
C31 = [prem('C-g3.3', conc_g33, C['g3.3']['text'], grd("arithmetic_fact", [], "established"), "supporting")]
concl_ = concl('g3.1', conc_g31, C['g3.1']['text'], grd("specialist_inference", [], "established"))
pr = problem('bi-t13-g3.1', req, 'g3.1', T_SYMS, T_PREMS + C31, concl_, notes="Literal endpoints and monotone rise checked against the table.")
OUT['g3.1'] = result(pr, "Encodes the literal claim: 18 at 10 C, 92 at 35 C, and uptake increasing at every step from 10 to 35 C. The cited support g3.3 is included as an asserted premise, but it concerns only the steepest interval; the endpoints and monotone rise are checked against the table facts.",
                     [('t%d' % k, 'uptake at %d C' % k) for k in TAB],
                     [("CITED_SUPPORT_NARROW", "The cited support (g3.3) covers only the steepest interval and the slowdown; it does not establish the endpoint values or the rise at every step. The literal claim is checked against the table.", ["Treat g3.3 as the only ground (verdict then rests on the link alone)", "Check the literal claim against the table (as encoded)"])])

# g4.1 (point c): mechanism plus the cited table drop (g4.3)
C43 = [prem('C-g4.3', AND(LT(t(40), t(35)), EQ(t(35), R("92")), EQ(t(40), R("61"))), C['g4.3']['text'], grd("arithmetic_fact", [], "established"), "supporting")]
# g4.1 mechanism is the specialist's own assertion; only the cited support is linked
sym41 = sym('s_g4_1', "Bool", C['g4.1']['text'], grd("specialist_inference", [], "probable"))
link41 = prem('L-g4.1', IMP(AND(LT(t(40), t(35)), EQ(t(35), R("92")), EQ(t(40), R("61"))), V('s_g4_1')),
              "the specialist's stated support for the denaturation claim: the drop from 92 to 61", grd("specialist_inference", [], "probable"))
concl_ = concl('g4.1', V('s_g4_1'), C['g4.1']['text'], grd("specialist_inference", [], "probable"))
pr = problem('bi-t13-g4.1', req, 'g4.1', [sym41] + T_SYMS, T_PREMS + [link41], concl_, notes="Support: the table drop; mechanism is uncited.")
OUT['g4.1'] = result(pr, "The denaturation claim is linked only to the cited drop in uptake (92 to 61). The mechanism (heat breaks bonds, active sites change) is the specialist's own assertion and has no citation, so it is not encoded as a premise.",
                     [('s_g4_1', 'denaturation at 40 C lowers substrate binding and uptake')],
                     [("UNCITED_MECHANISM", "The denaturation mechanism is not cited, so the claim's link from the drop to the mechanism is the specialist's own inference.", ["Add the protein-denaturation rule as general knowledge (changes the verdict)", "Keep the link as the specialist's inference (as encoded)"])])

# g5.1 (point d): support list without the marks note '[1 spare]' (g5.8)
C2 = copy.deepcopy(C)
C2['g5.1']['supporting_claim_ids'] = [x for x in C['g5.1']['supporting_claim_ids'] if x != 'g5.8']
syms, prems, cc, gl = chain2('g5.1', C2, {}, kinds={})
pr = problem('bi-t13-g5.1', req, 'g5.1', syms, prems, cc, notes="Support graph of g5.1 as parsed, without the marks note.")
OUT['g5.1'] = result(pr, "Read as the specialist's argument: the three analysis steps (water formed from electrons and H+, aerobic respiration stops without oxygen, HL electron transport chain) jointly support the claim that oxygen is the final electron acceptor. The support g5.8 is a marks note with no content and is not encoded.",
                     gl, [("NONCONTENT_SUPPORT", "The parser lists the marks note '[1 spare]' as a support. It has no content, so it is not encoded. The level of the g5.7 step is HL-only; the task does not state the level, so the HL content is included.", ["Encode g5.8 as an asserted premise (not meaningful)", "Drop it (as encoded)"])])

# g5.8: marks note with no content
OUT['g5.8'] = {"problem": None, "interpretation": {"reading": "The claim is a marks note ('[1 spare]') with no content about the material.", "glossary": [], "ambiguity_flags": []},
               "ambiguous": False, "unsupported_reason": "The claim is a marks note ('[1 spare]') and states no proposition about the material, so there is nothing to encode in IR 1.0."}

json.dump({"report_id": d['report_id'], "claims": OUT}, open('/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/arena/r7/translations/bi-t13.json', 'w'), indent=1, ensure_ascii=False)
print('wrote', sorted(OUT))
