import sys, json
sys.path.insert(0, '/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/arena/r7/work')
from irlib2 import *
d, C = load('sp-t13')
req = d['request_id']
M = {
 'g1.1': "Answer to question 1: the plot had rubbish and broken glass before the project (two details, as asked).",
 'g1.2': "The answer is taken from the first paragraph; the rusty fence is left out because the question asks for two details.",
 'g2.1': "Answer to question 2: the idea came from Lucia Ferrer, a retired teacher.",
 'g2.2': "In 2020 she gathered twelve neighbours to ask the town council for permission.",
 'g2.3': "Both parts of the answer come from the first sentence of the second paragraph.",
 'g4.1': "Item 3b is true (V): older people who often lived alone are shown taking part, and friendships grow.",
 'g4.2': "This is the item that depends most on reading.",
 'g6.1': "Answer to question 4: some traders fear that the project will push up rents.",
 'g6.2': "Some traders fear the project; 'se ha puesto de moda' is given as the reason for that fear.",
}
K = {'g2.2': 'supplied_text', 'g1.2': 'specialist_inference'}
READ = ("Spanish source claims translated by meaning; quotations are verbatim spans of doc-huertos (located by the parser). "
        "Paraphrases of the article are grounded as supplied_text. Each support link is an implies premise whose antecedent is the "
        "conjunction of the claims cited as support. The specialist cites no quotation for the answer to question 1 or the "
        "two details of the first paragraph, so no quotation is added for them.")
out = {}
specs = {
 'g1.1': ([("Basura y cristales rotos" , "")], None),
}
for t in ['g1.1', 'g2.1', 'g4.1', 'g6.1']:
    flags = []
    if t == 'g1.1':
        flags.append(("UNCITED_TEXT", "The specialist cites no excerpt for the two details. The first paragraph contains 'basura, cristales rotos y una valla oxidada' verbatim, but that span was not cited, so it is not added as a premise; the answer rests on the uncited inference 'g1.2'.", ["Encode the verbatim span as a quotation premise", "Keep the answer grounded only by the specialist's stated inference (as encoded)"]))
    if t == 'g4.1':
        flags.append(("UNSOURCED_WORD", "The claim's note says the text never uses 'ayudar'. That word is not a supplied quotation and is not encoded as evidence.", ["Ignore the note (as encoded)", "Treat 'ayudar' as an unsupported assumption"]))
        flags.append(("INTERPRETIVE_TRUTH", "Whether the two quotations establish that the project helps older people is a reading; the specialist flags item 3b as depending most on reading.", ["Read 'vivian solas' as showing help (as encoded)", "Read the passage as showing only company, not help"]))
    syms, prems, cc, gl = chain2(t, C, M, kinds=K)
    pr = problem('sp-t13-' + t, req, t, syms, prems, cc,
                 notes="Encodes the specialist's stated support for claim " + t + " only.")
    out[t] = result(pr, READ + " Claim: " + M[t], gl, flags)
json.dump({"report_id": d['report_id'], "claims": out}, open('/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/arena/r7/translations/sp-t13.json', 'w'), indent=1, ensure_ascii=False)
print('wrote', list(out))
