import json,sys
for f in sys.argv[1:]:
    d=json.load(open(f))
    print("=== "+f+" report_id="+d["report_id"]+" n="+str(len(d["claims"])))
    for c in d["claims"]:
        refs=";".join(f'{r.get("document_id")}{"" if r.get("located") else "(UNLOC)"}' for r in c["source_refs"])
        print(f'[{c["claim_id"]}] role={c["role"]} mat={c["materiality"]} cert={c["certainty"]} elig={c["eligible"]}:{c["eligibility_class"]} sup={c["supporting_claim_ids"]} refs={refs or "-"} selfrep={c["advisory_verification_status"] or "-"}')
        print("   TEXT: "+c["text"])
        for a in c["assumptions"]:
            print("   ASSUMP: "+a[:300])
