import sys, json, re
sys.path.insert(0, '/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/arena/r7/work')
from irlib2 import *
d, C = load('bm-p7a')
req = d['request_id']
qtext = json.load(open('/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/arena/r7/specialists/bm-p7a.json'))['question']
print('marks in question:', re.findall(r'\((\w)\)[^\[]*\[(\d+)\]', qtext))
DOC = 'doc-fizzbrook'
BS = [sym('vol24', "Real", "Fizzbrook sales volume, 2024 (million litres, case)")]
BP = [prem('T-vol24', EQ(V('vol24'), R("15")), "Fizzbrook sold 15 million litres in 2024", grd("supplied_text", [ref(DOC)]), "supporting")]
ANCH = EQ(V('vol24'), R("15"))
ROUND = ("ROUNDED_LITERAL", "The claim gives rounded results (for example 7.22, 0.72, 1.62, 12.49 or 8.12). The literal equality is encoded; the exact value differs from the rounded figure. No rounding rule or tolerance is stated.", ["Literal equality with the rounded figure (as encoded)", "Equality within the stated rounding (needs a stated tolerance)"])
APPROX = ("APPROXIMATE_LITERAL", "The claim uses 'about' with no stated tolerance. The literal comparison is encoded, and the exact value differs from the approximation.", ["Literal value as written (as encoded)", "Approximate equality (needs a stated tolerance)"])
def A(*es): return AND(ANCH, *es)
EX = {}
EX['g2.3'] = (A(EQ(SUB(R("1.60"), R("0.95")), R("0.65")), EQ(SUB(MUL(R("0.65"), R("15")), R("6.5")), R("3.25"))), C['g2.3']['text'], 'arithmetic_fact')
EX['g3.2'] = (A(EQ(MUL(R("15"), SUB(R("1"), R("0.125"))), R("13.125")), EQ(SUB(R("1.90"), R("0.40")), R("1.50")), EQ(SUB(R("1.50"), R("0.95")), R("0.55")),
                EQ(MUL(R("0.55"), R("13.125")), R("7.22")), EQ(SUB(R("7.22"), R("6.5")), R("0.72")), EQ(MUL(R("1.50"), R("13.125")), R("19.69")), EQ(MUL(R("0.95"), R("13.125")), R("12.47"))), C['g3.2']['text'], 'arithmetic_fact')
EX['g4.1'] = (A(EQ(SUB(R("1.60"), R("0.95")), R("0.65")), EQ(SUB(MUL(R("0.65"), R("15")), R("6.5")), R("3.25")), EQ(SUB(R("1.50"), R("0.95")), R("0.55")), EQ(SUB(MUL(R("0.55"), R("13.125")), R("6.5")), R("0.72"))), C['g4.1']['text'], 'arithmetic_fact')
EX['g6.2'] = (A(EQ(MUL(R("-0.67"), R("25")), R("-16.75")), EQ(MUL(R("15"), SUB(R("1"), R("0.1675"))), R("12.5"))), C['g6.2']['text'], 'arithmetic_fact')
EX['g7.3'] = (A(EQ(SUB(R("2.00"), R("1.90")), R("0.10"))), C['g7.3']['text'], 'arithmetic_fact')
EX['g8.2'] = (A(EQ(SUB(MUL(R("12.5"), R("0.65")), R("6.5")), R("1.62")), GT(R("1.62"), R("0.72"))), C['g8.2']['text'], 'arithmetic_fact')
EX['g8.3'] = (A(EQ(DIV(R("26"), R("25")), R("1.04")), EQ(DIV(R("7.22"), R("0.65")), R("11.1"))), C['g8.3']['text'], 'arithmetic_fact')
EX['g9.1'] = (A(EQ(ADD(R("1.60"), R("0.40")), R("2.00")), EQ(SUB(R("2.00"), R("0.40")), R("1.60")), EQ(MUL(R("15"), SUB(R("1"), R("0.1675"))), R("12.49")),
                EQ(MUL(R("12.49"), R("0.65")), R("8.12")), EQ(SUB(R("8.12"), R("6.5")), R("1.62")), EQ(DIV(R("7.22"), R("0.65")), R("11.1")), EQ(DIV(R("26"), R("25")), R("1.04"))), C['g9.1']['text'], 'arithmetic_fact')
M = {'g2.1': "Price received per litre in 2024 with no tax is $1.60 (measure and contribution).",
     'g3.1': "2025 volume and profit are computed from the Economics specialist's percentage change in quantity.",
     'g6.1': "PED of -0.67 implies a 25% price rise would cut sales by about 16.75%; the Economics specialist's PED and the rise in shelf price from $1.60 to $2.00.",
     'g7.1': "The market also limits the price Fizzbrook can charge.",
     'g7.4': "The market elasticity covers all sugar-sweetened drinks; one brand's buyers can switch, so they are probably more responsive than the market.",
     'g8.1': "The limit of this argument: the market figure alone does not rule out full pass-through.",
     'g11.1': "Fizzbrook could use the product by launching the low-sugar range proposed by its marketing manager."}
MARKS = {'g1.1': (4, 'a'), 'g5.1': (4, 'b'), 'g10.1': (2, 'c')}
OUT = {}
def marks(cid):
    n, part = MARKS[cid]
    m = 'marks_' + part
    syms = [sym(m, "Int", "marks allocated to part (" + part + ") of the question")]
    pre = [prem('T-' + cid, EQ(V(m), I(n)), "part (" + part + ") carries " + str(n) + " marks", grd("task_setting", [], "established"))]
    c = concl(cid, EQ(V(m), I(n)), C[cid]['text'], grd("task_setting", [], "established"))
    return result(problem('bm-p7a-' + cid, req, cid, syms, pre, c, notes="Mark allocation transcribed from the question."),
                  "The claim restates the mark allocation printed beside part (" + part + "). Encoded as a task_setting premise and the same equality as conclusion; checks transcription only.", [(m, 'marks for part ' + part)])
for cid in MARKS: OUT[cid] = marks(cid)
ARITHS = {k: EX[k] for k in EX}
def run(cid, flags=None, reading=None, extra_arith=None):
    arith = dict(ARITHS)
    syms, prems, cc, gl = chain2(cid, C, M, arith=arith, pre_syms=BS, pre_prems=BP)
    return result(problem('bm-p7a-' + cid, req, cid, syms, prems, cc, notes="Specialist support graph as parsed (" + cid + ")."), reading or "Read as the specialist's own argument; supports jointly support the claim.", gl, flags or [])
# quotations and judgements
OUT['g2.2'] = run('g2.2', reading="Quotation of the Economics specialist's pre-tax price, located in the relayed report.")
OUT['g2.1'] = run('g2.1', flags=[ROUND], reading="The measure is read as the specialist's chain: the quoted 2024 price (g2.2) and the contribution and profit working (g2.3) jointly support it.")
OUT['g2.3'] = run('g2.3', flags=[ROUND], reading="Contribution per litre 1.60 - 0.95 = 0.65 and annual profit 0.65 x 15 - 6.5 = 3.25 are exact.")
OUT['g3.2'] = run('g3.2', flags=[ROUND], reading="2025 volume 15 x (1 - 0.125) = 13.125 is exact; the 2025 contribution, profit and cost-revenue figures are rounded in the claim (7.22, 0.72, 19.69, 12.47), so those literal equalities are false under exact arithmetic.")
OUT['g3.1'] = run('g3.1', reading="The 2025 point is read as the specialist's chain from the quoted percentage change to the 2025 volume and profit (g3.2).")
OUT['g4.1'] = run('g4.1', flags=[ROUND], reading="Summary of the results; the 2025 profit 0.72 is the rounded value of 0.71875 and is encoded literally.")
OUT['g6.1'] = run('g6.1', flags=[APPROX], reading="The PED quotations (located in the relayed report) and the carry-on-as-before statement (g6.3) are the cited supports; the 25% price rise and sales fall of about 16.75% are checked in g6.2.")
OUT['g6.2'] = run('g6.2', flags=[APPROX], reading="-0.67 x 25 = -16.75 is exact. The volume 15 x (1 - 0.1675) = 12.4875 is written as 'about 12.5'; the literal 12.5 is encoded.")
OUT['g7.1'] = run('g7.1', reading="The market limit is read as the specialist's chain: the quoted 2025 consumer price (g7.2) and the 10 cents margin (g7.3) jointly support it; the elasticity judgement (g7.4) is asserted.")
OUT['g7.2'] = run('g7.2', reading="Quotation of the Economics specialist's 2025 consumer price (1.90), located in the relayed report.")
OUT['g7.3'] = run('g7.3', reading="2.00 - 1.90 = 0.10 is exact.")
OUT['g7.4'] = run('g7.4', flags=[("UNCITED_JUDGEMENT", "The claim is a judgement about the brand's buyers' responsiveness and cites no supporting fact; it is not supported by any premise.", ["Treat as an evaluation (as encoded, no premise)", "Add the market-share assumption as a premise (not supplied)"])], reading="Judgement without citation: the conclusion has no supporting premise and is not entailed.")
OUT['g8.1'] = run('g8.1', flags=[APPROX, ROUND], reading="The measure is read as the specialist's chain: the approximate profit under full pass-through (g8.2) and the threshold (g8.3) jointly support it; g8.4 is asserted.")
OUT['g8.2'] = run('g8.2', flags=[APPROX], reading="Profit at 12.5 million litres and 0.65 contribution is 1.625 exactly, written as 'about 1.62'; the literal value is encoded.")
OUT['g8.3'] = run('g8.3', flags=[APPROX, ROUND], reading="26 / 25 = 1.04 is exact; the volume threshold 7.22 / 0.65 = 11.1077 is written as 'about 11.1'; the literal value is encoded.")
OUT['g9.1'] = run('g9.1', flags=[ROUND, APPROX], reading="Working for (b): the exact steps (2.00 shelf price, 1.60 received, 26/25 = 1.04) hold; the volume 12.4875 and contribution 8.1185 and threshold 11.1077 are rounded in the claim and are encoded literally.")
OUT['g11.1'] = run('g11.1', flags=[("UNCITED_TEXT", "The rule that drinks under 5 g of sugar per 100 ml are not taxed is stated in the case but is not cited by the specialist report. It is not added as a premise.", ["Ground the rule by quotation from doc-fizzbrook (changes the verdict)", "Leave it out (as encoded)"])], reading="Read as the specialist's own argument: the untaxed-range support (g11.2) and the two interpretive steps (g11.3, g11.4) support the claim that the range could use the product.")
# g11.2: an untaxed-range claim whose tax rule is in the case but uncited
u = sym('untaxed', "Bool", "the low-sugar range would carry none of the $0.40 tax and need no higher shelf price", grd("specialist_inference", [], "established"))
cc = concl('g11.2', AND(ANCH, V('untaxed')), C['g11.2']['text'], grd("specialist_inference", [], "established"))
OUT['g11.2'] = result(problem('bm-p7a-g11.2', req, 'g11.2', [u] + BS, BP, cc, notes="Tax-rule claim; the rule is not cited."),
                      "The claim says drinks under 5 g sugar per 100 ml are untaxed, so the new range carries none of the tax. The rule is in the case but is not cited, so the conclusion is not entailed.",
                      [('untaxed', 'low-sugar range carries no tax')],
                      [("UNCITED_TEXT", "The tax rule (under 5 g per 100 ml not taxed) is in the case (doc-fizzbrook) but the specialist cites no excerpt, so it is not added.", ["Ground the rule by quotation (changes the verdict)", "Leave it uncited (as encoded)"])])
json.dump({"report_id": d['report_id'], "claims": OUT}, open('/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/arena/r7/translations/bm-p7a.json', 'w'), indent=1, ensure_ascii=False)
print('wrote', sorted(OUT))
