import json,sys
d=json.load(open(sys.argv[1]))
print('report', d['report_id'], d['request_id'], 'n', len(d['claims']))
for c in d['claims']:
    print('---', c['claim_id'], '|', c['role'], '|', c['materiality'], '|', c['certainty'], '| elig=', c['eligible'], c['eligibility_class'], '| sup=', c['supporting_claim_ids'])
    print('   TEXT:', c['text'])
    for r in c['source_refs']:
        print('   SRC:', r.get('document_id'), r.get('locator'), '| located=', r.get('located'), '| excerpt=', repr(r.get('excerpt')))
    for a in c['assumptions']:
        print('   ASSUMP:', a)
