# Arena r7 (QUALIFIED: 202 of 224 recorded translations not served; 22 served by claim id only)

Transmissions: 177; functional: 177 (100.0%). This is the transport measure only: fixture coverage, translation fidelity and the claim counts are separate measures (below), never combined with it into one rate.

Genuine transmissions, peer relays and combinator syntheses: 44. With an error-level finding: 18 (bi-t13.json [synthesis syn-bi-t13]: INT-LEDGER-001 ['s0', 'g3.1', 'g3.3'], INT-LEDGER-001 ['s1', 'g4.1', 'g4.3'], INT-LEDGER-001 ['s2', 'g5.1', 'g5.3', 'g5.5'], INT-LEDGER-002 ['s2.1'], INT-LEDGER-002 ['s3.1'], INT-LEDGER-002 ['s4.1'], INT-LEDGER-002 ['s5.1']; bm-t13.json [synthesis syn-bm-t13]: INT-LEDGER-001 ['s0', 'g2.1', 'g3.1', 'g4.1', 'g5.1'], INT-LEDGER-001 ['s1', 'g12.1', 'g12.3'], INT-LEDGER-001 ['s2', 'g7.2', 'g8.1', 'g9.1', 'g10.1'], INT-LEDGER-001 ['g7.1'], INT-LEDGER-002 ['g5.2@business-management-specialist'], INT-LEDGER-002 ['g7.1@business-management-specialist'], INT-LEDGER-002 ['g9.1@business-management-specialist'], INT-LEDGER-002 ['g10.1@business-management-specialist'], INT-LEDGER-002 ['g12.1@business-management-specialist']; ch-t13.json [genuine]: INT-REQ-005 []; ch-t13.json [synthesis syn-ch-t13]: INT-LEDGER-001 ['s0', 'g5.1', 'g3.1'], INT-LEDGER-001 ['s1', 'g2.1'], INT-LEDGER-001 ['s2', 'g4.1'], INT-LEDGER-001 ['s3', 'g6.1', 'g6.2'], INT-LEDGER-001 ['g1.1'], INT-LEDGER-001 ['g5.2'], INT-LEDGER-001 ['g7.1'], INT-LEDGER-002 ['s1.1'], INT-LEDGER-002 ['s2.1'], INT-LEDGER-002 ['s4.1'], INT-LEDGER-002 ['s6.1'], INT-LEDGER-002 ['s7.1']; cs-t13.json [synthesis syn-cs-t13]: INT-LEDGER-001 ['s0', 'g9.1', 'g9.2', 'g9.4'], INT-LEDGER-001 ['s1', 'g11.1', 'g11.2', 'g11.3', 'g12.1', 'g12.2', 'g12.3'], INT-LEDGER-001 ['s2', 'g14.1', 'g14.2'], INT-LEDGER-001 ['s3', 'g7.1', 'g7.2'], INT-LEDGER-001 ['g15.1'], INT-LEDGER-002 ['c2.4'], INT-LEDGER-002 ['c4.1'], INT-LEDGER-002 ['c6.1'], INT-LEDGER-002 ['c7.1'], INT-LEDGER-002 ['c7.2'], INT-LEDGER-002 ['c8.1'], INT-LEDGER-002 ['c9.1'], INT-LEDGER-002 ['c10.1']; ec-t13.json [synthesis syn-ec-t13]: INT-LEDGER-001 ['s0', 'g2.1', 'g2.2', 'g2.3'], INT-LEDGER-001 ['s1', 'g5.1', 'g5.2'], INT-LEDGER-001 ['s2', 'g5.3', 'g5.5'], INT-LEDGER-002 ['g2.6@economics-specialist'], INT-LEDGER-002 ['g5.1@economics-specialist']; ess-t13.json [synthesis syn-ess-t13]: INT-LEDGER-001 ['s0', 'g2.1', 'g2.2', 'g2.3'], INT-LEDGER-001 ['s1', 'g3.1', 'g3.2', 'g3.3', 'g3.4'], INT-LEDGER-001 ['s2', 'g4.1', 'g4.2', 'g4.4', 'g4.6'], INT-LEDGER-002 ['s1.1'], INT-LEDGER-002 ['s2.1'], INT-LEDGER-002 ['s3.1'], INT-LEDGER-002 ['s4.1'], INT-LEDGER-002 ['s4.6']; ge-t13.json [synthesis syn-ge-t13]: INT-LEDGER-001 ['s0', 'g6.1', 'g5.1', 'g6.3'], INT-LEDGER-001 ['s1', 'g7.1', 'g7.2', 'g7.3', 'g7.4'], INT-LEDGER-001 ['s2', 'g8.1', 'g8.2'], INT-LEDGER-001 ['s3', 'g8.3', 'g8.4'], INT-LEDGER-002 ['g4.1@geography-specialist'], INT-LEDGER-002 ['g6.1@geography-specialist'], INT-LEDGER-002 ['g7.1@geography-specialist'], INT-LEDGER-002 ['g8.1@geography-specialist'], INT-LEDGER-002 ['g8.3@geography-specialist']; hi-p7c.json [genuine]: INT-SUBJ-001 ['h1.1']; lit-t13.json [synthesis syn-lit-t13]: INT-LEDGER-023 ['s0', 'p2-point'], INT-LEDGER-003 ['s1', 'p1-s04'], INT-LEDGER-001 ['s2', 'p1-s03'], INT-LEDGER-001 ['p3-point'], INT-LEDGER-002 ['p1-s05'], INT-LEDGER-002 ['p1-s06'], INT-LEDGER-002 ['p1-s07'], INT-LEDGER-002 ['p1-s09']; maa-t13.json [synthesis syn-maa-t13]: INT-LEDGER-001 ['s0', 'g1.1', 'g2.1', 'g2.2'], INT-LEDGER-001 ['s1', 'g3.1', 'g3.2', 'g3.3', 'g3.4', 'g3.5'], INT-LEDGER-002 ['m1.4'], INT-LEDGER-002 ['m2.6'], INT-LEDGER-002 ['m3.7'], INT-LEDGER-002 ['m3.8'], INT-LEDGER-002 ['m3.10']; mai-t13.json [synthesis syn-mai-t13]: INT-LEDGER-001 ['s0', 'g4.1', 'g4.3', 'g5.1', 'g5.2', 'g5.3', 'g6.1', 'g6.3'], INT-LEDGER-001 ['s1', 'g11.1', 'g11.3', 'g12.1', 'g12.2', 'g12.3'], INT-LEDGER-001 ['s2', 'g13.1', 'g13.2', 'g14.1', 'g15.2'], INT-LEDGER-001 ['s3', 'g16.1', 'g15.1'], INT-LEDGER-002 ['m3.1'], INT-LEDGER-002 ['m4.1'], INT-LEDGER-002 ['m5.1'], INT-LEDGER-002 ['m6.1'], INT-LEDGER-002 ['m9.1'], INT-LEDGER-002 ['m10.1'], INT-LEDGER-002 ['m11.1'], INT-LEDGER-002 ['m12.2'], INT-LEDGER-002 ['m12.3'], INT-LEDGER-002 ['m14.1']; ph-t13.json [synthesis syn-ph-t13]: INT-LEDGER-001 ['s0', 'g1.2', 'g2.1'], INT-LEDGER-001 ['s1', 'g3.2', 'g4.2', 'g4.3'], INT-LEDGER-001 ['s2', 'g5.2', 'g5.3', 'g5.4', 'g5.5'], INT-LEDGER-001 ['g1.1', 'g3.1', 'g4.1', 'g5.1'], INT-LEDGER-002 ['s1.4'], INT-LEDGER-002 ['s2.2'], INT-LEDGER-002 ['s3.2'], INT-LEDGER-002 ['s4.3'], INT-LEDGER-002 ['s5.1'], INT-LEDGER-002 ['s5.4']; ps-t13.json [synthesis syn-ps-t13]: INT-LEDGER-001 ['s0', 'g1.1', 'g1.2'], INT-LEDGER-001 ['s1', 'g2.1', 'g2.2', 'g2.3', 'g2.4'], INT-LEDGER-002 ['g1.1@psychology-specialist'], INT-LEDGER-002 ['g2.1@psychology-specialist']; sp-t13.json [synthesis syn-sp-t13]: INT-LEDGER-001 ['s0', 'g1.1', 'g1.2'], INT-LEDGER-001 ['s1', 'g2.1', 'g2.2', 'g2.3'], INT-LEDGER-001 ['s2', 'g4.1', 'g4.2'], INT-LEDGER-001 ['s3', 'g6.1', 'g6.2'], INT-LEDGER-002 ['g1.1@language-b-spanish-specialist'], INT-LEDGER-002 ['g2.1@language-b-spanish-specialist'], INT-LEDGER-002 ['g2.2@language-b-spanish-specialist'], INT-LEDGER-002 ['g3.1@language-b-spanish-specialist'], INT-LEDGER-002 ['g4.1@language-b-spanish-specialist'], INT-LEDGER-002 ['g5.1@language-b-spanish-specialist'], INT-LEDGER-002 ['g6.1@language-b-spanish-specialist'], INT-LEDGER-002 ['g7.1@language-b-spanish-specialist']; bm-p7a.json [synthesis syn-p7a]: INT-LEDGER-001 ['ec-p7a-s0', 'g2.1', 'g2.2', 'g2.3'], INT-LEDGER-001 ['ec-p7a-s1', 'g4.1', 'g4.2'], INT-LEDGER-001 ['ec-p7a-s2', 'g6.1', 'g6.2', 'g6.3', 'g11.1'], INT-LEDGER-001 ['ec-p7a-s3', 'g8.1', 'g8.2', 'g8.3'], INT-LEDGER-001 ['bm-p7a-s0', 'g2.1', 'g2.3', 'g3.1', 'g3.2', 'g4.1'], INT-LEDGER-001 ['bm-p7a-s1', 'g6.1', 'g6.2', 'g9.1', 'g8.1', 'g8.4', 'g7.4'], INT-LEDGER-001 ['bm-p7a-s2', 'g7.1', 'g7.2', 'g7.3'], INT-LEDGER-001 ['bm-p7a-s3', 'g11.1', 'g11.2', 'g11.4'], INT-LEDGER-001 ['g11.3'], INT-LEDGER-002 ['g2.5@economics-specialist'], INT-LEDGER-002 ['g4.2@economics-specialist'], INT-LEDGER-002 ['g6.8@economics-specialist'], INT-LEDGER-002 ['g8.7@economics-specialist'], INT-LEDGER-002 ['g11.1@economics-specialist'], INT-LEDGER-002 ['g11.3@economics-specialist'], INT-LEDGER-002 ['g4.1@business-management-specialist'], INT-LEDGER-002 ['g6.1@business-management-specialist'], INT-LEDGER-002 ['g7.1@business-management-specialist'], INT-LEDGER-002 ['g8.1@business-management-specialist'], INT-LEDGER-002 ['g9.5@business-management-specialist'], INT-LEDGER-002 ['g11.1@business-management-specialist']; lit-p7c.json [synthesis syn-p7c]: INT-LEDGER-003 ['hi-p7c-s0', 'h1.1', 'h1.2', 'h1.3', 'h1.4']; maa-p7b.json [synthesis syn-p7b]: INT-LEDGER-001 ['ph-p7b-s0', 'g1.3'], INT-LEDGER-001 ['ph-p7b-s1', 'g2.2', 'g2.3', 'g3.2'], INT-LEDGER-001 ['ph-p7b-s2', 'g4.2', 'g4.3'], INT-LEDGER-001 ['ph-p7b-s3', 'g5.2', 'g5.3', 'g5.4', 'g5.5', 'g5.6'], INT-LEDGER-001 ['maa-p7b-s0', 'g1.1', 'g1.2', 'g2.1'], INT-LEDGER-001 ['maa-p7b-s1', 'g3.1', 'g3.2', 'g5.1', 'g5.2'], INT-LEDGER-001 ['maa-p7b-s2', 'g4.1', 'g4.2'], INT-LEDGER-001 ['maa-p7b-s3', 'g7.1', 'g7.2', 'g8.1', 'g8.2'], INT-LEDGER-001 ['g1.1', 'g2.1', 'g3.1', 'g4.1', 'g5.1'], INT-LEDGER-001 ['g9.1'], INT-LEDGER-002 ['s1.3'], INT-LEDGER-002 ['s1.4'], INT-LEDGER-002 ['s1.5'], INT-LEDGER-002 ['s1.6'], INT-LEDGER-002 ['s1.7'], INT-LEDGER-002 ['s1.8'], INT-LEDGER-002 ['s1.9'], INT-LEDGER-002 ['s2.2'], INT-LEDGER-002 ['s3.2'], INT-LEDGER-002 ['s4.1'], INT-LEDGER-002 ['s5.1'], INT-LEDGER-002 ['m2.5'], INT-LEDGER-002 ['m3.6'], INT-LEDGER-002 ['m4.6'], INT-LEDGER-002 ['m5.2'], INT-LEDGER-002 ['m7.1'], INT-LEDGER-002 ['m8.2'], INT-LEDGER-002 ['m8.3']), of which 18 counted functional. With warning-level findings only: 18, of which 18 counted functional. The rate does not judge whether a finding is true: a false error on a correct statement is counted functional like a true one, so read every finding in the genuine section below.

## Measures (each on its own denominator; none is combined with another into one rate)

- Transport (functional transmissions): 177 of 177 (100.0%). Genuine traffic delivered and decided: 44 of 44 (genuine replies 22, peer relays 3, syntheses 19); injected faults named: 133 of 133 mutation records. Transport says the hub delivered and decided every transmission; it does not judge whether a finding is true, whether a translation is faithful or whether an answer is better.
- Fixture coverage (recorded translations served in this run): 22 of 224 served; NOT SERVED: 202 (200 match no delivered claim id; 2 claim not eligible under the current policy). Of the 22 served, 0 were bound to a recorded claim-text digest and 22 by claim id only.
- Translation fidelity (faithful translations where adjudicated): not adjudicated; the round has no adjudications/translation_fidelity.json, so no fidelity figure applies to this run.
- Claims (genuine pass, each delivered claim once): extracted 475; eligible for translation 296; attempted 22; completed (a definitive verdict displayed) 6; faithful: not adjudicated; approved (displayed ENTAILED with no error-level finding on the claim; not a release decision) 6, of which 6 rest on at least one ungrounded premise and 6 on at least one unresolved dependency (ungrounded, or authority no check validated); release permitted by the release assessment (the application's rule, apart from the formal status) 0. Eligible claims with no translation attempted: 274.
- Latency (hub processing per transmission in this run, on this machine; not a stress measurement): genuine traffic median 81 ms, 95th percentile 297 ms, max 455 ms over 41; injected faults median 176 ms, 95th percentile 619 ms, max 731 ms over 133.
- Cost: no translation provider was called (recorded fixtures only).
- QUALIFIED (TRANSLATIONS_LOST): 202 of 224 recorded translations were not served in this run (200 match no delivered claim id; 2 claim not eligible under the current policy); translation outcomes cover the 22 served, so this run is not a translation regression over the recorded round.
- QUALIFIED (FIXTURES_UNBOUND): 22 of the 22 served translations carry no recorded claim-text digest: each is bound to the text its claim id carries in this run, which may not be the sentence it was produced for.

| variant | functional | total |
| --- | --- | --- |
| genuine | 22 | 22 |
| synthesis | 19 | 19 |
| peer_relay | 3 | 3 |
| invented_quotation | 22 | 22 |
| invented_quotation_single | 22 | 22 |
| self_certification | 22 | 22 |
| wrong_arithmetic | 22 | 22 |
| chronology_error | 22 | 22 |
| stem_arithmetic_slip | 7 | 7 |
| stem_substitution | 7 | 7 |
| altered_quotation | 8 | 8 |
| stem_wrong_unit | 1 | 1 |

## Translation outcomes (provider-dependent; genuine pass, one outcome per eligible claim with a fixture)

- AMBIGUOUS_TRANSLATION: 10 (10 distinct claims)
- ENTAILED: 6 (6 distinct claims)
- INVALID_FORMALIZATION: 6 (6 distinct claims)
- NOT_ELIGIBLE: 2 (2 distinct claims)
- ENTAILED verdicts resting only on ungrounded premises: 0 of 6
- encodings given no verdict on genuine claims (displayed INVALID_FORMALIZATION: a definitive engine status withheld, or the encoding rejected at translation): 6; E108 vacuous result: 0; E110 unasserted figure: 0; E111 unencoded reason: 0; E112 circular encoding: 6 (hi-p7c.json h1.2 (rejected at translation), hi-p7c.json h1.4 (rejected at translation), hi-t13.json h1.4 (rejected at translation), hi-t13.json h1.7 (rejected at translation), hi-t13.json h1.9 (rejected at translation), hi-t13.json h1.11 (rejected at translation)); stated precision: 0; exactness: 0
- advisory coverage warnings on genuine claims (the verdict on the encoding stands; the encoding leaves a figure or symbol open that no source asserts; a coverage measure, not a verdict): 0; W110 unasserted figure, advisory: 0; W111 unconstrained symbol, advisory: 0
- definitive verdicts other than ENTAILED displayed on genuine claims (each is shown to the router as the engine's verdict on the claim's encoding: COUNTEREXAMPLE, the claim does not follow from its premises; INCONSISTENT_PREMISES, its premises conflict): 0
- translation fixtures recorded under claim ids this parse does not deliver (never served; those claims have no outcome): 200 (bi-t13.json: ['g2.1', 'g3.1', 'g3.3', 'g4.1', 'g4.3', 'g5.1', 'g5.8']; bm-t13.json: ['g1.1', 'g10.1', 'g11.1', 'g12.1', 'g12.3', 'g2.1', 'g3.1', 'g4.1', 'g5.1', 'g6.1', 'g7.1', 'g7.2', 'g8.1', 'g9.1']; ch-t13.json: ['g1.1', 'g2.1', 'g3.1', 'g4.1', 'g5.1', 'g6.1', 'g6.2', 'g7.1']; cs-t13.json: ['g1.1', 'g10.1', 'g11.1', 'g11.2', 'g11.3', 'g12.1', 'g12.2', 'g12.3', 'g13.1', 'g14.1', 'g14.2', 'g3.1', 'g4.1', 'g5.1', 'g7.1', 'g7.2', 'g8.1', 'g9.1', 'g9.3', 'g9.5']; ec-p7a.json: ['g1.1', 'g10.1', 'g11.1', 'g11.2', 'g2.1', 'g2.2', 'g2.3', 'g3.1', 'g4.1', 'g4.2', 'g5.1', 'g6.1', 'g6.2', 'g6.3', 'g7.1', 'g8.1', 'g8.2', 'g8.3', 'g9.1']; ec-t13.json: ['g1.1', 'g2.1', 'g2.2', 'g2.3', 'g3.1', 'g4.1', 'g5.1', 'g5.2', 'g5.3']; ess-t13.json: ['g1.1', 'g2.1', 'g2.2', 'g2.3', 'g3.1', 'g3.2', 'g3.3', 'g3.4', 'g4.1', 'g4.2', 'g4.3', 'g4.4', 'g4.5']; ge-t13.json: ['g1.1', 'g4.1', 'g5.1', 'g6.1', 'g6.3', 'g7.1', 'g7.2', 'g7.4', 'g8.1']; lit-t13.json: ['p3-point']; maa-t13.json: ['g1.1', 'g2.1', 'g2.2', 'g3.1', 'g3.2', 'g3.3', 'g3.4', 'g3.5']; mai-t13.json: ['g1.1', 'g10.1', 'g11.1', 'g11.3', 'g12.1', 'g12.2', 'g12.3', 'g13.1', 'g13.2', 'g14.1', 'g15.1', 'g15.2', 'g16.1', 'g17.1', 'g2.1', 'g3.1', 'g4.1', 'g4.3', 'g5.1', 'g5.2', 'g5.3', 'g6.1', 'g6.2', 'g6.3', 'g7.1', 'g8.1', 'g9.1']; ph-p7b.json: ['g1.1', 'g1.3', 'g2.1', 'g2.2', 'g2.3', 'g3.1', 'g3.2', 'g4.1', 'g4.2', 'g4.3', 'g5.1']; ph-t13.json: ['g1.1', 'g1.2', 'g2.1', 'g3.1', 'g3.2', 'g4.1', 'g4.2', 'g4.3', 'g5.1', 'g5.2', 'g5.3', 'g5.4']; ps-t13.json: ['g1.1', 'g2.1', 'g3.1']; sp-t13.json: ['g1.1', 'g2.1', 'g4.1', 'g6.1']; bm-p7a.json: ['g1.1', 'g10.1', 'g11.1', 'g11.2', 'g2.1', 'g2.2', 'g2.3', 'g3.1', 'g3.2', 'g4.1', 'g5.1', 'g6.1', 'g6.2', 'g7.1', 'g7.2', 'g7.3', 'g7.4', 'g8.1', 'g8.2', 'g8.3', 'g9.1']; maa-p7b.json: ['g1.1', 'g1.2', 'g2.1', 'g3.1', 'g3.2', 'g4.1', 'g4.2', 'g5.1', 'g5.2', 'g7.1', 'g7.2', 'g8.1', 'g8.2', 'g9.1'])
- all variants together (the same claims repeated): {'ENTAILED': 39, 'AMBIGUOUS_TRANSLATION': 63, 'INVALID_FORMALIZATION': 36, 'NOT_ELIGIBLE': 16, 'STALE_FIXTURE_REFUSED': 2}

## Genuine transmissions, peer relays and combinator syntheses carrying error- or warning-level findings (correct against a specialist's or the combinator's fault, or a false finding: read the message)

- bi-t13.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['CORE-QNT-001']
  - warning CORE-QNT-001 ['s2.1']: paragraph 2, sentence 1 states a derived figure or a relation over dated figures ('an increase of 100%') that could not be checked: no figures are stated with it in its sentence and the sentence states no year and no anaphor such as 'that year'; the stated arithmetic was not checked
- bi-t13.json [synthesis syn-bi-t13] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-001', 'INT-LEDGER-002'], warnings ['INT-SYNTH-012']
  - error INT-LEDGER-001 ['s0', 'g3.1', 'g3.3']: synthesized claim cites unknown source claims ['g3.1', 'g3.3']
  - error INT-LEDGER-001 ['s1', 'g4.1', 'g4.3']: synthesized claim cites unknown source claims ['g4.1', 'g4.3']
  - error INT-LEDGER-001 ['s2', 'g5.1', 'g5.3', 'g5.5']: synthesized claim cites unknown source claims ['g5.1', 'g5.3', 'g5.5']
  - error INT-LEDGER-002 ['s2.1']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['s3.1']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['s4.1']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['s5.1']: material source claim is neither carried, transformed nor recorded as dropped
  - warning INT-SYNTH-012 ['s0', 'g3.1', 'g3.3']: material claim produced by 'merged' from ['g3.1', 'g3.3']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s1', 'g4.1', 'g4.3']: material claim produced by 'merged' from ['g4.1', 'g4.3']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'g5.1', 'g5.3', 'g5.5']: material claim produced by 'merged' from ['g5.1', 'g5.3', 'g5.5']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- bm-t13.json [synthesis syn-bm-t13] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-001', 'INT-LEDGER-002'], warnings ['INT-SYNTH-012']
  - error INT-LEDGER-001 ['s0', 'g2.1', 'g3.1', 'g4.1', 'g5.1']: synthesized claim cites unknown source claims ['g2.1', 'g3.1', 'g4.1', 'g5.1']
  - error INT-LEDGER-001 ['s1', 'g12.1', 'g12.3']: synthesized claim cites unknown source claims ['g12.1', 'g12.3']
  - error INT-LEDGER-001 ['s2', 'g7.2', 'g8.1', 'g9.1', 'g10.1']: synthesized claim cites unknown source claims ['g7.2', 'g8.1', 'g9.1', 'g10.1']
  - error INT-LEDGER-001 ['g7.1']: ledger entry cites unknown source claims ['g7.1']
  - error INT-LEDGER-002 ['g5.2@business-management-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['g7.1@business-management-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['g9.1@business-management-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['g10.1@business-management-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['g12.1@business-management-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - warning INT-SYNTH-012 ['s0', 'g2.1', 'g3.1', 'g4.1', 'g5.1']: material claim produced by 'merged' from ['g2.1', 'g3.1', 'g4.1', 'g5.1']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s1', 'g12.1', 'g12.3']: material claim produced by 'merged' from ['g12.1', 'g12.3']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'g7.2', 'g8.1', 'g9.1', 'g10.1']: material claim produced by 'merged' from ['g7.2', 'g8.1', 'g9.1', 'g10.1']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- ch-t13.json [genuine] ACCEPTED_WITH_FINDINGS: errors ['INT-REQ-005'], warnings []
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 439 words; bound min_words 540; solver COUNTEREXAMPLE
- ch-t13.json [synthesis syn-ch-t13] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-001', 'INT-LEDGER-002'], warnings ['INT-SYNTH-012']
  - error INT-LEDGER-001 ['s0', 'g5.1', 'g3.1']: synthesized claim cites unknown source claims ['g5.1', 'g3.1']
  - error INT-LEDGER-001 ['s1', 'g2.1']: synthesized claim cites unknown source claims ['g2.1']
  - error INT-LEDGER-001 ['s2', 'g4.1']: synthesized claim cites unknown source claims ['g4.1']
  - error INT-LEDGER-001 ['s3', 'g6.1', 'g6.2']: synthesized claim cites unknown source claims ['g6.1', 'g6.2']
  - error INT-LEDGER-001 ['g1.1']: ledger entry cites unknown source claims ['g1.1']
  - error INT-LEDGER-001 ['g5.2']: ledger entry cites unknown source claims ['g5.2']
  - error INT-LEDGER-001 ['g7.1']: ledger entry cites unknown source claims ['g7.1']
  - error INT-LEDGER-002 ['s1.1']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['s2.1']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['s4.1']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['s6.1']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['s7.1']: material source claim is neither carried, transformed nor recorded as dropped
  - warning INT-SYNTH-012 ['s0', 'g5.1', 'g3.1']: material claim produced by 'merged' from ['g5.1', 'g3.1']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s3', 'g6.1', 'g6.2']: material claim produced by 'merged' from ['g6.1', 'g6.2']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- cs-t13.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['ST-UNDEC-001']
  - warning ST-UNDEC-001 ['c8.2']: an arrow (a limit, a mapping or a reaction outside a chemistry reading); the relation in c8.2 is not checked
- cs-t13.json [synthesis syn-cs-t13] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-001', 'INT-LEDGER-002'], warnings ['INT-SYNTH-012']
  - error INT-LEDGER-001 ['s0', 'g9.1', 'g9.2', 'g9.4']: synthesized claim cites unknown source claims ['g9.1', 'g9.2', 'g9.4']
  - error INT-LEDGER-001 ['s1', 'g11.1', 'g11.2', 'g11.3', 'g12.1', 'g12.2', 'g12.3']: synthesized claim cites unknown source claims ['g11.1', 'g11.2', 'g11.3', 'g12.1', 'g12.2', 'g12.3']
  - error INT-LEDGER-001 ['s2', 'g14.1', 'g14.2']: synthesized claim cites unknown source claims ['g14.1', 'g14.2']
  - error INT-LEDGER-001 ['s3', 'g7.1', 'g7.2']: synthesized claim cites unknown source claims ['g7.1', 'g7.2']
  - error INT-LEDGER-001 ['g15.1']: ledger entry cites unknown source claims ['g15.1']
  - error INT-LEDGER-002 ['c2.4']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['c4.1']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['c6.1']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['c7.1']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['c7.2']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['c8.1']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['c9.1']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['c10.1']: material source claim is neither carried, transformed nor recorded as dropped
  - warning INT-SYNTH-012 ['s0', 'g9.1', 'g9.2', 'g9.4']: material claim produced by 'merged' from ['g9.1', 'g9.2', 'g9.4']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s1', 'g11.1', 'g11.2', 'g11.3', 'g12.1', 'g12.2', 'g12.3']: material claim produced by 'merged' from ['g11.1', 'g11.2', 'g11.3', 'g12.1', 'g12.2', 'g12.3']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'g14.1', 'g14.2']: material claim produced by 'merged' from ['g14.1', 'g14.2']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s3', 'g7.1', 'g7.2']: material claim produced by 'merged' from ['g7.1', 'g7.2']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- ec-p7a.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['CORE-QNT-001']
  - warning CORE-QNT-001 ['g4.1@economics-specialist']: paragraph 4, sentence 1 states worked arithmetic ('$0.40 × 105 million litres = $42 million per year') that could not be checked: it is written arithmetic in '=' form (a worked equation), which this branch's prose arithmetic reader does not decide; the stated arithmetic was not checked
  - warning CORE-QNT-001 ['g6.5@economics-specialist', 'g6.6@economics-specialist']: paragraph 6, sentence 2 states worked arithmetic ('$0.30 × 105 million litres = $31.50 million per year', '$0.10 × 105 million litres = $10.50 million per year') that could not be checked: it is written arithmetic in '=' form (a worked equation), which this branch's prose arithmetic reader does not decide; the stated arithmetic was not checked
  - warning CORE-QNT-001 ['g8.2@economics-specialist', 'g8.3@economics-specialist']: paragraph 8, sentence 2 states worked arithmetic ('$1.60 × 120 million litres = $192.00 million per year', '$1.50 × 105 million litres = $157.50 million per year') that could not be checked: it is written arithmetic in '=' form (a worked equation), which this branch's prose arithmetic reader does not decide; the stated arithmetic was not checked
  - warning CORE-QNT-001 ['g8.7@economics-specialist']: paragraph 8, sentence 3 states a derived figure or a relation over dated figures ('fell by $34.50 million per year') that could not be checked: its sentence states no pair of figures it can be read against (only 17.97%) and the paragraph states no dated series with figures for 2024 and 2025; the stated arithmetic was not checked
- ec-t13.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['CORE-QNT-001']
  - warning CORE-QNT-001 ['g2.6@economics-specialist']: paragraph 2, sentence 3 states a derived figure or a relation over dated figures ('appreciated by 20.00%') that could not be checked: its sentence states its figures only as written arithmetic ('1 ÷ 8.40 = US$0.1190 per krona'), which this reader does not decide, and no pair of figures in words it can be read against and the paragraph states no dated series with figures for 2022 and 2025; the stated arithmetic was not checked
- ec-t13.json [synthesis syn-ec-t13] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-001', 'INT-LEDGER-002'], warnings ['INT-SYNTH-012']
  - error INT-LEDGER-001 ['s0', 'g2.1', 'g2.2', 'g2.3']: synthesized claim cites unknown source claims ['g2.1', 'g2.2', 'g2.3']
  - error INT-LEDGER-001 ['s1', 'g5.1', 'g5.2']: synthesized claim cites unknown source claims ['g5.1', 'g5.2']
  - error INT-LEDGER-001 ['s2', 'g5.3', 'g5.5']: synthesized claim cites unknown source claims ['g5.3', 'g5.5']
  - error INT-LEDGER-002 ['g2.6@economics-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['g5.1@economics-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - warning INT-SYNTH-012 ['s0', 'g2.1', 'g2.2', 'g2.3']: material claim produced by 'merged' from ['g2.1', 'g2.2', 'g2.3']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s1', 'g5.1', 'g5.2']: material claim produced by 'merged' from ['g5.1', 'g5.2']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'g5.3', 'g5.5']: material claim produced by 'merged' from ['g5.3', 'g5.5']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- en-t13.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['ES-STR-001', 'INT-REQ-005']
  - warning INT-REQ-005 []: constraint c3 not satisfied: measured 4 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several)
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
- en-t13.json [synthesis syn-en-t13] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-SYNTH-012']
  - warning INT-SYNTH-012 ['s0', 'p1-s01', 'p4-point']: material claim produced by 'merged' from ['p1-s01', 'p4-point']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s1', 'p1-s02', 'p3-point']: material claim produced by 'merged' from ['p1-s02', 'p3-point']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- ess-t13.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['CORE-QNT-001']
  - warning CORE-QNT-001 ['s4.2']: paragraph 4, sentence 2 states a derived figure or a relation over dated figures ('largest rise') that could not be checked: no figures are stated with it in its sentence and the sentence states no year and no anaphor such as 'that year'; the stated arithmetic was not checked
- ess-t13.json [synthesis syn-ess-t13] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-001', 'INT-LEDGER-002'], warnings ['INT-SYNTH-012']
  - error INT-LEDGER-001 ['s0', 'g2.1', 'g2.2', 'g2.3']: synthesized claim cites unknown source claims ['g2.1', 'g2.2', 'g2.3']
  - error INT-LEDGER-001 ['s1', 'g3.1', 'g3.2', 'g3.3', 'g3.4']: synthesized claim cites unknown source claims ['g3.1', 'g3.2', 'g3.3', 'g3.4']
  - error INT-LEDGER-001 ['s2', 'g4.1', 'g4.2', 'g4.4', 'g4.6']: synthesized claim cites unknown source claims ['g4.1', 'g4.2', 'g4.4', 'g4.6']
  - error INT-LEDGER-002 ['s1.1']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['s2.1']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['s3.1']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['s4.1']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['s4.6']: material source claim is neither carried, transformed nor recorded as dropped
  - warning INT-SYNTH-012 ['s0', 'g2.1', 'g2.2', 'g2.3']: material claim produced by 'merged' from ['g2.1', 'g2.2', 'g2.3']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s1', 'g3.1', 'g3.2', 'g3.3', 'g3.4']: material claim produced by 'merged' from ['g3.1', 'g3.2', 'g3.3', 'g3.4']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'g4.1', 'g4.2', 'g4.4', 'g4.6']: material claim produced by 'merged' from ['g4.1', 'g4.2', 'g4.4', 'g4.6']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- ge-t13.json [synthesis syn-ge-t13] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-001', 'INT-LEDGER-002'], warnings ['INT-SYNTH-012']
  - error INT-LEDGER-001 ['s0', 'g6.1', 'g5.1', 'g6.3']: synthesized claim cites unknown source claims ['g6.1', 'g5.1', 'g6.3']
  - error INT-LEDGER-001 ['s1', 'g7.1', 'g7.2', 'g7.3', 'g7.4']: synthesized claim cites unknown source claims ['g7.1', 'g7.2', 'g7.3', 'g7.4']
  - error INT-LEDGER-001 ['s2', 'g8.1', 'g8.2']: synthesized claim cites unknown source claims ['g8.1', 'g8.2']
  - error INT-LEDGER-001 ['s3', 'g8.3', 'g8.4']: synthesized claim cites unknown source claims ['g8.3', 'g8.4']
  - error INT-LEDGER-002 ['g4.1@geography-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['g6.1@geography-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['g7.1@geography-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['g8.1@geography-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['g8.3@geography-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - warning INT-SYNTH-012 ['s0', 'g6.1', 'g5.1', 'g6.3']: material claim produced by 'merged' from ['g6.1', 'g5.1', 'g6.3']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s1', 'g7.1', 'g7.2', 'g7.3', 'g7.4']: material claim produced by 'merged' from ['g7.1', 'g7.2', 'g7.3', 'g7.4']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'g8.1', 'g8.2']: material claim produced by 'merged' from ['g8.1', 'g8.2']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s3', 'g8.3', 'g8.4']: material claim produced by 'merged' from ['g8.3', 'g8.4']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- hi-p7c.json [genuine] ACCEPTED_WITH_FINDINGS: errors ['INT-SUBJ-001'], warnings ['INT-CONFLICT-005', 'INT-GLOSSARY-005', 'INT-REQ-006']
  - error INT-SUBJ-001 ['h1.1']: the report's own duration statement in claim h1.1 does not hold: report's own arithmetic: ...ctor border on 13 August 1961 ended a drain that had run for more than twelve years, and the Wall that followed was the answer to pressure that had built up ove... [stated across sentences: the span is the one sentence 2 of the paragraph states ('Between the founding of the German Democratic Republic on 7 October 1949 and 1961'); its last year 1961 read as 13 August 1961, the date the duration's own sentence gives in that year] [a stated length of years against its span: in whole years, the difference of the years or the difference plus one (both end years counted); with day or month dates, the elapsed days / 365.2425; 'more than', 'over', 'at least', 'less than', 'under' are exact bounds, 'nearly'/'almost' approach the length from below (85 per cent of it up to it), and 'about', 'roughly' or no qualifier allow 5% of the elapsed time or half a year; a span whose dates are too coarse to decide the length is reported undecided]
  - warning INT-REQ-006 ['h1.1']: claim h1.1's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned COUNTEREXAMPLE, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.2']: claim h1.2's verification gave no verdict: its outcome is displayed INVALID_FORMALIZATION (translation INVALID_FORMALIZATION; no engine result was produced), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.4']: claim h1.4's verification gave no verdict: its outcome is displayed INVALID_FORMALIZATION (translation INVALID_FORMALIZATION; no engine result was produced), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.6']: claim h1.6's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-GLOSSARY-005 ['h1.1', 'h1.6']: symbol 'closed_1961' (Bool) is glossed with different meanings across claims: 'East German forces closed the sector route on 13 August 1961' in 'h1.1' vs 'the route was closed on 13 August 1961' in 'h1.6' (only the first states ['east', 'forc', 'german', 'sector']); the consistency check reads them as different quantities (the symbol is renamed apart per claim), so no contradiction is charged on this shared name; one name for two quantities is a translation fault, not the specialist's (claims ['h1.1', 'h1.6'] are AMBIGUOUS_TRANSLATION: their pooled formalization is one assumed reading, not a fixed one)
  - warning INT-CONFLICT-005 ['h1.1']: specialist claim 'h1.1' refutes itself only under the assumed reading of its AMBIGUOUS_TRANSLATION: its own assertions ['d_mc', 'd_mf', 'd_yc', 'd_yf', 'f_d12', 'f_dm', 'h1.1 (conclusion)'] refute each other in the pooled formalization, which is one reading the translator chose, not a fixed one, so the specialist is not charged with an inconsistency (no other claim is involved; no disclosure is demanded)
- hi-t13.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['HI-STR-001', 'INT-GLOSSARY-005', 'INT-REQ-006']
  - warning INT-REQ-006 ['h1.1']: claim h1.1's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.4']: claim h1.4's verification gave no verdict: its outcome is displayed INVALID_FORMALIZATION (translation INVALID_FORMALIZATION; no engine result was produced), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.5']: claim h1.5's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.7']: claim h1.7's verification gave no verdict: its outcome is displayed INVALID_FORMALIZATION (translation INVALID_FORMALIZATION; no engine result was produced), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.8']: claim h1.8's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.9']: claim h1.9's verification gave no verdict: its outcome is displayed INVALID_FORMALIZATION (translation INVALID_FORMALIZATION; no engine result was produced), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.11']: claim h1.11's verification gave no verdict: its outcome is displayed INVALID_FORMALIZATION (translation INVALID_FORMALIZATION; no engine result was produced), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.13']: claim h1.13's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-GLOSSARY-005 ['h1.1', 'h1.8']: symbol 'laws_1925_26' (Bool) is glossed with different meanings across claims: 'between December 1925 and November 1926 laws gave the head of government powers beyond parliamentary control, banned opposition parties and created the Special Tribunal' in 'h1.1' vs 'the 1925-26 laws were passed' in 'h1.8' (only the first states ['1926', 'bann', 'between', 'beyond', 'control', 'creat', 'december', 'gave', 'government', 'head', 'november', 'opposition', 'parliamentary', 'parti', 'power', 'special', 'tribunal']; only the second states ['26', 'pass']); the consistency check reads them as different quantities (the symbol is renamed apart per claim), so no contradiction is charged on this shared name; one name for two quantities is a translation fault, not the specialist's (claims ['h1.1', 'h1.8'] are AMBIGUOUS_TRANSLATION: their pooled formalization is one assumed reading, not a fixed one)
  - warning INT-GLOSSARY-005 ['h1.1', 'h1.13']: symbol 'rests_violence' (Bool) is glossed with different meanings across claims: 'the legal means rested on the violence that brought him to power' in 'h1.1' vs 'the legal means rested on the violence' in 'h1.13' (only the first states ['brought', 'him', 'power', 'to']); the consistency check reads them as different quantities (the symbol is renamed apart per claim), so no contradiction is charged on this shared name; one name for two quantities is a translation fault, not the specialist's (claims ['h1.1', 'h1.13'] are AMBIGUOUS_TRANSLATION: their pooled formalization is one assumed reading, not a fixed one)
  - warning HI-STR-001 ['h1.1', 'h1.2', 'h1.3', 'h1.4', 'h1.5', 'h1.6', 'h1.7', 'h1.8', 'h1.9', 'h1.10', 'h1.11', 'h1.12', 'h1.13', 'h1.14']: body paragraph 1 has no judgement move (counter-case weighed by a criterion)
- hi-t13.json [synthesis syn-hi-t13] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-GLOSSARY-005', 'INT-SYNTH-012']
  - warning INT-GLOSSARY-005 ['h1.1', 'h1.8']: symbol 'laws_1925_26' (Bool) is glossed with different meanings across claims: 'between December 1925 and November 1926 laws gave the head of government powers beyond parliamentary control, banned opposition parties and created the Special Tribunal' in 'h1.1' vs 'the 1925-26 laws were passed' in 'h1.8' (only the first states ['1926', 'bann', 'between', 'beyond', 'control', 'creat', 'december', 'gave', 'government', 'head', 'november', 'opposition', 'parliamentary', 'parti', 'power', 'special', 'tribunal']; only the second states ['26', 'pass']); the consistency check reads them as different quantities (the symbol is renamed apart per claim), so no contradiction is charged on this shared name; one name for two quantities is a translation fault, not the specialist's (claims ['h1.1', 'h1.8'] are AMBIGUOUS_TRANSLATION: their pooled formalization is one assumed reading, not a fixed one)
  - warning INT-GLOSSARY-005 ['h1.1', 'h1.13']: symbol 'rests_violence' (Bool) is glossed with different meanings across claims: 'the legal means rested on the violence that brought him to power' in 'h1.1' vs 'the legal means rested on the violence' in 'h1.13' (only the first states ['brought', 'him', 'power', 'to']); the consistency check reads them as different quantities (the symbol is renamed apart per claim), so no contradiction is charged on this shared name; one name for two quantities is a translation fault, not the specialist's (claims ['h1.1', 'h1.13'] are AMBIGUOUS_TRANSLATION: their pooled formalization is one assumed reading, not a fixed one)
  - warning INT-SYNTH-012 ['s0', 'h1.1', 'h1.14']: material claim produced by 'merged' from ['h1.1', 'h1.14']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s1', 'h1.4', 'h1.5', 'h1.7']: material claim produced by 'merged' from ['h1.4', 'h1.5', 'h1.7']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'h1.8', 'h1.9', 'h1.10', 'h1.11']: material claim produced by 'merged' from ['h1.8', 'h1.9', 'h1.10', 'h1.11']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s3', 'h1.12', 'h1.13']: material claim produced by 'merged' from ['h1.12', 'h1.13']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- lit-t13.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['ES-STR-001', 'INT-REQ-006']
  - warning INT-REQ-006 ['p1-point']: claim p1-point's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['p2-point']: claim p2-point's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning ES-STR-001 []: body paragraph 3 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
- lit-t13.json [synthesis syn-lit-t13] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-001', 'INT-LEDGER-002', 'INT-LEDGER-003', 'INT-LEDGER-023'], warnings ['INT-LEDGER-019', 'INT-LEDGER-026', 'INT-LEDGER-029', 'INT-SYNTH-012']
  - error INT-LEDGER-023 ['s0', 'p2-point']: synthesized claim ('paraphrased') states figures or dates ['2'] that occur in none of its cited sources ['p2-point']: a changed or introduced figure or date, whatever the transformation label
  - warning INT-LEDGER-026 ['s0', 'p2-point']: synthesized claim ('paraphrased') may say something other than its cited sources ['p2-point']: it adds a negation its cited sources do not state (lexical comparison; not formally checked)
  - error INT-LEDGER-003 ['s1', 'p1-s04']: certainty inflated: synthesis says 'probable' but the weakest source is rank 1 (['possible'])
  - warning INT-LEDGER-026 ['s1', 'p1-s04']: synthesized claim ('paraphrased') may say something other than its cited sources ['p1-s04']: it adds a negation its cited sources do not state (lexical comparison; not formally checked)
  - error INT-LEDGER-001 ['s2', 'p1-s03']: synthesized claim cites unknown source claims ['p1-s03']
  - warning INT-LEDGER-026 ['s3', 'p1-s11']: synthesized claim ('paraphrased') may say something other than its cited sources ['p1-s11']: it adds a negation its cited sources do not state (lexical comparison; not formally checked)
  - warning INT-LEDGER-029 ['s1', 'p1-s04']: synthesized claim ('paraphrased', material) is made only from notes of the specialists ['p1-s04']: claims the delivery read as notes (role 'other': a self-report, a verification label, a word count, a decline, a question, a task note, a heading or a line of a feedback layout such as its provisional marks, or another remark about the answer, never a claim of it), so whatever its wording it carries a note back as a claim: advisory only, never material content and no evidence that anything was checked
  - warning INT-LEDGER-019 ['p1-point']: MATERIAL source claims ['p1-point'] were dropped from the answer; recorded reason: "Restates the task question ('How does the writer present Mrs Okafor's feelings about returning home?'), a task-setting note rather than a content claim."
  - error INT-LEDGER-001 ['p3-point']: ledger entry cites unknown source claims ['p3-point']
  - error INT-LEDGER-002 ['p1-s05']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['p1-s06']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['p1-s07']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['p1-s09']: material source claim is neither carried, transformed nor recorded as dropped
  - warning INT-SYNTH-012 ['s0', 'p2-point']: material claim produced by 'paraphrased' from ['p2-point']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s1', 'p1-s04']: material claim produced by 'paraphrased' from ['p1-s04']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'p1-s03']: material claim produced by 'paraphrased' from ['p1-s03']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s3', 'p1-s11']: material claim produced by 'paraphrased' from ['p1-s11']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- ll-t13.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-REQ-006']
  - warning INT-REQ-006 ['p1-point']: claim p1-point's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
- ll-t13.json [synthesis syn-ll-t13] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-SYNTH-012']
  - warning INT-SYNTH-012 ['s1', 'p1-s03', 'p1-s04']: material claim produced by 'merged' from ['p1-s03', 'p1-s04']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'p1-s07', 'p1-s08', 'p1-s09']: material claim produced by 'merged' from ['p1-s07', 'p1-s08', 'p1-s09']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- maa-t13.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['ST-UNDEC-001']
  - warning ST-UNDEC-001 ['m1.2']: a relation outside the encodings: a derivative; the relation in m1.2 is not checked
  - warning ST-UNDEC-001 ['m3.5']: a relation outside the encodings: an integral; the relation in m3.5 is not checked
  - warning ST-UNDEC-001 ['m3.7']: a relation outside the encodings: an integral; the evaluation of an antiderivative between limits; the relation in m3.7 is not checked
  - warning ST-UNDEC-001 ['m3.8']: a relation outside the encodings: an integral; the evaluation of an antiderivative between limits; the relation in m3.8 is not checked
- maa-t13.json [synthesis syn-maa-t13] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-001', 'INT-LEDGER-002'], warnings ['INT-SYNTH-012']
  - error INT-LEDGER-001 ['s0', 'g1.1', 'g2.1', 'g2.2']: synthesized claim cites unknown source claims ['g1.1', 'g2.1', 'g2.2']
  - error INT-LEDGER-001 ['s1', 'g3.1', 'g3.2', 'g3.3', 'g3.4', 'g3.5']: synthesized claim cites unknown source claims ['g3.1', 'g3.2', 'g3.3', 'g3.4', 'g3.5']
  - error INT-LEDGER-002 ['m1.4']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['m2.6']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['m3.7']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['m3.8']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['m3.10']: material source claim is neither carried, transformed nor recorded as dropped
  - warning INT-SYNTH-012 ['s0', 'g1.1', 'g2.1', 'g2.2']: material claim produced by 'merged' from ['g1.1', 'g2.1', 'g2.2']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s1', 'g3.1', 'g3.2', 'g3.3', 'g3.4', 'g3.5']: material claim produced by 'merged' from ['g3.1', 'g3.2', 'g3.3', 'g3.4', 'g3.5']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- mai-t13.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['ST-UNDEC-001']
  - warning ST-UNDEC-001 ['m8.1']: a relation outside the encodings: a symbolic power; the relation in m8.1 is not checked
  - warning ST-UNDEC-001 ['m11.1']: a relation outside the encodings: a symbolic power; the relation in m11.1 is not checked
  - warning ST-UNDEC-001 ['m12.1']: a relation outside the encodings: a symbolic power; the relation in m12.1 is not checked
  - warning ST-UNDEC-001 ['m12.3']: a relation outside the encodings: an ellipsis; the relation in m12.3 is not checked
- mai-t13.json [synthesis syn-mai-t13] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-001', 'INT-LEDGER-002'], warnings ['INT-SYNTH-012']
  - error INT-LEDGER-001 ['s0', 'g4.1', 'g4.3', 'g5.1', 'g5.2', 'g5.3', 'g6.1', 'g6.3']: synthesized claim cites unknown source claims ['g4.1', 'g4.3', 'g5.1', 'g5.2', 'g5.3', 'g6.1', 'g6.3']
  - error INT-LEDGER-001 ['s1', 'g11.1', 'g11.3', 'g12.1', 'g12.2', 'g12.3']: synthesized claim cites unknown source claims ['g11.1', 'g11.3', 'g12.1', 'g12.2', 'g12.3']
  - error INT-LEDGER-001 ['s2', 'g13.1', 'g13.2', 'g14.1', 'g15.2']: synthesized claim cites unknown source claims ['g13.1', 'g13.2', 'g14.1', 'g15.2']
  - error INT-LEDGER-001 ['s3', 'g16.1', 'g15.1']: synthesized claim cites unknown source claims ['g16.1', 'g15.1']
  - error INT-LEDGER-002 ['m3.1']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['m4.1']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['m5.1']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['m6.1']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['m9.1']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['m10.1']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['m11.1']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['m12.2']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['m12.3']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['m14.1']: material source claim is neither carried, transformed nor recorded as dropped
  - warning INT-SYNTH-012 ['s0', 'g4.1', 'g4.3', 'g5.1', 'g5.2', 'g5.3', 'g6.1', 'g6.3']: material claim produced by 'merged' from ['g4.1', 'g4.3', 'g5.1', 'g5.2', 'g5.3', 'g6.1', 'g6.3']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s1', 'g11.1', 'g11.3', 'g12.1', 'g12.2', 'g12.3']: material claim produced by 'merged' from ['g11.1', 'g11.3', 'g12.1', 'g12.2', 'g12.3']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'g13.1', 'g13.2', 'g14.1', 'g15.2']: material claim produced by 'merged' from ['g13.1', 'g13.2', 'g14.1', 'g15.2']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s3', 'g16.1', 'g15.1']: material claim produced by 'merged' from ['g16.1', 'g15.1']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- ph-t13.json [synthesis syn-ph-t13] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-001', 'INT-LEDGER-002'], warnings ['INT-SYNTH-012']
  - error INT-LEDGER-001 ['s0', 'g1.2', 'g2.1']: synthesized claim cites unknown source claims ['g1.2', 'g2.1']
  - error INT-LEDGER-001 ['s1', 'g3.2', 'g4.2', 'g4.3']: synthesized claim cites unknown source claims ['g3.2', 'g4.2', 'g4.3']
  - error INT-LEDGER-001 ['s2', 'g5.2', 'g5.3', 'g5.4', 'g5.5']: synthesized claim cites unknown source claims ['g5.2', 'g5.3', 'g5.4', 'g5.5']
  - error INT-LEDGER-001 ['g1.1', 'g3.1', 'g4.1', 'g5.1']: ledger entry cites unknown source claims ['g1.1', 'g3.1', 'g4.1', 'g5.1']
  - error INT-LEDGER-002 ['s1.4']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['s2.2']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['s3.2']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['s4.3']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['s5.1']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['s5.4']: material source claim is neither carried, transformed nor recorded as dropped
  - warning INT-SYNTH-012 ['s0', 'g1.2', 'g2.1']: material claim produced by 'merged' from ['g1.2', 'g2.1']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s1', 'g3.2', 'g4.2', 'g4.3']: material claim produced by 'merged' from ['g3.2', 'g4.2', 'g4.3']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'g5.2', 'g5.3', 'g5.4', 'g5.5']: material claim produced by 'merged' from ['g5.2', 'g5.3', 'g5.4', 'g5.5']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- ps-t13.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['PS-SRC-001']
  - warning PS-SRC-001 ['g2.1@psychology-specialist']: study attribution 'Tversky and Kahneman (1974)' has no knowledge-document or library grounding
- ps-t13.json [synthesis syn-ps-t13] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-001', 'INT-LEDGER-002'], warnings ['INT-SYNTH-012']
  - error INT-LEDGER-001 ['s0', 'g1.1', 'g1.2']: synthesized claim cites unknown source claims ['g1.1', 'g1.2']
  - error INT-LEDGER-001 ['s1', 'g2.1', 'g2.2', 'g2.3', 'g2.4']: synthesized claim cites unknown source claims ['g2.1', 'g2.2', 'g2.3', 'g2.4']
  - error INT-LEDGER-002 ['g1.1@psychology-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['g2.1@psychology-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - warning INT-SYNTH-012 ['s0', 'g1.1', 'g1.2']: material claim produced by 'merged' from ['g1.1', 'g1.2']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s1', 'g2.1', 'g2.2', 'g2.3', 'g2.4']: material claim produced by 'merged' from ['g2.1', 'g2.2', 'g2.3', 'g2.4']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- sp-t13.json [synthesis syn-sp-t13] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-001', 'INT-LEDGER-002'], warnings ['INT-SYNTH-012']
  - error INT-LEDGER-001 ['s0', 'g1.1', 'g1.2']: synthesized claim cites unknown source claims ['g1.1', 'g1.2']
  - error INT-LEDGER-001 ['s1', 'g2.1', 'g2.2', 'g2.3']: synthesized claim cites unknown source claims ['g2.1', 'g2.2', 'g2.3']
  - error INT-LEDGER-001 ['s2', 'g4.1', 'g4.2']: synthesized claim cites unknown source claims ['g4.1', 'g4.2']
  - error INT-LEDGER-001 ['s3', 'g6.1', 'g6.2']: synthesized claim cites unknown source claims ['g6.1', 'g6.2']
  - error INT-LEDGER-002 ['g1.1@language-b-spanish-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['g2.1@language-b-spanish-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['g2.2@language-b-spanish-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['g3.1@language-b-spanish-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['g4.1@language-b-spanish-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['g5.1@language-b-spanish-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['g6.1@language-b-spanish-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['g7.1@language-b-spanish-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - warning INT-SYNTH-012 ['s0', 'g1.1', 'g1.2']: material claim produced by 'merged' from ['g1.1', 'g1.2']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s1', 'g2.1', 'g2.2', 'g2.3']: material claim produced by 'merged' from ['g2.1', 'g2.2', 'g2.3']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'g4.1', 'g4.2']: material claim produced by 'merged' from ['g4.1', 'g4.2']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s3', 'g6.1', 'g6.2']: material claim produced by 'merged' from ['g6.1', 'g6.2']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- bm-p7a.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['CORE-QNT-001']
  - warning CORE-QNT-001 ['g6.1@business-management-specialist']: paragraph 6, sentence 1 states worked arithmetic ('−12.50 ÷ 18.75 = −0.67') that could not be checked: it is written arithmetic in '=' form (a worked equation), which this branch's prose arithmetic reader does not decide; the stated arithmetic was not checked
  - warning CORE-QNT-001 ['g9.5@business-management-specialist']: paragraph 9, sentence 1 states worked arithmetic ('$7.22 million ÷ $0.65 = about 11.1 million litres, a fall of about 26% from 15 million litres (26% ÷ 25% = 1.04)') that could not be checked: it is written arithmetic in '=' form (a worked equation), which this branch's prose arithmetic reader does not decide; the stated arithmetic was not checked
- bm-p7a.json [synthesis syn-p7a] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-001', 'INT-LEDGER-002'], warnings ['INT-SYNTH-012'] (cites a report whose recorded relay ['relayed/bm-p7a.json'] differs from the current parse: see the recorded peer relays below)
  - error INT-LEDGER-001 ['ec-p7a-s0', 'g2.1', 'g2.2', 'g2.3']: synthesized claim cites unknown source claims ['g2.1', 'g2.2', 'g2.3']
  - error INT-LEDGER-001 ['ec-p7a-s1', 'g4.1', 'g4.2']: synthesized claim cites unknown source claims ['g4.1', 'g4.2']
  - error INT-LEDGER-001 ['ec-p7a-s2', 'g6.1', 'g6.2', 'g6.3', 'g11.1']: synthesized claim cites unknown source claims ['g6.1', 'g6.2', 'g6.3', 'g11.1']
  - error INT-LEDGER-001 ['ec-p7a-s3', 'g8.1', 'g8.2', 'g8.3']: synthesized claim cites unknown source claims ['g8.1', 'g8.2', 'g8.3']
  - error INT-LEDGER-001 ['bm-p7a-s0', 'g2.1', 'g2.3', 'g3.1', 'g3.2', 'g4.1']: synthesized claim cites unknown source claims ['g2.1', 'g2.3', 'g3.1', 'g3.2', 'g4.1']
  - error INT-LEDGER-001 ['bm-p7a-s1', 'g6.1', 'g6.2', 'g9.1', 'g8.1', 'g8.4', 'g7.4']: synthesized claim cites unknown source claims ['g6.1', 'g6.2', 'g9.1', 'g8.1', 'g8.4', 'g7.4']
  - error INT-LEDGER-001 ['bm-p7a-s2', 'g7.1', 'g7.2', 'g7.3']: synthesized claim cites unknown source claims ['g7.1', 'g7.2', 'g7.3']
  - error INT-LEDGER-001 ['bm-p7a-s3', 'g11.1', 'g11.2', 'g11.4']: synthesized claim cites unknown source claims ['g11.1', 'g11.2', 'g11.4']
  - error INT-LEDGER-001 ['g11.3']: ledger entry cites unknown source claims ['g11.3']
  - error INT-LEDGER-002 ['g2.5@economics-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['g4.2@economics-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['g6.8@economics-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['g8.7@economics-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['g11.1@economics-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['g11.3@economics-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['g4.1@business-management-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['g6.1@business-management-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['g7.1@business-management-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['g8.1@business-management-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['g9.5@business-management-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['g11.1@business-management-specialist']: material source claim is neither carried, transformed nor recorded as dropped
  - warning INT-SYNTH-012 ['ec-p7a-s0', 'g2.1', 'g2.2', 'g2.3']: material claim produced by 'merged' from ['g2.1', 'g2.2', 'g2.3']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['ec-p7a-s1', 'g4.1', 'g4.2']: material claim produced by 'merged' from ['g4.1', 'g4.2']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['ec-p7a-s2', 'g6.1', 'g6.2', 'g6.3', 'g11.1']: material claim produced by 'merged' from ['g6.1', 'g6.2', 'g6.3', 'g11.1']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['ec-p7a-s3', 'g8.1', 'g8.2', 'g8.3']: material claim produced by 'merged' from ['g8.1', 'g8.2', 'g8.3']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['bm-p7a-s0', 'g2.1', 'g2.3', 'g3.1', 'g3.2', 'g4.1']: material claim produced by 'merged' from ['g2.1', 'g2.3', 'g3.1', 'g3.2', 'g4.1']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['bm-p7a-s1', 'g6.1', 'g6.2', 'g9.1', 'g8.1', 'g8.4', 'g7.4']: material claim produced by 'merged' from ['g6.1', 'g6.2', 'g9.1', 'g8.1', 'g8.4', 'g7.4']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['bm-p7a-s2', 'g7.1', 'g7.2', 'g7.3']: material claim produced by 'merged' from ['g7.1', 'g7.2', 'g7.3']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['bm-p7a-s3', 'g11.1', 'g11.2', 'g11.4']: material claim produced by 'merged' from ['g11.1', 'g11.2', 'g11.4']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- lit-p7c.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['ES-META-001', 'INT-CONFLICT-005', 'INT-GLOSSARY-005', 'INT-REQ-006']
  - warning INT-REQ-006 ['p1-point']: claim p1-point's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-GLOSSARY-005 ['h1.1', 'h1.6']: symbol 'closed_1961' (Bool) is glossed with different meanings across claims: 'East German forces closed the sector route on 13 August 1961' in 'h1.1' vs 'the route was closed on 13 August 1961' in 'h1.6' (only the first states ['east', 'forc', 'german', 'sector']); the consistency check reads them as different quantities (the symbol is renamed apart per claim), so no contradiction is charged on this shared name; one name for two quantities is a translation fault, not the specialist's (claims ['h1.1', 'h1.6'] are AMBIGUOUS_TRANSLATION: their pooled formalization is one assumed reading, not a fixed one)
  - warning INT-CONFLICT-005 ['h1.1']: specialist claim 'h1.1' refutes itself only under the assumed reading of its AMBIGUOUS_TRANSLATION: its own assertions ['d_mc', 'd_mf', 'd_yc', 'd_yf', 'f_d12', 'f_dm', 'h1.1 (conclusion)'] refute each other in the pooled formalization, which is one reading the translator chose, not a fixed one, so the specialist is not charged with an inconsistency (no other claim is involved; no disclosure is demanded)
  - warning ES-META-001 []: paragraph 2 is meta-text ('Note: I use none of the History specialist's figures, since its own note says...'): a note about the text, a self-certification, a pasted receipt or a narrated check is not analysis, provides no evidence and plays no part in verification
- lit-p7c.json [synthesis syn-p7c] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-003'], warnings ['INT-CONFLICT-005', 'INT-GLOSSARY-005', 'INT-SYNTH-012'] (cites a report whose recorded relay ['relayed/lit-p7c.json'] differs from the current parse: see the recorded peer relays below)
  - error INT-LEDGER-003 ['hi-p7c-s0', 'h1.1', 'h1.2', 'h1.3', 'h1.4']: certainty inflated: synthesis says 'established' but the weakest source is rank 2 (['established', 'probable', 'established', 'established'])
  - warning INT-GLOSSARY-005 ['h1.1', 'h1.6']: symbol 'closed_1961' (Bool) is glossed with different meanings across claims: 'East German forces closed the sector route on 13 August 1961' in 'h1.1' vs 'the route was closed on 13 August 1961' in 'h1.6' (only the first states ['east', 'forc', 'german', 'sector']); the consistency check reads them as different quantities (the symbol is renamed apart per claim), so no contradiction is charged on this shared name; one name for two quantities is a translation fault, not the specialist's (claims ['h1.1', 'h1.6'] are AMBIGUOUS_TRANSLATION: their pooled formalization is one assumed reading, not a fixed one)
  - warning INT-CONFLICT-005 ['h1.1']: specialist claim 'h1.1' refutes itself only under the assumed reading of its AMBIGUOUS_TRANSLATION: its own assertions ['d_mc', 'd_mf', 'd_yc', 'd_yf', 'f_d12', 'f_dm', 'h1.1 (conclusion)'] refute each other in the pooled formalization, which is one reading the translator chose, not a fixed one, so the specialist is not charged with an inconsistency (no other claim is involved; no disclosure is demanded)
  - warning INT-SYNTH-012 ['hi-p7c-s0', 'h1.1', 'h1.2', 'h1.3', 'h1.4']: material claim produced by 'merged' from ['h1.1', 'h1.2', 'h1.3', 'h1.4']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- maa-p7b.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['ST-UNDEC-001']
  - warning ST-UNDEC-001 ['m1.1']: a relation outside the encodings: a symbolic power; the relation in m1.1 is not checked
  - warning ST-UNDEC-001 ['m2.1']: a relation outside the encodings: a symbolic power; the relation in m2.1 is not checked
  - warning ST-UNDEC-001 ['m2.2']: a relation outside the encodings: a symbolic power; the relation in m2.2 is not checked
  - warning ST-UNDEC-001 ['m2.3']: a relation outside the encodings: a symbolic power; the relation in m2.3 is not checked
  - warning ST-UNDEC-001 ['m3.3']: a relation outside the encodings: a symbolic power; the relation in m3.3 is not checked
  - warning ST-UNDEC-001 ['m4.2']: a relation outside the encodings: a symbolic power; the relation in m4.2 is not checked
  - warning ST-UNDEC-001 ['m5.1']: a function of an unknown; the relation in m5.1 is not checked
- maa-p7b.json [synthesis syn-p7b] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-001', 'INT-LEDGER-002'], warnings ['INT-SYNTH-012'] (cites a report whose recorded relay ['relayed/maa-p7b.json'] differs from the current parse: see the recorded peer relays below)
  - error INT-LEDGER-001 ['ph-p7b-s0', 'g1.3']: synthesized claim cites unknown source claims ['g1.3']
  - error INT-LEDGER-001 ['ph-p7b-s1', 'g2.2', 'g2.3', 'g3.2']: synthesized claim cites unknown source claims ['g2.2', 'g2.3', 'g3.2']
  - error INT-LEDGER-001 ['ph-p7b-s2', 'g4.2', 'g4.3']: synthesized claim cites unknown source claims ['g4.2', 'g4.3']
  - error INT-LEDGER-001 ['ph-p7b-s3', 'g5.2', 'g5.3', 'g5.4', 'g5.5', 'g5.6']: synthesized claim cites unknown source claims ['g5.2', 'g5.3', 'g5.4', 'g5.5', 'g5.6']
  - error INT-LEDGER-001 ['maa-p7b-s0', 'g1.1', 'g1.2', 'g2.1']: synthesized claim cites unknown source claims ['g1.1', 'g1.2', 'g2.1']
  - error INT-LEDGER-001 ['maa-p7b-s1', 'g3.1', 'g3.2', 'g5.1', 'g5.2']: synthesized claim cites unknown source claims ['g3.1', 'g3.2', 'g5.1', 'g5.2']
  - error INT-LEDGER-001 ['maa-p7b-s2', 'g4.1', 'g4.2']: synthesized claim cites unknown source claims ['g4.1', 'g4.2']
  - error INT-LEDGER-001 ['maa-p7b-s3', 'g7.1', 'g7.2', 'g8.1', 'g8.2']: synthesized claim cites unknown source claims ['g7.1', 'g7.2', 'g8.1', 'g8.2']
  - error INT-LEDGER-001 ['g1.1', 'g2.1', 'g3.1', 'g4.1', 'g5.1']: ledger entry cites unknown source claims ['g1.1', 'g2.1', 'g3.1', 'g4.1', 'g5.1']
  - error INT-LEDGER-001 ['g9.1']: ledger entry cites unknown source claims ['g9.1']
  - error INT-LEDGER-002 ['s1.3']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['s1.4']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['s1.5']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['s1.6']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['s1.7']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['s1.8']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['s1.9']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['s2.2']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['s3.2']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['s4.1']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['s5.1']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['m2.5']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['m3.6']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['m4.6']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['m5.2']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['m7.1']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['m8.2']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['m8.3']: material source claim is neither carried, transformed nor recorded as dropped
  - warning INT-SYNTH-012 ['ph-p7b-s1', 'g2.2', 'g2.3', 'g3.2']: material claim produced by 'merged' from ['g2.2', 'g2.3', 'g3.2']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['ph-p7b-s2', 'g4.2', 'g4.3']: material claim produced by 'merged' from ['g4.2', 'g4.3']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['ph-p7b-s3', 'g5.2', 'g5.3', 'g5.4', 'g5.5', 'g5.6']: material claim produced by 'merged' from ['g5.2', 'g5.3', 'g5.4', 'g5.5', 'g5.6']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['maa-p7b-s0', 'g1.1', 'g1.2', 'g2.1']: material claim produced by 'merged' from ['g1.1', 'g1.2', 'g2.1']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['maa-p7b-s1', 'g3.1', 'g3.2', 'g5.1', 'g5.2']: material claim produced by 'merged' from ['g3.1', 'g3.2', 'g5.1', 'g5.2']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['maa-p7b-s2', 'g4.1', 'g4.2']: material claim produced by 'merged' from ['g4.1', 'g4.2']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['maa-p7b-s3', 'g7.1', 'g7.2', 'g8.1', 'g8.2']: material claim produced by 'merged' from ['g7.1', 'g7.2', 'g8.1', 'g8.2']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked

## Recorded peer relays (relayed/<task>.json) compared with the current parse of the peer's raw text (the genuine pass delivers the current parse; the recording is the dependent agent's document only)

- relayed/bm-p7a.json (ec-p7a relayed to bm-p7a): DIFFERS from the current parse; the genuine pass delivered the current parse and used the recording only for the document the agent read
  - the recorded file also carries router-only fields the dependent agent could read beyond its peer's report: ['peer_receipt', 'plan', 'relay', 'request'] (relay_peer.py now writes them to router/<task>.json)
  - claims only in the recording: ['g1.1', 'g2.1', 'g2.2', 'g2.3', 'g3.1', 'g4.1', 'g4.2', 'g5.1', 'g6.1', 'g6.2', 'g6.3', 'g7.1', 'g8.1', 'g8.2', 'g8.3', 'g9.1', 'g10.1', 'g11.1', 'g11.2', 'g11.3', 'g11.4']
  - claims only in the current parse: ['g2.1@economics-specialist', 'g2.2@economics-specialist', 'g2.3@economics-specialist', 'g2.4@economics-specialist', 'g2.5@economics-specialist', 'g2.6@economics-specialist', 'g4.1@economics-specialist', 'g4.2@economics-specialist', 'g6.1@economics-specialist', 'g6.2@economics-specialist', 'g6.3@economics-specialist', 'g6.4@economics-specialist', 'g6.5@economics-specialist', 'g6.6@economics-specialist', 'g6.7@economics-specialist', 'g6.8@economics-specialist', 'g8.1@economics-specialist', 'g8.2@economics-specialist', 'g8.3@economics-specialist', 'g8.4@economics-specialist', 'g8.5@economics-specialist', 'g8.6@economics-specialist', 'g8.7@economics-specialist', 'g10.1@economics-specialist', 'g10.2@economics-specialist', 'g10.3@economics-specialist', 'g10.4@economics-specialist', 'g10.5@economics-specialist', 'g10.6@economics-specialist', 'g11.1@economics-specialist', 'g11.2@economics-specialist', 'g11.3@economics-specialist', 'g11.4@economics-specialist']
- relayed/lit-p7c.json (hi-p7c relayed to lit-p7c): DIFFERS from the current parse; the genuine pass delivered the current parse and used the recording only for the document the agent read
  - the recorded file also carries router-only fields the dependent agent could read beyond its peer's report: ['peer_receipt', 'plan', 'relay', 'request'] (relay_peer.py now writes them to router/<task>.json)
  - payload fields that differ: ['unresolved_issues']
  - h1.2 assumptions: recorded [] -> current ["the answer's own note (h2.1) says its sources do not confirm the figure 'millions': the figure is the specialist's estimate, not a confirmed one"]
  - h1.2 certainty: recorded "established" -> current "probable"
  - h2.1 claim_role: recorded "point" -> current "other"
  - h2.1 materiality: recorded "material" -> current "supporting"
- relayed/maa-p7b.json (ph-p7b relayed to maa-p7b): DIFFERS from the current parse; the genuine pass delivered the current parse and used the recording only for the document the agent read
  - the recorded file also carries router-only fields the dependent agent could read beyond its peer's report: ['peer_receipt', 'plan', 'relay', 'request'] (relay_peer.py now writes them to router/<task>.json)
  - claims only in the recording: ['g1.1', 'g1.2', 'g1.3', 'g2.1', 'g2.2', 'g2.3', 'g3.1', 'g3.2', 'g4.1', 'g4.2', 'g4.3', 'g5.1', 'g5.2', 'g5.3', 'g5.4', 'g5.5', 'g5.6']
  - claims only in the current parse: ['s1.1', 's1.2', 's1.3', 's1.4', 's1.5', 's1.6', 's1.7', 's1.8', 's1.9', 's2.1', 's2.2', 's3.1', 's3.2', 's4.1', 's4.2', 's5.1', 's5.2', 's5.3', 's5.4', 's5.5']

## Mutations: findings beyond the genuine record that do not name the injection (a consequence of the injected words, such as a word bound crossed, or a wrong receipt: read the message)

- ch-t13.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['s7.3']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 456 words; bound min_words 540; solver COUNTEREXAMPLE (genuine record: constraint c1 not satisfied: measured 439 words; bound min_words 540; solver COUNTEREXAMPLE) (genuine record: measured 439 words; bound min_words 540; solver COUNTEREXAMPLE; the mutation added 17 words)
- ch-t13.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['s7.3']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 456 words; bound min_words 540; solver COUNTEREXAMPLE (genuine record: constraint c1 not satisfied: measured 439 words; bound min_words 540; solver COUNTEREXAMPLE) (genuine record: measured 439 words; bound min_words 540; solver COUNTEREXAMPLE; the mutation added 17 words)
- ch-t13.json [self_certification] ACCEPTED_WITH_FINDINGS: injected claims ['s8.1']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 439 words (6 words of note or meta-text blocks excluded, as for paragraphs); bound min_words 540; solver COUNTEREXAMPLE (genuine record: constraint c1 not satisfied: measured 439 words; bound min_words 540; solver COUNTEREXAMPLE) (genuine record: measured 439 words; bound min_words 540; solver COUNTEREXAMPLE; the mutation added 6 words)
- ch-t13.json [wrong_arithmetic] ACCEPTED_WITH_FINDINGS: injected claims ['s7.3']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 452 words; bound min_words 540; solver COUNTEREXAMPLE (genuine record: constraint c1 not satisfied: measured 439 words; bound min_words 540; solver COUNTEREXAMPLE) (genuine record: measured 439 words; bound min_words 540; solver COUNTEREXAMPLE; the mutation added 13 words)
- ch-t13.json [chronology_error] ACCEPTED_WITH_FINDINGS: injected claims ['s7.3']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 455 words; bound min_words 540; solver COUNTEREXAMPLE (genuine record: constraint c1 not satisfied: measured 439 words; bound min_words 540; solver COUNTEREXAMPLE) (genuine record: measured 439 words; bound min_words 540; solver COUNTEREXAMPLE; the mutation added 16 words)
- en-t13.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q02', 'p4-s03']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 307 words; bound max_words 300; solver COUNTEREXAMPLE (genuine record: measured 290 words; bound max_words 300; solver ENTAILED; the mutation added 17 words)
  - lost from the genuine record: warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
- en-t13.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q02', 'p4-s03']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 307 words; bound max_words 300; solver COUNTEREXAMPLE (genuine record: measured 290 words; bound max_words 300; solver ENTAILED; the mutation added 17 words)
  - lost from the genuine record: warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
- en-t13.json [wrong_arithmetic] ACCEPTED_WITH_FINDINGS: injected claims ['p4-s03']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 303 words; bound max_words 300; solver COUNTEREXAMPLE (genuine record: measured 290 words; bound max_words 300; solver ENTAILED; the mutation added 13 words)
- en-t13.json [chronology_error] ACCEPTED_WITH_FINDINGS: injected claims ['p4-s03']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 306 words; bound max_words 300; solver COUNTEREXAMPLE (genuine record: measured 290 words; bound max_words 300; solver ENTAILED; the mutation added 16 words)
- hi-p7c.json [wrong_arithmetic] ACCEPTED_WITH_FINDINGS: injected claims ['h2.2']
  - info-level: ['CORE-SRC-002']
- lit-t13.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['p3-q01', 'p3-s04']
  - warning ES-STR-001 ['p3-point']: body paragraph 3 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence (genuine record: body paragraph 3 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence)
  - info-level: ['ES-STR-002']
- lit-t13.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['p3-q01', 'p3-s04']
  - warning ES-STR-001 ['p3-point']: body paragraph 3 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence (genuine record: body paragraph 3 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence)
  - info-level: ['ES-STR-002']
- lit-t13.json [wrong_arithmetic] ACCEPTED_WITH_FINDINGS: injected claims ['p3-s04']
  - info-level: ['ES-STR-002']
- lit-t13.json [chronology_error] ACCEPTED_WITH_FINDINGS: injected claims ['p3-s04']
  - info-level: ['ES-STR-002']
- ll-t13.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['p1-q16', 'p1-s11']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 302 words; bound max_words 300; solver COUNTEREXAMPLE (genuine record: measured 285 words; bound max_words 300; solver ENTAILED; the mutation added 17 words)
- ll-t13.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['p1-q16', 'p1-s11']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 302 words; bound max_words 300; solver COUNTEREXAMPLE (genuine record: measured 285 words; bound max_words 300; solver ENTAILED; the mutation added 17 words)
- ll-t13.json [chronology_error] ACCEPTED_WITH_FINDINGS: injected claims ['p1-s11']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 301 words; bound max_words 300; solver COUNTEREXAMPLE (genuine record: measured 285 words; bound max_words 300; solver ENTAILED; the mutation added 16 words)
- maa-t13.json [wrong_arithmetic] ACCEPTED_WITH_FINDINGS: injected claims ['m4.2']
  - info-level: ['CORE-SRC-002']
- ph-t13.json [wrong_arithmetic] ACCEPTED_WITH_FINDINGS: injected claims ['s5.5']
  - info-level: ['CORE-SRC-002']
- ps-t13.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['g3.2@psychology-specialist']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 216 words; bound max_words 200; solver COUNTEREXAMPLE (genuine record: measured 199 words; bound max_words 200; solver ENTAILED; the mutation added 17 words)
- ps-t13.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['g3.2@psychology-specialist']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 216 words; bound max_words 200; solver COUNTEREXAMPLE (genuine record: measured 199 words; bound max_words 200; solver ENTAILED; the mutation added 17 words)
- ps-t13.json [wrong_arithmetic] ACCEPTED_WITH_FINDINGS: injected claims ['g3.2@psychology-specialist']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 212 words; bound max_words 200; solver COUNTEREXAMPLE (genuine record: measured 199 words; bound max_words 200; solver ENTAILED; the mutation added 13 words)
  - info-level: ['CORE-SRC-002']
- ps-t13.json [chronology_error] ACCEPTED_WITH_FINDINGS: injected claims ['g3.2@psychology-specialist']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 215 words; bound max_words 200; solver COUNTEREXAMPLE (genuine record: measured 199 words; bound max_words 200; solver ENTAILED; the mutation added 16 words)
- lit-p7c.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['p2-point', 'p2-q01']
  - lost from the genuine record: warning ES-META-001 []: paragraph 2 is meta-text ('Note: I use none of the History specialist's figures, since its own note says...'): a note about the text, a self-certification, a pasted receipt or a narrated check is not analysis, provides no evidence and plays no part in verification
  - info-level: ['ES-STY-001']
- lit-p7c.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['p2-point', 'p2-q01']
  - lost from the genuine record: warning ES-META-001 []: paragraph 2 is meta-text ('Note: I use none of the History specialist's figures, since its own note says...'): a note about the text, a self-certification, a pasted receipt or a narrated check is not analysis, provides no evidence and plays no part in verification
  - info-level: ['ES-STY-001']
- lit-p7c.json [wrong_arithmetic] ACCEPTED_WITH_FINDINGS: injected claims ['p2-s02']
  - warning ES-STR-001 []: body paragraph 2 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
  - lost from the genuine record: warning ES-META-001 []: paragraph 2 is meta-text ('Note: I use none of the History specialist's figures, since its own note says...'): a note about the text, a self-certification, a pasted receipt or a narrated check is not analysis, provides no evidence and plays no part in verification
  - info-level: ['ES-STY-001']
- lit-p7c.json [chronology_error] ACCEPTED_WITH_FINDINGS: injected claims ['p2-s02']
  - warning ES-STR-001 []: body paragraph 2 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
  - lost from the genuine record: warning ES-META-001 []: paragraph 2 is meta-text ('Note: I use none of the History specialist's figures, since its own note says...'): a note about the text, a self-certification, a pasted receipt or a narrated check is not analysis, provides no evidence and plays no part in verification
  - info-level: ['ES-STY-001']

## Delivery decisions (delivery policy delivery-v1: 240 s translation budget, overseer-selected fallback above 0.9; docs/DELIVERY.md)

Each genuine answer is replayed on a hub of its own with the transfer auditor attached and decided by the delivery policy. Overseer agents: not configured (the harness calls no model): the fallback establishes no accuracy. A separate measure: it changes no transport count. Modes: formally_checked 0, overseer_selected 0, not_checked 0, withheld 22; receipts identical to the genuine records' (status and codes): 22 of 22; the pass took 14.028 s.

| task | mode | time to decision (s) | translation (s) | overseer (s) | candidates (accuracy) | chosen | why |
| --- | --- | --- | --- | --- | --- | --- | --- |
| bi-t13.json | withheld | 0.345 | 0.342 | - | biology-specialist 0/4 | - | claim s2.1: not_attempted (the verifier produced no outcome (no translation was served) (NOT_ATTEMPTED)) |
| bm-t13.json | withheld | 0.385 | 0.381 | - | business-management-specialist 0/5 | - | claim g5.2@business-management-specialist: not_attempted (the verifier produced no outcome (no translation was served) (NOT_ATTEMPTED)) |
| ch-t13.json | withheld | 0.177 | 0.173 | - | chemistry-specialist 0/5 (faulted, not deliverable) | - | the consolidation is NO_DELIVERABLE_OUTPUT: every answer is excluded |
| cs-t13.json | withheld | 0.268 | 0.264 | - | computer-science-specialist 0/8 | - | claim c2.4: not_attempted (the verifier produced no outcome (no translation was served) (NOT_ATTEMPTED)) |
| ec-p7a.json | withheld | 0.531 | 0.524 | - | economics-specialist 0/6 | - | claim g2.5@economics-specialist: not_attempted (the verifier produced no outcome (no translation was served) (NOT_ATTEMPTED)) |
| ec-t13.json | withheld | 0.328 | 0.324 | - | economics-specialist 0/2 | - | claim g2.6@economics-specialist: not_attempted (the verifier produced no outcome (no translation was served) (NOT_ATTEMPTED)) |
| en-t13.json | withheld | 1.590 | 1.514 | - | english-specialist-specialist 0/5 | - | claim p2-point: unresolved (release rule release-v1: ungrounded dependencies (relied on, not established by the supplied material or the task): L-p2-s02, A-p2-s… |
| ess-t13.json | withheld | 0.521 | 0.517 | - | ess-specialist 0/5 | - | claim s1.1: not_attempted (the verifier produced no outcome (no translation was served) (NOT_ATTEMPTED)) |
| ge-t13.json | withheld | 0.329 | 0.325 | - | geography-specialist 0/5 | - | claim g4.1@geography-specialist: not_attempted (the verifier produced no outcome (no translation was served) (NOT_ATTEMPTED)) |
| hi-p7c.json | withheld | 0.689 | 0.670 | - | history-specialist 0/2 (refuted, not deliverable) | - | the consolidation is NO_DELIVERABLE_OUTPUT: every answer is excluded |
| hi-t13.json | withheld | 0.950 | 0.911 | - | history-specialist 0/3 | - | claim h1.1: unresolved (translation AMBIGUOUS_TRANSLATION; the translation carries ambiguity flags: because, largely; display status AMBIGUOUS_TRANSLATION: no d… |
| lit-t13.json | withheld | 0.497 | 0.482 | - | english-a-literature-specialist 0/6 (faulted, not deliverable) | - | the consolidation is NO_DELIVERABLE_OUTPUT: every answer is excluded |
| ll-t13.json | withheld | 0.550 | 0.531 | - | english-a-lang-lit-specialist 0/1 | - | claim p1-point: unresolved (translation AMBIGUOUS_TRANSLATION; the translation carries ambiguity flags: referent, link_basis; display status AMBIGUOUS_TRANSLATI… |
| maa-t13.json | withheld | 0.665 | 0.661 | - | mathematics-aa-specialist 0/5 | - | claim m1.4: not_attempted (the verifier produced no outcome (no translation was served) (NOT_ATTEMPTED)) |
| mai-t13.json | withheld | 0.580 | 0.575 | - | mathematics-ai-specialist 0/10 | - | claim m3.1: not_attempted (the verifier produced no outcome (no translation was served) (NOT_ATTEMPTED)) |
| ph-p7b.json | withheld | 0.862 | 0.856 | - | physics-specialist 0/11 | - | claim s1.3: not_attempted (the verifier produced no outcome (no translation was served) (NOT_ATTEMPTED)) |
| ph-t13.json | withheld | 0.993 | 0.989 | - | physics-specialist 0/6 | - | claim s1.4: not_attempted (the verifier produced no outcome (no translation was served) (NOT_ATTEMPTED)) |
| ps-t13.json | withheld | 0.064 | 0.062 | - | psychology-specialist 0/2 | - | claim g1.1@psychology-specialist: not_attempted (the verifier produced no outcome (no translation was served) (NOT_ATTEMPTED)) |
| sp-t13.json | withheld | 0.083 | 0.079 | - | language-b-spanish-specialist 0/8 | - | claim g1.1@language-b-spanish-specialist: not_attempted (the verifier produced no outcome (no translation was served) (NOT_ATTEMPTED)) |
| bm-p7a.json | withheld | 0.834 | 0.824 | - | business-management-specialist 0/6 | - | claim g4.1@business-management-specialist: not_attempted (the verifier produced no outcome (no translation was served) (NOT_ATTEMPTED)) |
| lit-p7c.json | withheld | 1.423 | 1.368 | - | english-a-literature-specialist 0/2 | - | claim p1-point: unresolved (translation AMBIGUOUS_TRANSLATION; the translation carries ambiguity flags: attribution; display status AMBIGUOUS_TRANSLATION: no de… |
| maa-p7b.json | withheld | 1.247 | 1.239 | - | mathematics-aa-specialist 0/7 | - | claim m2.5: not_attempted (the verifier produced no outcome (no translation was served) (NOT_ATTEMPTED)) |

## Failures

(none)