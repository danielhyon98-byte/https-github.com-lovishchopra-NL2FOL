# Arena r4 (QUALIFIED: 2 of 27 recorded translations not served; 25 served by claim id only)

Transmissions: 46; functional: 46 (100.0%). This is the transport measure only: fixture coverage, translation fidelity and the claim counts are separate measures (below), never combined with it into one rate.

Genuine transmissions, peer relays and combinator syntheses: 12. With an error-level finding: 1 (en-p3.json [synthesis syn-p3]: INT-LEDGER-002 ['h1.8'], INT-LEDGER-002 ['p1-s08']), of which 1 counted functional. With warning-level findings only: 8, of which 8 counted functional. The rate does not judge whether a finding is true: a false error on a correct statement is counted functional like a true one, so read every finding in the genuine section below.

## Measures (each on its own denominator; none is combined with another into one rate)

- Transport (functional transmissions): 46 of 46 (100.0%). Genuine traffic delivered and decided: 12 of 12 (genuine replies 6, peer relays 1, syntheses 5); injected faults named: 34 of 34 mutation records. Transport says the hub delivered and decided every transmission; it does not judge whether a finding is true, whether a translation is faithful or whether an answer is better.
- Fixture coverage (recorded translations served in this run): 25 of 27 served; NOT SERVED: 2 (2 claim not eligible under the current policy). Of the 25 served, 0 were bound to a recorded claim-text digest and 25 by claim id only.
- Translation fidelity (faithful translations where adjudicated): not adjudicated; the round has no adjudications/translation_fidelity.json, so no fidelity figure applies to this run.
- Claims (genuine pass, each delivered claim once): extracted 100; eligible for translation 27; attempted 25; completed (a definitive verdict displayed) 8; faithful: not adjudicated; approved (displayed ENTAILED with no error-level finding on the claim; not a release decision) 2, of which 2 rest on at least one ungrounded premise and 2 on at least one unresolved dependency (ungrounded, or authority no check validated); release permitted by the release assessment (the application's rule, apart from the formal status) 0. Eligible claims with no translation attempted: 2.
- Latency (hub processing per transmission in this run, on this machine; not a stress measurement): genuine traffic median 98 ms, 95th percentile 384 ms, max 384 ms over 11; injected faults median 140 ms, 95th percentile 344 ms, max 402 ms over 34.
- Cost: no translation provider was called (recorded fixtures only).
- QUALIFIED (TRANSLATIONS_LOST): 2 of 27 recorded translations were not served in this run (2 claim not eligible under the current policy); translation outcomes cover the 25 served, so this run is not a translation regression over the recorded round.
- QUALIFIED (FIXTURES_UNBOUND): 25 of the 25 served translations carry no recorded claim-text digest: each is bound to the text its claim id carries in this run, which may not be the sentence it was produced for.

| variant | functional | total |
| --- | --- | --- |
| genuine | 6 | 6 |
| synthesis | 5 | 5 |
| peer_relay | 1 | 1 |
| invented_quotation | 6 | 6 |
| invented_quotation_single | 6 | 6 |
| altered_quotation | 4 | 4 |
| self_certification | 6 | 6 |
| wrong_arithmetic | 6 | 6 |
| chronology_error | 6 | 6 |

## Translation outcomes (provider-dependent; genuine pass, one outcome per eligible claim with a fixture)

- AMBIGUOUS_TRANSLATION: 16 (16 distinct claims)
- COUNTEREXAMPLE: 6 (6 distinct claims)
- ENTAILED: 2 (2 distinct claims)
- INVALID_FORMALIZATION: 1 (1 distinct claims)
- NOT_ELIGIBLE: 2 (2 distinct claims)
- ENTAILED verdicts resting only on ungrounded premises: 1 of 2: en-t7.json p1-s01
- encodings given no verdict on genuine claims (displayed INVALID_FORMALIZATION: a definitive engine status withheld, or the encoding rejected at translation): 1; E108 vacuous result: 1 (hi-t8.json h1.4 (COUNTEREXAMPLE)); E110 unasserted figure: 0; E111 unencoded reason: 0; E112 circular encoding: 0; stated precision: 0; exactness: 0
- advisory coverage warnings on genuine claims (the verdict on the encoding stands; the encoding leaves a figure or symbol open that no source asserts; a coverage measure, not a verdict): 0; W110 unasserted figure, advisory: 0; W111 unconstrained symbol, advisory: 0
- definitive verdicts other than ENTAILED displayed on genuine claims (each is shown to the router as the engine's verdict on the claim's encoding: COUNTEREXAMPLE, the claim does not follow from its premises; INCONSISTENT_PREMISES, its premises conflict): 6
  - en-t8.json p4-point: COUNTEREXAMPLE (translation TRANSLATED, engine COUNTEREXAMPLE); rests on the problem's 5 premise(s), 4 ungrounded and 0 unverified; no premise relied on: a counterexample has no core, it holds every premise and falsifies the conclusion; counterexample: country_quote=true, mock_solemn_stake=true, trivial_inflated=true, completes_pattern=false, gap_draws_reader=true, reader_kept_in_joke=true; conclusion: 'The mock-solemn stake, "or the Country\'s done for", completes the pattern: a trivial point is inflated into national survival, and the reader is kept in on the joke rather than asked to take it seriou'; engine diagnostics: none
  - hi-p3.json h1.6: COUNTEREXAMPLE (translation TRANSLATED, engine COUNTEREXAMPLE); rests on the problem's 2 premise(s), 2 ungrounded and 0 unverified; no premise relied on: a counterexample has no core, it holds every premise and falsifies the conclusion; counterexample: peace_signed_25mar1802=true, peace_ended_war=false, war_since_1793=true, visitors_allowed_summer=false, wordsworth_among_visitors=false; conclusion: 'The Peace of Amiens, signed on 25 March 1802, ended a war that Britain had fought with France since 1793 and allowed British visitors to cross to Paris that summer, Wordsworth among them.'; engine diagnostics: none
  - hi-t7.json h1.5: COUNTEREXAMPLE (translation TRANSLATED, engine COUNTEREXAMPLE); rests on the problem's 2 premise(s), 2 ungrounded and 0 unverified; no premise relied on: a counterexample has no core, it holds every premise and falsifies the conclusion; counterexample: reparations_date=true, bill_bn=132, finances_tied_foreign=false; conclusion: "The reparations bill, fixed on 5 May 1921 at 132 billion gold marks, tied the state's finances to foreign transfers."; engine diagnostics: none
  - hi-t7.json h1.9: COUNTEREXAMPLE (translation TRANSLATED, engine COUNTEREXAMPLE); rests on the problem's 4 premise(s), 4 ungrounded and 0 unverified; no premise relied on: a counterexample has no core, it holds every premise and falsifies the conclusion; counterexample: spart_jan1919=true, spart_left=false, kapp_mar1920=true, kapp_right=false, erz_aug1921=true, rath_jun1922=true, murders_far_right=false, courts_lenient=false; conclusion: 'The Spartacist rising of January 1919 and the Kapp Putsch of March 1920 came from the left and the right, and the murders of Matthias Erzberger in August 1921 and Walther Rathenau in June 1922 were ca'; engine diagnostics: none
  - hi-t8.json h1.1: COUNTEREXAMPLE (translation TRANSLATED, engine COUNTEREXAMPLE); rests on the problem's 15 premise(s), 15 ungrounded and 0 unverified; no premise relied on: a counterexample has no core, it holds every premise and falsifies the conclusion; counterexample: u1929=19/10, u1930=31/10, u1931=9/2, u1932=28/5, u_peak=61/10, peak_feb1932=true, h13_decree_dec1930=true, h13_decree_jun1931=true, h13_danatbank=true, h13_cut_wages=true, h13_deepened=true, h13_banking_turn=true, h14_turning_1930=true, h15_claim=true, h16_claim=true, credit_recall=false; conclusion: 'The Wall Street Crash of October 1929 led American lenders to recall the short-term credit on which the Weimar economy depended, and registered unemployment then rose in each year that followed.'; engine diagnostics: none
  - hi-t8.json h1.3: COUNTEREXAMPLE (translation TRANSLATED, engine COUNTEREXAMPLE); rests on the problem's 3 premise(s), 3 ungrounded and 0 unverified; no premise relied on: a counterexample has no core, it holds every premise and falsifies the conclusion; counterexample: decree_dec1930=true, decree_jun1931=true, cut_wages_benefits=false, deepened_fall=false, danatbank_jul1931=true, banking_crisis_turn=false; conclusion: "Brüning's deflationary decrees of December 1930 and June 1931 cut wages and benefits and deepened the fall in demand, while the collapse of the Danatbank on 13 July 1931 turned the slump into a bankin"; engine diagnostics: none
- all variants together (the same claims repeated): {'AMBIGUOUS_TRANSLATION': 103, 'ENTAILED': 13, 'COUNTEREXAMPLE': 38, 'NOT_ELIGIBLE': 13, 'INVALID_FORMALIZATION': 6, 'STALE_FIXTURE_REFUSED': 2}

## Genuine transmissions, peer relays and combinator syntheses carrying error- or warning-level findings (correct against a specialist's or the combinator's fault, or a false finding: read the message)

- en-t7.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['ES-STR-001', 'INT-GLOSSARY-005', 'INT-REQ-005']
  - warning INT-REQ-005 []: constraint c3 not satisfied: measured 4 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several)
  - warning INT-GLOSSARY-005 ['p2-point', 'p4-point']: symbol 'seem_word' (Bool) is glossed with different meanings across claims: "the poem uses the verb 'seem'" in 'p2-point' vs "the qualifier 'seem' is in the poem" in 'p4-point' (only the first states ['use', 'verb']; only the second states ['qualifier']); the consistency check reads them as different quantities (the symbol is renamed apart per claim), so no contradiction is charged on this shared name; one name for two quantities is a translation fault, not the specialist's (claims ['p2-point', 'p4-point'] are AMBIGUOUS_TRANSLATION: their pooled formalization is one assumed reading, not a fixed one)
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
- en-t7.json [synthesis syn-en-t7] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-GLOSSARY-005']
  - warning INT-GLOSSARY-005 ['p2-point', 'p4-point']: symbol 'seem_word' (Bool) is glossed with different meanings across claims: "the poem uses the verb 'seem'" in 'p2-point' vs "the qualifier 'seem' is in the poem" in 'p4-point' (only the first states ['use', 'verb']; only the second states ['qualifier']); the consistency check reads them as different quantities (the symbol is renamed apart per claim), so no contradiction is charged on this shared name; one name for two quantities is a translation fault, not the specialist's (claims ['p2-point', 'p4-point'] are AMBIGUOUS_TRANSLATION: their pooled formalization is one assumed reading, not a fixed one)
- en-t8.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['ES-STR-001', 'INT-REQ-005']
  - warning INT-REQ-005 []: constraint c4 not satisfied: measured 4 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several)
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
- hi-p3.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['CORE-SRC-003']
  - warning CORE-SRC-003 ['h1.8']: 1 quotation(s) cannot be verified: no text was supplied and the from-memory label concerns dates and figures, not quotations: 'smokeless air'
- hi-t7.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['CORE-CHR-001']
  - warning CORE-CHR-001 ['h1.2']: paragraph 1, sentence 2 orders two dated events ('before': 28 June 1919 later than the violence) but the relation could not be decided: stated across sentences: the date of 'the treaty' (28 June 1919) was taken from another sentence of the paragraph: 'Signed on 28 June 1919, the treaty took about 13 per cent of Germany's pre-war European territory and roughly a tenth of', but 'the violence' carries no date in this sentence or elsewhere in the paragraph; the stated relation was not checked
  - warning CORE-CHR-001 ['h1.8']: paragraph 1, sentence 8 orders two dated events ('before': 28 June 1919 later than instability) but the relation could not be decided: stated across sentences: the date of 'the treaty' (28 June 1919) was taken from another sentence of the paragraph: 'Signed on 28 June 1919, the treaty took about 13 per cent of Germany's pre-war European territory and roughly a tenth of', but 'instability' carries no date in this sentence or elsewhere in the paragraph; the stated relation was not checked
- hi-t7.json [synthesis syn-hi-t7] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-LEDGER-027', 'INT-SYNTH-012']
  - warning INT-LEDGER-027 ['s0', 'h1.1', 'h1.11']: synthesized claim ('merged') states dated or quantified items ['1923'] of source claims ['h1.1', 'h1.11'] that the specialist labelled from memory (['a note of its report labels its dates and figures from memory']), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-LEDGER-027 ['s1', 'h1.10']: synthesized claim ('carried') states dated or quantified items ['1923'] of source claims ['h1.10'] that the specialist labelled from memory (['a note of its report labels its dates and figures from memory']), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-LEDGER-027 ['s2', 'h1.6']: synthesized claim ('paraphrased') states dated or quantified items ['11', '4.2', '1923', 'january 1923', 'november 1923'] of source claims ['h1.6'] that the specialist labelled from memory (['a note of its report labels its dates and figures from memory']), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-SYNTH-012 ['s0', 'h1.1', 'h1.11']: material claim produced by 'merged' from ['h1.1', 'h1.11']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'h1.6']: material claim produced by 'paraphrased' from ['h1.6']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- hi-t8.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-CONFLICT-005']
  - warning INT-CONFLICT-005 ['h1.5']: specialist claim 'h1.5' refutes itself only under the assumed reading of its AMBIGUOUS_TRANSLATION: its own assertions ['concl (conclusion)', 'pr_u1929', 'pr_u1930'] refute each other in the pooled formalization, which is one reading the translator chose, not a fixed one, so the specialist is not charged with an inconsistency (no other claim is involved; no disclosure is demanded)
- hi-t8.json [synthesis syn-hi-t8] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-CONFLICT-005', 'INT-LEDGER-010', 'INT-LEDGER-027', 'INT-SYNTH-012']
  - warning INT-LEDGER-027 ['s1', 'h1.2']: synthesized claim ('carried') states dated or quantified items ['1.9', '3.1', '4.5', '5.6', '6.1', '1929', '1930', '1931', '1932', 'february 1932'] of source claims ['h1.2'] that the specialist labelled from memory (["'figures from memory; check them against your notes'"]), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-LEDGER-010 ['s1', 'h1.2']: claim marked 'carried' but its text differs from the source; record it as 'paraphrased' or a new linked claim
  - warning INT-CONFLICT-005 ['h1.5']: specialist claim 'h1.5' refutes itself only under the assumed reading of its AMBIGUOUS_TRANSLATION: its own assertions ['concl (conclusion)', 'pr_u1929', 'pr_u1930'] refute each other in the pooled formalization, which is one reading the translator chose, not a fixed one, so the specialist is not charged with an inconsistency (no other claim is involved; no disclosure is demanded)
  - warning INT-SYNTH-012 ['s2', 'h1.4', 'h1.5']: material claim produced by 'merged' from ['h1.4', 'h1.5']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- en-p3.json [synthesis syn-p3] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-002'], warnings ['INT-LEDGER-024', 'INT-LEDGER-027', 'INT-SYNTH-012'] (cites a report whose recorded relay ['relayed/en-p3.json'] differs from the current parse: see the recorded peer relays below)
  - warning INT-LEDGER-027 ['hi-p3-s0', 'h1.2']: synthesized claim ('carried') states dated or quantified items ['1801', '1802', 'a million'] of source claims ['h1.2'] that the specialist labelled from memory (['a note of its report labels its dates and figures from memory']), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-LEDGER-024 ['hi-p3-s1', 'h1.4', 'h1.5']: figures or dates ['1661'] of the cited sources ['h1.4', 'h1.5'] do not appear in the 'merged' synthesized claim or in any other synthesized claim citing those sources; the dated or quantified content of those sources was left out of the combined claim
  - warning INT-LEDGER-027 ['hi-p3-s1', 'h1.5']: synthesized claim ('merged') states dated or quantified items ['1800', 'a million'] of source claims ['h1.5'] that the specialist labelled from memory (['a note of its report labels its dates and figures from memory']), without the label: the qualification was dropped, so the router reads those items as unqualified
  - error INT-LEDGER-002 ['h1.8']: material source claim is neither carried, transformed nor recorded as dropped
  - error INT-LEDGER-002 ['p1-s08']: material source claim is neither carried, transformed nor recorded as dropped
  - warning INT-SYNTH-012 ['hi-p3-s1', 'h1.4', 'h1.5']: material claim produced by 'merged' from ['h1.4', 'h1.5']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['en-p3-s1', 'p1-s02', 'p1-s04']: material claim produced by 'merged' from ['p1-s02', 'p1-s04']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['en-p3-s2', 'p1-s03']: material claim produced by 'paraphrased' from ['p1-s03']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked

## Recorded peer relays (relayed/<task>.json) compared with the current parse of the peer's raw text (the genuine pass delivers the current parse; the recording is the dependent agent's document only)

- relayed/en-p3.json (hi-p3 relayed to en-p3): DIFFERS from the current parse; the genuine pass delivered the current parse and used the recording only for the document the agent read
  - payload fields that differ: ['unresolved_issues']
  - h1.1 advisory_verification_status: recorded "self-certified in the response text" -> current null
  - h1.2 supporting_claim_ids: recorded ["h1.3", "h1.4", "h1.5", "h1.6", "h1.7", "h1.8"] -> current ["h1.3", "h1.4", "h1.5", "h1.6", "h1.7"]
  - h1.8 claim_role: recorded "evidence" -> current "link"
  - h1.8 materiality: recorded "supporting" -> current "material"
  - h1.8 proposed_claim_kind: recorded "factual" -> current "unknown"
  - h1.8 supporting_claim_ids: recorded [] -> current ["h1.2", "h1.3", "h1.4", "h1.5", "h1.6", "h1.7"]

## Mutations: findings beyond the genuine record that do not name the injection (a consequence of the injected words, such as a word bound crossed, or a wrong receipt: read the message)

- en-t7.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q02', 'p4-s02']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 304 words; bound max_words 300; solver COUNTEREXAMPLE (genuine record: measured 287 words; bound max_words 300; solver ENTAILED; the mutation added 17 words)
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence (genuine record: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence)
- en-t7.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q02', 'p4-s02']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 304 words; bound max_words 300; solver COUNTEREXAMPLE (genuine record: measured 287 words; bound max_words 300; solver ENTAILED; the mutation added 17 words)
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence (genuine record: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence)
- en-t7.json [altered_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['p2-point', 'p2-q01']
  - lost from the genuine record: warning INT-GLOSSARY-005 ['p2-point', 'p4-point']: symbol 'seem_word' (Bool) is glossed with different meanings across claims: "the poem uses the verb 'seem'" in 'p2-point' vs "the qualifier 'seem' is in the poem" in 'p4-point' (only the first states ['use', 'verb']; only the second states ['qualifier']); the consistency check reads them as differen
- en-t7.json [chronology_error] ACCEPTED_WITH_FINDINGS: injected claims ['p4-s02']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 303 words; bound max_words 300; solver COUNTEREXAMPLE (genuine record: measured 287 words; bound max_words 300; solver ENTAILED; the mutation added 16 words)
- en-t8.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q02', 'p4-s03']
  - error INT-REQ-005 []: constraint c2 not satisfied: measured 282 words; bound max_words 275; solver COUNTEREXAMPLE (genuine record: measured 265 words; bound max_words 275; solver ENTAILED; the mutation added 17 words)
  - lost from the genuine record: warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
- en-t8.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q02', 'p4-s03']
  - error INT-REQ-005 []: constraint c2 not satisfied: measured 282 words; bound max_words 275; solver COUNTEREXAMPLE (genuine record: measured 265 words; bound max_words 275; solver ENTAILED; the mutation added 17 words)
  - lost from the genuine record: warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
- en-t8.json [wrong_arithmetic] ACCEPTED_WITH_FINDINGS: injected claims ['p4-s03']
  - error INT-REQ-005 []: constraint c2 not satisfied: measured 278 words; bound max_words 275; solver COUNTEREXAMPLE (genuine record: measured 265 words; bound max_words 275; solver ENTAILED; the mutation added 13 words)
- en-t8.json [chronology_error] ACCEPTED_WITH_FINDINGS: injected claims ['p4-s03']
  - error INT-REQ-005 []: constraint c2 not satisfied: measured 281 words; bound max_words 275; solver COUNTEREXAMPLE (genuine record: measured 265 words; bound max_words 275; solver ENTAILED; the mutation added 16 words)
- hi-t7.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['h2.2']
  - warning INT-REQ-005 []: constraint c3 not satisfied: measured 2 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several) (genuine record: measured 1 paragraphs; bound max_paragraphs 1; solver ENTAILED; the mutation added 17 words)
- hi-t7.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['h2.2']
  - warning INT-REQ-005 []: constraint c3 not satisfied: measured 2 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several) (genuine record: measured 1 paragraphs; bound max_paragraphs 1; solver ENTAILED; the mutation added 17 words)
- hi-t7.json [wrong_arithmetic] ACCEPTED_WITH_FINDINGS: injected claims ['h2.2']
  - warning INT-REQ-005 []: constraint c3 not satisfied: measured 2 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several) (genuine record: measured 1 paragraphs; bound max_paragraphs 1; solver ENTAILED; the mutation added 13 words)
- hi-t7.json [chronology_error] ACCEPTED_WITH_FINDINGS: injected claims ['h2.2']
  - warning INT-REQ-005 []: constraint c3 not satisfied: measured 2 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several) (genuine record: measured 1 paragraphs; bound max_paragraphs 1; solver ENTAILED; the mutation added 16 words)
- hi-t8.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['h1.7']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 203 words (8 words of note or meta-text blocks excluded, as for paragraphs); bound max_words 200; solver COUNTEREXAMPLE (genuine record: measured 186 words (8 words of note or meta-text blocks excluded, as for paragraphs); bound max_words 200; solver ENTAILED; the mutation added 17 words)
- hi-t8.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['h1.7']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 203 words (8 words of note or meta-text blocks excluded, as for paragraphs); bound max_words 200; solver COUNTEREXAMPLE (genuine record: measured 186 words (8 words of note or meta-text blocks excluded, as for paragraphs); bound max_words 200; solver ENTAILED; the mutation added 17 words)
- hi-t8.json [chronology_error] ACCEPTED_WITH_FINDINGS: injected claims ['h1.7']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 202 words (8 words of note or meta-text blocks excluded, as for paragraphs); bound max_words 200; solver COUNTEREXAMPLE (genuine record: measured 186 words (8 words of note or meta-text blocks excluded, as for paragraphs); bound max_words 200; solver ENTAILED; the mutation added 16 words)
- en-p3.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['p1-q16', 'p1-s10']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 304 words; bound max_words 300; solver COUNTEREXAMPLE (genuine record: measured 287 words; bound max_words 300; solver ENTAILED; the mutation added 17 words)
- en-p3.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['p1-q16', 'p1-s10']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 304 words; bound max_words 300; solver COUNTEREXAMPLE (genuine record: measured 287 words; bound max_words 300; solver ENTAILED; the mutation added 17 words)
- en-p3.json [chronology_error] ACCEPTED_WITH_FINDINGS: injected claims ['p1-s10']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 303 words; bound max_words 300; solver COUNTEREXAMPLE (genuine record: measured 287 words; bound max_words 300; solver ENTAILED; the mutation added 16 words)

## Failures

(none)