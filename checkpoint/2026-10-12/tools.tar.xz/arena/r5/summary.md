# Arena r5

Transmissions: 46; functional: 46 (100.0%)

Genuine transmissions, peer relays and combinator syntheses: 12. With an error-level finding: 2 (hi-p4.json [genuine]: INT-REQ-003 ['h1.7']; hi-p4.json [synthesis syn-p4]: INT-LEDGER-002 ['p1-s08']), of which 2 counted functional. With warning-level findings only: 5, of which 5 counted functional. The rate does not judge whether a finding is true: a false error on a correct statement is counted functional like a true one, so read every finding in the genuine section below.

| variant | functional | total |
| --- | --- | --- |
| genuine | 6 | 6 |
| synthesis | 5 | 5 |
| peer_relay | 1 | 1 |
| invented_quotation | 6 | 6 |
| invented_quotation_single | 6 | 6 |
| altered_quotation | 4 | 4 |
| self_certification | 6 | 6 |
| wrong_arithmetic | 6 | 6 |
| chronology_error | 6 | 6 |

## Translation outcomes (provider-dependent; genuine pass, one outcome per eligible claim with a fixture)

- AMBIGUOUS_TRANSLATION: 8 (8 distinct claims)
- ENTAILED: 6 (6 distinct claims)
- INVALID_FORMALIZATION: 3 (3 distinct claims)
- NOT_ELIGIBLE: 3 (3 distinct claims)
- ENTAILED verdicts resting only on ungrounded premises: 3 of 6: hi-t10.json h1.3, hi-t9.json h1.6, hi-t9.json h1.9
- encodings given no verdict on genuine claims (displayed INVALID_FORMALIZATION: a definitive engine status withheld, or the encoding rejected at translation): 3; E108 vacuous result: 0; E110 unasserted figure: 0; E111 unencoded reason: 0; E112 circular encoding: 3 (hi-t10.json h1.2 (rejected at translation), hi-t10.json h1.4 (rejected at translation), hi-t9.json h1.2 (rejected at translation)); stated precision: 0
- definitive verdicts other than ENTAILED displayed on genuine claims (each is shown to the router as the engine's verdict on the claim's encoding: COUNTEREXAMPLE, the claim does not follow from its premises; INCONSISTENT_PREMISES, its premises conflict): 0
- all variants together (the same claims repeated): {'AMBIGUOUS_TRANSLATION': 50, 'ENTAILED': 39, 'INVALID_FORMALIZATION': 18, 'NOT_ELIGIBLE': 20}

## Genuine transmissions, peer relays and combinator syntheses carrying error- or warning-level findings (correct against a specialist's or the combinator's fault, or a false finding: read the message)

- en-t10.json [synthesis syn-en-t10] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-SYNTH-012']
  - warning INT-SYNTH-012 ['s1', 'p1-s02', 'p1-q01', 'p1-q02', 'p1-s03', 'p1-q03', 'p1-q04', 'p1-s04', 'p1-q05']: material claim produced by 'merged' from ['p1-s02', 'p1-q01', 'p1-q02', 'p1-s03', 'p1-q03', 'p1-q04', 'p1-s04', 'p1-q05']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'p1-s05', 'p1-q06', 'p1-s06', 'p1-q07', 'p1-s07', 'p1-q08', 'p1-q09', 'p1-q10']: material claim produced by 'merged' from ['p1-s05', 'p1-q06', 'p1-s06', 'p1-q07', 'p1-s07', 'p1-q08', 'p1-q09', 'p1-q10']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s3', 'p1-s08', 'p1-q11', 'p1-s09', 'p1-q12', 'p1-s10']: material claim produced by 'merged' from ['p1-s08', 'p1-q11', 'p1-s09', 'p1-q12', 'p1-s10']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- en-t9.json [synthesis syn-en-t9] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-SYNTH-012']
  - warning INT-SYNTH-012 ['s1', 'p1-q01', 'p1-s02', 'p1-s03', 'p1-q02', 'p1-s04']: material claim produced by 'paraphrased' from ['p1-q01', 'p1-s02', 'p1-s03', 'p1-q02', 'p1-s04']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'p1-q03', 'p1-q04', 'p1-s05', 'p1-q05', 'p1-s06']: material claim produced by 'merged' from ['p1-q03', 'p1-q04', 'p1-s05', 'p1-q05', 'p1-s06']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s3', 'p1-q06', 'p1-q07', 'p1-q08', 'p1-q09', 'p1-s09', 'p1-q10', 'p1-q11', 'p1-q12', 'p1-s10', 'p1-q13', 'p1-s11', 'p1-s12']: material claim produced by 'merged' from ['p1-q06', 'p1-q07', 'p1-q08', 'p1-q09', 'p1-s09', 'p1-q10', 'p1-q11', 'p1-q12', 'p1-s10', 'p1-q13', 'p1-s11', 'p1-s12']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- hi-t10.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['CORE-QNT-001']
  - warning CORE-QNT-001 ['h1.5']: paragraph 1, sentence 5 states a derived figure or a relation over dated figures ('more than any other decade') that could not be checked: no other decade of the period has figures at both its ends in the paragraph's dated series (the 1830s, the 1850s, the 1860s are not stated decade by decade); the stated arithmetic was not checked
- hi-t10.json [synthesis syn-hi-t10] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-LEDGER-024', 'INT-LEDGER-027', 'INT-SYNTH-012']
  - warning INT-LEDGER-024 ['s1', 'h1.4', 'h1.5']: figures or dates ['1848'] of the cited sources ['h1.4', 'h1.5'] do not appear in the 'merged' synthesized claim or in any other synthesized claim citing those sources; the dated or quantified content of those sources was left out of the combined claim
  - warning INT-LEDGER-027 ['s1', 'h1.4']: synthesized claim ('merged') states dated or quantified items ['1500', '1840', '1850', '6000'] of source claims ['h1.4'] that the specialist labelled from memory (["'from memory; check your notes'"]), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-SYNTH-012 ['s0', 'h1.1', 'h1.2', 'h1.3']: material claim produced by 'merged' from ['h1.1', 'h1.2', 'h1.3']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s1', 'h1.4', 'h1.5']: material claim produced by 'merged' from ['h1.4', 'h1.5']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s3', 'h1.1', 'h1.7', 'h1.8']: material claim produced by 'merged' from ['h1.1', 'h1.7', 'h1.8']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- hi-t9.json [synthesis syn-hi-t9] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-LEDGER-010', 'INT-LEDGER-027', 'INT-SYNTH-012']
  - warning INT-LEDGER-027 ['s0', 'h1.8']: synthesized claim ('merged') states dated or quantified items ['1941'] of source claims ['h1.8'] that the specialist labelled from memory (['a note of its report labels its dates and figures from memory']), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-LEDGER-027 ['s1', 'h1.2', 'h1.3']: synthesized claim ('merged') states dated or quantified items ['10', '35', '64', '3.3', '4.3', '5.9', '6.2', '1928', '1932'] of source claims ['h1.2', 'h1.3'] that the specialist labelled from memory (['a note of its report labels its dates and figures from memory']), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-LEDGER-027 ['s2', 'h1.5', 'h1.6']: synthesized claim ('merged') states dated or quantified items ['22', '128', '1932', '1933', '1937', '1941', 'june 1941'] of source claims ['h1.5', 'h1.6'] that the specialist labelled from memory (['a note of its report labels its dates and figures from memory']), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-LEDGER-010 ['s3', 'h1.7']: claim marked 'carried' but its text differs from the source; record it as 'paraphrased' or a new linked claim
  - warning INT-SYNTH-012 ['s0', 'h1.1', 'h1.8', 'h1.9']: material claim produced by 'merged' from ['h1.1', 'h1.8', 'h1.9']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s1', 'h1.2', 'h1.3']: material claim produced by 'merged' from ['h1.2', 'h1.3']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'h1.4', 'h1.5', 'h1.6']: material claim produced by 'merged' from ['h1.4', 'h1.5', 'h1.6']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- hi-p4.json [genuine] ACCEPTED_WITH_FINDINGS: errors ['INT-REQ-003'], warnings []
  - error INT-REQ-003 ['h1.7']: quotation 'quaint and curious war' of claim h1.7, which the report credits to no text, was not found in the supplied texts ['peer:en-p4']: the request holds all of its words but 'quaint', 'curious' (an altered quotation)
- hi-p4.json [synthesis syn-p4] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-002'], warnings ['INT-LEDGER-010', 'INT-LEDGER-024', 'INT-LEDGER-027', 'INT-SYNTH-012'] (cites a report whose recorded relay ['relayed/hi-p4.json'] differs from the current parse: see the recorded peer relays below)
  - warning INT-LEDGER-027 ['hi-p4-s0', 'h1.3']: synthesized claim ('carried') states dated or quantified items ['11', '31', '1899', '1902', 'may 1902', 'october 1899'] of source claims ['h1.3'] that the specialist labelled from memory (["'from memory; check your notes'"]), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-LEDGER-010 ['hi-p4-s0', 'h1.3']: claim marked 'carried' but its text differs from the source; record it as 'paraphrased' or a new linked claim
  - warning INT-LEDGER-024 ['hi-p4-s1', 'h1.4', 'h1.5']: figures or dates ['1900'] of the cited sources ['h1.4', 'h1.5'] do not appear in the 'merged' synthesized claim or in any other synthesized claim citing those sources; the dated or quantified content of those sources was left out of the combined claim
  - warning INT-LEDGER-027 ['hi-p4-s1', 'h1.4']: synthesized claim ('merged') states dated or quantified items ['11', '1899', 'december 1899'] of source claims ['h1.4'] that the specialist labelled from memory (["'from memory'"]), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-LEDGER-027 ['hi-p4-s3', 'h1.6']: synthesized claim ('merged') states dated or quantified items ['22000'] of source claims ['h1.6'] that the specialist labelled from memory (["'from memory; approximate, and sources differ'"]), without the label: the qualification was dropped, so the router reads those items as unqualified
  - error INT-LEDGER-002 ['p1-s08']: material source claim is neither carried, transformed nor recorded as dropped
  - warning INT-SYNTH-012 ['en-p4-s1', 'p1-s03', 'p1-q02', 'p1-q03', 'p1-q04', 'p1-q05']: material claim produced by 'paraphrased' from ['p1-s03', 'p1-q02', 'p1-q03', 'p1-q04', 'p1-q05']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['en-p4-s2', 'p1-s04', 'p1-q06', 'p1-q07', 'p1-s05', 'p1-q08']: material claim produced by 'merged' from ['p1-s04', 'p1-q06', 'p1-q07', 'p1-s05', 'p1-q08']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['en-p4-s3', 'p1-s06', 'p1-q09', 'p1-s07', 'p1-q10']: material claim produced by 'merged' from ['p1-s06', 'p1-q09', 'p1-s07', 'p1-q10']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['hi-p4-s1', 'h1.4', 'h1.5']: material claim produced by 'merged' from ['h1.4', 'h1.5']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['hi-p4-s2', 'h1.1']: material claim produced by 'paraphrased' from ['h1.1']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['hi-p4-s3', 'h1.6', 'h1.7']: material claim produced by 'merged' from ['h1.6', 'h1.7']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked

## Recorded peer relays (relayed/<task>.json) compared with the current parse of the peer's raw text (the genuine pass delivers the current parse; the recording is the dependent agent's document only)

- relayed/hi-p4.json (en-p4 relayed to hi-p4): DIFFERS from the current parse; the genuine pass delivered the current parse and used the recording only for the document the agent read
  - claims only in the current parse: ['p1-s08']
  - the shared claims come in another order
  - p1-point supporting_claim_ids: recorded ["p1-q01", "p1-s02", "p1-q02", "p1-q03", "p1-q04", "p1-q05", "p1-s03", "p1-q06", "p1-q07", "p1-s04", "p1-q08", "p1-s05", "p1-q09", "p1-s06", "p1-q10", "p1-s07"] -> current ["p1-q01", "p1-s02", "p1-q02", "p1-q03", "p1-s03", "p1-q04", "p1-q05", "p1-s04", "p1-q06", "p1-q07", "p1-s05", "p1-q08", "p1-s06", "p1-q09", "p1-s07", "p1-q10"]
  - p1-s03 claim_text: recorded "The clipped \"'list\" makes enlisting sound impulsive, while \"just as I\" implies that the speaker's own reason matches the enemy's. The key word \"traps\", which conventionally denotes snares but in colloquial use means a man's gear and belongings, suggests a man who has sold his belongings for want of work, so poverty becomes the motive, as the closing \"No other reason why\" confirms." -> current "The clipped \"'list\" makes enlisting sound impulsive, while \"just as I\" implies that the speaker's own reason matches the enemy's."
  - p1-s03 supporting_claim_ids: recorded ["p1-q02", "p1-q03", "p1-q04", "p1-q05"] -> current ["p1-q02", "p1-q03"]
  - p1-s04 claim_text: recorded "The view of the enemy is built through the repetition of \"foe\": \"I shot him dead because— / Because he was my foe, / Just so: my foe of course he was\"." -> current "The key word \"traps\", which conventionally denotes snares but in colloquial use means a man's gear and belongings, suggests a man who has sold his belongings for want of work, so poverty becomes the motive, as the closing \"No other reason why\" confirms."
  - p1-s04 supporting_claim_ids: recorded ["p1-q06", "p1-q07"] -> current ["p1-q04", "p1-q05"]
  - p1-s05 claim_text: recorded "Foe should supply a reason for killing, but it only restates the killing, so the justification becomes circular, and the unfinished \"although\" that ends the stanza shows a speaker who does not complete his argument." -> current "The view of the enemy is built through the repetition of \"foe\": \"I shot him dead because— / Because he was my foe, / Just so: my foe of course he was\"."
  - p1-s05 supporting_claim_ids: recorded ["p1-q08"] -> current ["p1-q06", "p1-q07"]
  - p1-s06 claim_text: recorded "The opening conditional, \"Had he and I but met\", imagines the man as a drinking companion, which suggests the speaker sees the enemy as a man like himself." -> current "Foe should supply a reason for killing, but it only restates the killing, so the justification becomes circular, and the unfinished \"although\" that ends the stanza shows a speaker who does not complete his argument."
  - p1-s06 supporting_claim_ids: recorded ["p1-q09"] -> current ["p1-q08"]
  - p1-s07 claim_text: recorded "The final stanza sets the killing beside a social courtesy, \"You shoot a fellow down / You'd treat if met where any bar is\", so the colloquial voice comfortably holds a contradiction." -> current "The opening conditional, \"Had he and I but met\", imagines the man as a drinking companion, which suggests the speaker sees the enemy as a man like himself."
  - p1-s07 supporting_claim_ids: recorded ["p1-q10"] -> current ["p1-q09"]

## Mutations: findings beyond the genuine record that do not name the injection (a consequence of the injected words, such as a word bound crossed, or a wrong receipt: read the message)

- en-p4.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['p1-q11', 'p1-s09']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 261 words; bound max_words 250; solver COUNTEREXAMPLE (genuine record: measured 244 words; bound max_words 250; solver ENTAILED; the mutation added 17 words)
- en-p4.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['p1-q11', 'p1-s09']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 261 words; bound max_words 250; solver COUNTEREXAMPLE (genuine record: measured 244 words; bound max_words 250; solver ENTAILED; the mutation added 17 words)
- en-p4.json [wrong_arithmetic] ACCEPTED_WITH_FINDINGS: injected claims ['p1-s09']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 257 words; bound max_words 250; solver COUNTEREXAMPLE (genuine record: measured 244 words; bound max_words 250; solver ENTAILED; the mutation added 13 words)
- en-p4.json [chronology_error] ACCEPTED_WITH_FINDINGS: injected claims ['p1-s09']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 260 words; bound max_words 250; solver COUNTEREXAMPLE (genuine record: measured 244 words; bound max_words 250; solver ENTAILED; the mutation added 16 words)

## Failures

(none)