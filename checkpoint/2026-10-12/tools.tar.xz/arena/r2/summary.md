# Arena r2 (QUALIFIED: 2 of 24 recorded translations not served; 22 served by claim id only)

Transmissions: 46; functional: 46 (100.0%). This is the transport measure only: fixture coverage, translation fidelity and the claim counts are separate measures (below), never combined with it into one rate.

Genuine transmissions, peer relays and combinator syntheses: 12. With an error-level finding: 2 (hi-t4.json [synthesis syn-hi-t4]: INT-LEDGER-003 ['s2', 'h1.3'], INT-LEDGER-003 ['s3', 'h1.4']; en-p1.json [synthesis syn-p1]: INT-LEDGER-003 ['hi-p1-s0', 'h1.1'], INT-LEDGER-002 ['p1-s08']), of which 2 counted functional. With warning-level findings only: 7, of which 7 counted functional. The rate does not judge whether a finding is true: a false error on a correct statement is counted functional like a true one, so read every finding in the genuine section below.

## Measures (each on its own denominator; none is combined with another into one rate)

- Transport (functional transmissions): 46 of 46 (100.0%). Genuine traffic delivered and decided: 12 of 12 (genuine replies 6, peer relays 1, syntheses 5); injected faults named: 34 of 34 mutation records. Transport says the hub delivered and decided every transmission; it does not judge whether a finding is true, whether a translation is faithful or whether an answer is better.
- Fixture coverage (recorded translations served in this run): 22 of 24 served; NOT SERVED: 2 (2 claim not eligible under the current policy). Of the 22 served, 0 were bound to a recorded claim-text digest and 22 by claim id only.
- Translation fidelity (faithful translations where adjudicated): not adjudicated; the round has no adjudications/translation_fidelity.json, so no fidelity figure applies to this run.
- Claims (genuine pass, each delivered claim once): extracted 120; eligible for translation 36; attempted 22; completed (a definitive verdict displayed) 2; faithful: not adjudicated; approved (displayed ENTAILED with no error-level finding on the claim; not a release decision) 2, of which 2 rest on at least one ungrounded premise and 2 on at least one unresolved dependency (ungrounded, or authority no check validated); release permitted by the release assessment (the application's rule, apart from the formal status) 0. Eligible claims with no translation attempted: 14.
- Latency (hub processing per transmission in this run, on this machine; not a stress measurement): genuine traffic median 209 ms, 95th percentile 362 ms, max 362 ms over 11; injected faults median 310 ms, 95th percentile 608 ms, max 646 ms over 34.
- Cost: no translation provider was called (recorded fixtures only).
- Replay configuration (what a recording cannot run as production does is named, never counted as run): the task record of each request is passed to the translator, as production passes it (22 of 22 genuine translations validated against it); 0 served translations bound to a recorded claim-text digest, 22 by claim id only; retries NOT exercised (a recorded translation is one output, so a retry is served the same output and the outcome is the first attempt's) on 3 genuine claim(s): hi-p1.json h1.1, hi-t3.json h1.2, hi-t4.json h1.4 (19 over every variant); syntheses stamped at relay time.
- QUALIFIED (TRANSLATIONS_LOST): 2 of 24 recorded translations were not served in this run (2 claim not eligible under the current policy); translation outcomes cover the 22 served, so this run is not a translation regression over the recorded round.
- QUALIFIED (FIXTURES_UNBOUND): 22 of the 22 served translations carry no recorded claim-text digest: each is bound to the text its claim id carries in this run, which may not be the sentence it was produced for (record the digests with the translations when they are recorded: scripts/arena/bind_translations.py).

| variant | functional | total |
| --- | --- | --- |
| genuine | 6 | 6 |
| synthesis | 5 | 5 |
| peer_relay | 1 | 1 |
| invented_quotation | 6 | 6 |
| invented_quotation_single | 6 | 6 |
| altered_quotation | 4 | 4 |
| self_certification | 6 | 6 |
| wrong_arithmetic | 6 | 6 |
| chronology_error | 6 | 6 |

## Translation outcomes (provider-dependent; genuine pass, one outcome per eligible claim with a fixture)

- AMBIGUOUS_TRANSLATION: 17 (17 distinct claims)
- ENTAILED: 2 (2 distinct claims)
- INVALID_FORMALIZATION: 3 (3 distinct claims)
- NOT_ELIGIBLE: 2 (2 distinct claims)
- ENTAILED verdicts resting only on ungrounded premises: 0 of 2
- encodings given no verdict on genuine claims (displayed INVALID_FORMALIZATION: a definitive engine status withheld, or the encoding rejected at translation): 3; E108 vacuous result: 0; E110 unasserted figure: 0; E111 unencoded reason: 0; E112 circular encoding: 3 (hi-p1.json h1.1 (rejected at translation), hi-t3.json h1.2 (rejected at translation), hi-t4.json h1.4 (rejected at translation)); stated precision: 0; exactness: 0
- advisory coverage warnings on genuine claims (the verdict on the encoding stands; the encoding leaves a figure or symbol open that no source asserts; a coverage measure, not a verdict): 0; W110 unasserted figure, advisory: 0; W111 unconstrained symbol, advisory: 0
- definitive verdicts other than ENTAILED displayed on genuine claims (each is shown to the router as the engine's verdict on the claim's encoding: COUNTEREXAMPLE, the claim does not follow from its premises; INCONSISTENT_PREMISES, its premises conflict): 0
- all variants together (the same claims repeated): {'AMBIGUOUS_TRANSLATION': 112, 'ENTAILED': 13, 'INVALID_FORMALIZATION': 19, 'NOT_ELIGIBLE': 14, 'STALE_FIXTURE_REFUSED': 3}

## Genuine transmissions, peer relays and combinator syntheses carrying error- or warning-level findings (correct against a specialist's or the combinator's fault, or a false finding: read the message)

- en-t3.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-REQ-005', 'INT-REQ-006']
  - warning INT-REQ-005 []: constraint c3 not satisfied: measured 4 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several)
  - warning INT-REQ-006 ['p2-point']: claim p2-point's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['p4-point']: claim p4-point's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['p1-s01']: claim p1-s01's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
- en-t4.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-REQ-005', 'INT-REQ-006']
  - warning INT-REQ-005 []: constraint c4 not satisfied: measured 4 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several)
  - warning INT-REQ-006 ['p3-point']: claim p3-point's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['p4-point']: claim p4-point's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['p1-s01']: claim p1-s01's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
- hi-p1.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-REQ-006']
  - warning INT-REQ-006 ['h1.1']: claim h1.1's verification gave no verdict: its outcome is displayed INVALID_FORMALIZATION (translation INVALID_FORMALIZATION; no engine result was produced), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.3']: claim h1.3's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.5']: claim h1.5's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
- hi-t3.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['CORE-SRC-003', 'INT-REQ-006']
  - warning INT-REQ-006 ['h1.1']: claim h1.1's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.2']: claim h1.2's verification gave no verdict: its outcome is displayed INVALID_FORMALIZATION (translation INVALID_FORMALIZATION; no engine result was produced), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.4']: claim h1.4's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.5']: claim h1.5's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.6']: claim h1.6's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning CORE-SRC-003 ['h1.6']: 1 quotation(s) cannot be verified: no text was supplied and the from-memory label concerns dates and figures, not quotations: 'three years of natural disasters'
- hi-t3.json [synthesis syn-hi-t3] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-LEDGER-027', 'INT-SYNTH-012']
  - warning INT-LEDGER-027 ['s2', 'h1.4', 'h1.8']: synthesized claim ('merged') states dated or quantified items ['200', '375', '1958', '1959', 'august 1959'] of source claims ['h1.4', 'h1.8'] that the specialist labelled from memory (['a note of its report labels its dates and figures from memory']), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-LEDGER-027 ['s3', 'h1.6']: synthesized claim ('carried') states dated or quantified items ['1959', '1960', '1961', '1960s', 'july 1960'] of source claims ['h1.6'] that the specialist labelled from memory (['a note of its report labels its dates and figures from memory']), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-SYNTH-012 ['s2', 'h1.4', 'h1.8']: material claim produced by 'merged' from ['h1.4', 'h1.8']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- hi-t4.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['CORE-QNT-001', 'INT-REQ-006']
  - warning INT-REQ-006 ['h1.1']: claim h1.1's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.3']: claim h1.3's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.4']: claim h1.4's verification gave no verdict: its outcome is displayed INVALID_FORMALIZATION (translation INVALID_FORMALIZATION; no engine result was produced), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.5']: claim h1.5's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning CORE-QNT-001 ['h1.3']: paragraph 1, sentence 3 states a derived figure or a relation over dated figures ('a third') that could not be checked: its sentence states no pair of figures it can be read against (only 9,000 banks failed) and the paragraph states no dated series with figures for 1930 and 1933; the stated arithmetic was not checked
  - warning CORE-QNT-001 ['h1.4']: paragraph 1, sentence 4 states a derived figure or a relation over dated figures ('a quarter') that could not be checked: its sentence states no pair of figures it can be read against (only 25 per cent in 1933) and the paragraph's dated figures state no year before 1933; the stated arithmetic was not checked
- hi-t4.json [synthesis syn-hi-t4] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-003'], warnings ['INT-SYNTH-012']
  - error INT-LEDGER-003 ['s2', 'h1.3']: certainty inflated: synthesis says 'established' but the weakest source is rank 2 (['probable'])
  - error INT-LEDGER-003 ['s3', 'h1.4']: certainty inflated: synthesis says 'established' but the weakest source is rank 2 (['probable'])
  - warning INT-SYNTH-012 ['s1', 'h1.6', 'h1.7']: material claim produced by 'merged' from ['h1.6', 'h1.7']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- en-p1.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-REQ-006']
  - warning INT-REQ-006 ['p1-point']: claim p1-point's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['p1-s10']: claim p1-s10's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
- en-p1.json [synthesis syn-p1] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-002', 'INT-LEDGER-003'], warnings [] (cites a report whose recorded relay ['relayed/en-p1.json'] differs from the current parse: see the recorded peer relays below)
  - error INT-LEDGER-003 ['hi-p1-s0', 'h1.1']: certainty inflated: synthesis says 'established' but the weakest source is rank 2 (['probable'])
  - error INT-LEDGER-002 ['p1-s08']: material source claim is neither carried, transformed nor recorded as dropped

## Recorded peer relays (relayed/<task>.json) compared with the current parse of the peer's raw text (the genuine pass delivers the current parse; the recording is the dependent agent's document only)

- relayed/en-p1.json (hi-p1 relayed to en-p1): DIFFERS from the current parse; the genuine pass delivered the current parse and used the recording only for the document the agent read
  - the recorded file also carries router-only fields the dependent agent could read beyond its peer's report: ['peer_receipt', 'plan', 'relay', 'request'] (relay_peer.py now writes them to router/<task>.json)
  - h1.1 supporting_claim_ids: recorded ["h1.2", "h1.3", "h1.4", "h1.5", "h1.6"] -> current ["h1.2", "h1.3", "h1.4", "h1.5"]
  - h1.2 assumptions: recorded ["the sentence carries the method's own label inline ('dates other than the poem's own are from memory, so check your notes.'); the label is kept out of the claim's role and its dated items are from memory"] -> current ["the sentence carries the method's own label inline ('dates other than the poem's own are from memory, so check your notes'); the label is kept out of the claim's role and its dated items are from memory"]
  - h1.2 certainty: recorded "established" -> current "probable"

## Mutations: findings beyond the genuine record that do not name the injection (a consequence of the injected words, such as a word bound crossed, or a wrong receipt: read the message)

- en-t3.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q07', 'p4-s05']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 306 words; bound max_words 300; solver COUNTEREXAMPLE (genuine record: measured 289 words; bound max_words 300; solver ENTAILED; the mutation added 17 words)
- en-t3.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q07', 'p4-s05']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 306 words; bound max_words 300; solver COUNTEREXAMPLE (genuine record: measured 289 words; bound max_words 300; solver ENTAILED; the mutation added 17 words)
- en-t3.json [wrong_arithmetic] ACCEPTED_WITH_FINDINGS: injected claims ['p4-s05']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 302 words; bound max_words 300; solver COUNTEREXAMPLE (genuine record: measured 289 words; bound max_words 300; solver ENTAILED; the mutation added 13 words)
- en-t3.json [chronology_error] ACCEPTED_WITH_FINDINGS: injected claims ['p4-s05']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 305 words; bound max_words 300; solver COUNTEREXAMPLE (genuine record: measured 289 words; bound max_words 300; solver ENTAILED; the mutation added 16 words)
- en-t4.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q05', 'p4-s04']
  - warning INT-REQ-005 []: constraint c2 not satisfied: measured 288 words; bound max_words 275; solver COUNTEREXAMPLE (the request states a band around a target length, and the measure lies within a quarter of the target, so it is a warning) (genuine record: measured 271 words; bound max_words 275; solver ENTAILED; the mutation added 17 words)
- en-t4.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q05', 'p4-s04']
  - warning INT-REQ-005 []: constraint c2 not satisfied: measured 288 words; bound max_words 275; solver COUNTEREXAMPLE (the request states a band around a target length, and the measure lies within a quarter of the target, so it is a warning) (genuine record: measured 271 words; bound max_words 275; solver ENTAILED; the mutation added 17 words)
- en-t4.json [wrong_arithmetic] ACCEPTED_WITH_FINDINGS: injected claims ['p4-s04']
  - warning INT-REQ-005 []: constraint c2 not satisfied: measured 284 words; bound max_words 275; solver COUNTEREXAMPLE (the request states a band around a target length, and the measure lies within a quarter of the target, so it is a warning) (genuine record: measured 271 words; bound max_words 275; solver ENTAILED; the mutation added 13 words)
- en-t4.json [chronology_error] ACCEPTED_WITH_FINDINGS: injected claims ['p4-s04']
  - warning INT-REQ-005 []: constraint c2 not satisfied: measured 287 words; bound max_words 275; solver COUNTEREXAMPLE (the request states a band around a target length, and the measure lies within a quarter of the target, so it is a warning) (genuine record: measured 271 words; bound max_words 275; solver ENTAILED; the mutation added 16 words)
- en-p1.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['p1-q18', 'p1-s11']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 312 words; bound max_words 300; solver COUNTEREXAMPLE (genuine record: measured 295 words; bound max_words 300; solver ENTAILED; the mutation added 17 words)
- en-p1.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['p1-q18', 'p1-s11']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 312 words; bound max_words 300; solver COUNTEREXAMPLE (genuine record: measured 295 words; bound max_words 300; solver ENTAILED; the mutation added 17 words)
- en-p1.json [wrong_arithmetic] ACCEPTED_WITH_FINDINGS: injected claims ['p1-s11']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 308 words; bound max_words 300; solver COUNTEREXAMPLE (genuine record: measured 295 words; bound max_words 300; solver ENTAILED; the mutation added 13 words)
- en-p1.json [chronology_error] ACCEPTED_WITH_FINDINGS: injected claims ['p1-s11']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 311 words; bound max_words 300; solver COUNTEREXAMPLE (genuine record: measured 295 words; bound max_words 300; solver ENTAILED; the mutation added 16 words)

## Delivery decisions (delivery policy delivery-v1: 240 s translation budget, overseer-selected fallback above 0.9; docs/DELIVERY.md)

Each genuine answer is replayed on a hub of its own with the transfer auditor attached and decided by the delivery policy. Overseer agents: not configured (the harness calls no model): the fallback establishes no accuracy. A separate measure: it changes no transport count. Modes: formally_checked 0, overseer_selected 0, not_checked 0, withheld 6; receipts identical to the genuine records' (status and codes): 6 of 6; the pass took 11.688 s.

| task | mode | time to decision (s) | translation (s) | overseer (s) | candidates (accuracy) | chosen | why |
| --- | --- | --- | --- | --- | --- | --- | --- |
| en-t3.json | withheld | 1.504 | 1.461 | - | english-specialist 0/4 | - | claim p2-point: unresolved (translation AMBIGUOUS_TRANSLATION; the translation carries ambiguity flags: said_reading, only_exclusivity; display status AMBIGUOUS… |
| en-t4.json | withheld | 1.378 | 1.337 | - | english-specialist 0/4 | - | claim p2-point: unresolved (release rule release-v1: ungrounded dependencies (relied on, not established by the supplied material or the task): l_super, l_rests… |
| hi-p1.json | withheld | 1.645 | 1.629 | - | history-specialist 0/2 | - | claim h1.1: unresolved (translation INVALID_FORMALIZATION; display status INVALID_FORMALIZATION: no definitive verdict; release rule release-v1: translation INV… |
| hi-t3.json | withheld | 2.554 | 2.369 | - | history-specialist 0/2 | - | claim h1.1: unresolved (translation AMBIGUOUS_TRANSLATION; the translation carries ambiguity flags: large_extent, catastrophe_link, weather_counter; display sta… |
| hi-t4.json | withheld | 2.178 | 2.142 | - | history-specialist 0/3 | - | claim h1.1: unresolved (translation AMBIGUOUS_TRANSLATION; the translation carries ambiguity flags: channel_direction, approximate_figures; display status AMBIG… |
| en-p1.json | withheld | 2.390 | 2.299 | - | english-specialist 0/3 | - | claim p1-point: unresolved (translation AMBIGUOUS_TRANSLATION; the translation carries ambiguity flags: setting_source, hedged_point; display status AMBIGUOUS_T… |

## Specialist revisions

(not run: the round has no feedback/ directory (scripts/arena/revision_feedback.py was not run))

## Failures

(none)