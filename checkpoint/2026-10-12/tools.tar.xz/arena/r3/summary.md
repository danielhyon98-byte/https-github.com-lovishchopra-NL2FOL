# Arena r3 (QUALIFIED: 3 of 27 recorded translations not served; 24 served by claim id only)

Transmissions: 46; functional: 46 (100.0%). This is the transport measure only: fixture coverage, translation fidelity and the claim counts are separate measures (below), never combined with it into one rate.

Genuine transmissions, peer relays and combinator syntheses: 12. With an error-level finding: 2 (hi-t5.json [synthesis syn-hi-t5]: INT-LEDGER-032 ['s2', 'h1.8'], INT-LEDGER-002 ['h1.10']; hi-p2.json [synthesis syn-p2]: INT-LEDGER-003 ['hi-p2-s0', 'h1.1']), of which 2 counted functional. With warning-level findings only: 9, of which 9 counted functional. The rate does not judge whether a finding is true: a false error on a correct statement is counted functional like a true one, so read every finding in the genuine section below.

## Measures (each on its own denominator; none is combined with another into one rate)

- Transport (functional transmissions): 46 of 46 (100.0%). Genuine traffic delivered and decided: 12 of 12 (genuine replies 6, peer relays 1, syntheses 5); injected faults named: 34 of 34 mutation records. Transport says the hub delivered and decided every transmission; it does not judge whether a finding is true, whether a translation is faithful or whether an answer is better.
- Fixture coverage (recorded translations served in this run): 24 of 27 served; NOT SERVED: 3 (3 claim not eligible under the current policy). Of the 24 served, 0 were bound to a recorded claim-text digest and 24 by claim id only.
- Translation fidelity (faithful translations where adjudicated): not adjudicated; the round has no adjudications/translation_fidelity.json, so no fidelity figure applies to this run.
- Claims (genuine pass, each delivered claim once): extracted 87; eligible for translation 33; attempted 24; completed (a definitive verdict displayed) 7; faithful: not adjudicated; approved (displayed ENTAILED with no error-level finding on the claim; not a release decision) 7, of which 7 rest on at least one ungrounded premise and 7 on at least one unresolved dependency (ungrounded, or authority no check validated); release permitted by the release assessment (the application's rule, apart from the formal status) 0. Eligible claims with no translation attempted: 9.
- Latency (hub processing per transmission in this run, on this machine; not a stress measurement): genuine traffic median 125 ms, 95th percentile 276 ms, max 276 ms over 11; injected faults median 180 ms, 95th percentile 289 ms, max 291 ms over 34.
- Cost: no translation provider was called (recorded fixtures only).
- Replay configuration (what a recording cannot run as production does is named, never counted as run): the task record of each request is passed to the translator, as production passes it (24 of 24 genuine translations validated against it); 0 served translations bound to a recorded claim-text digest, 24 by claim id only; retries NOT exercised (a recorded translation is one output, so a retry is served the same output and the outcome is the first attempt's) on 7 genuine claim(s): hi-t5.json h1.2, hi-t5.json h1.3, hi-t5.json h1.8, hi-t5.json h1.11, hi-p2.json h1.2, hi-p2.json h1.4, hi-p2.json h1.7 (45 over every variant); syntheses stamped at relay time.
- QUALIFIED (TRANSLATIONS_LOST): 3 of 27 recorded translations were not served in this run (3 claim not eligible under the current policy); translation outcomes cover the 24 served, so this run is not a translation regression over the recorded round.
- QUALIFIED (FIXTURES_UNBOUND): 24 of the 24 served translations carry no recorded claim-text digest: each is bound to the text its claim id carries in this run, which may not be the sentence it was produced for (record the digests with the translations when they are recorded: scripts/arena/bind_translations.py).

| variant | functional | total |
| --- | --- | --- |
| genuine | 6 | 6 |
| synthesis | 5 | 5 |
| peer_relay | 1 | 1 |
| invented_quotation | 6 | 6 |
| invented_quotation_single | 6 | 6 |
| altered_quotation | 4 | 4 |
| self_certification | 6 | 6 |
| wrong_arithmetic | 6 | 6 |
| chronology_error | 6 | 6 |

## Translation outcomes (provider-dependent; genuine pass, one outcome per eligible claim with a fixture)

- AMBIGUOUS_TRANSLATION: 10 (10 distinct claims)
- ENTAILED: 7 (7 distinct claims)
- INVALID_FORMALIZATION: 7 (7 distinct claims)
- NOT_ELIGIBLE: 3 (3 distinct claims)
- ENTAILED verdicts resting only on ungrounded premises: 5 of 7: en-t5.json p1-s01, en-t5.json p1-s02, en-t6.json p1-s01, hi-t5.json h1.7, hi-p2.json h1.3
- encodings given no verdict on genuine claims (displayed INVALID_FORMALIZATION: a definitive engine status withheld, or the encoding rejected at translation): 7; E108 vacuous result: 0; E110 unasserted figure: 0; E111 unencoded reason: 0; E112 circular encoding: 7 (hi-t5.json h1.2 (rejected at translation), hi-t5.json h1.3 (rejected at translation), hi-t5.json h1.8 (rejected at translation), hi-t5.json h1.11 (rejected at translation), hi-p2.json h1.2 (rejected at translation), hi-p2.json h1.4 (rejected at translation), hi-p2.json h1.7 (rejected at translation)); stated precision: 0; exactness: 0
- advisory coverage warnings on genuine claims (the verdict on the encoding stands; the encoding leaves a figure or symbol open that no source asserts; a coverage measure, not a verdict): 2; W110 unasserted figure, advisory: 0; W111 unconstrained symbol, advisory: 2 (en-p2.json p1-s01 (AMBIGUOUS_TRANSLATION), en-t5.json p4-point (AMBIGUOUS_TRANSLATION))
- definitive verdicts other than ENTAILED displayed on genuine claims (each is shown to the router as the engine's verdict on the claim's encoding: COUNTEREXAMPLE, the claim does not follow from its premises; INCONSISTENT_PREMISES, its premises conflict): 0
- all variants together (the same claims repeated): {'AMBIGUOUS_TRANSLATION': 66, 'ENTAILED': 48, 'INVALID_FORMALIZATION': 45, 'NOT_ELIGIBLE': 20}

## Genuine transmissions, peer relays and combinator syntheses carrying error- or warning-level findings (correct against a specialist's or the combinator's fault, or a false finding: read the message)

- en-p2.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['ES-STR-001', 'INT-REQ-005', 'INT-REQ-006']
  - warning INT-REQ-005 []: constraint c3 not satisfied: measured 4 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several)
  - warning INT-REQ-006 ['p2-point']: claim p2-point's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned COUNTEREXAMPLE, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['p1-s01']: claim p1-s01's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned COUNTEREXAMPLE, which the outcome does not show), so the router must not read the claim as checked
  - warning ES-STR-001 ['p3-point']: body paragraph 3 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
- en-t5.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['ES-STR-001', 'INT-REQ-005', 'INT-REQ-006']
  - warning INT-REQ-005 []: constraint c3 not satisfied: measured 4 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several)
  - warning INT-REQ-006 ['p3-point']: claim p3-point's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['p4-point']: claim p4-point's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned COUNTEREXAMPLE, which the outcome does not show), so the router must not read the claim as checked
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
- en-t5.json [synthesis syn-en-t5] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-SYNTH-012']
  - warning INT-SYNTH-012 ['s0', 'p1-s01', 'p1-s02']: material claim produced by 'merged' from ['p1-s01', 'p1-s02']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s1', 'p4-point', 'p2-point', 'p2-s03', 'p2-q01', 'p2-q04']: material claim produced by 'merged' from ['p4-point', 'p2-point', 'p2-s03', 'p2-q01', 'p2-q04']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'p3-point', 'p3-s02', 'p3-s03', 'p3-s04']: material claim produced by 'merged' from ['p3-point', 'p3-s02', 'p3-s03', 'p3-s04']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- en-t6.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['ES-STR-001', 'INT-ARG-001', 'INT-REQ-005', 'INT-REQ-006']
  - warning INT-REQ-005 []: constraint c4 not satisfied: measured 4 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several)
  - warning INT-REQ-006 ['p2-point']: claim p2-point's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['p3-point']: claim p3-point's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-ARG-001 ['p1-s01']: lack_of_evidence [EVD-LACK-001]: the point rests on pr-pt-ironic, pr-pt-arr (the opening's irony works through a gap between what it states and what it means (p2-po...; marriage is presented as a social and economic arrangement shaped by power, and the iro...), which cites no source, and no check verified it in this process: nothing in the supplied texts or the task supports it
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
- en-t6.json [synthesis syn-en-t6] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-LEDGER-019', 'INT-SYNTH-012']
  - warning INT-LEDGER-019 ['p4-point']: MATERIAL source claims ['p4-point'] were dropped from the answer; recorded reason: 'Concluding restatement of the thesis in p1-s01, which the first claim carries; the claim is marked NOT_ELIGIBLE_OTHER, so it is not carried as a separate claim.'
  - warning INT-SYNTH-012 ['s1', 'p2-point', 'p2-s02', 'p2-s04', 'p2-q01', 'p2-q02', 'p2-q05']: material claim produced by 'merged' from ['p2-point', 'p2-s02', 'p2-s04', 'p2-q01', 'p2-q02', 'p2-q05']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'p3-point', 'p3-s02', 'p3-s03', 'p3-q01', 'p3-q02', 'p3-q03']: material claim produced by 'merged' from ['p3-point', 'p3-s02', 'p3-s03', 'p3-q01', 'p3-q02', 'p3-q03']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- hi-t5.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-ARG-001', 'INT-REQ-006']
  - warning INT-REQ-006 ['h1.1']: claim h1.1's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.2']: claim h1.2's verification gave no verdict: its outcome is displayed INVALID_FORMALIZATION (translation INVALID_FORMALIZATION; no engine result was produced), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.3']: claim h1.3's verification gave no verdict: its outcome is displayed INVALID_FORMALIZATION (translation INVALID_FORMALIZATION; no engine result was produced), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.8']: claim h1.8's verification gave no verdict: its outcome is displayed INVALID_FORMALIZATION (translation INVALID_FORMALIZATION; no engine result was produced), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.9']: claim h1.9's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.11']: claim h1.11's verification gave no verdict: its outcome is displayed INVALID_FORMALIZATION (translation INVALID_FORMALIZATION; no engine result was produced), so the router must not read the claim as checked
  - warning INT-ARG-001 ['h1.11']: circular_reasoning [ARG-CIRC-001]: circular: the translation was refused because its premise(s) pr-kenn restate the point and no check in this process established them (whatever their label): the point is assumed, not derived
- hi-t5.json [synthesis syn-hi-t5] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-002', 'INT-LEDGER-032'], warnings ['INT-LEDGER-027', 'INT-SYNTH-012']
  - warning INT-LEDGER-027 ['s0', 'h1.1']: synthesized claim ('merged') states dated or quantified items ['28', '1962', 'october 1962'] of source claims ['h1.1'] that the specialist labelled from memory (['a note of its report labels its dates and figures from memory']), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-LEDGER-027 ['s1', 'h1.2', 'h1.3', 'h1.4', 'h1.7']: synthesized claim ('merged') states dated or quantified items ['2', '14', '22', '24', '26', '27', '28'] of source claims ['h1.2', 'h1.3', 'h1.4', 'h1.7'] that the specialist labelled from memory (['a note of its report labels its dates and figures from memory']), without the label: the qualification was dropped, so the router reads those items as unqualified
  - error INT-LEDGER-032 ['s2', 'h1.8']: synthesized claim ('paraphrased') names an actor its cited sources ['h1.8'] do not name (rule name-substitution): it names 'Khrushchev', which none of its cited sources states, where they give the same act (next to 'chos') to 'he' (a substituted actor), whatever its formal conclusion: who acted is content the claim it cites does not state
  - warning INT-LEDGER-027 ['s2', 'h1.8']: synthesized claim ('paraphrased') states dated or quantified items ['27'] of source claims ['h1.8'] that the specialist labelled from memory (['a note of its report labels its dates and figures from memory']), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-LEDGER-027 ['s3', 'h1.9']: synthesized claim ('carried') states dated or quantified items ['1969'] of source claims ['h1.9'] that the specialist labelled from memory (['a note of its report labels its dates and figures from memory']), without the label: the qualification was dropped, so the router reads those items as unqualified
  - error INT-LEDGER-002 ['h1.10']: material source claim is neither carried, transformed nor recorded as dropped
  - warning INT-SYNTH-012 ['s0', 'h1.1', 'h1.6', 'h1.11']: material claim produced by 'merged' from ['h1.1', 'h1.6', 'h1.11']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s1', 'h1.2', 'h1.3', 'h1.4', 'h1.7']: material claim produced by 'merged' from ['h1.2', 'h1.3', 'h1.4', 'h1.7']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'h1.8']: material claim produced by 'paraphrased' from ['h1.8']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- hi-t6.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-REQ-006']
  - warning INT-REQ-006 ['h1.1']: claim h1.1's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.5']: claim h1.5's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned COUNTEREXAMPLE, which the outcome does not show), so the router must not read the claim as checked
- hi-t6.json [synthesis syn-hi-t6] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-LEDGER-027', 'INT-SYNTH-012']
  - warning INT-LEDGER-027 ['s1', 'h1.2']: synthesized claim ('paraphrased') states dated or quantified items ['4.2', '1923', '18000', 'a trillion', 'january 1923', 'november 1923'] of source claims ['h1.2'] that the specialist labelled from memory (["'from memory; check your notes'"]), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-LEDGER-027 ['s3', 'h1.4']: synthesized claim ('merged') states dated or quantified items ['800', '1924'] of source claims ['h1.4'] that the specialist labelled from memory (["'from memory'"]), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-SYNTH-012 ['s0', 'h1.1', 'h1.5']: material claim produced by 'merged' from ['h1.1', 'h1.5']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s1', 'h1.2']: material claim produced by 'paraphrased' from ['h1.2']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s3', 'h1.4', 'h1.6']: material claim produced by 'merged' from ['h1.4', 'h1.6']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- hi-p2.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-REQ-006']
  - warning INT-REQ-006 ['h1.2']: claim h1.2's verification gave no verdict: its outcome is displayed INVALID_FORMALIZATION (translation INVALID_FORMALIZATION; no engine result was produced), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.4']: claim h1.4's verification gave no verdict: its outcome is displayed INVALID_FORMALIZATION (translation INVALID_FORMALIZATION; no engine result was produced), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.7']: claim h1.7's verification gave no verdict: its outcome is displayed INVALID_FORMALIZATION (translation INVALID_FORMALIZATION; no engine result was produced), so the router must not read the claim as checked
- hi-p2.json [synthesis syn-p2] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-003'], warnings ['INT-LEDGER-019', 'INT-LEDGER-027', 'INT-SYNTH-012']
  - error INT-LEDGER-003 ['hi-p2-s0', 'h1.1']: certainty inflated: synthesis says 'established' but the weakest source is rank 2 (['probable'])
  - warning INT-LEDGER-027 ['hi-p2-s1', 'h1.2', 'h1.3']: synthesized claim ('merged') states dated or quantified items ['1555', '1600', '1793', '1799'] of source claims ['h1.2', 'h1.3'] that the specialist labelled from memory (["'from memory'"]), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-LEDGER-027 ['hi-p2-s2', 'h1.4', 'h1.5']: synthesized claim ('merged') states dated or quantified items ['1775', '1788', '1791', 'july 1791'] of source claims ['h1.4', 'h1.5'] that the specialist labelled from memory (["'both from memory'", "'from memory'"]), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-LEDGER-027 ['hi-p2-s3', 'h1.7']: synthesized claim ('merged') states dated or quantified items ['1793', '1794', 'february 1793'] of source claims ['h1.7'] that the specialist labelled from memory (["'from memory'"]), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-LEDGER-019 ['p4-point']: MATERIAL source claims ['p4-point'] were dropped from the answer; recorded reason: 'Concluding restatement of the thesis in p1-s01, which the first claim carries; the claim is marked NOT_ELIGIBLE_OTHER, so it is not carried as a separate claim.'
  - warning INT-SYNTH-012 ['en-p2-s1', 'p2-point', 'p2-s02', 'p2-q01']: material claim produced by 'merged' from ['p2-point', 'p2-s02', 'p2-q01']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['en-p2-s2', 'p3-point', 'p3-s02', 'p3-s03', 'p3-q01', 'p3-q02', 'p3-q03']: material claim produced by 'merged' from ['p3-point', 'p3-s02', 'p3-s03', 'p3-q01', 'p3-q02', 'p3-q03']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['en-p2-s3', 'p3-point', 'p3-s04', 'p3-q04']: material claim produced by 'narrowed' from ['p3-point', 'p3-s04', 'p3-q04']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['hi-p2-s1', 'h1.2', 'h1.3']: material claim produced by 'merged' from ['h1.2', 'h1.3']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['hi-p2-s2', 'h1.4', 'h1.5']: material claim produced by 'merged' from ['h1.4', 'h1.5']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['hi-p2-s3', 'h1.7', 'h1.8']: material claim produced by 'merged' from ['h1.7', 'h1.8']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked

## Recorded peer relays (relayed/<task>.json) compared with the current parse of the peer's raw text (the genuine pass delivers the current parse; the recording is the dependent agent's document only)

- relayed/hi-p2.json (en-p2 relayed to hi-p2): identical to the current parse (created_at aside)
  - the recorded file also carries router-only fields the dependent agent could read beyond its peer's report: ['peer_receipt', 'plan', 'relay', 'request'] (relay_peer.py now writes them to router/<task>.json)

## Mutations: findings beyond the genuine record that do not name the injection (a consequence of the injected words, such as a word bound crossed, or a wrong receipt: read the message)

- en-p2.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q01', 'p4-s02']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 251 words; bound max_words 250; solver COUNTEREXAMPLE (genuine record: measured 234 words; bound max_words 250; solver ENTAILED; the mutation added 17 words)
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence (genuine record: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence)
- en-p2.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q01', 'p4-s02']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 251 words; bound max_words 250; solver COUNTEREXAMPLE (genuine record: measured 234 words; bound max_words 250; solver ENTAILED; the mutation added 17 words)
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence (genuine record: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence)
- en-t5.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q04', 'p4-s03']
  - lost from the genuine record: warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
- en-t5.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q04', 'p4-s03']
  - lost from the genuine record: warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
- en-t6.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q01', 'p4-s02']
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence (genuine record: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence)
- en-t6.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q01', 'p4-s02']
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence (genuine record: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence)
- hi-t5.json [chronology_error] ACCEPTED_WITH_FINDINGS: injected claims ['h1.13']
  - warning CORE-CHR-001 ['h1.2']: paragraph 1, sentence 2 orders two dated events ('after': 26 October later than 14 October) but the relation could not be decided: neither '26 October' nor '14 October' carries a year; the paragraph states 4 different years; the stated relation was not checked

## Delivery decisions (delivery policy delivery-v1: 240 s translation budget, overseer-selected fallback above 0.9; docs/DELIVERY.md)

Each genuine answer is replayed on a hub of its own with the transfer auditor attached and decided by the delivery policy. Overseer agents: not configured (the harness calls no model): the fallback establishes no accuracy. A separate measure: it changes no transport count. Modes: formally_checked 0, overseer_selected 0, not_checked 0, withheld 6; receipts identical to the genuine records' (status and codes): 6 of 6; the pass took 8.348 s.

Overseer-selected fallback: NOT exercised in this pass: no overseer agent is configured (the harness calls no model): no accuracy was established, so neither the overseer-selected fallback above the threshold nor the below-threshold rule was exercised. Withheld by cause: no_accuracy 6.

| task | mode | time to decision (s) | translation (s) | overseer (s) | candidates (accuracy) | chosen | why |
| --- | --- | --- | --- | --- | --- | --- | --- |
| en-p2.json | withheld | 1.130 | 1.097 | - | english-specialist 0/4 | - | claim p2-point: unresolved (translation AMBIGUOUS_TRANSLATION; the translation carries ambiguity flags: come_first_reading; display status AMBIGUOUS_TRANSLATION… |
| en-t5.json | withheld | 1.734 | 1.668 | - | english-specialist 0/5 | - | claim p2-point: unresolved (release rule release-v1: ungrounded dependencies (relied on, not established by the supplied material or the task): pr-meaning, lk-r… |
| en-t6.json | withheld | 1.507 | 1.480 | - | english-specialist 0/4 | - | claim p2-point: unresolved (translation AMBIGUOUS_TRANSLATION; the translation carries ambiguity flags: gap_routes; display status AMBIGUOUS_TRANSLATION: no def… |
| hi-t5.json | withheld | 1.865 | 1.818 | - | history-specialist 0/3 | - | claim h1.1: unresolved (translation AMBIGUOUS_TRANSLATION; the translation carries ambiguity flags: to_a_large_extent, circular_support; display status AMBIGUOU… |
| hi-t6.json | withheld | 0.911 | 0.895 | - | history-specialist 0/2 | - | claim h1.1: unresolved (translation AMBIGUOUS_TRANSLATION; the translation carries ambiguity flags: mattered_undefined, exactly_two, partial_encoding; display s… |
| hi-p2.json | withheld | 1.162 | 1.148 | - | history-specialist 0/1 | - | claim h1.2: unresolved (translation INVALID_FORMALIZATION; display status INVALID_FORMALIZATION: no definitive verdict; release rule release-v1: translation INV… |

## Specialist revisions

(not run: the round has no feedback/ directory (scripts/arena/revision_feedback.py was not run))

## Failures

(none)