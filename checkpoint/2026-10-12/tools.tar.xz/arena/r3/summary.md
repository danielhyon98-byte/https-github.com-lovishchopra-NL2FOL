# Arena r3

Transmissions: 46; functional: 46 (100.0%)

Genuine transmissions, peer relays and combinator syntheses: 12. With an error-level finding: 2 (hi-t5.json [synthesis syn-hi-t5]: INT-LEDGER-002 ['h1.10']; hi-p2.json [synthesis syn-p2]: INT-LEDGER-003 ['hi-p2-s0', 'h1.1']), of which 2 counted functional. With warning-level findings only: 6, of which 6 counted functional. The rate does not judge whether a finding is true: a false error on a correct statement is counted functional like a true one, so read every finding in the genuine section below.

| variant | functional | total |
| --- | --- | --- |
| genuine | 6 | 6 |
| synthesis | 5 | 5 |
| peer_relay | 1 | 1 |
| invented_quotation | 6 | 6 |
| invented_quotation_single | 6 | 6 |
| altered_quotation | 4 | 4 |
| self_certification | 6 | 6 |
| wrong_arithmetic | 6 | 6 |
| chronology_error | 6 | 6 |

## Translation outcomes (provider-dependent; genuine pass, one outcome per eligible claim with a fixture)

- AMBIGUOUS_TRANSLATION: 11 (11 distinct claims)
- ENTAILED: 7 (7 distinct claims)
- INVALID_FORMALIZATION: 6 (6 distinct claims)
- NOT_ELIGIBLE: 3 (3 distinct claims)
- ENTAILED verdicts resting only on ungrounded premises: 4 of 7: en-t5.json p1-s01, en-t5.json p1-s02, en-t6.json p1-s01, hi-t5.json h1.7
- encodings given no verdict on genuine claims (displayed INVALID_FORMALIZATION: a definitive engine status withheld, or the encoding rejected at translation): 6; E108 vacuous result: 0; E110 unasserted figure: 0; E111 unencoded reason: 0; E112 circular encoding: 6 (hi-t5.json h1.2 (rejected at translation), hi-t5.json h1.3 (rejected at translation), hi-t5.json h1.8 (rejected at translation), hi-p2.json h1.2 (rejected at translation), hi-p2.json h1.4 (rejected at translation), hi-p2.json h1.7 (rejected at translation)); stated precision: 0
- definitive verdicts other than ENTAILED displayed on genuine claims (each is shown to the router as the engine's verdict on the claim's encoding: COUNTEREXAMPLE, the claim does not follow from its premises; INCONSISTENT_PREMISES, its premises conflict): 0
- all variants together (the same claims repeated): {'AMBIGUOUS_TRANSLATION': 72, 'ENTAILED': 48, 'INVALID_FORMALIZATION': 39, 'NOT_ELIGIBLE': 20}

## Genuine transmissions, peer relays and combinator syntheses carrying error- or warning-level findings (correct against a specialist's or the combinator's fault, or a false finding: read the message)

- en-p2.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['ES-STR-001', 'INT-REQ-005']
  - warning INT-REQ-005 []: constraint c3 not satisfied: measured 4 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several)
  - warning ES-STR-001 ['p3-point']: body paragraph 3 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
- en-t5.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['ES-STR-001', 'INT-REQ-005']
  - warning INT-REQ-005 []: constraint c3 not satisfied: measured 4 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several)
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
- en-t5.json [synthesis syn-en-t5] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-SYNTH-012']
  - warning INT-SYNTH-012 ['s0', 'p1-s01', 'p1-s02']: material claim produced by 'merged' from ['p1-s01', 'p1-s02']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s1', 'p4-point', 'p2-point', 'p2-s03', 'p2-q01', 'p2-q04']: material claim produced by 'merged' from ['p4-point', 'p2-point', 'p2-s03', 'p2-q01', 'p2-q04']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'p3-point', 'p3-s02', 'p3-s03', 'p3-s04']: material claim produced by 'merged' from ['p3-point', 'p3-s02', 'p3-s03', 'p3-s04']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- en-t6.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['ES-STR-001', 'INT-REQ-005']
  - warning INT-REQ-005 []: constraint c4 not satisfied: measured 4 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several)
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
- en-t6.json [synthesis syn-en-t6] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-LEDGER-019', 'INT-SYNTH-012']
  - warning INT-LEDGER-019 ['p4-point']: MATERIAL source claims ['p4-point'] were dropped from the answer; recorded reason: 'Concluding restatement of the thesis in p1-s01, which the first claim carries; the claim is marked NOT_ELIGIBLE_OTHER, so it is not carried as a separate claim.'
  - warning INT-SYNTH-012 ['s1', 'p2-point', 'p2-s02', 'p2-s04', 'p2-q01', 'p2-q02', 'p2-q05']: material claim produced by 'merged' from ['p2-point', 'p2-s02', 'p2-s04', 'p2-q01', 'p2-q02', 'p2-q05']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'p3-point', 'p3-s02', 'p3-s03', 'p3-q01', 'p3-q02', 'p3-q03']: material claim produced by 'merged' from ['p3-point', 'p3-s02', 'p3-s03', 'p3-q01', 'p3-q02', 'p3-q03']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- hi-t5.json [synthesis syn-hi-t5] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-002'], warnings ['INT-LEDGER-027', 'INT-SYNTH-012']
  - warning INT-LEDGER-027 ['s0', 'h1.1']: synthesized claim ('merged') states dated or quantified items ['28', '1962', 'october 1962'] of source claims ['h1.1'] that the specialist labelled from memory (['a note of its report labels its dates and figures from memory']), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-LEDGER-027 ['s1', 'h1.2', 'h1.3', 'h1.4', 'h1.7']: synthesized claim ('merged') states dated or quantified items ['2', '14', '22', '24', '26', '27', '28'] of source claims ['h1.2', 'h1.3', 'h1.4', 'h1.7'] that the specialist labelled from memory (['a note of its report labels its dates and figures from memory']), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-LEDGER-027 ['s2', 'h1.8']: synthesized claim ('paraphrased') states dated or quantified items ['27'] of source claims ['h1.8'] that the specialist labelled from memory (['a note of its report labels its dates and figures from memory']), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-LEDGER-027 ['s3', 'h1.9']: synthesized claim ('carried') states dated or quantified items ['1969'] of source claims ['h1.9'] that the specialist labelled from memory (['a note of its report labels its dates and figures from memory']), without the label: the qualification was dropped, so the router reads those items as unqualified
  - error INT-LEDGER-002 ['h1.10']: material source claim is neither carried, transformed nor recorded as dropped
  - warning INT-SYNTH-012 ['s0', 'h1.1', 'h1.6', 'h1.11']: material claim produced by 'merged' from ['h1.1', 'h1.6', 'h1.11']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s1', 'h1.2', 'h1.3', 'h1.4', 'h1.7']: material claim produced by 'merged' from ['h1.2', 'h1.3', 'h1.4', 'h1.7']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'h1.8']: material claim produced by 'paraphrased' from ['h1.8']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- hi-t6.json [synthesis syn-hi-t6] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-LEDGER-027', 'INT-SYNTH-012']
  - warning INT-LEDGER-027 ['s1', 'h1.2']: synthesized claim ('paraphrased') states dated or quantified items ['4.2', '1923', '18000', 'a trillion', 'january 1923', 'november 1923'] of source claims ['h1.2'] that the specialist labelled from memory (["'from memory; check your notes'"]), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-LEDGER-027 ['s3', 'h1.4']: synthesized claim ('merged') states dated or quantified items ['800', '1924'] of source claims ['h1.4'] that the specialist labelled from memory (["'from memory'"]), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-SYNTH-012 ['s0', 'h1.1', 'h1.5']: material claim produced by 'merged' from ['h1.1', 'h1.5']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s1', 'h1.2']: material claim produced by 'paraphrased' from ['h1.2']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s3', 'h1.4', 'h1.6']: material claim produced by 'merged' from ['h1.4', 'h1.6']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- hi-p2.json [synthesis syn-p2] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-003'], warnings ['INT-LEDGER-019', 'INT-LEDGER-027', 'INT-SYNTH-012']
  - error INT-LEDGER-003 ['hi-p2-s0', 'h1.1']: certainty inflated: synthesis says 'established' but the weakest source is rank 2 (['probable'])
  - warning INT-LEDGER-027 ['hi-p2-s1', 'h1.2', 'h1.3']: synthesized claim ('merged') states dated or quantified items ['1555', '1600', '1793', '1799'] of source claims ['h1.2', 'h1.3'] that the specialist labelled from memory (["'from memory'"]), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-LEDGER-027 ['hi-p2-s2', 'h1.4', 'h1.5']: synthesized claim ('merged') states dated or quantified items ['1775', '1788', '1791', 'july 1791'] of source claims ['h1.4', 'h1.5'] that the specialist labelled from memory (["'both from memory'", "'from memory'"]), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-LEDGER-027 ['hi-p2-s3', 'h1.7']: synthesized claim ('merged') states dated or quantified items ['1793', '1794', 'february 1793'] of source claims ['h1.7'] that the specialist labelled from memory (["'from memory'"]), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-LEDGER-019 ['p4-point']: MATERIAL source claims ['p4-point'] were dropped from the answer; recorded reason: 'Concluding restatement of the thesis in p1-s01, which the first claim carries; the claim is marked NOT_ELIGIBLE_OTHER, so it is not carried as a separate claim.'
  - warning INT-SYNTH-012 ['en-p2-s1', 'p2-point', 'p2-s02', 'p2-q01']: material claim produced by 'merged' from ['p2-point', 'p2-s02', 'p2-q01']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['en-p2-s2', 'p3-point', 'p3-s02', 'p3-s03', 'p3-q01', 'p3-q02', 'p3-q03']: material claim produced by 'merged' from ['p3-point', 'p3-s02', 'p3-s03', 'p3-q01', 'p3-q02', 'p3-q03']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['en-p2-s3', 'p3-point', 'p3-s04', 'p3-q04']: material claim produced by 'narrowed' from ['p3-point', 'p3-s04', 'p3-q04']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['hi-p2-s1', 'h1.2', 'h1.3']: material claim produced by 'merged' from ['h1.2', 'h1.3']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['hi-p2-s2', 'h1.4', 'h1.5']: material claim produced by 'merged' from ['h1.4', 'h1.5']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['hi-p2-s3', 'h1.7', 'h1.8']: material claim produced by 'merged' from ['h1.7', 'h1.8']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked

## Recorded peer relays (relayed/<task>.json) compared with the current parse of the peer's raw text (the genuine pass delivers the current parse; the recording is the dependent agent's document only)

- relayed/hi-p2.json (en-p2 relayed to hi-p2): identical to the current parse (created_at aside)

## Mutations: findings beyond the genuine record that do not name the injection (a consequence of the injected words, such as a word bound crossed, or a wrong receipt: read the message)

- en-p2.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q01', 'p4-s02']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 251 words; bound max_words 250; solver COUNTEREXAMPLE (genuine record: measured 234 words; bound max_words 250; solver ENTAILED; the mutation added 17 words)
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence (genuine record: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence)
- en-p2.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q01', 'p4-s02']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 251 words; bound max_words 250; solver COUNTEREXAMPLE (genuine record: measured 234 words; bound max_words 250; solver ENTAILED; the mutation added 17 words)
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence (genuine record: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence)
- en-t5.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q04', 'p4-s03']
  - lost from the genuine record: warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
- en-t5.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q04', 'p4-s03']
  - lost from the genuine record: warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
- en-t6.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q01', 'p4-s02']
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence (genuine record: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence)
- en-t6.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q01', 'p4-s02']
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence (genuine record: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence)
- hi-t5.json [chronology_error] ACCEPTED_WITH_FINDINGS: injected claims ['h1.13']
  - warning CORE-CHR-001 ['h1.2']: paragraph 1, sentence 2 orders two dated events ('after': 26 October later than 14 October) but the relation could not be decided: neither '26 October' nor '14 October' carries a year; the paragraph states 4 different years; the stated relation was not checked

## Failures

(none)