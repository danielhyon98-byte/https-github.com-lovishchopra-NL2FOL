# Arena r6 (QUALIFIED: 1 of 28 recorded translations not served; 27 served by claim id only)

Transmissions: 46; functional: 46 (100.0%). This is the transport measure only: fixture coverage, translation fidelity and the claim counts are separate measures (below), never combined with it into one rate.

Genuine transmissions, peer relays and combinator syntheses: 12. With an error-level finding: 0, of which 0 counted functional. With warning-level findings only: 10, of which 10 counted functional. The rate does not judge whether a finding is true: a false error on a correct statement is counted functional like a true one, so read every finding in the genuine section below.

## Measures (each on its own denominator; none is combined with another into one rate)

- Transport (functional transmissions): 46 of 46 (100.0%). Genuine traffic delivered and decided: 12 of 12 (genuine replies 6, peer relays 1, syntheses 5); injected faults named: 34 of 34 mutation records. Transport says the hub delivered and decided every transmission; it does not judge whether a finding is true, whether a translation is faithful or whether an answer is better.
- Fixture coverage (recorded translations served in this run): 27 of 28 served; NOT SERVED: 1 (1 claim not eligible under the current policy). Of the 27 served, 0 were bound to a recorded claim-text digest and 27 by claim id only.
- Translation fidelity (faithful translations where adjudicated): not adjudicated; the round has no adjudications/translation_fidelity.json, so no fidelity figure applies to this run.
- Claims (genuine pass, each delivered claim once): extracted 93; eligible for translation 33; attempted 27; completed (a definitive verdict displayed) 15; faithful: not adjudicated; approved (displayed ENTAILED with no error-level finding on the claim; not a release decision) 15, of which 15 rest on at least one ungrounded premise and 15 on at least one unresolved dependency (ungrounded, or authority no check validated); release permitted by the release assessment (the application's rule, apart from the formal status) 0. Eligible claims with no translation attempted: 6.
- Latency (hub processing per transmission in this run, on this machine; not a stress measurement): genuine traffic median 146 ms, 95th percentile 457 ms, max 457 ms over 11; injected faults median 241 ms, 95th percentile 439 ms, max 496 ms over 34.
- Cost: no translation provider was called (recorded fixtures only).
- QUALIFIED (TRANSLATIONS_LOST): 1 of 28 recorded translations were not served in this run (1 claim not eligible under the current policy); translation outcomes cover the 27 served, so this run is not a translation regression over the recorded round.
- QUALIFIED (FIXTURES_UNBOUND): 27 of the 27 served translations carry no recorded claim-text digest: each is bound to the text its claim id carries in this run, which may not be the sentence it was produced for.

| variant | functional | total |
| --- | --- | --- |
| genuine | 6 | 6 |
| synthesis | 5 | 5 |
| peer_relay | 1 | 1 |
| invented_quotation | 6 | 6 |
| invented_quotation_single | 6 | 6 |
| altered_quotation | 4 | 4 |
| self_certification | 6 | 6 |
| wrong_arithmetic | 6 | 6 |
| chronology_error | 6 | 6 |

## Translation outcomes (provider-dependent; genuine pass, one outcome per eligible claim with a fixture)

- AMBIGUOUS_TRANSLATION: 2 (2 distinct claims)
- ENTAILED: 15 (15 distinct claims)
- INVALID_FORMALIZATION: 10 (10 distinct claims)
- NOT_ELIGIBLE: 1 (1 distinct claims)
- ENTAILED verdicts resting only on ungrounded premises: 9 of 15: en-t11.json p1-s01, en-t11.json p1-s02, en-t12.json p1-s01, hi-p5.json h1.3, hi-t11.json h1.6, hi-t11.json h1.7, hi-t11.json h1.8, hi-t11.json h1.9, hi-t12.json h1.6
- encodings given no verdict on genuine claims (displayed INVALID_FORMALIZATION: a definitive engine status withheld, or the encoding rejected at translation): 10; E108 vacuous result: 0; E110 unasserted figure: 8 (hi-p5.json h1.2 (rejected at translation), hi-p5.json h1.5 (rejected at translation), hi-t11.json h1.3 (rejected at translation), hi-t11.json h1.4 (rejected at translation), hi-t12.json h1.2 (rejected at translation), hi-t12.json h1.4 (rejected at translation), hi-t12.json h1.5 (rejected at translation), hi-t12.json h1.7 (rejected at translation)); E111 unencoded reason: 0; E112 circular encoding: 2 (hi-p5.json h1.4 (rejected at translation), hi-t12.json h1.3 (rejected at translation)); stated precision: 0; exactness: 0
- advisory coverage warnings on genuine claims (the verdict on the encoding stands; the encoding leaves a figure or symbol open that no source asserts; a coverage measure, not a verdict): 0; W110 unasserted figure, advisory: 0; W111 unconstrained symbol, advisory: 0
- definitive verdicts other than ENTAILED displayed on genuine claims (each is shown to the router as the engine's verdict on the claim's encoding: COUNTEREXAMPLE, the claim does not follow from its premises; INCONSISTENT_PREMISES, its premises conflict): 0
- all variants together (the same claims repeated): {'ENTAILED': 99, 'AMBIGUOUS_TRANSLATION': 13, 'INVALID_FORMALIZATION': 64, 'NOT_ELIGIBLE': 7, 'STALE_FIXTURE_REFUSED': 2}

## Genuine transmissions, peer relays and combinator syntheses carrying error- or warning-level findings (correct against a specialist's or the combinator's fault, or a false finding: read the message)

- en-t11.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['ES-STR-001', 'INT-REQ-005', 'INT-REQ-006']
  - warning INT-REQ-005 []: constraint c4 not satisfied: measured 4 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several)
  - warning INT-REQ-006 ['p3-point']: claim p3-point's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
- en-t11.json [synthesis syn-en-t11] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-SYNTH-012']
  - warning INT-SYNTH-012 ['s0', 'p1-s01', 'p1-s02']: material claim produced by 'merged' from ['p1-s01', 'p1-s02']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'p3-point', 'p3-s02', 'p3-s03']: material claim produced by 'merged' from ['p3-point', 'p3-s02', 'p3-s03']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s3', 'p4-point', 'p4-s02']: material claim produced by 'merged' from ['p4-point', 'p4-s02']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- en-t12.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['ES-STR-001', 'INT-REQ-005']
  - warning INT-REQ-005 []: constraint c3 not satisfied: measured 4 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several)
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
- en-t12.json [synthesis syn-en-t12] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-SYNTH-012']
  - warning INT-SYNTH-012 ['s2', 'p3-point', 'p3-s02', 'p3-s03']: material claim produced by 'merged' from ['p3-point', 'p3-s02', 'p3-s03']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- hi-p5.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-REQ-006']
  - warning INT-REQ-006 ['h1.2']: claim h1.2's verification gave no verdict: its outcome is displayed INVALID_FORMALIZATION (translation INVALID_FORMALIZATION; no engine result was produced), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.4']: claim h1.4's verification gave no verdict: its outcome is displayed INVALID_FORMALIZATION (translation INVALID_FORMALIZATION; no engine result was produced), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.5']: claim h1.5's verification gave no verdict: its outcome is displayed INVALID_FORMALIZATION (translation INVALID_FORMALIZATION; no engine result was produced), so the router must not read the claim as checked
- hi-t11.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-REQ-006']
  - warning INT-REQ-006 ['h1.1']: claim h1.1's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.3']: claim h1.3's verification gave no verdict: its outcome is displayed INVALID_FORMALIZATION (translation INVALID_FORMALIZATION; no engine result was produced), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.4']: claim h1.4's verification gave no verdict: its outcome is displayed INVALID_FORMALIZATION (translation INVALID_FORMALIZATION; no engine result was produced), so the router must not read the claim as checked
- hi-t11.json [synthesis syn-hi-t11] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-SYNTH-012']
  - warning INT-SYNTH-012 ['s0', 'h1.1']: material claim produced by 'paraphrased' from ['h1.1']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s1', 'h1.3']: material claim produced by 'paraphrased' from ['h1.3']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'h1.7', 'h1.8']: material claim produced by 'merged' from ['h1.7', 'h1.8']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- hi-t12.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['CORE-SRC-003', 'HI-STR-001', 'INT-REQ-006']
  - warning INT-REQ-006 ['h1.2']: claim h1.2's verification gave no verdict: its outcome is displayed INVALID_FORMALIZATION (translation INVALID_FORMALIZATION; no engine result was produced), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.3']: claim h1.3's verification gave no verdict: its outcome is displayed INVALID_FORMALIZATION (translation INVALID_FORMALIZATION; no engine result was produced), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.4']: claim h1.4's verification gave no verdict: its outcome is displayed INVALID_FORMALIZATION (translation INVALID_FORMALIZATION; no engine result was produced), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.5']: claim h1.5's verification gave no verdict: its outcome is displayed INVALID_FORMALIZATION (translation INVALID_FORMALIZATION; no engine result was produced), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.7']: claim h1.7's verification gave no verdict: its outcome is displayed INVALID_FORMALIZATION (translation INVALID_FORMALIZATION; no engine result was produced), so the router must not read the claim as checked
  - warning CORE-SRC-003 ['h1.4']: 1 quotation(s) cannot be verified: no text was supplied and the from-memory label concerns dates and figures, not quotations: 'wind of change'
  - warning HI-STR-001 ['h1.1', 'h1.2', 'h1.3', 'h1.4', 'h1.5', 'h1.6', 'h1.7', 'h1.8']: body paragraph 1 has no judgement move (counter-case weighed by a criterion)
- hi-t12.json [synthesis syn-hi-t12] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-SYNTH-012']
  - warning INT-SYNTH-012 ['s0', 'h1.2']: material claim produced by 'paraphrased' from ['h1.2']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s1', 'h1.3']: material claim produced by 'paraphrased' from ['h1.3']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'h1.4']: material claim produced by 'paraphrased' from ['h1.4']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s3', 'h1.7']: material claim produced by 'paraphrased' from ['h1.7']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- en-p5.json [synthesis syn-p5] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-SYNTH-012'] (cites a report whose recorded relay ['relayed/en-p5.json'] differs from the current parse: see the recorded peer relays below)
  - warning INT-SYNTH-012 ['hi-p5-s0', 'h1.2']: material claim produced by 'paraphrased' from ['h1.2']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['hi-p5-s1', 'h1.3']: material claim produced by 'paraphrased' from ['h1.3']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['hi-p5-s2', 'h1.4']: material claim produced by 'paraphrased' from ['h1.4']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['en-p5-s1', 'p1-s03', 'p1-s04']: material claim produced by 'merged' from ['p1-s03', 'p1-s04']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['en-p5-s2', 'p1-s07', 'p1-s08', 'p1-s09']: material claim produced by 'merged' from ['p1-s07', 'p1-s08', 'p1-s09']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked

## Recorded peer relays (relayed/<task>.json) compared with the current parse of the peer's raw text (the genuine pass delivers the current parse; the recording is the dependent agent's document only)

- relayed/en-p5.json (hi-p5 relayed to en-p5): DIFFERS from the current parse; the genuine pass delivered the current parse and used the recording only for the document the agent read
  - the recorded file also carries router-only fields the dependent agent could read beyond its peer's report: ['peer_receipt', 'plan', 'relay', 'request'] (relay_peer.py now writes them to router/<task>.json)
  - h1.2 supporting_claim_ids: recorded ["h1.3", "h1.4", "h1.5"] -> current ["h1.3", "h1.4"]

## Mutations: findings beyond the genuine record that do not name the injection (a consequence of the injected words, such as a word bound crossed, or a wrong receipt: read the message)

- en-t11.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q02', 'p4-s03']
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence (genuine record: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence)
- en-t11.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q02', 'p4-s03']
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence (genuine record: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence)
- en-t12.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q02', 'p4-s03']
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence (genuine record: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence)
- en-t12.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q02', 'p4-s03']
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence (genuine record: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence)
- hi-t11.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['h2.2']
  - warning INT-REQ-005 []: constraint c3 not satisfied: measured 2 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several) (genuine record: measured 1 paragraphs; bound max_paragraphs 1; solver ENTAILED; the mutation added 17 words)
- hi-t11.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['h2.2']
  - warning INT-REQ-005 []: constraint c3 not satisfied: measured 2 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several) (genuine record: measured 1 paragraphs; bound max_paragraphs 1; solver ENTAILED; the mutation added 17 words)
- hi-t11.json [wrong_arithmetic] ACCEPTED_WITH_FINDINGS: injected claims ['h2.2']
  - warning INT-REQ-005 []: constraint c3 not satisfied: measured 2 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several) (genuine record: measured 1 paragraphs; bound max_paragraphs 1; solver ENTAILED; the mutation added 13 words)
- hi-t11.json [chronology_error] ACCEPTED_WITH_FINDINGS: injected claims ['h2.2']
  - warning INT-REQ-005 []: constraint c3 not satisfied: measured 2 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several) (genuine record: measured 1 paragraphs; bound max_paragraphs 1; solver ENTAILED; the mutation added 16 words)

## Delivery decisions (delivery policy delivery-v1: 240 s translation budget, overseer-selected fallback above 0.9; docs/DELIVERY.md)

Each genuine answer is replayed on a hub of its own with the transfer auditor attached and decided by the delivery policy. Overseer agents: not configured (the harness calls no model): the fallback establishes no accuracy. A separate measure: it changes no transport count. Modes: formally_checked 0, overseer_selected 0, not_checked 0, withheld 6; receipts identical to the genuine records' (status and codes): 6 of 6; the pass took 6.608 s.

| task | mode | time to decision (s) | translation (s) | overseer (s) | candidates (accuracy) | chosen | why |
| --- | --- | --- | --- | --- | --- | --- | --- |
| en-t11.json | withheld | 1.164 | 1.102 | - | english-specialist 0/5 | - | claim p2-point: unresolved (release rule release-v1: ungrounded dependencies (relied on, not established by the supplied material or the task): pr_pronouns_narr… |
| en-t12.json | withheld | 0.882 | 0.846 | - | english-specialist 0/4 | - | claim p2-point: unresolved (release rule release-v1: ungrounded dependencies (relied on, not established by the supplied material or the task): pr_tag_splits, p… |
| hi-p5.json | withheld | 0.453 | 0.443 | - | history-specialist 0/2 | - | claim h1.2: unresolved (translation INVALID_FORMALIZATION; display status INVALID_FORMALIZATION: no definitive verdict; release rule release-v1: translation INV… |
| hi-t11.json | withheld | 2.315 | 2.262 | - | history-specialist 0/4 (faulted, not deliverable) | - | the consolidation is NO_DELIVERABLE_OUTPUT: every answer is excluded |
| hi-t12.json | withheld | 0.807 | 0.792 | - | history-specialist 0/2 | - | claim h1.2: unresolved (translation INVALID_FORMALIZATION; display status INVALID_FORMALIZATION: no definitive verdict; release rule release-v1: translation INV… |
| en-p5.json | withheld | 0.955 | 0.919 | - | english-specialist 0/2 | - | claim p1-point: unresolved (release rule release-v1: ungrounded dependencies (relied on, not established by the supplied material or the task): pr_q_hostility, … |

## Failures

(none)