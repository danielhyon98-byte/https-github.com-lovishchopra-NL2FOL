# Arena r6

Transmissions: 46; functional: 46 (100.0%)

Genuine transmissions, peer relays and combinator syntheses: 12. With an error-level finding: 0, of which 0 counted functional. With warning-level findings only: 8, of which 8 counted functional. The rate does not judge whether a finding is true: a false error on a correct statement is counted functional like a true one, so read every finding in the genuine section below.

| variant | functional | total |
| --- | --- | --- |
| genuine | 6 | 6 |
| synthesis | 5 | 5 |
| peer_relay | 1 | 1 |
| invented_quotation | 6 | 6 |
| invented_quotation_single | 6 | 6 |
| altered_quotation | 4 | 4 |
| self_certification | 6 | 6 |
| wrong_arithmetic | 6 | 6 |
| chronology_error | 6 | 6 |

## Translation outcomes (provider-dependent; genuine pass, one outcome per eligible claim with a fixture)

- AMBIGUOUS_TRANSLATION: 2 (2 distinct claims)
- ENTAILED: 15 (15 distinct claims)
- INVALID_FORMALIZATION: 10 (10 distinct claims)
- NOT_ELIGIBLE: 1 (1 distinct claims)
- ENTAILED verdicts resting only on ungrounded premises: 9 of 15: en-t11.json p1-s01, en-t11.json p1-s02, en-t12.json p1-s01, hi-p5.json h1.3, hi-t11.json h1.6, hi-t11.json h1.7, hi-t11.json h1.8, hi-t11.json h1.9, hi-t12.json h1.6
- encodings given no verdict on genuine claims (displayed INVALID_FORMALIZATION: a definitive engine status withheld, or the encoding rejected at translation): 10; E108 vacuous result: 0; E110 unasserted figure: 8 (hi-p5.json h1.2 (rejected at translation), hi-p5.json h1.5 (rejected at translation), hi-t11.json h1.3 (rejected at translation), hi-t11.json h1.4 (rejected at translation), hi-t12.json h1.2 (rejected at translation), hi-t12.json h1.4 (rejected at translation), hi-t12.json h1.5 (rejected at translation), hi-t12.json h1.7 (rejected at translation)); E111 unencoded reason: 0; E112 circular encoding: 2 (hi-p5.json h1.4 (rejected at translation), hi-t12.json h1.3 (rejected at translation)); stated precision: 0
- definitive verdicts other than ENTAILED displayed on genuine claims (each is shown to the router as the engine's verdict on the claim's encoding: COUNTEREXAMPLE, the claim does not follow from its premises; INCONSISTENT_PREMISES, its premises conflict): 0
- all variants together (the same claims repeated): {'ENTAILED': 99, 'AMBIGUOUS_TRANSLATION': 13, 'INVALID_FORMALIZATION': 64, 'NOT_ELIGIBLE': 7, 'STALE_FIXTURE_REFUSED': 2}

## Genuine transmissions, peer relays and combinator syntheses carrying error- or warning-level findings (correct against a specialist's or the combinator's fault, or a false finding: read the message)

- en-t11.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['ES-STR-001', 'INT-REQ-005']
  - warning INT-REQ-005 []: constraint c4 not satisfied: measured 4 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several)
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
- en-t11.json [synthesis syn-en-t11] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-SYNTH-012']
  - warning INT-SYNTH-012 ['s0', 'p1-s01', 'p1-s02']: material claim produced by 'merged' from ['p1-s01', 'p1-s02']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'p3-point', 'p3-s02', 'p3-s03']: material claim produced by 'merged' from ['p3-point', 'p3-s02', 'p3-s03']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s3', 'p4-point', 'p4-s02']: material claim produced by 'merged' from ['p4-point', 'p4-s02']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- en-t12.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['ES-STR-001', 'INT-REQ-005']
  - warning INT-REQ-005 []: constraint c3 not satisfied: measured 4 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several)
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
- en-t12.json [synthesis syn-en-t12] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-SYNTH-012']
  - warning INT-SYNTH-012 ['s2', 'p3-point', 'p3-s02', 'p3-s03']: material claim produced by 'merged' from ['p3-point', 'p3-s02', 'p3-s03']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- hi-t11.json [synthesis syn-hi-t11] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-SYNTH-012']
  - warning INT-SYNTH-012 ['s0', 'h1.1']: material claim produced by 'paraphrased' from ['h1.1']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s1', 'h1.3']: material claim produced by 'paraphrased' from ['h1.3']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'h1.7', 'h1.8']: material claim produced by 'merged' from ['h1.7', 'h1.8']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- hi-t12.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['CORE-SRC-003', 'HI-STR-001']
  - warning CORE-SRC-003 ['h1.4']: 1 quotation(s) cannot be verified: no text was supplied and the from-memory label concerns dates and figures, not quotations: 'wind of change'
  - warning HI-STR-001 ['h1.1', 'h1.2', 'h1.3', 'h1.4', 'h1.5', 'h1.6', 'h1.7', 'h1.8']: body paragraph 1 has no judgement move (counter-case weighed by a criterion)
- hi-t12.json [synthesis syn-hi-t12] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-SYNTH-012']
  - warning INT-SYNTH-012 ['s0', 'h1.2']: material claim produced by 'paraphrased' from ['h1.2']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s1', 'h1.3']: material claim produced by 'paraphrased' from ['h1.3']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'h1.4']: material claim produced by 'paraphrased' from ['h1.4']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s3', 'h1.7']: material claim produced by 'paraphrased' from ['h1.7']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- en-p5.json [synthesis syn-p5] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-SYNTH-012'] (cites a report whose recorded relay ['relayed/en-p5.json'] differs from the current parse: see the recorded peer relays below)
  - warning INT-SYNTH-012 ['hi-p5-s0', 'h1.2']: material claim produced by 'paraphrased' from ['h1.2']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['hi-p5-s1', 'h1.3']: material claim produced by 'paraphrased' from ['h1.3']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['hi-p5-s2', 'h1.4']: material claim produced by 'paraphrased' from ['h1.4']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['en-p5-s1', 'p1-s03', 'p1-s04']: material claim produced by 'merged' from ['p1-s03', 'p1-s04']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['en-p5-s2', 'p1-s07', 'p1-s08', 'p1-s09']: material claim produced by 'merged' from ['p1-s07', 'p1-s08', 'p1-s09']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked

## Recorded peer relays (relayed/<task>.json) compared with the current parse of the peer's raw text (the genuine pass delivers the current parse; the recording is the dependent agent's document only)

- relayed/en-p5.json (hi-p5 relayed to en-p5): DIFFERS from the current parse; the genuine pass delivered the current parse and used the recording only for the document the agent read
  - h1.2 supporting_claim_ids: recorded ["h1.3", "h1.4", "h1.5"] -> current ["h1.3", "h1.4"]

## Mutations: findings beyond the genuine record that do not name the injection (a consequence of the injected words, such as a word bound crossed, or a wrong receipt: read the message)

- en-t11.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q02', 'p4-s03']
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence (genuine record: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence)
- en-t11.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q02', 'p4-s03']
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence (genuine record: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence)
- en-t12.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q02', 'p4-s03']
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence (genuine record: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence)
- en-t12.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q02', 'p4-s03']
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence (genuine record: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence)
- hi-t11.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['h2.2']
  - warning INT-REQ-005 []: constraint c3 not satisfied: measured 2 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several) (genuine record: measured 1 paragraphs; bound max_paragraphs 1; solver ENTAILED; the mutation added 17 words)
- hi-t11.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['h2.2']
  - warning INT-REQ-005 []: constraint c3 not satisfied: measured 2 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several) (genuine record: measured 1 paragraphs; bound max_paragraphs 1; solver ENTAILED; the mutation added 17 words)
- hi-t11.json [wrong_arithmetic] ACCEPTED_WITH_FINDINGS: injected claims ['h2.2']
  - warning INT-REQ-005 []: constraint c3 not satisfied: measured 2 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several) (genuine record: measured 1 paragraphs; bound max_paragraphs 1; solver ENTAILED; the mutation added 13 words)
- hi-t11.json [chronology_error] ACCEPTED_WITH_FINDINGS: injected claims ['h2.2']
  - warning INT-REQ-005 []: constraint c3 not satisfied: measured 2 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several) (genuine record: measured 1 paragraphs; bound max_paragraphs 1; solver ENTAILED; the mutation added 16 words)

## Failures

(none)