#!/usr/bin/env python3
"""Scratch helper for building IR 1.0 translations (not part of the repo)."""
import json
import re
from pathlib import Path

R6 = Path("/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/arena/r6")
SPEC = R6 / "specialists"
REL = R6 / "relayed"
OUT = R6 / "translations"
NAME_RE = re.compile(r"^[a-z][a-z0-9_]{0,63}$")


def V(n):
    return {"op": "var", "name": n}


def AND(xs):
    xs = list(xs)
    return xs[0] if len(xs) == 1 else {"op": "and", "args": xs}


def IMPL(left, right):
    return {"op": "implies", "left": left, "right": right}


def IFF(left, right):
    return {"op": "iff", "left": left, "right": right}


def CMP(op, left, right):
    return {"op": op, "left": left, "right": right}


def INT(v):
    return {"op": "int", "value": str(v)}


def REAL(v):
    return {"op": "real", "value": str(v)}


def QG(doc, ex, cert="established"):
    return {"kind": "quotation", "source_refs": [{"document_id": doc, "excerpt": ex}], "certainty": cert}


def SIG(cert="probable"):
    return {"kind": "specialist_inference", "certainty": cert}


def STG(cert="probable"):
    return {"kind": "supplied_text", "certainty": cert}


def GKG(cert="probable"):
    return {"kind": "general_knowledge", "certainty": cert,
            "note": "stated from memory in the specialist report; no supplied text checks it"}


def load_claims(task):
    rows = json.loads((R6 / f"listing_{task}.json").read_text())["claims"]
    return {r["claim_id"]: r["text"] for r in rows}


def load_request(task):
    return json.loads((R6 / f"listing_{task}.json").read_text())["request_id"]


def load_report(task):
    return json.loads((R6 / f"listing_{task}.json").read_text())["report_id"]


def load_texts(task):
    spec = json.loads((SPEC / f"{task}.json").read_text())
    texts = {t["document_id"]: t["text"] for t in spec.get("supplied_texts", [])}
    if spec.get("peer_of"):
        rel = json.loads((REL / f"{task}.json").read_text())
        assert rel.get("delivered") and rel.get("payload"), "peer not delivered"
        texts[f"peer:{spec['peer_of']}"] = rel["payload"]["original_response"]
    return texts


class Reg:
    """Registry of atoms. Each atom is a Bool symbol, optionally derived from others,
    or a numeric fact (Int/Real symbol inside an iff premise)."""

    def __init__(self, texts):
        self.texts = texts
        self.atoms = {}
        self.order = []

    def _add(self, name, atom):
        assert NAME_RE.match(name), f"bad symbol name {name}"
        assert name not in self.atoms, f"duplicate atom {name}"
        atom.setdefault("deps", [])
        self.atoms[name] = atom
        self.order.append(name)

    def q(self, name, meaning, doc, ex, cert="established", label=None):
        assert doc in self.texts, f"missing doc {doc}"
        assert ex in self.texts[doc], f"excerpt not found verbatim in {doc}: {ex!r}"
        self._add(name, {"type": "var", "meaning": meaning, "label": label or meaning,
                         "grounding": QG(doc, ex, cert)})

    def a(self, name, meaning, grounding, label=None):
        self._add(name, {"type": "var", "meaning": meaning, "label": label or meaning,
                         "grounding": grounding})

    def d(self, name, meaning, deps, cert="probable", label=None):
        self._add(name, {"type": "derived", "meaning": meaning, "label": label or meaning,
                         "grounding": SIG(cert), "deps": list(deps)})

    def num(self, name, intname, meaning, op, value, sort="Int", cert="probable", label=None):
        self._add(name, {"type": "num", "intname": intname, "sort": sort, "meaning": meaning,
                         "label": label or meaning, "op": op, "value": value,
                         "grounding": GKG(cert)})


def build(reg, task, claim_id, request_id, concl, concl_label, supports=(), notes=None):
    mat = set()

    def walk(names, acc):
        for n in names:
            assert n in reg.atoms, f"undefined atom {n} in {claim_id}"
            if n in acc:
                continue
            acc.add(n)
            walk(reg.atoms[n]["deps"], acc)

    walk(concl, mat)
    alln = set(mat)
    walk(supports, alln)
    symbols, premises = [], []
    for n in reg.order:
        if n not in alln:
            continue
        at = reg.atoms[n]
        role = "material" if n in mat else "supporting"
        t = at["type"]
        if t == "var":
            symbols.append({"name": n, "sort": "Bool", "meaning": at["meaning"], "grounding": at["grounding"]})
            premises.append({"id": "pr_" + n, "expr": V(n), "label": at["label"],
                             "grounding": at["grounding"], "materiality": role})
        elif t == "derived":
            symbols.append({"name": n, "sort": "Bool", "meaning": at["meaning"], "grounding": at["grounding"]})
            ants = AND([V(x) for x in at["deps"]])
            premises.append({"id": "pr_" + n, "expr": IMPL(ants, V(n)), "label": at["label"],
                             "grounding": at["grounding"], "materiality": role})
        elif t == "num":
            g = at["grounding"]
            symbols.append({"name": at["intname"], "sort": at["sort"], "meaning": at["meaning"], "grounding": g})
            symbols.append({"name": n, "sort": "Bool", "meaning": at["meaning"], "grounding": g})
            rhs = REAL(at["value"]) if at["sort"] == "Real" else INT(at["value"])
            premises.append({"id": "pr_" + n, "expr": IFF(V(n), CMP(at["op"], V(at["intname"]), rhs)),
                             "label": at["label"], "grounding": g, "materiality": role})
    problem = {
        "ir_version": "1.0",
        "problem_id": f"{task}-{claim_id}",
        "request_id": request_id,
        "claim_id": claim_id,
        "query": "entailment",
        "symbols": symbols,
        "premises": premises,
        "conclusion": {"id": "concl", "expr": AND([V(n) for n in concl]), "label": concl_label},
    }
    if notes:
        problem["notes"] = notes
    return problem


def entry(reg, task, claim_id, request_id, concl, concl_label, reading, flags=(), supports=(), notes=None):
    prob = build(reg, task, claim_id, request_id, concl, concl_label, supports, notes)
    glossary = [{"symbol": s["name"], "meaning": s["meaning"], "grounding": None} for s in prob["symbols"]]
    return {
        "problem": prob,
        "interpretation": {"reading": reading, "glossary": glossary, "ambiguity_flags": list(flags)},
        "ambiguous": bool(flags),
        "unsupported_reason": None,
    }


def write_task(task, claims):
    out = {"report_id": load_report(task), "claims": claims}
    path = OUT / f"{task}.json"
    path.write_text(json.dumps(out, ensure_ascii=False, indent=2) + "\n")
    return path
