import sys
sys.path.insert(0, "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/arena/r6/tools")
from build_lib import Reg, load_texts, load_claims, load_request, write_task, entry, STG, SIG

TASK = "en-t12"
LV = "doc-love"
T = load_claims(TASK)
RQ = load_request(TASK)
R = Reg(load_texts(TASK))

R.q("q_knowyou", "Love asks: And know you not, sayes Love, who bore the blame", LV,
    "And know you not, sayes Love, who bore the blame")
R.q("q_sayes", "the tag sayes", LV, "sayes")
R.q("q_sweetly", "Love questions sweetly, If I lack'd any thing, with the speaker's pronoun", LV,
    "sweetly questioning,\nIf I lack'd any thing")
R.q("q_refuse", "the speaker refuses: I cannot look on thee", LV, "I cannot look on thee")
R.q("q_took", "Love took the speaker's hand and smiling did reply", LV,
    "Love took my hand, and smiling did reply")
R.q("q_who", "the short question: Who made the eyes but I", LV, "Who made the eyes but I")
R.q("q_cannot", "the modal cannot", LV, "cannot")
R.q("q_sit", "Love's words: You must sit down, sayes Love, and taste my meat", LV,
    "You must sit down, sayes Love, and taste my meat")
R.q("q_serve", "the speaker's reply: My deare, then I will serve", LV, "My deare, then I will serve")
R.q("q_did", "the word did", LV, "did")

# Structural facts about the poem (supplied_text, asserted not checked).
R.a("st_no_quote_marks", "the speech has no quotation marks", STG(), "the speech has no quotation marks")
R.a("st_refusal_short", "the refusal I cannot look on thee is compressed into one short line", STG(),
    "the refusal is compressed into one short line")
R.a("st_reply_long", "Love's reply follows a long line of action", STG(),
    "Love's reply follows a long line of action")
R.a("st_closing_long", "Love's words in the closing lines fill the long lines", STG(),
    "Love's words in the closing lines fill the long lines")
R.a("st_replies_short", "the speaker's replies in the closing lines stay short", STG(),
    "the speaker's replies in the closing lines stay short")
R.a("st_insistence_last_long", "Insistence has the last long line", STG(), "Insistence has the last long line")
R.a("st_refusals_pairs", "each of the speaker's refusals is answered in the following pair of lines", STG(),
    "each of the speaker's refusals is answered in the following pair of lines")

R.d("tag_splits", "the tag sayes splits Love's question, so the attribution interrupts the argument",
    ["q_knowyou", "q_sayes"],
    label="the tag sayes splits Love's question, so the attribution interrupts the argument")
R.d("tenderness_filtered", "Love's tenderness reaches the reader filtered through the speaker's account",
    ["q_sweetly"],
    label="Love's question takes the speaker's pronoun, so Love's tenderness reaches the reader filtered through the speaker's account")
R.d("refusal_incapacity", "the refusal is a short line, Love's reply a long line of action, and the question answers "
    "the modal cannot by attributing the eyes to Love",
    ["q_refuse", "st_refusal_short", "q_took", "st_reply_long", "q_who", "q_cannot"],
    label="the refusal is compressed into one short line; Love's reply follows a long line of action; the modal cannot presents refusal as incapacity, and the question answers it by attributing the eyes to Love's making")
R.d("closing_contrast", "Love's words fill the long lines while the speaker's replies stay short",
    ["q_sit", "q_serve", "st_closing_long", "st_replies_short"],
    label="in the closing lines Love's words fill the long lines while the speaker's replies stay short")
R.d("did_emphatic", "the final did is emphatic and the last short line closes the exchange on obedience",
    ["q_did"], label="the final did is emphatic, and the poem's last short line closes the exchange on obedience rather than dissent")
R.d("point_p2", T["p2-point"], ["st_no_quote_marks", "tag_splits"], label=T["p2-point"])
R.d("point_p3", T["p3-point"], ["refusal_incapacity", "closing_contrast"], label=T["p3-point"])
R.d("point_p4", T["p4-point"], ["st_insistence_last_long", "st_refusals_pairs"], label=T["p4-point"])

R.a("rep_p2", "report claim p2-point, asserted in this report (chained in its own problem)", SIG(), T["p2-point"])
R.a("rep_p3", "report claim p3-point, asserted in this report (chained in its own problem)", SIG(), T["p3-point"])
R.a("rep_p4", "report claim p4-point, asserted in this report (chained in its own problem)", SIG(), T["p4-point"])
R.d("thesis_s01", T["p1-s01"], ["rep_p2", "rep_p3", "rep_p4"], label=T["p1-s01"])

CLAIMS = {}
CLAIMS["p2-point"] = entry(
    R, TASK, "p2-point", RQ, ["point_p2"], T["p2-point"],
    reading=("The first clause, 'no quotation marks', is a supplied_text fact about the poem. The tag claim is one link "
             "from the quoted 'And know you not, sayes Love, who bore the blame' and the tag 'sayes'. The final link "
             "combines the no-quotation-marks fact with the tag claim to give the point. The device about Love's question "
             "taking the speaker's pronoun is carried as supporting only and does not feed the conclusion."),
    flags=[],
    supports=["tenderness_filtered"])

CLAIMS["p3-point"] = entry(
    R, TASK, "p3-point", RQ, ["point_p3"], T["p3-point"],
    reading=("'The short lines carry the decisive turns' is encoded from two specialist links. The first joins the "
             "refusal ('I cannot look on thee'), Love's long-line reply, the short question and the modal 'cannot' (with "
             "the line-length facts as supplied_text). The second joins the closing lines, where Love's words fill the long "
             "lines and the replies stay short (supplied_text). The point is one final link from the two."),
    flags=[])

CLAIMS["p4-point"] = entry(
    R, TASK, "p4-point", RQ, ["point_p4"], T["p4-point"],
    reading=("'Insistence has the last long line' and 'each refusal is answered in the following pair of lines' are "
             "structural supplied_text facts about the poem, asserted and not checked. The emphasis on the final 'did' is "
             "carried as a supporting premise; it is not used in the conclusion."),
    flags=[],
    supports=["did_emphatic"])

CLAIMS["p1-s01"] = entry(
    R, TASK, "p1-s01", RQ, ["thesis_s01"], T["p1-s01"],
    reading=("The thesis is one link from the three point claims (p2-point, p3-point, p4-point), each asserted here as "
             "the specialist's own claim. Each point's chain is encoded in its own problem."),
    flags=[])

write_task(TASK, CLAIMS)
print("wrote", TASK, list(CLAIMS))
