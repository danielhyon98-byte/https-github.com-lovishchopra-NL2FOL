import sys
sys.path.insert(0, "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/arena/r6/tools")
from build_lib import Reg, load_texts, load_claims, load_request, write_task, entry, STG, SIG

TASK = "en-t11"
JE = "doc-je"
T = load_claims(TASK)
RQ = load_request(TASK)
R = Reg(load_texts(TASK))

R.q("q_she", "the justification uses she for Mrs Reed", JE, "she")
R.q("q_i", "the justification uses I for Jane", JE, "I")
R.q("q_dispensed", "the word dispensed", JE, "dispensed")
R.q("q_dispensed_sent", "Mrs Reed says she had dispensed Jane from joining the group", JE,
    "Me, she had dispensed from joining the group")
R.q("q_until_bessie", "the condition is until she heard from Bessie", JE, "until she heard from Bessie")
R.q("q_bessie_say", "Jane asks what Bessie says she has done", JE, "What does Bessie say I have done")
R.q("q_jane", "Mrs Reed shifts to the name Jane", JE, "Jane")
R.q("q_child", "Mrs Reed calls Jane a child taking up her elders", JE, "a child taking up her elders")
R.q("q_remain", "Mrs Reed commands remain silent", JE, "remain silent")
R.q("q_until", "the repeated word until", JE, "until")

# Structural facts about the extract that the claims rely on (supplied_text, asserted not checked).
R.a("st_marks_in_quotes", "Mrs Reed's justification sits within quotation marks", STG(),
    "Mrs Reed's justification sits within quotation marks")
R.a("st_tense_narrator", "the tense of Mrs Reed's justification belongs to the narrator's report", STG(),
    "the tense of Mrs Reed's justification belongs to the narrator's report")
R.a("st_exchange_direct", "the exchange between Jane and Mrs Reed is direct speech", STG(),
    "the exchange between Jane and Mrs Reed is direct speech")

# Specialist assertion with no listed support.
R.a("official_exemption", "the exclusion sounds like an official exemption rather than a personal snub, since to "
    "dispense someone from a duty conventionally releases them from an obligation", SIG(),
    "the exclusion sounds like an official exemption rather than a personal snub")

R.d("key_dispensed", "the key word is dispensed, as in the quoted sentence", ["q_dispensed", "q_dispensed_sent"],
    label="the key word is dispensed, as in Me, she had dispensed from joining the group")
R.d("pronouns_narrator", "the pronouns belong to the narrator's report, with she for Mrs Reed and I for Jane",
    ["q_she", "q_i"], label="its pronouns belong to the narrator's report, with she for Mrs Reed and I for Jane")
R.d("reaches_indirectly", "so the justification reaches the reader indirectly",
    ["st_marks_in_quotes", "pronouns_narrator", "st_tense_narrator"],
    label="so it reaches the reader indirectly")
R.d("standing_depends_reports", "Jane's standing depends on reports she has not heard", ["q_until_bessie"],
    label="the judgement is conditional, waiting until she heard from Bessie, so Jane's standing depends on reports she has not heard")
R.d("deflects_hierarchy", "Mrs Reed deflects Jane's question by shifting from Jane to a child taking up her elders, "
    "a breach of hierarchy", ["q_bessie_say", "q_jane", "q_child"],
    label="Jane's question seeks the grounds, and Mrs Reed deflects it by shifting from Jane to a child taking up her elders, a breach of hierarchy")
R.d("silence_condition", "silence is the condition Jane must keep until she can speak pleasantly", ["q_remain"],
    label="the imperative remain silent makes silence the condition Jane must keep until she can speak pleasantly")
R.d("exchange_differs", T["p3-point"], ["st_exchange_direct", "deflects_hierarchy", "silence_condition"],
    label=T["p3-point"])
R.d("until_moves_to_voice", "the repeated until moves the condition from reports about Jane to her own voice, "
    "leaving the exclusion without a stated end", ["q_until"],
    label="the repeated until moves the condition from reports about Jane to her own voice, leaving the exclusion without a stated end")
R.d("point_p4", T["p4-point"], ["until_moves_to_voice"], label=T["p4-point"])

# Report claims used as premises by the thesis claims; each is chained in its own problem.
R.a("rep_p2", "report claim p2-point, asserted in this report (chained in its own problem)", SIG(),
    T["p2-point"])
R.a("rep_p3", "report claim p3-point, asserted in this report (chained in its own problem)", SIG(),
    T["p3-point"])
R.a("rep_p4", "report claim p4-point, asserted in this report (chained in its own problem)", SIG(),
    T["p4-point"])
R.d("thesis_s01", T["p1-s01"], ["rep_p2", "rep_p3", "rep_p4"], label=T["p1-s01"])
R.d("thesis_s02", T["p1-s02"], ["rep_p2", "rep_p3", "rep_p4"], label=T["p1-s02"])

CLAIMS = {}
CLAIMS["p2-point"] = entry(
    R, TASK, "p2-point", RQ,
    ["st_marks_in_quotes", "pronouns_narrator", "st_tense_narrator", "reaches_indirectly"], T["p2-point"],
    reading=("The claim has three parts: the justification sits within quotation marks, its pronouns and tense belong "
             "to the narrator's report (she for Mrs Reed, I for Jane), and so it reaches the reader indirectly. The two "
             "structural parts (quotation marks, tense) are supplied_text facts about the extract, asserted and not "
             "checked. The pronoun part is one link from the quoted she and I. The final 'so' is one link from the three "
             "parts. The listed supports on 'dispensed', the official-exemption gloss and the conditional judgement are "
             "carried as supporting premises; they do not feed the conclusion."),
    flags=[],
    supports=["key_dispensed", "official_exemption", "standing_depends_reports"])

CLAIMS["p3-point"] = entry(
    R, TASK, "p3-point", RQ, ["exchange_differs"], T["p3-point"],
    reading=("The sentence is a topic claim, 'the direct exchange differs'. It is encoded as differing from the reported "
             "passage, which the sentence presupposes. 'Direct' is a supplied_text fact about the extract. The content of "
             "the exchange is encoded from the listed supports: Jane's question and Mrs Reed's deflection to 'a child "
             "taking up her elders' (one link), and the imperative 'remain silent' making silence the condition (one link). "
             "Both links feed one final link."),
    flags=[{"code": "unstated_comparandum",
            "message": "'differs' names no comparison; it is encoded as differing from the reported passage.",
            "alternatives": ["differs from the reported speech of the preceding passage",
                             "differs in tone or rhythm from the reported passage"]}])

CLAIMS["p4-point"] = entry(
    R, TASK, "p4-point", RQ, ["point_p4"], T["p4-point"],
    reading=("The point is encoded from its listed supports only: the repeated 'until' and the step it makes (the "
             "condition moves from reports about Jane to her own voice, leaving the exclusion without a stated end). "
             "The sentence refers to 'the two forms' and to the judgement and its enforcement, which are the content of "
             "p2-point and p3-point. Those claims are not among this claim's listed supporting claims, so they are not "
             "linked here."),
    flags=[])

CLAIMS["p1-s01"] = entry(
    R, TASK, "p1-s01", RQ, ["thesis_s01"], T["p1-s01"],
    reading=("The thesis is one link from the three point claims (p2-point, p3-point, p4-point), each asserted here as "
             "the specialist's own claim. Each point's chain is encoded in its own problem."),
    flags=[],
    supports=[])

CLAIMS["p1-s02"] = entry(
    R, TASK, "p1-s02", RQ, ["thesis_s02"], T["p1-s02"],
    reading=("The thesis is one link from the three point claims (p2-point, p3-point, p4-point). The movement from "
             "reported to direct speech is carried by p2-point (reported) and p3-point (direct). Each point's chain is "
             "encoded in its own problem."),
    flags=[],
    supports=[])

write_task(TASK, CLAIMS)
print("wrote", TASK, list(CLAIMS))
