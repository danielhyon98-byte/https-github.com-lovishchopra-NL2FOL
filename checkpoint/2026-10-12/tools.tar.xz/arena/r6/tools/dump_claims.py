import json, sys
from pathlib import Path
from epinoic_logic.adapters.sources import check_excerpt
from epinoic_logic.branches import default_registry
from epinoic_logic.translate.contracts import SuppliedText
from epinoic_logic.translate.eligibility import decide_eligibility

spec_path = Path(sys.argv[1]).resolve()
item = json.loads(spec_path.read_text())
if item.get("peer_of"):
    relayed = spec_path.parent.parent / "relayed" / f"{item['task_id']}.json"
    if relayed.exists():
        rel = json.loads(relayed.read_text())
        if rel.get("delivered") and rel.get("payload"):
            item["supplied_texts"] = [*item.get("supplied_texts", []), {"document_id": rel.get("document_id", f"peer:{item['peer_of']}"), "title": "peer report relayed through the hub", "author": rel["payload"].get("agent_id"), "text": rel["payload"]["original_response"]}]
branch, profile = default_registry().for_subject(item["subject"])
texts = [SuppliedText(document_id=t["document_id"], title=t.get("title"), author=t.get("author"), text=t["text"], locator_scheme=t.get("locator_scheme", "none")) for t in item.get("supplied_texts", [])]
group = item.get("group") or spec_path.stem
report = branch.parser().parse_response(item["response_text"], request_id=f"req-{group}", task_id=group, report_id=f"rep-{item['task_id']}-0",
                                        subject=item["subject"], task_type=item.get("task_type", "analytical_paragraph"), supplied_texts=texts, agent_id=item["agent_id"])
docs = {t.document_id: t for t in texts}
print(f"##### {item['task_id']} report={report.report_id} request={report.request_id} docs={list(docs)}")
for c in report.claims:
    e = decide_eligibility(c)
    print(f"--- {c.claim_id} role={c.claim_role} mat={c.materiality} cert={c.certainty} elig={e.eligible}/{e.eligibility_class.value}")
    print(f"    TEXT: {c.claim_text}")
    print(f"    SUPPORTS: {list(c.supporting_claim_ids)}")
    for r in c.source_refs:
        loc = bool(r.excerpt) and r.document_id in docs and check_excerpt(r.excerpt, r.document_id, docs).located
        print(f"    REF doc={r.document_id} loc={r.locator} located={loc} excerpt={r.excerpt!r}")
    for a in c.assumptions:
        print(f"    ASSUMPTION: {a}")
