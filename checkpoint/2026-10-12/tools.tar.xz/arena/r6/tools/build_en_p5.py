import sys
sys.path.insert(0, "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/arena/r6/tools")
from build_lib import Reg, load_texts, load_claims, load_request, write_task, entry, STG, GKG, SIG

TASK = "en-p5"
NC, PE = "doc-nc", "peer:hi-p5"
T = load_claims(TASK)
RQ = load_request(TASK)
R = Reg(load_texts(TASK))

R.q("q_giant", "the poem names the brazen giant", NC, "brazen giant")
R.q("q_neg_giant", "the poem says it is not like the brazen giant of Greek fame", NC,
    "Not like the brazen giant of Greek fame")
R.q("q_conquer", "the poem says the giant has conquering limbs astride from land to land", NC,
    "conquering limbs astride from land to land")
R.q("q_mother", "the poem names its figure Mother of Exiles", NC, "Mother of Exiles")
R.q("q_exiles", "the poem uses the noun Exiles", NC, "Exiles")
R.q("q_mother_word", "the poem uses the word Mother", NC, "Mother")
R.q("q_mild_cmd", "the poem says her mild eyes command", NC, "mild eyes command")
R.q("q_mild", "the poem uses the adjective mild", NC, "mild")
R.q("q_homeless", "the poem calls the arrivals the homeless, tempest-tost", NC, "the homeless, tempest-tost")
R.q("q_yearning", "the poem gives the arrivals yearning to breathe free", NC, "yearning to breathe free")
R.q("q_lamp", "the figure says she lifts her lamp beside the golden door", NC,
    "I lift my lamp beside the golden door")
R.q("q_worldwide", "the poem speaks of a world-wide welcome", NC, "world-wide welcome")
R.q("q_hostility", "the History specialist's text says hostility toward one group was already written into law",
    PE, "Hostility toward one group was already written into law")
R.q("q_spoken", "the History specialist's text says the welcome was spoken into a country admitting immigrants "
    "in unprecedented numbers while excluding some by origin", PE,
    "welcome was therefore spoken into a country that was admitting immigrants in unprecedented numbers "
    "while excluding some by origin")
R.q("q_stat", "the History specialist's text says about 5.2 million people entered the United States in the 1880s",
    PE, "About 5.2 million people entered the United States in the 1880s")
R.q("q_memory", "the History specialist's text marks its figures as from memory", PE, "from memory")

R.a("st_no_exclusion", "the sonnet never mentions exclusion", STG(), "the sonnet never mentions exclusion")
R.a("st_stat_context", "the History statistic comes from context, not from the poem", STG(),
    "the statistic comes from context, not the poem")
R.a("gk_exiles", "conventionally, exiles names people forced from their homes", GKG(),
    "conventionally, exiles names people forced from their homes")
R.a("closing_develops", "the closing lines develop this pattern", SIG(), "the closing lines develop this pattern")
R.a("welcome_from_action", "the welcome comes from her action, while the arrivals appear through need and passivity",
    SIG(), "the welcome comes from her action, while the arrivals appear through need and passivity")

R.d("neg_rejects_power", "the negation rejects a power whose conquering limbs span territory",
    ["q_neg_giant", "q_conquer"],
    label="negation opens the contrast: the brazen giant is rejected as a power whose conquering limbs span territory")
R.d("replacement_mother", "the replacement is Mother of Exiles, with the noun Exiles as key word",
    ["q_mother", "q_exiles"],
    label="the replacement is Mother of Exiles, and the key word is the noun Exiles")
R.d("mother_ties_displaced", "the name ties the figure to the displaced rather than to power she holds",
    ["q_mother_word", "gk_exiles"],
    label="Mother implies nurture, so the name ties the figure to the displaced rather than to power she holds")
R.d("power_as_hospitality", "power is exercised as hospitality", ["q_mild_cmd", "q_mild"],
    label="her authority survives in mild eyes command, so power is exercised as hospitality")
R.d("arrivals_need_passive", "the arrivals appear through need and passivity", ["q_homeless", "q_yearning"],
    label="the arrivals are the homeless, tempest-tost, a passive participle, and their only activity is yearning to breathe free")
R.d("figure_acts", "the figure acts", ["q_lamp"],
    label="the figure, by contrast, acts: I lift my lamp beside the golden door")
R.d("history_states_both", "the History specialist states hostility in law and a welcome spoken into an excluding country",
    ["q_hostility", "q_spoken"],
    label="the History specialist states that hostility was written into law and that the welcome was spoken into an excluding country")
R.d("ideal_contradicted", "the universal welcome can be read as an ideal the country's law contradicted",
    ["q_worldwide", "q_hostility"],
    label="the world-wide welcome names no origin, so its universal welcome can be read as an ideal the country's law contradicted")
R.d("reading_plausible", "the reading stays plausible: the sonnet never mentions exclusion and the statistic is from context",
    ["q_stat", "st_no_exclusion", "st_stat_context"],
    label="the reading stays plausible: the sonnet never mentions exclusion, and the statistic comes from context")
R.d("point_p1", T["p1-point"],
    ["neg_rejects_power", "replacement_mother", "mother_ties_displaced", "power_as_hospitality",
     "closing_develops", "arrivals_need_passive", "figure_acts", "welcome_from_action",
     "history_states_both", "ideal_contradicted", "reading_plausible"],
    label=T["p1-point"])
R.d("reported_unverified", "the History figures are reported unverified", ["q_memory"],
    label="so they are reported unverified")

CLAIMS = {}
CLAIMS["p1-point"] = entry(
    R, TASK, "p1-point", RQ, ["point_p1"], T["p1-point"],
    reading=("The point is encoded as the specialist's final link from its supporting claims. "
             "Three strands are encoded separately: the negation and the Mother of Exiles naming (rejection of the "
             "giant's conquest, replacement, power as hospitality); the arrivals and the figure's action "
             "(extension of the welcome to the displaced); and the History account's statements (the welcome spoken "
             "into an excluding country, read as a possibility). Quoted words are grounded in doc-nc or in the relayed "
             "History paragraph peer:hi-p5. The specialist's own links are implications. Two assertions have no listed "
             "supporting claim and stand ungrounded: 'the closing lines develop this pattern' and 'the welcome comes from "
             "her action'. The 'can be read as' modality is kept as written."),
    supports=["q_giant", "q_memory"],
    notes=("Structural statements about the poem (no sonnet mention of exclusion; statistic from context) are "
           "supplied_text, asserted but not checked. Figures from the History paragraph are quoted from peer:hi-p5, "
           "not restated."))

CLAIMS["p1-s13"] = entry(
    R, TASK, "p1-s13", RQ, ["q_memory", "reported_unverified"], T["p1-s13"],
    reading=("The sentence has two parts: the History account marks its figures as 'from memory' (quoted from "
             "peer:hi-p5), and therefore they are reported unverified (one specialist link). The parser lists the whole "
             "preceding report as support for this sentence. Only the from-memory marking bears on it, so only that quote "
             "and the link are encoded."))

write_task(TASK, CLAIMS)
print("wrote", TASK, list(CLAIMS))
