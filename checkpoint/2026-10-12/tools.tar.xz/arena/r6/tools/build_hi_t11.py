import sys
sys.path.insert(0, "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/arena/r6/tools")
from build_lib import Reg, load_claims, load_request, write_task, entry, GKG, SIG

TASK = "hi-t11"
T = load_claims(TASK)
RQ = load_request(TASK)
R = Reg({})
NOTE = ("No supplied text exists for this task. Dates and figures are from memory and are grounded as "
        "general_knowledge, matching the History adapter fixtures; the engine reports them as unverified.")

# h1.2 (analysis, not eligible; a listed support of h1.1, h1.7, h1.8, h1.9)
R.a("relief_dollar_shortage", "the Plan's most direct effect was to relieve the dollar shortage that capped European imports",
    SIG("established"), label="its most direct effect was to relieve the dollar shortage that capped European imports")

# h1.3 (evidence, eligible)
R.a("gk_erp_launch", "the Economic Cooperation Act, signed on 3 April 1948, launched a European Recovery Programme", GKG(),
    label="the Economic Cooperation Act, signed on 3 April 1948, launched a European Recovery Programme")
R.num("erp_13bn", "num_erp_total", "the programme had transferred about 13 billion dollars by mid-1952 (literal equality)",
      "eq", 13000000000, label="transferred about $13 billion in grants and loans by mid-1952")
R.num("uk_3_2bn", "num_uk_received", "the United Kingdom received about 3.2 billion dollars (literal equality)",
      "eq", 3200000000, label="the United Kingdom received about $3.2 billion")
R.num("france_2_7bn", "num_france_received", "France received about 2.7 billion dollars (literal equality)",
      "eq", 2700000000, label="France received about $2.7 billion")

# h1.4 (evidence, eligible)
R.a("gk_dollar_credit", "the dollar credit bought American coal, grain and machinery which European currencies could not buy",
    GKG(), label="that dollar credit bought American coal, grain and machinery which European currencies could not buy")
R.a("gk_devalued_1949", "sterling was devalued on 18 September 1949", GKG(),
    label="sterling was devalued on 18 September 1949")
R.num("rate_before_4_03", "num_sterling_before", "the sterling rate before devaluation was 4.03 dollars",
      "eq", "4.03", sort="Real", label="sterling was devalued from $4.03")
R.num("rate_after_2_80", "num_sterling_after", "the sterling rate after devaluation was 2.80 dollars",
      "eq", "2.80", sort="Real", label="to $2.80")
R.d("constraint_binding_1949", "the dollar constraint was still binding when sterling was devalued",
    ["gk_devalued_1949"], label="the constraint was still binding when sterling was devalued")

# h1.6 (evidence, eligible)
R.a("gk_reform_1948", "West Germany's currency reform of 20 June 1948", GKG(),
    label="West Germany's currency reform of 20 June 1948")
R.a("gk_reform_ended_bm", "the reform ended the black market", GKG(), label="the reform ended the black market")
R.a("gk_reform_before", "the reform came before most Marshall deliveries had arrived", GKG(),
    label="it came before most Marshall deliveries had arrived")
R.d("restored_incentive", "the reform restored the incentive to sell", ["gk_reform_1948", "gk_reform_ended_bm"],
    label="the reform restored the incentive to sell")
R.d("output_revived_before_aid", "output had already begun to revive before most Marshall deliveries",
    ["restored_incentive", "gk_reform_before"], label="output had already begun to revive")

# h1.5 (perspective, not eligible; a listed support of h1.1 and h1.7)
R.a("gk_aid_share", "the aid averaged around 2 to 3 per cent of recipients' combined national income in its heaviest years",
    GKG(), label="the aid averaged around 2 to 3 per cent of recipients' combined national income in its heaviest years")
R.d("aid_insufficient_alone", "the aid was too small beside the economies to have produced recovery by its own weight",
    ["gk_aid_share"], label="the aid was small beside the economies it served and could not by its own weight have produced the recovery")

# Judgements h1.1 (point), h1.7, h1.8, h1.9
R.d("decisive_pace_imports", "the Plan was decisive for the pace and the import capacity of recovery",
    ["relief_dollar_shortage", "gk_dollar_credit"],
    label="the Plan was decisive for the pace and the import capacity of recovery")
R.d("not_origin", "the Plan was not decisive for the origin of recovery", ["output_revived_before_aid", "aid_insufficient_alone"],
    label="the Plan was not decisive for the origin of recovery")
R.d("speed_sig_limited", "the Plan was responsible for the speed of Western European recovery to a significant but limited extent",
    ["decisive_pace_imports", "aid_insufficient_alone"],
    label="the Plan was responsible for the speed of recovery to a significant but limited extent")
R.d("timing_over_occurrence", "the Plan was more responsible for the timing of recovery than for its occurrence",
    ["not_origin"], label="more for the timing of recovery than for its occurrence")
R.d("real_but_partial", "the Plan's responsibility was real but partial", ["decisive_pace_imports", "not_origin"],
    cert="established", label="its responsibility was real but partial")

R.a("counterfactual_stall", "reconstruction would have stalled without dollars", SIG("probable"),
    label="the strongest counter-case, that reconstruction would have stalled without dollars")
R.d("aid_decided_1948_49", "aid decided what could be bought in 1948 and 1949",
    ["gk_dollar_credit", "constraint_binding_1949"],
    label="aid decided what could be bought at all")
R.d("counter_case_1948_49", "the strongest counter-case holds for 1948 and 1949",
    ["counterfactual_stall", "aid_decided_1948_49"], label="the counter-case holds for 1948 and 1949")
R.a("counter_exports_revived", "European exports had revived by 1950", SIG("probable"),
    label="European exports had revived by 1950")
R.a("gk_korea_1950", "the Korean War began on 25 June 1950", GKG(), label="the Korean War, begun on 25 June 1950")
R.d("korea_lifted_orders", "demand from the Korean War lifted orders further", ["gk_korea_1950"],
    label="demand from the Korean War lifted orders further")
R.d("weighs_less_1950_52", "the counter-case weighs less for 1950 to 1952",
    ["counter_exports_revived", "korea_lifted_orders"], label="it weighs less for 1950 to 1952")

# Report claims listed as supports of other judgements; asserted here, chained in their own problems.
R.a("rep_h11", "report claim h1.1: the Plan was responsible to a significant but limited extent", SIG("probable"),
    label=T["h1.1"])
R.a("rep_h17", "report claim h1.7: the strongest counter-case holds for 1948 and 1949", SIG("probable"),
    label=T["h1.7"])
R.a("rep_h18", "report claim h1.8: the counter-case weighs less for 1950 to 1952", SIG("probable"),
    label=T["h1.8"])
R.a("rep_h19", "report claim h1.9: the responsibility was real but partial", SIG("established"),
    label=T["h1.9"])

CLAIMS = {}
CLAIMS["h1.1"] = entry(
    R, TASK, "h1.1", RQ, ["speed_sig_limited", "timing_over_occurrence"], T["h1.1"],
    reading=("The point has two parts: responsibility for the speed of recovery to a significant but limited extent, and "
             "more responsibility for timing than for occurrence. The first is one link from the decisive effect on pace "
             "and imports (direct dollar relief plus dollar credit, general_knowledge) and the small aid share. The second "
             "is one link from the reform-driven revival before aid arrived and the small aid share. The Economic "
             "Cooperation Act and sterling figures are supporting premises from memory."),
    flags=[{"code": "vague_degree",
            "message": "'a significant but limited extent' has no threshold for significant or limited; encoded as the "
                       "two links above rather than a numeric bound.",
            "alternatives": ["responsible for the speed of recovery to a bounded minority share",
                             "decisive for speed but short of decisive for the origin of recovery"]}],
    supports=["gk_erp_launch", "erp_13bn", "uk_3_2bn", "france_2_7bn", "rate_before_4_03", "rate_after_2_80",
              "constraint_binding_1949", "rep_h17", "rep_h18", "rep_h19"],
    notes=NOTE)

CLAIMS["h1.3"] = entry(
    R, TASK, "h1.3", RQ, ["gk_erp_launch", "erp_13bn", "uk_3_2bn", "france_2_7bn"], T["h1.3"],
    reading=("Launch of the programme by the Act on 3 April 1948 and three transfer totals from memory. 'About' is read "
             "as literal equality, so the totals are encoded as exact values; the stated transfer date (mid-1952) is "
             "part of the total's description."),
    flags=[{"code": "vague_quantity",
            "message": "'about $13 billion', '$3.2 billion' and '$2.7 billion' carry no stated tolerance; literal equalities are encoded.",
            "alternatives": ["the totals are exact as written",
                             "the totals are within a tolerance of the stated figures (approximate reading)"]}],
    notes=NOTE)

CLAIMS["h1.4"] = entry(
    R, TASK, "h1.4", RQ,
    ["gk_dollar_credit", "constraint_binding_1949", "rate_before_4_03", "rate_after_2_80", "gk_devalued_1949"], T["h1.4"],
    reading=("The dollar credit's purchases (general_knowledge), the devaluation from 4.03 to 2.80 on 18 September 1949 "
             "(Real equalities from memory), and the claim that the constraint was still binding, as one link from the "
             "devaluation."),
    flags=[],
    notes=NOTE)

CLAIMS["h1.6"] = entry(
    R, TASK, "h1.6", RQ,
    ["output_revived_before_aid", "gk_reform_1948", "gk_reform_ended_bm", "restored_incentive", "gk_reform_before"],
    T["h1.6"],
    reading=("The reform of 20 June 1948 and its effects (ended the black market; came before most deliveries) are "
             "general_knowledge. The reform restoring the incentive to sell is one link. The colon's claim that output had "
             "already begun to revive is one link from the restored incentive and the timing."),
    flags=[],
    notes=NOTE)

CLAIMS["h1.7"] = entry(
    R, TASK, "h1.7", RQ, ["counter_case_1948_49", "aid_decided_1948_49"], T["h1.7"],
    reading=("The counter-case (reconstruction would have stalled without dollars) is asserted by the specialist and "
             "stands ungrounded. It holds for 1948 and 1949 through one link from the claim that aid decided what could be "
             "bought, which follows from the dollar credit and the 1949 binding constraint. The listed supports include the "
             "thesis and the later judgements (h1.1, h1.8, h1.9), which depend on this claim; they are carried as supporting "
             "premises only, not as inputs to its conclusion."),
    flags=[],
    supports=["rep_h11", "relief_dollar_shortage", "erp_13bn", "output_revived_before_aid", "aid_insufficient_alone",
              "rep_h18", "rep_h19"],
    notes=NOTE)

CLAIMS["h1.8"] = entry(
    R, TASK, "h1.8", RQ, ["weighs_less_1950_52"], T["h1.8"],
    reading=("The counter-case weighs less for 1950 to 1952 through one link from two components: European exports had "
             "revived (asserted by the specialist, no listed support) and the Korean War's demand lifted orders (one link "
             "from the war's start date, from memory)."),
    flags=[],
    supports=["rep_h11", "rep_h17", "rep_h19", "relief_dollar_shortage", "aid_insufficient_alone",
              "output_revived_before_aid", "constraint_binding_1949", "erp_13bn"],
    notes=NOTE)

CLAIMS["h1.9"] = entry(
    R, TASK, "h1.9", RQ, ["decisive_pace_imports", "not_origin", "real_but_partial"], T["h1.9"],
    reading=("The judgement has three parts: decisive for pace and import capacity (one link from the direct dollar "
             "relief and dollar credit), not decisive for origin (one link from the pre-aid revival and the small aid "
             "share), and real but partial (one link from the first two). 'Weighed by timing and scale' is the "
             "specialist's framing and is not separately encoded."),
    flags=[],
    supports=["rep_h11", "rep_h17", "rep_h18"],
    notes=NOTE)

write_task(TASK, CLAIMS)
print("wrote", TASK, list(CLAIMS))
