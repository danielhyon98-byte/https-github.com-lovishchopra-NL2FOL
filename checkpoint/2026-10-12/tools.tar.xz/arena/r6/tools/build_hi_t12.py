import sys
sys.path.insert(0, "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/arena/r6/tools")
from build_lib import Reg, load_claims, load_request, write_task, entry, GKG, SIG

TASK = "hi-t12"
T = load_claims(TASK)
RQ = load_request(TASK)
R = Reg({})
NOTE = ("No supplied text exists for this task. Dates and figures are from memory and are grounded as "
        "general_knowledge, matching the History adapter fixtures; the engine reports them as unverified.")

# h1.2 (point, eligible): 1957
R.num("only_one_1957", "num_states_1957", "only one African territory became independent in 1957 (literal equality to 1)",
      "eq", 1, label="In 1957 only one African territory became independent")
R.a("gk_ghana_6mar1957", "the Gold Coast became independent as Ghana on 6 March 1957", GKG(),
    label="the Gold Coast, as Ghana, on 6 March")

# h1.3 (evidence, eligible): Guinea 1958
R.a("gk_guinea_2oct1958", "Guinea followed on 2 October 1958", GKG(), label="In 1958 Guinea followed on 2 October")
R.a("gk_guinea_voted_no", "Guinea voted No in de Gaulle's referendum of 28 September 1958", GKG(),
    label="having voted No in de Gaulle's referendum of 28 September")
R.a("gk_french_withdrawal", "Guinea faced the immediate withdrawal of French aid and personnel", GKG(),
    label="faced the immediate withdrawal of French aid and personnel")

# h1.4 (evidence, eligible): 1960
R.num("states_1960_17", "num_states_1960", "seventeen African states became independent in 1960 (literal equality)",
      "eq", 17, label="when seventeen African states became independent")
R.a("gk_nigeria_1oct1960", "Nigeria became independent on 1 October 1960", GKG(),
    label="Nigeria on 1 October")
R.a("gk_congo_30jun1960", "the Belgian Congo became independent on 30 June 1960", GKG(),
    label="the Belgian Congo on 30 June")
R.a("assume_macmillan", "earlier in 1960 Harold Macmillan told the South African parliament that a 'wind of change' was "
    "blowing through the continent", GKG(), label="Harold Macmillan told the South African parliament that a 'wind of change' was blowing through the continent")
R.d("pace_changed_1960", "the pace of independence changed in 1960", ["states_1960_17"],
    label="The pace changed in 1960")

# h1.5 (evidence, eligible): 1961 to 1968
R.num("states_1961_68_15", "num_states_1961_68", "roughly fifteen states became independent from 1961 to 1968 (literal equality to 15)",
      "eq", 15, label="the flow slowed to roughly fifteen states by 1968")
R.a("gk_tanganyika_1961", "Tanganyika became independent in 1961", GKG(), label="including Tanganyika in 1961")
R.a("gk_kenya_1963", "Kenya became independent in 1963", GKG(), label="Kenya in 1963")
R.a("gk_botswana_1966", "Botswana became independent in 1966", GKG(), label="Botswana in 1966")
R.d("flow_slowed", "the flow of independence slowed from 1961", ["states_1961_68_15"],
    label="from 1961 the flow slowed")

# h1.6 (evidence, eligible): settler resistance
R.a("gk_algeria_1962", "Algeria won independence on 5 July 1962", GKG(), label="Algeria won independence on 5 July 1962")
R.a("gk_algeria_war_1954", "the Algerian war began in 1954", GKG(), label="only after a war that began in 1954")
R.d("algeria_only_after_war", "Algeria won independence only after a war that began in 1954",
    ["gk_algeria_1962", "gk_algeria_war_1954"], label="only after a war that began in 1954")
R.a("gk_rhodesia_udi", "Southern Rhodesia's white government declared independence unilaterally on 11 November 1965",
    GKG(), label="Southern Rhodesia's white government declared independence unilaterally on 11 November 1965")
R.d("settlers_resisted", "settler communities resisted", ["algeria_only_after_war", "gk_rhodesia_udi"],
    label="Settler communities resisted")

# h1.8 (analysis, not eligible; a listed support of h1.2 and h1.7)
R.a("h18_scale_continuation", "the scale of the transfers, and the decision of Britain, France and Belgium to accept "
    "independence as the general course, made the later transfers a continuation rather than a new departure",
    SIG("established"), label="Its scale, and the decision of Britain, France and Belgium to accept independence as the general course, made the later transfers a continuation rather than a new departure")

# h1.7 (judgement, eligible): the turning point
R.d("turning_point_1960", "the decisive turning point was 1960", ["pace_changed_1960", "h18_scale_continuation"],
    label="The decisive turning point was 1960")

# Report claim asserted as a support of h1.2.
R.a("rep_h17", "report claim h1.7: the decisive turning point was 1960", SIG("probable"), label=T["h1.7"])

CLAIMS = {}
CLAIMS["h1.2"] = entry(
    R, TASK, "h1.2", RQ, ["only_one_1957", "gk_ghana_6mar1957"], T["h1.2"],
    reading=("'Only one African territory in 1957' is encoded as a literal equality of the count to 1, and the Gold Coast "
             "as Ghana on 6 March 1957 is general_knowledge. The listed supports (the later independence years, the "
             "1960 pace, the settler wars, the scale judgement and the turning-point judgement) concern other years and "
             "are carried as supporting premises only."),
    flags=[],
    supports=["gk_guinea_2oct1958", "gk_guinea_voted_no", "gk_french_withdrawal", "pace_changed_1960", "flow_slowed",
              "settlers_resisted", "h18_scale_continuation", "rep_h17"],
    notes=NOTE)

CLAIMS["h1.3"] = entry(
    R, TASK, "h1.3", RQ, ["gk_guinea_2oct1958", "gk_guinea_voted_no", "gk_french_withdrawal"], T["h1.3"],
    reading=("Three from-memory facts about Guinea in 1958: independence on 2 October, the No vote in the referendum of "
             "28 September, and the immediate withdrawal of French aid and personnel. The claim states no inference, so it "
             "is a conjunction of general_knowledge premises."),
    flags=[],
    notes=NOTE)

CLAIMS["h1.4"] = entry(
    R, TASK, "h1.4", RQ,
    ["states_1960_17", "gk_nigeria_1oct1960", "gk_congo_30jun1960", "assume_macmillan", "pace_changed_1960"], T["h1.4"],
    reading=("Seventeen states in 1960 (literal equality), Nigeria and the Belgian Congo among them (general_knowledge), "
             "the Macmillan 'wind of change' remark, and one link from the 1960 count to the claim that the pace changed. "
             "The remark's quoted words are not in any supplied text and are encoded as an assumption, not as a quotation "
             "(the schema reserves quotation grounding for supplied texts)."),
    flags=[],
    notes=NOTE + " The quoted phrase 'wind of change' has no supplied text to check against; it is grounded as assumption.")

CLAIMS["h1.5"] = entry(
    R, TASK, "h1.5", RQ,
    ["states_1961_68_15", "gk_tanganyika_1961", "gk_kenya_1963", "gk_botswana_1966", "flow_slowed"], T["h1.5"],
    reading=("'Roughly fifteen states by 1968' is encoded as a literal equality to 15 and the three named independences "
             "are general_knowledge. 'The flow slowed' is one link from the count. The comparison with the 1960 pace is "
             "not stated as a number and is not encoded."),
    flags=[{"code": "vague_quantity",
            "message": "'roughly fifteen states' has no stated tolerance; literal equality to 15 is encoded.",
            "alternatives": ["exactly 15 states from 1961 to 1968",
                             "about 15 states within a tolerance of one or two (approximate reading)"]}],
    notes=NOTE)

CLAIMS["h1.6"] = entry(
    R, TASK, "h1.6", RQ, ["settlers_resisted", "gk_algeria_1962", "gk_algeria_war_1954", "algeria_only_after_war",
                          "gk_rhodesia_udi"], T["h1.6"],
    reading=("Algeria's independence date and the 1954 war's start are general_knowledge; 'only after a war' is one link "
             "from the two. Rhodesia's unilateral declaration is general_knowledge. 'Settler communities resisted' is one "
             "link from the Algerian and Rhodesian facts."),
    flags=[],
    notes=NOTE)

CLAIMS["h1.7"] = entry(
    R, TASK, "h1.7", RQ, ["turning_point_1960"], T["h1.7"],
    reading=("The turning point is one link from the 1960 pace change (count of seventeen states) and the specialist's "
             "scale-and-policy judgement, which the report asserts without a listed support. The listed supports (1957, "
             "1958, the 1960 pace, the later years, the settler wars and the scale judgement) are carried as supporting "
             "premises where they are not already in the chain."),
    flags=[],
    supports=["only_one_1957", "gk_ghana_6mar1957", "gk_guinea_2oct1958", "flow_slowed", "settlers_resisted"],
    notes=NOTE)

write_task(TASK, CLAIMS)
print("wrote", TASK, list(CLAIMS))
