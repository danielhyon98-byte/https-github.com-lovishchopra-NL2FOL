import sys
sys.path.insert(0, "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/arena/r6/tools")
from build_lib import Reg, load_claims, load_request, write_task, entry, GKG, SIG

TASK = "hi-p5"
T = load_claims(TASK)
RQ = load_request(TASK)
R = Reg({})
NOTE = ("No supplied text exists for this task. Dates and figures are from memory and are grounded as "
        "general_knowledge, matching the History adapter fixtures; the engine reports them as unverified.")

R.num("entrants_5_2m", "num_entrants_1880s",
      "about 5.2 million people entered the United States in the 1880s (literal equality)", "eq", 5200000,
      label="About 5.2 million people entered the United States in the 1880s")
R.num("arrivals_1882_near_790k", "num_arrivals_1882",
      "nearly 790,000 people entered the United States in 1882 (literal strict bound below 790,000)", "lt", 790000,
      label="1882 alone brought nearly 790,000")
R.a("trend_se_europe", "arrivals increasingly came from southern and eastern Europe rather than from the north and west",
    GKG(), label="arrivals increasingly came from southern and eastern Europe rather than from the north and west")
R.a("gk_act_1882", "President Chester A. Arthur signed the Chinese Exclusion Act on 6 May 1882", GKG(),
    label="on 6 May 1882 President Chester A. Arthur signed the Chinese Exclusion Act")
R.a("gk_act_10yrs", "the Chinese Exclusion Act suspended Chinese labour immigration for ten years", GKG(),
    label="the Act suspended Chinese labour immigration for ten years")
R.a("gk_lazarus", "Emma Lazarus was a New York writer already active in aid for Jewish refugees from Russia", GKG(),
    label="Emma Lazarus, a New York writer already active in aid for Jewish refugees from Russia")
R.a("gk_sonnet_1883", "Lazarus wrote the sonnet in 1883 for an auction to raise money for the statue's pedestal", GKG(),
    label="she wrote the sonnet in 1883 for an auction to raise money for the statue's pedestal")
R.a("gk_statue_1886", "the statue, a gift from France, was dedicated on 28 October 1886", GKG(),
    label="the statue, a gift from France, was dedicated on 28 October 1886")

# Report claims listed as supports of h1.2; asserted here, chained in their own problems.
R.a("sup_h13", "report claim h1.3: hostility was written into law by the Chinese Exclusion Act", SIG("probable"),
    label=T["h1.3"])
R.a("sup_h14", "report claim h1.4: Lazarus and the 1883 sonnet, statue dedicated in 1886", SIG("probable"),
    label=T["h1.4"])
R.a("sup_h15", "report claim h1.5: the welcome was spoken into an excluding country", SIG("established"),
    label=T["h1.5"])

R.d("hostility_in_law", "hostility toward one group was already written into law", ["gk_act_1882", "gk_act_10yrs"],
    label="hostility toward one group was already written into law")
R.d("admitting_unprecedented", "the country was admitting immigrants in unprecedented numbers", ["entrants_5_2m"],
    label="the country was admitting immigrants in unprecedented numbers")
R.d("welcome_spoken_excluding", T["h1.5"], ["admitting_unprecedented", "hostility_in_law", "gk_sonnet_1883"],
    cert="established", label=T["h1.5"])

CLAIMS = {}
CLAIMS["h1.2"] = entry(
    R, TASK, "h1.2", RQ, ["entrants_5_2m", "arrivals_1882_near_790k", "trend_se_europe"], T["h1.2"],
    reading=("The claim has three figures and a trend, all from memory with no supplied text. 'About 5.2 million' is "
             "encoded as a literal equality and 'nearly 790,000' as a strict bound below 790,000. The trend is "
             "general_knowledge. The listed supports h1.3 to h1.5 do not derive these figures; they are carried as "
             "supporting premises only."),
    flags=[{"code": "vague_quantity",
            "message": "'About 5.2 million' and 'nearly 790,000' carry no stated tolerance; literal equality and strict bound are encoded.",
            "alternatives": ["the total is exactly 5,200,000",
                             "the total is within a tolerance of 5,200,000 (approximate reading)"]}],
    supports=["sup_h13", "sup_h14", "sup_h15"],
    notes=NOTE)

CLAIMS["h1.3"] = entry(
    R, TASK, "h1.3", RQ, ["hostility_in_law", "gk_act_1882", "gk_act_10yrs"], T["h1.3"],
    reading=("The Act's signing date and signatory, and its ten-year suspension of Chinese labour immigration, are "
             "from-memory facts (general_knowledge). 'Hostility was already written into law' is one specialist link "
             "from those two facts."),
    flags=[],
    notes=NOTE)

CLAIMS["h1.4"] = entry(
    R, TASK, "h1.4", RQ, ["gk_lazarus", "gk_sonnet_1883", "gk_statue_1886"], T["h1.4"],
    reading=("Three from-memory facts: Lazarus's context, the 1883 sonnet written for a pedestal auction, and the "
             "statue's gift and dedication date. No inference is stated, so the claim is a conjunction of "
             "general_knowledge premises."),
    flags=[],
    notes=NOTE)

CLAIMS["h1.5"] = entry(
    R, TASK, "h1.5", RQ, ["welcome_spoken_excluding"], T["h1.5"],
    reading=("'Therefore' is one specialist link from three antecedents: the admitting of immigrants in unprecedented "
             "numbers (from the 5.2 million figure), the hostility written into law (from the Chinese Exclusion Act facts), "
             "and the 1883 sonnet context. The report gives 'unprecedented' no comparator, so the link carries that "
             "gap; the trend and the Lazarus and statue facts are carried as supporting premises."),
    flags=[],
    supports=["trend_se_europe", "gk_lazarus", "gk_statue_1886"],
    notes=NOTE)

write_task(TASK, CLAIMS)
print("wrote", TASK, list(CLAIMS))
