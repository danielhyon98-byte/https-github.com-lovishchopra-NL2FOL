# Arena r1 (QUALIFIED: 1 of 17 recorded translations not served; 16 served by claim id only)

Transmissions: 30; functional: 30 (100.0%). This is the transport measure only: fixture coverage, translation fidelity and the claim counts are separate measures (below), never combined with it into one rate.

Genuine transmissions, peer relays and combinator syntheses: 8. With an error-level finding: 4 (en-t1.json [synthesis syn-en-t1]: INT-LEDGER-001 ['s2', 'p3-s02']; en-t2.json [synthesis syn-en-t2]: INT-LEDGER-025 ['s1', 'p2-point', 'p2-q01', 'p2-q02', 'p2-s02', 'p2-q03', 'p2-q04', 'p2-s03', 'p2-q05', 'p2-s04', 'p2-s05', 'p2-q06', 'p2-s06']; hi-t1.json [synthesis syn-hi-t1]: INT-LEDGER-003 ['s0', 'h1.1'], INT-LEDGER-003 ['s1', 'h1.2', 'h1.3', 'h1.4', 'h2.1'], INT-LEDGER-003 ['s2', 'h1.5', 'h1.6'], INT-LEDGER-003 ['s3', 'h1.7']; hi-t2.json [synthesis syn-hi-t2]: INT-LEDGER-003 ['s1', 'h1.2', 'h1.3', 'h1.4'], INT-LEDGER-003 ['s2', 'h2.1', 'h2.2', 'h2.3', 'h2.4']), of which 4 counted functional. With warning-level findings only: 4, of which 4 counted functional. The rate does not judge whether a finding is true: a false error on a correct statement is counted functional like a true one, so read every finding in the genuine section below.

## Measures (each on its own denominator; none is combined with another into one rate)

- Transport (functional transmissions): 30 of 30 (100.0%). Genuine traffic delivered and decided: 8 of 8 (genuine replies 4, peer relays 0, syntheses 4); injected faults named: 22 of 22 mutation records. Transport says the hub delivered and decided every transmission; it does not judge whether a finding is true, whether a translation is faithful or whether an answer is better.
- Fixture coverage (recorded translations served in this run): 16 of 17 served; NOT SERVED: 1 (1 claim not eligible under the current policy). Of the 16 served, 0 were bound to a recorded claim-text digest and 16 by claim id only.
- Translation fidelity (faithful translations where adjudicated): not adjudicated; the round has no adjudications/translation_fidelity.json, so no fidelity figure applies to this run.
- Claims (genuine pass, each delivered claim once): extracted 71; eligible for translation 26; attempted 16; completed (a definitive verdict displayed) 3; faithful: not adjudicated; approved (displayed ENTAILED with no error-level finding on the claim; not a release decision) 3, of which 3 rest on at least one ungrounded premise and 3 on at least one unresolved dependency (ungrounded, or authority no check validated); release permitted by the release assessment (the application's rule, apart from the formal status) 0. Eligible claims with no translation attempted: 10.
- Latency (hub processing per transmission in this run, on this machine; not a stress measurement): genuine traffic median 176 ms, 95th percentile 377 ms, max 377 ms over 8; injected faults median 234 ms, 95th percentile 350 ms, max 410 ms over 22.
- Cost: no translation provider was called (recorded fixtures only).
- Replay configuration (what a recording cannot run as production does is named, never counted as run): the task record of each request is passed to the translator, as production passes it (16 of 16 genuine translations validated against it); 0 served translations bound to a recorded claim-text digest, 16 by claim id only; retries NOT exercised (a recorded translation is one output, so a retry is served the same output and the outcome is the first attempt's) on 1 genuine claim(s): hi-t2.json h2.2 (6 over every variant); syntheses stamped at relay time.
- QUALIFIED (TRANSLATIONS_LOST): 1 of 17 recorded translations were not served in this run (1 claim not eligible under the current policy); translation outcomes cover the 16 served, so this run is not a translation regression over the recorded round.
- QUALIFIED (FIXTURES_UNBOUND): 16 of the 16 served translations carry no recorded claim-text digest: each is bound to the text its claim id carries in this run, which may not be the sentence it was produced for (record the digests with the translations when they are recorded: scripts/arena/bind_translations.py).

| variant | functional | total |
| --- | --- | --- |
| genuine | 4 | 4 |
| synthesis | 4 | 4 |
| invented_quotation | 4 | 4 |
| invented_quotation_single | 4 | 4 |
| altered_quotation | 2 | 2 |
| self_certification | 4 | 4 |
| wrong_arithmetic | 4 | 4 |
| chronology_error | 4 | 4 |

## Translation outcomes (provider-dependent; genuine pass, one outcome per eligible claim with a fixture)

- AMBIGUOUS_TRANSLATION: 12 (12 distinct claims)
- ENTAILED: 3 (3 distinct claims)
- INVALID_FORMALIZATION: 1 (1 distinct claims)
- NOT_ELIGIBLE: 1 (1 distinct claims)
- ENTAILED verdicts resting only on ungrounded premises: 2 of 3: en-t1.json p1-s01, en-t2.json p1-s01
- encodings given no verdict on genuine claims (displayed INVALID_FORMALIZATION: a definitive engine status withheld, or the encoding rejected at translation): 1; E108 vacuous result: 0; E110 unasserted figure: 0; E111 unencoded reason: 0; E112 circular encoding: 1 (hi-t2.json h2.2 (rejected at translation)); stated precision: 0; exactness: 0
- advisory coverage warnings on genuine claims (the verdict on the encoding stands; the encoding leaves a figure or symbol open that no source asserts; a coverage measure, not a verdict): 2; W110 unasserted figure, advisory: 0; W111 unconstrained symbol, advisory: 2 (en-t2.json p4-point (AMBIGUOUS_TRANSLATION), hi-t2.json h1.1 (AMBIGUOUS_TRANSLATION))
- definitive verdicts other than ENTAILED displayed on genuine claims (each is shown to the router as the engine's verdict on the claim's encoding: COUNTEREXAMPLE, the claim does not follow from its premises; INCONSISTENT_PREMISES, its premises conflict): 0
- all variants together (the same claims repeated): {'AMBIGUOUS_TRANSLATION': 77, 'ENTAILED': 21, 'NOT_ELIGIBLE': 6, 'INVALID_FORMALIZATION': 6}

## Genuine transmissions, peer relays and combinator syntheses carrying error- or warning-level findings (correct against a specialist's or the combinator's fault, or a false finding: read the message)

- en-t1.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['ES-STR-001', 'ES-STY-003', 'INT-ARG-001', 'INT-REQ-005', 'INT-REQ-006']
  - warning INT-REQ-005 []: constraint c3 not satisfied: measured 4 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several)
  - warning INT-REQ-006 ['p2-point']: claim p2-point's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['p3-point']: claim p3-point's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-ARG-001 ['p4-point']: lack_of_evidence [EVD-LACK-001]: the point rests on p_maj (the majority's reassignment of the victim (stated in the point; chain in p3-point)), which cites no source, and no check verified it in this process: nothing in the supplied texts or the task supports it
  - warning INT-ARG-001 ['p1-s01']: lack_of_evidence [EVD-LACK-001]: the point rests on sup_p2, sup_p3, sup_p4 (the lawyer's thesis shows the code decides the legal defence (p2-point); the town's verdict follows the same logic (p3-point); the legal process reproduces communal judgement (p4-point)), which cites no source, and no check verified it in this process: nothing in the supplied texts or the task supports it
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
  - warning ES-STY-003 ['p3-q01']: paragraph 3, sentence 2 is only a quotation ('"For the immense majority of people there was only one victim: Bayardo San Ro...'); every quotation should be embedded in a sentence of the writer's own
- en-t1.json [synthesis syn-en-t1] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-001'], warnings ['INT-SYNTH-012']
  - error INT-LEDGER-001 ['s2', 'p3-s02']: synthesized claim cites unknown source claims ['p3-s02']
  - warning INT-SYNTH-012 ['s1', 'p2-point', 'p2-q01', 'p2-s02', 'p2-q02', 'p2-s03', 'p2-s04', 'p2-q03', 'p2-s05', 'p2-s06']: material claim produced by 'merged' from ['p2-point', 'p2-q01', 'p2-s02', 'p2-q02', 'p2-s03', 'p2-s04', 'p2-q03', 'p2-s05', 'p2-s06']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'p3-point', 'p3-q01', 'p3-s02', 'p3-q02', 'p3-q03', 'p3-s03', 'p3-s04', 'p3-q04', 'p3-s05', 'p3-q05', 'p3-s06', 'p3-q06', 'p3-q07', 'p3-s07', 'p3-s08']: material claim produced by 'merged' from ['p3-point', 'p3-q01', 'p3-s02', 'p3-q02', 'p3-q03', 'p3-s03', 'p3-s04', 'p3-q04', 'p3-s05', 'p3-q05', 'p3-s06', 'p3-q06', 'p3-q07', 'p3-s07', 'p3-s08']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s3', 'p4-point', 'p4-s02']: material claim produced by 'merged' from ['p4-point', 'p4-s02']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- en-t2.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['ES-STR-001', 'INT-ARG-001', 'INT-REQ-005', 'INT-REQ-006']
  - warning INT-REQ-005 []: constraint c4 not satisfied: measured 4 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several)
  - warning INT-REQ-006 ['p2-point']: claim p2-point's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['p3-point']: claim p3-point's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['p4-point']: claim p4-point's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned COUNTEREXAMPLE, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-ARG-001 ['p1-s01']: lack_of_evidence [EVD-LACK-001]: the point rests on sup_p2, sup_p3, sup_p4 (the declaration makes the separation explicit (p2-point); the physical detail works against the declared innocence (p3-point); verdicts rest on honour and detail keeps guilt in view (p4-point)), which cites no source, and no check verified it in this process: nothing in the supplied texts or the task supports it
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
- en-t2.json [synthesis syn-en-t2] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-025'], warnings ['INT-SYNTH-012']
  - error INT-LEDGER-025 ['s1', 'p2-point', 'p2-q01', 'p2-q02', 'p2-s02', 'p2-q03', 'p2-q04', 'p2-s03', 'p2-q05', 'p2-s04', 'p2-s05', 'p2-q06', 'p2-s06']: synthesized claim ('merged') quotes ["We killed him openly, but we're innocent"], which occur in none of the supplied texts, the cited reports or its cited source claims ['p2-point', 'p2-q01', 'p2-q02', 'p2-s02', 'p2-q03', 'p2-q04', 'p2-s03', 'p2-q05', 'p2-s04', 'p2-s05', 'p2-q06', 'p2-s06']: an altered or invented quotation
  - warning INT-SYNTH-012 ['s1', 'p2-point', 'p2-q01', 'p2-q02', 'p2-s02', 'p2-q03', 'p2-q04', 'p2-s03', 'p2-q05', 'p2-s04', 'p2-s05', 'p2-q06', 'p2-s06']: material claim produced by 'merged' from ['p2-point', 'p2-q01', 'p2-q02', 'p2-s02', 'p2-q03', 'p2-q04', 'p2-s03', 'p2-q05', 'p2-s04', 'p2-s05', 'p2-q06', 'p2-s06']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'p3-point', 'p3-q01', 'p3-q02', 'p3-s02', 'p3-s03', 'p3-q03', 'p3-s04', 'p3-q04', 'p3-q05', 'p3-s05', 'p3-s06']: material claim produced by 'merged' from ['p3-point', 'p3-q01', 'p3-q02', 'p3-s02', 'p3-s03', 'p3-q03', 'p3-s04', 'p3-q04', 'p3-q05', 'p3-s05', 'p3-s06']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s3', 'p4-point', 'p4-q01', 'p4-s02', 'p4-s03']: material claim produced by 'merged' from ['p4-point', 'p4-q01', 'p4-s02', 'p4-s03']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- hi-t1.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-REQ-006']
  - warning INT-REQ-006 ['h1.1']: claim h1.1's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned COUNTEREXAMPLE, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.2']: claim h1.2's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.5']: claim h1.5's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned COUNTEREXAMPLE, which the outcome does not show), so the router must not read the claim as checked
- hi-t1.json [synthesis syn-hi-t1] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-003'], warnings ['INT-LEDGER-010', 'INT-LEDGER-024', 'INT-LEDGER-027', 'INT-SYNTH-012']
  - error INT-LEDGER-003 ['s0', 'h1.1']: certainty inflated: synthesis says 'established' but the weakest source is rank 2 (['probable'])
  - warning INT-LEDGER-027 ['s0', 'h1.1']: synthesized claim ('carried') states dated or quantified items ['1928'] of source claims ['h1.1'] that the specialist labelled from memory (['a note of its report labels its dates and figures from memory']), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-LEDGER-010 ['s0', 'h1.1']: claim marked 'carried' but its text differs from the source; record it as 'paraphrased' or a new linked claim
  - error INT-LEDGER-003 ['s1', 'h1.2', 'h1.3', 'h1.4', 'h2.1']: certainty inflated: synthesis says 'established' but the weakest source is rank 2 (['probable', 'established', 'probable', 'established'])
  - warning INT-LEDGER-024 ['s1', 'h1.2', 'h1.3', 'h1.4', 'h2.1']: figures or dates ['107', '18.3', '1930', 'september 1930'] of the cited sources ['h1.2', 'h1.3', 'h1.4', 'h2.1'] do not appear in the 'merged' synthesized claim or in any other synthesized claim citing those sources; the dated or quantified content of those sources was left out of the combined claim
  - error INT-LEDGER-003 ['s2', 'h1.5', 'h1.6']: certainty inflated: synthesis says 'established' but the weakest source is rank 2 (['probable', 'established'])
  - warning INT-LEDGER-027 ['s2', 'h1.5']: synthesized claim ('merged') states dated or quantified items ['10.6', '16.9', '1928', '1932', '33.1', 'november 1932'] of source claims ['h1.5'] that the specialist labelled from memory (['a note of its report labels its dates and figures from memory']), without the label: the qualification was dropped, so the router reads those items as unqualified
  - error INT-LEDGER-003 ['s3', 'h1.7']: certainty inflated: synthesis says 'established' but the weakest source is rank 2 (['probable'])
  - warning INT-LEDGER-027 ['s3', 'h1.7']: synthesized claim ('carried') states dated or quantified items ['1933', 'january 1933'] of source claims ['h1.7'] that the specialist labelled from memory (['a note of its report labels its dates and figures from memory']), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-SYNTH-012 ['s1', 'h1.2', 'h1.3', 'h1.4', 'h2.1']: material claim produced by 'merged' from ['h1.2', 'h1.3', 'h1.4', 'h2.1']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'h1.5', 'h1.6']: material claim produced by 'merged' from ['h1.5', 'h1.6']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- hi-t2.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['HI-STR-001', 'INT-REQ-006']
  - warning INT-REQ-006 ['h1.1']: claim h1.1's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned COUNTEREXAMPLE, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.2']: claim h1.2's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h1.4']: claim h1.4's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h2.1']: claim h2.1's verification gave no verdict: its outcome is displayed AMBIGUOUS_TRANSLATION (translation AMBIGUOUS_TRANSLATION; the engine returned ENTAILED, which the outcome does not show), so the router must not read the claim as checked
  - warning INT-REQ-006 ['h2.2']: claim h2.2's verification gave no verdict: its outcome is displayed INVALID_FORMALIZATION (translation INVALID_FORMALIZATION; no engine result was produced), so the router must not read the claim as checked
  - warning HI-STR-001 ['h1.1', 'h1.2', 'h1.3', 'h1.4']: body paragraph 1 has no judgement move (counter-case weighed by a criterion)
- hi-t2.json [synthesis syn-hi-t2] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-003'], warnings ['INT-SYNTH-012']
  - error INT-LEDGER-003 ['s1', 'h1.2', 'h1.3', 'h1.4']: certainty inflated: synthesis says 'established' but the weakest source is rank 2 (['probable', 'probable', 'probable'])
  - error INT-LEDGER-003 ['s2', 'h2.1', 'h2.2', 'h2.3', 'h2.4']: certainty inflated: synthesis says 'established' but the weakest source is rank 2 (['established', 'probable', 'established', 'established'])
  - warning INT-SYNTH-012 ['s1', 'h1.2', 'h1.3', 'h1.4']: material claim produced by 'merged' from ['h1.2', 'h1.3', 'h1.4']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'h2.1', 'h2.2', 'h2.3', 'h2.4']: material claim produced by 'merged' from ['h2.1', 'h2.2', 'h2.3', 'h2.4']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked

## Recorded peer relays (relayed/<task>.json) compared with the current parse of the peer's raw text (the genuine pass delivers the current parse; the recording is the dependent agent's document only)

(no recorded relay)

## Mutations: findings beyond the genuine record that do not name the injection (a consequence of the injected words, such as a word bound crossed, or a wrong receipt: read the message)

- en-t1.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q01', 'p4-s03']
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence (genuine record: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence)
- en-t1.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q01', 'p4-s03']
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence (genuine record: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence)
- en-t2.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q02', 'p4-s04']
  - lost from the genuine record: warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
- en-t2.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q02', 'p4-s04']
  - lost from the genuine record: warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
- hi-t1.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['h2.2']
  - warning INT-REQ-005 []: constraint c3 not satisfied: measured 2 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several) (genuine record: measured 1 paragraphs; bound max_paragraphs 1; solver ENTAILED; the mutation added 17 words)
- hi-t1.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['h2.2']
  - warning INT-REQ-005 []: constraint c3 not satisfied: measured 2 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several) (genuine record: measured 1 paragraphs; bound max_paragraphs 1; solver ENTAILED; the mutation added 17 words)
- hi-t1.json [wrong_arithmetic] ACCEPTED_WITH_FINDINGS: injected claims ['h2.2']
  - warning INT-REQ-005 []: constraint c3 not satisfied: measured 2 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several) (genuine record: measured 1 paragraphs; bound max_paragraphs 1; solver ENTAILED; the mutation added 13 words)
- hi-t1.json [chronology_error] ACCEPTED_WITH_FINDINGS: injected claims ['h2.2']
  - warning INT-REQ-005 []: constraint c3 not satisfied: measured 2 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several) (genuine record: measured 1 paragraphs; bound max_paragraphs 1; solver ENTAILED; the mutation added 16 words)
- hi-t2.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['h2.6']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 254 words (8 words of note or meta-text blocks excluded, as for paragraphs); bound max_words 250; solver COUNTEREXAMPLE (genuine record: measured 237 words (8 words of note or meta-text blocks excluded, as for paragraphs); bound max_words 250; solver ENTAILED; the mutation added 17 words)
- hi-t2.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['h2.6']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 254 words (8 words of note or meta-text blocks excluded, as for paragraphs); bound max_words 250; solver COUNTEREXAMPLE (genuine record: measured 237 words (8 words of note or meta-text blocks excluded, as for paragraphs); bound max_words 250; solver ENTAILED; the mutation added 17 words)
- hi-t2.json [chronology_error] ACCEPTED_WITH_FINDINGS: injected claims ['h2.6']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 253 words (8 words of note or meta-text blocks excluded, as for paragraphs); bound max_words 250; solver COUNTEREXAMPLE (genuine record: measured 237 words (8 words of note or meta-text blocks excluded, as for paragraphs); bound max_words 250; solver ENTAILED; the mutation added 16 words)

## Delivery decisions (delivery policy delivery-v1: 240 s translation budget, overseer-selected fallback above 0.9; docs/DELIVERY.md)

Each genuine answer is replayed on a hub of its own with the transfer auditor attached and decided by the delivery policy. Overseer agents: not configured (the harness calls no model): the fallback establishes no accuracy. A separate measure: it changes no transport count. Modes: formally_checked 0, overseer_selected 0, not_checked 0, withheld 4; receipts identical to the genuine records' (status and codes): 4 of 4; the pass took 7.502 s.

| task | mode | time to decision (s) | translation (s) | overseer (s) | candidates (accuracy) | chosen | why |
| --- | --- | --- | --- | --- | --- | --- | --- |
| en-t1.json | withheld | 1.558 | 1.511 | - | english-specialist 0/4 | - | claim p2-point: unresolved (translation AMBIGUOUS_TRANSLATION; the translation carries ambiguity flags: pronoun_this; display status AMBIGUOUS_TRANSLATION: no d… |
| en-t2.json | withheld | 1.615 | 1.576 | - | english-specialist 0/4 | - | claim p2-point: unresolved (translation AMBIGUOUS_TRANSLATION; the translation carries ambiguity flags: this_separation_referent, support_not_feeding; display s… |
| hi-t1.json | withheld | 2.572 | 2.550 | - | history-specialist 0/3 | - | claim h1.1: unresolved (translation AMBIGUOUS_TRANSLATION; the translation carries ambiguity flags: above_all_vs_large_degree, because_causal_or_evidential, uns… |
| hi-t2.json | withheld | 1.738 | 1.715 | - | history-specialist 0/4 | - | claim h1.1: unresolved (translation AMBIGUOUS_TRANSLATION; the translation carries ambiguity flags: trigger_vs_cause, qualifier_unsupported; display status AMBI… |

## Failures

(none)