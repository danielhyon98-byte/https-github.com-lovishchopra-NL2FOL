# Arena r1

Transmissions: 30; functional: 30 (100.0%)

Genuine transmissions, peer relays and combinator syntheses: 8. With an error-level finding: 3 (en-t2.json [synthesis syn-en-t2]: INT-LEDGER-025 ['s1', 'p2-point', 'p2-q01', 'p2-q02', 'p2-s02', 'p2-q03', 'p2-q04', 'p2-s03', 'p2-q05', 'p2-s04', 'p2-s05', 'p2-q06', 'p2-s06']; hi-t1.json [synthesis syn-hi-t1]: INT-LEDGER-003 ['s0', 'h1.1'], INT-LEDGER-003 ['s1', 'h1.2', 'h1.3', 'h1.4', 'h2.1'], INT-LEDGER-003 ['s2', 'h1.5', 'h1.6'], INT-LEDGER-003 ['s3', 'h1.7']; hi-t2.json [synthesis syn-hi-t2]: INT-LEDGER-003 ['s1', 'h1.2', 'h1.3', 'h1.4'], INT-LEDGER-003 ['s2', 'h2.1', 'h2.2', 'h2.3', 'h2.4']), of which 3 counted functional. With warning-level findings only: 4, of which 4 counted functional. The rate does not judge whether a finding is true: a false error on a correct statement is counted functional like a true one, so read every finding in the genuine section below.

| variant | functional | total |
| --- | --- | --- |
| genuine | 4 | 4 |
| synthesis | 4 | 4 |
| invented_quotation | 4 | 4 |
| invented_quotation_single | 4 | 4 |
| altered_quotation | 2 | 2 |
| self_certification | 4 | 4 |
| wrong_arithmetic | 4 | 4 |
| chronology_error | 4 | 4 |

## Translation outcomes (provider-dependent; genuine pass, one outcome per eligible claim with a fixture)

- AMBIGUOUS_TRANSLATION: 11 (11 distinct claims)
- ENTAILED: 4 (4 distinct claims)
- INVALID_FORMALIZATION: 1 (1 distinct claims)
- NOT_ELIGIBLE: 1 (1 distinct claims)
- ENTAILED verdicts resting only on ungrounded premises: 3 of 4: en-t1.json p1-s01, en-t2.json p1-s01, hi-t2.json h1.4
- encodings given no verdict on genuine claims (displayed INVALID_FORMALIZATION: a definitive engine status withheld, or the encoding rejected at translation): 1; E108 vacuous result: 0; E110 unasserted figure: 0; E111 unencoded reason: 0; E112 circular encoding: 1 (hi-t2.json h2.2 (rejected at translation)); stated precision: 0
- definitive verdicts other than ENTAILED displayed on genuine claims (each is shown to the router as the engine's verdict on the claim's encoding: COUNTEREXAMPLE, the claim does not follow from its premises; INCONSISTENT_PREMISES, its premises conflict): 0
- all variants together (the same claims repeated): {'AMBIGUOUS_TRANSLATION': 71, 'ENTAILED': 27, 'NOT_ELIGIBLE': 6, 'INVALID_FORMALIZATION': 6}

## Genuine transmissions, peer relays and combinator syntheses carrying error- or warning-level findings (correct against a specialist's or the combinator's fault, or a false finding: read the message)

- en-t1.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['ES-STR-001', 'ES-STY-003', 'INT-REQ-005']
  - warning INT-REQ-005 []: constraint c3 not satisfied: measured 4 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several)
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
  - warning ES-STY-003 ['p3-q01']: paragraph 3, sentence 2 is only a quotation ('"For the immense majority of people there was only one victim: Bayardo San Ro...'); every quotation should be embedded in a sentence of the writer's own
- en-t1.json [synthesis syn-en-t1] ACCEPTED_WITH_FINDINGS: errors [], warnings ['INT-SYNTH-012']
  - warning INT-SYNTH-012 ['s1', 'p2-point', 'p2-q01', 'p2-s02', 'p2-q02', 'p2-s03', 'p2-s04', 'p2-q03', 'p2-s05', 'p2-s06']: material claim produced by 'merged' from ['p2-point', 'p2-q01', 'p2-s02', 'p2-q02', 'p2-s03', 'p2-s04', 'p2-q03', 'p2-s05', 'p2-s06']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'p3-point', 'p3-q01', 'p3-q02', 'p3-q03', 'p3-s03', 'p3-s04', 'p3-q04', 'p3-s05', 'p3-q05', 'p3-s06', 'p3-q06', 'p3-q07', 'p3-s07', 'p3-s08']: material claim produced by 'merged' from ['p3-point', 'p3-q01', 'p3-q02', 'p3-q03', 'p3-s03', 'p3-s04', 'p3-q04', 'p3-s05', 'p3-q05', 'p3-s06', 'p3-q06', 'p3-q07', 'p3-s07', 'p3-s08']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s3', 'p4-point', 'p4-s02']: material claim produced by 'merged' from ['p4-point', 'p4-s02']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- en-t2.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['ES-STR-001', 'INT-GLOSSARY-005', 'INT-REQ-005']
  - warning INT-REQ-005 []: constraint c4 not satisfied: measured 4 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several)
  - warning INT-GLOSSARY-005 ['p1-s01', 'p4-point']: symbol 'p2p' (Bool) is glossed with different meanings across claims: "p2-point: the twins' declaration makes the separation explicit" in 'p4-point' vs "p2-point: the twins' declaration makes the separation of guilt and innocence explicit" in 'p1-s01' (only the second states ['guilt', 'innocenc']); the consistency check reads them as different quantities (the symbol is renamed apart per claim), so no contradiction is charged on this shared name; one name for two quantities is a translation fault, not the specialist's (claims ['p4-point'] are AMBIGUOUS_TRANSLATION: their pooled formalization is one assumed reading, not a fixed one)
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
- en-t2.json [synthesis syn-en-t2] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-025'], warnings ['INT-GLOSSARY-005', 'INT-SYNTH-012']
  - error INT-LEDGER-025 ['s1', 'p2-point', 'p2-q01', 'p2-q02', 'p2-s02', 'p2-q03', 'p2-q04', 'p2-s03', 'p2-q05', 'p2-s04', 'p2-s05', 'p2-q06', 'p2-s06']: synthesized claim ('merged') quotes ["We killed him openly, but we're innocent"], which occur in none of the supplied texts, the cited reports or its cited source claims ['p2-point', 'p2-q01', 'p2-q02', 'p2-s02', 'p2-q03', 'p2-q04', 'p2-s03', 'p2-q05', 'p2-s04', 'p2-s05', 'p2-q06', 'p2-s06']: an altered or invented quotation
  - warning INT-GLOSSARY-005 ['p1-s01', 'p4-point']: symbol 'p2p' (Bool) is glossed with different meanings across claims: "p2-point: the twins' declaration makes the separation explicit" in 'p4-point' vs "p2-point: the twins' declaration makes the separation of guilt and innocence explicit" in 'p1-s01' (only the second states ['guilt', 'innocenc']); the consistency check reads them as different quantities (the symbol is renamed apart per claim), so no contradiction is charged on this shared name; one name for two quantities is a translation fault, not the specialist's (claims ['p4-point'] are AMBIGUOUS_TRANSLATION: their pooled formalization is one assumed reading, not a fixed one)
  - warning INT-SYNTH-012 ['s1', 'p2-point', 'p2-q01', 'p2-q02', 'p2-s02', 'p2-q03', 'p2-q04', 'p2-s03', 'p2-q05', 'p2-s04', 'p2-s05', 'p2-q06', 'p2-s06']: material claim produced by 'merged' from ['p2-point', 'p2-q01', 'p2-q02', 'p2-s02', 'p2-q03', 'p2-q04', 'p2-s03', 'p2-q05', 'p2-s04', 'p2-s05', 'p2-q06', 'p2-s06']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'p3-point', 'p3-q01', 'p3-q02', 'p3-s02', 'p3-s03', 'p3-q03', 'p3-s04', 'p3-q04', 'p3-q05', 'p3-s05', 'p3-s06']: material claim produced by 'merged' from ['p3-point', 'p3-q01', 'p3-q02', 'p3-s02', 'p3-s03', 'p3-q03', 'p3-s04', 'p3-q04', 'p3-q05', 'p3-s05', 'p3-s06']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s3', 'p4-point', 'p4-q01', 'p4-s02', 'p4-s03']: material claim produced by 'merged' from ['p4-point', 'p4-q01', 'p4-s02', 'p4-s03']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- hi-t1.json [synthesis syn-hi-t1] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-003'], warnings ['INT-LEDGER-010', 'INT-LEDGER-024', 'INT-LEDGER-027', 'INT-SYNTH-012']
  - error INT-LEDGER-003 ['s0', 'h1.1']: certainty inflated: synthesis says 'established' but the weakest source is rank 2 (['probable'])
  - warning INT-LEDGER-027 ['s0', 'h1.1']: synthesized claim ('carried') states dated or quantified items ['1928'] of source claims ['h1.1'] that the specialist labelled from memory (['a note of its report labels its dates and figures from memory']), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-LEDGER-010 ['s0', 'h1.1']: claim marked 'carried' but its text differs from the source; record it as 'paraphrased' or a new linked claim
  - error INT-LEDGER-003 ['s1', 'h1.2', 'h1.3', 'h1.4', 'h2.1']: certainty inflated: synthesis says 'established' but the weakest source is rank 2 (['probable', 'established', 'probable', 'established'])
  - warning INT-LEDGER-024 ['s1', 'h1.2', 'h1.3', 'h1.4', 'h2.1']: figures or dates ['107', '18.3', '1930', 'september 1930'] of the cited sources ['h1.2', 'h1.3', 'h1.4', 'h2.1'] do not appear in the 'merged' synthesized claim or in any other synthesized claim citing those sources; the dated or quantified content of those sources was left out of the combined claim
  - error INT-LEDGER-003 ['s2', 'h1.5', 'h1.6']: certainty inflated: synthesis says 'established' but the weakest source is rank 2 (['probable', 'established'])
  - warning INT-LEDGER-027 ['s2', 'h1.5']: synthesized claim ('merged') states dated or quantified items ['10.6', '16.9', '1928', '1932', '33.1', 'november 1932'] of source claims ['h1.5'] that the specialist labelled from memory (['a note of its report labels its dates and figures from memory']), without the label: the qualification was dropped, so the router reads those items as unqualified
  - error INT-LEDGER-003 ['s3', 'h1.7']: certainty inflated: synthesis says 'established' but the weakest source is rank 2 (['probable'])
  - warning INT-LEDGER-027 ['s3', 'h1.7']: synthesized claim ('carried') states dated or quantified items ['1933', 'january 1933'] of source claims ['h1.7'] that the specialist labelled from memory (['a note of its report labels its dates and figures from memory']), without the label: the qualification was dropped, so the router reads those items as unqualified
  - warning INT-SYNTH-012 ['s1', 'h1.2', 'h1.3', 'h1.4', 'h2.1']: material claim produced by 'merged' from ['h1.2', 'h1.3', 'h1.4', 'h2.1']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'h1.5', 'h1.6']: material claim produced by 'merged' from ['h1.5', 'h1.6']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
- hi-t2.json [genuine] ACCEPTED_WITH_FINDINGS: errors [], warnings ['HI-STR-001', 'INT-GLOSSARY-005']
  - warning INT-GLOSSARY-005 ['h1.1', 'h1.2']: symbol 'coal_brk' (Bool) is glossed with different meanings across claims: 'the Grand Coalition under Müller broke on 27 March 1930 over whether to raise unemployment insurance contributions' in 'h1.1' vs 'the Grand Coalition under Hermann Müller broke on 27 March 1930 over whether to raise unemployment insurance contributions' in 'h1.2' (only the second states ['hermann']); the consistency check reads them as different quantities (the symbol is renamed apart per claim), so no contradiction is charged on this shared name; one name for two quantities is a translation fault, not the specialist's (claims ['h1.1', 'h1.2'] are AMBIGUOUS_TRANSLATION: their pooled formalization is one assumed reading, not a fixed one)
  - warning INT-GLOSSARY-005 ['h1.1', 'h1.4']: symbol 'se30' (Int) is glossed with different meanings across claims: 'Nazi seats on 14 September 1930 (107)' in 'h1.1' vs 'Nazi seats returned by the 14 September 1930 election (107)' in 'h1.4' (only the second states ['election', 'return']); the consistency check reads them as different quantities (the symbol is renamed apart per claim), so no contradiction is charged on this shared name; one name for two quantities is a translation fault, not the specialist's (claims ['h1.1'] are AMBIGUOUS_TRANSLATION: their pooled formalization is one assumed reading, not a fixed one)
  - warning HI-STR-001 ['h1.1', 'h1.2', 'h1.3', 'h1.4']: body paragraph 1 has no judgement move (counter-case weighed by a criterion)
- hi-t2.json [synthesis syn-hi-t2] ACCEPTED_WITH_FINDINGS: errors ['INT-LEDGER-003'], warnings ['INT-GLOSSARY-005', 'INT-SYNTH-012']
  - error INT-LEDGER-003 ['s1', 'h1.2', 'h1.3', 'h1.4']: certainty inflated: synthesis says 'established' but the weakest source is rank 2 (['probable', 'probable', 'probable'])
  - error INT-LEDGER-003 ['s2', 'h2.1', 'h2.2', 'h2.3', 'h2.4']: certainty inflated: synthesis says 'established' but the weakest source is rank 2 (['established', 'probable', 'established', 'established'])
  - warning INT-GLOSSARY-005 ['h1.1', 'h1.2']: symbol 'coal_brk' (Bool) is glossed with different meanings across claims: 'the Grand Coalition under Müller broke on 27 March 1930 over whether to raise unemployment insurance contributions' in 'h1.1' vs 'the Grand Coalition under Hermann Müller broke on 27 March 1930 over whether to raise unemployment insurance contributions' in 'h1.2' (only the second states ['hermann']); the consistency check reads them as different quantities (the symbol is renamed apart per claim), so no contradiction is charged on this shared name; one name for two quantities is a translation fault, not the specialist's (claims ['h1.1', 'h1.2'] are AMBIGUOUS_TRANSLATION: their pooled formalization is one assumed reading, not a fixed one)
  - warning INT-GLOSSARY-005 ['h1.1', 'h1.4']: symbol 'se30' (Int) is glossed with different meanings across claims: 'Nazi seats on 14 September 1930 (107)' in 'h1.1' vs 'Nazi seats returned by the 14 September 1930 election (107)' in 'h1.4' (only the second states ['election', 'return']); the consistency check reads them as different quantities (the symbol is renamed apart per claim), so no contradiction is charged on this shared name; one name for two quantities is a translation fault, not the specialist's (claims ['h1.1'] are AMBIGUOUS_TRANSLATION: their pooled formalization is one assumed reading, not a fixed one)
  - warning INT-SYNTH-012 ['s1', 'h1.2', 'h1.3', 'h1.4']: material claim produced by 'merged' from ['h1.2', 'h1.3', 'h1.4']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked
  - warning INT-SYNTH-012 ['s2', 'h2.1', 'h2.2', 'h2.3', 'h2.4']: material claim produced by 'merged' from ['h2.1', 'h2.2', 'h2.3', 'h2.4']: its content change was NOT formally checked on this channel (no formal conclusion was supplied or could be formed), so the router must not treat the rewording as checked

## Recorded peer relays (relayed/<task>.json) compared with the current parse of the peer's raw text (the genuine pass delivers the current parse; the recording is the dependent agent's document only)

(no recorded relay)

## Mutations: findings beyond the genuine record that do not name the injection (a consequence of the injected words, such as a word bound crossed, or a wrong receipt: read the message)

- en-t1.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q01', 'p4-s03']
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence (genuine record: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence)
- en-t1.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q01', 'p4-s03']
  - warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence (genuine record: body paragraph 4 carries 0 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence)
- en-t2.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q02', 'p4-s04']
  - lost from the genuine record: warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
- en-t2.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['p4-q02', 'p4-s04']
  - lost from the genuine record: warning ES-STR-001 ['p4-point']: body paragraph 4 carries 1 quotation(s) of at least 2 words; the working rule expects one idea carried by two strands, each with its own evidence
- hi-t1.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['h2.2']
  - warning INT-REQ-005 []: constraint c3 not satisfied: measured 2 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several) (genuine record: measured 1 paragraphs; bound max_paragraphs 1; solver ENTAILED; the mutation added 17 words)
- hi-t1.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['h2.2']
  - warning INT-REQ-005 []: constraint c3 not satisfied: measured 2 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several) (genuine record: measured 1 paragraphs; bound max_paragraphs 1; solver ENTAILED; the mutation added 17 words)
- hi-t1.json [wrong_arithmetic] ACCEPTED_WITH_FINDINGS: injected claims ['h2.2']
  - warning INT-REQ-005 []: constraint c3 not satisfied: measured 2 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several) (genuine record: measured 1 paragraphs; bound max_paragraphs 1; solver ENTAILED; the mutation added 13 words)
- hi-t1.json [chronology_error] ACCEPTED_WITH_FINDINGS: injected claims ['h2.2']
  - warning INT-REQ-005 []: constraint c3 not satisfied: measured 2 paragraphs; bound max_paragraphs 1; solver COUNTEREXAMPLE (blank-line blocks; a paragraph set out in blocks counts as several) (genuine record: measured 1 paragraphs; bound max_paragraphs 1; solver ENTAILED; the mutation added 16 words)
- hi-t2.json [invented_quotation] ACCEPTED_WITH_FINDINGS: injected claims ['h2.6']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 254 words (8 words of note or meta-text blocks excluded, as for paragraphs); bound max_words 250; solver COUNTEREXAMPLE (genuine record: measured 237 words (8 words of note or meta-text blocks excluded, as for paragraphs); bound max_words 250; solver ENTAILED; the mutation added 17 words)
- hi-t2.json [invented_quotation_single] ACCEPTED_WITH_FINDINGS: injected claims ['h2.6']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 254 words (8 words of note or meta-text blocks excluded, as for paragraphs); bound max_words 250; solver COUNTEREXAMPLE (genuine record: measured 237 words (8 words of note or meta-text blocks excluded, as for paragraphs); bound max_words 250; solver ENTAILED; the mutation added 17 words)
- hi-t2.json [chronology_error] ACCEPTED_WITH_FINDINGS: injected claims ['h2.6']
  - error INT-REQ-005 []: constraint c1 not satisfied: measured 253 words (8 words of note or meta-text blocks excluded, as for paragraphs); bound max_words 250; solver COUNTEREXAMPLE (genuine record: measured 237 words (8 words of note or meta-text blocks excluded, as for paragraphs); bound max_words 250; solver ENTAILED; the mutation added 16 words)

## Failures

(none)