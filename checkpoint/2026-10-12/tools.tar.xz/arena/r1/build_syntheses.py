import json, os

BASE = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/arena/r1"
OUT = os.path.join(BASE, "syntheses")
CLAIMS = os.path.join(BASE, "claims_tmp")
RANK = {"established": 3, "probable": 2, "possible": 1}

synth = {}

synth["en-t1"] = {
    "report_id": "rep-en-t1-0",
    "claims": [
        {
            "text": "García Márquez presents the administration of justice as governed less by the act itself than by the community's expectations of honour, so that the court and the town reach the same verdict by different routes.",
            "source_claim_ids": ["p1-s01"],
            "certainty": "probable",
            "transformation": "carried",
        },
        {
            "text": "The lawyer's thesis recasts the killing as 'homicide in legitimate defense of honor', so that the adjective 'legitimate' lends the authority of law to a community code of honour, and the court upholds the thesis in good faith; the code thus decides what the law recognises as a defence, and the court's sincerity makes this influence hard to detect.",
            "source_claim_ids": ["p2-point", "p2-q01", "p2-s02", "p2-q02", "p2-s03", "p2-s04", "p2-q03", "p2-s05", "p2-s06"],
            "certainty": "probable",
            "transformation": "merged",
        },
        {
            "text": "The immense majority of the town gives the word 'victim' to Bayardo San Roman, 'who had lost everything', which suggests that harm is measured by social standing rather than by the death; the verb 'expiated' makes Santiago Nasar's death a payment cancelling 'the insult', and the brothers having 'proved their status as men' and the sister being 'in possession of her honor once more' turn justice into a ledger in which a life settles a reputation, so the town's verdict is a social verdict rather than an assessment of the crime.",
            "source_claim_ids": ["p3-point", "p3-q01", "p3-s02", "p3-q02", "p3-q03", "p3-s03", "p3-s04", "p3-q04", "p3-s05", "p3-q05", "p3-s06", "p3-q06", "p3-q07", "p3-s07", "p3-s08"],
            "certainty": "probable",
            "transformation": "merged",
        },
        {
            "text": "Together, the court's acceptance of the thesis and the majority's reassignment of the victim show that the legal process reproduces communal judgement rather than testing the act against law, so justice is presented as subordinate to honour because both institutions measure the killing by the reputation it was believed to restore.",
            "source_claim_ids": ["p4-point", "p4-s02"],
            "certainty": "probable",
            "transformation": "merged",
        },
    ],
    "dropped": [],
}

synth["en-t2"] = {
    "report_id": "rep-en-t2-0",
    "claims": [
        {
            "text": "García Márquez constructs the reader's view of guilt and innocence by separating the two judgements, so that the court and the town grant the twins innocence while the extract keeps their guilt physically and morally visible.",
            "source_claim_ids": ["p1-s01"],
            "certainty": "probable",
            "transformation": "carried",
        },
        {
            "text": "The twins' declaration, 'We killed him openly, but we're innocent', places the admission in the verb 'killed' and the denial in the conjunction 'but'; the adverb 'openly', with its connotations of candour and moral transparency, lends the confession a virtue so that candour appears to cancel culpability, so the reader is encouraged to test the claim rather than accept it, and the priest's reply 'Perhaps before God' defers judgement to God rather than settling it.",
            "source_claim_ids": ["p2-point", "p2-q01", "p2-q02", "p2-s02", "p2-q03", "p2-q04", "p2-s03", "p2-q05", "p2-s04", "p2-s05", "p2-q06", "p2-s06"],
            "certainty": "probable",
            "transformation": "merged",
        },
        {
            "text": "The physical detail works against that declared innocence: the twins place the knives 'with clean blades' on the priest's desk yet arrive with 'faces smeared with sweat and still living blood', which locates guilt in the men rather than in the instruments, and the narration's 'barbarous work of death' sits uneasily with the priest's view of the surrender as 'an act of great dignity', so visible guilt persists beneath the declared innocence.",
            "source_claim_ids": ["p3-point", "p3-q01", "p3-q02", "p3-s02", "p3-s03", "p3-q03", "p3-s04", "p3-q04", "p3-q05", "p3-s05", "p3-s06"],
            "certainty": "probable",
            "transformation": "merged",
        },
        {
            "text": "Together, the verdicts of innocence from court and town rest on honour while the physical and narrative detail keeps the killing's guilt in view, and the narrator's 'we all could have been to blame' spreads culpability across the community so that guilt is redistributed rather than cancelled, leaving the reader to weigh a declared innocence against a guilt the text refuses to erase.",
            "source_claim_ids": ["p4-point", "p4-q01", "p4-s02", "p4-s03"],
            "certainty": "probable",
            "transformation": "merged",
        },
    ],
    "dropped": [],
}

synth["hi-t1"] = {
    "report_id": "rep-hi-t1-0",
    "claims": [
        {
            "text": "The Great Depression was responsible for the Nazi electoral rise above all because it destroyed the economic security of groups that had voted for moderate and conservative parties in 1928, giving the party a mass following it had never possessed.",
            "source_claim_ids": ["h1.1"],
            "certainty": "established",
            "transformation": "carried",
        },
        {
            "text": "Unemployment rose from about 1.4 million in 1928 to more than six million by early 1932 and the Nazi vote rose from 2.6 per cent and twelve seats in May 1928 to 37.3 per cent and 230 seats in July 1932, but this correlation is not itself the explanation: the mechanism was fear of ruin among the lower middle class and farmers, since the agrarian crisis ruined farming communities in the Protestant north while small businesses threatened with bankruptcy turned to a party promising national community and the destruction of Marxism, a message that had found little audience among them before the Crash (the specialist flags these figures as from memory, to be verified).",
            "source_claim_ids": ["h1.2", "h1.3", "h1.4", "h2.1"],
            "certainty": "established",
            "transformation": "merged",
        },
        {
            "text": "The strongest counter-case is that the Nazi vote fell to 33.1 per cent in November 1932 as the economy began to recover while the Communist vote reached 16.9 per cent against 10.6 per cent in 1928, suggesting that distress alone did not decide where votes went; measured by the criterion of what made the breakthrough possible, however, the Depression carries the greater weight, because the fall came only after the crisis had already made the Nazis the largest party.",
            "source_claim_ids": ["h1.5", "h1.6"],
            "certainty": "established",
            "transformation": "merged",
        },
        {
            "text": "The Depression was therefore responsible for the Nazi electoral rise to a large degree, though not for the appointment of January 1933, which depended on the choices of the conservative elite.",
            "source_claim_ids": ["h1.7"],
            "certainty": "established",
            "transformation": "carried",
        },
    ],
    "dropped": [],
}

synth["hi-t2"] = {
    "report_id": "rep-hi-t2-0",
    "claims": [
        {
            "text": "The Depression was the decisive trigger of the collapse of parliamentary government, but not its sole cause.",
            "source_claim_ids": ["h1.1"],
            "certainty": "established",
            "transformation": "carried",
        },
        {
            "text": "The Grand Coalition broke on 27 March 1930 over whether to raise unemployment insurance contributions, a dispute sharpened by unemployment rising from about 1.4 million in 1928 to about 3 million by September 1930; Brüning, appointed Chancellor on 30 March, could not secure a majority for his financial measures, and the Reichstag voted to overturn his emergency decree on 16 July and was dissolved; after the 14 September 1930 election returned 107 Nazi seats against 12 in 1928, the Chancellor depended on presidential rather than parliamentary support, and in 1932 Franz von Papen and then Kurt von Schleicher governed without a majority (the specialist flags these dates and figures as from memory, to be checked).",
            "source_claim_ids": ["h1.2", "h1.3", "h1.4"],
            "certainty": "established",
            "transformation": "merged",
        },
        {
            "text": "The strongest counter-case is structural: proportional representation, the emergency power of Article 48 and parties unwilling to compromise all existed in 1919, and the system survived the crisis of 1923 without ending parliamentary government, so these flaws became decisive only when the crisis made majorities impossible to form, while Brüning's deflationary policy deepened the slump as a response to the Depression rather than an independent cause.",
            "source_claim_ids": ["h2.1", "h2.2", "h2.3", "h2.4"],
            "certainty": "established",
            "transformation": "merged",
        },
        {
            "text": "The collapse was therefore caused by the Depression to a large extent, though it worked through a constitution the parties would not make function, turning a fiscal dispute into rule by decree.",
            "source_claim_ids": ["h2.5"],
            "certainty": "established",
            "transformation": "carried",
        },
    ],
    "dropped": [],
}

# Write files
for task_id, body in synth.items():
    out = {"report_id": body["report_id"], "claims": body["claims"], "dropped": body["dropped"]}
    with open(os.path.join(OUT, task_id + ".json"), "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)
        fh.write("\n")

# Validate against list_claims output
errors = []
for task_id, body in synth.items():
    src = json.load(open(os.path.join(CLAIMS, task_id + ".claims.json"), encoding="utf-8"))
    if src["report_id"] != body["report_id"]:
        errors.append(f"{task_id}: report_id mismatch {src['report_id']} vs {body['report_id']}")
    by_id = {c["claim_id"]: c for c in src["claims"]}
    if not (2 <= len(body["claims"]) <= 4):
        errors.append(f"{task_id}: claim count {len(body['claims'])}")
    for i, c in enumerate(body["claims"], 1):
        if c["certainty"] not in RANK:
            errors.append(f"{task_id} c{i}: bad certainty")
        if c["transformation"] not in {"carried", "paraphrased", "merged", "narrowed"}:
            errors.append(f"{task_id} c{i}: bad transformation")
        if not c["source_claim_ids"]:
            errors.append(f"{task_id} c{i}: no sources")
        for sid in c["source_claim_ids"]:
            if sid not in by_id:
                errors.append(f"{task_id} c{i}: unknown source id {sid}")
                continue
            if RANK[c["certainty"]] > RANK[by_id[sid]["certainty"]]:
                errors.append(f"{task_id} c{i}: certainty {c['certainty']} stronger than source {sid} ({by_id[sid]['certainty']})")
    # coverage: every claim id in source either used or dropped
    used = {s for c in body["claims"] for s in c["source_claim_ids"]}
    dropped_ids = {s for d in body["dropped"] for s in d["source_claim_ids"]}
    unused = [cid for cid in by_id if cid not in used and cid not in dropped_ids]
    print(f"{task_id}: claims={len(body['claims'])} sources_used={len(used)} of {len(by_id)} unused={unused}")

print("ERRORS:", errors if errors else "none")
