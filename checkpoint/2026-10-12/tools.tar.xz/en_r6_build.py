import json
import os

SRC = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/arena/r6/tasks.json"
OUT_DIR = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/arena/r6/specialists"

responses = {
    "en-t11": [
        '''Brontë presents Jane's exclusion as a judgement that depends on reports, and is then enforced by silencing her. The passage moves from reported speech to direct speech, keeping the family's authority at a distance before placing it face to face with Jane as she tries to question it.''',
        '''Mrs Reed's justification sits within quotation marks, yet its pronouns and tense belong to the narrator's report, with "she" for Mrs Reed and "I" for Jane, so it reaches the reader indirectly. The key word is "dispensed", as in "Me, she had dispensed from joining the group". To dispense someone from a duty is conventionally to release them from an obligation, so the exclusion sounds like an official exemption rather than a personal snub. The judgement is also conditional, waiting "until she heard from Bessie", which makes Jane's standing depend on reports that Jane has not heard.''',
        '''The direct exchange differs. Jane's question, "What does Bessie say I have done?", seeks the grounds of the judgement, but Mrs Reed deflects it by shifting from "Jane" to "a child taking up her elders", a phrase that turns the question into a breach of hierarchy. The reply ends with the imperative "remain silent", making silence the condition Jane must keep until she can speak pleasantly.''',
        '''Together, the two forms show exclusion built through control of speech: the judgement is kept at a remove, then enforced where Jane's question would test it. The repeated "until" moves the condition from reports about Jane to her own voice, leaving the exclusion without a stated end.''',
    ],
    "en-t12": [
        '''Herbert's unmarked speech and his regular alternation of long and short lines present the speaker's reluctance as a position that Love's insistence answers within the same exchange, so that refusal gives way to compliance by the final line.''',
        '''The speech has no quotation marks, so the boundaries between voices are marked mainly by tags, and the tags sometimes fall inside what is said. A tag conventionally sits outside the words it attributes, but in "And know you not, sayes Love, who bore the blame?" the tag "sayes" splits Love's question, so the attribution interrupts the argument. Even Love's question, "sweetly questioning, / If I lack'd any thing", takes the speaker's pronoun, so Love's tenderness reaches the reader filtered through the speaker's account.''',
        '''The short lines carry the decisive turns. The refusal "I cannot look on thee." is compressed into one short line, and Love's reply follows a long line of action, "Love took my hand, and smiling did reply," as the short question "Who made the eyes but I?" The modal "cannot" presents refusal as incapacity, and the question answers it by attributing the eyes to Love's making. In the closing lines Love's words fill the long lines, "You must sit down, sayes Love, and taste my meat:", while the speaker's replies stay short, "My deare, then I will serve."''',
        '''Insistence therefore has the last long line, while each of the speaker's refusals is answered in the following pair of lines. The final "did" is emphatic, and the poem's last short line closes the exchange on obedience rather than dissent.''',
    ],
}

with open(SRC, encoding="utf-8") as f:
    tasks = json.load(f)
by_id = {t["task_id"]: t for t in tasks}

os.makedirs(OUT_DIR, exist_ok=True)
for tid, blocks in responses.items():
    record = dict(by_id[tid])
    text = "\n\n".join(b.strip() for b in blocks)
    record["response_text"] = text
    path = os.path.join(OUT_DIR, tid + ".json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(record, f, ensure_ascii=False, indent=2)
        f.write("\n")
    print(path, len(text.split()))
