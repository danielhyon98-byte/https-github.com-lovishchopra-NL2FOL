"""Final-only gate for one overseer-build commit (used by publish_overseer.sh; Daniel: upload only final edits).

A commit passes only when every check holds; otherwise the reason is printed on stdout and the exit status is 1.
  1. Its title is a verified step of the overseer build (a review round, a contained round, the documentation
     commit) or the overseer rebuild on the STEM-merged translator (REBUILD_SUBJECT, made by a separate workflow
     whose journal the publisher passes for it), never work in progress.
  2. Its message records a green suite (no non-zero failure or error count), at least one tampering, every
     tampering detected and no false alarm.
  3. The build's workflow journal shows that the commit was made by the step's own commit agent, and that the step
     before it completed: the fix or documentation agent returned a result and so did the evaluation, which reports
     suite_passed, no failing tests, every tampering detected and no false alarm. (The build commits even when a step
     crashed part-way, so the title alone never proves a finished step.) For the rebuild the step is rebuild:merge,
     its evaluation eval:rebuild and its commit agent commit:rebuild, all read from the journal given; the rebuild
     must also have left its merge staged; its independent test
     (rebuild:audit) must have completed clean after the last merge step (after the repair, when an earlier test was
     not clean) and before the evaluation; its evaluation must record every contained gate passing and a pack export
     that succeeded (export_ok true).
  4. The rebuild commit is a two-parent merge (merge_structure): its first parent is on the overseer build's line (it
     descends from the fork point FORK and from the overseer build's first commit, and is not already in the history
     of the second parent) and its second parent T is on the development branch and descends from (or is) the STEM
     merge "Merge STEM support into the translator" (pinned by sha and subject; else found in the source's own
     history, else on the development branch). For every round recorded by the newest commit in T's first-parent
     history that has a "Harness after the change" line, the rebuild's own such line records at least that functional
     count; simulate.sh replays every one of those rounds with the per-round maximum of both records as its floor
     (harness_floor below), for the rebuild and for every later commit on its line.
  5. Every candidate that carries a merged development translator gets the translator checks, not only the rebuild:
     every merge M on the candidate's first-parent line since FORK whose second parent T descends from the STEM merge
     (translator_merges; the rebuild itself, a later merge of the development branch, ...) passes the structural
     checks of 4 (and T must not already be in M's first parent's history: such a merge brings in nothing), and so
     does every commit titled as an overseer rebuild on that line. The candidate's own tree then follows the
     preservation policy against each M's T, from merge-base(M's first parent, T), oldest merge first
     (development_preservation): a later merge, made after the development branch merged the overseer, has a later
     merge base, so the earlier merges keep the earlier development changes covered. For an older merge a path whose
     candidate version is the newest T's, or that the newest T deleted, is skipped (a newer development change
     superseded it); policy (a) is read against the newest T, which carries every development test still wanted.
     The candidate is HELD when
       (a) a test function or test class that T has under tests/ or scripts/ (def test*, class Test*, qualified by
           their enclosing classes, per file) is missing from the candidate's file, or is kept but switched off while
           T runs it: a skip, skipif or xfail mark or unittest.skip*, a module- or class-level pytestmark or
           __test__ = False, a skip, xfail or importorskip call in its body, in the module, in a class body or in a
           setup function, a definition under a constant-false if, a later redefinition or rebinding of its name
           (tests_disabled); a collect_ignore or collect_ignore_glob in a conftest.py, a pytest option in
           pyproject.toml, setup.cfg, pytest.ini or tox.ini (--ignore, --ignore-glob, --deselect, testpaths,
           norecursedirs, python_files, python_functions, python_classes, positional arguments) that leaves it out
           (collection_rules, file_off, name_off); or an option, hook or fixture the gate cannot evaluate (-k, -m, -p,
           a collection hook, an autouse fixture, ...) that neither T nor the overseer side has. A test T itself does
           not run (an unconditional skip or xfail, or left out by T's own rules) is not held;
       (b) a path the development side changed is deleted by the candidate, reverted to the merge base, kept although
           the development side deleted it, or taken whole from the overseer side;
       (c) its evaluation passed fewer tests than the newest "Suite: N passed" record in the newest T's first-parent
           history.
     Line-level differences are REPORTED, never held (development_report, over the same merges): every non-blank
     line T added that the candidate's file does not have verbatim is counted, and of these the ones found rewritten
     (an import of the same module with a superset of the names, or a line holding its tokens in order) are counted
     again separately. The upload note and the commit message state both counts and the files. The full suite and
     every recorded round's harness floor guard behaviour, so a legitimate refactor of development code is reported,
     not held.
On success it prints "OK <recorded passed> <recorded skipped>" so the publisher can check its own re-run ran at least
as many tests.
Usage: overseer_gate.py REPO SHA JOURNAL      (JOURNAL: the rebuild's journal for REBUILD_SUBJECT, else the build's)
"""
import ast
import collections
import configparser
import fnmatch
import hashlib
import json
import os
import re
import shlex
import subprocess
import sys
import tomllib

REBUILD_SUBJECT = "Overseer rebuild: on the STEM-merged translator, with the faulty checks corrected"
STEM_MERGE_SUBJECT = "Merge STEM support into the translator"
# The STEM merge, pinned (its subject is checked, so a rewritten history cannot substitute another commit); when it is
# absent, the commit with that subject in the source's own history, and only then on the development branch.
STEM_MERGE_SHA = "83e97e9d792fc458fd8f11f7ea240e170a32a9a7"
# The overseer build's fork point (also publish_overseer.sh's FORK) and the development branch that carries the STEM merge.
FORK = "ae7b1e62c848191293ac84e0ce4e7c140ddedccf"
DEV_REF = "refs/heads/claude/z3-verification-engine-plan-nk3luq"
# The overseer build's first commit after the fork point, pinned with its subject; when absent, the first commit after
# FORK on the overseer build branch's first-parent line, if its subject matches.
OVERSEER_REF = "refs/heads/overseer-build"
OVERSEER_FIRST_SHA = "3b13b468f40428d183a4b51cb4a8af485b16ce14"
OVERSEER_FIRST_SUBJECT = "Overseer design: logic-checking overseer agents for transfers between agents"
HARNESS_MARK = "Harness after the change: "
HARNESS_RE = re.compile(r"\b(r\d+(?:-[a-z]+)?)\s+(\d+)/(\d+)")
SUITE_RE = re.compile(r"^Suite: (\d+) passed\b", re.M)
LIST_CAP = 40
# Where the development side's tests live (policy (a)); only Python files there are read for test names.
TEST_ROOTS = ("tests/", "scripts/")

TITLES = [
    (re.compile(r"^Overseer review round (\d+): fix tamper-evasion, agent-abuse and precision findings$"), lambda m: (f"commit:review-{m.group(1)}", f"review-fix:{m.group(1)}", f"eval:review-{m.group(1)}")),
    (re.compile(r"^Overseer contained round (c\d+): fix judge findings$"), lambda m: (f"commit:contained-{m.group(1)}", f"fix:{m.group(1)}", f"eval:{m.group(1)}")),
    (re.compile(r"^Overseer agents: documentation and contained-test results$"), lambda m: ("commit:docs", "docs", "eval:final")),
    (re.compile("^" + re.escape(REBUILD_SUBJECT) + "$"), lambda m: ("commit:rebuild", "rebuild:merge", "eval:rebuild")),
]


def fail(reason):
    print(reason)
    sys.exit(1)


def _git(repo, *args):
    return subprocess.run(["git", "-C", repo, *args], capture_output=True, text=True)


def is_ancestor(repo, a, b):
    return _git(repo, "merge-base", "--is-ancestor", a, b).returncode == 0


def harness_record(msg):
    """Per-round (functional, transmissions) from a message's first "Harness after the change" line, read exactly as
    simulate.sh reads it (the text after the line's last marker); {} when there is none."""
    line = next((ln for ln in msg.split("\n") if HARNESS_MARK in ln), None)
    if line is None:
        return {}
    return {m.group(1): (int(m.group(2)), int(m.group(3))) for m in HARNESS_RE.finditer(line.rsplit(HARNESS_MARK, 1)[1])}


def _newest_record(repo, sha, parse):
    """(commit, parse(message)) for the newest commit in sha's first-parent history whose parsed record is not empty."""
    out = _git(repo, "log", "--first-parent", "--format=%H%x00%B%x1e", sha).stdout
    for chunk in out.split("\x1e"):
        h, _, body = chunk.strip("\n").partition("\x00")
        rec = parse(body)
        if h and rec:
            return h, rec
    return None, None


def newest_harness_record(repo, sha):
    """(commit, record) for the newest commit in sha's first-parent history whose message has a non-empty
    "Harness after the change" record, or (None, {})."""
    h, rec = _newest_record(repo, sha, harness_record)
    return h, rec or {}


def newest_suite_record(repo, sha):
    """(commit, passed) for the newest commit in sha's first-parent history whose message has a "Suite: N passed" line,
    or (None, None)."""
    return _newest_record(repo, sha, lambda body: (lambda m: int(m.group(1)) if m else None)(SUITE_RE.search(body)))


def _subject(repo, sha):
    r = _git(repo, "log", "-1", "--format=%s", sha + "^{commit}", "--")
    return r.stdout.strip() if r.returncode == 0 else None


def stem_merge(repo, source=None):
    """The STEM merge "Merge STEM support into the translator": the pinned commit when the repository has it with that
    subject; otherwise the newest commit with that subject in source's own history, then on the development branch; or
    None."""
    if _subject(repo, STEM_MERGE_SHA) == STEM_MERGE_SUBJECT:
        return STEM_MERGE_SHA
    for ref in ([source] if source else []) + [DEV_REF]:
        out = _git(repo, "log", "--format=%H%x09%s", ref, "--").stdout
        h = next((h for h, _, sub in (ln.partition("\t") for ln in out.splitlines()) if sub == STEM_MERGE_SUBJECT), None)
        if h:
            return h
    return None


def overseer_first(repo):
    """The overseer build's first commit after the fork point (pinned, else found on the overseer build branch), or None."""
    if _subject(repo, OVERSEER_FIRST_SHA) == OVERSEER_FIRST_SUBJECT:
        return OVERSEER_FIRST_SHA
    first = _git(repo, "rev-list", "--first-parent", "--reverse", f"{FORK}..{OVERSEER_REF}", "--").stdout.split()[:1]
    return first[0] if first and _subject(repo, first[0]) == OVERSEER_FIRST_SUBJECT else None


def translator_merge(repo, to):
    """The newest merge on to's first-parent line that brought in a development translator: its second parent descends
    from (or is) the STEM merge, whatever the merge's subject. Returns {"merge", "translator" (that second parent, T),
    "stem"} or None."""
    stem = stem_merge(repo, to)
    if not stem:
        return None
    for ln in _git(repo, "log", "--first-parent", "--merges", "--format=%H %P", to).stdout.splitlines():
        parts = ln.split()
        if len(parts) >= 3 and is_ancestor(repo, stem, parts[2]):
            return {"merge": parts[0], "translator": parts[2], "stem": stem}
    return None


def translator_merges(repo, to):
    """Every merge on to's first-parent line since FORK that brought in a development translator (its second parent
    descends from, or is, the STEM merge), oldest first: [{"merge", "translator", "stem"}]."""
    stem = stem_merge(repo, to)
    if not stem:
        return []
    out = []
    for ln in _git(repo, "log", "--first-parent", "--merges", "--format=%H %P", to, "^" + FORK, "--").stdout.splitlines():
        parts = ln.split()
        if len(parts) >= 3 and is_ancestor(repo, stem, parts[2]):
            out.append({"merge": parts[0], "translator": parts[2], "stem": stem})
    return out[::-1]


def harness_floor(repo, source):
    """The harness floor for an overseer source that carries a merged development translator (the rebuild, or a later
    commit on its line): per round, the higher of the source's own "Harness after the change" count and the count
    recorded by the newest commit in T's first-parent history that has such a line (T: the translator merge's second
    parent). Returns (floor, T, record commit), or None when the source carries no merged translator (its own record
    is then the floor, as before). Raises ValueError when T has no record."""
    tm = translator_merge(repo, source)
    if not tm:
        return None
    rc, trec = newest_harness_record(repo, tm["translator"])
    if not trec:
        raise ValueError(f"the merged translator {tm['translator'][:7]} has no \"Harness after the change\" record in its first-parent history")
    own = harness_record(_git(repo, "log", "-1", "--format=%B", source).stdout)
    floor = {}
    for r in set(own) | set(trec):
        # The higher functional count; on a tie the record that allows fewer non-functional transmissions.
        floor[r] = max((x for x in (own.get(r), trec.get(r)) if x), key=lambda x: (x[0], -(x[1] - x[0])))
    return floor, tm["translator"], rc


def _tree(repo, rev):
    """{path: blob id} of every file in rev's tree."""
    out = _git(repo, "ls-tree", "-r", "-z", "--full-tree", rev).stdout
    tree = {}
    for ent in out.split("\0"):
        meta, _, path = ent.partition("\t")
        if path:
            tree[path] = meta.split()[2]
    return tree


def _blob(repo, oid):
    return subprocess.run(["git", "-C", repo, "cat-file", "blob", oid], capture_output=True, check=True).stdout


def _text(repo, oid):
    return _blob(repo, oid).decode("utf-8", "replace") if oid else ""


# ---------------------------------------------------------------------------------------------- (a) test names
_TEST_DEF_RE = re.compile(r"^([ \t]*)(?:async[ \t]+)?def[ \t]+(\w+)|^([ \t]*)class[ \t]+(\w+)", re.M)


def _test_names_ast(text):
    """pytest-style test names in a Python file: functions named test* and classes named Test*, at module level, in
    module-level compound statements, or in classes (qualified by the enclosing classes); a Counter."""
    out = collections.Counter()

    def walk(nodes, prefix):
        for node in nodes:
            if isinstance(node, ast.ClassDef):
                if node.name.startswith("Test"):
                    out[prefix + node.name] += 1
                walk(node.body, prefix + node.name + ".")
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if node.name.startswith("test"):
                    out[prefix + node.name] += 1
            else:
                for field in ("body", "orelse", "finalbody", "handlers", "cases"):
                    sub = getattr(node, field, None)
                    if isinstance(sub, list):
                        walk(sub, prefix)

    walk(ast.parse(text).body, "")
    return out


def _test_names_re(text):
    """The same names read line by line (for a file this Python cannot parse), qualified by indentation."""
    out, stack = collections.Counter(), []
    for m in _TEST_DEF_RE.finditer(text):
        ind = len((m.group(1) if m.group(2) is not None else m.group(3)).expandtabs())
        while stack and stack[-1][0] >= ind:
            stack.pop()
        prefix = "".join(n + "." for _, n in stack)
        if m.group(2) is not None:
            if m.group(2).startswith("test"):
                out[prefix + m.group(2)] += 1
        else:
            if m.group(4).startswith("Test"):
                out[prefix + m.group(4)] += 1
            stack.append((ind, m.group(4)))
    return out


def tests_missing(t_text, c_text):
    """Test names T's file has that the candidate's file lacks (a Counter). Both files are read the same way: parsed,
    or, when either does not parse, line by line."""
    try:
        return _test_names_ast(t_text) - _test_names_ast(c_text)
    except (SyntaxError, ValueError, RecursionError):
        return _test_names_re(t_text) - _test_names_re(c_text)


# ---------------------------------------------------------------------------------------------- (a) disabled tests
# A development test the candidate switches off while T runs it counts as missing under policy (a). A test is switched
# off by a cause: a skip, skipif or xfail mark (pytest.mark.*, unittest.skip*, expectedFailure, or a module-level alias
# of such a mark) on the test or an enclosing class; a module- or class-level pytestmark holding one; __test__ = False;
# a top-level pytest.skip, pytest.xfail, importorskip, self.skipTest or raise SkipTest in the test's body, in the
# module, in a class body or in a setup function; a definition under an if (or while) whose test is constant false; a
# later binding of the same name (a redefinition, an assignment or a del). Each cause is kept with its source (ast.dump,
# no line numbers), so a cause T itself has is never counted again. Unconditional causes (skip, xfail without a
# condition, a constant-true skipif, dead code, a later binding) mean T itself does not run the test; conditional ones
# (skipif, importorskip) do not. Collection is read the same way (collection_rules below).
_SKIP_MARKS = {"skip", "skipif", "xfail", "skipIf", "skipUnless", "expectedFailure"}
_SKIP_CALL_BASES = {"pytest", "unittest", "self", "cls"}
_SETUPS = {"setup_module", "setUpModule", "setup_class", "setUpClass", "setup_method", "setUp", "setup", "setup_function"}


def _const_truth(node):
    """True or False when an if or while test is constant (a literal, its negation, __name__ == "__main__"), else None."""
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.Not):
        v = _const_truth(node.operand)
        return None if v is None else not v
    if (isinstance(node, ast.Compare) and isinstance(node.left, ast.Name) and node.left.id == "__name__"
            and len(node.ops) == 1 and isinstance(node.ops[0], ast.Eq) and isinstance(node.comparators[0], ast.Constant)
            and node.comparators[0].value == "__main__"):
        return False
    try:
        return bool(ast.literal_eval(node))
    except (ValueError, TypeError, SyntaxError, MemoryError, RecursionError):
        return None


def _mark_kind(node, aliases):
    """None when the expression holds no skip, skipif or xfail mark; True when one switches the test off whatever the
    condition (skip, expectedFailure, xfail without a condition, skipif with a constant-true one, or an alias of such a
    mark); False when every one is conditional."""
    calls = {id(n.func): n for n in ast.walk(node) if isinstance(n, ast.Call)}
    kind = None
    for sub in ast.walk(node):
        name = sub.id if isinstance(sub, ast.Name) else sub.attr if isinstance(sub, ast.Attribute) else None
        if name in aliases:
            k = aliases[name]
        elif name in _SKIP_MARKS:
            call = calls.get(id(sub))
            if name in ("skip", "expectedFailure"):
                k = True
            elif name == "xfail":
                k = call is None or not call.args or _const_truth(call.args[0]) is True
            else:
                k = call is not None and bool(call.args) and _const_truth(call.args[0]) is (name != "skipUnless")
        else:
            continue
        kind = k or bool(kind)
    return kind


def _stmt_kind(st):
    """None, or whether a statement switches off what it runs in: True for pytest.skip, pytest.xfail, self.skipTest
    or raise SkipTest; False (conditional) for importorskip."""
    call = getattr(st, "value", None) if isinstance(st, (ast.Expr, ast.Assign, ast.AnnAssign)) else None
    if isinstance(call, ast.Await):
        call = call.value
    if isinstance(call, ast.Call):
        f = call.func
        # pytest.skip(...), self.skipTest(...), skip(...); never a mark (pytest.mark.skip(...) builds a mark).
        name = (f.id if isinstance(f, ast.Name) else
                f.attr if isinstance(f, ast.Attribute) and isinstance(f.value, ast.Name) and f.value.id in _SKIP_CALL_BASES else None)
        if name in ("skip", "xfail", "skipTest"):
            return True
        if name == "importorskip":
            return False
    if isinstance(st, ast.Raise) and st.exc is not None:
        names = {n.id if isinstance(n, ast.Name) else n.attr for n in ast.walk(st.exc) if isinstance(n, (ast.Name, ast.Attribute))}
        if names & {"SkipTest", "Skipped", "XFailed"} or {"skip", "Exception"} <= names:
            return True
    return None


def _scope_causes(body, aliases, where):
    """Causes that switch off every test in a module or class body (pytestmark, __test__ = False, a top-level skip
    statement, a setup function that skips); {signature: unconditional}. Statements in a branch whose test is not
    constant are conditional."""
    out = {}

    def scan(stmts, cond):
        for st in stmts:
            if isinstance(st, (ast.Assign, ast.AnnAssign, ast.AugAssign)):
                targets = st.targets if isinstance(st, ast.Assign) else [st.target]
                names = {t.id for t in targets if isinstance(t, ast.Name)}
                if "pytestmark" in names and st.value is not None:
                    k = _mark_kind(st.value, aliases)
                    if k is not None:
                        out[(where, "pytestmark", ast.dump(st))] = k and not cond
                if "__test__" in names and st.value is not None and _const_truth(st.value) is False:
                    out[(where, "__test__", ast.dump(st))] = not cond
            k = _stmt_kind(st)
            if k is not None:
                out[(where, "statement", ast.dump(st))] = k and not cond
            if isinstance(st, (ast.FunctionDef, ast.AsyncFunctionDef)) and st.name in _SETUPS:
                for s2 in st.body:
                    k = _stmt_kind(s2)
                    if k is not None:
                        out[(where, st.name, ast.dump(s2))] = k and not cond
            elif isinstance(st, (ast.If, ast.While)):
                c = _const_truth(st.test)
                if c is None:
                    scan(st.body, True)
                    scan(st.orelse, True)
                else:
                    scan(st.body if c else st.orelse, cond)
            elif not isinstance(st, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                for field in ("body", "orelse", "finalbody", "handlers", "cases"):
                    sub = getattr(st, field, None)
                    if isinstance(sub, list):
                        scan(sub, True if field in ("handlers", "cases") else cond)
    scan(body, False)
    return out


def test_states(text):
    """{qualified test name: {"defs": definitions, "kind": "function" or "class", "causes": {signature: unconditional}}}
    for a Python file (names as _test_names_ast reads them; the causes of the last definition, the one pytest
    collects). Raises SyntaxError (or ValueError) when the file does not parse."""
    tree = ast.parse(text)
    aliases = {}
    for st in tree.body:
        if isinstance(st, ast.Assign) and not any(isinstance(t, ast.Name) and t.id == "pytestmark" for t in st.targets):
            k = _mark_kind(st.value, aliases)
            if k is not None:
                aliases.update({t.id: k for t in st.targets if isinstance(t, ast.Name)})
    states, rebound = {}, set()

    def bind_names(st):
        if isinstance(st, (ast.Assign, ast.AnnAssign, ast.AugAssign, ast.Delete)):
            targets = st.targets if isinstance(st, (ast.Assign, ast.Delete)) else [st.target]
            return [n.id for t in targets for n in ast.walk(t) if isinstance(n, ast.Name)]
        if isinstance(st, (ast.Import, ast.ImportFrom)):
            return [(a.asname or a.name).split(".")[0] for a in st.names]
        return []

    def walk(nodes, prefix, inherited, bindings, dead):
        for node in nodes:
            if isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
                q = prefix + node.name
                own = dict(inherited)
                if dead:
                    own[(q, "dead code", dead)] = True
                for dec in node.decorator_list:
                    k = _mark_kind(dec, aliases)
                    if k is not None:
                        own[(q, "decorator", ast.dump(dec))] = k
                is_class = isinstance(node, ast.ClassDef)
                if is_class:
                    own.update(_scope_causes(node.body, aliases, q))
                    test = node.name.startswith("Test")
                else:
                    test = node.name.startswith("test")
                    for st in node.body:
                        k = _stmt_kind(st)
                        if k is not None:
                            own[(q, "body", ast.dump(st))] = k
                if test:
                    e = states.setdefault(q, {"defs": 0, "kind": "class" if is_class else "function", "causes": {}})
                    e["defs"] += 1
                    e["causes"] = dict(own)
                bindings.append((node.name, q))
                if is_class:
                    inner = []
                    walk(node.body, q + ".", own, inner, dead)
                    finish(inner)
            elif isinstance(node, (ast.If, ast.While)):
                c = _const_truth(node.test)
                sig = ast.dump(node.test)
                walk(node.body, prefix, inherited, bindings if c is not False else [], dead or (sig if c is False else None))
                walk(node.orelse, prefix, inherited, bindings if c is not True or isinstance(node, ast.While) else [],
                     dead or (sig if c is True and isinstance(node, ast.If) else None))
            else:
                for name in bind_names(node):
                    bindings.append((name, None))
                for field in ("body", "orelse", "finalbody", "handlers", "cases"):
                    sub = getattr(node, field, None)
                    if isinstance(sub, list):
                        walk(sub, prefix, inherited, bindings, dead)

    def finish(bindings):
        last = {}
        for name, q in bindings:
            last[name] = q
        for name, q in bindings:
            if q is not None and last[name] != q:
                rebound.add(q)

    top = []
    walk(tree.body, "", _scope_causes(tree.body, aliases, ""), top, None)
    finish(top)
    # A name bound again later (a redefinition, an assignment, a del) is not the test pytest collects; a class bound
    # again takes its tests with it.
    for q, e in states.items():
        parts = q.split(".")
        for i in range(1, len(parts) + 1):
            if ".".join(parts[:i]) in rebound:
                e["causes"][(".".join(parts[:i]), "bound again later", "")] = True
    return states


def tests_disabled(t_text, c_text):
    """Test names T's file runs that the candidate's file keeps but switches off: a cause T does not have, or more
    definitions of the name than T has (the earlier ones are shadowed). T runs a test when it has no unconditional
    cause. A sorted list of (name, the first new cause as text); [] when either file does not parse."""
    try:
        ts, cs = test_states(t_text), test_states(c_text)
    except (SyntaxError, ValueError, RecursionError):
        return []
    out = []
    for q, e in sorted(ts.items()):
        if q not in cs or cs[q]["defs"] < e["defs"] or any(e["causes"].values()):
            continue
        new = [sig for sig in cs[q]["causes"] if sig not in e["causes"]]
        if new:
            out.append((q, _cause_text(new[0])))
        elif cs[q]["defs"] > e["defs"]:
            out.append((q, "defined again later"))
    return out


def _cause_text(sig):
    where, what, _ = sig
    at = f"on {where}" if where else "at module level"
    return {"decorator": f"a skip or xfail mark on {where}", "body": f"a skip, xfail or importorskip call in the body of {where}",
            "dead code": f"{where} defined under a constant-false condition", "bound again later": f"{where} bound again later in the file",
            "pytestmark": f"a skip or xfail pytestmark {at}", "__test__": f"__test__ = False {at}",
            "statement": f"a skip, xfail or importorskip statement {at}"}.get(what, f"a skip in {what} {at}")


# ---------------------------------------------------------------------------------------------- (a) collection
# pytest's own selection, read from the configuration files (every one of them, whatever their precedence) and every
# conftest.py: testpaths, positional arguments, norecursedirs, python_files, --ignore, --ignore-glob and conftest
# collect_ignore / collect_ignore_glob (with literal values), an unconditional skip at a conftest's module level are
# evaluated per file; --deselect, python_functions and python_classes per test. Whatever cannot be evaluated (-k, -m,
# -p, -c, -o, --co, --lf, --sw, --noconftest, --confcutdir, --rootdir, --pyargs, usefixtures and similar keys, a
# non-literal collect_ignore, a collection or run hook (a pytest_configure that only registers markers excepted), an
# autouse fixture that can skip, or pytest_plugins in a conftest.py, a file that cannot be read) is compared exactly: when the candidate has one that neither T nor the overseer side has, every
# test in its scope counts as switched off.
_CONFIGS = ("pytest.ini", ".pytest.ini", "pyproject.toml", "tox.ini", "setup.cfg")
_VALUE_OPTS = {"-k", "-m", "-p", "-c", "-o", "-W", "-n", "-r", "--config-file", "--override-ini", "--deselect", "--ignore",
               "--ignore-glob", "--confcutdir", "--rootdir", "--basetemp", "--maxfail", "--timeout", "--timeout-method",
               "--durations", "--durations-min", "--tb", "--show-capture", "--capture", "--import-mode", "--log-level",
               "--log-format", "--log-date-format", "--log-file", "--log-file-level", "--log-cli-level", "--junitxml",
               "--junit-xml", "--junit-prefix", "--cov", "--cov-report", "--cov-fail-under", "--cov-config", "--dist",
               "--hypothesis-profile", "--hypothesis-seed", "--color", "--code-highlight", "--pastebin", "--debug",
               "--doctest-glob", "--report-log", "--json-report-file", "--deselect-file", "--rootdir"}
_OPAQUE_OPTS = {"-k", "-m", "-p", "-c", "--config-file", "--co", "--collect-only", "--collectonly", "--lf", "--last-failed",
                "--lfnf", "--last-failed-no-failures", "--sw", "--stepwise", "--sw-skip", "--stepwise-skip", "--noconftest",
                "--confcutdir", "--rootdir", "--pyargs", "--deselect-file", "--doctest-modules"}
_FILE_KEYS = ("testpaths", "norecursedirs", "python_files")
_NAME_KEYS = ("python_functions", "python_classes")
_OPAQUE_KEYS = ("usefixtures", "empty_parameter_set_mark", "collect_imported_tests", "confcutdir", "consider_namespace_packages",
                "python_paths", "pythonpath", "required_plugins", "addopts_extend")
_HARMLESS_HOOKS = {"pytest_addoption", "pytest_report_header", "pytest_report_teststatus", "pytest_terminal_summary",
                   "pytest_assertrepr_compare", "pytest_make_parametrize_id", "pytest_unconfigure", "pytest_sessionfinish"}


def _skips_inside(fn):
    """Whether a function calls pytest.skip, pytest.xfail, importorskip or skipTest, or raises SkipTest, anywhere."""
    return any(_stmt_kind(ast.Expr(value=n) if isinstance(n, ast.Call) else n) is not None
               for n in ast.walk(fn) if isinstance(n, (ast.Call, ast.Raise)))


def _registers_markers_only(fn):
    """A pytest_configure that only documents itself and calls config.addinivalue_line (registers markers)."""
    for st in fn.body:
        if isinstance(st, ast.Expr) and isinstance(st.value, ast.Constant) and isinstance(st.value.value, str):
            continue
        if (isinstance(st, ast.Expr) and isinstance(st.value, ast.Call) and isinstance(st.value.func, ast.Attribute)
                and st.value.func.attr == "addinivalue_line"):
            continue
        return False
    return True


def _config_options(path, text):
    """{key: value} of a configuration file's pytest section ({} when it has none); raises ValueError when unreadable."""
    if path == "pyproject.toml":
        tool = tomllib.loads(text).get("tool", {}).get("pytest", {})
        if not isinstance(tool, dict):
            raise ValueError("[tool.pytest] is not a table")
        opts = dict(tool.get("ini_options") or {})
        opts.update({k: v for k, v in tool.items() if k != "ini_options"})
        return opts
    cp = configparser.RawConfigParser(strict=False)
    try:
        cp.read_string(text)
    except configparser.Error as e:
        raise ValueError(str(e)) from e
    sec = "tool:pytest" if path == "setup.cfg" else "pytest"
    return dict(cp.items(sec)) if cp.has_section(sec) else {}


def _words(value):
    return [str(x) for x in value] if isinstance(value, (list, tuple)) else str(value).split()


def _addopts(value):
    toks = []
    for part in (value if isinstance(value, (list, tuple)) else [value]):
        toks += shlex.split(str(part))
    pairs, i = [], 0
    while i < len(toks):
        tok = toks[i]
        if tok.startswith("--") and "=" in tok:
            pairs.append(tuple(tok.split("=", 1)))
        elif tok in _VALUE_OPTS and i + 1 < len(toks):
            pairs.append((tok, toks[i + 1]))
            i += 1
        elif tok.startswith("-") and not tok.startswith("--") and len(tok) > 2 and tok[:2] in _VALUE_OPTS:
            pairs.append((tok[:2], tok[2:]))
        elif tok.startswith("-"):
            pairs.append((tok, ""))
        else:
            pairs.append(("", tok))
        i += 1
    return pairs


def _norm(p):
    p = p.strip()
    while p.startswith("./"):
        p = p[2:]
    return p.rstrip("/")


def _join(d, p):
    p = _norm(p)
    return _norm(f"{d}/{p}") if d and p not in ("", ".") else (d if p in ("", ".") else p)


def _under(path, base):
    base = _norm(base)
    if base in ("", "."):
        return True
    if any(ch in base for ch in "*?["):
        parts = path.split("/")
        return any(fnmatch.fnmatchcase("/".join(parts[:i]), base) for i in range(1, len(parts) + 1))
    return path == base or path.startswith(base + "/")


def _pymatch(name, pat):
    return fnmatch.fnmatchcase(name, pat) if any(ch in pat for ch in "*?[") else name.startswith(pat)


def collection_rules(files):
    """pytest's selection for one tree. files: {path: text} of the configuration files at the root and every
    conftest.py. Returns {"files": [(kind, scope, values, source)], "names": [(kind, values, source)],
    "opaque": {key: (scope, text)}}."""
    rules = {"files": [], "names": [], "opaque": {}}

    def opaque(scope, text, key=None):
        rules["opaque"][(scope, key if key is not None else text)] = (scope, text)

    for cfg in _CONFIGS:
        if cfg not in files:
            continue
        try:
            opts = _config_options(cfg, files[cfg])
            pairs = _addopts(opts["addopts"]) if "addopts" in opts else []
        except (ValueError, TypeError, AttributeError) as e:
            opaque("", f"{cfg} could not be read ({str(e)[:60]})", f"{cfg} unreadable {hashlib.sha1(files[cfg].encode()).hexdigest()}")
            continue
        for key in _FILE_KEYS:
            if key in opts:
                rules["files"].append((key, "", _words(opts[key]), cfg))
        for key in _NAME_KEYS:
            if key in opts:
                rules["names"].append((key, _words(opts[key]), cfg))
        for key in _OPAQUE_KEYS:
            if key in opts:
                opaque("", f"{key} = {' '.join(_words(opts[key]))} in {cfg}", f"{key} = {' '.join(_words(opts[key]))}")
        args = []
        for opt, val in pairs:
            if opt == "--ignore":
                rules["files"].append(("ignore", "", [val], f"addopts --ignore in {cfg}"))
            elif opt == "--ignore-glob":
                rules["files"].append(("ignore_glob", "", [val], f"addopts --ignore-glob in {cfg}"))
            elif opt == "--deselect":
                rules["names"].append(("deselect", [val], f"addopts --deselect in {cfg}"))
            elif opt == "":
                args.append(val)
            elif opt in ("-o", "--override-ini") and val.split("=", 1)[0].strip() in _FILE_KEYS + _NAME_KEYS:
                k, _, v = val.partition("=")
                rules["files" if k.strip() in _FILE_KEYS else "names"].append(
                    (k.strip(), "", v.split(), f"addopts {opt} in {cfg}") if k.strip() in _FILE_KEYS else (k.strip(), v.split(), f"addopts {opt} in {cfg}"))
            elif opt in _OPAQUE_OPTS or opt in ("-o", "--override-ini"):
                opaque("", f"addopts {opt} {val}".rstrip() + f" in {cfg}", f"addopts {opt} {val}")
        if args:
            rules["files"].append(("arguments", "", args, f"addopts in {cfg}"))
    for path, text in files.items():
        if path.rsplit("/", 1)[-1] != "conftest.py":
            continue
        d = path.rsplit("/", 1)[0] if "/" in path else ""
        try:
            tree = ast.parse(text)
        except (SyntaxError, ValueError, RecursionError):
            opaque(d, f"{path} could not be read", f"{path} unreadable {hashlib.sha1(text.encode()).hexdigest()}")
            continue

        def scan(stmts):
            for st in stmts:
                if isinstance(st, (ast.Assign, ast.AnnAssign, ast.AugAssign)):
                    targets = st.targets if isinstance(st, ast.Assign) else [st.target]
                    for name in {t.id for t in targets if isinstance(t, ast.Name)} & {"collect_ignore", "collect_ignore_glob", "pytest_plugins"}:
                        try:
                            vals = ast.literal_eval(st.value) if st.value is not None else []
                            ok = name != "pytest_plugins" and isinstance(vals, (list, tuple)) and all(isinstance(v, str) for v in vals)
                        except (ValueError, TypeError, SyntaxError, MemoryError, RecursionError):
                            ok = False
                        if ok:
                            rules["files"].append((name, d, list(vals), path))
                        else:
                            opaque(d, f"{name} in {path}", f"{name} {ast.dump(st)}")
                if (isinstance(st, ast.Expr) and isinstance(st.value, ast.Call) and isinstance(st.value.func, ast.Attribute)
                        and isinstance(st.value.func.value, ast.Name) and st.value.func.value.id in ("collect_ignore", "collect_ignore_glob")):
                    name = st.value.func.value.id
                    try:
                        vals = [ast.literal_eval(a) for a in st.value.args]
                        vals = [v for x in vals for v in (x if isinstance(x, (list, tuple)) else [x])]
                        ok = all(isinstance(v, str) for v in vals)
                    except (ValueError, TypeError, SyntaxError, MemoryError, RecursionError):
                        ok = False
                    if ok:
                        rules["files"].append((name, d, vals, path))
                    else:
                        opaque(d, f"{name} in {path}", f"{name} {ast.dump(st)}")
                k = _stmt_kind(st)
                if k:
                    rules["files"].append(("skip", d, [], path))
                elif k is False:
                    opaque(d, f"a module-level importorskip in {path}", f"statement {ast.dump(st)}")
                if isinstance(st, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    if st.name.startswith("pytest_") and st.name not in _HARMLESS_HOOKS:
                        if not (st.name == "pytest_configure" and _registers_markers_only(st)):
                            opaque(d, f"the hook {st.name} in {path}", f"hook {st.name} {ast.dump(st)}")
                    elif _skips_inside(st) and any(isinstance(n, ast.keyword) and n.arg == "autouse" and _const_truth(n.value) is not False
                                                   for dec in st.decorator_list for n in ast.walk(dec)):
                        opaque(d, f"the autouse fixture {st.name} in {path}", f"autouse {st.name} {ast.dump(st)}")
                elif isinstance(st, (ast.If, ast.Try, ast.With)) or type(st).__name__ == "TryStar":
                    for field in ("body", "orelse", "finalbody", "handlers"):
                        sub = getattr(st, field, None)
                        if isinstance(sub, list):
                            scan(sub)
                elif isinstance(st, ast.ExceptHandler):
                    scan(st.body)
        scan(tree.body)
    return rules


def file_off(rules, path):
    """Why the rules leave a test file out of collection, or None."""
    for kind, scope, vals, src in rules["files"]:
        if kind in ("testpaths", "arguments"):
            if not any(_under(path, v.split("::")[0]) for v in vals):
                return f"{kind} in {src} ({' '.join(vals)}) leaves it out" if kind == "testpaths" else f"the {kind} of {src} ({' '.join(vals)}) leave it out"
        elif kind == "norecursedirs":
            hit = next((f"{p} ({d})" for d in path.split("/")[:-1] for p in vals if fnmatch.fnmatchcase(d, p)), None)
            if hit:
                return f"norecursedirs in {src} matches {hit}"
        elif kind == "python_files":
            if not any(fnmatch.fnmatchcase(path.rsplit("/", 1)[-1], p) for p in vals):
                return f"python_files in {src} ({' '.join(vals)}) does not match it"
        elif kind in ("ignore", "collect_ignore"):
            hit = next((v for v in vals if _under(path, _join(scope, v)) and not any(ch in v for ch in "*?[")), None)
            if hit:
                return f"{'--ignore' if kind == 'ignore' else 'collect_ignore'} {hit} in {src}"
        elif kind in ("ignore_glob", "collect_ignore_glob"):
            hit = next((v for v in vals if _under(path, _join(scope, v)) or fnmatch.fnmatchcase(path, _join(scope, v))), None)
            if hit:
                return f"{'--ignore-glob' if kind == 'ignore_glob' else 'collect_ignore_glob'} {hit} in {src}"
        elif kind == "skip" and _under(path, scope):
            return f"a module-level skip in {src}"
    return None


def name_off(rules, path, q, kind):
    """Why the rules deselect one test (q: its qualified name; kind: "function" or "class"), or None."""
    parts = q.split(".")
    for key, vals, src in rules["names"]:
        if key == "deselect":
            for v in vals:
                p, _, rest = v.partition("::")
                node = re.sub(r"\[.*$", "", rest).replace("::", ".")
                if _norm(p) == path and (not node or q == node or q.startswith(node + ".")):
                    return f"--deselect {v} ({src})"
        elif key == "python_functions" and kind == "function" and not any(_pymatch(parts[-1], p) for p in vals):
            return f"python_functions in {src} ({' '.join(vals)}) does not match it"
        elif key == "python_classes":
            classes = parts if kind == "class" else parts[:-1]
            if any(not any(_pymatch(c, p) for p in vals) for c in classes):
                return f"python_classes in {src} ({' '.join(vals)}) does not match it"
    return None


def collection_files(tree):
    """The paths collection_rules reads from a tree ({path: blob})."""
    return [p for p in tree if p in _CONFIGS or p.rsplit("/", 1)[-1] == "conftest.py"]


# ---------------------------------------------------------------------------------------------- line report
_TOK = re.compile(r"\w+|[^\w\s]")
_FROM_IMPORT = re.compile(r"^from\s+(\S+)\s+import\s+\(?([^()#]*?)\)?,?\s*(?:#.*)?$")


def _subsequence(a, b):
    it = iter(b)
    return all(x in it for x in a)


def line_accounting(cand, base, theirs, ours):
    """The non-blank lines T added (theirs against base, stripped, counted as a multiset; a base copy the overseer side
    (ours) removed is not required) that the candidate's file does not have verbatim. Returns (missing, rewritten),
    each [(line, copies)] in T's order: rewritten copies are accounted for by a candidate line that is no line of T's
    file (each such line accounts for one copy): for "from M import names", an import of M whose names are a superset
    (one such import may account for several), otherwise a line holding the line's tokens in order (an argument or a
    name added, a re-wrapped expression); missing copies are found none of these ways."""
    nb = lambda text: [ln.strip() for ln in text.split("\n") if ln.strip()]  # noqa: E731
    R, B, T, P = nb(cand), nb(base), nb(theirs), nb(ours)
    tc, bc, pc, rc = (collections.Counter(x) for x in (T, B, P, R))
    # Candidate lines that are not copies of T's lines: the only ones that may stand for a changed development line.
    spare, pool = rc - tc, []
    for ln in R:
        if spare[ln] > 0:
            pool.append(ln)
            spare[ln] -= 1
    used = [False] * len(pool)
    toks = [None] * len(pool)
    imps = [_FROM_IMPORT.match(x) for x in pool]
    missing, rewritten, seen = [], [], set()
    for ln in T:
        if ln in seen or tc[ln] <= bc[ln]:
            continue
        seen.add(ln)
        need = tc[ln] - max(0, bc[ln] - pc[ln]) - rc[ln]
        if need <= 0:
            continue
        before = need
        m = _FROM_IMPORT.match(ln)
        if m:
            names = {y.strip() for y in m.group(2).split(",") if y.strip()}
            if any(x and x.group(1) == m.group(1) and names <= {y.strip() for y in x.group(2).split(",") if y.strip()} for x in imps):
                need = 0
        else:
            lt = _TOK.findall(ln)
            for i, x in enumerate(pool):
                if need <= 0:
                    break
                if used[i] or imps[i]:
                    continue
                if toks[i] is None:
                    toks[i] = _TOK.findall(x)
                if _subsequence(lt, toks[i]):
                    used[i] = True
                    need -= 1
        if before > need:
            rewritten.append((ln, before - need))
        if need > 0:
            missing.append((ln, need))
    return missing, rewritten


def lines_not_kept(cand, base, theirs, ours):
    """The development lines (line_accounting) found none of the ways: [(line, missing copies)] in T's order."""
    return line_accounting(cand, base, theirs, ours)[0]


# ---------------------------------------------------------------------------------------------- preservation policy
def _rules_of(repo, tree, texts):
    files = {}
    for p in collection_files(tree):
        if tree[p] not in texts:
            texts[tree[p]] = _text(repo, tree[p])
        files[p] = texts[tree[p]]
    return collection_rules(files)


def development_preservation(repo, p1, t, sha, who="the rebuild", report=False, newest=None, tests=True):
    """The preservation policy for a candidate (sha) that carries the development translator T merged onto the overseer
    side p1 (the merge's first parent), over every path the development side changed since merge-base(p1, T).
    newest: for an older translator merge on the candidate's line, the tree ({path: blob}) of the newest merge's T; a
    path whose candidate version is that T's, or that that T deleted, is then skipped (a newer development change
    superseded it), and a reported line that T no longer has is dropped. tests: run policy (a) (the newest merge only:
    its T carries every development test still wanted).
    Returns (merge base, holds, report):
      holds  {reason: [(path, detail)]}: (b) a path the development side changed that the candidate deleted, reverted
             to the merge base, kept although the development side deleted it, or took whole from the overseer side;
             (a) a test function or class T has under tests/ or scripts/ that the candidate's file lacks, or that T
             runs and the candidate keeps but switches off (tests_disabled; a collection rule, file_off and name_off,
             that T does not have; a cause T's own rules cannot evaluate that neither T nor p1 has);
      report (only when report=True) {"lines": {path: [(line, copies)]}, "rewritten": {path: [(line, copies)]},
             "binary": [path]}: the development lines the candidate does not have verbatim (line_accounting), on the
             paths not held: under "lines" those found none of the ways, under "rewritten" those found rewritten; a
             binary file that differs from T's is listed by path.
    The suite floor (c) is checked by the caller against the candidate's evaluation."""
    mb = _git(repo, "merge-base", p1, t).stdout.strip()
    if not mb:
        return None, {"no merge base with the overseer side": [("(all)", "")]}, {"lines": {}, "rewritten": {}, "binary": []}
    tb, tt, tp, tr = (_tree(repo, x) for x in (mb, t, p1, sha))
    holds = collections.defaultdict(list)
    rep = {"lines": {}, "rewritten": {}, "binary": []}
    held = set()
    texts = {}
    for path in sorted(set(tb) | set(tt)):
        b, tv, pv, r = tb.get(path), tt.get(path), tp.get(path), tr.get(path)
        if b == tv or r == tv:
            continue
        if newest is not None and (path not in newest or r == newest[path]):
            continue
        if tv is None:
            why = f"deleted by the development side but kept by {who}"
        elif r is None:
            why = f"deleted by {who}"
        elif r == b:
            why = "reverted to the merge base"
        elif pv != b and r == pv:
            why = "taken whole from the overseer side"
        else:
            if report:
                blobs = [_blob(repo, o) if o else b"" for o in (r, b, tv, pv)]
                if any(b"\0" in x for x in blobs):
                    rep["binary"].append(path)
                else:
                    miss, rewr = line_accounting(*(x.decode("utf-8", "replace") for x in blobs))
                    if newest is not None:
                        still = collections.Counter(ln.strip() for ln in _text(repo, newest[path]).split("\n") if ln.strip())
                        miss = [(ln, min(c, still[ln])) for ln, c in miss if still[ln]]
                        rewr = [(ln, min(c, still[ln])) for ln, c in rewr if still[ln]]
                    if miss:
                        rep["lines"][path] = miss
                    if rewr:
                        rep["rewritten"][path] = rewr
            continue
        holds[why].append((path, ""))
        held.add(path)
    if not tests:
        return mb, dict(holds), rep
    # Policy (a): pytest's selection in T, and in the candidate; a rule or hook only the candidate has.
    rt, rc_, rp = (_rules_of(repo, x, texts) for x in (tt, tr, tp))
    novel = [v for k, v in rc_["opaque"].items() if k not in rt["opaque"] and k not in rp["opaque"]]
    names_differ = rt["names"] != rc_["names"]
    disabled = collections.defaultdict(list)
    for path, tv in sorted(tt.items()):
        if not path.startswith(TEST_ROOTS) or not path.endswith(".py") or path in held:
            continue
        cv = tr.get(path)
        off_t = file_off(rt, path)
        off_c = None if off_t else file_off(rc_, path) or next(
            (f"{text} (in neither the translator nor the overseer side)" for scope, text in novel if _under(path, scope)), None)
        if cv == tv and not off_c and not names_differ:
            continue
        t_text = texts.setdefault(tv, _text(repo, tv))
        c_text = texts.setdefault(cv, _text(repo, cv)) if cv else ""
        miss = tests_missing(t_text, c_text) if cv != tv else collections.Counter()
        if miss:
            names = sorted(miss.elements())
            holds["development test(s) missing"].append(
                (path, f"{len(names)} test(s): " + ", ".join(names[:5]) + (f" (+{len(names) - 5} more)" if len(names) > 5 else "")))
        if off_t:
            continue
        try:
            ts = test_states(t_text)
        except (SyntaxError, ValueError, RecursionError):
            continue
        runs = {q: e for q, e in ts.items() if not any(e["causes"].values()) and q not in miss and not name_off(rt, path, q, e["kind"])}
        if not runs:
            continue
        off = []
        if off_c:
            off = [(q, off_c) for q in runs]
        else:
            if cv != tv:
                off = [(q, why) for q, why in tests_disabled(t_text, c_text) if q in runs]
            seen_q = {q for q, _ in off}
            off += [(q, why) for q, e in runs.items() if q not in seen_q for why in [name_off(rc_, path, q, e["kind"])] if why]
        if off:
            off.sort()
            disabled[path] = off
    for path, off in disabled.items():
        names = [q for q, _ in off]
        holds["development test(s) switched off (missing under the policy)"].append(
            (path, f"{len(names)} test(s): " + ", ".join(names[:5]) + (f" (+{len(names) - 5} more)" if len(names) > 5 else "")
             + f"; {off[0][1]}"))
    return mb, dict(holds), rep


def _hold_text(holds):
    groups = []
    for why, items in holds.items():
        shown = [p + (f" ({d})" if d else "") for p, d in items[:LIST_CAP]]
        groups.append(f"{why}: " + ", ".join(shown) + (f" (+{len(items) - LIST_CAP} more)" if len(items) > LIST_CAP else ""))
    return len({p for items in holds.values() for p, _ in items}), "; ".join(groups)


def development_report(repo, sha):
    """The line-level report for the upload note and the commit message (never a reason to hold), over every translator
    merge on sha's first-parent line since FORK (translator_merges; older merges with the newest T's skip rules): None
    when sha carries no merged development translator, else {"merge", "translator", "stem" (the newest merge's),
    "lines": {path: [(line, copies)]} (found none of the ways), "rewritten": {path: [(line, copies)]} (found rewritten),
    "binary": [path], "n" and "files": the copies and files under "lines", "m": the copies under "rewritten",
    "not_verbatim" and "not_verbatim_files": every development line not there verbatim (n + m) and the files they are
    in}."""
    merges = translator_merges(repo, sha)
    if not merges:
        return None
    newest = _tree(repo, merges[-1]["translator"])
    lines, rewritten, binary = {}, {}, []
    for i, tm in enumerate(merges):
        p1 = _git(repo, "rev-parse", tm["merge"] + "^1").stdout.strip()
        last = i == len(merges) - 1
        _, _, rep = development_preservation(repo, p1, tm["translator"], sha, report=True, newest=None if last else newest, tests=False)
        for into, part in ((lines, rep["lines"]), (rewritten, rep["rewritten"])):
            for path, items in part.items():
                have = dict(into.get(path, []))
                for ln, c in items:
                    have[ln] = max(c, have.get(ln, 0))
                into[path] = list(have.items())
        binary += [p for p in rep["binary"] if p not in binary]
    n, m = (sum(c for v in x.values() for _, c in v) for x in (lines, rewritten))
    return dict(merges[-1], lines=lines, rewritten=rewritten, binary=binary, n=n, m=m, files=len(lines), not_verbatim=n + m,
                not_verbatim_files=len(set(lines) | set(rewritten)))


# ---------------------------------------------------------------------------------------------- structure
def merge_structure(repo, m, who):
    """(reason, first parent, T): reason is None when m is a two-parent merge of the STEM-merged development translator
    T into the overseer build's line (check 4, without the harness record), else why not (p1 and T are then None)."""
    parents = _git(repo, "rev-list", "--parents", "-n1", m).stdout.split()[1:]
    if len(parents) != 2:
        return f"{who} is not a two-parent merge ({len(parents)} parent(s)): it does not merge the STEM-merged translator into the overseer build", None, None
    p1, t = parents
    if not is_ancestor(repo, FORK, p1):
        return f"{who}'s first parent {p1[:7]} is not on the overseer build's line (it does not descend from the fork point {FORK[:7]})", None, None
    stem = stem_merge(repo, m)
    if not stem:
        return f"no commit \"{STEM_MERGE_SUBJECT}\" was found (not the pinned {STEM_MERGE_SHA[:7]}, not in the history of {m[:7]}, not on the development branch)", None, None
    if not is_ancestor(repo, stem, t):
        return f"{who}'s second parent {t[:7]} does not descend from the development branch's STEM merge {stem[:7]}: {who} is not a merge of the STEM-merged translator", None, None
    if not is_ancestor(repo, t, DEV_REF):
        return f"{who}'s second parent {t[:7]} is not on the development branch ({DEV_REF.rsplit('/', 1)[-1]}): the translator it merges was never verified there", None, None
    first = overseer_first(repo)
    if not first:
        return f"the overseer build's first commit (\"{OVERSEER_FIRST_SUBJECT}\") was not found", None, None
    if not is_ancestor(repo, first, p1):
        return f"{who}'s first parent {p1[:7]} is not on the overseer build's line (it does not descend from the overseer build's first commit {first[:7]})", None, None
    # The overseer side must not already be in T's history (the merge would then bring in nothing of the overseer's own
    # line); this does not depend on where the development branch stands later (it may merge the overseer itself).
    if is_ancestor(repo, p1, t):
        return f"{who}'s first parent {p1[:7]} is already in the history of its second parent {t[:7]}: it does not merge the translator into the overseer build's line", None, None
    # Nor may T already be in the overseer side's history: such a merge brings in nothing, and taken as a translator
    # merge it would move the merge base past the development changes the checks below must cover.
    if is_ancestor(repo, t, p1):
        return f"{who}'s second parent {t[:7]} is already in the history of its first parent {p1[:7]}: it brings in nothing from the development branch", None, None
    return None, p1, t


def harness_kept(repo, t, msg, who):
    """Why msg's "Harness after the change" record drops below the translator as verified at T, or None."""
    rc, trec = newest_harness_record(repo, t)
    if not trec:
        return f"the merged translator {t[:7]} has no \"Harness after the change\" record in its first-parent history"
    own = harness_record(msg)
    low = [f"{r} " + (f"{own[r][0]}/{own[r][1]}" if r in own else "not recorded") + f" (translator {n}/{m})"
           for r, (n, m) in sorted(trec.items()) if r not in own or own[r][0] < n]
    if low:
        return f"{who}'s recorded harness drops below the translator as verified at {t[:7]} (record at {rc[:7]}): " + ", ".join(low)
    return None


def translator_checks(repo, sha, msg, is_rebuild):
    """Checks 4 and 5 for a candidate; returns (T, suite record commit, T's recorded passed count) for the evaluation's
    check (c), T being the newest translator merge's second parent, or None when the candidate carries no merged
    development translator (a build commit before the rebuild). Every translator merge on the candidate's first-parent
    line since FORK is checked, oldest first (a later merge, after the development branch merged the overseer, has a
    later merge base and would not cover the earlier development changes)."""
    if is_rebuild:
        who = by = "the rebuild"
        reason, p1, t = merge_structure(repo, sha, who)
        reason = reason or harness_kept(repo, t, msg, who)
        if reason:
            fail(reason)
    else:
        who, by = "this commit", "this commit's line"
        # A rebuild on this commit's line that is not a well-formed merge (squashed, an octopus, swapped parents) would
        # carry the translator without translator_merges finding it: such a line is held, never uploaded later.
        for ln in _git(repo, "log", "--first-parent", "--format=%H%x09%s", f"{FORK}..{sha}", "--").stdout.splitlines():
            h, _, subj = ln.partition("\t")
            if h != sha and subj.startswith("Overseer rebuild"):
                reason, _, _ = merge_structure(repo, h, f"the rebuild {h[:7]}")
                if reason:
                    fail(f"this commit sits on the rebuild {h[:7]}, which is not a well-formed translator merge: {reason}")
    steps = []
    for tm in translator_merges(repo, sha):
        m = tm["merge"]
        if is_rebuild and m == sha:
            steps.append((m, p1, t))
            continue
        reason, mp1, mt = merge_structure(repo, m, f"the translator merge {m[:7]}")
        if reason:
            fail(f"this commit carries the translator merge {m[:7]}, which does not pass the rebuild's structural checks: {reason}")
        steps.append((m, mp1, mt))
    if not steps:
        return None
    newest = _tree(repo, steps[-1][2])
    for i, (m, mp1, mt) in enumerate(steps):
        last = i == len(steps) - 1
        try:
            mb, holds, _ = development_preservation(repo, mp1, mt, sha, by, newest=None if last else newest, tests=last)
        except (subprocess.CalledProcessError, OSError) as e:
            fail(f"{who} could not be compared with the translator at {mt[:7]}: {e}")
        if holds:
            n, text = _hold_text(holds)
            on = "" if m == sha else f" (on the translator merged at {m[:7]})"
            fail(f"{who}{on} does not keep the development side's changes at {mt[:7]} (since the merge base {(mb or '')[:7]}) on {n} path(s): {text}")
    t = steps[-1][2]
    sc, passed = newest_suite_record(repo, t)
    if passed is None:
        fail(f"the merged translator {t[:7]} has no \"Suite: N passed\" record in its first-parent history")
    return t, sc, passed


# Daniel, 24 Oct 2026 ~18:25 UTC, answering "Which did you want me to go ahead with?" with "Commit both (Recommended)": commit
# the overseer rebuild after its last audit with the remaining issues recorded as known defects and publish it through the usual
# simulated publishers. So the last audit may list open issues, but only for the exact audit Daniel's approval names (by the
# sha256 of its canonical JSON, written to approvals/overseer-known-defects.json when that audit returned) and only when the
# commit message lists every one of them as a known defect ("[severity] problem", one per open issue). Every other rebuild
# check, the evaluation and the simulation are unchanged.
APPROVAL = os.path.join(os.path.dirname(os.path.abspath(__file__)), "approvals", "overseer-known-defects.json")


def audit_digest(audit):
    return hashlib.sha256(json.dumps(audit, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()


def known_defects_approved(audit, msg):
    """None when the open issues of this audit are approved as known defects and listed in the message, else the reason."""
    try:
        with open(APPROVAL, encoding="utf-8") as fh:
            ap = json.load(fh)
    except (OSError, ValueError) as e:
        return f"no recorded approval for known defects ({e.__class__.__name__})"
    if ap.get("audit_sha256") != audit_digest(audit):
        return "the recorded approval names a different audit"
    if not str(ap.get("approved_by", "")).strip() or not str(ap.get("decision", "")).strip():
        return "the recorded approval has no approver or decision"
    n = len(audit.get("violations") or [])
    if "known defect" not in msg.lower():
        return "the commit message does not record the open issues as known defects"
    listed = len(re.findall(r"\[(?:critical|blocker|high|medium|low|[a-z]+-[a-z]+|unrated)\] \S", msg, re.I))
    if listed < n:
        return f"the commit message lists {listed} known defect(s) for the audit's {n} open issue(s)"
    return None


def rebuild_checks(events, si, step, ei, ev, msg=""):
    """The rebuild workflow's own green conditions. The merge was left staged; the independent test for bugs and faults (rebuild:audit) completed after the last merge step (the
    first merge, or the repair that followed a not-ok audit) and before the evaluation, and reported ok with no
    violation (the workflow re-tests after its one repair and commits only on a clean test); the evaluation's contained
    gates and pack export passed."""
    if not isinstance(step, dict) or step.get("staged") is not True:
        fail("the rebuild step (rebuild:merge) did not leave the merge staged")
    audits = [(i, typ, r) for i, (lab, typ, r) in enumerate(events[:ei]) if i > si and lab == "rebuild:audit"]
    if not audits or audits[-1][1] != "result" or not isinstance(audits[-1][2], dict):
        repaired = sum(1 for lab, typ, r in events[:si + 1] if lab == "rebuild:merge" and typ == "result") > 1
        fail("the independent test (rebuild:audit) did not complete" + (" after the repair" if repaired else "")
             + " before the evaluation")
    # (Daniel, 23:2x: the specialist feedback function moved to the next overseer stage; the rebuild has no feedback step.)
    audit = audits[-1][2]
    if audit.get("ok") is not True or audit.get("violations"):
        n = len(audit["violations"]) if isinstance(audit.get("violations"), list) else "?"
        why = known_defects_approved(audit, msg) if isinstance(audit.get("violations"), list) and audit["violations"] else "no violation listed"
        if why:
            fail(f"the independent test (rebuild:audit) was not clean: ok={audit.get('ok')}, {n} violation(s) listed; known defects not accepted: {why}")
    if ev.get("contained_gates_ok") is not True:
        fail("the rebuild's evaluation did not record every contained gate passing (contained_gates_ok)")
    if ev.get("export_ok") is False:
        fail("the rebuild's evaluation recorded a failed knowledge-pack export (export_ok)")
    if ev.get("export_ok") is not True:
        fail(f"the rebuild's evaluation did not record a successful knowledge-pack export (export_ok not recorded: {ev.get('export_ok')!r})")


def suite_floor(ev, tsuite, rebuild):
    """(c): the evaluation passed at least as many tests as the translator's newest "Suite: N passed" record."""
    t, sc, passed = tsuite
    p = re.search(r"\b(\d+) passed\b", str(ev.get("suite_tail") or ""))
    if not p or int(p.group(1)) < passed:
        fail(f"the {'rebuild' + chr(39) + 's ' if rebuild else ''}evaluation passed fewer tests ({p.group(1) + ' passed' if p else 'no passed count'}) than the translator as verified at {t[:7]} (Suite: {passed} passed, recorded at {sc[:7]})")


def main():
    repo, sha, journal = sys.argv[1:4]
    msg = subprocess.run(["git", "-C", repo, "log", "-1", "--format=%B", sha], check=True, capture_output=True, text=True).stdout
    subject = msg.splitlines()[0] if msg else ""
    if subject.startswith("WIP"):
        fail("work in progress")
    labels = None
    for rx, f in TITLES:
        m = rx.match(subject)
        if m:
            labels = f(m)
    if not labels:
        fail("not a verified overseer build step: " + subject[:120])
    t = re.search(r"(\d+)/(\d+) tamperings detected", msg)
    if not t or int(t.group(2)) == 0:
        fail("no tampering result recorded")
    if t.group(1) != t.group(2):
        fail(f"tamperings missed: {t.group(1)}/{t.group(2)} detected")
    f = re.search(r"(\d+) false alarms", msg)
    if not f or f.group(1) != "0":
        fail("false alarms recorded: " + (f.group(1) if f else "not recorded"))
    # The build derives the suite fragment from the evaluation's last line, which can be prose; when it records a
    # count it must be green, and the journal's structured evaluation below is required in every case.
    s = re.search(r"suite (\d[^\n]*)", msg)
    if s and re.search(r"\b[1-9]\d* (failed|errors?|failures?)\b", s.group(1)):
        fail("the recorded suite has failures")
    if re.search(r"\b[1-9]\d* (failed|errors)\b", msg):
        fail("the message records failures")

    commit_label, step_label, eval_label = labels
    # Checks 4 and 5: the rebuild, and every later candidate that carries a merged development translator.
    tsuite = translator_checks(repo, sha, msg, commit_label == "commit:rebuild")
    try:
        lines = open(journal, encoding="utf-8").read().split("\n")
    except OSError:
        fail(("the rebuild's" if commit_label == "commit:rebuild" else "the build's") + " journal is unreadable")
    label_of, events = {}, []
    for line in lines:
        try:
            e = json.loads(line)
        except ValueError:
            continue
        if e.get("type") == "started":
            label_of[e.get("key")] = e.get("label")
        elif e.get("type") in ("result", "failed"):
            events.append((label_of.get(e.get("key")), e.get("type"), e.get("result")))
    at = next((i for i, (lab, typ, r) in enumerate(events) if lab == commit_label and typ == "result" and isinstance(r, dict)
               and r.get("committed") and r.get("sha") and (sha.startswith(r["sha"]) or r["sha"].startswith(sha)) and len(r["sha"]) >= 7), None)
    if at is None:
        fail(f"no journal record of {commit_label} making this commit")

    def last_before(label):
        for i in range(at - 1, -1, -1):
            lab, typ, r = events[i]
            if lab == label:
                return i, typ, r
        return None, None, None

    si, typ, step = last_before(step_label)
    if typ != "result" or not step:
        fail(f"the step before the commit ({step_label}) did not complete")
    ei, typ, ev = last_before(eval_label)
    if typ != "result" or not isinstance(ev, dict):
        fail(f"the evaluation before the commit ({eval_label}) did not complete")
    # The evaluation must measure the finished step: it must come after the step's result (an evaluation replayed from
    # the cache of an earlier, interrupted attempt would describe a partial tree).
    if commit_label == "commit:docs":
        prev_commit = max((i for i, (lab, typ2, r) in enumerate(events[:at]) if typ2 == "result" and lab and re.match(r"^commit:(review|contained)-", lab)), default=-1)
        if ei < prev_commit:
            fail("the final evaluation predates the last fix commit")
    elif ei < si:
        fail("the evaluation predates the step it should verify")
    if commit_label == "commit:rebuild":
        rebuild_checks(events, si, step, ei, ev, msg)
    if tsuite:
        suite_floor(ev, tsuite, commit_label == "commit:rebuild")
    if ev.get("suite_passed") is not True or ev.get("failing_tests"):
        fail("the evaluation did not record a passing suite")
    if not ev.get("tamperings") or ev.get("tamperings_detected") != ev.get("tamperings"):
        fail(f"the evaluation recorded {ev.get('tamperings_detected')}/{ev.get('tamperings')} tamperings detected")
    if ev.get("false_alarms_on_genuine") != 0:
        fail(f"the evaluation recorded {ev.get('false_alarms_on_genuine')} false alarms")
    tail = str(ev.get("suite_tail") or "")
    p = re.search(r"\b(\d+) passed\b", tail)
    k = re.search(r"\b(\d+) skipped\b", tail)
    print(f"OK {p.group(1) if p else 0} {k.group(1) if k else 0}")


if __name__ == "__main__":
    main()
