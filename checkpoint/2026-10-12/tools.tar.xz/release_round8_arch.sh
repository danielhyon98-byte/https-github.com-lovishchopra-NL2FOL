#!/usr/bin/env bash
# Daniel, 10 Nov 2026: "a release tag for monday's upload". Adds the annotated tag "prototype-round8-arch" on Bruno's
# repository at the verified-updates commit that uploaded source commit c4f276c (Mon 9 Nov 17:37: round 8 and the
# architecture step). Modelled on release_prototype.sh: a new tag only (no branch), an ordinary push of a new ref, an
# existing tag is never moved (the script stops instead), and the target must record a passing simulation.
# Usage: release_round8_arch.sh [--dry-run]
set -euo pipefail
case "${1:-}" in ''|--dry-run) DRY=${1:-} ;; *) echo "usage: release_round8_arch.sh [--dry-run]"; exit 2 ;; esac
R=/home/user/https-github.com-lovishchopra-NL2FOL
TAG=prototype-round8-arch
SRC_WANT=c4f276ca060909e1e7d26c2ed403a6726c50eb2c
cd "$R"
timeout 120 git fetch -q epinoic "+refs/heads/verified-updates:refs/remotes/epinoic/verified-updates" || { echo "STOP: could not fetch verified-updates"; exit 1; }
TARGET=""
for C in $(git log --format=%H refs/remotes/epinoic/verified-updates -200); do
  [ "$(git log -1 --format=%s "$C" | grep -c '^Verified update: ')" -gt 0 ] || continue
  SRC=$(git log -1 --format=%B "$C" | sed -n 's/^Source-Commit: //p' | tail -1)
  if [ "$SRC" = "$SRC_WANT" ]; then TARGET=$C; break; fi
done
[ -n "$TARGET" ] || { echo "STOP: no verified update with Source-Commit $SRC_WANT on verified-updates"; exit 1; }
[ "$(git log -1 --format=%B "$TARGET" | grep -c '^Simulation of this tree before upload: SIMULATION OK')" -gt 0 ] || { echo "HOLD: $TARGET does not record a passing simulation"; exit 1; }
set +e; timeout 120 git ls-remote --exit-code epinoic "refs/tags/$TAG" >/dev/null 2>&1; RC=$?; set -e
if [ $RC -eq 0 ]; then echo "NOTHING: $TAG already exists on Bruno's repository (never moved)"; exit 0; fi
[ $RC -eq 2 ] || { echo "STOP: could not reach Bruno's repository (ls-remote exit $RC)"; exit 1; }
echo "target: $(git log -1 --format='%h %s' "$TARGET")"
if [ "$DRY" = "--dry-run" ]; then echo "DRY RUN: would push the annotated tag $TAG at $TARGET"; exit 0; fi
if git rev-parse -q --verify "refs/tags/$TAG" >/dev/null; then
  # 10 Nov: the first push was refused (HTTP 403) after the local tag was made; reuse it only if it tags TARGET.
  [ "$(git rev-parse "refs/tags/$TAG^{commit}")" = "$TARGET" ] || { echo "STOP: local tag $TAG points elsewhere; inspect it"; exit 1; }
  echo "reusing the local tag $TAG (made 10 Nov)"
else
git -c user.name=Claude -c user.email=noreply@anthropic.com tag -a "$TAG" "$TARGET" -m "Prototype after arena round 8 and the architecture step

The translator code exactly as verified in source commit c4f276c on the development
branch: the round-8 prototype (the integrated Z3 logic translator with STEM support,
the logic-checking overseer agents with their knowledge pack, consolidation, the pool
and the delivery rule) plus the architecture step after round 8 (the overseer, flash
router, combinator and integration kit as sub-projects, the twofold review and the
feedback function). In this release the FORMALLY CHECKED label is withheld for every
answer (docs/PROTOTYPE.md).

Simulated before upload: SIMULATION OK for tree c4f276c (the recorded arena rounds r1
to r7 replay to their recorded results; contained run 355/355 tamperings). Suite and
harness numbers at the source commit are in the commit message of the tagged update.
See docs/PROTOTYPE.md and UPDATE_README.md. Results prove properties of the encoded
problems only."
fi
timeout 300 git push epinoic "refs/tags/$TAG:refs/tags/$TAG"
timeout 120 git ls-remote epinoic "refs/tags/$TAG" "refs/tags/$TAG^{}"
