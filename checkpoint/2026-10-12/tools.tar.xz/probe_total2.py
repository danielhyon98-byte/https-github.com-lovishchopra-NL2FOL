import time
from epinoic_logic.branches import quant
def tm(label, fn, ks):
    out = []
    for k in ks:
        t = time.perf_counter(); fn(k); out.append("k=%d %.3fs" % (k, time.perf_counter() - t))
    print(label, " | ".join(out), flush=True)
tm("_TOTAL_RE.search('one hundred and '*k)", lambda k: quant._TOTAL_RE.search("one hundred and " * k), [100, 200, 400, 800, 1600])
tm("_TOTAL_RE.search('one hundred and '*k + 'x')", lambda k: quant._TOTAL_RE.search("The total is one hundred and " * k + "x"), [100, 200, 400, 800, 1600])
names = [n for n in dir(quant) if n.endswith("_RE") and "TOTAL" in n.upper()]
print("total patterns:", names)
for n in names:
    pat = getattr(quant, n)
    tm(n + ".search(words)", lambda k, pat=pat: pat.search("total of one hundred and " * k), [200, 400, 800, 1600])
