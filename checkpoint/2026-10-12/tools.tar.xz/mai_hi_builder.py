#!/usr/bin/env python3
"""Builds the translation objects for mai-e1 and hi-e1a (data only; nothing here evaluates model output)."""
import json
from pathlib import Path

OUT = Path("/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/e2e/run1/translations")
TBL = "doc-bread"
PEER = "peer:maa-e1a"
NOTE = ("Scope: proves properties of this encoding only. Figures are the specialist's own, taken as written; "
        "the engine does not recompute them.")


# ---------- expression helpers (allowlisted nodes only) ----------
def V(n): return {"op": "var", "name": n}
def R(x): return {"op": "real", "value": str(x)}
def I(x): return {"op": "int", "value": str(x)}
def CMP(op, l, r): return {"op": op, "left": l, "right": r}
def AND(*a): return {"op": "and", "args": list(a)}
def IMP(l, r): return {"op": "implies", "left": l, "right": r}
def IFF(l, r): return {"op": "iff", "left": l, "right": r}
def ADD(*a): return {"op": "add", "args": list(a)}
def SUB(l, r): return {"op": "sub", "left": l, "right": r}
def MUL(*a): return {"op": "mul", "args": list(a)}
def DIV(l, r): return {"op": "div", "left": l, "right": r}

def RANGE(x, lo, hi):  # closed interval: the figure as written (half-unit bounds)
    return AND(CMP("ge", V(x), R(lo)), CMP("le", V(x), R(hi)))

def ROUND(x, lo, hi):  # rounding claim: lo <= x < hi
    return AND(CMP("ge", V(x), R(lo)), CMP("lt", V(x), R(hi)))


# ---------- structure helpers ----------
def G(kind, cert="established", refs=(), note=None):
    g = {"kind": kind, "source_refs": [], "certainty": cert}
    for doc, exc in refs:
        g["source_refs"].append({"document_id": doc, "excerpt": exc} if exc else {"document_id": doc})
    if note:
        g["note"] = note
    return g

def S(name, sort, meaning, grounding=None):
    return {"name": name, "sort": sort, "meaning": meaning, "grounding": grounding}

def P(pid, expr, label, grounding):
    return {"id": pid, "expr": expr, "label": label, "grounding": grounding, "materiality": "material"}

def C(expr, label):
    return {"id": "concl", "expr": expr, "label": label, "grounding": None, "materiality": "material"}

def FLAG(code, msg, alts):
    return {"code": code, "message": msg, "alternatives": list(alts)}

def PROB(pid, claim_id, req, symbols, premises, concl):
    return {"ir_version": "1.0", "problem_id": pid, "request_id": req, "claim_id": claim_id,
            "query": "entailment", "symbols": symbols, "premises": premises, "conclusion": concl,
            "notes": NOTE}

def CL(problem, reading, flags=(), ambiguous=False):
    gl = [{"symbol": s["name"], "meaning": s["meaning"], "grounding": None} for s in problem["symbols"]]
    return {"problem": problem,
            "interpretation": {"reading": reading, "glossary": gl, "ambiguity_flags": list(flags)},
            "ambiguous": ambiguous, "unsupported_reason": None}

def NULL(reason, reading):
    return {"problem": None,
            "interpretation": {"reading": reading, "glossary": [], "ambiguity_flags": []},
            "ambiguous": False, "unsupported_reason": reason}


# =====================================================================
# mai-e1 (request req-mai-e1, report rep-mai-e1-0)
# =====================================================================
REQ_M = "req-mai-e1"

def sym_pmt_exact(): return S("pmt_exact", "Real", "magnitude of the monthly payment (EUR), unrounded solver figure", G("specialist_inference"))
def sym_total(): return S("total_repaid", "Real", "total amount repaid over the loan (EUR)")
def sym_pmt_paid(): return S("pmt_paid", "Real", "monthly payment actually made (EUR, exact to the cent)", G("specialist_inference"))
def sym_loan(): return S("loan_amt", "Real", "amount borrowed (EUR)", G("arithmetic_fact"))
def sym_interest(): return S("interest_total", "Real", "total interest paid (EUR)")

def pr_total_link():
    return P("pr_total_link", CMP("eq", V("total_repaid"), MUL(R("60"), V("pmt_paid"))),
             "total repaid is 60 equal monthly payments of the payment made",
             G("specialist_inference", note="the claim's own instalment step"))

def pr_pmt_paid():
    return P("pr_pmt_paid", CMP("eq", V("pmt_paid"), R("352.19")),
             "the payment actually made is €352.19 to the cent",
             G("specialist_inference", note="from m5.1 and m9.1: the payment made is an exact cent amount"))

def pr_loan():
    return P("pr_loan", CMP("eq", V("loan_amt"), R("18000")), "she borrows €18 000", G("arithmetic_fact"))

def pr_int_link():
    return P("pr_int_link", CMP("eq", V("interest_total"), SUB(V("total_repaid"), V("loan_amt"))),
             "interest is total repaid minus amount borrowed", G("specialist_inference"))

def sym_g24(): return S("g24", "Real", "growth factor (1 + 0.065/12)^24, written 1.138429…", G("specialist_inference"))
def sym_bal24(): return S("bal24", "Real", "balance after 24 monthly payments, second route (EUR)")
def sym_owed(): return S("owed_2y", "Real", "amount still owed after 2 years (EUR)")

def pr_g24():
    return P("pr_g24", RANGE("g24", "1.1384285", "1.1384295"),
             "(1 + 0.065/12)^24 = 1.138429… (6 dp, read as the half-unit interval)",
             G("specialist_inference", note="figure from the claim m14.1 itself"))

def pr_bal_link():
    return P("pr_bal_link",
             CMP("eq", V("bal24"), SUB(MUL(R("18000"), V("g24")),
                                       MUL(R("352.19"), DIV(SUB(V("g24"), R("1")), R("13/2400"))))),
             "balance = 18 000 × growth − 352.19 × (growth − 1) ÷ (0.065/12)",
             G("specialist_inference", note="the claim's own second-route formula; 0.065/12 = 13/2400"))

PREC_FLAG = FLAG("vague_figure_precision",
                 "The growth factor is written 1.138429… with an ellipsis. Across its stated interval the balance "
                 "moves by about 0.05, so the cent-level result is not fixed by the figures as written.",
                 ["read the growth factor as exactly 1.138429",
                  "read it as the half-unit interval of its written precision (balance not fixed to the cent)"])

def sym_p_tall(): return S("p_tall", "Real", "P(X > 190) for X ~ N(170, 12²)", G("specialist_inference"))

def pr_p_tall():
    return P("pr_p", RANGE("p_tall", "0.047785", "0.047795"),
             "P(X > 190) = 0.04779… (5 dp, read as the half-unit interval)",
             G("specialist_inference", note="figure from the supporting claim m19.1"))

def pr_exp():
    return P("pr_exp", CMP("eq", V("expected_tall"), MUL(R("400"), V("p_tall"))),
             "expected number = 400 × P(X > 190)", G("specialist_inference"))

def sym_expected(): return S("expected_tall", "Real", "expected number of the 400 sunflowers taller than 190 cm")

def pr_z():
    return P("pr_z", RANGE("z_h", "-1.281555", "-1.281545"),
             "the z-score for an area of 0.10 to the left is −1.28155… (5 dp, half-unit interval)",
             G("specialist_inference", note="figure from the supporting claim m21.1"))

def pr_h_link():
    return P("pr_h_link", CMP("eq", V("h_cm"), ADD(R("170"), MUL(R("12"), V("z_h")))),
             "standardising: (h − 170)/12 = z, so h = 170 + 12z", G("specialist_inference"))

def sym_z(): return S("z_h", "Real", "z-score of h: area 0.10 to the left", G("specialist_inference"))
def sym_h(): return S("h_cm", "Real", "height h (cm) below which 10% of the sunflowers lie")


def build_mai():
    rid = "rep-mai-e1-0"
    cl = {}
    def pid(c): return "mai-" + c.replace(".", "-")

    # ---- Question 1: loan ----
    cl["m1.1"] = NULL("A sign convention for the finance solver's inputs and outputs. It asserts no figure about the loan, "
                      "and encoded alone it restates itself, so there is no relation to check.",
                      "Read as a statement of how the solver signs PV, PMT and FV. The later monthly-payment and balance "
                      "claims carry their own figures.")
    cl["m1.2"] = NULL("An assumption about timing (payments at the end of each month) and a solver setting (P/Y = C/Y = 12). "
                      "It is not a proposition about the loan figures and has no conclusion to check.",
                      "Read as a modelling assumption and calculator setting, supporting only the sign convention m1.1.")
    cl["m3.1"] = NULL("The equation needs the factor (1 + 0.065/12)^(−60), an exponential that IR 1.0 cannot express "
                      "(no power operator). The report states no value for that factor, and supplying one would invent a figure.",
                      "Read as the annuity formula for the monthly payment with 60 instalments at 0.065/12 per month.")
    cl["m4.1"] = NULL("This is the finance solver's output, PMT = −352.1907…. Checking it needs the exponential in m3.1, "
                      "which IR 1.0 cannot compute, so the only encodable form restates the figure. The figure is used "
                      "as a premise in m5.1 instead.",
                      "Read as the solver output for the stated inputs.")
    cl["m5.1"] = CL(PROB(pid("m5.1"), "m5.1", REQ_M, [sym_pmt_exact()],
                         [P("pr_solver", RANGE("pmt_exact", "352.19065", "352.19075"),
                            "the solver gives the monthly payment as 352.1907… (magnitude)",
                            G("specialist_inference", note="figure from the supporting claim m4.1, written to 4 dp with an ellipsis; read as the half-unit interval"))],
                         C(ROUND("pmt_exact", "352.185", "352.195"), "to the cent, her monthly payment is €352.19")),
                    "Read as a rounding claim: the solver figure from m4.1 (magnitude 352.1907…, read at its written precision) "
                    "is encoded as rounding to €352.19 at the cent. The solver figure itself is not recomputed.")
    cl["m6.1"] = CL(PROB(pid("m6.1"), "m6.1", REQ_M, [sym_total(), sym_pmt_paid()],
                         [pr_total_link(), pr_pmt_paid()],
                         C(CMP("eq", V("total_repaid"), MUL(R("60"), R("352.19"))), "total repaid = 60 × 352.19")),
                    "Total repaid is 60 equal instalments of the payment made (€352.19). The check is the product 60 × 352.19.")
    cl["m7.1"] = CL(PROB(pid("m7.1"), "m7.1", REQ_M, [sym_total(), sym_pmt_paid()],
                         [pr_total_link(), pr_pmt_paid()],
                         C(ROUND("total_repaid", "21131.395", "21131.405"), "total repaid is 21 131.40 to the cent")),
                    "Same instalment chain as m6.1; the claim is the product, read as a rounding claim to the cent.")
    cl["m8.1"] = CL(PROB(pid("m8.1"), "m8.1", REQ_M, [sym_total(), sym_pmt_paid()],
                         [pr_total_link(), pr_pmt_paid()],
                         C(ROUND("total_repaid", "21131.395", "21131.405"), "she repays €21 131.40 in total")),
                    "The conclusion is the total repaid to the cent, with the instalment chain as premises (m6.1 and m7.1).")
    cl["m9.1"] = NULL("It states which figure the arithmetic uses (the cent-rounded payment), a choice of method rather than a "
                      "proposition about the loan. The substitution it describes is encoded in m6.1.",
                      "Read as a statement that the total is built from the cent payment, not the unrounded solver figure.")
    cl["m10.1"] = CL(PROB(pid("m10.1"), "m10.1", REQ_M, [sym_total(), sym_pmt_paid(), sym_loan(), sym_interest()],
                          [pr_total_link(), pr_pmt_paid(), pr_loan(), pr_int_link()],
                          C(ROUND("interest_total", "3131.395", "3131.405"), "total interest is €3131.40")),
                     "Interest is total repaid minus the €18 000 borrowed. The check runs that subtraction on the chain from m6.1 and m7.1.")
    cl["m11.1"] = CL(PROB(pid("m11.1"), "m11.1", REQ_M, [sym_total(), sym_loan(), sym_interest()],
                          [P("pr_total_fig", ROUND("total_repaid", "21131.395", "21131.405"),
                             "total repaid is 21 131.40 (stated in m8.1)", G("specialist_inference")),
                           pr_loan(), pr_int_link()],
                          C(ROUND("interest_total", "3131.395", "3131.405"), "she pays €3131.40 in interest")),
                     "The interest figure is the stated total from m8.1 minus the loan. The claim restates the result of m10.1.")
    cl["m12.1"] = CL(PROB(pid("m12.1"), "m12.1", REQ_M,
                          [S("years_after", "Int", "years after the loan starts (task: 2)", G("task_setting")),
                           S("n_pay", "Int", "number of monthly payments made when the owed amount is read")],
                          [P("pr_years", CMP("eq", V("years_after"), I(2)), "the owed amount is read after 2 years", G("task_setting")),
                           P("pr_n", CMP("eq", V("n_pay"), MUL(I(12), V("years_after"))),
                             "there are 12 monthly payments a year", G("specialist_inference"))],
                          C(CMP("eq", V("n_pay"), I(24)), "N = 24: the owed amount is the balance after the 24th payment")),
                     "Two years of monthly payments is 24 payments. Treating the owed amount as the balance after payment 24 is the "
                     "method's convention; the checked content is N = 24.")
    cl["m13.1"] = NULL("Solver output for the balance after 24 months (FV = −11 491.11). It needs the exponential "
                       "(1 + 0.065/12)^24, which IR 1.0 cannot express, so the only encodable form restates the figure. "
                       "The balance is checked through the second-route encoding in m14.1 instead.",
                       "Read as the finance solver's output for N = 24, PMT = −352.19.")
    cl["m14.1"] = CL(PROB(pid("m14.1"), "m14.1", REQ_M, [sym_g24(), sym_bal24()],
                          [pr_g24(), pr_bal_link()],
                          C(ROUND("bal24", "11491.105", "11491.115"), "by the second route she still owes €11 491.11")),
                     "The second route, with the growth factor as the specialist's figure read at its written precision and the claim's "
                     "balance formula. The cent-level result is not entailed: the figure as written does not fix the balance to the cent. "
                     "This is a finding about stated precision, not a check of the arithmetic beyond it.",
                     [PREC_FLAG], ambiguous=True)
    cl["m15.1"] = CL(PROB(pid("m15.1"), "m15.1", REQ_M, [sym_g24(), sym_bal24(), sym_owed()],
                          [pr_g24(), pr_bal_link(),
                           P("pr_owed", CMP("eq", V("owed_2y"), V("bal24")),
                             "the amount owed after 2 years is the balance after payment 24 (m12.1)",
                             G("specialist_inference"))],
                          C(ROUND("owed_2y", "11491.105", "11491.115"), "after 2 years she still owes €11 491.11")),
                     "The owed amount after 2 years, read as the balance after payment 24 (m12.1), from the second-route formula used in "
                     "m14.1. Same precision limit: not entailed at the cent.",
                     [PREC_FLAG], ambiguous=True)
    cl["m16.1"] = NULL("The balance with the unrounded payment multiplies two uncertain figures (the payment and the growth factor). "
                       "IR 1.0 allows only one non-constant factor in a product, so this cannot be encoded without dropping part of the meaning.",
                       "Read as a counterfactual: the same balance formula with the unrounded payment 352.1907….")

    # ---- Question 2: normal distribution ----
    cl["m17.1"] = NULL("A definition of a random variable and its normal distribution. It asserts no relation among figures, "
                       "and IR 1.0 has no distribution functions.",
                       "Read as the setup: X is the sunflower height with mean 170 cm and variance 144 cm².")
    cl["m17.2"] = NULL("A convention about the calculator's input (the standard deviation, not the variance). It is not a "
                       "proposition about the sunflower figures.",
                       "Read as a note on the calculator input σ = 12.")
    cl["m18.1"] = NULL("A bare probability expression with no asserted value, so there is no proposition to encode.",
                       "Read as the target of part (a): P(X > 190).")
    cl["m19.1"] = NULL("The value 0.04779… comes from the normal distribution function, which IR 1.0 cannot compute. Its only "
                       "encodable form restates the figure. The figure is used as a premise in m20.1, m24.1 and m25.1.",
                       "Read as the calculator output for P(X > 190) with μ = 170 and σ = 12.")
    cl["m20.1"] = CL(PROB(pid("m20.1"), "m20.1", REQ_M, [sym_p_tall()], [pr_p_tall()],
                          C(ROUND("p_tall", "0.04775", "0.04785"), "to 3 s.f., P(X > 190) = 0.0478")),
                     "A rounding check: the figure from m19.1, read as its half-unit interval, rounds to 0.0478 at 3 s.f.")
    cl["m21.1"] = NULL("The inverse normal value z = −1.28155… comes from the inverse normal distribution, which IR 1.0 cannot compute. "
                       "Its only encodable form restates the figure. The figure is used as a premise in m22.1 and m23.1.",
                       "Read as the standardisation (h − 170)/12 = z, with the area 0.10 to the left of h.")
    cl["m22.1"] = CL(PROB(pid("m22.1"), "m22.1", REQ_M, [sym_z(), sym_h()], [pr_z(), pr_h_link()],
                          C(ROUND("h_cm", "154.6205", "154.6215"), "h = 154.621… cm")),
                     "The standardisation h = 170 + 12z, with the z-score from m21.1 read at its written precision, gives h to the "
                     "written precision of 154.621….")
    cl["m23.1"] = CL(PROB(pid("m23.1"), "m23.1", REQ_M, [sym_z(), sym_h()], [pr_z(), pr_h_link()],
                          C(ROUND("h_cm", "154.5", "155.5"), "to 3 s.f., h = 155 cm")),
                     "Same standardisation chain as m22.1; the claim is a rounding to 3 s.f.")
    cl["m24.1"] = CL(PROB(pid("m24.1"), "m24.1", REQ_M, [sym_p_tall(), sym_expected()],
                          [pr_p_tall(), pr_exp()],
                          C(ROUND("expected_tall", "19.1155", "19.1165"), "expected number = 19.116…")),
                     "The expected number is 400 times P(X > 190), using the figure from m19.1. At its written precision 0.04779… fixes "
                     "the product only to about ±0.002, so the 3-decimal claim 19.116… is not entailed.",
                     [FLAG("vague_figure_precision",
                           "The probability is written 0.04779… and the product 19.116…, both with ellipses. At the written precision "
                           "the product cannot be fixed to three decimals.",
                           ["read 0.04779 as exact (then 400 × 0.04779 = 19.116)",
                            "read it as the half-unit interval of its written precision (not fixed to 3 dp)"])],
                     ambiguous=True)
    cl["m25.1"] = CL(PROB(pid("m25.1"), "m25.1", REQ_M, [sym_p_tall(), sym_expected()],
                          [pr_p_tall(), pr_exp()],
                          C(ROUND("expected_tall", "19.05", "19.15"), "to 3 s.f., the expected number taller than 190 cm is 19.1")),
                     "A rounding check: 400 times the m19.1 probability, read at its written precision, rounds to 19.1 at 3 s.f.")

    return {"report_id": rid, "claims": cl}


# =====================================================================
# hi-e1a (request req-e1a, report rep-hi-e1a-0)
# =====================================================================
REQ_H = "req-e1a"
EXC_SEP = "September 1923 | 1,512,000"
EXC_NOV = "November 1923 | 201,000,000,000"
EXC_JUL = "July 1923 | 3,465"
EXC_RATE1 = "≈ 1.55 per month"
EXC_RATE2 = "≈ 20.9 per month"
EXC_RATE3 = "≈ 365 per month"
EXC_PRED = "5.51 × 10⁷ marks"
EXC_RATIO = "about 1.59 × 10⁴ times the table value"
EXC_NOWHY = "they do not show why prices rose."


def build_hi():
    rid = "rep-hi-e1a-0"
    cl = {}
    def pid(c): return "hi-" + c.replace(".", "-")

    # h1.1: 'because the dates separate the two' -> 'not the main reason'
    cl["h1.1"] = CL(PROB(pid("h1.1"), "h1.1", REQ_H,
                         [S("y_peak", "Int", "year of the highest bread price in the table (1923)",
                            G("supplied_text", refs=[(TBL, EXC_NOV)], note="structural fact: the highest price is the November 1923 row")),
                          S("y_surge", "Int", "year of the electoral surge (the 1930 Reichstag election)", G("general_knowledge")),
                          S("sep_dates", "Bool", "the electoral surge came after the inflation peak (the dates separate the two)",
                            G("specialist_inference")),
                          S("not_main", "Bool", "hyperinflation was not the main reason people began voting for the Nazis")],
                         [P("pr_peak", CMP("eq", V("y_peak"), I(1923)), "the inflation peak falls in 1923",
                            G("supplied_text", refs=[(TBL, EXC_NOV)])),
                          P("pr_surge", CMP("eq", V("y_surge"), I(1930)), "the electoral surge came in the 1930 Reichstag election",
                            G("general_knowledge")),
                          P("pr_sep", IFF(V("sep_dates"), CMP("gt", V("y_surge"), V("y_peak"))),
                            "the surge is separated from the peak: it came later", G("specialist_inference")),
                          P("pr_link", IMP(V("sep_dates"), V("not_main")),
                            "dates separated from the peak mean hyperinflation was not the main reason", G("specialist_inference"))],
                         C(V("not_main"), "hyperinflation was not the main reason people began voting for the Nazis")),
                    "'Not the main reason, because the dates separate the two': the table's peak year (1923) and the surge year (1930, memory) "
                    "are compared, and the specialist's 'because' link is encoded as a premise. The conclusion is valid only given that link.",
                    [FLAG("because_reading",
                          "'because the dates separate the two' can be read as evidential (the timing shows the vote did not follow the "
                          "inflation) or causal (the inflation did not produce the vote). The encoding takes the timing link as the specialist's.",
                          ["evidential: the timing rules out the inflation as the main trigger of the vote",
                           "causal: the inflation did not cause the vote"])],
                    ambiguous=True)

    # h1.2: table values and quoted peer rates, ordered
    cl["h1.2"] = CL(PROB(pid("h1.2"), "h1.2", REQ_H,
                         [S("price_sep23", "Real", "table price of a loaf in September 1923 (marks)", G("quotation", refs=[(TBL, EXC_SEP)])),
                          S("price_nov23", "Real", "table price of a loaf in November 1923 (marks)", G("quotation", refs=[(TBL, EXC_NOV)])),
                          S("rate_jan_jul", "Real", "Mathematics specialist's monthly factor, January to July 1923 (≈ 1.55)",
                            G("quotation", refs=[(PEER, EXC_RATE1)])),
                          S("rate_jul_sep", "Real", "Mathematics specialist's monthly factor, July to September 1923 (≈ 20.9)",
                            G("quotation", refs=[(PEER, EXC_RATE2)])),
                          S("rate_sep_nov", "Real", "Mathematics specialist's monthly factor, September to November 1923 (≈ 365)",
                            G("quotation", refs=[(PEER, EXC_RATE3)]))],
                         [P("pr_sep", CMP("eq", V("price_sep23"), R("1512000")), "the table gives 1,512,000 marks in September 1923",
                            G("quotation", refs=[(TBL, EXC_SEP)])),
                          P("pr_nov", CMP("eq", V("price_nov23"), R("201000000000")), "the table gives 201,000,000,000 marks in November 1923",
                            G("quotation", refs=[(TBL, EXC_NOV)])),
                          P("pr_rate1", RANGE("rate_jan_jul", "1.545", "1.555"), "the Mathematics specialist gives ≈ 1.55 per month, January to July",
                            G("quotation", refs=[(PEER, EXC_RATE1)])),
                          P("pr_rate2", RANGE("rate_jul_sep", "20.85", "20.95"), "the Mathematics specialist gives ≈ 20.9 per month, July to September",
                            G("quotation", refs=[(PEER, EXC_RATE2)])),
                          P("pr_rate3", RANGE("rate_sep_nov", "364.5", "365.5"), "the Mathematics specialist gives ≈ 365 per month, September to November",
                            G("quotation", refs=[(PEER, EXC_RATE3)]))],
                         C(AND(CMP("gt", V("price_nov23"), V("price_sep23")),
                               CMP("gt", V("rate_sep_nov"), V("rate_jul_sep")),
                               CMP("gt", V("rate_jul_sep"), V("rate_jan_jul"))),
                           "prices rose fastest in autumn 1923: the November price exceeds the September price, and the monthly rates increase in turn")),
                    "Checks the ordering in the claim: the table's September and November prices, and the peer's quoted monthly rates read at their "
                    "written precision (≈ read as the stated precision), each quoted from its source. The claim's 'shows the acceleration' is the rate ordering.")

    # h1.6: the peer's July prediction against the table value, and the specialist's own quoted sentence
    cl["h1.6"] = CL(PROB(pid("h1.6"), "h1.6", REQ_H,
                         [S("pred_jul23", "Real", "the model's July 1923 prediction (marks)", G("quotation", refs=[(PEER, EXC_PRED)])),
                          S("table_jul23", "Real", "table price of a loaf in July 1923 (marks)", G("quotation", refs=[(TBL, EXC_JUL)])),
                          S("ratio_claim", "Bool", "the prediction is about 1.59 × 10⁴ times the table value",
                            G("arithmetic_fact", refs=[(PEER, EXC_RATIO), (TBL, EXC_JUL)])),
                          S("cannot_show", "Bool", "the model cannot show what prices did"),
                          S("quote_no_why", "Bool", "the specialist's words: the model does not show why prices rose",
                            G("quotation", refs=[(PEER, EXC_NOWHY)]))],
                         [P("pr_pred", RANGE("pred_jul23", "55050000", "55150000"), "the prediction is 5.51 × 10⁷ marks (3 s.f., half-unit interval)",
                            G("quotation", refs=[(PEER, EXC_PRED)])),
                          P("pr_table", CMP("eq", V("table_jul23"), R("3465")), "the table gives 3,465 marks for July 1923",
                            G("quotation", refs=[(TBL, EXC_JUL)])),
                          P("pr_ratio", V("ratio_claim"), "the prediction is about 1.59 × 10⁴ times the table value",
                            G("arithmetic_fact", refs=[(PEER, EXC_RATIO), (TBL, EXC_JUL)])),
                          P("pr_ratio_check",
                            IFF(V("ratio_claim"), AND(CMP("ge", V("pred_jul23"), MUL(R("15850"), V("table_jul23"))),
                                                      CMP("lt", V("pred_jul23"), MUL(R("15950"), V("table_jul23"))))),
                            "the ratio rounds to 1.59 × 10⁴ at 3 s.f.: 15 850 ≤ prediction ÷ table < 15 950",
                            G("arithmetic_fact")),
                          P("pr_link", IMP(V("ratio_claim"), V("cannot_show")),
                            "so it cannot show what prices did", G("specialist_inference")),
                          P("pr_quote", V("quote_no_why"), "they do not show why prices rose (the specialist's words)",
                            G("quotation", refs=[(PEER, EXC_NOWHY)]))],
                         C(AND(V("cannot_show"), V("quote_no_why")),
                           "the prediction is about 1.59 × 10⁴ times the table value, so it cannot show what prices did, and the specialist says it does not show why prices rose")),
                    "The 3-significant-figure ratio is checked against the quoted prediction and the table value. The 'so it cannot show' step is the "
                    "specialist's link, encoded as a premise, and the quoted sentence is a quotation premise. The conclusion depends on that link.")

    # h1.8: 'therefore' the Depression matters
    cl["h1.8"] = CL(PROB(pid("h1.8"), "h1.8", REQ_H,
                         [S("y_surge", "Int", "year of the electoral surge (the 1930 Reichstag election)", G("general_knowledge")),
                          S("y_dep", "Int", "year the Depression reached Germany (1929)", G("general_knowledge")),
                          S("dep_timing", "Bool", "the surge came once the Depression had reached Germany", G("specialist_inference")),
                          S("not_main", "Bool", "hyperinflation was not the main reason people began voting for the Nazis"),
                          S("depression_matters", "Bool", "the Depression is the economic crisis that matters for the Nazi vote")],
                         [P("pr_not_main", V("not_main"), "hyperinflation was not the main reason (the conclusion of h1.1)",
                            G("specialist_inference")),
                          P("pr_surge", CMP("eq", V("y_surge"), I(1930)), "the electoral surge came in 1930", G("general_knowledge")),
                          P("pr_dep", CMP("eq", V("y_dep"), I(1929)), "the Depression reached Germany in 1929", G("general_knowledge")),
                          P("pr_dep_timing", IFF(V("dep_timing"), CMP("gt", V("y_surge"), V("y_dep"))),
                            "the surge came after the Depression had reached Germany", G("specialist_inference")),
                          P("pr_link", IMP(AND(V("not_main"), V("dep_timing")), V("depression_matters")),
                            "the dates point to the Depression as the crisis that matters for the vote", G("specialist_inference"))],
                         C(V("depression_matters"), "the Depression is the economic crisis that matters for the Nazi vote")),
                    "'Therefore': from the h1.1 conclusion and the timing (surge after the 1929 Depression), the specialist's link gives that the "
                    "Depression matters. Entailed only given that link.")

    # h1.10: the verdict on the student's claim
    cl["h1.10"] = CL(PROB(pid("h1.10"), "h1.10", REQ_H,
                          [S("not_main", "Bool", "hyperinflation was not the main reason people began voting for the Nazis"),
                           S("claim_fails", "Bool", "the student's claim (hyperinflation was the main reason) fails as worded")],
                          [P("pr_not_main", V("not_main"), "hyperinflation was not the main reason (the conclusion of h1.1)",
                             G("specialist_inference")),
                           P("pr_fail", IMP(V("not_main"), V("claim_fails")),
                             "the claim fails if hyperinflation was not the main reason", G("specialist_inference"))],
                          C(V("claim_fails"), "the claim, as worded, fails")),
                     "Verdict on the student's claim: it fails when hyperinflation is not the main reason (h1.1). The step is the specialist's link.")

    # not encodable
    cl["h1.3"] = NULL("The claim is a set of historical facts from memory: the November 1923 currency reform, the Nazi party's ban after "
                      "the Munich Putsch, and its small share in the 1928 election. Each is general knowledge with no relation among "
                      "figures to check, and 'still small' is an unquantified comparison, so an encoding would only restate the facts.",
                      "Read as three memory facts supporting the point that the inflation's end and the Nazi party's weakness in 1928.")
    cl["h1.7"] = NULL("The claim places the 1930 election 'nearly seven years' after the inflation peak. That needs month-level dates "
                      "and a tolerance for 'nearly', and IR 1.0 has no date type. Encoding only the year comparison would drop the "
                      "'nearly seven years' part of the claim. The 1930-after-1929 relation is encoded in h1.8.",
                      "Read as a timing claim: election in 1930, inflation peak about seven years earlier, Depression from 1929.")

    return {"report_id": rid, "claims": cl}


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    for task, builder in (("mai-e1", build_mai), ("hi-e1a", build_hi)):
        obj = builder()
        path = OUT / f"{task}.json"
        path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
        n_prob = sum(1 for v in obj["claims"].values() if v["problem"] is not None)
        print(f"{task}: wrote {path} claims={len(obj['claims'])} problems={n_prob} nulls={len(obj['claims']) - n_prob}")


if __name__ == "__main__":
    main()
