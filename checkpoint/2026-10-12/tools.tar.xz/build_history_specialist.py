import json
import os

BASE = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/arena/r2"
TASKS = os.path.join(BASE, "tasks.json")
OUT_DIR = os.path.join(BASE, "specialists")

RESPONSES = {
    "hi-t3": (
        "The Great Leap Forward explains the famine to a large extent, though not wholly: it removed the grain reserves and the labour that a poor harvest needs in order to remain a shortage rather than become a catastrophe. "
        "By the end of 1958 nearly all rural households had been placed in people's communes, where communal canteens consumed private grain stores, and millions of peasants were drawn from the fields into backyard steel furnaces to meet a national target of 10.7 million tonnes of steel. "
        "The decisive error followed in 1959. State procurement quotas were fixed against a claimed 1958 harvest of 375 million tonnes, a figure later revised to about 200 million, so grain was requisitioned from villages that had little left to eat. "
        "Revised official output then fell to about 170 million tonnes in 1959 and about 144 million in 1960, while the recorded population dropped by roughly eleven million in 1960 alone and the crude death rate reached about 25 per thousand that year. "
        "The counter-case rests on drought and flood in several provinces between 1959 and 1961, which the leadership of the early 1960s itself blamed as 'three years of natural disasters', and on the withdrawal of Soviet experts in July 1960. "
        "Weather explains part of the fall in output, but it does not explain why requisitioning continued after that fall was visible, or why cadres kept reporting surpluses. "
        "These practices persisted after the Lushan plenum of July and August 1959, which condemned Peng Dehuai for criticising the Leap and silenced reports of shortfall. "
        "By the criterion of persistence, policy rather than weather decided the scale of the famine, so the Leap was the mechanism through which a bad harvest became mass death.\n"
        "Dates and figures are from memory; verify them against your notes before use.\n"
        "Syllabus version and level were not stated, so no band or mark is given."
    ),
    "hi-t4": (
        "The Wall Street Crash affected the American economy through the collapse of share values, the failure of banks and the fall in trade, and these effects compounded one another. "
        "The Dow Jones Industrial Average fell from about 381 in September 1929 to about 41 in July 1932 (figures from memory; check your notes). "
        "Some 9,000 banks failed between 1930 and 1933 and the money supply fell by roughly a third, so firms and farmers lost the credit needed to keep producing. "
        "Prices fell by about a quarter, real output fell by roughly a quarter, and unemployment reached about 25 per cent of the workforce in 1933. "
        "The Smoot-Hawley tariff of June 1930 and the collapse of world trade cut US exports by about two-thirds between 1929 and 1933. "
        "On balance the banking collapse mattered most, because it was the channel through which the other effects spread: deflation and mass unemployment followed the destruction of credit, and the trade fall deepened a contraction already under way. "
        "By the criterion of persistence, the bank failures explain why the downturn became a depression rather than a sharp fall in share prices.\n"
        "Syllabus version and level were not stated."
    ),
    "hi-p1": (
        "Shelley's sonnet was written in 1817 and printed in January 1818 in The Examiner, the radical weekly edited by Leigh Hunt. "
        "Two developments of the years before framed it; dates other than the poem's own are from memory, so check your notes. "
        "Egyptian antiquities had reached Britain in quantity: the Rosetta Stone entered the British Museum in 1802, and in 1816 Giovanni Belzoni, working for the consul Henry Salt, removed a colossal head of Ramesses II from Thebes, which reached London in 1817. "
        "Shelley drew on Diodorus Siculus's account of an Egyptian statue inscribed with the name Ozymandias, so a desert ruin became a subject of public interest in London. "
        "Britain after Waterloo, fought on 18 June 1815, was a country of postwar distress and repression: the Corn Law of 1815 kept foreign wheat out until domestic prices reached 80 shillings a quarter, demobilisation swelled unemployment, and after a crowd broke a window of the Prince Regent's carriage in January 1817, Parliament suspended habeas corpus in March. "
        "A poem about a king whose works lie in ruins therefore appeared in a country that had just seen its rulers' authority challenged and then restrained by law."
    ),
}


def main():
    with open(TASKS, encoding="utf-8") as f:
        tasks = json.load(f)

    targets = [t for t in tasks if t.get("agent_id") == "history-specialist"]
    target_ids = {t["task_id"] for t in targets}
    assert target_ids == set(RESPONSES), (target_ids, set(RESPONSES))

    os.makedirs(OUT_DIR, exist_ok=True)
    for t in targets:
        tid = t["task_id"]
        record = dict(t)
        record["response_text"] = RESPONSES[tid]
        path = os.path.join(OUT_DIR, tid + ".json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(record, f, ensure_ascii=False, indent=2)
            f.write("\n")
        print(path, len(RESPONSES[tid].split()))


if __name__ == "__main__":
    main()
