import sys,time,cProfile,pstats
from epinoic_logic import selfcert
selfcert.read('warm')
fam={'blank':lambda n:('a\n\n'*(n//3+1))[:n],'stops':lambda n:('a. '*(n//3+1))[:n],'lines':lambda n:('a\n'*(n//2+1))[:n]}
for k,f in fam.items():
  for n in (8192,32768):
    t=f(n)+' '
    a=time.process_time(); selfcert.read(t); print(k,n,round(time.process_time()-a,3))
if len(sys.argv)>1:
  t=fam[sys.argv[1]](32768)+' '
  cProfile.run('selfcert.read(t)',sys.argv[0]+'.out')
  pstats.Stats(sys.argv[0]+'.out').sort_stats('tottime').print_stats(20)
