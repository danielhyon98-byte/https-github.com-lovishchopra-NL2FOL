#!/usr/bin/env bash
# Wait until the phase-2 journal shows an event for a label: wait_label.sh <started|result> <label regex>. Prints the time and the label.
set -uo pipefail
J=/root/.claude/projects/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/subagents/workflows/wf_eee12853-0ae/journal.jsonl
kind=$1; pat=$2
start=$(wc -l < "$J")
while true; do
  hit=$(python3 - "$J" "$kind" "$pat" "$start" <<'PY'
import json,re,sys
j,kind,pat,start=sys.argv[1],sys.argv[2],re.compile(sys.argv[3]),int(sys.argv[4])
lab={}
for n,l in enumerate(open(j)):
    try: d=json.loads(l)
    except Exception: continue
    if d.get('type')=='started': lab[d['key']]=d.get('label','')
    L=lab.get(d.get('key'),'')
    if n>=start and d.get('type')==kind and pat.search(L or ''):
        print(L); break
PY
)
  if [ -n "$hit" ]; then echo "$(date -u +%H:%M:%S) $kind $hit"; exit 0; fi
  if ! pgrep -f "dummy-never" >/dev/null && [ -f /tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/wait_label.stop ]; then echo stopped; exit 0; fi
  sleep 30
done
