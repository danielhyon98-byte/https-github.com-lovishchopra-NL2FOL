#!/usr/bin/env bash
# Run named tests on a tree in the same hermetic overlay simulate.sh uses (12 Nov: classify the baseline failures).
# Usage: run_tests_on_tree.sh TREE TEST_ID...   (exit status = pytest's)
set -uo pipefail
TREE=$1; shift
R=/home/user/https-github.com-lovishchopra-NL2FOL
S=$(cd "$(dirname "$0")" && pwd)
VPY=$S/z3venv/bin/python
W=$(mktemp -d); trap 'rm -rf "$W"' EXIT
FAIL=""
mkdir -p "$W/tree" "$W/rounds"
git -C "$R" archive "$TREE" | tar -x -C "$W/tree" || { echo "SIMULATION FAILED: could not unpack $TREE"; exit 1; }
for d in "$S"/arena/r[0-9]*; do [ -d "$d/specialists" ] && cp -r "$d" "$W/rounds/"; done
# Hermetic interpreter: a few tests start "python -I" subprocesses, which ignore PYTHONPATH and would import the package
# from the shared editable install (the main checkout, possibly mid-merge) instead of the tree under test. An overlay
# environment whose only path file lists the tree's src first, then the shared environment's packages, makes every
# process in the simulation import exactly the tree being simulated.
ZSP=$("$VPY" -c "import sysconfig; print(sysconfig.get_paths()['purelib'])")
"$VPY" -m venv --without-pip "$W/venv" >/dev/null 2>&1 || { echo "SIMULATION FAILED: could not create the overlay environment"; exit 1; }
OSP=$("$W/venv/bin/python" -c "import sysconfig; print(sysconfig.get_paths()['purelib'])")
# Since architecture step 2 (8 Nov) the overseer, the flash router and the combinator are sub-projects with their own src
# directories (overseer/src, flash-router/src, combinator/src); each one the tree carries is listed before the shared packages,
# so that no process imports a sub-project from the main checkout instead of the tree under test.
TREEPATH="$W/tree/src"
for sub in overseer flash-router combinator; do [ -d "$W/tree/$sub/src" ] && TREEPATH="$TREEPATH:$W/tree/$sub/src"; done
export TREEPATH
echo "$TREEPATH" | tr ':' '\n' > "$OSP/00-simulated-tree.pth"; echo "$ZSP" >> "$OSP/00-simulated-tree.pth"
VPY=$W/venv/bin/python
GOT=$(cd / && "$VPY" -I -c "import epinoic_logic; print(epinoic_logic.__file__)" 2>&1)
case "$GOT" in "$W/tree/src/"*) ;; *) echo "SIMULATION FAILED: the overlay environment imports $GOT, not the tree under test"; exit 1 ;; esac
for pair in overseer:epinoic_overseer flash-router:epinoic_flash_router combinator:epinoic_combinator; do
  sub=${pair%%:*}; mod=${pair#*:}; [ -d "$W/tree/$sub/src" ] || continue
  GOT=$(cd / && "$VPY" -I -c "import $mod; print($mod.__file__)" 2>&1)
  case "$GOT" in "$W/tree/$sub/src/"*) ;; *) echo "SIMULATION FAILED: the overlay environment imports $mod from $GOT, not the tree under test"; exit 1 ;; esac
done

(cd "$W/tree" && EPINOIC_ARENA_ROUNDS="$W/rounds" PYTHONPATH="$TREEPATH" timeout --foreground 3000 "$VPY" -m pytest -q -p no:cacheprovider "$@" 2>&1 | tail -40)
exit ${PIPESTATUS[0]}
