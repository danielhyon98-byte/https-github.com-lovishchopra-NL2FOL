#!/usr/bin/env bash
# Publish one VERIFIED sub-project to its own branch on origin (Daniel, 17 Oct: "just create sub branches"):
# git subtree split of <prefix> at <verified commit>, the sub-project's own tests on the split tree alone,
# leak check, then a fast-forward push to subproject/<name>. Never forced; a refused push is reported, not retried.
# Usage: publish_subbranch.sh <combinator|flash-router|overseer> <verified commit> [reason]
set -euo pipefail
S=/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad
R=/home/user/https-github.com-lovishchopra-NL2FOL
NAME=${1:?name}; SRC=${2:?verified commit}; WHY=${3:-}
case "$NAME" in combinator|flash-router|overseer) PREFIX=$NAME ;; *) echo "STOP: unknown sub-project $NAME"; exit 1 ;; esac
SRC=$(git -C "$R" rev-parse --verify "$SRC^{commit}")
[ -n "$(git -C "$R" ls-tree -d "$SRC" -- "$PREFIX")" ] || { echo "STOP: $PREFIX/ is not in $SRC"; exit 1; }
# git subtree needs the prefix in the working tree it runs in: split inside a temporary detached worktree at SRC
WT=$S/wf/subbranch/wt-$NAME; git -C "$R" worktree remove --force "$WT" 2>/dev/null || true; rm -rf "$WT"
git -C "$R" worktree add --detach -q "$WT" "$SRC"
SPLIT=$(git -C "$WT" subtree split --prefix "$PREFIX" "$SRC" 2> "$S/wf/subbranch/split-$NAME.err" | tail -1) || true
git -C "$R" worktree remove --force "$WT"
[ -n "$SPLIT" ] || { echo "STOP: subtree split failed: $(tail -2 "$S/wf/subbranch/split-$NAME.err" | tr '\n' ' ')"; exit 1; }
W=$S/wf/subbranch/$NAME-${SPLIT:0:12}; rm -rf "$W"; mkdir -p "$W/tree"
git -C "$R" archive "$SPLIT" | tar -x -C "$W/tree"
LEAK='a7c3c8b5|/tmp/claude-0|/root/\.claude|session_0[0-9A-Za-z]|\b(Opus|Haiku|Sonnet)\b|[Cc]laude (cheapest|strongest)-tier|(cheapest|strongest)-tier model [0-9]'
if grep -rlE "$LEAK" "$W/tree" > "$W/leaks.txt"; then echo "STOP: scratch path, session id or model name in: $(head -5 "$W/leaks.txt" | tr '\n' ' ')"; exit 1; fi
# commit messages carry the required attribution trailers; only scratch paths are refused there
if git -C "$R" log --format=%B "$SPLIT" | grep -qE 'a7c3c8b5|/tmp/claude-0|/root/\.claude'; then echo "STOP: a scratch path in the split history"; exit 1; fi
# the sub-project's code must not import the translator; its conformance tests check it against the translator's port
# definitions, which come from the same verified commit (never from another tree)
if grep -rEn '^[[:space:]]*(import|from)[[:space:]]+epinoic_logic' "$W/tree/src" --include='*.py' > "$W/imports.txt"; then
  echo "STOP: the sub-project's code imports the translator: $(head -3 "$W/imports.txt" | tr '\n' ' ')"; exit 1; fi
mkdir -p "$W/translator"; git -C "$R" archive "$SRC" src | tar -x -C "$W/translator"
cd "$W/tree"
PKG=$(PYTHONPATH="$W/tree/src" "$S/z3venv/bin/python" -c "import pathlib,sys; print(next(p.name for p in pathlib.Path('src').iterdir() if (p/'__init__.py').exists()))")
WHERE=$(PYTHONPATH="$W/tree/src" "$S/z3venv/bin/python" -c "import $PKG,sys; print($PKG.__file__)")
case "$WHERE" in "$W/tree/src/"*) ;; *) echo "STOP: $PKG imports from $WHERE, not the split tree"; exit 1 ;; esac
if ! PYTHONPATH="$W/tree/src:$W/translator/src" PYTHONDONTWRITEBYTECODE=1 "$S/z3venv/bin/python" -m pytest -q -p no:cacheprovider > "$W/tests.txt" 2>&1; then
  echo "STOP: the split tree's own tests fail: $(tail -3 "$W/tests.txt" | tr '\n' ' ')"; exit 1; fi
TESTS=$(tail -1 "$W/tests.txt")
cd "$S"
if git -C "$R" push origin "$SPLIT:refs/heads/subproject/$NAME" > "$W/push.txt" 2>&1; then
  echo "PUSHED subproject/$NAME = $SPLIT (split of $PREFIX/ at ${SRC:0:7}); standalone tests: $TESTS"
  printf '%s\t%s\t%s\t%s\t%s\n' "$(date -u +%FT%TZ)" "$NAME" "$SPLIT" "$SRC" "$WHY" >> "$S/wf/subbranch/published.tsv"
else
  echo "REFUSED: push of subproject/$NAME was refused (not retried): $(tail -3 "$W/push.txt" | tr '\n' ' ')"; exit 1
fi
