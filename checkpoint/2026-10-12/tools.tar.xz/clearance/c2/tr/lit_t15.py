import sys
sys.path.insert(0, "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2/tr")
from ir import *

REQ = "req-lit-t15"
DOC = "doc-interpreter"
S, PR = {}, {}


def sym(name, sort, meaning, kind=None, doc=None, excerpt=None, cert="established"):
    S[name] = SYM(name, sort, meaning, kind, doc, excerpt, cert)


def pr(pid, expr, label, kind=None, doc=None, excerpt=None, cert="established"):
    PR[pid] = P(pid, expr, label, kind, doc, excerpt, cert)


def ent(cid, pid, prems, concl, reading, flags=(), ambiguous=False, cert="established"):
    problem = PROBLEM("p-" + pid, REQ, cid, S, prems, P("concl", concl, None, None, None, None, cert))
    return ENTRY(problem=problem, reading=reading, flags=flags, ambiguous=ambiguous)


sym("carries", "Bool", "the speaker carries each sentence across in both hands", "supplied_text", DOC, "each sentence across in both hands")
sym("sets_down", "Bool", "she sets it down on her side of the desk", "supplied_text", DOC, "down on her side of the desk")
sym("watch_open", "Bool", "she watches her mother open it", "supplied_text", DOC, "and watch her open it")
sym("between", "Bool", "the speaker occupies the space between the two sides", "specialist_inference", cert="probable")
sym("mother_ctl", "Bool", "the mother controls what is opened", "specialist_inference", cert="probable")
sym("s03", "Bool", "the speaker is between two sides while the mother controls what is opened", "specialist_inference", cert="probable")
sym("nod_owes", "Bool", "the clerk nods as if the speaker is the one who owes", "supplied_text", DOC, "as if I am the one who owes")
sym("debt_sp", "Bool", "the debt has moved onto the speaker", "specialist_inference", cert="probable")
sym("resp", "Bool", "the change is a change in who is held responsible", "specialist_inference", cert="probable")
sym("s07", "Bool", "the debt has moved onto the speaker and the change is one of responsibility", "specialist_inference", cert="probable")
sym("hand_tight", "Bool", "the mother holds the speaker's hand too tightly", "supplied_text", DOC, "holds my hand too tightly")
sym("recall", "Bool", "the speaker was once one who could not cross a road", "supplied_text", DOC, "who could not cross a road")
sym("dep_rev", "Bool", "the speaker's old dependence is reversed", "specialist_inference", cert="probable")
sym("grip_need", "Bool", "the mother's grip reads as need", "specialist_inference", cert="probable")
sym("s08", "Bool", "dependence is reversed and the grip reads as need", "specialist_inference", cert="probable")
sym("reversal", "Bool", "the poem moves to a reversal in which the speaker holds the mother's words and the mother depends on her", "specialist_inference", cert="probable")
sym("choose_one", "Bool", "at HL the student only has to choose one of two passages", "task_setting")
sym("write_each", "Bool", "at HL one analysis is written on each passage", "general_knowledge")
sym("max20", "Bool", "a single-passage answer scores at most 20 of 40 marks", "general_knowledge")

C = {}
C["p1-s03"] = ent("p1-s03", "lit-p1-s03",
    [P("pr_c", V("carries"), "the speaker carries each sentence across in both hands", "supplied_text", DOC, "each sentence across in both hands"),
     P("pr_s", V("sets_down"), "she sets it down on her side of the desk", "supplied_text", DOC, "down on her side of the desk"),
     P("pr_w", V("watch_open"), "she watches her mother open it", "supplied_text", DOC, "and watch her open it"),
     P("pr_b", IMP(AND(V("carries"), V("sets_down")), V("between")), "carrying and setting down place her between the two sides", "specialist_inference", cert="probable"),
     P("pr_m", IMP(V("watch_open"), V("mother_ctl")), "watching her mother open it shows the mother controls what is opened", "specialist_inference", cert="probable")],
    AND(V("between"), V("mother_ctl")),
    "The speaker carries and sets down the sentences (quoted), so she is between the sides; the mother controls the opening (quoted).")

C["p1-s07"] = ent("p1-s07", "lit-p1-s07",
    [P("pr_n", V("nod_owes"), "the clerk nods as if the speaker is the one who owes", "supplied_text", DOC, "as if I am the one who owes"),
     P("pr_d", IMP(V("nod_owes"), V("debt_sp")), "the nod places the debt on the speaker", "specialist_inference", cert="probable"),
     P("pr_r", IMP(V("debt_sp"), V("resp")), "a debt moved onto the speaker is a change in who is held responsible", "specialist_inference", cert="probable")],
    AND(V("debt_sp"), V("resp")),
    "The clerk's nod (quoted) suggests the debt has moved onto the speaker, so the change is one of responsibility (probable).")

C["p1-s08"] = ent("p1-s08", "lit-p1-s08",
    [P("pr_h", V("hand_tight"), "the mother holds the speaker's hand too tightly", "supplied_text", DOC, "holds my hand too tightly"),
     P("pr_rc", V("recall"), "the speaker was the one who could not cross a road", "supplied_text", DOC, "who could not cross a road"),
     P("pr_dr", IMP(AND(V("hand_tight"), V("recall")), V("dep_rev")), "the recalled dependence is reversed by the grip", "specialist_inference", cert="probable"),
     P("pr_g", IMP(V("dep_rev"), V("grip_need")), "the reversal makes the grip read as need", "specialist_inference", cert="probable")],
    AND(V("dep_rev"), V("grip_need")),
    "The mother's tight grip (quoted), recalling the speaker who could not cross a road (quoted), reverses the old dependence so the grip reads as need (probable).")

C["p1-point"] = ent("p1-point", "lit-p1-point",
    [P("pr_s03", AND(V("between"), V("mother_ctl")), "the speaker stands between the sides while the mother controls the opening", "specialist_inference", cert="probable"),
     P("pr_s07", AND(V("debt_sp"), V("resp")), "the debt moves onto the speaker, a change in responsibility", "specialist_inference", cert="probable"),
     P("pr_s08", AND(V("dep_rev"), V("grip_need")), "the old dependence is reversed and the grip reads as need", "specialist_inference", cert="probable"),
     P("pr_link", IMP(AND(AND(V("between"), V("mother_ctl")), AND(V("debt_sp"), V("resp")), AND(V("dep_rev"), V("grip_need"))), V("reversal")),
       "the three shifts together make a reversal in which the speaker holds the mother's words and the mother depends on her", "specialist_inference", cert="probable")],
    V("reversal"),
    "Across the poem the speaker moves from receiving her mother's words to holding them and the mother depending on her; the point is the combined reading of p1-s03, p1-s07 and p1-s08 (probable).")

C["p1-s12"] = ent("p1-s12", "lit-p1-s12",
    [P("pr_hl", V("choose_one"), "the student only has to choose one of two passages at HL", "task_setting"),
     P("pr_wr", IMP(V("write_each"), V("max20")), "one analysis per passage would be needed, and a single-passage answer scores at most 20 of 40", "general_knowledge")],
    AND(V("write_each"), V("max20")),
    "The planning note says HL requires one analysis per passage, which conflicts with the question's statement that the student only has to choose one; the conclusion is not derivable from the task and is flagged.",
    flags=[("conflicts_with_task", "the question states that at HL only one of the two passages must be chosen; the note says one analysis is needed on each", ["the task statement is right: one passage only", "the note is right: one analysis on each passage"])],
    ambiguous=True)

DUMP("lit-t15", "rep-lit-t15-0", C)
