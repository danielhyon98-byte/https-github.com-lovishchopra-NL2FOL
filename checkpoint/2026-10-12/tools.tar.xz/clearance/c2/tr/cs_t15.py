import sys
sys.path.insert(0, "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2/tr")
from ir import *

REQ = "req-cs-t15"
S = {}
PR = {}


def I(s):
    return {"op": "int", "value": str(s)}


def MODop(l, r):
    return {"op": "mod", "left": l, "right": r}


def IDIVop(l, r):
    return {"op": "idiv", "left": l, "right": r}


def sym(name, sort, meaning, kind=None, cert="established"):
    S[name] = SYM(name, sort, meaning, kind, None, None, cert)


def pr(pid, expr, label, kind=None, cert="established"):
    PR[pid] = P(pid, expr, label, kind, None, None, cert)


def PB(cid, pid, prems, concl_expr, concl_label, reading, ambiguous=False, flags=()):
    problem = PROBLEM("p-" + pid, REQ, cid, S, [PR[p] if isinstance(p, str) else p for p in prems],
                      P("concl", concl_expr, concl_label))
    return ENTRY(problem=problem, reading=reading, ambiguous=ambiguous, flags=flags)


def NULL(reason):
    return ENTRY(unsup=reason, reading=reason)


# symbols
sym("gb", "Real", "file size in GB", "task_setting")
sym("mb", "Real", "file size in MB", "arithmetic_fact")
sym("by", "Real", "file size in bytes", "arithmetic_fact")
sym("bits", "Real", "file size in bits", "arithmetic_fact")
sym("spm", "Real", "upload speed in Mbit/s", "task_setting")
sym("sp", "Real", "upload speed in bits per second", "arithmetic_fact")
sym("t", "Real", "upload time in seconds", "arithmetic_fact")
sym("mins", "Real", "upload time in minutes", "arithmetic_fact")
sym("mbf", "Real", "packet test file size in MB", "task_setting")
sym("by4", "Real", "packet test file size in bytes", "arithmetic_fact")
sym("by4i", "Int", "packet test file size in bytes (integer)", "arithmetic_fact")
sym("pk", "Real", "number of packets", "arithmetic_fact")
sym("switch_mac", "Bool", "a switch forwards frames by MAC address", "specialist_inference")
sym("local_only", "Bool", "local traffic goes only to the addressed device", "specialist_inference")
sym("tcp_ack", "Bool", "TCP numbers and acknowledges each segment and resends unacknowledged ones", "specialist_inference")
sym("tcp_reliable", "Bool", "TCP is reliable", "specialist_inference")
sym("tcp_conn", "Bool", "TCP is connection-oriented", "general_knowledge")
sym("server_all", "Bool", "the server receives every part of the file", "specialist_inference")
sym("udp_noack", "Bool", "UDP sends with no acknowledgement, retransmission or ordering", "general_knowledge")
sym("udp_gaps", "Bool", "UDP leaves gaps in the video", "specialist_inference")
sym("udp_scr", "Bool", "UDP can scramble the video", "specialist_inference")
sym("slow_ok", "Bool", "a slower upload is acceptable", "specialist_inference", cert="probable")
sym("damage_no", "Bool", "a damaged file is not acceptable", "specialist_inference", cert="probable")
sym("tcp_worth", "Bool", "TCP's extra overhead is worth paying", "specialist_inference", cert="probable")
sym("ip_hdr", "Bool", "IP adds a header with the source and destination IP addresses", "specialist_inference")
sym("ip_pk", "Bool", "the internet layer creates packets", "specialist_inference")
sym("frame_mac", "Bool", "each packet is framed with the MAC address of the next device", "specialist_inference")
sym("sent_link", "Bool", "the frame is sent over the cable or wireless link", "specialist_inference")
sym("cmp_sim", "Bool", "the compare question asks for similarities only", "specialist_inference", cert="possible")
sym("pts_sim", "Bool", "each point is a similarity", "specialist_inference", cert="possible")
sym("static_tcp", "Bool", "static routing leaves end-to-end delivery to TCP", "specialist_inference")
sym("dyn_tcp", "Bool", "dynamic routing leaves end-to-end delivery to TCP", "specialist_inference")
sym("both_tcp", "Bool", "both routing methods leave end-to-end delivery to TCP", "specialist_inference")
sym("tcp_resend", "Bool", "TCP resends any lost segment", "general_knowledge")
sym("resend_any", "Bool", "TCP resends a lost segment whichever route the packets take", "specialist_inference")

# premises
pr("pa_gb", EQ(V("gb"), R("1.8")), "the video file is 1.8 GB (question)", "task_setting")
pr("pa_spm", EQ(V("spm"), R("40")), "upload speed is 40 Mbit/s (question)", "task_setting")
pr("pa_mbf", EQ(V("mbf"), R("6.0")), "the file is 6.0 MB (question)", "task_setting")
pr("d_mb", EQ(V("mb"), MUL(V("gb"), R("1000"))), "1 GB = 1000 MB", "task_setting")
pr("d_by", EQ(V("by"), MUL(V("mb"), R("1000000"))), "1 MB = 10^6 bytes", "task_setting")
pr("d_bits", EQ(V("bits"), MUL(V("by"), R("8"))), "1 byte = 8 bits", "task_setting")
pr("d_sp", EQ(V("sp"), MUL(V("spm"), R("1000000"))), "1 Mbit = 10^6 bits, so 40 Mbit/s = 4.0 x 10^7 bit/s", "task_setting")
pr("d_t", EQ(V("t"), DIV(V("bits"), R("40000000"))), "time = bits / (4.0 x 10^7 bit/s)", "specialist_inference")
pr("d_mins", EQ(V("mins"), DIV(V("t"), R("60"))), "minutes = seconds / 60", "arithmetic_fact")
pr("d_by4", EQ(V("by4"), MUL(V("mbf"), R("1000000"))), "6.0 MB x 10^6 bytes", "task_setting")
pr("d_pk", EQ(V("pk"), DIV(V("by4"), R("1500"))), "packets = bytes / 1500", "specialist_inference")
pr("pa_by4i", EQ(V("by4i"), I("6000000")), "6 000 000 bytes as an integer", "arithmetic_fact")

# part (b) chain
C = {}
C["c1.1"] = NULL("a statement about treating the level of the course; it adds no inference to check")
C["c1.2"] = NULL("restates the unit conventions the question gives; no inference to check")
C["c1.3"] = NULL("a stated assumption about the MB convention; no inference is drawn from it")
C["c1.4"] = NULL("a stated assumption about the Mbit convention; no inference is drawn from it")

pr("pr_switch", V("switch_mac"), "a switch forwards frames by MAC address", "specialist_inference")
C["c2.1"] = PB("c2.1", "cs-c2.1", [PR["pr_switch"] if False else P("pr_sw", V("switch_mac"), "a switch forwards frames by MAC address", "specialist_inference"),
                                   P("pr_lo", IMP(V("switch_mac"), V("local_only")), "MAC-based forwarding sends local traffic only to the addressed device", "specialist_inference")],
               V("local_only"), "a switch sends local traffic only to the device it is addressed to",
               "The switch forwards frames by MAC address, so local traffic goes only to the addressed device.")

C["c3.2"] = PB("c3.2", "cs-c3.2", ["pa_gb", "d_mb"], EQ(V("mb"), R("1800")), "1.8 GB = 1800 MB",
               "1.8 GB x 1000 MB per GB = 1800 MB.")
C["c3.3"] = PB("c3.3", "cs-c3.3", ["pa_gb", "d_mb", "d_by"], EQ(V("by"), R("1800000000")), "1800 MB = 1.8 x 10^9 bytes",
               "1800 MB x 10^6 bytes per MB = 1.8 x 10^9 bytes.")
C["c3.4"] = PB("c3.4", "cs-c3.4", ["pa_gb", "d_mb", "d_by", "d_bits"], EQ(V("bits"), R("14400000000")),
               "1.8 x 10^9 bytes = 1.44 x 10^10 bits",
               "1.8 x 10^9 bytes x 8 bits per byte = 1.44 x 10^10 bits.")
C["c3.5"] = PB("c3.5", "cs-c3.5", ["pa_spm", "d_sp"], EQ(V("sp"), R("40000000")), "40 Mbit/s = 4.0 x 10^7 bit/s",
               "40 Mbit/s = 40 x 10^6 bit/s = 4.0 x 10^7 bit/s.")
C["c3.6"] = PB("c3.6", "cs-c3.6", ["pa_gb", "d_mb", "d_by", "d_bits", "pa_spm", "d_sp", "d_t"], EQ(V("t"), R("360")),
               "time = 360 s", "1.44 x 10^10 bits / 4.0 x 10^7 bit/s = 360 s.")
C["c3.7"] = PB("c3.7", "cs-c3.7", ["d_t", "d_mins"], EQ(V("mins"), R("6")), "360 s = 6.0 minutes",
               "360 s / 60 s per minute = 6.0 minutes.")
C["c3.8"] = PB("c3.8", "cs-c3.8", ["pa_gb", "d_mb", "d_by", "d_bits", "pa_spm", "d_sp", "d_t", "d_mins"],
               AND(GE(V("mins"), R("5.95")), LT(V("mins"), R("6.05"))),
               "the minimum upload time is 6.0 minutes (one decimal place)",
               "The minimum time is 6.0 minutes; stated to one decimal place, so the exact value lies in [5.95, 6.05).")

C["c4.2"] = PB("c4.2", "cs-c4.2", ["pa_mbf", "d_by4"], EQ(V("by4"), R("6000000")), "6.0 MB = 6 000 000 bytes",
               "6.0 MB x 10^6 bytes per MB = 6 000 000 bytes.")
C["c4.3"] = PB("c4.3", "cs-c4.3", ["pa_mbf", "d_by4", "d_pk"], EQ(V("pk"), R("4000")), "6 000 000 bytes / 1500 bytes = 4000 packets",
               "6 000 000 bytes / 1500 bytes per packet = 4000 packets.")
C["c4.4"] = PB("c4.4", "cs-c4.4", ["pa_mbf", "d_by4", "d_pk"], EQ(V("pk"), R("4000")), "the file needs 4000 packets",
               "The number of packets needed is 4000.")
C["c4.5"] = ENTRY(problem=PROBLEM("p-cs-c4.5", REQ, "c4.5", S,
                  [PR["pa_by4i"]],
                  P("concl", AND(EQ(MODop(V("by4i"), I("1500")), I("0")), EQ(IDIVop(V("by4i"), I("1500")), I("4000"))),
                    "the division is exact, so no extra packet is needed")),
                  reading="6 000 000 mod 1500 = 0 and 6 000 000 div 1500 = 4000: the division is exact, so no extra packet is needed.")

C["c5.2"] = PB("c5.2", "cs-c5.2", [P("pr_ack", V("tcp_ack"), "each TCP segment is numbered, acknowledged and resent if not acknowledged", "specialist_inference"),
                                   P("pr_srv", IMP(V("tcp_ack"), V("server_all")), "acknowledgement and resending deliver every part to the server", "specialist_inference")],
               V("server_all"), "the server receives every part of the file",
               "Numbered, acknowledged, resent segments mean the server receives every part.")

C["c5.4"] = ENTRY(problem=PROBLEM("p-cs-c5.4", REQ, "c5.4", S,
                  [P("pr_noack", V("udp_noack"), "UDP sends datagrams with no acknowledgement, retransmission or ordering", "general_knowledge"),
                   P("pr_gap", IMP(V("udp_noack"), V("udp_gaps")), "lost packets leave gaps", "specialist_inference"),
                   P("pr_scr", IMP(V("udp_noack"), V("udp_scr")), "out-of-order packets scramble the video", "specialist_inference")],
                  P("concl", AND(V("udp_gaps"), V("udp_scr")), "UDP would leave gaps and scramble the video")),
                  reading="With no acknowledgement or ordering, UDP loses packets (gaps) and can reorder them (scrambling).")

C["c5.5"] = PB("c5.5", "cs-c5.5", [P("pr_slow", V("slow_ok"), "a slower upload is acceptable", "specialist_inference", cert="probable"),
                                   P("pr_dam", V("damage_no"), "a damaged file is not acceptable", "specialist_inference", cert="probable"),
                                   P("pr_w", IMP(AND(V("slow_ok"), V("damage_no")), V("tcp_worth")), "so TCP's overhead is worth paying", "specialist_inference", cert="probable")],
               V("tcp_worth"), "TCP's extra overhead is worth paying",
               "Slower upload is acceptable but damage is not, so TCP's overhead is worth paying (probable).")

C["c5.1"] = PB("c5.1", "cs-c5.1", [P("pr_conn", V("tcp_conn"), "TCP is connection-oriented", "general_knowledge"),
                                   P("pr_ack2", V("tcp_ack"), "TCP acknowledges and resends segments", "specialist_inference"),
                                   P("pr_rel", IMP(V("tcp_ack"), V("tcp_reliable")), "acknowledgement and resending make TCP reliable", "specialist_inference")],
               V("tcp_reliable"), "TCP is reliable (and connection-oriented, as stated)",
               "TCP is connection-oriented (general knowledge) and reliable because each segment is acknowledged and resent.")

C["c6.4"] = PB("c6.4", "cs-c6.4", [P("pr_hdr", V("ip_hdr"), "IP adds a header with the source and destination IP addresses", "specialist_inference"),
                                   P("pr_pk", IMP(V("ip_hdr"), V("ip_pk")), "the header makes the internet layer create packets", "specialist_inference")],
               V("ip_pk"), "the internet layer adds the IP header and creates packets",
               "IP adds a header with both IP addresses, creating packets.")

C["c6.6"] = PB("c6.6", "cs-c6.6", [P("pr_fr", V("frame_mac"), "each packet is framed with the next device's MAC address", "specialist_inference"),
                                   P("pr_sent", IMP(V("frame_mac"), V("sent_link")), "the frame is sent over the link", "specialist_inference")],
               V("sent_link"), "the network access layer sends the frame over the cable or wireless link",
               "Each packet is framed with the next device's MAC address and sent over the link.")

C["c7.1"] = ENTRY(problem=PROBLEM("p-cs-c7.1", REQ, "c7.1", S,
                  [P("pr_cmp", V("cmp_sim"), "the Compare instruction asks for similarities only", "specialist_inference", cert="possible"),
                   P("pr_pts", IMP(V("cmp_sim"), V("pts_sim")), "so each point is a similarity", "specialist_inference", cert="possible")],
                  P("concl", V("pts_sim"), "each point below is a similarity")),
                  reading="The claim rests on the reading that 'compare' asks for similarities only. The question text ('Compare static and dynamic routing') does not state that restriction; the premise is the specialist's own reading.",
                  ambiguous=True,
                  flags=[("unsupported_premise", "the restriction of 'compare' to similarities is not stated in the question", ["compare means similarities and differences", "compare means similarities only"])])

C["c7.5"] = ENTRY(problem=PROBLEM("p-cs-c7.5", REQ, "c7.5", S,
                  [P("pr_s", V("static_tcp"), "static routing leaves end-to-end delivery to TCP", "specialist_inference"),
                   P("pr_d", V("dyn_tcp"), "dynamic routing leaves end-to-end delivery to TCP", "specialist_inference"),
                   P("pr_both", IMP(AND(V("static_tcp"), V("dyn_tcp")), V("both_tcp")), "both routes leave delivery to TCP", "specialist_inference"),
                   P("pr_res", IMP(V("tcp_resend"), V("resend_any")), "TCP resends lost segments whichever route is used", "specialist_inference"),
                   P("pr_tr", V("tcp_resend"), "TCP resends any lost segment", "general_knowledge")],
                  P("concl", AND(V("both_tcp"), V("resend_any")), "both leave end-to-end delivery to TCP, which resends any lost segment whichever route is used")),
                  reading="Both routing methods leave end-to-end delivery to TCP, which resends lost segments whichever route the packets take.")

DUMP("cs-t15", "rep-cs-t15-0", C)
