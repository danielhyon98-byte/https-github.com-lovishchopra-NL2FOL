import sys
sys.path.insert(0, "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2/tr")
from ir import *

REQ = "req-p9c"
PEER = "peer:ge-p9c"
S, PR = {}, {}


def sym(name, sort, meaning, kind=None, doc=None, excerpt=None, cert="established"):
    S[name] = SYM(name, sort, meaning, kind, doc, excerpt, cert)


def pr(pid, expr, label, kind=None, doc=None, excerpt=None, cert="established"):
    PR[pid] = P(pid, expr, label, kind, doc, excerpt, cert)


def ent(cid, pid, prems, concl, reading, cert="established", ambiguous=False, flags=()):
    problem = PROBLEM("p-" + pid, REQ, cid, S, [PR[p] if isinstance(p, str) else p for p in prems], P("concl", concl, None, None, None, None, cert))
    return ENTRY(problem=problem, reading=reading, ambiguous=ambiguous, flags=flags)


def NULL(reason):
    return ENTRY(unsup=reason, reading=reason)


# task data
sym("mm1", "Real", "rain in Storm 1 (mm)", "task_setting")
sym("mm2", "Real", "rain in Storm 2 (mm)", "task_setting")
sym("rd1", "Real", "rain depth Storm 1 (m)", "arithmetic_fact")
sym("rd2", "Real", "rain depth Storm 2 (m)", "arithmetic_fact")
sym("akm", "Real", "catchment area (km2)", "task_setting")
sym("am", "Real", "catchment area (m2)", "arithmetic_fact")
sym("rv1", "Real", "rain volume Storm 1 (m3)", "arithmetic_fact")
sym("rv2", "Real", "rain volume Storm 2 (m3)", "arithmetic_fact")
sym("ro1", "Real", "storm runoff Storm 1 (m3)", "task_setting")
sym("ro2", "Real", "storm runoff Storm 2 (m3)", "task_setting")
sym("pct1", "Real", "percentage of rain leaving as runoff, Storm 1", "arithmetic_fact")
sym("pct2", "Real", "percentage of rain leaving as runoff, Storm 2", "arithmetic_fact")
sym("lag1", "Real", "lag time Storm 1 (h)", "arithmetic_fact")
sym("lag2", "Real", "lag time Storm 2 (h)", "arithmetic_fact")
sym("rt1", "Real", "time of peak rainfall Storm 1 (h)", "supplied_text")
sym("rt2", "Real", "time of peak rainfall Storm 2 (h)", "supplied_text")
sym("pk1", "Real", "peak discharge Storm 1 (m3 s-1)", "quotation", PEER, "the peak discharge rose by 200%")
sym("pk2", "Real", "peak discharge Storm 2 (m3 s-1)", "quotation", PEER, "the peak discharge rose by 200%")
sym("pkrise", "Real", "percentage rise in peak discharge", "arithmetic_fact")
sym("bu1", "Real", "built-up share 2006 (%)", "quotation", PEER, "rose from 8% to 31%")
sym("bu2", "Real", "built-up share 2024 (%)", "quotation", PEER, "rose from 8% to 31%")
sym("sumrise", "Real", "rise in percentage points (placeholder)", "arithmetic_fact")
sym("surf", "Bool", "a larger surface flow reaches the channel", "specialist_inference")
sym("peak_up", "Bool", "the peak rises", "specialist_inference")
sym("flow_up", "Bool", "the flow at the gauging station rose", "specialist_inference")
sym("arr_sooner", "Bool", "the flow arrives sooner", "specialist_inference")
sym("less_inf", "Bool", "less rain infiltrates", "specialist_inference")
sym("replace_perm", "Bool", "roofs, roads and car parks replace permeable ground", "specialist_inference")
sym("quick", "Bool", "runoff reaches the brook quickly", "specialist_inference")
sym("drains_fast", "Bool", "drains and sewers move water faster than soil", "specialist_inference")
sym("timing_catch", "Bool", "the timing difference comes from the catchment itself", "specialist_inference")
sym("suds_hold", "Bool", "permeable paving and rain gardens hold rain and let it soak in", "general_knowledge")
sym("suds_restore", "Bool", "sustainable drainage restores some storage", "specialist_inference")
sym("eco", "Bool", "an ecocentric view values natural processes", "specialist_inference")
sym("eco_small", "Bool", "an ecocentric view favours small-scale features", "specialist_inference")
sym("partial", "Bool", "sustainable drainage only partly restores permeable ground", "specialist_inference")
sym("limit_built", "Bool", "limits on new built-up area are needed", "specialist_inference")
sym("techno", "Bool", "a technocentric view trusts designable and measurable engineering", "specialist_inference")
sym("q_small", "Bool", "many small features may not hold back the largest storms", "specialist_inference")
sym("prefer_eng", "Bool", "a technocentric view would prefer engineered storage", "specialist_inference")
sym("target_loss", "Bool", "sustainable drainage targets the lost infiltration", "specialist_inference")
sym("nobuilt_reduce", "Bool", "the built-up share is reduced", "specialist_inference")
sym("no_restore", "Bool", "the data show that sustainable drainage alone restores the 2006 pattern", "specialist_inference")

# premises
pr("pt_mm1", EQ(V("mm1"), R("38")), "Storm 1 had 38 mm of rain (question)", "task_setting")
pr("pt_mm2", EQ(V("mm2"), R("36")), "Storm 2 had 36 mm of rain (question)", "task_setting")
pr("pt_ak", EQ(V("akm"), R("24")), "catchment area 24 km2 (question)", "task_setting")
pr("pt_ro1", EQ(V("ro1"), R("182000")), "runoff Storm 1 is 1.82 x 10^5 m3 (question)", "task_setting")
pr("pt_ro2", EQ(V("ro2"), R("410000")), "runoff Storm 2 is 4.10 x 10^5 m3 (question)", "task_setting")
pr("d_rd1", EQ(V("rd1"), DIV(V("mm1"), R("1000"))), "38 mm = 0.038 m", "arithmetic_fact")
pr("d_rd2", EQ(V("rd2"), DIV(V("mm2"), R("1000"))), "36 mm = 0.036 m", "arithmetic_fact")
pr("d_am", EQ(V("am"), MUL(V("akm"), R("1000000"))), "24 km2 = 24 x 10^6 m2", "arithmetic_fact")
pr("d_rv1", EQ(V("rv1"), MUL(V("rd1"), R("24000000"))), "rain volume = depth x area (2.4 x 10^7 m2)", "specialist_inference")
pr("d_rv2", EQ(V("rv2"), MUL(V("rd2"), R("24000000"))), "rain volume = depth x area (2.4 x 10^7 m2)", "specialist_inference")
pr("d_pct1", EQ(V("pct1"), DIV(MUL(V("ro1"), R("100")), R("912000"))), "percentage = runoff / rain x 100 (rain 9.12 x 10^5 m3)", "specialist_inference")
pr("d_pct2", EQ(V("pct2"), DIV(MUL(V("ro2"), R("100")), R("864000"))), "percentage = runoff / rain x 100 (rain 8.64 x 10^5 m3)", "specialist_inference")
pr("d_lag1", EQ(V("lag1"), SUB(R("21.5"), R("9.5"))), "lag 1 = 21:30 - 09:30 = 12 h", "specialist_inference")
pr("d_lag2", EQ(V("lag2"), SUB(R("14"), R("9.5"))), "lag 2 = 14:00 - 09:30 = 4.5 h", "specialist_inference")
pr("pt_rt1", EQ(V("rt1"), R("9.5")), "peak rainfall Storm 1 at 09:30", "supplied_text", PEER, None)
pr("pt_rt2", EQ(V("rt2"), R("9.5")), "peak rainfall Storm 2 at 09:30", "supplied_text", PEER, None)
pr("pt_pk1", EQ(V("pk1"), R("5.4")), "peak discharge 5.4 m3 s-1 in Storm 1", "quotation", PEER, "the peak discharge rose by 200%")
pr("pt_pk2", EQ(V("pk2"), R("16.2")), "peak discharge 16.2 m3 s-1 in Storm 2", "quotation", PEER, "the peak discharge rose by 200%")
pr("d_pkrise", EQ(V("pkrise"), DIV(MUL(R("100"), SUB(V("pk2"), V("pk1"))), R("5.4"))), "percentage rise = (new - old) / old x 100", "specialist_inference")
pr("pt_bu1", EQ(V("bu1"), R("8")), "built-up share 8% in 2006", "quotation", PEER, "rose from 8% to 31%")
pr("pt_bu2", EQ(V("bu2"), R("31")), "built-up share 31% in 2024", "quotation", PEER, "rose from 8% to 31%")

C = {}
C["s2.1"] = ent("s2.1", "ess-s2.1", ["pt_mm1", "pt_mm2", "d_rd1", "d_rd2"],
                AND(EQ(V("rd1"), R("0.038")), EQ(V("rd2"), R("0.036"))),
                "rainfall is 0.038 m in Storm 1 and 0.036 m in Storm 2")
C["s2.2"] = ent("s2.2", "ess-s2.2", ["pt_ak", "d_am"], EQ(V("am"), R("24000000")),
                "catchment area is 24 x 10^6 m2 (2.4 x 10^7 m2)")
C["s2.4"] = ent("s2.4", "ess-s2.4", ["pt_mm1", "d_rd1", "d_am", "d_rv1", "pt_ak"], EQ(V("rv1"), R("912000")),
                "Storm 1 rain volume is 9.12 x 10^5 m3")
C["s2.5"] = ent("s2.5", "ess-s2.5", ["pt_mm2", "d_rd2", "d_am", "d_rv2", "pt_ak"], EQ(V("rv2"), R("864000")),
                "Storm 2 rain volume is 8.64 x 10^5 m3")
C["s3.1"] = NULL("a general formula (percentage of rain as runoff) with no value; its instances s3.2 and s3.3 are the checkable statements")
C["s3.2"] = ent("s3.2", "ess-s3.2", ["pt_ro1", "d_pct1"],
                AND(GE(V("pct1"), R("19.95")), LT(V("pct1"), R("20.05"))),
                "about 20.0% of Storm 1 rain left as runoff (3 s.f.)",
                "1.82 x 10^5 / 9.12 x 10^5 x 100 = 19.956%, which is 20.0% to three significant figures.")
C["s3.3"] = ent("s3.3", "ess-s3.3", ["pt_ro2", "d_pct2"],
                AND(GE(V("pct2"), R("47.45")), LT(V("pct2"), R("47.55"))),
                "about 47.5% of Storm 2 rain left as runoff (3 s.f.)",
                "4.10 x 10^5 / 8.64 x 10^5 x 100 = 47.4537%, which is 47.5% to three significant figures.")
C["s3.4"] = ent("s3.4", "ess-s3.4", ["d_pct1", "d_pct2", "pt_ro1", "pt_ro2"],
                AND(GE(SUB(V("pct2"), V("pct1")), R("27.45")), LT(SUB(V("pct2"), V("pct1")), R("27.55"))),
                "the share rose by 27.5 percentage points, from 20.0% to 47.5%",
                "The exact values 19.956% and 47.4537% differ by 27.498, which is 27.5 to one decimal place.")
C["s4.1"] = ent("s4.1", "ess-s4.1",
                [P("pr_bu", V("replace_perm"), "built-up surfaces replace permeable ground", "specialist_inference"),
                 P("pr_q", IMP(V("replace_perm"), V("less_inf")), "less rain infiltrates", "specialist_inference"),
                 P("pr_qk", IMP(V("less_inf"), V("quick")), "rain that does not soak in runs off quickly", "specialist_inference"),
                 P("pr_fl", IMP(GT(V("pk2"), V("pk1")), V("flow_up")), "a higher peak means the flow at the station rose", "specialist_inference"),
                 P("pr_ar", IMP(GT(V("lag1"), V("lag2")), V("arr_sooner")), "a shorter lag means the flow arrives sooner", "specialist_inference"),
                 "pt_pk1", "pt_pk2", "d_lag1", "d_lag2"],
                AND(V("flow_up"), V("arr_sooner")),
                "the built-up growth sends more water quickly into the brook, so the flow rose and arrived sooner")
C["s5.2"] = ent("s5.2", "ess-s5.2",
                [P("pr_rp", V("replace_perm"), "roofs, roads and car parks replace permeable ground", "specialist_inference"),
                 P("pr_li", IMP(V("replace_perm"), V("less_inf")), "replacing permeable ground means less rain infiltrates", "specialist_inference")],
                V("less_inf"), "less rain infiltrates and is held in the soil store")
C["s6.2"] = ent("s6.2", "ess-s6.2",
                ["d_pct1", "d_pct2", "pt_ro1", "pt_ro2",
                 P("pr_sf", IMP(GT(V("pct2"), V("pct1")), V("surf")), "a rise in the share of runoff means more surface flow", "specialist_inference")],
                AND(GT(V("pct2"), V("pct1")), V("surf")),
                "the share rose from 20.0% to 47.5%, so a larger flow reached the channel over the surface")
C["s7.2"] = ent("s7.2", "ess-s7.2", ["d_lag1", "d_lag2"],
                AND(EQ(V("lag1"), R("12")), EQ(V("lag2"), R("4.5"))),
                "the Geography specialist's lag times are 12 hours and 4.5 hours, from the clock times")
C["s7.3"] = ent("s7.3", "ess-s7.3",
                ["pt_rt1", "pt_rt2",
                 P("pr_tc", IMP(EQ(V("rt1"), V("rt2")), V("timing_catch")), "equal peak rainfall times mean the timing difference comes from the catchment", "specialist_inference"),
                 P("pr_df", V("drains_fast"), "drains and sewers move water faster than soil", "specialist_inference")],
                AND(V("timing_catch"), V("drains_fast")),
                "drains and sewers move water faster than soil, and with equal rainfall times the timing difference comes from the catchment")
C["s8.2"] = ent("s8.2", "ess-s8.2", ["pt_pk1", "pt_pk2", "d_pkrise"],
                EQ(V("pkrise"), R("200")),
                "the peak discharge rose by 200%, from 5.4 to 16.2 m3 s-1")
C["s8.3"] = ent("s8.3", "ess-s8.3",
                [P("pr_sf2", V("surf"), "the larger surface flow reaches the channel together", "specialist_inference"),
                 P("pr_pk", IMP(V("surf"), V("peak_up")), "the surface flow raises the peak", "specialist_inference")],
                V("peak_up"), "the larger, faster surface flow reaches the channel together, so the peak rises")
C["s10.1"] = ent("s10.1", "ess-s10.1",
                 [P("pr_sh", V("suds_hold"), "permeable paving, green roofs and rain gardens hold rain and let it soak in", "general_knowledge"),
                  P("pr_sr", IMP(V("suds_hold"), V("suds_restore")), "holding rain on the surface restores some storage", "specialist_inference")],
                 V("suds_restore"), "sustainable drainage restores some of the storage that built surfaces removed")
C["s11.1"] = ent("s11.1", "ess-s11.1",
                 [P("pr_eco", V("eco"), "an ecocentric view values the brook's natural processes and habitats", "specialist_inference"),
                  P("pr_es", IMP(V("eco"), V("eco_small")), "so it favours small-scale features that work with infiltration", "specialist_inference")],
                 V("eco_small"), "an ecocentric view would favour small-scale features that work with infiltration and vegetation")
C["s11.2"] = ent("s11.2", "ess-s11.2",
                 [P("pr_pa", V("partial"), "sustainable drainage only partly restores the permeable ground lost", "specialist_inference"),
                  P("pr_lm", IMP(V("partial"), V("limit_built")), "so limits on new built-up area are sought", "specialist_inference"),
                  "pt_bu1", "pt_bu2"],
                 V("limit_built"), "an ecocentric view would press for limits on new built-up area")
C["s12.1"] = ent("s12.1", "ess-s12.1",
                 [P("pr_tc", V("techno"), "a technocentric view trusts designable and measurable engineering", "specialist_inference"),
                  P("pr_tq", IMP(V("techno"), V("q_small")), "it would question whether many small features hold back the largest storms", "specialist_inference"),
                  P("pr_tp", IMP(V("q_small"), V("prefer_eng")), "it would probably prefer engineered storage of known capacity", "specialist_inference")],
                 V("prefer_eng"), "a technocentric view would question small features and probably prefer engineered storage", ambiguous=False)
C["s13.2"] = ent("s13.2", "ess-s13.2",
                 ["d_pct1", "d_pct2", "pt_ro1", "pt_ro2",
                  P("pr_ts", IMP(GT(V("pct2"), V("pct1")), V("target_loss")), "the runoff shares show the loss of infiltration the measure targets", "specialist_inference")],
                 V("target_loss"), "sustainable drainage targets the loss of infiltration that the runoff shares show; no figure for the peak reduction is given")
C["s13.3"] = ent("s13.3", "ess-s13.3",
                 ["pt_bu2",
                  P("pr_nr", V("no_restore"), "nothing in the data shows that sustainable drainage alone restores the 2006 pattern", "specialist_inference"),
                  P("pr_nb", V("nobuilt_reduce"), "the built-up share is not reduced", "specialist_inference")],
                 IMP(NOT(V("nobuilt_reduce")), V("no_restore")),
                 "unless the built-up share is reduced, nothing in the data shows that sustainable drainage alone restores the 2006 pattern",
                 flags=[("unverified_premise", "the reduction of the built-up share is a stated condition, not a supplied fact", ["the built-up share is not reduced", "the built-up share is reduced"])])

DUMP("ess-p9c", "rep-ess-p9c-0", C)
