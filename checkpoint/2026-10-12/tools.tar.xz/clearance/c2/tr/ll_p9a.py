import sys
sys.path.insert(0, "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2/tr")
from ir import *

REQ = "req-p9a"
DOC = "doc-kestrel"
S = {}


def sym(name, sort, meaning, kind=None, doc=None, excerpt=None, cert="established"):
    S[name] = SYM(name, sort, meaning, kind, doc, excerpt, cert)


def P2(pid, expr, label, kind=None, doc=None, excerpt=None, cert="established"):
    return P(pid, expr, label, kind, doc, excerpt, cert)


sym("first_step", "Bool", "the email presents Jordan's survey answer as a first step", "supplied_text", DOC,
    "Two weeks ago you answered our one-question survey")
sym("ask_money", "Bool", "the request is to become a Friend for 4 pounds a month", "supplied_text", DOC,
    "become a Friend of the Kestrel for £4 a month")
sym("not_named", "Bool", "the email never names a commitment mechanism", "supplied_text", DOC, None)
sym("built_wording", "Bool", "the sense of commitment is built by the wording rather than stated", "specialist_inference", cert="probable")
sym("reads_cont", "Bool", "the £4 request reads as a continuation rather than a new demand", "specialist_inference", cert="probable")

C = {}
C["p1-s10"] = ENTRY(problem=PROBLEM("p-ll-p9a-p1-s10", REQ, "p1-s10", S,
    [P2("pr_nn", V("not_named"), "the email itself never names such a mechanism", "supplied_text", DOC, None),
     P2("pr_bw", IMP(V("not_named"), V("built_wording")), "without a named mechanism the commitment is built by wording", "specialist_inference", cert="probable")],
    P2("concl", V("built_wording"), "the sense of commitment is built by the wording rather than stated", None, None, None, "probable")),
    reading="The email does not name a commitment mechanism; the commitment is therefore carried by wording (probable). Stated as the specialist's interpretation.")

C["p1-point"] = ENTRY(problem=PROBLEM("p-ll-p9a-p1-point", REQ, "p1-point", S,
    [P2("pr_fs", V("first_step"), "the email presents the survey answer as a first step", "supplied_text", DOC, "Two weeks ago you answered our one-question survey"),
     P2("pr_ask", V("ask_money"), "the request is for 4 pounds a month", "supplied_text", DOC, "become a Friend of the Kestrel for £4 a month"),
     P2("pr_s10", V("built_wording"), "the commitment is built by wording (p1-s10)", "specialist_inference", cert="probable"),
     P2("pr_cont", IMP(AND(V("first_step"), V("built_wording"), V("ask_money")), V("reads_cont")),
        "the first step plus the built commitment make the request read as a continuation", "specialist_inference", cert="probable")],
    P2("concl", V("reads_cont"), "the £4 request reads as a continuation rather than a new demand", None, None, None, "probable")),
    reading="The survey answer (quoted) is presented as a first step; the commitment is carried by wording (p1-s10), so the £4 request (quoted) reads as continuation (probable). The peer psychology explanation is not quoted here.")

DUMP("ll-p9a", "rep-ll-p9a-0", C)
