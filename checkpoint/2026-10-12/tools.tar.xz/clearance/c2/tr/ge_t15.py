import sys
sys.path.insert(0, "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2/tr")
from ir import *

REQ = "req-ge-t15"
DOC = "doc-ostrel"
S, PR = {}, {}


def sym(name, sort, meaning, kind=None, doc=None, excerpt=None, cert="established"):
    S[name] = SYM(name, sort, meaning, kind, doc, excerpt, cert)


def pr(pid, expr, label, kind=None, doc=None, excerpt=None, cert="established"):
    PR[pid] = P(pid, expr, label, kind, doc, excerpt, cert)


def ent(cid, pid, prems, concl, reading, ambiguous=False, flags=(), cert="established"):
    problem = PROBLEM("p-" + pid, REQ, cid, S, [PR[p] if isinstance(p, str) else p for p in prems], P("concl", concl, None, None, None, None, cert))
    return ENTRY(problem=problem, reading=reading, ambiguous=ambiguous, flags=flags)


def NULL(reason):
    return ENTRY(unsup=reason, reading=reason)


WS = "Wind and solar power | 1 | 13"
COAL = "Coal | 46 | 28"
TPS = "Total primary energy supply (petajoules, PJ) | 820 | 1,050"
IMPT = "Share of primary energy supply that is imported (%) | 38 | 54"
rows = [("ws05", "ws25", WS, 1, 13, "wind and solar share (%)"), ("coal05", "coal25", COAL, 46, 28, "coal share (%)"),
        ("tps05", "tps25", TPS, 820, 1050, "total primary energy supply (PJ)"), ("imp05", "imp25", IMPT, 38, 54, "imported share (%)")]
for a, b, ex, va, vb, lab in rows:
    for n, v, yr in ((a, va, "2005"), (b, vb, "2025")):
        sym(n, "Real", f"{lab} in {yr}", "quotation", DOC, ex)
        pr("t_" + n, EQ(V(n), R(str(v))), f"{lab} in {yr} is {v} (Table)", "quotation", DOC, ex)

sym("coalpj05", "Real", "coal supply 2005 (PJ)", "arithmetic_fact")
sym("coalpj25", "Real", "coal supply 2025 (PJ)", "arithmetic_fact")
sym("pc", "Real", "percentage change in coal supply", "arithmetic_fact")
sym("tg", "Real", "percentage growth in total supply", "arithmetic_fact")
sym("imppj05", "Real", "imported energy 2005 (PJ)", "arithmetic_fact")
sym("imppj25", "Real", "imported energy 2025 (PJ)", "arithmetic_fact")
sym("incr", "Real", "percentage increase in imported energy", "arithmetic_fact")
sym("wsdiff", "Real", "change in wind and solar share (points)", "arithmetic_fact")
sym("cdiff", "Real", "change in coal share (points)", "arithmetic_fact")
sym("impdiff", "Real", "change in imported share (points)", "arithmetic_fact")
sym("imp_up", "Bool", "the imported share of supply rose", "specialist_inference")
sym("depends_abroad", "Bool", "supply depends more on conditions in other countries", "specialist_inference")
sym("supply_less_rel", "Bool", "supply becomes less reliable", "specialist_inference", cert="probable")
sym("sec_falls", "Bool", "energy security falls", "specialist_inference", cert="probable")
sym("policy_climate", "Bool", "government policy and climate commitments", "specialist_inference", cert="probable")
sym("ws_profit", "Bool", "wind and solar become more profitable", "specialist_inference")
sym("coal_costly", "Bool", "coal becomes more expensive to run", "specialist_inference")
sym("invest_ws", "Bool", "new investment goes to wind and solar", "specialist_inference")
sym("coal_less", "Bool", "some older coal plants run less", "specialist_inference")
sym("mix_shift", "Bool", "the energy mix shifts from coal toward wind and solar", "specialist_inference", cert="probable")
sym("falling_costs", "Bool", "technology costs fall", "specialist_inference", cert="probable")
sym("cheap_ws", "Bool", "wind and solar become cheaper", "specialist_inference")
sym("ws_lowest", "Bool", "new wind and solar can be the lowest-cost option", "specialist_inference")
sym("invest_instead", "Bool", "investors build wind and solar instead of new coal stations", "specialist_inference")
sym("fictional", "Bool", "Ostrel is a fictional country", "supplied_text", DOC, "Ostrel is a fictional country")
sym("gen_reasons", "Bool", "the reasons are general explanations to test, not facts about a real country", "specialist_inference")

pr("d_coalpj05", EQ(V("coalpj05"), DIV(MUL(V("coal05"), R("820")), R("100"))), "coal 2005 = 46% x 820 PJ", "arithmetic_fact")
pr("d_coalpj25", EQ(V("coalpj25"), DIV(MUL(V("coal25"), R("1050")), R("100"))), "coal 2025 = 28% x 1050 PJ", "arithmetic_fact")
pr("d_pc", EQ(V("pc"), DIV(MUL(R("100"), SUB(V("coalpj25"), V("coalpj05"))), R("377.2"))), "percentage change = (294.0 - 377.2) / 377.2 x 100", "arithmetic_fact")
pr("d_tg", EQ(V("tg"), DIV(MUL(R("100"), SUB(V("tps25"), V("tps05"))), R("820"))), "total supply growth = (1050 - 820) / 820 x 100", "arithmetic_fact")
pr("d_imppj05", EQ(V("imppj05"), DIV(MUL(V("imp05"), R("820")), R("100"))), "imported 2005 = 38% x 820", "arithmetic_fact")
pr("d_imppj25", EQ(V("imppj25"), DIV(MUL(V("imp25"), R("1050")), R("100"))), "imported 2025 = 54% x 1050", "arithmetic_fact")
pr("d_incr", EQ(V("incr"), DIV(MUL(R("100"), SUB(V("imppj25"), V("imppj05"))), R("311.6"))), "increase = (567.0 - 311.6) / 311.6 x 100", "arithmetic_fact")
pr("d_wsdiff", EQ(V("wsdiff"), SUB(V("ws25"), V("ws05"))), "change in wind and solar share", "arithmetic_fact")
pr("d_cdiff", EQ(V("cdiff"), SUB(V("coal25"), V("coal05"))), "change in coal share", "arithmetic_fact")
pr("d_impdiff", EQ(V("impdiff"), SUB(V("imp25"), V("imp05"))), "change in imported share", "arithmetic_fact")

C = {}
C["g1.1@geography-specialist"] = ent("g1.1@geography-specialist", "ge-g1.1",
    [PR["t_ws05"], PR["t_ws25"], PR["d_wsdiff"]],
    EQ(V("wsdiff"), R("12")), "the wind and solar share rose by 12 percentage points (13 - 1)",
    "The table gives 1% in 2005 and 13% in 2025, so the change is 12 percentage points.")

C["g1.2@geography-specialist"] = ent("g1.2@geography-specialist", "ge-g1.2",
    [PR["t_ws05"], PR["t_ws25"]],
    EQ(MUL(R("100"), DIV(SUB(V("ws25"), V("ws05")), R("1"))), R("1200")),
    "as a relative change the share change would be 1,200% (12 / 1 x 100); the method (percentage points) is a methodological note",
    )

C["g2.1@geography-specialist"] = ent("g2.1@geography-specialist", "ge-g2.1",
    [PR["t_coal05"], PR["t_tps05"], PR["d_coalpj05"]],
    EQ(V("coalpj05"), R("377.2")), "coal supply in 2005 is 377.2 PJ (46% x 820 PJ)",
    "46% of 820 PJ is 377.2 PJ.")

C["g2.2@geography-specialist"] = ent("g2.2@geography-specialist", "ge-g2.2",
    [PR["t_coal25"], PR["t_tps25"], PR["d_coalpj25"]],
    EQ(V("coalpj25"), R("294")), "coal supply in 2025 is 294.0 PJ (28% x 1,050 PJ)",
    "28% of 1,050 PJ is 294.0 PJ.")

C["g2.3@geography-specialist"] = ent("g2.3@geography-specialist", "ge-g2.3",
    [PR["t_coal05"], PR["t_coal25"], PR["t_tps05"], PR["t_tps25"], PR["d_coalpj05"], PR["d_coalpj25"], PR["d_pc"]],
    AND(GE(V("pc"), R("-22.15")), LT(V("pc"), R("-22.05"))),
    "the percentage change in coal supply is -22.1% (one decimal place)",
    "(294.0 - 377.2) / 377.2 x 100 = -22.06%, which is -22.1% to one decimal place.")

C["g2.4@geography-specialist"] = ent("g2.4@geography-specialist", "ge-g2.4",
    [PR["t_coal05"], PR["t_coal25"], PR["t_tps05"], PR["t_tps25"], PR["d_coalpj05"], PR["d_coalpj25"], PR["d_pc"]],
    AND(EQ(V("coalpj05"), R("377.2")), EQ(V("coalpj25"), R("294")), GE(V("pc"), R("-22.15")), LT(V("pc"), R("-22.05"))),
    "coal supply fell by 22.1%, from 377.2 PJ in 2005 to 294.0 PJ in 2025",
    "Coal supply fell from 377.2 PJ to 294.0 PJ, a fall of 22.1%.")

C["g2.5@geography-specialist"] = ent("g2.5@geography-specialist", "ge-g2.5",
    [PR["t_coal05"], PR["t_coal25"], PR["t_tps05"], PR["t_tps25"], PR["d_cdiff"], PR["d_tg"], PR["d_pc"]],
    AND(EQ(V("cdiff"), R("-18")), GE(V("tg"), R("27.95")), LT(V("tg"), R("28.05")), GE(V("pc"), R("-22.15")), LT(V("pc"), R("-22.05"))),
    "the coal share fell by 18 points, total supply grew by 28.0%, and coal supply fell by 22.1%",
    "The causal 'which is why' link between total growth and the smaller fall in coal supply is not separately encoded; the figures are.")

C["g3.1@geography-specialist"] = ent("g3.1@geography-specialist", "ge-g3.1",
    [PR["t_imp05"], PR["t_imp25"], PR["d_impdiff"]],
    EQ(V("impdiff"), R("16")), "imports rose from 38% to 54% of supply, a rise of 16 percentage points",
    "54 - 38 = 16 percentage points.")

C["g3.2@geography-specialist"] = ent("g3.2@geography-specialist", "ge-g3.2",
    [PR["t_imp05"], PR["t_imp25"], PR["t_tps05"], PR["t_tps25"], PR["d_imppj05"], PR["d_imppj25"], PR["d_incr"]],
    AND(EQ(V("imppj05"), R("311.6")), EQ(V("imppj25"), R("567")), GE(V("incr"), R("81.95")), LT(V("incr"), R("82.05"))),
    "imported energy rose from 311.6 PJ to 567.0 PJ, an increase of 82.0%",
    "0.38 x 820 = 311.6; 0.54 x 1,050 = 567.0; (567.0 - 311.6) / 311.6 x 100 = 81.97%, which is 82.0% to one decimal place.")

C["g3.3@geography-specialist"] = ent("g3.3@geography-specialist", "ge-g3.3",
    [PR["t_imp05"], PR["t_imp25"], PR["d_impdiff"],
     P("pr_iu", IMP(GT(V("impdiff"), R("0")), V("imp_up")), "a positive change means the imported share rose", "arithmetic_fact"),
     P("pr_da", IMP(V("imp_up"), V("depends_abroad")), "a larger imported share makes supply depend more on other countries", "specialist_inference", cert="probable")],
    V("depends_abroad"), "a larger share of energy from abroad means supply depends more on conditions in other countries",
    cert="probable")

C["g3.5@geography-specialist"] = ent("g3.5@geography-specialist", "ge-g3.5",
    [PR["t_imp05"], PR["t_imp25"], PR["d_impdiff"],
     P("pr_iu", IMP(GT(V("impdiff"), R("0")), V("imp_up")), "a positive change means the imported share rose", "arithmetic_fact"),
     P("pr_da", IMP(V("imp_up"), V("depends_abroad")), "a larger imported share makes supply depend more on other countries", "specialist_inference", cert="probable"),
     P("pr_sl", IMP(V("depends_abroad"), V("supply_less_rel")), "dependence on other countries makes supply less reliable and less affordable", "specialist_inference", cert="probable"),
     P("pr_se", IMP(V("supply_less_rel"), V("sec_falls")), "less reliable supply means energy security falls", "specialist_inference", cert="probable")],
    AND(V("supply_less_rel"), V("sec_falls")),
    "Greater dependence on imports makes supply less reliable and energy security falls (probable); the affordability limb is not separately encoded.",
    cert="probable")

C["g3.6@geography-specialist"] = NULL("a structural fact about the table (it gives no breakdown of imports by fuel); the premise and the conclusion would restate each other, so no relation to check")

C["g4.1@geography-specialist"] = ent("g4.1@geography-specialist", "ge-g4.1",
    [P("pr_pol", V("policy_climate"), "government policy and climate commitments are a reason", "specialist_inference", cert="probable"),
     P("pr_pw", IMP(V("policy_climate"), AND(V("ws_profit"), V("coal_costly"))), "policy makes wind and solar profitable and coal costly", "specialist_inference", cert="probable"),
     P("pr_mix", IMP(AND(V("ws_profit"), V("coal_costly")), V("mix_shift")), "the profitability shift changes the energy mix", "specialist_inference", cert="probable")],
    V("mix_shift"), "government policy and climate commitments are a reason the energy mix changes (a reason to test, not a confirmed one)",
    cert="probable")

C["g4.3@geography-specialist"] = ent("g4.3@geography-specialist", "ge-g4.3",
    [P("pr_pw", IMP(V("ws_profit"), V("invest_ws")), "more profitable wind and solar attract new investment", "specialist_inference"),
     P("pr_cl", IMP(V("coal_costly"), V("coal_less")), "coal more expensive to run means some older plants run less", "specialist_inference"),
     P("pr_pwp", V("ws_profit"), "wind and solar are more profitable", "specialist_inference"),
     P("pr_cc", V("coal_costly"), "coal is more expensive to run", "specialist_inference")],
    AND(V("invest_ws"), V("coal_less")), "new investment goes to wind and solar and some older coal plants run less")

C["g4.4@geography-specialist"] = ent("g4.4@geography-specialist", "ge-g4.4",
    [PR["t_ws05"], PR["t_ws25"], PR["t_coal05"], PR["t_coal25"], PR["d_wsdiff"], PR["d_cdiff"]],
    AND(EQ(V("wsdiff"), R("12")), EQ(V("cdiff"), R("-18"))),
    "Ostrel's figures fit the pattern: wind and solar up from 1% to 13%, coal down from 46% to 28%; the table records no policy, so this is a reason to test, not a confirmed one")

C["g5.1@geography-specialist"] = ent("g5.1@geography-specialist", "ge-g5.1",
    [P("pr_fc", V("falling_costs"), "technology costs are falling", "specialist_inference", cert="probable"),
     P("pr_cw", IMP(V("falling_costs"), V("cheap_ws")), "falling costs make wind and solar cheaper", "specialist_inference", cert="probable"),
     P("pr_wl", IMP(V("cheap_ws"), V("ws_lowest")), "cheaper wind and solar can be the lowest-cost option", "specialist_inference", cert="probable"),
     P("pr_ii", IMP(V("ws_lowest"), V("invest_instead")), "the lowest-cost option is what investors build", "specialist_inference", cert="probable")],
    V("invest_instead"), "falling technology costs lead investors to build wind and solar instead of new coal (reason 2; fuel prices not encoded)",
    cert="probable")

C["g5.2@geography-specialist"] = ent("g5.2@geography-specialist", "ge-g5.2",
    [P("pr_cw", V("cheap_ws"), "wind and solar technology is becoming cheaper", "specialist_inference"),
     P("pr_wl", IMP(V("cheap_ws"), V("ws_lowest")), "cheaper wind and solar can be the lowest-cost option", "specialist_inference"),
     P("pr_ii", IMP(V("ws_lowest"), V("invest_instead")), "the lowest-cost option is built instead of new coal", "specialist_inference")],
    V("invest_instead"), "investors build wind and solar instead of new coal stations")

C["g6.1@geography-specialist"] = ent("g6.1@geography-specialist", "ge-g6.1",
    [P("pr_fic", V("fictional"), "Ostrel is a fictional country", "supplied_text", DOC, "Ostrel is a fictional country"),
     P("pr_gen", IMP(V("fictional"), V("gen_reasons")), "because the country is fictional, the reasons are general explanations to test", "specialist_inference")],
    V("gen_reasons"), "the reasons are general explanations to test against the data, not facts about a real country")

DUMP("ge-t15", "rep-ge-t15-0", C)
