import json, glob, os, sys
D = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2"
relay = {}
for f in glob.glob(f"{D}/relayed/*.json"):
    d = json.load(open(f))
    relay[d["document_id"]] = d["payload"]["original_response"]
bad = 0
total = 0
for tf in sorted(glob.glob(f"{D}/revision-translations/*.json")):
    task = os.path.basename(tf)[:-5]
    rv = json.load(open(f"{D}/revisions/{task}.json"))
    docs = {t["document_id"]: t["text"] for t in rv["supplied_texts"]}
    out = json.load(open(tf))
    def refs_of(g):
        if not g: return []
        return g.get("source_refs", [])
    for cid, c in out["claims"].items():
        pb = c.get("problem")
        if not pb: continue
        items = [("sym", s["name"], s.get("grounding")) for s in pb["symbols"]]
        items += [("prem", p["id"], p.get("grounding")) for p in pb["premises"]]
        items += [("concl", pb["conclusion"]["id"], pb["conclusion"].get("grounding"))]
        for kind, name, g in items:
            for sr in refs_of(g):
                ex = sr.get("excerpt")
                did = sr["document_id"]
                total += 1
                text = docs.get(did) or relay.get(did)
                if text is None:
                    print("NODOC", task, cid, kind, name, did); bad += 1; continue
                if ex is not None and ex not in text:
                    print("MISS", task, cid, kind, name, repr(ex[:80])); bad += 1
print("refs checked", total, "problems", bad)
