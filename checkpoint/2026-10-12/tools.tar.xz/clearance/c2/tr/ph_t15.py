import sys
sys.path.insert(0, "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2/tr")
from ir import *

REQ = "req-ph-t15"
S, PR = {}, {}


def sym(name, sort, meaning, kind=None, cert="established"):
    S[name] = SYM(name, sort, meaning, kind, None, None, cert)


def pr(pid, expr, label, kind=None, cert="established"):
    PR[pid] = P(pid, expr, label, kind, None, None, cert)


def ent(cid, pid, prems, concl, reading, cert="established", ambiguous=False, flags=()):
    problem = PROBLEM("p-" + pid, REQ, cid, S, [PR[p] if isinstance(p, str) else p for p in prems], P("concl", concl, None, None, None, None, cert))
    return ENTRY(problem=problem, reading=reading, ambiguous=ambiguous, flags=flags)


def NULL(reason):
    return ENTRY(unsup=reason, reading=reason)


sym("v2", "Real", "square of the speed at the bottom of the slope (m2 s-2)", "specialist_inference")
sym("v", "Real", "speed of the wagon at the bottom of the slope (m s-1)", "specialist_inference")
sym("pb", "Real", "total momentum before the collision (kg m s-1)", "arithmetic_fact")
sym("vv", "Real", "speed of the coupled wagons after the collision (m s-1)", "specialist_inference")
sym("ek0", "Real", "kinetic energy before the collision (J)", "arithmetic_fact")
sym("ek1", "Real", "kinetic energy after the collision (J)", "arithmetic_fact")
sym("de", "Real", "kinetic energy transferred to other forms (J)", "arithmetic_fact")
sym("pct", "Real", "kinetic energy transferred as a percentage", "arithmetic_fact")
sym("dp", "Real", "change in momentum of the coupled wagons (kg m s-1)", "arithmetic_fact")
sym("force", "Real", "average force by the buffer (N)", "arithmetic_fact")
sym("x2", "Real", "square of the spring compression (m2)", "arithmetic_fact")
sym("mom_cons", "Bool", "total momentum is conserved in the collision", "general_knowledge")
sym("no_ext", "Bool", "there is no external horizontal force", "specialist_inference")
sym("weights_bal", "Bool", "the weights are balanced by normal forces", "specialist_inference")
sym("friction_ign", "Bool", "friction is ignored", "task_setting")
sym("pair_eq", "Bool", "the coupling forces are an equal and opposite pair", "general_knowledge")
sym("internal", "Bool", "the coupling forces are internal to the system", "specialist_inference")
sym("ke_less", "Bool", "the kinetic energy after the collision is less", "specialist_inference")
sym("couple_inel", "Bool", "the coupling deforms and heats and makes sound", "general_knowledge")

pr("pa_v2", EQ(V("v2"), MUL(R("2"), R("9.8"), R("0.46"))), "v^2 = 2 x 9.8 x 0.46", "arithmetic_fact")
pr("pa_pb", EQ(V("pb"), ADD(MUL(R("12000"), R("3.0")), MUL(R("8000"), R("0")))), "momentum before = 1.2e4 x 3.0 + 8.0e3 x 0", "arithmetic_fact")
pr("pa_cons", IMP(V("mom_cons"), EQ(V("pb"), MUL(R("20000"), V("vv")))), "momentum conserved: before = (2.0e4 kg) v", "specialist_inference")
pr("pa_pair_true", V("pair_eq"), "the coupling forces are an equal and opposite pair (third law)", "general_knowledge")
pr("pa_cons_true", V("mom_cons"), "total momentum is conserved (general principle)", "general_knowledge")
pr("pa_ek0", EQ(V("ek0"), DIV(MUL(R("12000"), R("9")), R("2"))), "Ek before = 1/2 x 1.2e4 x 3.0^2", "arithmetic_fact")
pr("pa_ek1", EQ(V("ek1"), DIV(MUL(R("20000"), R("3.24")), R("2"))), "Ek after = 1/2 x 2.0e4 x 1.8^2", "arithmetic_fact")
pr("pa_de", EQ(V("de"), SUB(V("ek0"), V("ek1"))), "energy transferred = before - after", "arithmetic_fact")
pr("pa_pct", EQ(V("pct"), DIV(MUL(R("100"), V("de")), R("54000"))), "percentage = transferred / before x 100", "arithmetic_fact")
pr("pa_dp", EQ(V("dp"), MUL(R("20000"), SUB(R("0"), R("1.8")))), "change in momentum = 2.0e4 x (0 - 1.8)", "arithmetic_fact")
pr("pa_force", EQ(V("force"), DIV(V("dp"), R("0.6"))), "force = change in momentum / time", "arithmetic_fact")
pr("pa_x2", EQ(V("x2"), DIV(MUL(R("2"), R("32400")), R("2000000"))), "x^2 = 2 x 3.24e4 / 2.0e6", "arithmetic_fact")
pr("pa_vv", EQ(V("vv"), R("1.8")), "speed after collision 1.8 m s-1 (part b)", "arithmetic_fact")
pr("pa_ek0v", EQ(V("ek0"), R("54000")), "kinetic energy before 5.4e4 J", "arithmetic_fact")
pr("pa_ek1v", EQ(V("ek1"), R("32400")), "kinetic energy after 3.24e4 J", "arithmetic_fact")
pr("pa_weights", V("weights_bal"), "the weights are balanced by normal forces", "specialist_inference")
pr("pa_friction", V("friction_ign"), "friction is ignored (question)", "task_setting")
pr("pa_ns_ext", IMP(AND(V("weights_bal"), V("friction_ign")), V("no_ext")), "balanced weights and no friction leave no external horizontal force", "specialist_inference")
pr("pa_ext_mom", IMP(V("no_ext"), V("mom_cons")), "no external force means momentum is conserved", "general_knowledge")
pr("pa_pair", IMP(V("pair_eq"), V("internal")), "an equal and opposite pair of forces is internal", "general_knowledge")
pr("pa_int_mom", IMP(AND(V("internal"), V("no_ext")), V("mom_cons")), "internal forces with no external force conserve momentum", "general_knowledge")

C = {}
C["s1.1"] = NULL("the assumptions restate the value of g from the data booklet and the given speed; no inference is drawn from them")
C["s2.3"] = NULL("a symbolic formula; the product of variables lies outside the IR allowlist, and the numerical instance is checked in s2.4")
C["s2.4"] = ent("s2.4", "ph-s2.4", ["pa_v2"], EQ(V("v2"), R("9.016")), "v^2 = 2 x 9.8 x 0.46 = 9.016 m2 s-2")
C["s2.5"] = ent("s2.5", "ph-s2.5", ["pa_v2"],
                AND(GE(V("v2"), R("8.970025")), LT(V("v2"), R("9.030025"))),
                "v = 3.00 m s-1 to three significant figures",
                flags=())
C["s2.6"] = ent("s2.6", "ph-s2.6", ["pa_v2"],
                AND(GE(V("v2"), R("8.7025")), LT(V("v2"), R("9.3025"))),
                "the computed speed agrees with 3.0 m s-1 (to two significant figures)")
C["s3.2"] = NULL("a list of symbols and given values restating the question's data; no inference to check")
C["s3.4"] = ent("s3.4", "ph-s3.4", ["pa_pb"], EQ(V("pb"), R("36000")),
                "momentum before the collision is 3.6 x 10^4 kg m s-1")
C["s3.5"] = ent("s3.5", "ph-s3.5", ["pa_pb", "pa_cons", "pa_cons_true"], EQ(V("pb"), MUL(R("20000"), V("vv"))),
                "3.6 x 10^4 kg m s-1 = (2.0 x 10^4 kg) v")
C["s3.6"] = ent("s3.6", "ph-s3.6", ["pa_pb", "pa_cons", "pa_cons_true"], AND(EQ(V("vv"), R("1.8")), GT(V("vv"), R("0"))),
                "v = 1.8 m s-1, in the original direction of motion")
C["s4.1"] = ent("s4.1", "ph-s4.1", ["pa_ek0"], EQ(V("ek0"), R("54000")), "Ek before = 5.4 x 10^4 J")
C["s4.2"] = ent("s4.2", "ph-s4.2", ["pa_ek1"], EQ(V("ek1"), R("32400")), "Ek after = 3.24 x 10^4 J")
C["s4.3"] = ent("s4.3", "ph-s4.3", ["pa_ek0", "pa_ek1", "pa_de"],
                AND(EQ(V("de"), R("21600")), GE(V("de"), R("21500")), LT(V("de"), R("22500"))),
                "the energy transferred is 2.16 x 10^4 J, which is 2.2 x 10^4 J to two significant figures")
C["s4.4"] = ent("s4.4", "ph-s4.4", ["pa_ek0", "pa_ek1", "pa_de", "pa_pct"],
                AND(GE(V("pct"), R("39.5")), LT(V("pct"), R("40.5"))),
                "the energy transferred is 40% of the kinetic energy before the collision (two significant figures)")
C["s5.3"] = NULL("a list of values restating the question's data for the buffer calculation; no inference to check")
C["s5.4"] = ent("s5.4", "ph-s5.4", ["pa_dp"], EQ(V("dp"), R("-36000")), "the change in momentum is -3.6 x 10^4 kg m s-1")
C["s5.5"] = ent("s5.5", "ph-s5.5", ["pa_dp", "pa_force"], EQ(V("force"), R("-60000")), "the average force is -6.0 x 10^4 N")
C["s5.6"] = ent("s5.6", "ph-s5.6", ["pa_dp", "pa_force"], AND(EQ(V("force"), R("-60000")), LT(V("force"), R("0"))),
                "the average force is 6.0 x 10^4 N, opposite to the direction of motion")
C["s6.1"] = NULL("a symbolic energy principle (1/2 k x^2 = Ek); its numerical instance is checked in s6.2")
C["s6.2"] = ent("s6.2", "ph-s6.2", ["pa_x2"], EQ(V("x2"), R("0.0324")), "x^2 = 3.24 x 10^-2 m2")
C["s6.3"] = ent("s6.3", "ph-s6.3", ["pa_x2"],
                AND(GE(V("x2"), R("0.030625")), LT(V("x2"), R("0.034225"))),
                "x = 0.18 m = 18 cm to two significant figures",
                flags=())
C["s7.1"] = ent("s7.1", "ph-s7.1", ["pa_pair", "pa_pair_true", "pa_ns_ext", "pa_weights", "pa_friction", "pa_ext_mom", "pa_int_mom"],
                V("mom_cons"), "the total momentum is conserved because the coupling forces are an equal and opposite internal pair")
C["s7.2"] = ent("s7.2", "ph-s7.2", ["pa_weights", "pa_friction", "pa_ns_ext", "pa_ext_mom"],
                AND(V("no_ext"), V("mom_cons")), "there is no external horizontal force and the total momentum is conserved")
C["s7.4"] = ent("s7.4", "ph-s7.4",
                [P("pr_ci", V("couple_inel"), "the coupling deforms, heats and makes sound", "general_knowledge"),
                 P("pr_kl", IMP(V("couple_inel"), V("ke_less")), "that transfer makes the kinetic energy after the collision less", "specialist_inference")],
                V("ke_less"), "part of the kinetic energy becomes internal energy and sound, so the kinetic energy after is less")

DUMP("ph-t15", "rep-ph-t15-0", C)
