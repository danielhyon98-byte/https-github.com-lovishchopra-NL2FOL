import sys
sys.path.insert(0, "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2/tr")
from ir import *

REQ = "req-maa-t15"
S, PR = {}, {}


def sym(name, sort, meaning, kind=None, cert="established"):
    S[name] = SYM(name, sort, meaning, kind, None, None, cert)


def pr(pid, expr, label, kind=None, cert="established"):
    PR[pid] = P(pid, expr, label, kind, None, None, cert)


def ent(cid, pid, prems, concl, reading, cert="established", ambiguous=False, flags=()):
    problem = PROBLEM("p-" + pid, REQ, cid, S, [PR[p] if isinstance(p, str) else p for p in prems], P("concl", concl, None, None, None, None, cert))
    return ENTRY(problem=problem, reading=reading, ambiguous=ambiguous, flags=flags)


def NULL(reason):
    return ENTRY(unsup=reason, reading=reason)


def C_(s):
    return R(s)


sym("k", "Real", "the constant k in f(x) = x^2 - 6x + k")
sym("delta", "Real", "discriminant b^2 - 4ac")
sym("pos_delta", "Bool", "the discriminant is positive (two distinct real roots)", "general_knowledge")
sym("x", "Real", "the input x")
sym("gx", "Real", "g(x) = 2x + 3")
sym("hgx", "Real", "(h o g)(x)")
sym("ginv", "Real", "the inverse g^-1(x)")
sym("y", "Real", "y = 2x + 3")
sym("gu", "Real", "g applied to (x - 3)/2")
sym("u", "Real", "(x - 3)/2")
sym("prr", "Real", "probability both red")
sym("p1", "Real", "probability the first draw is red (5/8)")
sym("pdiff", "Real", "probability of different colours")
sym("pe", "Real", "probability of event E")
sym("pf", "Real", "probability of event F")
sym("pfe", "Real", "probability of F and E")
sym("pfge", "Real", "conditional probability P(F | E)")
sym("f_in_e", "Bool", "F is contained in E", "specialist_inference")

pr("pa_pos", GT(V("delta"), R("0")), "two distinct real roots require delta > 0", "general_knowledge")
pr("pa_delta", EQ(V("delta"), SUB(R("36"), MUL(R("4"), V("k")))), "discriminant with a = 1, b = -6, c = k gives 36 - 4k", "specialist_inference")
pr("pa_24", GT(SUB(R("36"), MUL(R("4"), V("k"))), R("0")), "36 - 4k > 0", "specialist_inference")
pr("pa_25", GT(MUL(R("-4"), V("k")), R("-36")), "-4k > -36", "specialist_inference")
pr("pa_g", EQ(V("gx"), ADD(MUL(R("2"), V("x")), R("3"))), "g(x) = 2x + 3 (question)", "task_setting")
pr("pa_h", EQ(V("hgx"), DIV(SUB(V("gx"), R("1")), R("2"))), "h(g(x)) = (g(x) - 1) / 2", "task_setting")
pr("pa_x0", EQ(V("x"), R("0")), "x = 0 (instance)", "specialist_inference")
pr("pa_m52", EQ(V("hgx"), ADD(V("x"), R("1"))), "(h o g)(x) = x + 1", "specialist_inference")
pr("pa_y", EQ(V("y"), ADD(MUL(R("2"), V("x")), R("3"))), "y = 2x + 3", "task_setting")
pr("pa_ginv", EQ(V("ginv"), DIV(SUB(V("x"), R("3")), R("2"))), "g^-1(x) = (x - 3)/2", "specialist_inference")
pr("pa_u", EQ(V("u"), DIV(SUB(V("x"), R("3")), R("2"))), "u = (x - 3)/2", "specialist_inference")
pr("pa_gu", EQ(V("gu"), ADD(MUL(R("2"), V("u")), R("3"))), "g(u) = 2u + 3", "task_setting")
pr("pa_setup", EQ(V("hgx"), V("ginv")), "the equation (h o g)(x) = g^-1(x) to be solved", "task_setting")
pr("pa_prr", EQ(V("prr"), MUL(R("5/8"), R("4/7"))), "P(both red) = 5/8 x 4/7", "arithmetic_fact")
pr("pa_pdiff", EQ(V("pdiff"), ADD(MUL(R("5/8"), R("3/7")), MUL(R("3/8"), R("5/7")))), "P(different) = P(RB) + P(BR)", "arithmetic_fact")
pr("pa_fe", V("f_in_e"), "F is contained in E", "specialist_inference")
pr("pa_fe_imp", IMP(V("f_in_e"), EQ(V("pfe"), V("pf"))), "since F is contained in E, P(F and E) = P(F)", "general_knowledge")
pr("pa_pe", EQ(V("pe"), SUB(R("1"), V("prr"))), "P(E) = 1 - P(RR)", "specialist_inference")
pr("pa_pf", EQ(V("pf"), MUL(R("3/8"), R("2/7"))), "P(F) = 3/8 x 2/7", "arithmetic_fact")
pr("pa_pfge", EQ(V("pfge"), DIV(V("pf"), R("9/14"))), "P(F | E) = P(F) / P(E) with P(E) = 9/14", "specialist_inference")

C = {}
C["m2.1@maa"] = None
C = {}
C["m2.1"] = NULL("a standard discriminant criterion stated from memory; it contains no value-specific proposition beyond the formula checked in m2.4 to m2.6")
C["m2.2"] = NULL("a substitution of the given coefficients into the discriminant formula, which restates the definition; the simplified form is checked in m2.4 to m2.6")
C["m2.3"] = NULL("a simplification restating the discriminant formula with the given coefficients; no separate proposition to check beyond m2.4 to m2.6")
C["m2.4"] = ent("m2.4", "maa-m2.4", ["pa_pos", "pa_delta"], GT(SUB(R("36"), MUL(R("4"), V("k"))), R("0")),
                "36 - 4k > 0")
C["m2.5"] = ent("m2.5", "maa-m2.5", ["pa_24"], GT(MUL(R("-4"), V("k")), R("-36")),
                "-4k > -36 (subtracting 36 from both sides)")
C["m2.6"] = ent("m2.6", "maa-m2.6", ["pa_25"], LT(V("k"), R("9")),
                "k < 9 (dividing by -4 reverses the inequality)")
C["m4.1"] = NULL("a restatement of the question with k = 5 substituted; it asserts no result")
C["m4.3"] = NULL("a polynomial identity in x; products of the non-constant x are outside the IR allowlist")
C["m4.4"] = NULL("a polynomial identity in x; products of the non-constant x are outside the IR allowlist")
C["m4.5"] = NULL("a completed-square form in x; products of the non-constant x are outside the IR allowlist")
C["m4.6"] = NULL("a polynomial check in x; products of the non-constant x are outside the IR allowlist")
C["m4.7"] = NULL("a vertex claim about a quadratic in x; products of the non-constant x are outside the IR allowlist")
C["m5.1"] = ent("m5.1", "maa-m5.1", ["pa_g", "pa_h"],
                EQ(V("hgx"), DIV(ADD(MUL(R("2"), V("x")), R("2")), R("2"))),
                "(h o g)(x) = (2x + 2) / 2")
C["m5.2"] = ent("m5.2", "maa-m5.2", ["pa_g", "pa_h"], EQ(V("hgx"), ADD(V("x"), R("1"))),
                "(h o g)(x) = x + 1")
C["m5.3"] = ent("m5.3", "maa-m5.3", ["pa_g", "pa_h", "pa_x0"],
                AND(EQ(V("gx"), R("3")), EQ(V("hgx"), R("1"))),
                "at x = 0, g(0) = 3 and h(3) = 1 = 0 + 1")
C["m6.1"] = NULL("a set-up substitution (let y = 2x + 3) that asserts no result by itself; the derived form is checked in m6.2")
C["m6.2"] = ent("m6.2", "maa-m6.2", ["pa_y"], EQ(V("x"), DIV(SUB(V("y"), R("3")), R("2"))),
                "x = (y - 3) / 2, so the inverse is (x - 3) / 2 in the variable x")
C["m6.3"] = ent("m6.3", "maa-m6.3", ["pa_u", "pa_gu"], EQ(V("gu"), V("x")),
                "g((x - 3)/2) = 2 x (x - 3)/2 + 3 = x")
C["m7.1"] = ent("m7.1", "maa-m7.1", ["pa_m52", "pa_ginv", "pa_setup"],
                EQ(ADD(V("x"), R("1")), DIV(SUB(V("x"), R("3")), R("2"))),
                "x + 1 = (x - 3)/2, from (h o g)(x) = g^-1(x)")
C["m7.2"] = ent("m7.2", "maa-m7.2", ["pa_m52", "pa_ginv", "pa_setup"],
                EQ(ADD(MUL(R("2"), V("x")), R("2")), SUB(V("x"), R("3"))),
                "2x + 2 = x - 3")
C["m7.3"] = ent("m7.3", "maa-m7.3", ["pa_m52", "pa_ginv", "pa_setup"], EQ(V("x"), R("-5")),
                "x = -5")
C["m7.4"] = ENTRY(problem=PROBLEM("p-maa-m7.4", REQ, "m7.4", S, [],
                  P("concl", AND(EQ(ADD(R("-5"), R("1")), R("-4")), EQ(DIV(SUB(R("-5"), R("3")), R("2")), R("-4"))), None, None, None, None)),
                  reading="Check at x = -5: the left side is -4 and the right side (-5 - 3)/2 = -4.")
C["m8.1"] = NULL("a notation statement (R for red, B for blue); it asserts no result")
C["m8.2"] = NULL("a modelling assumption of the question (draws without replacement); no inference beyond m9.1 to check")
C["m9.1"] = ent("m9.1", "maa-m9.1", ["pa_prr"], EQ(V("prr"), R("5/14")), "P(both red) = 20/56 = 5/14")
C["m9.2"] = ENTRY(problem=PROBLEM("p-maa-m9.2", REQ, "m9.2", S, [],
                  P("concl", EQ(DIV(R("10"), R("28")), R("5/14")), None, None, None, None)),
                  reading="C(5,2) / C(8,2) = 10/28 = 5/14, a constant check.")
C["m10.1"] = ent("m10.1", "maa-m10.1", ["pa_pdiff"], EQ(V("pdiff"), R("15/28")),
                 "P(different colours) = 30/56 = 15/28")
C["m10.2"] = ENTRY(problem=PROBLEM("p-maa-m10.2", REQ, "m10.2", S, [],
                   P("concl", EQ(SUB(SUB(R("1"), R("5/14")), R("3/28")), R("15/28")), None, None, None, None)),
                   reading="1 - 5/14 - 3/28 = 15/28, a constant check (P(BB) = 3/28).")
C["m11.2"] = ent("m11.2", "maa-m11.2", ["pa_fe", "pa_fe_imp"], EQ(V("pfe"), V("pf")),
                 "since F is contained in E, P(F and E) = P(F)")
C["m11.3"] = ent("m11.3", "maa-m11.3", ["pa_prr", "pa_pe"], EQ(V("pe"), R("9/14")),
                 "P(E) = 1 - 5/14 = 9/14")
C["m11.4"] = ent("m11.4", "maa-m11.4", ["pa_pf"], EQ(V("pf"), R("3/28")), "P(F) = 3/28")
C["m11.5"] = ent("m11.5", "maa-m11.5", ["pa_pf", "pa_pfge"], EQ(V("pfge"), R("1/6")),
                 "P(F | E) = (3/28) / (9/14) = 42/252 = 1/6")
C["m11.6"] = ent("m11.6", "maa-m11.6", ["pa_pf", "pa_pfge"], EQ(V("pfge"), R("1/6")), "P(F | E) = 1/6")
C["m11.7"] = ENTRY(problem=PROBLEM("p-maa-m11.7", REQ, "m11.7", S, [],
                   P("concl", AND(EQ(SUB(R("28"), R("10")), R("18")), EQ(DIV(R("3"), R("18")), R("1/6"))), None, None, None, None)),
                   reading="Counting: C(8,2) - C(5,2) = 28 - 10 = 18 selections with a blue number, of which 3 are both blue, so 3/18 = 1/6.")

# closed arithmetic checks: bind each check to a declared symbol so the conclusion is not closed
def CHK(cid, pid, decls, concl_expr, label, reading):
    for name, sort, meaning, expr in decls:
        S[name] = SYM(name, sort, meaning, 'arithmetic_fact', None, None, 'established')
        PR[pid + '_' + name] = P(pid + '_' + name, EQ(V(name), expr), meaning, 'arithmetic_fact')
    prems = [PR[pid + '_' + d[0]] for d in decls]
    return ENTRY(problem=PROBLEM('p-' + pid, REQ, cid, S, prems, P('concl', concl_expr, label)), reading=reading)


C['m7.4'] = CHK('m7.4', 'maa-m7.4', [('lhs', 'Real', 'left side at x = -5', ADD(R('-5'), R('1'))), ('rhs', 'Real', 'right side at x = -5', DIV(SUB(R('-5'), R('3')), R('2')))],
                AND(EQ(V('lhs'), R('-4')), EQ(V('rhs'), R('-4'))), 'at x = -5 both sides equal -4', 'Check at x = -5: the left side is -4 and the right side (-5 - 3)/2 = -4.')
C['m9.2'] = CHK('m9.2', 'maa-m9.2', [('cr', 'Real', 'C(5,2) / C(8,2)', DIV(R('10'), R('28')))],
                EQ(V('cr'), R('5/14')), 'C(5,2)/C(8,2) = 5/14', 'C(5,2) / C(8,2) = 10/28 = 5/14, a constant check.')
C['m10.2'] = CHK('m10.2', 'maa-m10.2', [('cd', 'Real', '1 - P(RR) - P(BB)', SUB(SUB(R('1'), R('5/14')), R('3/28')))],
                 EQ(V('cd'), R('15/28')), '1 - 5/14 - 3/28 = 15/28', '1 - 5/14 - 3/28 = 15/28, a constant check (P(BB) = 3/28).')
C['m11.7'] = CHK('m11.7', 'maa-m11.7', [('nb', 'Real', 'selections with at least one blue number', SUB(R('28'), R('10'))), ('fr', 'Real', 'fraction both blue', DIV(R('3'), R('18')))],
                 AND(EQ(V('nb'), R('18')), EQ(V('fr'), R('1/6'))), 'C(8,2) - C(5,2) = 18 and 3/18 = 1/6', 'Counting: C(8,2) - C(5,2) = 18 selections with a blue number, of which 3 are both blue, so 3/18 = 1/6.')

DUMP("maa-t15", "rep-maa-t15-0", C)
