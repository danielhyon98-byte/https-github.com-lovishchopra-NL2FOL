import sys
sys.path.insert(0, "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2/tr")
from ir import *

REQ = "req-p9b"
S = {}
PR = {}


def sym(name, sort, meaning, kind=None, cert="established"):
    S[name] = SYM(name, sort, meaning, kind, None, None, cert)


def pr(pid, expr, label, kind=None, cert="established"):
    PR[pid] = P(pid, expr, label, kind, None, None, cert)


def PB(cid, pid, prems, concl_expr, concl_label, reading):
    problem = PROBLEM("p-" + pid, REQ, cid, S, [PR[p] for p in prems], P("concl", concl_expr, concl_label))
    return ENTRY(problem=problem, reading=reading)


def NULL(reason):
    return ENTRY(unsup=reason, reading=reason)


# symbols
sym("mc", "Real", "molar mass of C used (g mol-1)", "task_setting")
sym("mh", "Real", "molar mass of H used (g mol-1)", "task_setting")
sym("mo", "Real", "molar mass of O used (g mol-1)", "task_setting")
sym("mm", "Real", "molar mass of sucrose (g mol-1)", "arithmetic_fact")
sym("msuc", "Real", "mass of sucrose dissolved (g)", "task_setting")
sym("vcm", "Real", "volume of the stock solution made up (cm3)", "task_setting")
sym("vdm", "Real", "volume of the stock solution (dm3)", "arithmetic_fact")
sym("n", "Real", "amount of sucrose in the stock (mol)", "arithmetic_fact")
sym("cs", "Real", "concentration of the stock solution (mol dm-3)", "arithmetic_fact")
sym("c10", "Real", "concentration of the 10.00 cm3 dilution (mol dm-3)", "arithmetic_fact")
sym("c20", "Real", "concentration of the 20.00 cm3 dilution (mol dm-3)", "arithmetic_fact")
sym("c30", "Real", "concentration of the 30.00 cm3 dilution (mol dm-3)", "arithmetic_fact")
sym("c40", "Real", "concentration of the 40.00 cm3 dilution (mol dm-3)", "arithmetic_fact")
sym("dm", "Real", "balance uncertainty (g)", "task_setting")
sym("dv", "Real", "flask volume uncertainty (cm3)", "task_setting")
sym("e1", "Real", "percentage uncertainty from the balance (%)", "arithmetic_fact")
sym("e2", "Real", "percentage uncertainty from the flask (%)", "arithmetic_fact")
sym("etot", "Real", "total percentage uncertainty in the stock concentration (%)", "arithmetic_fact")
sym("vcm1", "Real", "volume of the most dilute sample (cm3)", "task_setting")
sym("v1", "Real", "volume of the most dilute sample (dm3)", "arithmetic_fact")
sym("n1", "Real", "amount of sucrose in 1.00 cm3 of the most dilute solution (mol)", "arithmetic_fact")
sym("nmol", "Real", "number of sucrose molecules in 1.00 cm3 (3 s.f. check, unrounded)", "arithmetic_fact")
sym("nrnd", "Real", "molecules with the rounded 0.197 mol dm-3", "arithmetic_fact")
sym("na", "Real", "Avogadro constant (mol-1)", "general_knowledge")
sym("cyl_less", "Bool", "a measuring cylinder is less precise than a volumetric flask", "general_knowledge", cert="established")
sym("vol_unc", "Bool", "the volume of each solution would be less certain", "specialist_inference")
sym("conc_unc", "Bool", "the concentration of each solution would be less certain", "specialist_inference")
sym("vf_reason", "Bool", "a volumetric flask is used because it gives the precise volume needed", "specialist_inference")

# premises
pr("pa_mc", EQ(V("mc"), R("12.01")), "M(C) = 12.01 (question)", "task_setting")
pr("pa_mh", EQ(V("mh"), R("1.01")), "M(H) = 1.01 (question)", "task_setting")
pr("pa_mo", EQ(V("mo"), R("16.00")), "M(O) = 16.00 (question)", "task_setting")
pr("pa_msuc", EQ(V("msuc"), R("84.20")), "84.20 g of sucrose dissolved (question)", "task_setting")
pr("pa_vcm", EQ(V("vcm"), R("250.0")), "solution made up to 250.0 cm3 (question)", "task_setting")
pr("pa_dm", EQ(V("dm"), R("0.01")), "balance reads to 0.01 g (question)", "task_setting")
pr("pa_dv", EQ(V("dv"), R("0.30")), "flask uncertainty 0.30 cm3 (question)", "task_setting")
pr("pa_vcm1", EQ(V("vcm1"), R("1.00")), "1.00 cm3 sample (question)", "task_setting")
pr("pa_na", EQ(V("na"), R("602000000000000000000000")), "N_A = 6.02 x 10^23 mol-1", "general_knowledge")
pr("pa_mm", EQ(V("mm"), R("342.34")), "molar mass of sucrose 342.34 g mol-1", "arithmetic_fact")
pr("d_mm", EQ(V("mm"), ADD(MUL(R("12"), V("mc")), MUL(R("22"), V("mh")), MUL(R("11"), V("mo")))),
   "M = 12(12.01) + 22(1.01) + 11(16.00)", "arithmetic_fact")
pr("d_n", EQ(V("n"), DIV(V("msuc"), R("342.34"))), "n = m / M", "specialist_inference")
pr("d_cs", EQ(V("cs"), DIV(V("n"), R("0.25"))), "c = n / 0.2500 dm3", "specialist_inference")
pr("d_vdm", EQ(V("vdm"), DIV(V("vcm"), R("1000"))), "V(dm3) = V(cm3) / 1000", "arithmetic_fact")
pr("d_c10", EQ(V("c10"), DIV(MUL(R("0.98382"), R("10.00")), R("50.00"))), "c(10.00) = 0.98382 x 10.00 / 50.00", "specialist_inference")
pr("d_c20", EQ(V("c20"), DIV(MUL(R("0.98382"), R("20.00")), R("50.00"))), "c(20.00) = 0.98382 x 20.00 / 50.00", "specialist_inference")
pr("d_c30", EQ(V("c30"), DIV(MUL(R("0.98382"), R("30.00")), R("50.00"))), "c(30.00) = 0.98382 x 30.00 / 50.00", "specialist_inference")
pr("d_c40", EQ(V("c40"), DIV(MUL(R("0.98382"), R("40.00")), R("50.00"))), "c(40.00) = 0.98382 x 40.00 / 50.00", "specialist_inference")
pr("d_e1", EQ(V("e1"), DIV(MUL(V("dm"), R("100")), R("84.20"))), "0.01 / 84.20 x 100", "specialist_inference")
pr("d_e2", EQ(V("e2"), DIV(MUL(V("dv"), R("100")), R("250.0"))), "0.30 / 250.0 x 100", "specialist_inference")
pr("d_etot", EQ(V("etot"), ADD(V("e1"), V("e2"))), "percentage uncertainties add for a quotient", "specialist_inference")
pr("d_v1", EQ(V("v1"), DIV(V("vcm1"), R("1000"))), "V(dm3) = 1.00 / 1000", "arithmetic_fact")
pr("d_n1", EQ(V("n1"), MUL(R("0.19676"), V("v1"))), "n = c x V = 0.19676 x 1.00e-3", "specialist_inference")
pr("d_nmol", EQ(V("nmol"), MUL(V("n1"), R("602000000000000000000000"))), "N = n x N_A", "specialist_inference")
pr("d_nrnd", EQ(V("nrnd"), MUL(R("0.197"), V("v1"), R("602000000000000000000000"))), "with 0.197 mol dm-3, N = 0.197 x 1.00e-3 x N_A", "specialist_inference")
pr("pa_c10v", EQ(V("c10"), R("0.19676")), "c(10.00) = 0.19676 (unrounded)", "specialist_inference")

C = {}
C["s1.1"] = NULL("a restatement of data supplied in the question; no relation between premises and conclusion to check")
C["s1.2"] = NULL("the Avogadro constant is stated from memory as a standard value; a bare fact with no relation to check")

C["s3.1"] = PB("s3.1", "ch-s3.1", ["pa_mc", "pa_mh", "pa_mo", "d_mm"],
               EQ(V("mm"), R("342.34")), "the molar mass of sucrose is 342.34 g mol-1",
               "M = 12(12.01) + 22(1.01) + 11(16.00) = 144.12 + 22.22 + 176.00 = 342.34.")

C["s5.1"] = PB("s5.1", "ch-s5.1", ["pa_msuc", "d_n", "pa_mm"],
               AND(GE(V("n"), R("0.2459535")), LT(V("n"), R("0.2459545"))),
               "n(sucrose) = 0.245954 mol unrounded",
               "n = 84.20 / 342.34 = 0.245954 (six decimal places, so the exact value lies in [0.2459535, 0.2459545)).")

C["s5.2"] = PB("s5.2", "ch-s5.2", ["pa_vcm", "d_vdm"],
               AND(GE(V("vdm"), R("0.24995")), LT(V("vdm"), R("0.25005"))),
               "V = 0.2500 dm3",
               "250.0 cm3 / 1000 = 0.2500 dm3 (four decimal places).")

C["s5.3"] = PB("s5.3", "ch-s5.3", ["pa_msuc", "pa_mm", "d_n", "d_cs"],
               AND(GE(V("cs"), R("0.9835")), LT(V("cs"), R("0.9845"))),
               "c(stock) = 0.984 mol dm-3 to 3 s.f.",
               "c = 0.245954 / 0.2500 = 0.98382, which is 0.984 to three significant figures.")

C["s7.1"] = NULL("a general dilution formula with no numerical value; its instances s7.3 to s7.6 are the checkable statements")

C["s7.2"] = PB("s7.2", "ch-s7.2", ["pa_msuc", "d_n", "d_cs"],
               AND(GE(V("cs"), R("0.983815")), LT(V("cs"), R("0.983825"))),
               "the unrounded stock concentration is 0.98382 mol dm-3",
               "The unrounded stock concentration 84.20 / 342.34 / 0.25 = 0.9838173, which is 0.98382 to five decimal places.")

C["s7.3"] = PB("s7.3", "ch-s7.3", ["d_c10"],
               AND(GE(V("c10"), R("0.196755")), LT(V("c10"), R("0.196765")), GE(V("c10"), R("0.1965")), LT(V("c10"), R("0.1975"))),
               "c(10.00 cm3 dilution) = 0.19676 mol dm-3, so 0.197 to 3 s.f.",
               "0.98382 x (10.00 / 50.00) = 0.196764, which is 0.19676 to five decimal places and 0.197 to three significant figures.")

C["s7.4"] = PB("s7.4", "ch-s7.4", ["d_c20"],
               AND(GE(V("c20"), R("0.393525")), LT(V("c20"), R("0.393535")), GE(V("c20"), R("0.3935")), LT(V("c20"), R("0.3945"))),
               "c(20.00 cm3 dilution) = 0.39353 mol dm-3, so 0.394 to 3 s.f.",
               "0.98382 x (20.00 / 50.00) = 0.393528, which is 0.39353 and 0.394 to three significant figures.")

C["s7.5"] = PB("s7.5", "ch-s7.5", ["d_c30"],
               AND(GE(V("c30"), R("0.590285")), LT(V("c30"), R("0.590295")), GE(V("c30"), R("0.5895")), LT(V("c30"), R("0.5905"))),
               "c(30.00 cm3 dilution) = 0.59029 mol dm-3, so 0.590 to 3 s.f.",
               "0.98382 x (30.00 / 50.00) = 0.590292, which is 0.59029 and 0.590 to three significant figures.")

C["s7.6"] = PB("s7.6", "ch-s7.6", ["d_c40"],
               AND(GE(V("c40"), R("0.787055")), LT(V("c40"), R("0.787065")), GE(V("c40"), R("0.7865")), LT(V("c40"), R("0.7875"))),
               "c(40.00 cm3 dilution) = 0.78706 mol dm-3, so 0.787 to 3 s.f.",
               "0.98382 x (40.00 / 50.00) = 0.787056, which is 0.78706 and 0.787 to three significant figures.")

C["s9.2"] = PB("s9.2", "ch-s9.2", ["pa_dm", "pa_msuc", "d_e1"],
               AND(GE(V("e1"), R("0.01185")), LT(V("e1"), R("0.01195"))),
               "the balance gives a percentage uncertainty of 0.0119%",
               "0.01 / 84.20 x 100 = 0.011876%, which is 0.0119% to three significant figures.")

C["s9.3"] = PB("s9.3", "ch-s9.3", ["pa_dv", "pa_vcm", "d_e2"],
               AND(GE(V("e2"), R("0.1195")), LT(V("e2"), R("0.1205"))),
               "the flask gives a percentage uncertainty of 0.120%",
               "0.30 / 250.0 x 100 = 0.120%.")

C["s9.4"] = PB("s9.4", "ch-s9.4", ["d_e1", "d_e2", "d_etot"],
               AND(GE(V("etot"), R("0.1315")), LT(V("etot"), R("0.1325")), GE(V("etot"), R("0.125")), LT(V("etot"), R("0.135"))),
               "the total percentage uncertainty is 0.132%, which is 0.13% to two significant figures",
               "For a quotient the percentage uncertainties add: 0.011876% + 0.120% = 0.131876%, which is 0.132% (three decimal places) and 0.13% (two significant figures).")

C["s10.1"] = NULL("a heading naming the quantity to be calculated; it states no claim")

C["s11.1"] = PB("s11.1", "ch-s11.1", ["d_c10", "d_c20", "d_c30", "d_c40", "pa_c10v"],
                AND(LT(V("c10"), V("c20")), LT(V("c10"), V("c30")), LT(V("c10"), V("c40")),
                    GE(V("c10"), R("0.196755")), LT(V("c10"), R("0.196765"))),
                "the most dilute solution is the 10.00 cm3 dilution, with c = 0.19676 mol dm-3",
                "The 10.00 cm3 dilution has the smallest concentration of the four and its unrounded value is 0.19676.")

C["s11.2"] = PB("s11.2", "ch-s11.2", ["pa_vcm1", "d_v1"],
                EQ(V("v1"), R("0.001")), "V = 1.00 x 10^-3 dm3",
                "1.00 cm3 / 1000 = 1.00 x 10^-3 dm3.")

C["s11.3"] = PB("s11.3", "ch-s11.3", ["pa_c10v", "d_v1", "d_n1"],
                EQ(V("n1"), R("0.00019676")), "n = 1.9676 x 10^-4 mol",
                "n = 0.19676 mol dm-3 x 1.00 x 10^-3 dm3 = 1.9676 x 10^-4 mol.")

C["s11.4"] = PB("s11.4", "ch-s11.4", ["d_n1", "d_nmol", "pa_na", "pa_c10v", "d_v1"],
                AND(GE(V("nmol"), R("117500000000000000000")), LT(V("nmol"), R("118500000000000000000"))),
                "N = 1.18 x 10^20 molecules (3 s.f.)",
                "N = 1.9676 x 10^-4 mol x 6.02 x 10^23 mol-1 = 1.18450 x 10^20, which is 1.18 x 10^20 to three significant figures.")

C["s11.5"] = PB("s11.5", "ch-s11.5", ["pa_vcm1", "d_v1", "d_nrnd", "pa_na"],
                AND(GE(V("nrnd"), R("118500000000000000000")), LT(V("nrnd"), R("119500000000000000000"))),
                "with the rounded 0.197 mol dm-3 the result would be 1.19 x 10^20",
                "0.197 x 1.00 x 10^-3 x 6.02 x 10^23 = 1.18594 x 10^20, which is 1.19 x 10^20 to three significant figures; the unrounded value is carried in s11.4.")

# s12.1 point: why a volumetric flask
C["s12.1"] = ENTRY(problem=PROBLEM("p-ch-s12.1", REQ, "s12.1", S,
                   [P("pr_cyl", V("cyl_less"), "a measuring cylinder is less precise", "general_knowledge"),
                    P("pr_l1", IMP(V("cyl_less"), V("vol_unc")), "less precise measurement makes the volume less certain", "specialist_inference"),
                    P("pr_l2", IMP(V("vol_unc"), V("conc_unc")), "a less certain volume makes the concentration less certain", "specialist_inference"),
                    P("pr_l3", IMP(V("conc_unc"), V("vf_reason")), "the flask is used to avoid uncertain concentrations", "specialist_inference")],
                   P("concl", V("vf_reason"), "a volumetric flask is used rather than a measuring cylinder because the concentration is more certain")),
                   reading="Chain: a measuring cylinder is less precise (general knowledge); so the volume and then the concentration would be less certain; so the flask is used. Encoded as implications.")

C["s13.1"] = NULL("a bare fact from subject knowledge (calibrated mark, one precise volume); it is encoded as a premise of s13.2 and s12.1 instead")

C["s13.2"] = ENTRY(problem=PROBLEM("p-ch-s13.2", REQ, "s13.2", S,
                   [P("pr_cyl", V("cyl_less"), "a measuring cylinder is less precise", "general_knowledge"),
                    P("pr_l1", IMP(V("cyl_less"), V("vol_unc")), "a less precise measurement makes the volume less certain", "specialist_inference"),
                    P("pr_l2", IMP(V("vol_unc"), V("conc_unc")), "a less certain volume makes the concentration less certain", "specialist_inference")],
                   P("concl", AND(V("vol_unc"), V("conc_unc")), "the volume and therefore the concentration would be less certain with a measuring cylinder")),
                   reading="A measuring cylinder is less precise, so the volume and therefore the concentration would be less certain (judgement, encoded as implications).")

C["s14.1"] = NULL("a heading introducing the concentrations; it states no claim")

C["s14.3"] = PB("s14.3", "ch-s14.3", ["d_c10"],
                AND(GE(V("c10"), R("0.1965")), LT(V("c10"), R("0.1975"))),
                "10.00 cm3 of stock gives 0.197 mol dm-3 to 3 s.f.",
                "0.98382 x (10.00 / 50.00) = 0.19676, which is 0.197 to three significant figures.")

C["s14.4"] = PB("s14.4", "ch-s14.4", ["d_c20"],
                AND(GE(V("c20"), R("0.3935")), LT(V("c20"), R("0.3945"))),
                "20.00 cm3 of stock gives 0.394 mol dm-3 to 3 s.f.",
                "0.98382 x (20.00 / 50.00) = 0.39353, which is 0.394 to three significant figures.")

C["s14.5"] = PB("s14.5", "ch-s14.5", ["d_c30"],
                AND(GE(V("c30"), R("0.5895")), LT(V("c30"), R("0.5905"))),
                "30.00 cm3 of stock gives 0.590 mol dm-3 to 3 s.f.",
                "0.98382 x (30.00 / 50.00) = 0.59029, which is 0.590 to three significant figures.")

C["s14.6"] = PB("s14.6", "ch-s14.6", ["d_c40"],
                AND(GE(V("c40"), R("0.7865")), LT(V("c40"), R("0.7875"))),
                "40.00 cm3 of stock gives 0.787 mol dm-3 to 3 s.f.",
                "0.98382 x (40.00 / 50.00) = 0.78706, which is 0.787 to three significant figures.")

C["s15.1"] = NULL("an instruction to the student to practise; it states no claim")

DUMP("ch-p9b", "rep-ch-p9b-0", C)
