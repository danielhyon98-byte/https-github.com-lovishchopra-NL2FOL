import json,sys
name=sys.argv[1]; base=sys.argv[2]
L=json.load(open(f"{base}/listings/{name}.listing.json"))
R=json.load(open(f"{base}/revisions/{name}.json"))
print("REPORT",L['report_id'],"REQ",L['request_id'],"BRANCH",L['branch'],"DELIVERED_AFTER",L['delivered_after'],"QUALIFIED",L['ids_qualified'])
print("TASK",R['task_id'],R['subject'],R['task_type'])
print("QUESTION:",R['question'])
for t in R['supplied_texts']:
    print("DOC",t['document_id'],"|",t.get('title'))
    print(t['text']); print("--END DOC--")
print("CLAIMS:")
for c in L['claims']:
    sup=c['supporting_claim_ids']
    print(c['claim_id'],"|",c['role'],"|",c['materiality'],"|",c['certainty'],"|",c['eligibility_class'],"| sup:",sup,"| asm:",c['assumptions'] if c['assumptions'] else "", "\n   TEXT:",c['text'])
