import sys
sys.path.insert(0, "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2/tr")
from ir import *

REQ = "req-ll-t15"
DOC = "doc-baths"
S = {}


def sym(name, sort, meaning, kind=None, doc=None, excerpt=None, cert="established"):
    S[name] = SYM(name, sort, meaning, kind, doc, excerpt, cert)


def P2(pid, expr, label, kind=None, doc=None, excerpt=None, cert="established"):
    return P(pid, expr, label, kind, doc, excerpt, cert)


sym("anecdote", "Bool", "the column opens with a personal anecdote about learning to swim", "supplied_text", DOC,
    "I learned to swim at the Corran Street Baths in 1989")
sym("humour", "Bool", "the column makes a humorous point about the swimmers", "supplied_text", DOC, "equally bad at butterfly in public")
sym("fused", "Bool", "anecdote and humour are fused", "specialist_inference", cert="probable")
sym("plan_absurd", "Bool", "the council's plan looks absurd to anyone who has swum there", "specialist_inference", cert="probable")
sym("whistle", "Bool", "the column closes with Mr Pask blowing his whistle", "supplied_text", DOC, "Mr Pask would have blown his whistle")
sym("stand_deep", "Bool", "the reader is told to stand at the deep end", "supplied_text", DOC, "Stand at the deep end")
sym("community", "Bool", "the community is grounded in a physical place", "specialist_inference", cert="probable")
sym("loyalty", "Bool", "opposing closure is loyalty to the community the anecdote builds", "specialist_inference", cert="probable")

C = {}
C["p1-point"] = ENTRY(problem=PROBLEM("p-ll-t15-p1-point", REQ, "p1-point", S,
    [P2("pr_an", V("anecdote"), "the anecdote about learning to swim", "supplied_text", DOC, "I learned to swim at the Corran Street Baths in 1989"),
     P2("pr_hu", V("humour"), "the humour about the swimmers", "supplied_text", DOC, "equally bad at butterfly in public"),
     P2("pr_fu", IMP(AND(V("anecdote"), V("humour")), V("fused")), "anecdote and humour are fused", "specialist_inference", cert="probable"),
     P2("pr_ab", IMP(V("fused"), V("plan_absurd")), "fused anecdote and humour make the plan look absurd to swimmers", "specialist_inference", cert="probable")],
    P2("concl", V("plan_absurd"), "the council's plan looks absurd to anyone who has swum there", None, None, None, "probable")),
    reading="Anecdote (quoted) and humour (quoted) are fused, so the plan looks absurd to swimmers (probable). The claim's persuasion to oppose closure is not separately encoded.")

C["p1-s11"] = ENTRY(problem=PROBLEM("p-ll-t15-p1-s11", REQ, "p1-s11", S,
    [P2("pr_wh", V("whistle"), "the column closes with Mr Pask blowing his whistle", "supplied_text", DOC, "Mr Pask would have blown his whistle"),
     P2("pr_sd", V("stand_deep"), "the reader is told to stand at the deep end", "supplied_text", DOC, "Stand at the deep end"),
     P2("pr_cm", IMP(AND(V("whistle"), V("stand_deep")), V("community")), "the closing image and the physical place ground the community", "specialist_inference", cert="probable"),
     P2("pr_lo", IMP(V("community"), V("loyalty")), "a community built by the anecdote makes opposing closure loyalty", "specialist_inference", cert="probable")],
    P2("concl", V("loyalty"), "opposing the closure becomes loyalty to the community the anecdote has built", None, None, None, "probable")),
    reading="The closing whistle and the call to stand at the deep end (both quoted) ground the community; opposing closure is then loyalty to it (probable).")

DUMP("ll-t15", "rep-ll-t15-0", C)
