#!/bin/bash
# usage: validate.sh <task>; runs the instructed validation command for every claim with a problem
P=/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/z3venv/bin/python
F=/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2/revision-translations/$1.json
ids=$($P -I -c "import json,sys; d=json.load(open(sys.argv[1])); print('\n'.join(k for k,v in d['claims'].items() if v['problem'] is not None))" "$F")
bad=0; n=0
for id in $ids; do
  n=$((n+1))
  r=$(cd /home/user/https-github.com-lovishchopra-NL2FOL && $P -I -c "import json,sys; from epinoic_logic.engine import parse_and_validate; p,o=parse_and_validate(json.dumps(json.load(open(sys.argv[1]))['claims'][sys.argv[2]]['problem'])); print(o.ok)" "$F" "$id" 2>&1 | tail -1)
  if [ "$r" != "True" ]; then bad=$((bad+1)); echo "FAIL $id -> $r"; fi
done
echo "$1: checked $n problems, failures $bad"
