import sys
sys.path.insert(0, "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2/tr")
from ir import *

REQ = "req-ec-t15"
DOC = "doc-halvoria"
DOCS = "doc-halvoria-student"
S = {}
PR = {}


def sym(name, sort, meaning, kind=None, doc=None, excerpt=None, cert="established"):
    S[name] = SYM(name, sort, meaning, kind, doc, excerpt, cert)


def pr(pid, expr, label, kind=None, doc=None, excerpt=None, cert="established"):
    PR[pid] = P(pid, expr, label, kind, doc, excerpt, cert)


def PB(cid, pid, prems, concl_expr, concl_label, reading, ambiguous=False, flags=()):
    problem = PROBLEM("p-" + pid, REQ, cid, S, [PR[p] if isinstance(p, str) else p for p in prems],
                      P("concl", concl_expr, concl_label))
    return ENTRY(problem=problem, reading=reading, ambiguous=ambiguous, flags=flags)


def NULL(reason):
    return ENTRY(unsup=reason, reading=reason)


FB = "marking feedback or an instruction to the student, not a proposition the report asserts about the economy or the figures"

# Table 1 values (billion dalers) with exact-row excerpts
rows = {
    "xg": ("Exports of goods | 48.2 | 45.6", (48.2, 45.6)),
    "mg": ("Imports of goods | 52.9 | 55.1", (52.9, 55.1)),
    "xs": ("Exports of services | 14.7 | 15.3", (14.7, 15.3)),
    "ms": ("Imports of services | 9.8 | 10.4", (9.8, 10.4)),
    "gdp": ("Nominal GDP | 412.0 | 425.0", (412.0, 425.0)),
}
names = {"xg": "exports of goods", "mg": "imports of goods", "xs": "exports of services",
         "ms": "imports of services", "gdp": "nominal GDP"}
vals = {}
for k, (ex, (a, b)) in rows.items():
    for yr, num, txt in (("24", a, "2024"), ("25", b, "2025")):
        n = k + yr
        sym(n, "Real", f"{names[k]} {txt} (billion dalers)", "quotation", DOC, ex)
        pr("t_" + n, EQ(V(n), R(str(num))), f"{names[k]} {txt} is {num} billion dalers (Table 1)", "quotation", DOC, ex)

sym("sden", "Real", "the GDP denominator used in the student's answer (billion dalers)", "supplied_text", DOCS, None)
pr("pa_sden", EQ(V("sden"), R("412.0")), "the student divides by 412.0", "supplied_text", DOCS, None)
sym("xgsub", "Real", "2025 balance of trade in goods (goods only)", "arithmetic_fact")
sym("bot25", "Real", "2025 balance of trade in goods and services", "arithmetic_fact")
sym("nx24", "Real", "net exports 2024 on goods and services (billion dalers)", "arithmetic_fact")
sym("nx25", "Real", "net exports 2025 on goods and services (billion dalers)", "arithmetic_fact")
pr("d_nx24", EQ(V("nx24"), SUB(ADD(V("xg24"), V("xs24")), ADD(V("mg24"), V("ms24")))), "net exports 2024 = (exports of goods + services) - (imports of goods + services)", "arithmetic_fact")
pr("d_nx25", EQ(V("nx25"), SUB(ADD(V("xg25"), V("xs25")), ADD(V("mg25"), V("ms25")))), "net exports 2025 = (exports of goods + services) - (imports of goods + services)", "arithmetic_fact")
sym("goods_only", "Bool", "the student's working uses goods figures only", "supplied_text", DOCS, None)
sym("svc_left", "Bool", "the services figures are left out of the working", "specialist_inference")
sym("nx_fell", "Bool", "net exports fell between 2024 and 2025", "specialist_inference")
sym("ad_left", "Bool", "aggregate demand shifts left", "specialist_inference")
sym("gdp_falls", "Bool", "real GDP falls", "specialist_inference")
sym("ca_comp", "Bool", "the current account includes goods, services, primary and secondary income", "general_knowledge")
sym("deficit_any", "Bool", "a current account deficit can come from any of these components", "specialist_inference")

C = {}
C["g1.1@economics-specialist"] = NULL(FB)
C["g1.4@economics-specialist"] = NULL(FB + " (a provisional mark)")
C["g1.6@economics-specialist"] = ENTRY(problem=PROBLEM("p-ec-g1.6", REQ, "g1.6@economics-specialist", S,
    [P("pr_comp", V("ca_comp"), "the current account covers goods, services, net primary income and net secondary income", "general_knowledge"),
     P("pr_any", IMP(V("ca_comp"), V("deficit_any")), "a deficit can therefore come from any component", "specialist_inference")],
    P("concl", V("deficit_any"), "a deficit can come from any of the components")),
    reading="The current account includes trade in services, net primary income and net secondary income as well as goods, so a deficit can come from any of them (general knowledge).")
C["g1.7@economics-specialist"] = NULL(FB)
C["g1.8@economics-specialist"] = NULL(FB + "; the definition is also a bare fact from memory")
C["g1.9@economics-specialist"] = NULL(FB)
C["g2.1@economics-specialist"] = NULL("restates the part-(b) instruction; it asserts no result")
C["g2.2@economics-specialist"] = NULL(FB)
C["g2.3@economics-specialist"] = PB("g2.3@economics-specialist", "ec-g2.3", ["t_xg25", "t_mg25"],
    EQ(SUB(V("xg25"), V("mg25")), R("-9.5")), "the subtraction 45.6 - 55.1 gives -9.5 billion dalers",
    "Exports of goods 45.6 minus imports of goods 55.1 is -9.5 billion dalers; the subtraction itself is correct. The unit and deficit sign are the marker's credit note and are not encoded.")
C["g2.4@economics-specialist"] = NULL(FB + " (a provisional mark)")
C["g2.5@economics-specialist"] = PB("g2.5@economics-specialist", "ec-g2.5",
    [P("pr_gonly", V("goods_only"), "the student's working uses goods figures only", "supplied_text", DOCS, None),
     P("pr_svc", IMP(V("goods_only"), V("svc_left")), "figures for goods only leave the services figures out", "specialist_inference")],
    V("svc_left"), "the services figures (15.3 and 10.4) are left out of the student's working",
    "The student's working is goods only, so the services figures are left out.")
C["g2.6@economics-specialist"] = NULL(FB)
C["g2.7@economics-specialist"] = NULL(FB)
C["g2.9@economics-specialist"] = NULL("a vague directive ('the two should agree') with no checkable proposition")
C["g2.10@economics-specialist"] = NULL("a definitional model formula; it restates the definition of the balance and yields no separate proposition to check")
C["g3.1@economics-specialist"] = NULL("restates the part-(c) instruction; it asserts no result")
C["g3.2@economics-specialist"] = NULL(FB)
C["g3.4@economics-specialist"] = NULL(FB + " (a provisional mark)")
C["g3.6@economics-specialist"] = NULL("a superlative ('the largest error') over a set of errors that the supplied texts do not enumerate")
C["g3.7@economics-specialist"] = PB("g3.7@economics-specialist", "ec-g3.7",
    ["pa_sden", "t_gdp24", "t_gdp25"],
    AND(EQ(V("sden"), V("gdp24")), NE(V("sden"), V("gdp25"))),
    "the percentage divides by 2024 GDP (412.0) rather than 2025 GDP (425.0)",
    "The student's denominator is 412.0, which is the 2024 nominal GDP and not the 2025 figure of 425.0.")
C["g3.8@economics-specialist"] = NULL(FB)
C["g3.9@economics-specialist"] = NULL(FB)
C["g3.10@economics-specialist"] = NULL(FB)
C["g3.11@economics-specialist"] = NULL("a definitional model formula; it yields no separate proposition to check beyond the arithmetic claims")
C["g4.1@economics-specialist"] = NULL("restates the part-(d) question; it asserts no result")
C["g4.4@economics-specialist"] = PB("g4.4@economics-specialist", "ec-g4.4",
    ["t_xg24", "t_xg25", "t_xs24", "t_xs25", "t_mg24", "t_mg25", "t_ms24", "t_ms25", "d_nx24", "d_nx25"],
    AND(EQ(V("nx24"), R("0.2")), EQ(V("nx25"), R("-4.6"))),
    "net exports on a goods and services basis are 0.2 billion dalers in 2024 and -4.6 billion dalers in 2025",
    "2024: (48.2 + 14.7) - (52.9 + 9.8) = 0.2; 2025: (45.6 + 15.3) - (55.1 + 10.4) = -4.6. The diagram axes are a marker's credit note and are not encoded.")
C["g4.5@economics-specialist"] = NULL(FB + " (a provisional mark)")
C["g4.7@economics-specialist"] = PB("g4.7@economics-specialist", "ec-g4.7",
    ["t_xg24", "t_xg25", "t_xs24", "t_xs25", "t_mg24", "t_mg25", "t_ms24", "t_ms25", "d_nx24", "d_nx25"],
    EQ(SUB(V("nx24"), V("nx25")), R("4.8")), "net exports fell by 4.8 billion dalers",
    "Net exports fell from 0.2 to -4.6, a fall of 4.8 billion dalers.")
C["g4.8@economics-specialist"] = PB("g4.8@economics-specialist", "ec-g4.8",
    ["t_xg24", "t_xg25", "t_xs24", "t_xs25", "t_mg24", "t_mg25", "t_ms24", "t_ms25", "d_nx24", "d_nx25",
     P("pr_fell", IMP(GT(SUB(V("nx24"), V("nx25")), R("0")), V("nx_fell")), "a positive fall in net exports is a fall", "specialist_inference"),
     P("pr_ad", IMP(V("nx_fell"), V("ad_left")), "a fall in net exports reduces aggregate demand, so AD shifts left", "specialist_inference"),
     P("pr_gdp", IMP(V("ad_left"), V("gdp_falls")), "a leftward AD shift reduces real GDP", "specialist_inference")],
    AND(V("ad_left"), V("gdp_falls")), "AD shifts left, not right, and real GDP falls",
    "Net exports fall by 4.8, so AD shifts left and real GDP falls (in the short run, on the usual AD/AS reading).")
C["g4.11@economics-specialist"] = NULL(FB)
C["g4.15@economics-specialist"] = NULL("a model statement of the causal chain restated from g4.8; the checkable content is in g4.8")
C["g5.1@economics-specialist"] = NULL("a provisional total mark and an estimate for practice only")
C["g6.1@economics-specialist"] = NULL(FB + " (a general pattern summary)")
C["g7.1@economics-specialist"] = NULL("a next practice task for the student; it asserts no result")

DUMP("ec-t15", "rep-ec-t15-0", C)
