import sys
sys.path.insert(0, "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2/tr")
from ir import *

REQ = "req-bm-t15"
DOC = "doc-pellow"
S = {}
PR = {}


def sym(name, sort, meaning, kind=None, doc=None, excerpt=None, cert="established"):
    S[name] = SYM(name, sort, meaning, kind, doc, excerpt, cert)


def pr(pid, expr, label, kind=None, doc=None, excerpt=None, cert="established"):
    PR[pid] = P(pid, expr, label, kind, doc, excerpt, cert)


def PB(cid, pid, prems, concl_expr, concl_label, reading, ambiguous=False, flags=()):
    problem = PROBLEM("p-" + pid, REQ, cid, S, [PR[p] if isinstance(p, str) else p for p in prems],
                      P("concl", concl_expr, concl_label))
    return ENTRY(problem=problem, reading=reading, ambiguous=ambiguous, flags=flags)


# ---- symbols (report-wide) ----
sym("s24", "Real", "Pellow Cycles sales revenue 2024 ($)", "arithmetic_fact", DOC, "2024 | 180,000 | 1,200,000")
sym("m24", "Real", "total Fenwick market sales revenue 2024 ($)", "arithmetic_fact", DOC, "2024 | 180,000 | 1,200,000")
sym("s25", "Real", "Pellow Cycles sales revenue 2025 ($)", "arithmetic_fact", DOC, "2025 | 198,000 | 1,500,000")
sym("m25", "Real", "total Fenwick market sales revenue 2025 ($)", "arithmetic_fact", DOC, "2025 | 198,000 | 1,500,000")
sym("sh24", "Real", "Pellow market share 2024 (%)", "specialist_inference")
sym("sh25", "Real", "Pellow market share 2025 (%)", "specialist_inference")
sym("mg", "Real", "market growth 2024 to 2025 (%)", "specialist_inference")
sym("sg", "Real", "Pellow sales growth 2024 to 2025 (%)", "specialist_inference")
sym("gs", "Real", "share of the market increase captured by Pellow (%)", "specialist_inference")
sym("pah", "Real", "Option A probability of high demand", "arithmetic_fact", DOC, "Probability of high demand 0.6, with returns of $150,000")
sym("rah", "Real", "Option A return at high demand ($)", "arithmetic_fact", DOC, "Probability of high demand 0.6, with returns of $150,000")
sym("pal", "Real", "Option A probability of low demand", "arithmetic_fact", DOC, "probability of low demand 0.4, with returns of $40,000")
sym("ral", "Real", "Option A return at low demand ($)", "arithmetic_fact", DOC, "probability of low demand 0.4, with returns of $40,000")
sym("ca", "Real", "Option A cost ($)", "arithmetic_fact", DOC, "Cost: $60,000")
sym("pbh", "Real", "Option B probability of high demand", "arithmetic_fact", DOC, "Probability of high demand 0.5, with returns of $80,000")
sym("rbh", "Real", "Option B return at high demand ($)", "arithmetic_fact", DOC, "Probability of high demand 0.5, with returns of $80,000")
sym("pbm", "Real", "Option B probability of medium demand", "arithmetic_fact", DOC, "probability of medium demand 0.3, with returns of $50,000")
sym("rbm", "Real", "Option B return at medium demand ($)", "arithmetic_fact", DOC, "probability of medium demand 0.3, with returns of $50,000")
sym("pbl", "Real", "Option B probability of low demand", "arithmetic_fact", DOC, "probability of low demand 0.2, with returns of $20,000")
sym("rbl", "Real", "Option B return at low demand ($)", "arithmetic_fact", DOC, "probability of low demand 0.2, with returns of $20,000")
sym("cb", "Real", "Option B cost ($)", "arithmetic_fact", DOC, "Cost: $25,000")
sym("cc", "Real", "Option C cost ($)", "arithmetic_fact", DOC, "Option C: do nothing. Cost: $0; returns: $0.")
sym("sav", "Real", "Aled's savings ($)", "arithmetic_fact", DOC, "Aled has $30,000 in savings")
sym("eva", "Real", "Option A expected value ($)", "specialist_inference")
sym("evb", "Real", "Option B expected value ($)", "specialist_inference")
sym("neta", "Real", "Option A net gain ($)", "specialist_inference")
sym("netb", "Real", "Option B net gain ($)", "specialist_inference")
sym("netc", "Real", "Option C net gain ($)", "arithmetic_fact", DOC, "Option C: do nothing. Cost: $0; returns: $0.")
sym("wla", "Real", "Option A low-demand outcome, net of cost ($)", "specialist_inference")
sym("wlb", "Real", "Option B low-demand outcome, net of cost ($)", "specialist_inference")
sym("loana", "Real", "bank loan needed for Option A ($)", "specialist_inference")
sym("loanb", "Real", "bank loan needed for Option B ($)", "specialist_inference")
sym("pstar", "Real", "probability of high demand at which A and B have the same net gain", "specialist_inference")
sym("ngap", "Real", "net gain of A minus net gain of B ($)", "specialist_inference")
sym("cannot_confirm", "Bool", "the case cannot confirm that online retailers took Pellow's share", "specialist_inference")
sym("no_retail", "Bool", "the case gives no online retailer sales figures", "supplied_text", DOC, None)
sym("demand_grew", "Bool", "demand grew after the cycle path opened and online retailers began delivering", "supplied_text", DOC,
    "two online retailers now deliver bicycles to Fenwick")
sym("est_given", "Bool", "the returns are Aled's own estimates", "supplied_text", DOC,
    "The returns are his estimates for the next three years.")
sym("probs_est", "Bool", "the probabilities are Aled's own estimates", "specialist_inference", cert="probable")
sym("no_evid", "Bool", "the case gives no evidence for the probabilities and returns", "specialist_inference")
sym("tree_est", "Bool", "the decision tree depends on estimates", "specialist_inference")
sym("avg_hides", "Bool", "expected values hide the downside and the financing", "specialist_inference")
sym("int_out", "Bool", "interest on borrowed money is not in the tree", "specialist_inference")
sym("ranking_insec", "Bool", "the ranking of the options is not secure", "specialist_inference")
sym("benefit_stated", "Bool", "Carys thinks the van would bring new customers into the shop", "supplied_text", DOC,
    "She thinks the van would bring new customers into the shop")
sym("may_under", "Bool", "the tree may understate Option B", "specialist_inference")
sym("savings_only", "Bool", "Aled's savings are his only buffer", "specialist_inference")
sym("never_mgd", "Bool", "Aled has never managed staff in a second location", "supplied_text", DOC,
    "Aled has never managed staff in a second location.")
sym("demand_rising", "Bool", "demand for bicycle services is rising", "specialist_inference", cert="probable")
sym("rossby_gap", "Bool", "the case gives no information on Rossby's market", "supplied_text", DOC, None)
sym("rossby_grow", "Bool", "a shop in Rossby would also grow", "specialist_inference")
sym("cond", "Bool", "the Fenwick repairs can be covered and commuter and school demand is tested first", "specialist_inference")
sym("choose_b", "Bool", "Aled should choose Option B", "specialist_inference")
sym("demand_unp", "Bool", "demand from commuters and schools is not yet shown", "specialist_inference")
sym("test_first", "Bool", "Aled should test demand with a few bookings before buying the van", "specialist_inference")
sym("prot", "Bool", "protection from a smaller worst-case loss and no debt is worth more than the expected-value difference",
    "specialist_inference", cert="probable")

# ---- premises (shared) ----
pr("pa_s24", EQ(V("s24"), R("180000")), "Pellow sales revenue 2024 is $180,000", "arithmetic_fact", DOC, "2024 | 180,000 | 1,200,000")
pr("pa_m24", EQ(V("m24"), R("1200000")), "total market sales 2024 is $1,200,000", "arithmetic_fact", DOC, "2024 | 180,000 | 1,200,000")
pr("pa_s25", EQ(V("s25"), R("198000")), "Pellow sales revenue 2025 is $198,000", "arithmetic_fact", DOC, "2025 | 198,000 | 1,500,000")
pr("pa_m25", EQ(V("m25"), R("1500000")), "total market sales 2025 is $1,500,000", "arithmetic_fact", DOC, "2025 | 198,000 | 1,500,000")
pr("d_sh24", EQ(V("sh24"), DIV(MUL(R("100"), V("s24")), R("1200000"))), "market share 2024 = sales / market x 100", "specialist_inference")
pr("d_sh25", EQ(V("sh25"), DIV(MUL(R("100"), V("s25")), R("1500000"))), "market share 2025 = sales / market x 100", "specialist_inference")
pr("d_mg", EQ(V("mg"), DIV(MUL(R("100"), SUB(V("m25"), V("m24"))), R("1200000"))), "market growth = (2025 - 2024) / 2024 x 100", "specialist_inference")
pr("d_sg", EQ(V("sg"), DIV(MUL(R("100"), SUB(V("s25"), V("s24"))), R("180000"))), "sales growth = (2025 - 2024) / 2024 x 100", "specialist_inference")
pr("d_gs", EQ(V("gs"), DIV(MUL(R("100"), SUB(V("s25"), V("s24"))), R("300000"))), "share of market increase = Pellow gain / market gain x 100", "specialist_inference")
pr("d_gf", EQ(V("sh25"), MUL(R("0.88"), V("sh24"))), "growth-rate form: new share = old share x 1.10 / 1.25 = old share x 0.88", "specialist_inference")
pr("pa_pAh", EQ(V("pah"), R("0.6")), "Option A high-demand probability 0.6", "arithmetic_fact", DOC, "Probability of high demand 0.6, with returns of $150,000")
pr("pa_rAh", EQ(V("rah"), R("150000")), "Option A high-demand return $150,000", "arithmetic_fact", DOC, "Probability of high demand 0.6, with returns of $150,000")
pr("pa_pAl", EQ(V("pal"), R("0.4")), "Option A low-demand probability 0.4", "arithmetic_fact", DOC, "probability of low demand 0.4, with returns of $40,000")
pr("pa_rAl", EQ(V("ral"), R("40000")), "Option A low-demand return $40,000", "arithmetic_fact", DOC, "probability of low demand 0.4, with returns of $40,000")
pr("pa_cA", EQ(V("ca"), R("60000")), "Option A cost $60,000", "arithmetic_fact", DOC, "Cost: $60,000")
pr("pa_pBh", EQ(V("pbh"), R("0.5")), "Option B high-demand probability 0.5", "arithmetic_fact", DOC, "Probability of high demand 0.5, with returns of $80,000")
pr("pa_rBh", EQ(V("rbh"), R("80000")), "Option B high-demand return $80,000", "arithmetic_fact", DOC, "Probability of high demand 0.5, with returns of $80,000")
pr("pa_pBm", EQ(V("pbm"), R("0.3")), "Option B medium-demand probability 0.3", "arithmetic_fact", DOC, "probability of medium demand 0.3, with returns of $50,000")
pr("pa_rBm", EQ(V("rbm"), R("50000")), "Option B medium-demand return $50,000", "arithmetic_fact", DOC, "probability of medium demand 0.3, with returns of $50,000")
pr("pa_pBl", EQ(V("pbl"), R("0.2")), "Option B low-demand probability 0.2", "arithmetic_fact", DOC, "probability of low demand 0.2, with returns of $20,000")
pr("pa_rBl", EQ(V("rbl"), R("20000")), "Option B low-demand return $20,000", "arithmetic_fact", DOC, "probability of low demand 0.2, with returns of $20,000")
pr("pa_cB", EQ(V("cb"), R("25000")), "Option B cost $25,000", "arithmetic_fact", DOC, "Cost: $25,000")
pr("pa_cC", EQ(V("netc"), R("0")), "Option C has cost $0 and returns $0, so no gain", "arithmetic_fact", DOC, "Option C: do nothing. Cost: $0; returns: $0.")
pr("pa_sav", EQ(V("sav"), R("30000")), "Aled has $30,000 of savings", "arithmetic_fact", DOC, "Aled has $30,000 in savings")
pr("d_evA", EQ(V("eva"), ADD(MUL(V("pah"), R("150000")), MUL(V("pal"), R("40000")))), "expected value A = 0.6 x 150,000 + 0.4 x 40,000", "specialist_inference")
pr("d_evB", EQ(V("evb"), ADD(MUL(V("pbh"), R("80000")), MUL(V("pbm"), R("50000")), MUL(V("pbl"), R("20000")))), "expected value B = sum of probability x return", "specialist_inference")
pr("d_netA", EQ(V("neta"), SUB(V("eva"), V("ca"))), "net gain A = expected value A - cost A", "specialist_inference")
pr("d_netB", EQ(V("netb"), SUB(V("evb"), V("cb"))), "net gain B = expected value B - cost B", "specialist_inference")
pr("d_wlA", EQ(V("wla"), SUB(V("ral"), V("ca"))), "Option A low-demand outcome net of cost", "specialist_inference")
pr("d_wlB", EQ(V("wlb"), SUB(V("rbl"), V("cb"))), "Option B low-demand outcome net of cost", "specialist_inference")
pr("d_loanA", EQ(V("loana"), SUB(V("ca"), V("sav"))), "Option A borrowing = cost minus savings", "specialist_inference")
pr("d_loanB", EQ(V("loanb"), ITE(LE(V("cb"), V("sav")), R("0"), SUB(V("cb"), V("sav")))), "Option B borrowing is zero when savings cover the cost", "specialist_inference")
pr("d_pstar", EQ(V("pstar"), DIV(ADD(V("netb"), R("20000")), R("110000"))), "p at which 110,000p - 20,000 equals B's net gain", "specialist_inference")
pr("pa_netB", EQ(V("netb"), R("34000")), "net gain of B is $34,000", "specialist_inference")
pr("pa_netA", EQ(V("neta"), R("46000")), "net gain of A is $46,000", "specialist_inference")
pr("pa_evA", EQ(V("eva"), R("106000")), "expected value of A is $106,000", "specialist_inference")
pr("pa_evB", EQ(V("evb"), R("59000")), "expected value of B is $59,000", "specialist_inference")

C = {}
RID = "bm-t15"
C["g1.1@business-management-specialist"] = ENTRY(
    unsup="a stipulated assumption about how the returns are read; it draws no inference that could be checked",
    reading="Stipulated treatment of the returns as undiscounted three-year totals. No conclusion follows from it, so no entailment problem is formed.")

C["g2.1@business-management-specialist"] = PB("g2.1@business-management-specialist", "bm-g2.1", ["pa_s24", "pa_m24", "d_sh24"],
    AND(GE(V("sh24"), R("14.95")), LT(V("sh24"), R("15.05"))), "market share 2024 is 15.0% (one decimal place)",
    "Share 2024 = 180,000 / 1,200,000 x 100 = 15.0; stated to one decimal place, so the exact value lies in [14.95, 15.05).")

C["g3.1@business-management-specialist"] = PB("g3.1@business-management-specialist", "bm-g3.1", ["pa_s25", "pa_m25", "d_sh25"],
    AND(GE(V("sh25"), R("13.15")), LT(V("sh25"), R("13.25"))), "market share 2025 is 13.2% (one decimal place)",
    "Share 2025 = 198,000 / 1,500,000 x 100 = 13.2; stated to one decimal place.")

C["g4.1@business-management-specialist"] = PB("g4.1@business-management-specialist", "bm-g4.1",
    ["pa_m24", "pa_m25", "d_mg", "d_sh24", "d_sh25", "pa_s24", "pa_s25"],
    AND(GE(V("mg"), R("24.95")), LT(V("mg"), R("25.05"))), "market growth is 25.0% (one decimal place)",
    "Market growth from 1,200,000 to 1,500,000 is 25.0%, with the two supporting share claims as premises.")

C["g5.1@business-management-specialist"] = PB("g5.1@business-management-specialist", "bm-g5.1",
    ["pa_s24", "pa_s25", "pa_m24", "pa_m25", "d_sg", "d_mg", "d_sh24", "d_sh25"],
    AND(GE(V("sg"), R("9.95")), LT(V("sg"), R("10.05")), GE(V("mg"), R("24.95")), LT(V("mg"), R("25.05")),
        GE(V("sh24"), R("14.95")), LT(V("sh24"), R("15.05")), GE(V("sh25"), R("13.15")), LT(V("sh25"), R("13.25")),
        LT(V("sh25"), V("sh24"))),
    "sales rose 10.0%, the market grew 25.0%, and the share fell from 15.0% to 13.2%",
    "Sales growth 18,000 / 180,000 = 10.0%; market growth 25.0%; share falls from 15.0% to 13.2%, following from the stated figures.")

C["g5.2@business-management-specialist"] = PB("g5.2@business-management-specialist", "bm-g5.2",
    ["pa_s24", "pa_m24", "d_sh24", "d_gf"],
    EQ(V("sh25"), R("13.2")), "the 2025 share by the growth-rate form is 13.2",
    "Growth-rate form: new share = old share x (1 + sales growth) / (1 + market growth) = 15.0 x 1.10 / 1.25 = 13.2.")

C["g5.3@business-management-specialist"] = PB("g5.3@business-management-specialist", "bm-g5.3",
    ["demand_grew_p"],
    V("demand_grew"), "demand grew after the cycle path opened and online retailers began delivering",
    "The case says cycling became more popular after the 2024 cycle path and that two online retailers now deliver to Fenwick; the claim's reading is that demand grew.") \
    if False else None
# the g5.3 claim is interpretive; encoded with the case fact as the conclusion
C["g5.3@business-management-specialist"] = ENTRY(problem=PROBLEM("p-bm-g5.3", REQ, "g5.3@business-management-specialist", S,
    [P("pr_demand", V("demand_grew"), "the case reports the rise and the new retailers", "supplied_text", DOC,
       "two online retailers now deliver bicycles to Fenwick")],
    P("concl", V("demand_grew"), "demand grew after the cycle path opened and online retailers began delivering")),
    reading="Stated in the case: the cycle path opened in 2024 and two online retailers now deliver to Fenwick. Encoded as a supplied-text fact; the growth reading is the market growth already checked in g4.1.")

C["g5.4@business-management-specialist"] = PB("g5.4@business-management-specialist", "bm-g5.4",
    ["pa_s24", "pa_s25", "pa_m24", "pa_m25", "d_gs"],
    AND(GE(V("gs"), R("5.95")), LT(V("gs"), R("6.05"))), "Pellow gained 6.0% of the market increase",
    "Pellow's gain of 18,000 out of the 300,000 market increase is 6.0% (one decimal place).")

C["g5.5@business-management-specialist"] = ENTRY(problem=PROBLEM("p-bm-g5.5", REQ, "g5.5@business-management-specialist", S,
    [P("pr_norail", V("no_retail"), "the case gives no online retailer sales figures", "supplied_text", DOC, None),
     P("pr_link", IMP(V("no_retail"), V("cannot_confirm")), "without those sales figures the case cannot confirm the share", "specialist_inference")],
    P("concl", V("cannot_confirm"), "the case cannot confirm that online retailers took Pellow's share")),
    reading="The case lists no online retailer sales, so it cannot confirm that they took Pellow's share.")

C["g6.2@business-management-specialist"] = PB("g6.2@business-management-specialist", "bm-g6.2",
    ["pa_pAh", "pa_rAh", "pa_pAl", "pa_rAl", "d_evA"],
    EQ(V("eva"), R("106000")), "expected value of Option A is $106,000",
    "Expected value A = (0.6 x 150,000) + (0.4 x 40,000) = 106,000.")

C["g6.3@business-management-specialist"] = PB("g6.3@business-management-specialist", "bm-g6.3",
    ["pa_cA", "d_evA", "d_netA", "pa_evA"],
    EQ(V("neta"), R("46000")), "net gain of Option A is $46,000",
    "Net gain A = expected value 106,000 - cost 60,000 = 46,000.")

C["g7.2@business-management-specialist"] = PB("g7.2@business-management-specialist", "bm-g7.2",
    ["pa_pBh", "pa_rBh", "pa_pBm", "pa_rBm", "pa_pBl", "pa_rBl", "d_evB"],
    EQ(V("evb"), R("59000")), "expected value of Option B is $59,000",
    "Expected value B = (0.5 x 80,000) + (0.3 x 50,000) + (0.2 x 20,000) = 59,000.")

C["g7.3@business-management-specialist"] = PB("g7.3@business-management-specialist", "bm-g7.3",
    ["pa_cB", "d_netB", "pa_evB"],
    EQ(V("netb"), R("34000")), "net gain of Option B is $34,000",
    "Net gain B = 59,000 - 25,000 = 34,000.")

C["g8.1@business-management-specialist"] = ENTRY(problem=PROBLEM("p-bm-g8.1", REQ, "g8.1@business-management-specialist", S,
    [P("pr_est", V("est_given"), "the returns are his estimates for the next three years", "supplied_text", DOC,
       "The returns are his estimates for the next three years."),
     P("pr_probs", V("probs_est"), "the probabilities are also Aled's own estimates", "specialist_inference", cert="probable"),
     P("pr_noev", IMP(AND(V("est_given"), V("probs_est")), V("no_evid")), "estimates given with no supporting evidence", "specialist_inference"),
     P("pr_tree", IMP(V("no_evid"), V("tree_est")), "a tree built on unevidenced estimates depends on them", "specialist_inference")],
    P("concl", V("tree_est"), "the decision tree depends on estimates")),
    reading="The tree depends on estimates: the returns are stated as Aled's estimates, the probabilities are his too, and the case gives no evidence for them.")

C["g8.2@business-management-specialist"] = ENTRY(problem=PROBLEM("p-bm-g8.2", REQ, "g8.2@business-management-specialist", S,
    [P("pr_est", V("est_given"), "the returns are his estimates for the next three years", "supplied_text", DOC,
       "The returns are his estimates for the next three years."),
     P("pr_probs", V("probs_est"), "the probabilities are also Aled's own estimates", "specialist_inference", cert="probable")],
    P("concl", V("no_evid"), "the case gives no evidence for the probabilities and returns")),
    reading="The returns are stated as Aled's estimates and the probabilities are his judgement; the claim that the case gives no evidence for them is not derivable from the case text and is left as the open conclusion.")

C["g8.3@business-management-specialist"] = PB("g8.3@business-management-specialist", "bm-g8.3",
    ["pa_netB", "d_pstar"],
    AND(GE(V("pstar"), R("0.485")), LT(V("pstar"), R("0.495"))),
    "the two options have the same net gain when the probability of high demand is about 0.49",
    "A's net gain is 110,000p - 20,000 (p = probability of high demand); it equals B's 34,000 at p = 54,000 / 110,000 = 0.4909, read as about 0.49.",
    ambiguous=True,
    flags=[("approximate_figure", "'about 0.49' has no stated precision; encoded at two decimal places as [0.485, 0.495)",
            ["p equal to 0.49 exactly", "p to two decimal places"])])

C["g8.4@business-management-specialist"] = ENTRY(problem=PROBLEM("p-bm-g8.4", REQ, "g8.4@business-management-specialist", S,
    [PR["pa_netB"],
     P("pr_rank", IMP(LT(SUB(MUL(R("110000"), R("0.49")), R("20000")), V("netb")), V("ranking_insec")),
       "if A at p = 0.49 falls below B, the ranking is not secure", "specialist_inference")],
    P("concl", AND(EQ(SUB(R("0.6"), R("0.49")), R("0.11")),
                   LT(SUB(MUL(R("110000"), R("0.49")), R("20000")), V("netb")),
                   V("ranking_insec")),
      "a fall of about 0.11 from 0.6 to 0.49 makes B the better choice, so the ranking is not secure")),
    reading="At p = 0.49, A's net gain is 110,000 x 0.49 - 20,000 = 33,900, below B's 34,000; the fall from 0.6 is 0.11; the ranking is therefore not secure.",
    ambiguous=True,
    flags=[("approximate_figure", "'about 0.11' and 'about 0.49' have no stated precision; the figures 0.6 and 0.49 are encoded exactly",
            ["p equal to 0.49 exactly", "p to two decimal places"])])

C["g9.1@business-management-specialist"] = ENTRY(problem=PROBLEM("p-bm-g9.1", REQ, "g9.1@business-management-specialist", S,
    [P("pr_g92", AND(EQ(SUB(V("ral"), V("ca")), R("-20000")), EQ(V("pal"), R("0.4"))),
       "Option A's low-demand outcome is 20,000 short of cost, with probability 0.4", "arithmetic_fact", DOC,
       "probability of low demand 0.4, with returns of $40,000"),
     P("pr_g93", AND(EQ(DIV(R("30000"), R("60000")), R("0.5")), V("int_out")),
       "savings cover half the cost and the interest is not in the tree", "specialist_inference"),
     P("pr_avg", IMP(V("int_out"), V("avg_hides")), "averaging hides the downside and the financing", "specialist_inference")],
    P("concl", V("avg_hides"), "expected values average the outcomes and hide the downside and the financing")),
    reading="Expected values hide a 20,000 shortfall at 40% probability and the financing (half the cost borrowed, interest outside the tree).")

C["g9.2@business-management-specialist"] = PB("g9.2@business-management-specialist", "bm-g9.2",
    ["pa_rAl", "pa_cA", "pa_pAl"],
    EQ(SUB(V("ral"), V("ca")), R("-20000")), "Option A's low-demand outcome is 20,000 short of the 60,000 cost",
    "Returns of 40,000 fall 20,000 short of the 60,000 cost, at probability 0.4 (stated in the claim).")

C["g9.3@business-management-specialist"] = PB("g9.3@business-management-specialist", "bm-g9.3",
    ["pa_sav", "pa_cA", "d_loanA"],
    AND(EQ(V("loana"), R("30000")), V("int_out")),
    "a 30,000 loan is needed and its interest is not in the tree",
    "Savings of 30,000 cover half of the 60,000 cost; the other 30,000 is borrowed, with interest outside the tree.")

C["g10.1@business-management-specialist"] = ENTRY(problem=PROBLEM("p-bm-g10.1", REQ, "g10.1@business-management-specialist", S,
    [PR["pa_netB"], PR["pa_netA"], PR["pa_cB"], PR["pa_sav"], PR["d_wlA"], PR["d_wlB"],
     P("pr_worst", AND(LT(V("wlb"), V("wla")), LE(V("cb"), V("sav"))), "B has a smaller worst-case loss and needs no debt", "specialist_inference"),
     P("pr_choose", IMP(AND(LT(V("wlb"), V("wla")), LE(V("cb"), V("sav"))), V("choose_b")),
       "a smaller worst-case loss and no debt favour choosing B", "specialist_inference"),
     P("pr_prot", IMP(AND(V("savings_only"), V("ranking_insec")), V("prot")),
       "protection outweighs the expected-value gap when savings are the only buffer and the ranking is insecure", "specialist_inference", cert="probable"),
     P("pr_so", V("savings_only"), "Aled's savings are his only buffer", "specialist_inference")],
    P("concl", IMP(V("cond"), V("choose_b")),
      "Aled should choose B on condition that the Fenwick repairs are covered and demand is tested")),
    reading="B is chosen on risk grounds (smaller worst-case loss, no debt); the recommendation is conditional on the Fenwick repairs and demand tests, encoded as cond implies choose_b.")

C["g11.1@business-management-specialist"] = PB("g11.1@business-management-specialist", "bm-g11.1",
    ["pa_netA", "pa_netB", "pa_rAh", "pa_rBh"],
    AND(GT(V("neta"), V("netb")), GT(V("rah"), V("rbh"))),
    "Option A has the higher expected net gain (46,000 against 34,000) and its high-demand return is larger than B's",
    "Net gains 46,000 (A) and 34,000 (B); A's high-demand return 150,000 exceeds B's 80,000.")

C["g11.2@business-management-specialist"] = PB("g11.2@business-management-specialist", "bm-g11.2",
    ["pa_netA", "pa_netB"],
    AND(GT(V("neta"), V("netb")), EQ(SUB(V("neta"), V("netb")), R("12000"))),
    "on the tree alone A is better, and the 12,000 difference is real",
    "On the tree alone A's net gain exceeds B's by 12,000.")

C["g12.2@business-management-specialist"] = ENTRY(problem=PROBLEM("p-bm-g12.2", REQ, "g12.2@business-management-specialist", S,
    [PR["pa_m24"], PR["pa_m25"], PR["d_mg"],
     P("pr_grow", IMP(GT(V("mg"), R("0")), V("demand_rising")),
       "market growth suggests that demand for bicycle services is rising", "specialist_inference", cert="probable")],
    P("concl", AND(V("demand_rising"), GE(V("mg"), R("24.95")), LT(V("mg"), R("25.05"))),
      "the market grew 25.0%, which suggests demand is rising")),
    reading="The market grew by 25.0%, which the specialist reads (probable) as rising demand for bicycle services.")

C["g12.3@business-management-specialist"] = ENTRY(problem=PROBLEM("p-bm-g12.3", REQ, "g12.3@business-management-specialist", S,
    [P("pr_gap", V("rossby_gap"), "the case gives no information on Rossby's market", "supplied_text", DOC, None),
     P("pr_nolink", IMP(V("rossby_gap"), NOT(V("rossby_grow"))),
       "without Rossby data, Fenwick growth does not show that a Rossby shop would grow", "specialist_inference")],
    P("concl", NOT(V("rossby_grow")), "Fenwick growth does not show that a Rossby shop would also grow")),
    reading="The case gives no Rossby market data, so Fenwick growth does not show that a Rossby shop would grow.")

C["g12.4@business-management-specialist"] = PB("g12.4@business-management-specialist", "bm-g12.4",
    ["pa_cA", "pa_sav", "d_loanA"],
    AND(EQ(V("loana"), R("30000")), V("int_out")),
    "Option A needs a 30,000 loan, with interest the case does not give",
    "Cost 60,000 less savings 30,000 gives a 30,000 loan; the interest is not given in the case.")

C["g12.5@business-management-specialist"] = ENTRY(problem=PROBLEM("p-bm-g12.5", REQ, "g12.5@business-management-specialist", S,
    [PR["pa_rAl"], PR["pa_cA"], PR["d_wlA"]],
    P("concl", EQ(V("wla"), R("-20000")), "in the low-demand outcome A loses 20,000")),
    reading="Option A's low-demand outcome nets -20,000. The second part, that Aled has never managed staff in a second location, is a verbatim case fact and is not repeated in the conclusion.")

C["g13.2@business-management-specialist"] = PB("g13.2@business-management-specialist", "bm-g13.2",
    ["pa_cB", "pa_sav", "d_loanB"],
    AND(LE(V("cb"), V("sav")), EQ(V("loanb"), R("0"))),
    "B's 25,000 cost is covered by savings, so no loan and no interest",
    "B's cost of 25,000 is within savings of 30,000, so the loan is zero.")

C["g13.3@business-management-specialist"] = PB("g13.3@business-management-specialist", "bm-g13.3",
    ["pa_rBl", "pa_cB", "pa_pBl", "pa_rAl", "pa_cA", "pa_pAl", "d_wlA", "d_wlB"],
    AND(EQ(V("wlb"), R("-5000")), EQ(V("wla"), R("-20000"))),
    "B's worst outcome is a loss of 5,000 (probability 0.2); A's is a loss of 20,000 (probability 0.4)",
    "Worst outcomes: B loses 5,000 at probability 0.2; A loses 20,000 at probability 0.4 (probabilities are premises).")

C["g13.4@business-management-specialist"] = ENTRY(problem=PROBLEM("p-bm-g13.4", REQ, "g13.4@business-management-specialist", S,
    [P("pr_ben", V("benefit_stated"), "Carys thinks the van would bring new customers into the shop", "supplied_text", DOC,
       "She thinks the van would bring new customers into the shop"),
     P("pr_notree", IMP(V("benefit_stated"), V("may_under")),
       "a benefit the tree does not count means the tree may understate B", "specialist_inference")],
    P("concl", V("may_under"), "the tree may understate Option B")),
    reading="Carys's view of new customers is stated in the case and the tree does not count it, so the tree may understate Option B.")

C["g14.2@business-management-specialist"] = PB("g14.2@business-management-specialist", "bm-g14.2",
    ["pa_netA", "pa_netB", "pa_sav", "pa_cB", "d_wlA", "d_wlB"],
    AND(EQ(SUB(V("neta"), V("netb")), R("12000")), GT(V("wlb"), V("wla")), LE(V("cb"), V("sav"))),
    "B gives up 12,000 of expected gain for a smaller worst-case loss and no debt",
    "B's expected gain is 12,000 lower; its worst-case net (-5,000) is smaller in loss than A's (-20,000); no debt is needed.")

C["g14.3@business-management-specialist"] = ENTRY(problem=PROBLEM("p-bm-g14.3", REQ, "g14.3@business-management-specialist", S,
    [P("pr_so", V("savings_only"), "Aled's savings are his only buffer", "specialist_inference"),
     P("pr_rr", V("ranking_insec"), "the ranking reverses if the high-demand probability falls to about 0.49", "specialist_inference"),
     P("pr_prot", IMP(AND(V("savings_only"), V("ranking_insec")), V("prot")),
       "protection is worth more than the expected-value difference for a sole trader with only savings", "specialist_inference", cert="probable")],
    P("concl", V("prot"), "for a sole trader whose savings are his only buffer, protection is worth more than the expected-value difference")),
    reading="A value judgement at probable certainty: where savings are the only buffer and the ranking can reverse, the protection outweighs the expected-value difference.")

C["g14.4@business-management-specialist"] = PB("g14.4@business-management-specialist", "bm-g14.4",
    ["pa_cC", "pa_netB"],
    GT(V("netb"), V("netc")), "Option C gives no gain, so B is preferred to C on these estimates",
    "Option C has zero net gain; B's net gain of 34,000 exceeds it.")

C["g15.3@business-management-specialist"] = ENTRY(problem=PROBLEM("p-bm-g15.3", REQ, "g15.3@business-management-specialist", S,
    [P("pr_dem", V("demand_unp"), "the case does not show that commuters and schools book enough work", "specialist_inference"),
     P("pr_test", IMP(V("demand_unp"), V("test_first")), "unproven demand means Aled should test it before buying the van", "specialist_inference")],
    P("concl", V("test_first"), "Aled should test demand with a few bookings before buying the van")),
    reading="Demand from commuters and schools is not yet shown, so Aled should test it with bookings before buying the van.")

DUMP(RID, "rep-bm-t15-0", C)
