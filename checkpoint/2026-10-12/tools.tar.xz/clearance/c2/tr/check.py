import json, sys
task = sys.argv[1]
lst = json.load(open(f"{sys.argv[2]}/listings/{task}.listing.json"))
out = json.load(open(f"/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2/revision-translations/{task}.json"))
ids = [c["claim_id"] for c in lst["claims"] if c.get("eligible")]
missing = [i for i in ids if i not in out["claims"]]
extra = [i for i in out["claims"] if i not in ids]
print("claims", len(ids), "missing", missing, "extra", extra, "report_id ok", out["report_id"] == lst["report_id"])
