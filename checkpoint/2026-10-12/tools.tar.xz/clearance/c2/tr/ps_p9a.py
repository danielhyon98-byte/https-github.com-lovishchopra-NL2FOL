import sys
sys.path.insert(0, "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2/tr")
from ir import *

REQ = "req-p9a"
S = {}


def sym(name, sort, meaning, kind=None, cert="established"):
    S[name] = SYM(name, sort, meaning, kind, None, None, cert)


def P2(pid, expr, label, kind=None, cert="established"):
    return P(pid, expr, label, kind, None, None, cert)


sym("mailing", "Real", "people on the mailing list", "task_setting")
sym("answered", "Real", "people who answered the survey", "task_setting")
sym("nonresp", "Real", "people on the list who did not answer the survey", "arithmetic_fact")
sym("small_req", "Bool", "answering a free one-question survey is a small request", "task_setting")
sym("commit_cons", "Bool", "people want to keep their commitments consistent", "general_knowledge", "probable")
sym("foot_door", "Bool", "foot-in-the-door works here", "specialist_inference", "probable")
sym("self_care", "Bool", "answering the survey leads respondents to see themselves as people who care", "specialist_inference", "probable")
sym("nr_nocommit", "Bool", "non-respondents made no earlier commitment", "specialist_inference")
sym("nr_nocons", "Bool", "the larger request has nothing for non-respondents to be consistent with", "specialist_inference")
sym("p1", "Real", "percentage of respondents who became Friends (228 of 1200)", "arithmetic_fact")
sym("p2", "Real", "percentage of non-respondents who became Friends (54 of 1800)", "arithmetic_fact")
sym("pdiff", "Real", "difference between the two percentages (percentage points)", "arithmetic_fact")
sym("stated912", "Bool", "the email states that 912 people in Callowfield are already Friends", "assumption")
sym("shows_many", "Bool", "the figure shows readers what many others have done", "specialist_inference", "probable")
sym("unsure", "Bool", "a reader is unsure whether 4 pounds a month is a good use of money", "specialist_inference")
sym("info_inf", "Bool", "informational influence applies", "specialist_inference", "probable")
sym("wants_belong", "Bool", "readers want to belong to the group that supports the theatre", "general_knowledge", "probable")
sym("norm_inf", "Bool", "normative influence applies", "specialist_inference", "probable")
sym("sent_all", "Bool", "the second email went to every person on the list", "task_setting")
sym("pressure_nr", "Bool", "the pressure reached the non-respondents", "specialist_inference")
sym("mailing_n", "Real", "list size", "task_setting")

pr = {}
for pid, e, lab, k in [
    ("pa_mail", EQ(V("mailing"), R("3000")), "the mailing list has 3000 people (question)", "task_setting"),
    ("pa_ans", EQ(V("answered"), R("1200")), "1,200 people answered the survey (question)", "task_setting"),
    ("d_nr", EQ(V("nonresp"), SUB(V("mailing"), V("answered"))), "non-respondents = list - respondents", "arithmetic_fact"),
    ("d_p1", EQ(V("p1"), DIV(MUL(R("100"), R("228")), R("1200"))), "228 of 1200 as a percentage", "arithmetic_fact"),
    ("d_p2", EQ(V("p2"), DIV(MUL(R("100"), R("54")), R("1800"))), "54 of 1800 as a percentage", "arithmetic_fact"),
    ("d_pdiff", EQ(V("pdiff"), SUB(V("p1"), V("p2"))), "difference in percentage points", "arithmetic_fact"),
]:
    P_ = P2(pid, e, lab, k)
    pr[pid] = P_

C = {}
C["g1.1@psychology-specialist"] = ENTRY(unsup="an assumption about the marking format of the answer; it draws no inference that could be checked",
                                       reading="Assumption about the format and length of the answer; no inference to check.")

C["g2.1@psychology-specialist"] = ENTRY(problem=PROBLEM("p-ps-g2.1", REQ, "g2.1@psychology-specialist", S,
    [P2("pr_sr", V("small_req"), "answering the free survey was a small request", "task_setting"),
     P2("pr_cc", V("commit_cons"), "people want to keep their commitments consistent", "general_knowledge", "probable"),
     P2("pr_ff", IMP(AND(V("small_req"), V("commit_cons")), V("foot_door")), "a small agreement becomes a commitment that people keep consistent, so foot-in-the-door works", "specialist_inference", "probable")],
    P2("concl", V("foot_door"), "foot-in-the-door works because a small agreement becomes a commitment that people want to keep consistent", None, "probable")),
    reading="The mechanism: a small free agreement (task) plus the consistency principle (general knowledge, probable) gives foot-in-the-door working (probable).")

C["g2.2@psychology-specialist"] = ENTRY(problem=PROBLEM("p-ps-g2.2", REQ, "g2.2@psychology-specialist", S,
    [P2("pr_sr", V("small_req"), "answering the free survey was a small request", "task_setting"),
     P2("pr_ss", IMP(V("small_req"), V("self_care")), "the small agreement makes respondents see themselves as people who care", "specialist_inference", "probable"),
     P2("pr_an", EQ(V("answered"), R("1200")), "1,200 respondents agreed", "task_setting")],
    P2("concl", V("self_care"), "the 1,200 respondents began to see themselves as people who care about the Kestrel", None, "probable")),
    reading="The 1,200 respondents agreed to a free small request; the specialist's link to self-image is probable.")

C["g2.5@psychology-specialist"] = ENTRY(problem=PROBLEM("p-ps-g2.5", REQ, "g2.5@psychology-specialist", S,
    [pr["pa_mail"], pr["pa_ans"], pr["d_nr"],
     P2("pr_nc", V("nr_nocommit"), "the non-respondents made no earlier commitment", "specialist_inference"),
     P2("pr_nn", IMP(V("nr_nocommit"), V("nr_nocons")), "with no earlier commitment there is nothing to be consistent with", "specialist_inference")],
    P2("concl", AND(EQ(V("nonresp"), R("1800")), V("nr_nocons")), "non-respondents made no earlier commitment, so the larger request had nothing to be consistent with")),
    reading="1,800 people on the list did not answer (3000 - 1200), and they made no earlier commitment, so the larger request has nothing for them to be consistent with.")

C["g2.6@psychology-specialist"] = ENTRY(problem=PROBLEM("p-ps-g2.6", REQ, "g2.6@psychology-specialist", S,
    [pr["d_p1"], pr["d_p2"], pr["d_pdiff"]],
    P2("concl", AND(GE(V("p1"), R("18.5")), LT(V("p1"), R("19.5")), GE(V("p2"), R("2.5")), LT(V("p2"), R("3.5")),
                    GE(V("pdiff"), R("15.5")), LT(V("pdiff"), R("16.5"))),
       "228 of 1,200 (19%) and 54 of 1,800 (3%) differ by 16 percentage points (stated to the nearest whole number)")),
    reading="The arithmetic: 228/1200 = 19.0%, 54/1800 = 3.0%, difference 16.0 percentage points; each figure is stated to the nearest whole number. The causal reading (provided the groups are alike) is not encoded, as the scenario does not establish it.")

C["g3.1@psychology-specialist"] = ENTRY(problem=PROBLEM("p-ps-g3.1", REQ, "g3.1@psychology-specialist", S,
    [P2("pr_st", V("stated912"), "the email states that 912 people in Callowfield are already Friends", "assumption"),
     P2("pr_sh", IMP(V("stated912"), V("shows_many")), "the figure shows readers what many others have done", "specialist_inference", "probable")],
    P2("concl", V("shows_many"), "telling readers about 912 existing Friends shows them what many others have done", None, "probable")),
    reading="The email's statement of 912 Friends (not verifiable against a supplied text) shows readers what many others have done (probable). The definition of conformity is not separately encoded.",
    )

C["g3.2@psychology-specialist"] = ENTRY(problem=PROBLEM("p-ps-g3.2", REQ, "g3.2@psychology-specialist", S,
    [P2("pr_st", V("stated912"), "the email states that 912 people are already Friends", "assumption"),
     P2("pr_un", V("unsure"), "a reader is unsure whether 4 pounds a month is a good use of money", "specialist_inference"),
     P2("pr_ii", IMP(AND(V("unsure"), V("stated912")), V("info_inf")), "the choices of 912 people count as evidence", "specialist_inference", "probable")],
    P2("concl", V("info_inf"), "informational influence applies", None, "probable")),
    reading="A reader who is unsure may treat the choices of 912 people as evidence, so informational influence applies (probable).")

C["g3.3@psychology-specialist"] = ENTRY(problem=PROBLEM("p-ps-g3.3", REQ, "g3.3@psychology-specialist", S,
    [P2("pr_st", V("stated912"), "the email states that 912 people are already Friends", "assumption"),
     P2("pr_wb", V("wants_belong"), "readers want to belong to the group that supports the theatre", "general_knowledge", "probable"),
     P2("pr_ni", IMP(AND(V("wants_belong"), V("stated912")), V("norm_inf")), "joining the group that looks large and typical satisfies that wish", "specialist_inference", "probable")],
    P2("concl", V("norm_inf"), "normative influence applies", None, "probable")),
    reading="Readers' wish to belong (general knowledge) and the large, typical group the figure shows give normative influence (probable).")

C["g3.4@psychology-specialist"] = ENTRY(problem=PROBLEM("p-ps-g3.4", REQ, "g3.4@psychology-specialist", S,
    [pr["pa_mail"], pr["pa_ans"], pr["d_nr"],
     P2("pr_sa", V("sent_all"), "the second email went to every person on the list", "task_setting"),
     P2("pr_pr", IMP(V("sent_all"), V("pressure_nr")), "a message sent to all reaches the non-respondents too", "specialist_inference")],
    P2("concl", AND(EQ(V("nonresp"), R("1800")), V("pressure_nr")), "the pressure reached the 1,800 people who had not answered the survey as well as the 1,200 who had")),
    reading="Every reader received the second email, so the pressure reached the 1,800 non-respondents (3000 - 1200) as well as the 1,200 respondents.")

DUMP("ps-p9a", "rep-ps-p9a-0", C)
