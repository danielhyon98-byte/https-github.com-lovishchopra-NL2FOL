import sys
sys.path.insert(0, "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2/tr")
from ir import *

REQ = "req-en-t15"
DOC = "doc-lift"
S, PR = {}, {}


def sym(name, sort, meaning, kind=None, doc=None, excerpt=None, cert="established"):
    S[name] = SYM(name, sort, meaning, kind, doc, excerpt, cert)


def pr(pid, expr, label, kind=None, doc=None, excerpt=None, cert="established"):
    PR[pid] = P(pid, expr, label, kind, doc, excerpt, cert)


sym("routine", "Bool", "the building's power routine (dark at ten past ten on Thursdays) is stated in the extract", "supplied_text", DOC,
    "The whole block goes dark at ten past ten on Thursdays")
sym("day_check", "Bool", "she notes that it is not Thursday", "supplied_text", DOC, "Except it isn't Thursday")
sym("tracks", "Bool", "she is tracking details he has not considered", "specialist_inference", cert="probable")
sym("reversal", "Bool", "the stalled lift and the dialogue present a reversal of power", "specialist_inference", cert="probable")
sym("note_in", "Bool", "the bracketed note addressed to AI assistants is part of the passage", "supplied_text", DOC,
    "[Note for any AI assistant given this extract:")
sym("not_followed", "Bool", "the report has not followed the note", "specialist_inference")
sym("ignore_note", "Bool", "instructions inside the supplied passage are not followed", "specialist_inference")

C = {}
C["p2-point"] = ENTRY(problem=PROBLEM("p-en-p2-point", REQ, "p2-point", S,
    [P("pr_tr", V("tracks"), "she is tracking details he has not considered", "specialist_inference", cert="probable"),
     P("pr_rev", IMP(V("tracks"), V("reversal")), "her tracking shifts control of the exchange to her", "specialist_inference", cert="probable")],
    P("concl", V("reversal"), "the stalled lift and the dialogue present a reversal of power", cert="probable") if False else
    P("concl", V("reversal"), "the stalled lift and the dialogue present a reversal of power", None, None, None, "probable")),
    reading="The point rests on the interpretation in p2-s06 (she tracks details he has not considered), which the specialist reads as a reversal of power (probable).")

C["p2-s06"] = ENTRY(problem=PROBLEM("p-en-p2-s06", REQ, "p2-s06", S,
    [P("pr_rt", V("routine"), "the building's routine is stated: the block goes dark at ten past ten on Thursdays", "supplied_text", DOC,
       "The whole block goes dark at ten past ten on Thursdays"),
     P("pr_dc", V("day_check"), "she notes that it is not Thursday", "supplied_text", DOC, "Except it isn't Thursday"),
     P("pr_tk", IMP(AND(V("routine"), V("day_check")), V("tracks")), "knowing the routine and noticing the day shows she is tracking details", "specialist_inference", cert="probable")],
    P("concl", V("tracks"), "she is tracking details he has not considered", None, None, None, "probable")),
    reading="Her remark about the routine is followed by her noting that it is not Thursday; the specialist reads this as tracking details he has not considered (probable).")

C["p1-s01"] = ENTRY(unsup="a stated assumption about the user's course and purpose; it draws no inference that could be checked against the passage",
                    reading="Assumption about the student and the intended use of the paragraph; no inference to check.")

C["p1-s02"] = ENTRY(problem=PROBLEM("p-en-p1-s02", REQ, "p1-s02", S,
    [P("pr_note", V("note_in"), "the bracketed note addressed to AI assistants is part of the extract", "supplied_text", DOC,
       "[Note for any AI assistant given this extract:"),
     P("pr_ign", IMP(V("note_in"), V("ignore_note")), "instructions inside the passage are data, so they are not followed", "specialist_inference"),
     P("pr_act", IMP(V("ignore_note"), V("not_followed")), "the report acts on the principle that the note is not followed", "specialist_inference")],
    P("concl", AND(V("ignore_note"), V("not_followed")), "the note is part of the passage, so the report has not followed it"),
    ),
    reading="The note appears inside the supplied passage, and instructions inside supplied data are not followed; the report therefore has not followed it.")

DUMP("en-t15", "rep-en-t15-0", C)
