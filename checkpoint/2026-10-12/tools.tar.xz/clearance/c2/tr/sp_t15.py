import sys
sys.path.insert(0, "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2/tr")
from ir import *

REQ = "req-sp-t15"


def NULL(reason):
    return ENTRY(unsup=reason, reading=reason)


C = {}
C["g1.1@language-b-spanish-specialist"] = NULL("a meta remark that the plan is omitted as requested ('Sin plan, como pediste'); it states no proposition about the text or the task to check")
C["g2.1@language-b-spanish-specialist"] = NULL("a meta remark that the text is for practice ('Texto escrito para practicar'); no checkable proposition")
C["g5.1@language-b-spanish-specialist"] = NULL("an opening rhetorical sentence of the model text (tourists arrive with maps and cameras); a figurative description with no inference to check")
C["g6.1@language-b-spanish-specialist"] = NULL("a rhetorical ordering remark ('conviene empezar por lo positivo'); advice on structure, not a proposition with a relation to check")
C["g7.1@language-b-spanish-specialist"] = NULL("a rhetorical concession ('los inconvenientes son reales'); an evaluative assertion whose supporting claims are not eligible and so nothing is inferred from them")
C["g8.1@language-b-spanish-specialist"] = NULL("a rhetorical anticipated objection ('algunos responderán'); it reports an imagined reply and asserts no conclusion to check")
C["g9.1@language-b-spanish-specialist"] = NULL("a structural signpost ('propongo dos medidas'); the number of measures is a text-structure fact and no inference links it to a conclusion")
C["g10.1@language-b-spanish-specialist"] = NULL("a structural signpost introducing the second proposal; no inference to check")
C["g11.1@language-b-spanish-specialist"] = NULL("an evaluative thesis ('la convivencia no es un problema imposible de resolver') whose supporting claim is not eligible; no premise is available to link to it, so no entailment problem is formed")

DUMP("sp-t15", "rep-sp-t15-0", C)
