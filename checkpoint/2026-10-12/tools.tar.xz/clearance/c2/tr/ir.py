"""Helpers that write Epinoic IR 1.0 JSON objects (translation provider scratch module)."""
import json
import os
import re

OUT_DIR = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2/revision-translations"


def V(n):
    return {"op": "var", "name": n}


def B(v):
    return {"op": "bool", "value": bool(v)}


def R(s):
    return {"op": "real", "value": str(s)}


def AND(*a):
    return {"op": "and", "args": list(a)}


def OR(*a):
    return {"op": "or", "args": list(a)}


def NOT(a):
    return {"op": "not", "arg": a}


def IMP(l, r):
    return {"op": "implies", "left": l, "right": r}


def IFF(l, r):
    return {"op": "iff", "left": l, "right": r}


def ITE(c, t, o):
    return {"op": "ite", "cond": c, "then": t, "otherwise": o}


def ADD(*a):
    return {"op": "add", "args": list(a)}


def MUL(*a):
    return {"op": "mul", "args": list(a)}


def SUB(l, r):
    return {"op": "sub", "left": l, "right": r}


def NEG(a):
    return {"op": "neg", "arg": a}


def DIV(l, r):
    return {"op": "div", "left": l, "right": r}


def EQ(l, r):
    return {"op": "eq", "left": l, "right": r}


def NE(l, r):
    return {"op": "ne", "left": l, "right": r}


def LT(l, r):
    return {"op": "lt", "left": l, "right": r}


def LE(l, r):
    return {"op": "le", "left": l, "right": r}


def GT(l, r):
    return {"op": "gt", "left": l, "right": r}


def GE(l, r):
    return {"op": "ge", "left": l, "right": r}


def G(kind, doc=None, excerpt=None, cert="established", note=None):
    g = {"kind": kind, "source_refs": [], "certainty": cert}
    if doc:
        sr = {"document_id": doc}
        if excerpt:
            sr["excerpt"] = excerpt
        g["source_refs"] = [sr]
    if note:
        g["note"] = note
    return g


def SYM(name, sort, meaning, kind=None, doc=None, excerpt=None, cert="established"):
    return {"name": name, "sort": sort, "meaning": meaning,
            "grounding": G(kind, doc, excerpt, cert) if kind else None}


def P(pid, expr, label, kind=None, doc=None, excerpt=None, cert="established", material="material"):
    return {"id": pid, "expr": expr, "label": label,
            "grounding": G(kind, doc, excerpt, cert) if kind else None,
            "materiality": material}


def _vars(node, acc):
    if isinstance(node, dict):
        if node.get("op") == "var":
            acc.add(node["name"])
        for v in node.values():
            _vars(v, acc)
    elif isinstance(node, list):
        for v in node:
            _vars(v, acc)
    return acc


def PROBLEM(pid, req, cid, allsyms, prems, concl):
    """allsyms: dict name -> Symbol; only the symbols the problem uses are declared."""
    used = set()
    for p in prems:
        _vars(p["expr"], used)
    _vars(concl["expr"], used)
    syms = [allsyms[n] for n in allsyms if n in used]
    return {"ir_version": "1.0", "problem_id": pid, "request_id": req, "claim_id": cid,
            "query": "entailment", "symbols": syms, "premises": prems, "conclusion": concl}


def ENTRY(problem=None, reading="", unsup=None, ambiguous=False, flags=()):
    gl = []
    if problem:
        for s in problem["symbols"]:
            gl.append({"symbol": s["name"], "meaning": s["meaning"], "grounding": s["grounding"]})
    return {"problem": problem,
            "interpretation": {"reading": reading, "glossary": gl,
                               "ambiguity_flags": [{"code": c, "message": m, "alternatives": a} for c, m, a in flags]},
            "ambiguous": ambiguous, "unsupported_reason": unsup}


def DUMP(task, report_id, claims):
    os.makedirs(OUT_DIR, exist_ok=True)
    path = os.path.join(OUT_DIR, task + ".json")
    with open(path, "w", encoding="utf-8") as fh:
        json.dump({"report_id": report_id, "claims": claims}, fh, ensure_ascii=False, indent=1)
    print("wrote", path, len(claims), "claims")
