import sys
sys.path.insert(0, "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2/tr")
from ir import *

REQ = "req-ps-t15"
S = {}


def sym(name, sort, meaning, kind=None, cert="established"):
    S[name] = SYM(name, sort, meaning, kind, None, None, cert)


def P2(pid, expr, label, kind=None, cert="established"):
    return P(pid, expr, label, kind, None, None, cert)


sym("in_psych", "Bool", "the topic sits within psychology", "specialist_inference", "probable")
sym("linked", "Bool", "the topic can be linked to existing research", "specialist_inference", "probable")
sym("ethics_ok", "Bool", "an experiment with 16- to 18-year-olds can be planned within ethical limits", "specialist_inference", "probable")
sym("topic_ok", "Bool", "the topic is allowed for the proposal", "specialist_inference", "probable")

C = {}
C["g2.1@psychology-specialist"] = NULL = ENTRY(unsup="a directive ('Start with the task') with no proposition to check")
C["g2.2@psychology-specialist"] = ENTRY(unsup="a bare fact about the assessment's weighting and length, stated from memory; no inference to check")
C["g2.3@psychology-specialist"] = ENTRY(unsup="a bare list of assessment criteria stated from memory; no inference to check")
C["g3.1@psychology-specialist"] = ENTRY(problem=PROBLEM("p-ps-t15-g3.1", REQ, "g3.1@psychology-specialist", S,
    [P2("pr_ip", V("in_psych"), "the topic sits within psychology", "specialist_inference", "probable"),
     P2("pr_lk", V("linked"), "the topic can be linked to existing research", "specialist_inference", "probable"),
     P2("pr_et", V("ethics_ok"), "an experiment with this population can be planned within ethical limits", "specialist_inference", "probable"),
     P2("pr_tp", IMP(AND(V("in_psych"), V("linked"), V("ethics_ok")), V("topic_ok")), "the three conditions make the topic allowed", "specialist_inference", "probable")],
    P2("concl", V("topic_ok"), "the student's topic is allowed", None, "probable")),
    reading="The topic is judged allowed because it sits in psychology, can be linked to research, and can be planned within ethical limits (each probable).")
C["g5.10@psychology-specialist"] = ENTRY(unsup="advice listing ethical considerations to weigh; it asserts no checkable proposition")

DUMP("ps-t15", "rep-ps-t15-0", C)
