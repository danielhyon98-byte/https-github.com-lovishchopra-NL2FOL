import json
import os

SRC = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2/tasks.json"
DST = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2/revisions/ph-t15.json"

response_lines = [
    "Assumptions: g = 9.8 m s⁻² (the data booklet value, since the question gives no value for g); friction and air resistance are ignored; the 3.0 m s⁻¹ in (b) is the value given in the question.",
    "",
    "(a) [2]",
    "Principle: with no friction, the gravitational potential energy lost equals the kinetic energy gained, and the wagon starts from rest.",
    "mgh = ½mv²",
    "The mass cancels: v² = 2gh",
    "Substitution: v² = 2 × 9.8 m s⁻² × 0.46 m = 9.016 m² s⁻²",
    "v = √(9.016 m² s⁻²) = 3.0027 m s⁻¹, so v = 3.00 m s⁻¹ (3 s.f.)",
    "This agrees with the value given, 3.0 m s⁻¹.",
    "",
    "(b) [2]",
    "Principle: momentum is conserved, since no external horizontal force acts during the collision.",
    "Symbols: m₁ = 1.2 × 10⁴ kg and u₁ = 3.0 m s⁻¹ (the moving wagon, before the collision); m₂ = 8.0 × 10³ kg and u₂ = 0 m s⁻¹ (the stationary wagon); v = common velocity of the coupled wagons just after the collision.",
    "m₁u₁ + m₂u₂ = (m₁ + m₂)v",
    "(1.2 × 10⁴ kg)(3.0 m s⁻¹) + (8.0 × 10³ kg)(0 m s⁻¹) = (1.2 × 10⁴ kg + 8.0 × 10³ kg)v",
    "3.6 × 10⁴ kg m s⁻¹ = (2.0 × 10⁴ kg)v",
    "v = 1.8 m s⁻¹, in the original direction of motion",
    "",
    "(c) [3]",
    "Before: E_k = ½m₁u₁² = ½(1.2 × 10⁴ kg)(3.0 m s⁻¹)² = 5.4 × 10⁴ J",
    "After: E_k = ½(m₁ + m₂)v² = ½(2.0 × 10⁴ kg)(1.8 m s⁻¹)² = 3.24 × 10⁴ J",
    "Transferred to other forms: ΔE = 5.4 × 10⁴ J − 3.24 × 10⁴ J = 2.16 × 10⁴ J, so ΔE = 2.2 × 10⁴ J (2 s.f.)",
    "As a percentage: (2.16 × 10⁴ J / 5.4 × 10⁴ J) × 100% = 40%",
    "",
    "(d) [2]",
    "Principle: impulse equals change in momentum, FΔt = Δp. The direction of motion is taken as positive, and the buffer force F is assumed to be the only horizontal force on the wagons (level track, friction and air resistance ignored).",
    "Values: m = 2.0 × 10⁴ kg (the coupled wagons); u = +1.8 m s⁻¹ (their velocity just after the collision, from (b)); v_f = 0 m s⁻¹ (at rest); Δt = 0.60 s.",
    "Δp = m(v_f − u) = (2.0 × 10⁴ kg)(0 m s⁻¹ − 1.8 m s⁻¹) = −3.6 × 10⁴ kg m s⁻¹",
    "F = Δp / Δt = (−3.6 × 10⁴ kg m s⁻¹) / (0.60 s) = −6.0 × 10⁴ N",
    "The average force is 6.0 × 10⁴ N, opposite to the direction of motion.",
    "",
    "(e) [2]",
    "Principle: ½kx² = E_k, with E_k = 3.24 × 10⁴ J from (c).",
    "x² = (2 × 3.24 × 10⁴ J) / (2.0 × 10⁶ N m⁻¹) = 3.24 × 10⁻² m²",
    "x = 0.18 m = 18 cm (2 s.f.)",
    "",
    "(f) [2]",
    "Momentum: the forces between the wagons during coupling are an equal and opposite pair (Newton's third law), so they are internal to the system. The weights are balanced by normal forces and friction is ignored, so there is no external horizontal force and the total momentum is conserved.",
    "Kinetic energy: the wagons stick together in an inelastic collision. Part of the kinetic energy becomes internal energy in the couplings (deformation and heating) and sound, so the kinetic energy after the collision is less, while the total energy is still conserved.",
    "",
    "Next step: redo (b) with the 8.0 × 10³ kg wagon moving at 3.0 m s⁻¹ towards the first wagon, and check the sign of your final velocity.",
    "",
    "Sources: your question (supplied text); course notes on energy, momentum and impulse (course notes)",
]

feedback_handled = [
    {
        "flaw_id": "f1",
        "change": "Defined every symbol with its unit before the momentum relation (m1, u1, m2, u2, and v as the common velocity just after the collision); gave the zero term its unit (0 m s-1) and wrote the combined mass line as 2.0 x 10^4 kg before solving. The value 1.8 m s-1 was kept: 3.6 x 10^4 kg m s-1 divided by 2.0 x 10^4 kg gives 1.8 m s-1.",
    },
    {
        "flaw_id": "f2",
        "change": "The symbol v had been used for 1.8 m s-1 in (b) and for the final velocity in (d), which made the line ambiguous. In (d) the initial speed is now u = +1.8 m s-1 and the final speed is v_f = 0 m s-1, with units on each. The arithmetic was already correct and is kept: (2.0 x 10^4)(0 - 1.8) = -3.6 x 10^4 kg m s-1.",
    },
    {
        "flaw_id": "f3",
        "change": "Before the impulse relation in (d), stated the mass (2.0 x 10^4 kg), the initial and final velocities with units, the time (0.60 s), the sign convention (direction of motion positive) and the assumption that the buffer force is the only horizontal force on the wagons. The step F = Δp/Δt is unchanged and its value (6.0 x 10^4 N) is kept.",
    },
    {
        "flaw_id": "f4",
        "change": "Corrected the unit of the square root: the root of m^2 s^-2 is m s-1, so the line now reads v = sqrt(9.016 m^2 s^-2) = 3.0027 m s-1. The numerical value is right (sqrt(9.016) = 3.00267, which rounds to 3.0027 at five significant figures) and the 3.00 m s-1 (3 s.f.) result is kept.",
    },
]

with open(SRC, encoding="utf-8") as f:
    items = json.load(f)

entry = next(t for t in items if t.get("task_id") == "ph-t15")
out = dict(entry)
out["response_text"] = "\n".join(response_lines)
out["feedback_handled"] = feedback_handled

os.makedirs(os.path.dirname(DST), exist_ok=True)
with open(DST, "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=2)

print("written", DST)
