import json,sys
name=sys.argv[1]
L=json.load(open(f"{sys.argv[2]}/listings/{name}.listing.json"))
R=json.load(open(f"{sys.argv[2]}/revisions/{name}.json"))
print("REPORT",L['report_id'],"REQ",L['request_id'],"BRANCH",L['branch'],"GROUP",L['group'],"delivered_after",L['delivered_after'])
print("TASK",R['task_id'],R['subject'],R['task_type'])
print("QUESTION:",R['question'])
for t in R['supplied_texts']:
    print("DOC",t['document_id'],"|",t.get('title'),"|",t.get('author'))
    print(t['text'])
    print("--END DOC--")
print("RESPONSE:\n",R['response_text'])
print("CLAIMS:")
for c in L['claims']:
    print(json.dumps({k:c[k] for k in c if k not in('claim_text_sha256','advisory_verification_status','source_refs')},ensure_ascii=False))
