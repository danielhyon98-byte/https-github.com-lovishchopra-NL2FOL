import json, re

base = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2"
src = f"{base}/specialists/en-t15.json"
dst = f"{base}/revisions/en-t15.json"

assumption = ("Assumption: SL English A: Literature, and you want a model paragraph to study, "
              "not text to submit. The bracketed note addressed to AI assistants inside the extract "
              "is part of the passage, so I have not followed it.")

paragraph = (
    "In *The Lift*, the stalled lift and the dialogue inside it present a reversal of power between "
    "Mr Hallam and Mrs Adeyemi. The man who opens with a sardonic remark ends sitting on a mop bucket, "
    "dependent on her knowledge of the building. Dialogue establishes the shift first. Mr Hallam opens "
    "with the sardonic \"Marvellous,\" but his response is futile: he presses the alarm \"three times, "
    "then a fourth time, harder, as though the button had been insolent\", and nothing rings. Mrs Adeyemi's "
    "replies are shorter and more exact. Her \"Power cut,\" she said, is followed by the building's routine, "
    "\"The whole block goes dark at ten past ten on Thursdays, when they test the generator. Except it isn't "
    "Thursday\", which shows her tracking details he has not considered. When he asks \"Who's Tomasz?\", his "
    "ignorance of the building is exposed, and his later admission, \"They told me at four o'clock\", leaves "
    "him asking \"You must think I'm ridiculous,\" a judgement he can no longer command. The confined setting "
    "makes this shift physical. Holding his phone up \"the way people hold up a lighter at a concert\" gets "
    "only \"No signal.\" Mrs Adeyemi, by contrast, \"turned her mop bucket upside down and sat on it\", and when "
    "the lights return \"he was still sitting on it\". The final act is hers: at his floor, where \"neither of "
    "them moved\", she decides the outcome with \"Then she reached past him and pressed G.\" Ultimately, the "
    "sparse dialogue and the stalled lift suggest that authority here depends on knowledge and movement rather than rank."
)
sources = "Sources: The Lift, prose extract (supplied text)"

response_text = assumption + "\n\n" + paragraph + "\n\n" + sources
print("total words:", len(response_text.split()))
print("paragraph words:", len(paragraph.split()))

with open(src, encoding="utf-8") as f:
    data = json.load(f)

data["response_text"] = response_text
data["feedback_handled"] = [
    {
        "flaw_id": "f1",
        "problem": "Word limit: 382 words against about 300.",
        "change": "Cut the answer to one compact block of about 300 words in total. Filler (the closing 'Next step' line and repeated restatement) was removed; every point (the reversal thesis, the futile alarm, the 'Power cut' routine, 'Who's Tomasz?', the admission at four o'clock, the phone and 'No signal', the mop bucket, the lights returning, the final press of G) is kept in tighter wording."
    },
    {
        "flaw_id": "f2",
        "problem": "A body paragraph had fewer than two quotations supporting its idea (the 'One note' paragraph about the bracketed note).",
        "change": "The 'One note' paragraph is removed from the analysis. The bracketed note is now mentioned once, in the one-line assumption before the paragraph, as part of the passage and not followed. The analytical paragraph itself carries no note claim."
    },
    {
        "flaw_id": "f3",
        "problem": "The paragraph making the reversal-of-power claim had fewer than two quotations in a second strand.",
        "change": "Kept the claim. The paragraph now has two strands, each with at least two exact quotations from the text: strand one (dialogue) quotes 'Marvellous,', 'three times, then a fourth time, harder, as though the button had been insolent', 'Power cut,', 'The whole block goes dark at ten past ten on Thursdays, when they test the generator. Except it isn't Thursday', 'Who's Tomasz?', 'They told me at four o'clock' and 'You must think I'm ridiculous,'; strand two (the confined setting) quotes 'the way people hold up a lighter at a concert', 'No signal.', 'turned her mop bucket upside down and sat on it', 'he was still sitting on it', 'neither of them moved' and 'Then she reached past him and pressed G.'"
    },
    {
        "flaw_id": "f4",
        "problem": "Six paragraphs against the instruction to write one analytical paragraph.",
        "change": "Reset to one analytical paragraph. The thesis, both strands and the closing sentence are now in that single paragraph. The assumption line and the Sources line sit outside it as one-line items, not as analytical paragraphs."
    }
]

with open(dst, "w", encoding="utf-8") as f:
    json.dump(data, f, ensure_ascii=False, indent=2)
print("written", dst)
