import json, subprocess, os

S = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad"
PY = f"{S}/z3venv/bin/python"
LC = "/home/user/https-github.com-lovishchopra-NL2FOL/scripts/arena/list_claims.py"
I = f"{S}/clearance/c2/combinator-instructions"
SP = f"{S}/clearance/c2/specialists"
OUT = f"{S}/clearance/c2/syntheses"

REASON_OTHER = "a note or source line (role other), which is never cited as a claim"

TASKS = ["bi-p9b", "bi-t15", "bm-t15", "ch-p9b", "ch-t15", "cs-t15", "ec-t15", "en-t15",
         "ess-p9c", "ess-t15", "ge-p9c", "ge-t15", "hi-t15", "lit-t15", "ll-p9a", "ll-t15",
         "maa-t15", "mai-t15", "ph-t15", "ps-p9a", "ps-t15", "sp-t15"]

HEAD = "a heading that names the topic of the following claims, with no claim of its own"

SPEC = {
    "bi-p9b": {
        "drop": {
            "s1.1@biology-specialist": "a remark on the status of the answer, not a claim about the osmosis data",
            "s1.2@biology-specialist": "a disclaimer that the practice data are invented, not a claim of the answer",
            "s1.3@biology-specialist": "a disclaimer about the provisional mark points, not a claim of the answer",
            "s2.3@biology-specialist": "a self-certification that the values were recalculated and agree, not a claim of the answer",
            "s4.1@biology-specialist": "a table header with no claim of its own",
            "s5.1@biology-specialist": "a self-certification that the six values are correct, not a claim about osmosis",
        },
    },
    "ch-p9b": {
        "drop": {
            "s2.1": HEAD, "s4.1": HEAD, "s6.1": HEAD, "s8.1": HEAD, "s10.1": HEAD, "s12.1": HEAD,
            "s15.1": "a suggestion to the student, not a claim of the answer",
        },
        "narrow": {
            "s7.3": "10.00 cm³: 0.98382 × (10.00 ÷ 50.00) = 0.19676 mol dm⁻³, so 0.197 mol dm⁻³",
        },
    },
    "ll-p9a": {
        "drop": {
            "p1-s01": "a remark that the paragraph is a model for practice, not a claim about the email",
        },
        "conflicts": [
            {
                "claim_ids": ["p3-point", "g3.1@psychology-specialist"],
                "description": "The English specialist says the email reads 'are already Friends', so the quoted 'were already Friends' is not the email's wording; the Psychology specialist presents 'were already Friends' as what readers were told.",
            }
        ],
    },
    "ps-p9a": {},
    "bi-t15": {
        "drop": {
            "s1.2": "a disclaimer that the mark tags are illustrative, not a claim of the answer",
            "s2.1": "a decline to give current figures, not a claim of the answer",
            "s2.2": "a suggestion about where current figures can be found, not a claim of the answer",
        },
        "narrow": {
            "s2.3": "Asthma narrows the airways, which limits the air reaching the alveoli.",
        },
    },
    "bm-t15": {},
    "ch-t15": {
        "drop": {
            "s1.1": HEAD, "s5.1": HEAD, "s7.1": HEAD, "s9.1": HEAD, "s11.1": HEAD,
            "s14.1": HEAD, "s16.1": HEAD,
            "s18.1": "an offer to check the student's own working, not a claim of the answer",
        },
        "narrow": {
            "s8.4": "nitrogen needed for 1500 cm³ of H₂ = 1500 ÷ 3 = 500 cm³.",
        },
    },
    "cs-t15": {
        "drop": {
            "c3.1": "a label that introduces the working, with no claim of its own",
            "c4.1": "a label that introduces the working, with no claim of its own",
            "c7.6": "a teaching note about the exam, not a claim of the answer",
        },
    },
    "ec-t15": {
        "drop": {
            "g7.1": "a suggested next task for the student, not a claim of the answer",
        },
    },
    "en-t15": {
        "drop": {
            "p2-point": "a remark about an instruction embedded in the supplied extract, not a claim about the story",
            "p2-s02": "a self-report about how the embedded instruction was handled, not a claim about the story",
        },
    },
    "ess-p9c": {
        "drop": {
            "s1.2": "a disclaimer that the mark tags are not the official markscheme, not a claim of the answer",
        },
    },
    "ess-t15": {
        "drop": {
            "s8.1": "a bare list number with no content of its own",
            "s12.1": "a disclaimer that the mark tags are illustrative, not a claim of the answer",
        },
    },
    "ge-p9c": {
        "drop": {
            "g1.2@geography-specialist": "a disclaimer that the data are fictional practice data, not a claim of the answer",
        },
    },
    "ge-t15": {},
    "hi-t15": {
        "drop": {
            "h1.17": "a remark that the structure is for testing, not a claim about the question",
        },
    },
    "lit-t15": {},
    "ll-t15": {},
    "maa-t15": {
        "drop": {
            "m12.1": "a disclaimer that the marks are a provisional allocation, not a claim of the answer",
        },
        "narrow": {
            "m4.6": "(x − 3)² − 4 = x² − 6x + 9 − 4 = x² − 6x + 5.",
            "m5.3": "At x = 0, g(0) = 3 and h(3) = 1 = 0 + 1.",
            "m6.3": "g((x − 3)/2) = 2 × (x − 3)/2 + 3 = x.",
            "m7.4": "the left side is −5 + 1 = −4 and the right side is (−5 − 3)/2 = −4.",
            "m9.2": "C(5, 2)/C(8, 2) = 10/28 = 5/14.",
            "m10.2": "1 − P(RR) − P(BB) = 1 − 5/14 − 3/28 = 15/28.",
            "m11.7": "Counting selections with at least one blue number: C(8, 2) − C(5, 2) = 28 − 10 = 18, of which C(3, 2) = 3 are both blue, so 3/18 = 1/6.",
        },
    },
    "mai-t15": {
        "drop": {
            "m23.1": "a self-report that the values were worked by hand, with advice to check them, not a claim of the answer",
            "m24.1": "a disclaimer that the marks are provisional, not a claim of the answer",
        },
        "narrow": {
            "m8.1": "$(6,\\ -1)$ lies on this line, and $(6 - 2)^2 + (-1 - 1)^2 = 20 = (6 - 8)^2 + (-1 - 3)^2$.",
            "m13.1": "$\\frac{2}{3}\\left(\\frac{45}{11}\\right) + 2 = \\frac{30}{11} + \\frac{22}{11} = \\frac{52}{11}$.",
            "m17.1": "the distances from the point to B and to C are also $\\frac{\\sqrt{2210}}{11}$, as they must be.",
        },
    },
    "ph-t15": {},
    "ps-t15": {
        "drop": {
            "g1.1": "a decline to write part of the proposal, which is a note and not a claim",
            "g1.2": "an offer of help, which is a note and not a claim",
            "g2.1": "an instruction to the student about where to start, not a claim about the proposal",
            "g4.8": "an instruction to the student, not a claim about the proposal",
            "g8.2": "an offer of future feedback, not a claim about the proposal",
        },
    },
    "sp-t15": {
        "drop": {
            "g1.1@language-b-spanish-specialist": "a remark that the text is written for practice, not a claim about the article",
            "g1.2@language-b-spanish-specialist": "a disclaimer that the author, school and city are fictional, not a claim about the article",
            "g11.1@language-b-spanish-specialist": "a word count, which is a remark about the answer and not a claim",
        },
    },
}


def load(task):
    out = subprocess.run([PY, "-I", LC, f"{SP}/{task}.json", "--json", "--instructions", I],
                         capture_output=True, text=True, check=True).stdout
    d = json.loads(out)
    return d["report_id"], d["claims"]


def build(task):
    report_id, claims = load(task)
    spec = SPEC.get(task, {})
    drop = spec.get("drop", {})
    narrow = spec.get("narrow", {})
    out_claims, out_dropped = [], []
    for c in claims:
        cid = c["claim_id"]
        if cid in drop:
            out_dropped.append({"source_claim_ids": [cid], "reason": drop[cid]})
            continue
        if c["role"] == "other":
            out_dropped.append({"source_claim_ids": [cid], "reason": REASON_OTHER})
            continue
        if cid in narrow:
            text, trans = narrow[cid], "narrowed"
        else:
            text, trans = c["text"], "carried"
        out_claims.append({"text": text, "source_claim_ids": [cid],
                           "certainty": c["certainty"], "transformation": trans})
    # coverage check: every own claim exactly once
    covered = [x for d in out_claims for x in d["source_claim_ids"]] + \
              [x for d in out_dropped for x in d["source_claim_ids"]]
    ids = [c["claim_id"] for c in claims]
    assert sorted(covered) == sorted(ids), (task, set(ids) ^ set(covered))
    assert out_claims, task
    res = {"claims": out_claims, "dropped": out_dropped}
    if spec.get("conflicts"):
        res["conflicts"] = spec["conflicts"]
    return report_id, res


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    for t in TASKS:
        rid, res = build(t)
        path = f"{OUT}/{t}.json"
        with open(path, "w", encoding="utf-8") as f:
            json.dump(res, f, ensure_ascii=False, indent=1)
        print(t, rid, "claims", len(res["claims"]), "dropped", len(res["dropped"]),
              "conflicts" if "conflicts" in res else "")
