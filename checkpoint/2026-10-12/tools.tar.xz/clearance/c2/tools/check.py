import json, sys
from epinoic_logic.engine import parse_and_validate
spec_path, tr_path = sys.argv[1], sys.argv[2]
spec = json.load(open(spec_path))
docs = {d['document_id']: d['text'] for d in spec.get('supplied_texts', [])}
tr = json.load(open(tr_path))
def walk_groundings(obj, out):
    if isinstance(obj, dict):
        g = obj.get('grounding')
        if isinstance(g, dict):
            out.append(g)
        for v in obj.values():
            walk_groundings(v, out)
    elif isinstance(obj, list):
        for v in obj:
            walk_groundings(v, out)
for cid, entry in tr['claims'].items():
    p = entry.get('problem')
    if p is None:
        print(cid, 'NULL'); continue
    prob, o = parse_and_validate(json.dumps(p))
    bad = []
    gs = []
    walk_groundings(p, gs)
    for g in gs:
        for r in g.get('source_refs', []):
            ex = r.get('excerpt')
            if ex is not None and r['document_id'] in docs and ex not in docs[r['document_id']]:
                bad.append((r['document_id'], ex))
            if ex is not None and r['document_id'] not in docs:
                bad.append(('MISSING DOC', r['document_id']))
    print(cid, 'valid=', o.ok, 'bad_excerpts=', bad if bad else 'none')
    if not o.ok:
        print('   ', getattr(o, 'errors', None) or getattr(o, 'issues', None) or vars(o))
