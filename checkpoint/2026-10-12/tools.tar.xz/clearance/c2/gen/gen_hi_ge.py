from common import *

# ---------------- history: hi-t15 ----------------
def gen_hi():
    T = "hi-t15"; DOC = "doc-prague-student"
    d, sm = load_listing(T); RID = d["request_id"]
    def P(short, syms, prems, concl, notes=None):
        return PROBLEM(f"{T}-{short.replace('.', '_')}", RID, sm[short], syms, prems, concl, notes)
    E = {}
    AP = "In April 1968 the party published its Action Programme"
    TW = "and in June the 'Two Thousand Words' manifesto called for even faster change"
    # h1.3 dating of Action Programme and Two Thousand Words
    syms = [SYM("apr_stud", "Bool", "the paragraph dates the Action Programme to April 1968", Q(DOC, AP)),
            SYM("jun_stud", "Bool", "the paragraph dates the Two Thousand Words manifesto to June 1968", Q(DOC, TW)),
            SYM("apr_fact", "Bool", "the Action Programme was published in April 1968", G("general_knowledge")),
            SYM("jun_fact", "Bool", "the Two Thousand Words manifesto was published in June 1968", G("general_knowledge"))]
    prems = [PREM("p_apr_stud", V("apr_stud"), "the paragraph dates the Action Programme to April 1968", Q(DOC, AP)),
             PREM("p_jun_stud", V("jun_stud"), "the paragraph dates the Two Thousand Words manifesto to June 1968", Q(DOC, TW)),
             PREM("p_apr_fact", V("apr_fact"), "the Action Programme was published in April 1968", G("general_knowledge")),
             PREM("p_jun_fact", V("jun_fact"), "the Two Thousand Words manifesto was published in June 1968", G("general_knowledge"))]
    concl = CONC("c_placed", AND(IFF(V("apr_stud"), V("apr_fact")), IFF(V("jun_stud"), V("jun_fact"))),
                 "the April 1968 Action Programme and the June Two Thousand Words manifesto are correctly placed by the paragraph")
    E["h1.3"] = ENTRY(P("h1.3", syms, prems, concl), "Each dating in the student paragraph is compared with the known date; the claim holds when both match.", syms)
    # h1.5 biggest gap
    ec = "Moscow's fear that Dubček's reforms would spread to the rest of the Eastern bloc"
    eh = "Brezhnev was worried because Poland and East Germany were already facing protests"
    id_ = "Therefore the Soviet Union invaded Czechoslovakia mainly because of ideology"
    syms = [SYM("ev_contag", "Bool", "the paragraph's evidence describes fear that the reforms would spread", Q(DOC, ec)),
            SYM("ev_cohes", "Bool", "the paragraph's evidence describes bloc cohesion under threat (protests in Poland and East Germany)", Q(DOC, eh)),
            SYM("ideo_concl", "Bool", "the paragraph concludes the invasion was mainly because of ideology", Q(DOC, id_)),
            SYM("weighed", "Bool", "the paragraph weighs a reason other than ideology", G("supplied_text", note="structural fact about the paragraph")),
            SYM("exam_met", "Bool", "the paragraph meets the demand to examine the reasons", G("specialist_inference"))]
    prems = [PREM("p_contag", V("ev_contag"), "the paragraph describes fear that reforms would spread", Q(DOC, ec)),
             PREM("p_cohes", V("ev_cohes"), "the paragraph describes protests in Poland and East Germany", Q(DOC, eh)),
             PREM("p_ideo", V("ideo_concl"), "the paragraph concludes mainly because of ideology", Q(DOC, id_), "supporting"),
             PREM("p_noweigh", NOT(V("weighed")), "the paragraph weighs no reason other than ideology", G("supplied_text", note="structural fact about the paragraph")),
             PREM("p_link", IMP(AND(OR(V("ev_contag"), V("ev_cohes")), NOT(V("weighed"))), NOT(V("exam_met"))),
                  "evidence of a reason other than ideology that is not weighed does not meet the demand to examine the reasons", G("specialist_inference"))]
    concl = CONC("c_gap", NOT(V("exam_met")), "the demand to examine the reasons is not met")
    E["h1.5"] = ENTRY(P("h1.5", syms, prems, concl), "The paragraph's own evidence describes other reasons, none is weighed, and the demand to examine reasons is therefore not met.", syms)
    # h1.7 Dubcek year
    ex = "became First Secretary of the Czechoslovak Communist Party in January 1967"
    syms = [SYM("yr_stud", "Int", "year the paragraph gives for Dubček becoming First Secretary", Q(DOC, ex)),
            SYM("yr_fact", "Int", "year Dubček became First Secretary", G("general_knowledge")),
            SYM("mo_fact", "Int", "month of Dubček's appointment (January = 1)", G("general_knowledge"))]
    prems = [PREM("p_yr_stud", EQ(V("yr_stud"), I(1967)), "the paragraph gives the year 1967", Q(DOC, ex)),
             PREM("p_yr_fact", EQ(V("yr_fact"), I(1968)), "Dubček became First Secretary in 1968", G("general_knowledge")),
             PREM("p_mo_fact", EQ(V("mo_fact"), I(1)), "Dubček became First Secretary in January", G("general_knowledge"))]
    concl = CONC("c_year", AND(NE(V("yr_stud"), V("yr_fact")), EQ(V("yr_fact"), I(1968)), EQ(V("mo_fact"), I(1))),
                 "Dubček became First Secretary in January 1968, not 1967")
    E["h1.7"] = ENTRY(P("h1.7", syms, prems, concl), "The paragraph's year (1967) is compared with the year of appointment (January 1968).", syms)
    # h1.8 invasion date
    ex = "night of 20–21 September 1968"
    syms = [SYM("mo_stud", "Int", "month the paragraph gives for the invasion", Q(DOC, ex)),
            SYM("mo_inv", "Int", "month in which the invasion began", G("general_knowledge")),
            SYM("yr_inv", "Int", "year in which the invasion began", G("general_knowledge")),
            SYM("day_inv", "Int", "first night of the invasion (day of month)", G("general_knowledge"))]
    prems = [PREM("p_mo_stud", EQ(V("mo_stud"), I(9)), "the paragraph gives September", Q(DOC, ex)),
             PREM("p_mo_inv", EQ(V("mo_inv"), I(8)), "the invasion began in August", G("general_knowledge")),
             PREM("p_yr_inv", EQ(V("yr_inv"), I(1968)), "the invasion began in 1968", G("general_knowledge")),
             PREM("p_day_inv", EQ(V("day_inv"), I(20)), "the invasion began on the night of the 20th", G("general_knowledge"))]
    concl = CONC("c_date", AND(NE(V("mo_stud"), V("mo_inv")), EQ(V("mo_inv"), I(8)), EQ(V("yr_inv"), I(1968)), EQ(V("day_inv"), I(20))),
                 "the invasion began on the night of 20–21 August 1968, so the paragraph's September is wrong")
    E["h1.8"] = ENTRY(P("h1.8", syms, prems, concl), "The paragraph's month (September) is compared with the known month of the invasion (August 1968).", syms)
    E["h1.1"] = NULL("Rubric description of what the question demands; it asserts nothing about the paragraph that could be checked.",
                     "rubric description of the question's demand, not a proposition the paragraph makes; no relation to check")
    E["h1.15"] = NULL("An instruction to the student to replace a sentence with a weighed judgement.",
                      "a feedback instruction, not an assertion with a conclusion to check")
    E["h1.18"] = NULL("A stated working assumption about the syllabus and mark scheme.",
                      "a stated assumption with no conclusion to check against evidence")
    emit(T, d["report_id"], E, sm)

# ---------------- geography: ge-t15 ----------------
def gen_ge():
    T = "ge-t15"; DOC = "doc-ostrel"
    d, sm = load_listing(T); RID = d["request_id"]
    def P(short, syms, prems, concl):
        return PROBLEM(f"{T}-{short.replace('.', '_')}", RID, sm[short], syms, prems, concl)
    def tbl(name, value, excerpt, meaning):
        return (SYM(name, "Int", meaning, Q(DOC, excerpt)),
                PREM("d_" + name, EQ(V(name), I(value)), f"the table gives {meaning} as {value}", Q(DOC, excerpt), "supporting"))
    COAL05 = tbl("coal_s05", 46, "Coal | 46 | 28", "coal share of primary energy in 2005 (%)")
    COAL25 = tbl("coal_s25", 28, "Coal | 46 | 28", "coal share of primary energy in 2025 (%)")
    WS05 = tbl("ws_s05", 1, "Wind and solar power | 1 | 13", "wind and solar share in 2005 (%)")
    WS25 = tbl("ws_s25", 13, "Wind and solar power | 1 | 13", "wind and solar share in 2025 (%)")
    TOT05 = tbl("tot_pj05", 820, "Total primary energy supply (petajoules, PJ) | 820 | 1,050", "total primary energy supply in 2005 (PJ)")
    TOT25 = tbl("tot_pj25", 1050, "Total primary energy supply (petajoules, PJ) | 820 | 1,050", "total primary energy supply in 2025 (PJ)")
    IMP05 = tbl("imp_s05", 38, "Share of primary energy supply that is imported (%) | 38 | 54", "imported share in 2005 (%)")
    IMP25 = tbl("imp_s25", 54, "Share of primary energy supply that is imported (%) | 38 | 54", "imported share in 2025 (%)")
    def pk(*pairs): return [p[0] for p in pairs], [p[1] for p in pairs]
    E = {}
    # g1.2
    s, p = pk(WS05, WS25)
    E["g1.2"] = ENTRY(P("g1.2", s, p, CONC("c_g12", EQ(SUB(V("ws_s25"), V("ws_s05")), I(12)), "wind and solar share rose by 12 percentage points")), "Difference of the two table shares.", s)
    # g1.3 relative change
    s, p = pk(WS05, WS25)
    concl = CONC("c_g13", EQ(MUL(I(100), SUB(V("ws_s25"), V("ws_s05"))), MUL(I(1200), V("ws_s05"))), "as a relative change the rise would be 1,200%")
    E["g1.3"] = ENTRY(P("g1.3", s, p, concl), "Relative change = (13 - 1) / 1 x 100 = 1,200%, cross-multiplied to stay linear.", s)
    # g2.2 / g2.3 coal supply amounts
    s, p = pk(COAL05, TOT05)
    E["g2.2"] = ENTRY(P("g2.2", s, p, CONC("c_g22", EQ(DIV(TOREAL(MUL(V("coal_s05"), I(820))), R("100")), R("377.2")), "coal supply in 2005 is 46% of 820 PJ = 377.2 PJ")),
                      "The product 46 x 820 is written with the table total as a constant because a product of two variables is outside IR 1.0.", s)
    s, p = pk(COAL25, TOT25)
    E["g2.3"] = ENTRY(P("g2.3", s, p, CONC("c_g23", EQ(DIV(TOREAL(MUL(V("coal_s25"), I(1050))), R("100")), R("294.0")), "coal supply in 2025 is 28% of 1,050 PJ = 294.0 PJ")),
                      "28 x 1050 / 100 = 294.0, with the table total as a constant.", s)
    # g2.4 percentage change -22.1 (1 dp)
    s, p = pk(COAL05, COAL25, TOT05, TOT25)
    fall = "20800/943"  # |(294.0-377.2)/377.2*100| = 22.057...
    E["g2.4"] = ENTRY(P("g2.4", s, p, CONC("c_g24", AND(GE(R("-" + fall), R("-22.15")), LT(R("-" + fall), R("-22.05"))),
                                       "the percentage change is -22.1% when rounded to one decimal place")),
                      "Exact percentage change is -20800/943 = -22.057...; a figure stated to one decimal place is encoded as the interval [-22.15, -22.05).", s,
                      flags=[])
    # g2.5 fell by 22.1% from 377.2 to 294.0
    s, p = pk(COAL05, COAL25, TOT05, TOT25)
    concl = CONC("c_g25", AND(GE(R(fall), R("22.05")), LT(R(fall), R("22.15")),
                              EQ(DIV(TOREAL(MUL(V("coal_s05"), I(820))), R("100")), R("377.2")),
                              EQ(DIV(TOREAL(MUL(V("coal_s25"), I(1050))), R("100")), R("294.0"))),
                 "coal supply fell by 22.1%, from 377.2 PJ in 2005 to 294.0 PJ in 2025")
    E["g2.5"] = ENTRY(P("g2.5", s, p, concl), "Fall magnitude 22.057...% rounds to 22.1%, and both PJ amounts follow from the table.", s)
    # g2.6 share fall 18 pp, total growth 28.0%, causal 'which is why'
    s, p = pk(COAL05, COAL25, TOT05, TOT25)
    concl = CONC("c_g26", AND(EQ(SUB(V("coal_s05"), V("coal_s25")), I(18)),
                              GE(R("1150/41"), R("27.95")), LT(R("1150/41"), R("28.05")),
                              GE(R(fall), R("22.05")), LT(R(fall), R("22.15"))),
                 "the coal share fell by 18 points, total supply grew by 28.0%, and the amount of coal fell by only 22.1%")
    E["g2.6"] = ENTRY(P("g2.6", s, p, concl),
                      "Share fall 46-28 = 18 points; total growth 230/820 = 28.05% (stated 28.0%); coal amount fall 22.1% as in g2.4. The 'which is why' link is encoded only as the arithmetic, not as causation.",
                      s, ambiguous=True,
                      flags=[FLAG("causal-because", "'which is why' may be a causal explanation or only an arithmetic consistency check",
                                  ["causal: the rise in total supply is the reason the coal amount fell by less", "arithmetic: the two figures are consistent with each other"])])
    # g3.1 imports share +16 pp
    s, p = pk(IMP05, IMP25)
    E["g3.1"] = ENTRY(P("g3.1", s, p, CONC("c_g31", EQ(SUB(V("imp_s25"), V("imp_s05")), I(16)), "imports rose from 38% to 54%, a rise of 16 percentage points")),
                      "Difference 54 - 38 = 16.", s)
    # g3.2 quantities and 82.0%
    s, p = pk(IMP05, IMP25)
    q05 = DIV(TOREAL(MUL(V("imp_s05"), I(820))), R("100"))
    q25 = DIV(TOREAL(MUL(V("imp_s25"), I(1050))), R("100"))
    incr = "63850/779"  # (567.0-311.6)/311.6*100 = 81.96...
    concl = CONC("c_g32", AND(EQ(q05, R("311.6")), EQ(q25, R("567.0")), GE(R(incr), R("81.95")), LT(R(incr), R("82.05"))),
                 "imported energy rose from 311.6 PJ to 567.0 PJ, an increase of 82.0%")
    E["g3.2"] = ENTRY(P("g3.2", s, p, concl), "Quantities 38% of 820 and 54% of 1,050; increase 255.4/311.6 = 81.96..%, which rounds to 82.0% at one decimal place.", s)
    # g3.3 larger foreign share -> depends more (because)
    s, p = pk(IMP05, IMP25)
    syms = s + [SYM("depends_foreign", "Bool", "Ostrel's supply depends more on conditions in other countries", G("specialist_inference"))]
    prems = p + [PREM("p_imp_up", GT(V("imp_s25"), V("imp_s05")), "the imported share is larger in 2025 than in 2005", G("arithmetic_fact")),
                 PREM("p_link_dep", IMP(GT(V("imp_s25"), V("imp_s05")), V("depends_foreign")),
                      "a larger imported share makes supply depend more on other countries", G("specialist_inference"))]
    E["g3.3"] = ENTRY(P("g3.3", syms, prems, CONC("c_g33", V("depends_foreign"), "Ostrel's supply depends more on conditions in other countries")),
                      "The larger import share is the stated reason; the dependence link is the specialist's own inference.", syms,
                      ambiguous=True,
                      flags=[FLAG("because-causal-or-evidential", "'Because' could be causal (the larger share causes greater dependence) or evidential (the share is evidence of dependence)",
                                  ["causal: larger foreign share causes greater dependence", "evidential: larger foreign share is evidence of greater dependence"])])
    # g3.5 chain to security falls
    syms = [SYM("depends_foreign", "Bool", "Ostrel's supply depends more on conditions in other countries", G("specialist_inference")),
            SYM("exposed", "Bool", "households and firms are directly exposed to fuel price rises, disputes or route interruptions", G("specialist_inference")),
            SYM("less_rel", "Bool", "supply becomes less reliable", G("specialist_inference")),
            SYM("less_aff", "Bool", "supply becomes less affordable", G("specialist_inference")),
            SYM("sec_falls", "Bool", "Ostrel's energy security falls", G("specialist_inference"))]
    prems = [PREM("p_dep", V("depends_foreign"), "supply depends more on conditions in other countries", G("specialist_inference")),
             PREM("p_l1", IMP(V("depends_foreign"), V("exposed")), "greater dependence means households and firms are directly exposed", G("specialist_inference")),
             PREM("p_l2", IMP(V("exposed"), AND(V("less_rel"), V("less_aff"))), "direct exposure makes supply less reliable and less affordable", G("specialist_inference")),
             PREM("p_l3", IMP(AND(V("less_rel"), V("less_aff")), V("sec_falls")), "less reliable and less affordable supply lowers energy security", G("specialist_inference"))]
    concl = CONC("c_g35", AND(V("less_rel"), V("less_aff"), V("sec_falls")), "supply therefore becomes less reliable and less affordable, and energy security falls")
    E["g3.5"] = ENTRY(P("g3.5", syms, prems, concl), "Chain of the specialist's own links from foreign dependence to lower security; no table figure is used here.", syms)
    # g3.6 table does not say which fuels
    syms = [SYM("fuel_given", "Bool", "the table says which fuels are imported", G("supplied_text", note="structural fact about the table")),
            SYM("depends_detail", "Bool", "the explanation depends on which fuels are imported", G("specialist_inference"))]
    prems = [PREM("p_nofuel", NOT(V("fuel_given")), "the table does not say which fuels are imported", G("supplied_text", note="structural fact about the table")),
             PREM("p_link_detail", IMP(NOT(V("fuel_given")), V("depends_detail")), "without the fuel detail the explanation depends on it", G("specialist_inference"))]
    concl = CONC("c_g36", V("depends_detail"), "the explanation depends on which fuels are imported")
    E["g3.6"] = ENTRY(P("g3.6", syms, prems, concl), "Structural fact about the table with the specialist's link to the dependence on the missing detail.", syms)
    # g4.1 heading
    E["g4.1"] = NULL("A heading that names reason 1; its causal content is in g4.3.",
                     "heading naming a reason, with no assertion beyond the label; the substance is checked under g4.3")
    # g4.3 policy chain
    syms = [SYM("policy", "Bool", "a government sets targets, subsidies or carbon charges", G("specialist_inference", "possible")),
            SYM("wind_prof", "Bool", "wind and solar become more profitable", G("specialist_inference")),
            SYM("coal_costly", "Bool", "coal becomes more expensive to run", G("specialist_inference")),
            SYM("invest_wind", "Bool", "new investment goes to wind and solar", G("specialist_inference")),
            SYM("coal_less", "Bool", "some older coal plants run less", G("specialist_inference"))]
    prems = [PREM("p_l1", IMP(V("policy"), AND(V("wind_prof"), V("coal_costly"))), "such policy makes wind and solar more profitable and coal more expensive", G("specialist_inference")),
             PREM("p_l2", IMP(AND(V("wind_prof"), V("coal_costly")), AND(V("invest_wind"), V("coal_less"))), "this shifts new investment and reduces coal running", G("specialist_inference"))]
    concl = CONC("c_g43", IMP(V("policy"), AND(V("invest_wind"), V("coal_less"))), "if a government sets such policy, new investment goes to wind and solar and some older coal plants run less")
    E["g4.3"] = ENTRY(P("g4.3", syms, prems, concl), "Conditional reasoning from the policy mechanism the specialist describes; the policy itself is hypothetical ('may').", syms)
    # g4.4 pattern fits, no confirmed reason
    syms = [SYM("ws_s05_", "Int", "placeholder", None)] if False else []
    s, p = pk(WS05, WS25, COAL05, COAL25)
    syms = s + [SYM("policy_in_table", "Bool", "the table records a government policy", G("supplied_text", note="structural fact about the table")),
                SYM("confirmed", "Bool", "the policy reason is a confirmed explanation", G("specialist_inference"))]
    prems = p + [PREM("p_nopolicy", NOT(V("policy_in_table")), "the table records no policy", G("supplied_text", note="structural fact about the table")),
                 PREM("p_link_conf", IMP(NOT(V("policy_in_table")), NOT(V("confirmed"))), "without recorded policy the reason is only plausible, not confirmed", G("specialist_inference"))]
    concl = CONC("c_g44", AND(GT(V("ws_s25"), V("ws_s05")), GT(V("coal_s05"), V("coal_s25")), NOT(V("confirmed"))),
                 "Ostrel's figures fit the pattern (wind and solar up, coal down), but the reason is plausible to test rather than confirmed")
    E["g4.4"] = ENTRY(P("g4.4", syms, prems, concl), "Trend directions from the table; the 'not confirmed' status follows from the absence of recorded policy.", syms)
    E["g5.1"] = NULL("A heading that names reason 2.", "heading naming a reason, with no assertion beyond the label; the substance is checked under g5.2 and g5.3")
    # g5.2 cheaper -> investors build instead of coal (chain)
    syms = [SYM("cheaper", "Bool", "wind and solar technology becomes cheaper", G("specialist_inference")),
            SYM("lowest", "Bool", "new wind and solar capacity is the lowest-cost option", G("specialist_inference")),
            SYM("invest_inst", "Bool", "investors build wind and solar instead of new coal stations", G("specialist_inference"))]
    prems = [PREM("p_l1", IMP(V("cheaper"), V("lowest")), "cheaper technology makes wind and solar the lowest-cost option", G("specialist_inference")),
             PREM("p_l2", IMP(V("lowest"), V("invest_inst")), "the lowest-cost option is built instead of new coal", G("specialist_inference"))]
    concl = CONC("c_g52", IMP(V("cheaper"), V("invest_inst")), "as wind and solar become cheaper, investors build them instead of new coal stations")
    E["g5.2"] = ENTRY(P("g5.2", syms, prems, concl), "Two specialist links chained from cheaper technology to investment choice.", syms)
    # g6.1 fictional country
    syms = [SYM("fictional", "Bool", "Ostrel is a fictional country and its figures are practice data", Q(DOC, "Ostrel is a fictional country")),
            SYM("general_expl", "Bool", "the reasons are general explanations to test against Ostrel's data", G("specialist_inference")),
            SYM("not_real", "Bool", "the reasons are not facts about a real country", G("specialist_inference"))]
    prems = [PREM("p_fict", V("fictional"), "Ostrel is a fictional country", Q(DOC, "Ostrel is a fictional country")),
             PREM("p_link", IMP(V("fictional"), AND(V("general_expl"), V("not_real"))), "as a fictional country's practice data, the reasons are general explanations, not real facts", G("specialist_inference"))]
    concl = CONC("c_g61", AND(V("general_expl"), V("not_real")), "these reasons are general explanations to test against Ostrel's data, not facts about a real country")
    E["g6.1"] = ENTRY(P("g6.1", syms, prems, concl), "Fictional status is quoted from the supplied table; the framing of the reasons is the specialist's link.", syms)
    emit(T, d["report_id"], E, sm)

if __name__ == "__main__":
    gen_hi()
    gen_ge()
