from common import *

def gen_gep9():
    T = "ge-p9c"
    d, sm = load_listing(T); RID = d["request_id"]
    def P(short, syms, prems, concl):
        return PROBLEM(f"{T}-{short.replace('.', '_')}", RID, sm[short], syms, prems, concl)
    def pk(*pairs): return [p[0] for p in pairs], [p[1] for p in pairs]
    TR = TASK("t_rain", "9.5", "time of peak rainfall in both storms (decimal hours, 09:30)")
    TP1 = TASK("t_pk1", "21.5", "time of peak discharge in Storm 1 (decimal hours, 21:30)")
    TP2 = TASK("t_pk2", "14", "time of peak discharge in Storm 2 (decimal hours, 14:00)")
    Q1 = TASK("q1", "5.4", "peak discharge in Storm 1 (m3 s-1)")
    Q2 = TASK("q2", "16.2", "peak discharge in Storm 2 (m3 s-1)")
    WID = TASK("width", "6.0", "width of the channel at the gauging station (m)")
    DEP = TASK("depth", "1.8", "mean depth of the channel (m)")
    VEL = TASK("vel", "1.5", "mean velocity of flow (m s-1)")
    BU06 = TASK("bu06", "8", "built-up share of the catchment in 2006 (%)", "Int")
    BU24 = TASK("bu24", "31", "built-up share of the catchment in 2024 (%)", "Int")
    RN1 = TASK("rain1", "38", "rainfall in Storm 1 (mm)", "Int")
    RN2 = TASK("rain2", "36", "rainfall in Storm 2 (mm)", "Int")
    E = {}
    E["g1.1"] = NULL("Heading of the question: Paper 1, Option A (Freshwater).", "a heading with no assertion to check")
    s, p = pk(TR, TP1)
    E["g2.2"] = ENTRY(P("g2.2", s, p, CONC("c_g22", EQ(SUB(V("t_pk1"), V("t_rain")), R("12")), "Storm 1 lag = 21:30 - 09:30 = 12 hours")),
                      "Lag = peak time minus rainfall peak time, in decimal hours.", s)
    s, p = pk(TR, TP2)
    E["g2.3"] = ENTRY(P("g2.3", s, p, CONC("c_g23", EQ(SUB(V("t_pk2"), V("t_rain")), R("4.5")), "Storm 2 lag = 14:00 - 09:30 = 4 hours 30 minutes = 4.5 hours")),
                      "Lag in decimal hours.", s)
    s, p = pk(TR, TP1, TP2)
    E["g2.4"] = ENTRY(P("g2.4", s, p, CONC("c_g24", AND(EQ(SUB(V("t_pk1"), V("t_rain")), R("12")), EQ(SUB(V("t_pk2"), V("t_rain")), R("4.5"))),
                                           "lag time of 12 hours for Storm 1 and 4.5 hours for Storm 2")),
                      "Both lags from the peak and rainfall times.", s)
    s, p = pk(Q1, Q2)
    pct = EQ(MUL(R("100"), DIV(SUB(R("16.2"), R("5.4")), R("5.4"))), R("200"))
    E["g3.1"] = ENTRY(P("g3.1", s, p, CONC("c_g31", pct, "percentage change = (16.2 - 5.4) / 5.4 x 100 = 200%")),
                      "Percentage change from the two peak discharges, with the old value 5.4 as the divisor.", s)
    E["g3.2"] = ENTRY(P("g3.2", s, p, CONC("c_g32", pct, "the peak discharge rose by 200%, from 5.4 m3 s-1 in Storm 1 to 16.2 m3 s-1 in Storm 2")),
                      "Same percentage change as g3.1, stated as a result.", s)
    E["g3.3"] = ENTRY(P("g3.3", s, p, CONC("c_g33", EQ(DIV(R("16.2"), R("5.4")), R("3")), "this is a threefold increase (16.2 / 5.4 = 3.0)")),
                      "Ratio of the peak discharges.", s)
    E["g4.2"] = ENTRY(P("g4.2", [], [], CONC("c_g42", EQ(MUL(R("6.0"), R("1.8")), R("10.8")), "cross-sectional area = 6.0 m x 1.8 m = 10.8 m2")), "Product of width and mean depth.", [])
    s, p = pk(WID, DEP, VEL, Q2)
    E["g4.3"] = ENTRY(P("g4.3", s, p, CONC("c_g43", EQ(MUL(R("10.8"), R("1.5")), R("16.2")), "Q = 10.8 m2 x 1.5 m s-1 = 16.2 m3 s-1")),
                      "Discharge as area times velocity, with the area written as its constant value.", s)
    s, p = pk(WID, DEP, VEL, Q2)
    E["g4.4"] = ENTRY(P("g4.4", s, p, CONC("c_g44", EQ(MUL(R("10.8"), R("1.5")), R("16.2")), "the calculated discharge is 16.2 m3 s-1")),
                      "Area 10.8 m2 times 1.5 m s-1.", s)
    s, p = pk(Q2)
    E["g4.5"] = ENTRY(P("g4.5", s, p, CONC("c_g45", EQ(MUL(R("10.8"), R("1.5")), V("q2")), "the calculated discharge agrees with the recorded peak of 16.2 m3 s-1 at 14:00 in Storm 2")),
                      "Calculated discharge equals the recorded Storm 2 peak.", s)
    # g5.1 point: more surface runoff -> higher peak
    syms = [bool_s("runoff_up", "more surface runoff occurs"), bool_s("volume_fast", "a larger volume of water reaches the channel in a short time"),
            bool_s("peak_up", "the peak discharge rises")]
    prems = [PREM("p_a", IMP(V("runoff_up"), V("volume_fast")), "more surface runoff means a larger volume reaches the channel quickly", G("specialist_inference")),
             PREM("p_b", IMP(V("volume_fast"), V("peak_up")), "a larger volume in a short time raises the peak discharge", G("specialist_inference"))]
    E["g5.1"] = ENTRY(P("g5.1", syms, prems, CONC("c_g51", IMP(V("runoff_up"), V("peak_up")), "more surface runoff gives a higher peak")),
                      "Two specialist links chained.", syms)
    # g5.2 roofs replace permeable ground
    syms = [bool_s("replace", "roofs, roads and car parks replace permeable ground", "general_knowledge"),
            bool_s("runoff_up", "more rain runs straight off the surface")]
    prems = [PREM("p_rep", V("replace"), "roofs, roads and car parks replace permeable ground", G("general_knowledge"))]
    E["g5.2"] = ENTRY(P("g5.2", syms, prems, CONC("c_g52", IMP(V("replace"), V("runoff_up")), "less rain soaks in and more runs straight off the surface")),
                      "The stated fact is the premise; the link to runoff is the specialist's bare inference, which no stated premise supports, so the check reports it as not entailed.", syms,
                      flags=[FLAG("bare-link", "the step from replaced ground to more runoff is asserted without a premise stating it", ["general hydrology: impermeable surfaces increase runoff", "specialist assertion only"])])
    # g5.3 larger volume -> peak rises (bare link)
    syms = [bool_s("volume_fast", "a larger volume of water reaches the channel in a short time"), bool_s("peak_up", "the peak discharge rises")]
    E["g5.3"] = ENTRY(P("g5.3", syms, [], CONC("c_g53", IMP(V("volume_fast"), V("peak_up")), "a larger volume in a short time means the peak discharge rises")),
                      "The claim is the link itself; no premise states it, so the check reports it as not entailed.", syms,
                      flags=[FLAG("bare-link", "the link from a larger short-time volume to a higher peak is asserted without a premise", ["hydrological rationale", "specialist assertion only"])])
    # g5.4 built-up 8 -> 31; storm 2 200% higher; similar rainfall
    s, p = pk(BU06, BU24, RN1, RN2, Q1, Q2)
    concl = CONC("c_g54", AND(GT(V("bu24"), V("bu06")), EQ(MUL(R("100"), DIV(SUB(R("16.2"), R("5.4")), R("5.4"))), R("200")), LE(SUB(V("rain1"), V("rain2")), I(2))),
                 "between 2006 and 2024 the built-up share rose from 8% to 31%, and Storm 2 produced a peak 200% higher than Storm 1 from similar rainfall (36 mm against 38 mm)")
    E["g5.4"] = ENTRY(P("g5.4", s, p, concl), "Built-up share increase, the 200% peak change, and the rainfall difference of 2 mm.", s, ambiguous=True,
                      flags=[FLAG("vague-similar", "'similar rainfall' has no stated tolerance", ["within 2 mm (a difference of at most 2 mm)", "a judgement that the storms had comparable rainfall"])])
    # g5.5 consistent, soil moisture not recorded
    s, p = pk(Q1, Q2, BU06, BU24)
    syms = s + [bool_s("peak_gt", "storm 2 peak exceeds storm 1 peak"), bool_s("built_rose", "the built-up share rose"),
                bool_s("consistent", "the larger peak is consistent with the change in the catchment"),
                SYM("soil_rec", "Bool", "the data record soil moisture before each storm", G("supplied_text", note="structural fact about the data"))]
    prems = p + [PREM("p_pk", GT(V("q2"), V("q1")), "the Storm 2 peak exceeds the Storm 1 peak", G("arithmetic_fact")),
                 PREM("p_bu", GT(V("bu24"), V("bu06")), "the built-up share rose", G("arithmetic_fact")),
                 PREM("p_link", IMP(AND(V("peak_gt"), V("built_rose")), V("consistent")), "a larger peak alongside a rising built-up share is consistent with the change", G("specialist_inference")),
                 PREM("p_nosoil", NOT(V("soil_rec")), "the data do not record soil moisture before each storm", G("supplied_text", note="structural fact about the data"))]
    # link the Bool flags to the arithmetic facts
    prems.append(PREM("p_flag_pk", V("peak_gt"), "storm 2 peak exceeds storm 1 peak (flag)", G("arithmetic_fact"), "supporting"))
    prems.append(PREM("p_flag_bu", V("built_rose"), "built-up share rose (flag)", G("arithmetic_fact"), "supporting"))
    concl = CONC("c_g55", AND(V("consistent"), NOT(V("soil_rec"))), "the larger peak is consistent with the change in the catchment, and soil moisture before each storm is not recorded")
    E["g5.5"] = ENTRY(P("g5.5", syms, prems, concl), "Consistency from the two arithmetic facts; the missing soil-moisture record is the stated limitation.", syms,
                      ambiguous=True, flags=[FLAG("hedge", "'consistent with' is weaker than a causal claim and the soil-moisture caveat is hedged", ["consistent with the change (not caused by it)", "the change explains the peak"])])
    # g6.1 drains -> shorter lag
    syms = [bool_s("drains", "gutters, storm drains and sewers are added to the catchment"), bool_s("faster_water", "water reaches the channel faster after rain"),
            bool_s("shorter_lag", "the lag time is shortened")]
    prems = [PREM("p_a", IMP(V("drains"), V("faster_water")), "drains carry water to the brook faster than the ground would", G("specialist_inference")),
             PREM("p_b", IMP(V("faster_water"), V("shorter_lag")), "water reaching the channel sooner shortens the lag", G("specialist_inference"))]
    E["g6.1"] = ENTRY(P("g6.1", syms, prems, CONC("c_g61", IMP(V("drains"), V("shorter_lag")), "drains and sewers shorten the lag time")),
                      "Two specialist links chained.", syms)
    syms = [bool_s("drains", "gutters, storm drains and sewers are added to the catchment"), bool_s("faster_water", "water reaches the channel faster after rain")]
    E["g6.2"] = ENTRY(P("g6.2", syms, [], CONC("c_g62", IMP(V("drains"), V("faster_water")), "gutters, storm drains and sewers carry water to the brook faster than the ground would, so it reaches the channel sooner")),
                      "The claim is the link itself; no premise states it, so the check reports it as not entailed.", syms,
                      flags=[FLAG("bare-link", "the drains-to-faster-water link is asserted without a premise", ["hydrological rationale", "specialist assertion only"])])
    # g6.3 same rainfall peak times -> difference from catchment
    s, p = pk(TASK("rain_t1", "9.5", "time of peak rainfall in Storm 1 (decimal hours)"), TASK("rain_t2", "9.5", "time of peak rainfall in Storm 2 (decimal hours)"))
    syms = s + [bool_s("timing_catch", "the difference in lag timing comes from the catchment itself")]
    prems = p + [PREM("p_link", IMP(EQ(V("rain_t1"), V("rain_t2")), V("timing_catch")), "with equal rainfall peak times the timing difference comes from the catchment", G("specialist_inference"))]
    E["g6.3"] = ENTRY(P("g6.3", syms, prems, CONC("c_g63", V("timing_catch"), "both storms had peak rainfall at 09:30, so the difference in timing comes from the catchment itself")),
                      "Equal rainfall times from the question, then the specialist's inference.", syms)
    # g6.4 lag 12 -> 4.5 consistent with drainage
    syms = [SYM("lag06", "Real", "lag time in 2006 (hours)", G("task_setting")), SYM("lag24", "Real", "lag time in 2024 (hours)", G("task_setting")),
            bool_s("consistent_drain", "the fall in lag is consistent with a more developed drainage network")]
    prems = [PREM("p_l06", EQ(V("lag06"), R("12")), "the lag was 12 hours in 2006", G("task_setting", note="given in the question"), "supporting"),
             PREM("p_l24", EQ(V("lag24"), R("4.5")), "the lag was 4.5 hours in 2024", G("task_setting", note="given in the question"), "supporting"),
             PREM("p_link", IMP(GT(V("lag06"), V("lag24")), V("consistent_drain")), "a fall in lag time is consistent with a more developed drainage network", G("specialist_inference"))]
    concl = CONC("c_g64", AND(EQ(SUB(V("lag06"), V("lag24")), R("7.5")), V("consistent_drain")),
                 "the lag time fell from 12 hours in 2006 to 4.5 hours in 2024, which is consistent with a more developed drainage network")
    E["g6.4"] = ENTRY(P("g6.4", syms, prems, concl), "Lag difference 7.5 hours and the specialist's consistency link.", syms)
    emit(T, d["report_id"], E, sm)

def bool_s(name, meaning, g="specialist_inference"):
    return SYM(name, "Bool", meaning, G(g))

if __name__ == "__main__":
    gen_gep9()
