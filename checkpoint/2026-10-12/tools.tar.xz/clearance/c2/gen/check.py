import json, sys
sys.path.insert(0, "/home/user/https-github.com-lovishchopra-NL2FOL/src")
from epinoic_logic.engine import parse_and_validate
BASE = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2"
tasks = sys.argv[1:]
for t in tasks:
    tr = json.load(open(f"{BASE}/translations/{t}.json", encoding="utf-8"))
    spec = json.load(open(f"{BASE}/specialists/{t}.json", encoding="utf-8"))
    docs = {s["document_id"]: s["text"] for s in spec.get("supplied_texts", [])}
    bad = 0; ok = 0; nul = 0
    for cid, e in tr["claims"].items():
        p = e["problem"]
        # excerpt check
        def walk(obj):
            if isinstance(obj, dict):
                if obj.get("kind") == "quotation":
                    for r in obj["source_refs"]:
                        if r["excerpt"] not in docs.get(r["document_id"], ""):
                            print("  EXCERPT NOT FOUND", t, cid, r["excerpt"][:60])
                for v in obj.values(): walk(v)
            elif isinstance(obj, list):
                for v in obj: walk(v)
        walk(e)
        if p is None:
            nul += 1
            continue
        pr, o = parse_and_validate(json.dumps(p))
        if o.ok:
            ok += 1
        else:
            bad += 1
            print("FAIL", t, cid, str(o)[:600])
    print(t, "ok", ok, "null", nul, "fail", bad)
