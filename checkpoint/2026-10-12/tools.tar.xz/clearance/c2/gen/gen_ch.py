from common import *

def pk(*pairs): return [p[0] for p in pairs], [p[1] for p in pairs]

def bool_s(name, meaning, g="specialist_inference"): return SYM(name, "Bool", meaning, G(g))

# ---------------- chemistry: ch-t15 ----------------
def gen_ch15():
    T = "ch-t15"
    d, sm = load_listing(T); RID = d["request_id"]
    def P(short, syms, prems, concl):
        return PROBLEM(f"{T}-{short.replace('.', '_')}", RID, sm[short], syms, prems, concl)
    E = {}
    BNN = TASK("bond_nn", "945", "N≡N average bond enthalpy (kJ mol-1)", "Int")
    BHH = TASK("bond_hh", "436", "H–H average bond enthalpy (kJ mol-1)", "Int")
    BNH = TASK("bond_nh", "391", "N–H average bond enthalpy (kJ mol-1)", "Int")
    CN2 = TASK("c_n2", "1", "stoichiometric coefficient of N2 in the equation", "Int")
    CH2 = TASK("c_h2", "3", "stoichiometric coefficient of H2 in the equation", "Int")
    CNH3 = TASK("c_nh3", "2", "stoichiometric coefficient of NH3 in the equation", "Int")
    N2V = TASK("n2_vol", "600", "volume of nitrogen mixed (cm3)", "Int")
    H2V = TASK("h2_vol", "1500", "volume of hydrogen mixed (cm3)", "Int")
    # s2.1 balanced equation atom counts
    concl = CONC("c_s21", AND(EQ(MUL(I(1), I(2)), MUL(I(2), I(1))), EQ(MUL(I(3), I(2)), MUL(I(2), I(3)))),
                 "N2(g) + 3H2(g) ⇌ 2NH3(g) is balanced: 2 N atoms and 6 H atoms on each side")
    E["s2.1"] = ENTRY(P("s2.1", [], [], concl), "Atom counts on each side of the equation.", [])
    s, p = pk(BNN, BHH)
    E["s3.1"] = ENTRY(P("s3.1", s, p, CONC("c_s31", EQ(ADD(MUL(I(1), V("bond_nn")), MUL(I(3), V("bond_hh"))), I(2253)), "bonds broken: 945 + 3 x 436 = 2253 kJ")),
                      "Bond enthalpies from the question times stoichiometric counts.", s)
    s, p = pk(BNH)
    E["s3.2"] = ENTRY(P("s3.2", s, p, CONC("c_s32", EQ(MUL(I(6), V("bond_nh")), I(2346)), "bonds formed: 6 x 391 = 2346 kJ")),
                      "Six N-H bonds in two NH3 molecules.", s)
    s, p = pk(BNN, BHH, BNH)
    concl = CONC("c_s33", EQ(SUB(ADD(MUL(I(1), V("bond_nn")), MUL(I(3), V("bond_hh"))), MUL(I(6), V("bond_nh"))), I(-93)),
                 "delta H = 2253 - 2346 = -93 kJ mol-1")
    E["s3.3"] = ENTRY(P("s3.3", s, p, concl), "Broken minus formed bond enthalpies.", s)
    E["s4.1"] = ENTRY(P("s4.1", [CNH3[0]], [PREM("p_cnh3", EQ(V("c_nh3"), I(2)), "the equation as written forms 2 mol NH3", G("task_setting", note="coefficient in the equation given in the question"), "supporting")],
                        CONC("c_s41", EQ(MUL(V("c_nh3"), I(3)), I(6)), "the reaction as written forms 2 mol NH3, which contains 6 N-H bonds")),
                      "Coefficient 2 of NH3 times three N-H bonds each.", [CNH3[0]])
    # s6.2 approximation
    syms = [bool_s("mean_vals", "average bond enthalpies are mean values taken over many compounds", "general_knowledge"),
            bool_s("gas_model", "the calculation treats every species as a gas", "assumption"),
            bool_s("approx", "the calculated value is only an approximation of the true enthalpy change")]
    prems = [PREM("p_mean", V("mean_vals"), "average bond enthalpies are mean values over many compounds", G("general_knowledge")),
             PREM("p_gas", V("gas_model"), "every species is treated as a gas", G("assumption")),
             PREM("p_approx", IMP(AND(V("mean_vals"), V("gas_model")), V("approx")), "mean values and the gas treatment make the value an approximation", G("specialist_inference"))]
    E["s6.2"] = ENTRY(P("s6.2", syms, prems, CONC("c_s62", V("approx"), "the calculated value is only an approximation of the true enthalpy change")),
                      "Two stated limitations and the specialist's link to approximation.", syms)
    # s8.1 volume ratio = mole ratio
    syms = [bool_s("avog", "equal volumes of gases at the same T and P contain equal numbers of molecules", "general_knowledge"),
            bool_s("volmol", "the volume ratio equals the mole ratio"), CN2[0], CH2[0], CNH3[0]]
    prems = [PREM("p_avog", V("avog"), "equal volumes of gases at the same temperature and pressure contain equal numbers of molecules", G("general_knowledge")),
             PREM("p_link", IMP(V("avog"), V("volmol")), "so the volume ratio equals the mole ratio", G("specialist_inference")),
             PREM("p_c", AND(EQ(V("c_n2"), I(1)), EQ(V("c_h2"), I(3)), EQ(V("c_nh3"), I(2))), "the equation gives N2 : H2 : NH3 = 1 : 3 : 2", G("task_setting", note="given in the question"), "supporting")]
    concl = CONC("c_s81", AND(V("volmol"), EQ(V("c_h2"), MUL(I(3), V("c_n2"))), EQ(V("c_nh3"), MUL(I(2), V("c_n2")))),
                 "at the same temperature and pressure the volume ratio equals the mole ratio N2 : H2 : NH3 = 1 : 3 : 2")
    E["s8.1"] = ENTRY(P("s8.1", syms, prems, concl), "Avogadro-based reading of gas volumes, and the stoichiometric ratio.", syms)
    # s8.2 3 x 600 = 1800
    s, p = pk(N2V)
    E["s8.2"] = ENTRY(P("s8.2", s, p, CONC("c_s82", EQ(MUL(I(3), V("n2_vol")), I(1800)), "hydrogen needed for 600 cm3 of N2 is 3 x 600 = 1800 cm3")),
                      "Ratio 3 applied to 600 cm3.", s)
    # s8.3 limiting reactant hydrogen
    syms = [H2V, (SYM("h2_lim", "Bool", "hydrogen is the limiting reactant", G("specialist_inference")), None)]
    s, p = pk(H2V)
    syms = s + [bool_s("h2_lim", "hydrogen is the limiting reactant")]
    prems = p + [PREM("p_lim", IMP(GT(I(1800), V("h2_vol")), V("h2_lim")), "if the hydrogen needed (1800 cm3) exceeds the hydrogen available, hydrogen is limiting", G("specialist_inference"))]
    concl = CONC("c_s83", AND(GT(I(1800), V("h2_vol")), V("h2_lim")), "only 1500 cm3 of H2 is available, so hydrogen is the limiting reactant")
    E["s8.3"] = ENTRY(P("s8.3", syms, prems, concl), "Required 1800 cm3 against available 1500 cm3.", syms)
    # s8.4 1500/3 = 500
    s, p = pk(H2V)
    E["s8.4"] = ENTRY(P("s8.4", s, p, CONC("c_s84", EQ(IDIV(V("h2_vol"), I(3)), I(500)), "nitrogen needed for 1500 cm3 of H2 is 1500 / 3 = 500 cm3")),
                      "Integer division by the ratio 3 (exact).", s)
    # s8.5 nitrogen in excess
    s, p = pk(N2V, H2V)
    E["s8.5"] = ENTRY(P("s8.5", s, p, CONC("c_s85", GT(V("n2_vol"), IDIV(V("h2_vol"), I(3))), "since 600 cm3 is available, nitrogen is in excess")),
                      "600 exceeds the 500 cm3 needed.", s)
    # s8.6 volume of NH3 = 1000
    s, p = pk(H2V)
    E["s8.6"] = ENTRY(P("s8.6", s, p, CONC("c_s86", EQ(IDIV(MUL(I(2), V("h2_vol")), I(3)), I(1000)), "volume of NH3 = 1500 x (2 / 3) = 1000 cm3")),
                      "Exact integer arithmetic: 2 x 1500 / 3 = 1000.", s)
    # s8.7 maximum NH3 = 1.00e3
    s, p = pk(H2V)
    syms = s + [bool_s("h2_lim", "hydrogen is the limiting reactant")]
    prems = p + [PREM("p_lim", IMP(GT(I(1800), V("h2_vol")), V("h2_lim")), "hydrogen needed (1800 cm3) exceeds hydrogen available, so it is limiting", G("specialist_inference")),
                 PREM("p_gt", GT(I(1800), V("h2_vol")), "1800 cm3 exceeds 1500 cm3", G("arithmetic_fact"))]
    concl = CONC("c_s87", AND(V("h2_lim"), GE(IDIV(MUL(I(2), V("h2_vol")), I(3)), I(995)), LT(IDIV(MUL(I(2), V("h2_vol")), I(3)), I(1005))),
                 "the maximum volume of ammonia is 1.00 x 10^3 cm3 at the same temperature and pressure")
    E["s8.7"] = ENTRY(P("s8.7", syms, prems, concl), "Maximum NH3 limited by H2: 1000 cm3, stated to 3 s.f. (interval [995, 1005)).", syms)
    # s10.1 percentage yield 15.0%
    syms = [SYM("actual_nh3", "Int", "actual volume of ammonia formed (cm3)", G("task_setting", note="given in the question")),
            SYM("theo_nh3", "Int", "theoretical volume of ammonia (cm3)", G("specialist_inference"))]
    prems = [PREM("p_act", EQ(V("actual_nh3"), I(150)), "the mixture formed 150 cm3 of ammonia", G("task_setting", note="given in the question"), "supporting"),
             PREM("p_theo", EQ(V("theo_nh3"), I(1000)), "the theoretical volume is 1000 cm3", G("specialist_inference"), "supporting")]
    concl = CONC("c_s101", EQ(MUL(R("100"), TOREAL(V("actual_nh3"))), MUL(R("15"), TOREAL(V("theo_nh3")))), "percentage yield = 150 / 1000 x 100 = 15.0%")
    E["s10.1"] = ENTRY(P("s10.1", syms, prems, concl), "Yield ratio checked in cross-multiplied form.", syms)
    E["s11.1"] = NULL("A heading for the Kc calculation.", "heading naming the calculation, with no assertion beyond the label")
    # s12.1 method statement
    E["s12.1"] = NULL("Method statement: concentration = amount / volume with V = 2.00 dm3.",
                      "a method statement without a result of its own; its numbers are checked under s12.2 to s12.4")
    for short, sym, val, res in [("s12.2", "n_n2", "0.400", "0.200"), ("s12.3", "n_h2", "1.20", "0.600"), ("s12.4", "n_nh3", "0.200", "0.100")]:
        meaning = {"n_n2": "amount of N2 at equilibrium (mol)", "n_h2": "amount of H2 at equilibrium (mol)", "n_nh3": "amount of NH3 at equilibrium (mol)"}[sym]
        syms = [SYM(sym, "Real", meaning, G("task_setting", note="given in the question"))]
        prems = [PREM("p_" + sym, EQ(V(sym), R(val)), f"the equilibrium amount is {val} mol", G("task_setting", note="given in the question"), "supporting")]
        concl = CONC("c_" + short.replace(".", "_"), EQ(DIV(V(sym), R("2.00")), R(res)), f"concentration = {val} / 2.00 = {res} mol dm-3")
        E[short] = ENTRY(P(short, syms, prems, concl), "Amount divided by the constant volume 2.00 dm3.", syms)
    # s13.1 Kc = 25/108 ~ 0.231
    concl = CONC("c_s131", AND(EQ(DIV(R("0.01"), R("0.0432")), R("25/108")), GE(R("25/108"), R("0.2305")), LT(R("25/108"), R("0.2315"))),
                 "Kc = (0.100)^2 / (0.200 x 0.600^3) = 0.0100 / 0.0432 = 0.231 dm6 mol-2 (3 s.f.)")
    E["s13.1"] = ENTRY(P("s13.1", [], [], concl), "Kc from the equilibrium concentrations; 0.0100 / 0.0432 = 25/108 = 0.2315 (rounded to 0.231).", [])
    # s15.1 Kc decreases when temperature increases (exothermic)
    syms = [SYM("dh", "Int", "enthalpy change of the reaction (kJ mol-1)", G("specialist_inference")),
            bool_s("exo", "the forward reaction is exothermic", "general_knowledge"),
            bool_s("temp_up", "the temperature increases", "assumption"),
            bool_s("shift_left", "the position of equilibrium shifts left"),
            bool_s("kc_falls", "Kc decreases")]
    prems = [PREM("p_dh", EQ(V("dh"), I(-93)), "the enthalpy change is -93 kJ mol-1 (part a)", G("specialist_inference")),
             PREM("p_exo", IMP(LT(V("dh"), I(0)), V("exo")), "a negative enthalpy change means an exothermic reaction", G("general_knowledge")),
             PREM("p_shift", IMP(AND(V("exo"), V("temp_up")), V("shift_left")), "a rise in temperature shifts an exothermic equilibrium left", G("general_knowledge")),
             PREM("p_kc", IMP(V("shift_left"), V("kc_falls")), "a shift to the left gives fewer products and so a lower Kc", G("specialist_inference"))]
    concl = CONC("c_s151", IMP(V("temp_up"), V("kc_falls")), "an increase in temperature makes Kc decrease")
    E["s15.1"] = ENTRY(P("s15.1", syms, prems, concl), "Conditional on a temperature rise: exothermic reaction, leftward shift, lower Kc.", syms)
    # s15.4 fewer products -> Kc falls (mechanism)
    syms = [bool_s("shift_left", "the position of equilibrium shifts left", "specialist_inference"),
            bool_s("fewer_prod", "fewer products and more reactants are present at equilibrium", "general_knowledge"),
            bool_s("kc_falls", "Kc falls")]
    prems = [PREM("p_l1", IMP(V("shift_left"), V("fewer_prod")), "a leftward shift leaves fewer products at equilibrium", G("general_knowledge")),
             PREM("p_l2", IMP(V("fewer_prod"), V("kc_falls")), "fewer products and more reactants lower Kc", G("specialist_inference"))]
    concl = CONC("c_s154", IMP(V("shift_left"), V("kc_falls")), "fewer products and more reactants at equilibrium, so Kc falls")
    E["s15.4"] = ENTRY(P("s15.4", syms, prems, concl), "Mechanism from a leftward shift to lower Kc.", syms)
    E["s16.1"] = NULL("A heading: why high pressure and a moderate temperature are used.", "heading for the answer's sections; the content is in s17.1 to s17.4")
    # s17.1 high pressure
    syms = [bool_s("p_inc", "the pressure increases", "assumption"),
            SYM("n_react", "Int", "moles of gas on the reactant side", G("general_knowledge")),
            SYM("n_prod", "Int", "moles of gas on the product side", G("general_knowledge")),
            bool_s("shift_right", "the position shifts to the side with fewer gas molecules", "general_knowledge"),
            bool_s("yield_up", "the equilibrium yield of ammonia increases")]
    prems = [PREM("p_nr", EQ(V("n_react"), I(4)), "reactants give 1 + 3 = 4 mol gas", G("general_knowledge")),
             PREM("p_np", EQ(V("n_prod"), I(2)), "products give 2 mol gas", G("general_knowledge")),
             PREM("p_shift", IMP(AND(V("p_inc"), LT(V("n_prod"), V("n_react"))), V("shift_right")), "an increase in pressure shifts equilibrium to the side with fewer gas molecules", G("general_knowledge")),
             PREM("p_yield", IMP(V("shift_right"), V("yield_up")), "the shift to the right increases the yield", G("specialist_inference"))]
    concl = CONC("c_s171", IMP(V("p_inc"), V("yield_up")), "high pressure shifts the position to the right and the equilibrium yield increases")
    E["s17.1"] = ENTRY(P("s17.1", syms, prems, concl), "Le Chatelier on gas moles, then the yield link.", syms)
    syms = [bool_s("p_inc", "the pressure increases", "assumption"), bool_s("freq_up", "the frequency of collisions increases", "general_knowledge"),
            bool_s("rate_up", "the rate of reaction increases", "general_knowledge")]
    prems = [PREM("p_f", IMP(V("p_inc"), V("freq_up")), "higher pressure increases the frequency of collisions", G("general_knowledge")),
             PREM("p_r", IMP(V("freq_up"), V("rate_up")), "more frequent collisions increase the rate", G("general_knowledge"))]
    E["s17.2"] = ENTRY(P("s17.2", syms, prems, CONC("c_s172", IMP(V("p_inc"), V("rate_up")), "higher pressure increases the rate of reaction")),
                       "Collision-frequency chain.", syms)
    syms = [SYM("dh", "Int", "enthalpy change of the reaction (kJ mol-1)", G("specialist_inference")),
            bool_s("exo", "the forward reaction is exothermic", "general_knowledge"),
            bool_s("temp_low", "the temperature is lower"), bool_s("yield_up_t", "a lower temperature gives a higher equilibrium yield", "general_knowledge")]
    prems = [PREM("p_dh", EQ(V("dh"), I(-93)), "the enthalpy change is -93 kJ mol-1", G("specialist_inference")),
             PREM("p_exo", IMP(LT(V("dh"), I(0)), V("exo")), "a negative enthalpy change means an exothermic reaction", G("general_knowledge")),
             PREM("p_t", IMP(V("exo"), IMP(V("temp_low"), V("yield_up_t"))), "for an exothermic reaction a lower temperature gives a higher yield", G("general_knowledge"))]
    E["s17.3"] = ENTRY(P("s17.3", syms, prems, CONC("c_s173", IMP(V("temp_low"), V("yield_up_t")), "a lower temperature would give a higher equilibrium yield, because the forward reaction is exothermic")),
                       "Exothermic reaction and Le Chatelier.", syms)
    syms = [bool_s("temp_low", "the temperature is lower"), bool_s("fewer_energetic", "fewer particles have energy at least the activation energy", "general_knowledge"),
            bool_s("rate_slow", "the rate would be too slow", "general_knowledge")]
    prems = [PREM("p_fe", IMP(V("temp_low"), V("fewer_energetic")), "a lower temperature gives fewer particles above the activation energy", G("general_knowledge")),
             PREM("p_rs", IMP(V("fewer_energetic"), V("rate_slow")), "fewer particles above the activation energy slow the rate", G("general_knowledge"))]
    E["s17.4"] = ENTRY(P("s17.4", syms, prems, CONC("c_s174", IMP(V("temp_low"), V("rate_slow")), "however, at a lower temperature the rate would be too slow")),
                       "Activation-energy chain.", syms)
    emit(T, d["report_id"], E, sm)

# ---------------- chemistry: ch-p9b ----------------
def gen_chp9():
    T = "ch-p9b"
    d, sm = load_listing(T); RID = d["request_id"]
    def P(short, syms, prems, concl):
        return PROBLEM(f"{T}-{short.replace('.', '_')}", RID, sm[short], syms, prems, concl)
    E = {}
    E["s1.1"] = NULL("A list of constants taken from the question.", "a restatement of constants given in the question; no proposition to check")
    NA = SYM("na", "Real", "Avogadro constant (mol-1)", G("general_knowledge"))
    E["s1.2"] = ENTRY(P("s1.2", [NA], [PREM("p_na", EQ(V("na"), R("602214076000000000000000")), "the Avogadro constant is 6.02214076 x 10^23 mol-1", G("general_knowledge"))],
                        CONC("c_s12", AND(GE(V("na"), R("601500000000000000000000")), LT(V("na"), R("602500000000000000000000"))),
                             "the Avogadro constant is 6.02 x 10^23 mol-1 (3 s.f.)")),
                      "Standard value to 3 s.f.", [NA])
    mC = TASK("mass_c", "12.01", "relative atomic mass of C"); mH = TASK("mass_h", "1.01", "relative atomic mass of H"); mO = TASK("mass_o", "16.00", "relative atomic mass of O")
    s, p = pk(mC, mH, mO)
    E["s3.1"] = ENTRY(P("s3.1", s, p, CONC("c_s31", EQ(ADD(MUL(R("12"), V("mass_c")), MUL(R("22"), V("mass_h")), MUL(R("11"), V("mass_o"))), R("342.34")), "M(C12H22O11) = 342.34 g mol-1")),
                      "Molar mass from the given relative atomic masses.", s)
    nsuc = SYM("n_suc", "Real", "amount of sucrose (mol), unrounded", G("arithmetic_fact"))
    E["s5.1"] = ENTRY(P("s5.1", [nsuc], [PREM("p_nM", EQ(MUL(R("342.34"), V("n_suc")), R("84.20")), "n x M = m for 84.20 g of sucrose with M = 342.34", G("arithmetic_fact"))],
                        CONC("c_s51", AND(GE(V("n_suc"), R("0.2459535")), LT(V("n_suc"), R("0.2459545"))), "n = 84.20 / 342.34 = 0.245954 mol (6 d.p.)")),
                      "Amount to six decimal places.", [nsuc])
    vol = SYM("vol_cm3", "Real", "volume of the stock flask (cm3)", G("task_setting", note="given in the question"))
    E["s5.2"] = ENTRY(P("s5.2", [vol], [PREM("p_vol", EQ(V("vol_cm3"), R("250.0")), "the flask is made up to 250.0 cm3", G("task_setting", note="given in the question"), "supporting")],
                        CONC("c_s52", EQ(MUL(R("0.001"), V("vol_cm3")), R("0.2500")), "250.0 cm3 = 0.2500 dm3")), "Unit conversion.", [vol])
    cst = SYM("c_stock", "Real", "concentration of the stock solution (mol dm-3)", G("arithmetic_fact"))
    E["s5.3"] = ENTRY(P("s5.3", [nsuc, cst], [PREM("p_n", EQ(V("n_suc"), R("8420/34234")), "n = 0.245954... mol unrounded", G("arithmetic_fact")),
                                              ],
                      CONC("c_s53", AND(EQ(MUL(R("0.25"), V("c_stock")), V("n_suc")), GE(V("c_stock"), R("0.9835")), LT(V("c_stock"), R("0.9845"))),
                           "c(stock) = n / V = 0.245954 / 0.2500 = 0.984 mol dm-3 (3 s.f.)")), "Concentration and rounding to 3 s.f.", [nsuc, cst])
    # s7.1 nonlinear formula -> null
    E["s7.1"] = NULL("Formula c(diluted) = c(stock) x V(pipetted) / 50.00.",
                     "a product of two non-constant quantities (stock concentration times pipetted volume) is outside IR 1.0; the specific dilutions are checked under s7.3 to s7.6")
    E["s7.2"] = NULL("Procedural note that the unrounded stock concentration is used.", "a note on method, not a proposition with a result to check")
    cs = SYM("c_stock", "Real", "stock concentration, unrounded (mol dm-3)", G("arithmetic_fact"))
    base_p = [PREM("p_cs", EQ(V("c_stock"), R("0.98382")), "the unrounded stock concentration is 0.98382 mol dm-3", G("arithmetic_fact"))]
    for short, fac, vol_, u5, u5lo, u5hi, sf_lo, sf_hi, sf in [
        ("s7.3", "0.2", "10.00", "0.19676", "0.196755", "0.196765", "0.1965", "0.1975", "0.197"),
        ("s7.4", "0.4", "20.00", "0.39353", "0.393525", "0.393535", "0.3935", "0.3945", "0.394"),
        ("s7.5", "0.6", "30.00", "0.59029", "0.590285", "0.590295", "0.5895", "0.5905", "0.590"),
        ("s7.6", "0.8", "40.00", "0.78706", "0.787055", "0.787065", "0.7865", "0.7875", "0.787")]:
        concl = CONC("c_" + short.replace(".", "_"), AND(GE(MUL(R(fac), V("c_stock")), R(u5lo)), LT(MUL(R(fac), V("c_stock")), R(u5hi)),
                                                       GE(MUL(R(fac), V("c_stock")), R(sf_lo)), LT(MUL(R(fac), V("c_stock")), R(sf_hi))),
                     f"{vol_} cm3 dilution: 0.98382 x ({vol_} / 50.00) = {u5} mol dm-3, so {sf} mol dm-3 (3 s.f.)")
        E[short] = ENTRY(P(short, [cs], base_p, concl), f"Dilution factor {vol_}/50.00 = {fac}; both the 5 d.p. and 3 s.f. statements checked.", [cs])
    # s9.2 mass uncertainty 0.0119%
    E["s9.2"] = ENTRY(P("s9.2", [], [], CONC("c_s92", AND(GE(R("5/421"), R("0.01185")), LT(R("5/421"), R("0.01195"))),
                                             "mass uncertainty: 0.01 / 84.20 x 100 = 0.0119%")),
                      "1/84.2 = 5/421 = 0.011876..., stated to 4 s.f.", [])
    E["s9.3"] = ENTRY(P("s9.3", [], [], CONC("c_s93", AND(EQ(MUL(R("100"), DIV(R("0.30"), R("250.0"))), R("0.12")), GE(R("0.12"), R("0.1195")), LT(R("0.12"), R("0.1205"))),
                                             "volume uncertainty: 0.30 / 250.0 x 100 = 0.120%")), "Volume uncertainty.", [])
    E["s9.4"] = ENTRY(P("s9.4", [], [], CONC("c_s94", AND(GE(ADD(R("0.0119"), R("0.120")), R("0.1315")), LT(ADD(R("0.0119"), R("0.120")), R("0.1325")),
                                                     GE(ADD(R("0.0119"), R("0.120")), R("0.125")), LT(ADD(R("0.0119"), R("0.120")), R("0.135"))),
                                             "percentage uncertainties add for a quotient: 0.0119 + 0.120 = 0.132%, so 0.13%")),
                      "Sum of the two percentage uncertainties; 0.1319 is 0.132 to 3 d.p. and 0.13 to 2 s.f.", [])
    E["s10.1"] = NULL("A heading: sucrose molecules in 1.00 cm3 of the most dilute solution.", "heading for the calculation under s11.1 to s11.4")
    cdil = SYM("c_dil", "Real", "concentration of the 10.00 cm3 dilution (mol dm-3), unrounded", G("arithmetic_fact"))
    E["s11.1"] = ENTRY(P("s11.1", [cs], base_p, CONC("c_s111", AND(GE(MUL(R("0.2"), V("c_stock")), R("0.196755")), LT(MUL(R("0.2"), V("c_stock")), R("0.196765")),
                                                             LT(R("10.00"), R("20.00")), LT(R("20.00"), R("30.00")), LT(R("30.00"), R("40.00"))),
                                                     "the most dilute solution is the 10.00 cm3 dilution, with c = 0.19676 mol dm-3 (unrounded)")),
                       "The 10.00 cm3 dilution has the smallest volume, hence the lowest concentration.", [cs])
    E["s11.2"] = ENTRY(P("s11.2", [], [], CONC("c_s112", EQ(MUL(R("0.001"), R("1.00")), R("0.00100")), "V = 1.00 cm3 = 1.00 x 10^-3 dm3")), "Unit conversion.", [])
    E["s11.3"] = ENTRY(P("s11.3", [cdil], [PREM("p_cd", EQ(V("c_dil"), R("0.19676")), "c = 0.19676 mol dm-3", G("arithmetic_fact"))],
                         CONC("c_s113", EQ(MUL(R("0.001"), V("c_dil")), R("0.00019676")), "n = c x V = 0.19676 x 1.00 x 10^-3 = 1.9676 x 10^-4 mol")),
                       "Amount from concentration and volume.", [cdil])
    nmol = SYM("n_mol", "Real", "amount of sucrose in 1.00 cm3 (mol)", G("arithmetic_fact"))
    E["s11.4"] = ENTRY(P("s11.4", [nmol], [PREM("p_nm", EQ(V("n_mol"), R("0.00019676")), "n = 1.9676 x 10^-4 mol", G("arithmetic_fact"))],
                         CONC("c_s114", AND(GE(MUL(V("n_mol"), R("602000000000000000000000")), R("117500000000000000000")),
                                            LT(MUL(V("n_mol"), R("602000000000000000000000")), R("118500000000000000000"))),
                              "N = 1.9676 x 10^-4 x 6.02 x 10^23 = 1.18 x 10^20 molecules (3 s.f.)")),
                       "Avogadro conversion to 3 s.f.", [nmol])
    E["s11.5"] = ENTRY(P("s11.5", [], [], CONC("c_s115", AND(GE(MUL(R("0.000197"), R("602000000000000000000000")), R("118500000000000000000")),
                                                        LT(MUL(R("0.000197"), R("602000000000000000000000")), R("119500000000000000000")),
                                                        GE(MUL(R("0.00019676"), R("602000000000000000000000")), R("117500000000000000000")),
                                                        LT(MUL(R("0.00019676"), R("602000000000000000000000")), R("118500000000000000000"))),
                                             "using the rounded 0.197 mol dm-3 gives 1.19 x 10^20, while the unrounded value gives 1.18 x 10^20")),
                       "Both the rounded and the unrounded routes to 3 s.f.", [])
    E["s12.1"] = NULL("A heading: why a volumetric flask is used.", "heading for the answer's explanation; the content is in s13.1 and s13.2")
    syms = [bool_s("single_mark", "a volumetric flask has a single calibrated mark", "general_knowledge"),
            bool_s("precise_vol", "the flask contains one precisely known volume", "general_knowledge")]
    prems = [PREM("p_mark", V("single_mark"), "a volumetric flask has a single calibrated mark", G("general_knowledge")),
             PREM("p_prec", IMP(V("single_mark"), V("precise_vol")), "a single mark gives one precisely known volume", G("general_knowledge"))]
    E["s13.1"] = ENTRY(P("s13.1", syms, prems, CONC("c_s131", V("precise_vol"), "a volumetric flask contains one precisely known volume, for example 250.0 cm3 ± 0.30 cm3")),
                       "General property of volumetric flasks; the example uncertainty is the question's.", syms)
    syms = [bool_s("cyl_less", "a measuring cylinder is less precise than a volumetric flask", "general_knowledge"),
            bool_s("vol_less", "the volume of each solution is less certain"), bool_s("conc_less", "the concentration is less certain")]
    prems = [PREM("p_c", V("cyl_less"), "a measuring cylinder is less precise", G("general_knowledge")),
             PREM("p_v", IMP(V("cyl_less"), V("vol_less")), "less precise measurement makes the volume less certain", G("specialist_inference")),
             PREM("p_cc", IMP(V("vol_less"), V("conc_less")), "volume uncertainty propagates to the concentration", G("specialist_inference"))]
    E["s13.2"] = ENTRY(P("s13.2", syms, prems, CONC("c_s132", IMP(V("cyl_less"), V("conc_less")), "with a measuring cylinder the concentration would be less certain")),
                       "Chain from precision to concentration uncertainty.", syms)
    E["s14.1"] = NULL("A heading for the concentrations list.", "heading for the list in s14.3 to s14.6")
    for short, fac, sf_lo, sf_hi, sf, unr_lo, unr_hi, vol_ in [
        ("s14.3", "1/5", "0.1965", "0.1975", "0.197", None, None, "10.00"),
        ("s14.4", "2/5", "0.3935", "0.3945", "0.394", None, None, "20.00"),
        ("s14.5", "3/5", "0.5895", "0.5905", "0.590", None, None, "30.00"),
        ("s14.6", "4/5", "0.7865", "0.7875", "0.787", None, None, "40.00")]:
        concl = CONC("c_" + short.replace(".", "_"), AND(GE(MUL(R(fac), V("c_stock")), R(sf_lo)), LT(MUL(R(fac), V("c_stock")), R(sf_hi))),
                     f"made from {vol_} cm3 of stock: {sf} mol dm-3 (3 s.f.)")
        E[short] = ENTRY(P(short, [cs], base_p, concl), f"Concentration {vol_}/50.00 of the stock, to 3 s.f.", [cs])
    E["s15.1"] = NULL("An imperative suggestion to try part (e).", "a suggestion to the student, not an assertion with a conclusion to check")
    emit(T, d["report_id"], E, sm)

if __name__ == "__main__":
    gen_ch15()
    gen_chp9()
