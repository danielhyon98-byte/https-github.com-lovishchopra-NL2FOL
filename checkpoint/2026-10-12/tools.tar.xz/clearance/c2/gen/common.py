import json
BASE = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2"

def V(n): return {"op": "var", "name": n}
def B(x): return {"op": "bool", "value": bool(x)}
def I(x): return {"op": "int", "value": str(x)}
def R(x): return {"op": "real", "value": str(x)}
def AND(*a): return {"op": "and", "args": list(a)}
def OR(*a): return {"op": "or", "args": list(a)}
def NOT(a): return {"op": "not", "arg": a}
def IMP(l, r): return {"op": "implies", "left": l, "right": r}
def IFF(l, r): return {"op": "iff", "left": l, "right": r}
def ADD(*a): return {"op": "add", "args": list(a)}
def MUL(*a): return {"op": "mul", "args": list(a)}
def SUB(l, r): return {"op": "sub", "left": l, "right": r}
def DIV(l, r): return {"op": "div", "left": l, "right": r}
def IDIV(l, r): return {"op": "idiv", "left": l, "right": r}
def TOREAL(a): return {"op": "to_real", "arg": a}
def EQ(l, r): return {"op": "eq", "left": l, "right": r}
def NE(l, r): return {"op": "ne", "left": l, "right": r}
def LT(l, r): return {"op": "lt", "left": l, "right": r}
def LE(l, r): return {"op": "le", "left": l, "right": r}
def GT(l, r): return {"op": "gt", "left": l, "right": r}
def GE(l, r): return {"op": "ge", "left": l, "right": r}

def Q(doc, excerpt, cert="established"):
    return {"kind": "quotation", "certainty": cert, "source_refs": [{"document_id": doc, "excerpt": excerpt}]}

def G(kind, cert="established", note=None):
    g = {"kind": kind, "certainty": cert, "source_refs": []}
    if note:
        g["note"] = note
    return g

def SYM(name, sort, meaning, grounding=None):
    return {"name": name, "sort": sort, "meaning": meaning, "grounding": grounding}

def PREM(pid, expr, label, grounding=None, mat="material"):
    return {"id": pid, "expr": expr, "label": label, "grounding": grounding, "materiality": mat}

def CONC(cid, expr, label, grounding=None):
    return {"id": cid, "expr": expr, "label": label, "grounding": grounding, "materiality": "material"}

def _has_var(e):
    if isinstance(e, dict):
        if e.get("op") == "var":
            return True
        return any(_has_var(v) for v in e.values())
    if isinstance(e, list):
        return any(_has_var(v) for v in e)
    return False

UNIT_SYM = SYM("unit", "Real", "the number one (arithmetic identity used to anchor constant-only conclusions)", G("arithmetic_fact"))
UNIT_PREM = PREM("p_unit", EQ(V("unit"), R("1")), "one equals one", G("arithmetic_fact"), "supporting")

def PROBLEM(pid, rid, cid, symbols, premises, conclusion, notes=None):
    symbols = list(symbols); premises = list(premises)
    if not _has_var(conclusion["expr"]):
        conclusion = dict(conclusion)
        conclusion["expr"] = AND(EQ(V("unit"), R("1")), conclusion["expr"])
        if all(s["name"] != "unit" for s in symbols):
            symbols.append(UNIT_SYM)
        if all(p["id"] != "p_unit" for p in premises):
            premises.append(UNIT_PREM)
    p = {"ir_version": "1.0", "problem_id": pid, "request_id": rid, "claim_id": cid,
         "query": "entailment", "symbols": symbols, "premises": premises, "conclusion": conclusion}
    if notes:
        p["notes"] = notes
    return p

def FLAG(code, msg, alts):
    return {"code": code, "message": msg, "alternatives": alts}

def ENTRY(problem, reading, symbols=(), ambiguous=False, flags=(), unsupported=None):
    gl = [{"symbol": s["name"], "meaning": s["meaning"], "grounding": s["grounding"]} for s in symbols]
    return {"problem": problem,
            "interpretation": {"reading": reading, "glossary": gl, "ambiguity_flags": list(flags)},
            "ambiguous": ambiguous, "unsupported_reason": unsupported}

def NULL(reading, reason, ambiguous=False, flags=()):
    return ENTRY(None, reading, (), ambiguous, flags, reason)

def DATA(name, value, doc, excerpt, meaning, sort="Int"):
    lit = I(value) if sort == "Int" else R(value)
    s = SYM(name, sort, meaning, Q(doc, excerpt))
    p = PREM("d_" + name, EQ(V(name), lit), f"the source gives {meaning} as {value}", Q(doc, excerpt), "supporting")
    return s, p

def TASK(name, value, meaning, sort="Real"):
    lit = I(value) if sort == "Int" else R(value)
    s = SYM(name, sort, meaning, G("task_setting", note="given in the question"))
    p = PREM("t_" + name, EQ(V(name), lit), f"the question gives {meaning} as {value}", G("task_setting", note="given in the question"), "supporting")
    return s, p

def load_listing(task_id):
    d = json.load(open(f"{BASE}/listings/{task_id}.json", encoding="utf-8"))
    short = {c["claim_id"].split("@")[0]: c["claim_id"] for c in d["claims"]}
    return d, short

def emit(task_id, report_id, entries_by_short, short_map):
    missing = [s for s in short_map if s not in entries_by_short]
    extra = [s for s in entries_by_short if s not in short_map]
    if missing or extra:
        raise SystemExit(f"{task_id}: missing={missing} extra={extra}")
    out = {"report_id": report_id, "claims": {short_map[s]: e for s, e in entries_by_short.items()}}
    with open(f"{BASE}/translations/{task_id}.json", "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print("wrote", task_id, len(out["claims"]))
