from common import *

# ---------------- maths: mai-t15 ----------------
def gen_mai():
    T = "mai-t15"
    d, sm = load_listing(T); RID = d["request_id"]
    def P(short, syms, prems, concl):
        return PROBLEM(f"{T}-{short.replace('.', '_')}", RID, sm[short], syms, prems, concl)
    def pk(*pairs): return [p[0] for p in pairs], [p[1] for p in pairs]
    AX = TASK("ax", "2", "x-coordinate of well A (km)"); AY = TASK("ay", "1", "y-coordinate of well A (km)")
    BX = TASK("bx", "8", "x-coordinate of well B (km)"); BY = TASK("by", "3", "y-coordinate of well B (km)")
    FX = TASK("fx", "5", "x-coordinate of the farmhouse P (km)"); FY = TASK("fy", "5", "y-coordinate of the farmhouse P (km)")
    base = pk(AX, AY, BX, BY)
    E = {}
    # m2.1 midpoint substitution
    concl = CONC("c_m21", AND(EQ(DIV(ADD(V("ax"), V("bx")), R("2")), DIV(ADD(R("2"), R("8")), R("2"))),
                              EQ(DIV(ADD(V("ay"), V("by")), R("2")), DIV(ADD(R("1"), R("3")), R("2")))),
                 "the midpoint of AB is ((2 + 8)/2, (1 + 3)/2)")
    s, p = base
    E["m2.1"] = ENTRY(P("m2.1", s, p, concl), "Substitution of the coordinates of A and B into the midpoint formula.", s)
    # m3.1 midpoint = (5,2)
    concl = CONC("c_m31", AND(EQ(DIV(ADD(V("ax"), V("bx")), R("2")), R("5")), EQ(DIV(ADD(V("ay"), V("by")), R("2")), R("2"))), "the midpoint of AB is (5, 2) km")
    E["m3.1"] = ENTRY(P("m3.1", s, p, concl), "Midpoint of A(2,1) and B(8,3) is (5,2).", s)
    # m4.1 gradient of AB = 1/3
    concl = CONC("c_m41", AND(NE(SUB(V("bx"), V("ax")), R("0")), EQ(MUL(R("1/3"), SUB(V("bx"), V("ax"))), SUB(V("by"), V("ay")))),
                 "the gradient of AB is 1/3")
    E["m4.1"] = ENTRY(P("m4.1", s, p, concl), "Gradient m satisfies m x (bx - ax) = by - ay with a non-zero run; checked as 1/3 x 6 = 2.", s)
    # m5.1 perpendicular gradient
    ms = [SYM("m_perp", "Real", "gradient of the perpendicular bisector of AB", None)]
    prems = [PREM("p_perp", EQ(MUL(R("1/3"), V("m_perp")), R("-1")), "the perpendicular gradient m satisfies (1/3) m = -1", G("general_knowledge"))]
    concl = CONC("c_m51", EQ(V("m_perp"), R("-3")), "the perpendicular gradient is m = -3")
    E["m5.1"] = ENTRY(P("m5.1", ms, prems, concl), "Perpendicular gradients multiply to -1, so m = -3.", ms)
    # m6.1 point-slope template
    E["m6.1"] = NULL("A line equation in free variables x and y, written as a template.",
                     "a line equation in free variables; IR 1.0 has no free-variable or quantified claims, so its content is checked under m7.1 and m8.1")
    # m7.1 line y = -3x + 17: intercept from midpoint (5,2)
    ms = [SYM("mdx", "Real", "x-coordinate of the midpoint of AB (km)", G("arithmetic_fact")),
          SYM("mdy", "Real", "y-coordinate of the midpoint of AB (km)", G("arithmetic_fact"))]
    prems = [PREM("p_mdx", EQ(V("mdx"), R("5")), "the midpoint of AB has x-coordinate 5", G("arithmetic_fact")),
             PREM("p_mdy", EQ(V("mdy"), R("2")), "the midpoint of AB has y-coordinate 2", G("arithmetic_fact"))]
    concl = CONC("c_m71", EQ(SUB(V("mdy"), MUL(R("-3"), V("mdx"))), R("17")), "the line through (5, 2) with gradient -3 is y = -3x + 17")
    E["m7.1"] = ENTRY(P("m7.1", ms, prems, concl), "Intercept c = y0 - m x0 = 2 - (-3)(5) = 17.", ms)
    # m8.1 check (6,-1) on line and squared distances
    concl = CONC("c_m81", AND(EQ(ADD(MUL(R("-3"), R("6")), R("17")), R("-1")),
                              EQ(ADD(MUL(R("4"), R("4")), MUL(R("-2"), R("-2"))), ADD(MUL(R("-2"), R("-2")), MUL(R("-4"), R("-4"))))),
                 "(6, -1) lies on the line, and (6 - 2)^2 + (-1 - 1)^2 = 20 = (6 - 8)^2 + (-1 - 3)^2")
    ms = [SYM("line_gradient_unit", "Real", "placeholder unit", None)] if False else []
    E["m8.1"] = ENTRY(P("m8.1", [], [], concl), "Constant check: the point (6,-1) satisfies y = -3x + 17 and the two squared distances are both 20.", [])
    # m9.1 symbolic equation in x -> null
    E["m9.1"] = NULL("Equating two line equations in the free variable x.",
                     "an equation in a free variable, not a closed claim; its solution and substitution are checked under m9.2, m10.1 and m13.1")
    # m9.2 solve: -3x+17 = (2/3)x+2 -> 11x = 45
    ms = [SYM("ix", "Real", "x-coordinate of the candidate point where the two bisectors meet (km)", None)]
    prems = [PREM("p_eq", EQ(ADD(MUL(R("-3"), V("ix")), R("17")), ADD(MUL(R("2/3"), V("ix")), R("2"))),
                  "the two perpendicular bisector equations are equal at the point", G("specialist_inference"))]
    concl = CONC("c_m92", EQ(MUL(R("11"), V("ix")), R("45")), "multiplying by 3 gives -9x + 51 = 2x + 6, so 11x = 45")
    E["m9.2"] = ENTRY(P("m9.2", ms, prems, concl), "Linear equation in x: multiply by 3, collect terms.", ms)
    # m10.1 x = 45/11
    ms = [SYM("ix", "Real", "x-coordinate of the candidate point where the two bisectors meet (km)", None)]
    prems = [PREM("p_11x", EQ(MUL(R("11"), V("ix")), R("45")), "11x = 45", G("specialist_inference"))]
    concl = CONC("c_m101", EQ(V("ix"), R("45/11")), "x = 45/11 = 4.0909...")
    E["m10.1"] = ENTRY(P("m10.1", ms, prems, concl), "Division by 11.", ms)
    # m11.1 y = 52/11
    ms = [SYM("ix", "Real", "x-coordinate of the candidate point (km)", None), SYM("iy", "Real", "y-coordinate of the candidate point (km)", None)]
    prems = [PREM("p_x", EQ(V("ix"), R("45/11")), "x = 45/11", G("specialist_inference")),
             PREM("p_y_line", EQ(V("iy"), ADD(MUL(R("-3"), V("ix")), R("17"))), "the point lies on y = -3x + 17", G("specialist_inference"))]
    concl = CONC("c_m111", EQ(V("iy"), R("52/11")), "y = -3(45/11) + 17 = 52/11 = 4.7272...")
    E["m11.1"] = ENTRY(P("m11.1", ms, prems, concl), "Substitution: -135/11 + 187/11 = 52/11.", ms)
    # m12.1 point (4.09, 4.73) to 2 dp
    ms = [SYM("ix", "Real", "x-coordinate of the candidate point (km)", None), SYM("iy", "Real", "y-coordinate of the candidate point (km)", None)]
    prems = [PREM("p_x", EQ(V("ix"), R("45/11")), "x = 45/11", G("specialist_inference")),
             PREM("p_y", EQ(V("iy"), R("52/11")), "y = 52/11", G("specialist_inference"))]
    concl = CONC("c_m121", AND(GE(V("ix"), R("4.085")), LT(V("ix"), R("4.095")), GE(V("iy"), R("4.725")), LT(V("iy"), R("4.735"))),
                 "the point is (4.09, 4.73) km to two decimal places")
    E["m12.1"] = ENTRY(P("m12.1", ms, prems, concl), "Two-decimal-place rounding intervals for 4.0909... and 4.7272....", ms)
    # m13.1 check 2/3 x 45/11 + 2 = 52/11
    ms = [SYM("ix", "Real", "x-coordinate of the candidate point (km)", None)]
    prems = [PREM("p_x", EQ(V("ix"), R("45/11")), "x = 45/11", G("specialist_inference"))]
    concl = CONC("c_m131", EQ(ADD(MUL(R("2/3"), V("ix")), R("2")), R("52/11")), "(2/3)(45/11) + 2 = 30/11 + 22/11 = 52/11")
    E["m13.1"] = ENTRY(P("m13.1", ms, prems, concl), "Check of the second bisector at the candidate x.", ms)
    # m14.1 squared distance from point to A (sqrt omitted)
    ms = [SYM("ix", "Real", "x-coordinate of the candidate point (km)", None), SYM("iy", "Real", "y-coordinate of the candidate point (km)", None)]
    prems = [PREM("p_x", EQ(V("ix"), R("45/11")), "x = 45/11", G("specialist_inference")),
             PREM("p_y", EQ(V("iy"), R("52/11")), "y = 52/11", G("specialist_inference"))]
    concl = CONC("c_m141", EQ(ADD(MUL(R("23/11"), R("23/11")), MUL(R("41/11"), R("41/11"))), R("2210/121")),
                 "the squared distance is (45/11 - 2)^2 + (52/11 - 1)^2 = (23/11)^2 + (41/11)^2 = 2210/121")
    E["m14.1"] = ENTRY(P("m14.1", ms, prems, concl), "The square root is outside IR 1.0; the squared distance is checked, from which the distance follows.", ms,
                       ambiguous=False)
    # m15.1 squared distance 2210/121, d = 4.2737...
    ms = [SYM("pt_da2", "Real", "squared distance from the candidate point to well A (km^2)", None)]
    prems = [PREM("p_da2", EQ(V("pt_da2"), R("2210/121")), "the squared distance from the candidate point to A is 2210/121", G("specialist_inference"))]
    concl = CONC("c_m151", AND(GE(V("pt_da2"), MUL(R("4.27365"), R("4.27365"))), LT(V("pt_da2"), MUL(R("4.27375"), R("4.27375")))),
                 "the distance is sqrt(2210)/11 = 4.2737... km (4 d.p.), checked through its square")
    E["m15.1"] = ENTRY(P("m15.1", ms, prems, concl), "Distance = sqrt(2210)/11; checked by the squared distance 2210/121 lying between the squares of 4.27365 and 4.27375.", ms)
    # m16.1 4.27 km
    ms = [SYM("pt_da2", "Real", "squared distance from the candidate point to well A (km^2)", None)]
    prems = [PREM("p_da2", EQ(V("pt_da2"), R("2210/121")), "the squared distance from the candidate point to A is 2210/121", G("specialist_inference"))]
    concl = CONC("c_m161", AND(GE(V("pt_da2"), MUL(R("4.265"), R("4.265"))), LT(V("pt_da2"), MUL(R("4.275"), R("4.275")))), "the distance is 4.27 km to 2 d.p.")
    E["m16.1"] = ENTRY(P("m16.1", ms, prems, concl), "Two-decimal rounding of the distance checked through the squared distance.", ms)
    # m17.1 distances to B and C equal
    ms = [SYM("ix", "Real", "x-coordinate of the candidate point (km)", None), SYM("iy", "Real", "y-coordinate of the candidate point (km)", None)]
    prems = [PREM("p_x", EQ(V("ix"), R("45/11")), "x = 45/11", G("specialist_inference")),
             PREM("p_y", EQ(V("iy"), R("52/11")), "y = 52/11", G("specialist_inference"))]
    concl = CONC("c_m171", AND(EQ(ADD(MUL(R("-43/11"), R("-43/11")), MUL(R("19/11"), R("19/11"))), R("2210/121")),
                               EQ(ADD(MUL(R("1/11"), R("1/11")), MUL(R("-47/11"), R("-47/11"))), R("2210/121"))),
                 "the distances from the point to B and to C are also sqrt(2210)/11")
    E["m17.1"] = ENTRY(P("m17.1", ms, prems, concl), "Squared distances to B (-43/11, 19/11) and to C (1/11, -47/11) both equal 2210/121.", ms)
    # m18.1 distance to A from farmhouse (5,5)
    concl = CONC("c_m181", AND(EQ(ADD(MUL(R("3"), R("3")), MUL(R("4"), R("4"))), R("25")), EQ(MUL(R("5"), R("5")), R("25"))),
                 "the distance from the farmhouse P(5, 5) to A is sqrt((5-2)^2 + (5-1)^2) = sqrt(25) = 5 km")
    E["m18.1"] = ENTRY(P("m18.1", [], [], concl), "Constant check of the farmhouse distance to A.", [])
    # m19.1 distance to B = sqrt13 ~ 3.61
    concl = CONC("c_m191", AND(EQ(ADD(MUL(R("-3"), R("-3")), MUL(R("2"), R("2"))), R("13")),
                               GE(R("13"), MUL(R("3.605"), R("3.605"))), LT(R("13"), MUL(R("3.615"), R("3.615")))),
                 "the distance from P to B is sqrt(13) = 3.61 km")
    E["m19.1"] = ENTRY(P("m19.1", [], [], concl), "Squared distance 13; 3.61 is sqrt(13) to 2 d.p. (3.605^2 < 13 < 3.615^2).", [])
    # m20.1 distance to C = sqrt17 ~ 4.12
    concl = CONC("c_m201", AND(EQ(ADD(MUL(R("1"), R("1")), MUL(R("-4"), R("-4"))), R("17")),
                               GE(R("17"), MUL(R("4.115"), R("4.115"))), LT(R("17"), MUL(R("4.125"), R("4.125")))),
                 "the distance from P to C is sqrt(17) = 4.12 km")
    E["m20.1"] = ENTRY(P("m20.1", [], [], concl), "Squared distance 17; 4.12 is sqrt(17) to 2 d.p.", [])
    # m21.1 nearest well B (squared distances), nearest-well rule
    ms = [SYM("fh_da2", "Real", "squared distance from farmhouse P to well A (km^2)", None),
          SYM("fh_db2", "Real", "squared distance from farmhouse P to well B (km^2)", None),
          SYM("fh_dc2", "Real", "squared distance from farmhouse P to well C (km^2)", None),
          SYM("take_b", "Bool", "the farmhouse takes its water from well B", G("task_setting"))]
    prems = [PREM("p_fa", EQ(V("fh_da2"), R("25")), "P to A squared is 25", G("arithmetic_fact")),
             PREM("p_fb", EQ(V("fh_db2"), R("13")), "P to B squared is 13", G("arithmetic_fact")),
             PREM("p_fc", EQ(V("fh_dc2"), R("17")), "P to C squared is 17", G("arithmetic_fact")),
             PREM("p_rule", IMP(AND(LT(V("fh_db2"), V("fh_dc2")), LT(V("fh_db2"), V("fh_da2"))), V("take_b")),
                  "each farm takes water from its nearest well", G("task_setting", note="given in the question"))]
    concl = CONC("c_m211", AND(V("take_b"), LT(V("fh_db2"), V("fh_dc2")), LT(V("fh_db2"), V("fh_da2"))),
                 "the farmhouse is closest to well B (3.61 km, against 4.12 km and 5 km), so it takes water from well B")
    E["m21.1"] = ENTRY(P("m21.1", ms, prems, concl), "Nearest-well rule applied to squared distances (monotone with distance).", ms)
    # m22.1 Voronoi vertex
    ms = [SYM("pt_da2", "Real", "squared distance from the candidate point to well A", None),
          SYM("pt_db2", "Real", "squared distance from the candidate point to well B", None),
          SYM("pt_dc2", "Real", "squared distance from the candidate point to well C", None),
          SYM("voronoi", "Bool", "the candidate point is a Voronoi vertex of the three wells", G("general_knowledge"))]
    prems = [PREM("p_da", EQ(V("pt_da2"), R("2210/121")), "the candidate point is 2210/121 squared from A", G("specialist_inference")),
             PREM("p_db", EQ(V("pt_db2"), R("2210/121")), "the candidate point is 2210/121 squared from B", G("specialist_inference")),
             PREM("p_dc", EQ(V("pt_dc2"), R("2210/121")), "the candidate point is 2210/121 squared from C", G("specialist_inference")),
             PREM("p_def", IMP(AND(EQ(V("pt_da2"), V("pt_db2")), EQ(V("pt_db2"), V("pt_dc2"))), V("voronoi")),
                  "a Voronoi vertex is equidistant from three sites where their cell boundaries meet", G("general_knowledge"))]
    concl = CONC("c_m221", AND(EQ(V("pt_da2"), V("pt_db2")), EQ(V("pt_db2"), V("pt_dc2")), V("voronoi")),
                 "the point in (c) is a Voronoi vertex, equidistant (4.27 km) from A, B and C, where the cell boundaries meet")
    E["m22.1"] = ENTRY(P("m22.1", ms, prems, concl), "Equidistance from the three wells, with the definition of a Voronoi vertex as the specialist's stated basis.", ms)
    emit(T, d["report_id"], E, sm)

if __name__ == "__main__":
    gen_mai()
