import json

base = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2"
with open(base + "/tasks.json", encoding="utf-8") as f:
    tasks = json.load(f)

task = next(t for t in tasks if t["task_id"] == "ll-t15")

paragraph = (
    'Bea Lindqvist persuades readers to oppose the closure by fusing personal anecdote with humour, '
    "so that the council's plan looks absurd to anyone who has swum there. "
    'The column opens with a memory rather than an argument: "I learned to swim at the Corran Street Baths in 1989, '
    'which is to say that I learned to sink there first." '
    'The self-mocking sentence casts the writer as a fellow bather rather than a campaigner, and the wordplay on '
    '"sink" primes a column in which water imagery carries the argument. '
    'The attendant\'s maxim, "If you can float, you can argue", becomes its implicit motto. '
    'The writer\'s disclaimer, "I am not an accountant, but I have stood in the shallow end long enough to know '
    'when something is out of its depth", turns her swimming experience into a claim to judge the council\'s sums. '
    'The pun "Bring the report; it floats" then suggests that the report lacks depth. '
    '\n\n'
    'The second strand shows how the anecdote widens into a community. '
    'The baths are "the only place in Corran where a pensioner, a toddler and a sixth-former can be equally bad at '
    'butterfly in public", a comic levelling that presents the baths as a shared space the car park would not provide. '
    'The humour then gives way to portraits: "the night-shift nurses winding down, the man from the bakery who swims '
    'twenty lengths before he sleeps". '
    'Concession also serves the persuasion. The writer grants that "nostalgia is not a business case. They are right", '
    'then answers with the plain request "They are asking for a roof", which keeps the appeal modest and credible. '
    '\n\n'
    'The link returns to the opening: "Mr Pask would have blown his whistle" closes the column, so opposing the closure '
    'becomes loyalty to the community that the anecdote has built. '
    'The humour\'s cost is that it can lighten a serious financial case, but the column keeps its figures in view.'
)

sources = "Sources: Last orders at the deep end, opinion column (supplied text)"

task["response_text"] = paragraph + "\n\n" + sources

out = base + "/specialists/ll-t15.json"
with open(out, "w", encoding="utf-8") as f:
    json.dump([task] if False else task, f, ensure_ascii=False, indent=2)

print(out)
print(len(paragraph.split()), "words in paragraph")
