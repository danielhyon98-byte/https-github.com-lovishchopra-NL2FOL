import json
import os

SRC = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2/tasks.json"
OUT_DIR = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2/specialists"
OUT = os.path.join(OUT_DIR, "bm-t15.json")

RESPONSE = """Assumption: each return in the case is treated as the total over the three years, undiscounted, because the case gives no discount rate.

(a)
Market share 2024 = Pellow Cycles' sales revenue ÷ total market sales revenue × 100
= $180,000 ÷ $1,200,000 × 100
= 15.0%

Market share 2025 = $198,000 ÷ $1,500,000 × 100
= 13.2%

Market growth = (market sales 2025 − market sales 2024) ÷ market sales 2024 × 100
= ($1,500,000 − $1,200,000) ÷ $1,200,000 × 100
= 25.0%

(b)
Pellow Cycles' sales revenue rose by 10.0%, but the market grew by 25.0%, so its market share fell from 15.0% to 13.2%. Demand grew after the new cycle path opened in 2024 and two online retailers began delivering bicycles to Fenwick. Pellow Cycles gained only $18,000 of the $300,000 increase in market sales, which is 6.0% of the growth, so most of the new demand went to other suppliers. The case does not give the online retailers' sales, so it cannot confirm that they took this share.

(c)
Option A
Expected value = sum of (probability × return)
= (0.6 × $150,000) + (0.4 × $40,000)
= $90,000 + $16,000 = $106,000
Net gain = expected value − cost
= $106,000 − $60,000 = $46,000

Option B
Expected value = (0.5 × $80,000) + (0.3 × $50,000) + (0.2 × $20,000)
= $40,000 + $15,000 + $4,000 = $59,000
Net gain = $59,000 − $25,000 = $34,000

(d)
The first limitation is that the tree depends on estimates. The probabilities (0.6 and 0.4 for Option A; 0.5, 0.3 and 0.2 for Option B) and the returns are Aled's own estimates, and the case gives no evidence for them. For Option A, the net gain equals 110,000p − $20,000, where p is the probability of high demand, so the two options have the same net gain when p is about 0.49. A fall of about 0.11 in the probability of high demand, from 0.6 to about 0.49, would make Option B the better choice, so the ranking is not secure.

The second limitation is that expected values average the outcomes and hide the downside and the financing. In Option A's low-demand outcome, returns of $40,000 fall $20,000 short of the $60,000 cost, and this has a 40% probability. Aled's $30,000 of savings covers only half the cost, so the other $30,000 must be borrowed at a rate the case does not give, and that interest is not in the tree. The tree also leaves out non-financial effects, such as Aled's lack of experience in managing staff at a second location and the loss of Carys's time for repairs in Fenwick if she runs the van.

(e)
Aled should choose Option B, the mobile repair service, on condition that the Fenwick repairs can still be covered and that demand from commuters and schools is tested before the van is bought.

Option A has the higher expected net gain, $46,000 against $34,000, and its high-demand return of $150,000 is larger than any return from Option B. On the tree alone it is the better option, and the $12,000 difference is real. The decisive question is whether that gain is worth the risk and the financing that come with it.

The case for Option A rests on return and growth. Fenwick's market grew by 25.0% between 2024 and 2025, which suggests that demand for bicycle services is rising, and a second shop in Rossby would give Aled a new site to grow into. However, the case gives no information on Rossby's market, so growth in Fenwick does not show that a shop there would also grow. Option A costs $60,000 against savings of $30,000, so Aled would need a $30,000 bank loan, with interest the case does not give. In its low-demand outcome it would lose $20,000, and Aled has never managed staff in a second location.

Option B has the smaller expected gain but the safer profile. Its $25,000 cost is covered by savings, so no loan is needed and no interest is added. Its worst outcome is a loss of $5,000, with a 20% probability, against a loss of $20,000 with a 40% probability for Option A. Carys's view that the van would bring new customers into the shop is a benefit the tree does not count, so the tree may understate Option B. Against Option B, Carys would have less time for repairs in Fenwick, and the case gives no figures for the income those repairs would lose.

The decisive factor is risk. Option B gives up $12,000 of expected gain in exchange for a smaller worst-case loss and no debt. For a sole trader whose savings are his only buffer, that protection is worth more than the difference in expected value, particularly because the ranking reverses if the high-demand probability for Option A falls to about 0.49. Doing nothing (Option C) gives no gain, so Option B is preferred to it on these estimates.

The recommendation holds only if Carys can keep the Fenwick repairs running without losing more income than the mobile service adds, and if commuters and schools book enough work to support the estimated returns. The case does not show either. Aled should test demand with a few bookings before he buys the van.
"""


def main():
    with open(SRC, encoding="utf-8") as f:
        tasks = json.load(f)
    matches = [t for t in tasks if t.get("task_id") == "bm-t15"]
    if len(matches) != 1:
        raise SystemExit("expected exactly one bm-t15 task, found %d" % len(matches))
    task = dict(matches[0])
    task["response_text"] = RESPONSE
    os.makedirs(OUT_DIR, exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(task, f, ensure_ascii=False, indent=2)
        f.write("\n")
    print(OUT)


if __name__ == "__main__":
    main()
