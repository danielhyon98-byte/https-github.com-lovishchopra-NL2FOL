import json, os

base = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c3"
out_dir = os.path.join(base, "specialists")

responses = {
    "hi-t16": (
        "Foreign intervention was a decisive reason for the Nationalist victory, but it was not the main reason on its own. "
        "Its first effect was to move the rebel army. In late July 1936 the rising had stalled in southern Spain, and Franco's Army of Africa could reach the mainland only by air: German transport aircraft began flying troops across from late July 1936, and Italian aircraft joined in August. "
        "Germany's Condor Legion, formed in late 1936, then gave the Nationalists bombers and air support that the Republic could not match, and its bombing of Guernica on 26 April 1937 showed the force this gave them. "
        "Italian units supplied infantry and armour for the major offensives of 1937 and 1938. "
        "Yet the same support had limits. Italian formations were defeated at Guadalajara in March 1937, and the Republic received Soviet aid from October 1936, so intervention was matched on the other side and did not settle every battle. "
        "Nationalist strength also came from within: Franco's decree of April 1937 merged the Falange with the Carlists under his leadership, while the Republic was torn apart by the May Days of 1937 in Barcelona, when anarchist and communist forces fought each other. "
        "Foreign intervention supplied the means of the Nationalist advance, but Franco's control of his own side and the Republic's divisions decided how those means were used, so intervention was decisive without being the main reason alone.\n\n"
        "Troop numbers and aid totals are not quoted, because no approved source in this session confirms them; your textbook will give exact figures to add.\n\n"
        "Next step: test the paragraph's claim against a counter-argument that gives Soviet aid more weight.\n\n"
        "Sources: none consulted (no retrieval in this session)"
    ),
    "hi-p10b": (
        "Under War Communism (1918–1921) the Bolshevik government tried to control grain by abolishing the free market in it: a state monopoly was declared, private grain trade was banned, and food detachments seized surplus grain from peasants. "
        "From early 1919 each village had a fixed surplus quota (prodrazverstka) to hand over, and the state set grain prices rather than the market. "
        "Peasants responded by reducing sowing or hiding grain, and urban shortages produced illegal trade: 'bagmen' (meshochniki) carried food and goods to the black market, where prices far exceeded the state's. "
        "Money lost most of its value and was partly replaced by barter. "
        "In March 1921, at the Tenth Party Congress, the New Economic Policy replaced requisitioning with a tax in kind, which let peasants sell their surplus, allowed small private trade and restored a market in grain. "
        "The famine of 1921–1922, which killed several million people, showed how urgently the change was needed.\n\n"
        "I have not quoted tonnages or price figures, because no approved source in this session confirms them; your textbook will give exact figures.\n\n"
        "Sources: none consulted (no retrieval in this session)"
    ),
}

with open(os.path.join(base, "tasks.json"), encoding="utf-8") as f:
    tasks = json.load(f)

written = []
for t in tasks:
    tid = t.get("task_id")
    if tid in responses:
        rec = dict(t)
        rec["response_text"] = responses[tid]
        path = os.path.join(out_dir, tid + ".json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(rec, f, ensure_ascii=False, indent=2)
        written.append(path)

print("\n".join(written))
print("word counts:", {k: len(v.split()) for k, v in responses.items()})
