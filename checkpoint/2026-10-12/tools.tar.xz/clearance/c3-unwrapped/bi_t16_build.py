import json

SRC = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c3/tasks.json"
OUT = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c3/specialists/bi-t16.json"

response_text = """(a) Control roots: mitotic cells = 52 + 14 + 8 + 14 = 88 out of 500 cells counted. Mitotic index = 88 ÷ 500 = 0.176 = 17.6% [1]
Roots grown in the extract: mitotic cells = 12 + 21 + 2 + 4 = 39 out of 500 cells counted. Mitotic index = 39 ÷ 500 = 0.078 = 7.8% [1]

(b) Percentage decrease = (17.6 − 7.8) ÷ 17.6 × 100 = 55.7%, a decrease [1]

(c) Assumption: the root-tip cells are a random sample of a population that is dividing continuously, and every cell takes the same time to pass through the cycle, so the time spent in a phase is proportional to the number of cells in that phase. [1]
Time in metaphase = (14 ÷ 500) × 18 h = 0.028 × 1080 min = 30.24 min, so about 30 min [1]

(d) The extract mainly holds cells in interphase, which rises from 412 to 461 cells. [1] Prophase falls most, from 52 to 12 cells, which suggests that fewer cells progress into mitosis. [1] Metaphase rises from 14 to 21 cells while anaphase falls from 8 to 2, so 54% of dividing cells are at metaphase, against 16% in the control. This suggests that cells may stall at metaphase, for example if the spindle is disrupted and chromatids cannot separate. [1] These are single counts of 500 cells per treatment, so they show the proportion of cells at each stage, not how long each stage lasts. [1 spare]

(e) Root tips contain meristematic tissue, whose cells divide continuously by mitosis, so enough cells are in mitosis to count. [1] Older root tissue has specialised cells that have stopped dividing, so few cells would be in mitosis and the mitotic index would be too low to compare reliably. [1]

Sources: your question and its practice data (supplied text); course notes on the cell cycle and the mitotic index (course notes)"""

with open(SRC, encoding="utf-8") as f:
    tasks = json.load(f)

selected = [t for t in tasks if t.get("task_id") in ["bi-t16"]]
out = []
for t in selected:
    rec = dict(t)
    rec["response_text"] = response_text
    out.append(rec)

with open(OUT, "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=2)

print(OUT, len(out), len(response_text.split()))
