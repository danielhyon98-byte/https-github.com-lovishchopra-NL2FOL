import json
import os

base = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c3"
with open(os.path.join(base, "tasks.json"), encoding="utf-8") as f:
    tasks = json.load(f)
with open(os.path.join(base, "specialists", "ll-t16-response.txt"), encoding="utf-8") as f:
    response_text = f.read().strip()

matched = [t for t in tasks if t.get("task_id") in ["ll-t16"]]
assert len(matched) == 1, len(matched)
out = dict(matched[0])
out["response_text"] = response_text

out_path = os.path.join(base, "specialists", "ll-t16.json")
with open(out_path, "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=2)
    f.write("\n")
print(out_path)
