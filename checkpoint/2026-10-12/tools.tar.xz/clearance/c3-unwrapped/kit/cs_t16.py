from builder import *
r = Report("cs-t16")
TS = lambda: G("task_setting", "established")
GK = lambda: G("general_knowledge", "established")
GI = lambda c="established": G("specialist_inference", c)
def ints(names, vals_meaning):
    return [(n, "Int", m, None) for n, m in vals_meaning]

def fcfs():
    S = []
    for i, b in enumerate([5, 3, 8, 2], 1):
        S.append((f"fb{i}", "Int", f"FCFS burst time of P{i}, ms", G("task_setting")))
    for i in range(1, 5):
        S.append((f"fs{i}", "Int", f"FCFS start time of P{i}, ms", GK()))
        S.append((f"fc{i}", "Int", f"FCFS completion time of P{i}, ms", GK()))
        S.append((f"fw{i}", "Int", f"FCFS waiting time of P{i}, ms", GK()))
    P = []
    for i, b in enumerate([5, 3, 8, 2], 1):
        P.append((f"tb{i}", EQ(V(f"fb{i}"), I(b)), f"P{i} burst time is {b} ms", G("task_setting"), "material"))
    P.append(("tf_s1", EQ(V("fs1"), I(0)), "P1 starts at time 0 (all processes ready at time 0, P1 first)", G("task_setting"), "material"))
    for i in range(1, 4):
        P.append((f"fcfs_link{i}", EQ(V(f"fs{i+1}"), V(f"fc{i}")), f"P{i+1} starts when P{i} completes (no switch time)", G("task_setting"), "material"))
    for i in range(1, 5):
        P.append((f"fcfs_c{i}", EQ(V(f"fc{i}"), ADD(V(f"fs{i}"), V(f"fb{i}"))), f"completion = start + burst for P{i}", GK(), "material"))
        P.append((f"fcfs_w{i}", EQ(V(f"fw{i}"), V(f"fs{i}")), f"waiting = start, since arrival is 0 for P{i}", GK(), "material"))
    return S, P

def fcfs_problem(cid, pid, extra_syms, extra_prem, concl, reading):
    S, P = fcfs()
    r.add(cid, pid, S + extra_syms, P + extra_prem, concl, reading)

# c1.1 self-report
r.unsupported("c1.1", "A statement about how the answer was produced (traced by hand, no code run).",
  "a self-report about the method, not a claim about the scheduling; no property of the scheduling to check")
# c1.2 assumption restates setup
r.unsupported("c1.2", "The assumption that all four processes arrive at time 0 in order P1-P4 with no switch time restates the question's setup.",
  "the statement restates the task setting; the only encoding is the setting itself, so there is no inference to check")

# c3.2..c3.5 FCFS table rows
fcfs_problem("c3.2", "cs-c3.2", [], [], ("concl", AND(EQ(V("fs1"),I(0)), EQ(V("fc1"),I(5)), EQ(V("fw1"),I(0))), "P1: burst 5, start 0, completes 5, waiting 0", GK()),
  "Row P1 of the first come, first served table, checked against the FCFS timing rules.")
fcfs_problem("c3.3", "cs-c3.3", [], [], ("concl", AND(EQ(V("fs2"),I(5)), EQ(V("fc2"),I(8)), EQ(V("fw2"),I(5))), "P2: burst 3, start 5, completes 8, waiting 5", GK()),
  "Row P2 of the FCFS table.")
fcfs_problem("c3.4", "cs-c3.4", [], [], ("concl", AND(EQ(V("fs3"),I(8)), EQ(V("fc3"),I(16)), EQ(V("fw3"),I(8))), "P3: burst 8, start 8, completes 16, waiting 8", GK()),
  "Row P3 of the FCFS table.")
fcfs_problem("c3.5", "cs-c3.5", [], [], ("concl", AND(EQ(V("fs4"),I(16)), EQ(V("fc4"),I(18)), EQ(V("fw4"),I(16))), "P4: burst 2, start 16, completes 18, waiting 16", GK()),
  "Row P4 of the FCFS table.")
# c4.1 completion times
fcfs_problem("c4.1", "cs-c4.1", [], [], ("concl", AND(EQ(V("fc1"),I(5)), EQ(V("fc2"),I(8)), EQ(V("fc3"),I(16)), EQ(V("fc4"),I(18))),
  "Completion times under FCFS: P1 5, P2 8, P3 16, P4 18 ms.", GK()), "Completion times from the FCFS chain.")
# c4.2 total waiting
fcfs_problem("c4.2", "cs-c4.2", [], [], ("concl", EQ(ADD(V("fw1"),V("fw2"),V("fw3"),V("fw4")), I(29)),
  "Total waiting time = 0 + 5 + 8 + 16 = 29 ms", GK()), "Sum of FCFS waiting times.")
# c4.3 average waiting
fcfs_problem("c4.3", "cs-c4.3", [], [], ("concl", EQ(DIV(TOREAL(ADD(V("fw1"),V("fw2"),V("fw3"),V("fw4"))), R(4)), R("7.25")),
  "Average waiting time = 29 / 4 = 7.25 ms", GK()), "Exact average of the FCFS waiting times.")

# c8.1 slice 6
r.add("c8.1", "cs-c8.1",
  [("rr_burst2","Int","P2 burst time, ms",G("task_setting")),("rr_prev2","Int","time P2 had already run before slice 6, ms",GI()),
   ("rr_rem2","Int","P2 time still needed before slice 6, ms",GK()),("rr_slice6","Int","length of slice 6, ms",GK())],
  [("t_b2",EQ(V("rr_burst2"),I(3)),"P2 burst time is 3 ms",G("task_setting"),"material"),
   ("t_prev2",EQ(V("rr_prev2"),I(2)),"P2 ran for 2 ms in slice 2 of the trace",GI(),"material"),
   ("rule_rem",EQ(V("rr_rem2"),SUB(V("rr_burst2"),V("rr_prev2"))),"remaining time = burst minus time already run",GK(),"material"),
   ("rule_slice",EQ(V("rr_slice6"),V("rr_rem2")),"a process finishing within the slice runs for its remaining time",GK(),"material")],
  ("concl", LT(V("rr_slice6"), I(2)), "Slice 6 is shorter than 2 ms because P2 finishes after 1 ms", GI()),
  "Because-claim: slice 6 runs P2's remaining 1 ms, from the round-robin rule and the trace's earlier 2 ms of P2.")

# c9.1 definition
r.unsupported("c9.1", "A definition: turnaround time equals completion time minus arrival time.",
  "a definition, not a claim about the case; its only encoding restates the definition, so there is no relation to check")

# c10.2..c10.5 RR turnaround/waiting per process
def rr_row(cid, pid, n, burst, comp, tat, wt):
    syms = [(f"rr_ct{n}","Int",f"P{n} completion time under round robin, ms (from the specialist trace)",GI()),
            (f"rr_arr{n}","Int",f"P{n} arrival time, ms",G("task_setting")),
            (f"rr_b{n}","Int",f"P{n} burst time, ms",G("task_setting")),
            (f"rr_tat{n}","Int",f"P{n} turnaround time, ms",GK()),
            (f"rr_wt{n}","Int",f"P{n} waiting time, ms",GK())]
    prem = [(f"t_ct{n}",EQ(V(f"rr_ct{n}"),I(comp)),f"P{n} completes at {comp} ms in the round-robin trace",GI(),"material"),
            (f"t_arr{n}",EQ(V(f"rr_arr{n}"),I(0)),f"P{n} arrives at time 0",G("task_setting"),"material"),
            (f"t_b{n}",EQ(V(f"rr_b{n}"),I(burst)),f"P{n} burst time is {burst} ms",G("task_setting"),"material"),
            (f"d_tat{n}",EQ(V(f"rr_tat{n}"),SUB(V(f"rr_ct{n}"),V(f"rr_arr{n}"))),"turnaround = completion minus arrival",GK(),"material"),
            (f"d_wt{n}",EQ(V(f"rr_wt{n}"),SUB(V(f"rr_tat{n}"),V(f"rr_b{n}"))),"waiting = turnaround minus burst",GK(),"material")]
    r.add(cid, pid, syms, prem,
          ("concl", AND(EQ(V(f"rr_tat{n}"),I(tat)), EQ(V(f"rr_wt{n}"),I(wt))), f"P{n}: turnaround {tat} ms, waiting {wt} ms", GK()),
          "Turnaround and waiting for one process; the completion time is taken from the specialist's round-robin trace, which is not itself encoded (see c8.3).")
rr_row("c10.2", "cs-c10.2", 1, 5, 14, 14, 9)
rr_row("c10.3", "cs-c10.3", 2, 3, 11, 11, 8)
rr_row("c10.4", "cs-c10.4", 3, 8, 18, 18, 10)
rr_row("c10.5", "cs-c10.5", 4, 2, 8, 8, 6)

# c11.1 average turnaround
r.add("c11.1", "cs-c11.1",
  [(f"rr_tat{n}","Int",f"P{n} turnaround time, ms (round robin)",GI()) for n in range(1,5)],
  [(f"t_tat{n}",EQ(V(f"rr_tat{n}"),I(v)),f"P{n} turnaround is {v} ms (round-robin trace)",GI(),"material") for n,v in zip(range(1,5),[14,11,18,8])],
  ("concl", EQ(DIV(TOREAL(ADD(V("rr_tat1"),V("rr_tat2"),V("rr_tat3"),V("rr_tat4"))), R(4)), R("12.75")),
   "Average turnaround time = (14 + 11 + 18 + 8) / 4 = 12.75 ms", GK()),
  "Exact average of the four turnaround times taken from the trace (c10).")
# c11.2 average waiting
r.add("c11.2", "cs-c11.2",
  [(f"rr_wt{n}","Int",f"P{n} waiting time, ms (round robin)",GI()) for n in range(1,5)],
  [(f"t_wt{n}",EQ(V(f"rr_wt{n}"),I(v)),f"P{n} waiting is {v} ms (round-robin trace)",GI(),"material") for n,v in zip(range(1,5),[9,8,10,6])],
  ("concl", EQ(DIV(TOREAL(ADD(V("rr_wt1"),V("rr_wt2"),V("rr_wt3"),V("rr_wt4"))), R(4)), R("8.25")),
   "Average waiting time = (9 + 8 + 10 + 6) / 4 = 8.25 ms", GK()),
  "Exact average of the four waiting times taken from the trace (c10).")

# c12.1 advantage
r.add("c12.1", "cs-c12.1",
  [("rr_ct4","Int","P4 completion time under round robin, ms",GI()),("fc4","Int","P4 completion time under FCFS, ms",GK()),
   ("turn_rr","Bool","round robin gives every ready process a turn within a short time",GK()),
   ("resp_sooner","Bool","an interactive user sees responses sooner",GI("probable"))],
  [("t_rr4",EQ(V("rr_ct4"),I(8)),"P4 completes at 8 ms under round robin",GI(),"material"),
   ("t_fc4",EQ(V("fc4"),I(18)),"P4 completes at 18 ms under FCFS",GK(),"material"),
   ("p_turn",V("turn_rr"),"round robin gives every process a turn within a short time",GK(),"material"),
   ("link_resp",IMP(V("turn_rr"),V("resp_sooner")),"every process gets a turn within a short time, so interactive responses come sooner",GI("probable"),"material")],
  ("concl", AND(LT(V("rr_ct4"),V("fc4")), V("resp_sooner")),
   "Round robin finishes the short process P4 at 8 ms instead of 18 ms, and an interactive user sees responses sooner", GI()),
  "Advantage claim: the numeric part is the P4 completion comparison; the interactive-response part is the specialist's link from the turn property.")

# c12.4 average waiting rises
r.add("c12.4", "cs-c12.4",
  [("fcfs_avg","Real","average waiting time under FCFS, ms",GK()),("rr_avg","Real","average waiting time under round robin, ms",GK()),
   ("always_red","Bool","round robin always reduces the average waiting time",GI()),
   ("wrr1","Int","P1 waiting under round robin, ms",GI()),("wrr2","Int","P2 waiting under round robin, ms",GI()),
   ("wrr3","Int","P3 waiting under round robin, ms",GI()),("wrr4","Int","P4 waiting under round robin, ms",GI())],
  [("t_wrr",EQ(V("rr_avg"),DIV(TOREAL(ADD(V("wrr1"),V("wrr2"),V("wrr3"),V("wrr4"))),R(4))),"round-robin average waiting is the mean of the four waits",GK(),"material"),
   ("t_wrr1",EQ(V("wrr1"),I(9)),"P1 waits 9 ms under round robin (trace)",GI(),"material"),
   ("t_wrr2",EQ(V("wrr2"),I(8)),"P2 waits 8 ms under round robin (trace)",GI(),"material"),
   ("t_wrr3",EQ(V("wrr3"),I(10)),"P3 waits 10 ms under round robin (trace)",GI(),"material"),
   ("t_wrr4",EQ(V("wrr4"),I(6)),"P4 waits 6 ms under round robin (trace)",GI(),"material"),
   ("t_fcfs_avg",EQ(V("fcfs_avg"),R("7.25")),"FCFS average waiting is 7.25 ms",GK(),"material"),
   ("link_rr",IMP(GT(V("rr_avg"),V("fcfs_avg")),NOT(V("always_red"))),"a round-robin average above the FCFS average means round robin does not always reduce waiting",GI("established"),"material")],
  ("concl", AND(EQ(V("rr_avg"),R("8.25")), GT(V("rr_avg"),V("fcfs_avg")), NOT(V("always_red"))),
   "Average waiting time rises from 7.25 ms to 8.25 ms, so round robin does not always reduce waiting time", GI()),
  "Numeric part: 8.25 versus 7.25 ms; the 'so' step is the specialist's inference from that comparison.")

# c13.1 too short
r.add("c13.1", "cs-c13.1",
  [("short","Bool","the time slice is too short",GK()),("freq","Bool","the processor switches very often",GK()),
   ("overhead","Bool","save and restore time is a large share of processor time",GK()),
   ("lessuse","Bool","less time goes on useful work",GI())],
  [("l1",IMP(V("short"),V("freq")),"a too-short slice means frequent switching",GK(),"material"),
   ("l2",IMP(V("freq"),V("overhead")),"frequent switching makes state save and restore a large share of time",GK(),"material"),
   ("l3",IMP(V("overhead"),V("lessuse")),"a large overhead share means less useful work",GI(),"material")],
  ("concl", IMP(V("short"), V("lessuse")), "a time slice that is too short means less time goes on useful work", GI()),
  "Conditional chain: short slice, then frequent switching, then overhead, then less useful work; each link stated in the report.")

# c13.2 too long
r.add("c13.2", "cs-c13.2",
  [("long","Bool","the time slice is too long",GK()),("mostburst","Bool","each process runs for most of its burst before another turn",GK()),
   ("fcfslike","Bool","scheduling behaves like first come, first served",GI()),("shortwait","Bool","short processes wait behind long ones",GI())],
  [("m1",IMP(V("long"),V("mostburst")),"a too-long slice means each process runs for most of its burst",GK(),"material"),
   ("m2",IMP(V("mostburst"),V("fcfslike")),"running most of each burst before switching behaves like first come, first served",GI(),"material"),
   ("m3",IMP(V("fcfslike"),V("shortwait")),"first come, first served makes short processes wait behind long ones",GI(),"material")],
  ("concl", IMP(V("long"), AND(V("fcfslike"), V("shortwait"))), "a time slice that is too long means scheduling behaves like first come, first served and short processes wait behind long ones", GI()),
  "Conditional chain from a long slice to first-come-first-served behaviour and short processes waiting.")

# null: queue-state claims and heading
r.unsupported("c5.1", "A heading naming the round-robin policy and time slice.",
  "a heading, not an assertion; the substantive content is in the trace rows")
for cid in ["c7.2","c7.3","c7.4","c7.5","c7.6","c7.7","c7.8","c7.9","c7.10","c7.11"]:
    r.unsupported(cid, "A round-robin trace row giving the slice, process, start and end times, time still needed and queue after the slice.",
      "a row of a round-robin trace needs the ordered queue of processes, which IR 1.0 cannot express (no lists or quantifiers); a timing-only encoding would drop which process runs, so it is not encoded")
r.unsupported("c8.2", "The execution order P1, P2, P3, P4, P1, P2, P3, P1, P3, P3.",
  "the claim is an ordered sequence of processes; IR 1.0 has no sequence or quantifier construct, so the order cannot be encoded without dropping part of its meaning")
r.unsupported("c8.3", "Round-robin completion times P1 14 ms, P2 11 ms, P3 18 ms, P4 8 ms.",
  "the completion times are outputs of the round-robin queue trace, which needs ordered queue state that IR 1.0 cannot express; they are used as trace inputs in c10 and c11 but not derived here")
r.write()
