"""Builds translation output objects (IR 1.0 problems) for one report. Scratch helper; not project code."""
import json, os

C3 = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c3"

def V(n): return {"op": "var", "name": n}
def B(v): return {"op": "bool", "value": bool(v)}
def I(v): return {"op": "int", "value": str(v)}
def R(v): return {"op": "real", "value": str(v)}
def NOT(a): return {"op": "not", "arg": a}
def AND(*a): return {"op": "and", "args": list(a)}
def OR(*a): return {"op": "or", "args": list(a)}
def IMP(a, b): return {"op": "implies", "left": a, "right": b}
def IFF(a, b): return {"op": "iff", "left": a, "right": b}
def ITE(c, t, o): return {"op": "ite", "cond": c, "then": t, "otherwise": o}
def ADD(*a): return {"op": "add", "args": list(a)}
def MUL(*a): return {"op": "mul", "args": list(a)}
def SUB(a, b): return {"op": "sub", "left": a, "right": b}
def NEG(a): return {"op": "neg", "arg": a}
def DIV(a, b): return {"op": "div", "left": a, "right": b}
def IDIV(a, b): return {"op": "idiv", "left": a, "right": b}
def MOD(a, b): return {"op": "mod", "left": a, "right": b}
def TOREAL(a): return {"op": "to_real", "arg": a}
def _cmp(op): return lambda a, b: {"op": op, "left": a, "right": b}
EQ, NE, LT, LE, GT, GE = (_cmp(o) for o in ["eq", "ne", "lt", "le", "gt", "ge"])

def G(kind, cert="established", refs=(), note=None):
    """refs: tuples (document_id, excerpt_or_None[, locator])."""
    sr = []
    for r in refs:
        d = {"document_id": r[0]}
        if len(r) > 2 and r[2]: d["locator"] = r[2]
        if r[1] is not None: d["excerpt"] = r[1]
        sr.append(d)
    g = {"kind": kind, "source_refs": sr, "certainty": cert}
    if note: g["note"] = note
    return g

class Report:
    def __init__(self, task_id, listing_name=None):
        self.task_id = task_id
        spec = json.load(open(f"{C3}/specialists/{task_id}.json"))
        lst = json.load(open(f"{C3}/listings/{task_id}.json"))
        self.report_id = lst["report_id"]
        self.request_id = lst["request_id"]
        self.docs = {}
        sup = spec.get("supplied_texts") or []
        if isinstance(sup, str):
            sup = []
        for s in sup:
            self.docs[s["document_id"]] = s.get("text", "")
        self.claims = {}
        self.listed = {c["claim_id"] for c in lst["claims"]}
        self.ids_seen = set()

    def check_refs(self, grounding):
        if not grounding: return
        for r in grounding.get("source_refs", []):
            if "excerpt" in r:
                doc = self.docs.get(r["document_id"])
                if doc is None or r["excerpt"] not in doc:
                    raise ValueError(f"{self.task_id}: excerpt not found in {r['document_id']}: {r['excerpt'][:60]!r}")

    def add(self, claim_id, problem_id, symbols, premises, conclusion, reading, glossary_extra=None,
            flags=(), ambiguous=False):
        """symbols: [(name, sort, meaning, grounding)]; premises: [(id, expr, label, grounding, materiality)];
        conclusion: (id, expr, label, grounding) or None."""
        assert claim_id in self.listed, claim_id
        syms = []
        gloss = []
        for name, sort, meaning, gr in symbols:
            self.check_refs(gr)
            s = {"name": name, "sort": sort, "meaning": meaning}
            if gr is not None: s["grounding"] = gr
            syms.append(s)
            gloss.append({"symbol": name, "meaning": meaning, "grounding": gr})
        prem = []
        for pid, expr, label, gr, mat in premises:
            self.check_refs(gr)
            p = {"id": pid, "expr": expr, "label": label, "materiality": mat}
            if gr is not None: p["grounding"] = gr
            prem.append(p)
        concl = None
        if conclusion is not None:
            cid, cexpr, clabel, cgr = conclusion
            self.check_refs(cgr)
            concl = {"id": cid, "expr": cexpr, "label": clabel, "materiality": "material"}
            if cgr is not None: concl["grounding"] = cgr
        prob = {"ir_version": "1.0", "problem_id": problem_id, "request_id": self.request_id,
                "claim_id": claim_id, "query": "entailment" if concl else "consistency",
                "symbols": syms, "premises": prem}
        if concl: prob["conclusion"] = concl
        self.claims[claim_id] = {
            "problem": prob,
            "interpretation": {"reading": reading, "glossary": gloss,
                               "ambiguity_flags": [{"code": c, "message": m, "alternatives": a} for c, m, a in flags]},
            "ambiguous": bool(ambiguous or flags),
            "unsupported_reason": None,
        }

    def unsupported(self, claim_id, reading, reason, flags=()):
        assert claim_id in self.listed, claim_id
        self.claims[claim_id] = {
            "problem": None,
            "interpretation": {"reading": reading, "glossary": [],
                               "ambiguity_flags": [{"code": c, "message": m, "alternatives": a} for c, m, a in flags]},
            "ambiguous": bool(flags),
            "unsupported_reason": reason,
        }

    def write(self):
        missing = self.listed - set(self.claims)
        if missing:
            raise SystemExit(f"{self.task_id}: missing claims {sorted(missing)}")
        out = {"report_id": self.report_id, "claims": self.claims}
        path = f"{C3}/translations/{self.task_id}.json"
        with open(path, "w", encoding="utf-8") as f:
            json.dump(out, f, ensure_ascii=False, indent=1)
            f.write("\n")
        print("wrote", path, len(self.claims))
