#!/bin/bash
# usage: validate.sh <task_id>
B=/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c3
PY=/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/z3venv/bin/python
F=$B/translations/$1.json
ids=$($PY -I -c "import json,sys; d=json.load(open(sys.argv[1])); print('\n'.join(k for k,v in d['claims'].items() if v['problem'] is not None))" "$F")
while IFS= read -r c; do
  [ -z "$c" ] && continue
  out=$($PY -I -c "import json,sys; from epinoic_logic.engine import parse_and_validate; p,o=parse_and_validate(json.dumps(json.load(open(sys.argv[1]))['claims'][sys.argv[2]]['problem'])); print(o.ok, '' if o.ok else str(getattr(o,'errors',o))[:300])" "$F" "$c" 2>&1 | tail -1)
  echo "$c => $out"
done <<< "$ids"
