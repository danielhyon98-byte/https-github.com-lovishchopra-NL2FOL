from builder import *
r = Report("bm-t16")
D = "doc-hartwell"
GF = lambda: G("arithmetic_fact", "established", [(D, None)])
GS = lambda: G("supplied_text", "established", [(D, None)])
GI = lambda c="established": G("specialist_inference", c)
GK = lambda: G("general_knowledge", "established")
def pct(a, b): return MUL(DIV(R(a), R(b)), R(100))
def fact_sym(name, meaning): return (name, "Int", meaning, GF())
def fact_prem(pid, name, val, label): return (pid, EQ(V(name), I(val)), label, GF(), "material")
SALES = fact_sym("sales25", "sales revenue 2025, $")
COGS = fact_sym("cogs25", "cost of sales 2025, $")
EXP = fact_sym("exp25", "expenses 2025, $")
NCL = fact_sym("ncl25", "non-current liabilities 2025, $")
EQTY = fact_sym("eqty25", "equity 2025, $")
PBIT = ("pbit25", "Int", "profit before interest and tax 2025 (gross profit less expenses), $", GI())
OPT1 = fact_sym("opt1cost", "cost of Option 1, $")
OPT2 = fact_sym("opt2cost", "cost of Option 2, $")
P_SALES = fact_prem("p_sales", "sales25", 2400000, "sales revenue 2025 is $2,400,000")
P_COGS = fact_prem("p_cogs", "cogs25", 960000, "cost of sales 2025 is $960,000")
P_EXP = fact_prem("p_exp", "exp25", 1104000, "expenses are $1,104,000")
P_NCL = fact_prem("p_ncl", "ncl25", 500000, "non-current liabilities are $500,000")
P_EQTY = fact_prem("p_eqty", "eqty25", 1750000, "equity is $1,750,000")
P_OPT1 = fact_prem("p_opt1", "opt1cost", 380000, "Option 1 costs $380,000")
P_OPT2 = fact_prem("p_opt2", "opt2cost", 290000, "Option 2 costs $290,000")
P_PBIT = ("p_pbit", EQ(V("pbit25"), I(336000)), "2025 profit before interest and tax is $336,000", GI(), "material")
PBIT_CE = ("p_pbit", EQ(V("pbit25"), I(336000)), "2025 profit before interest and tax is $336,000 (computed from the figures)", GF(), "material")
CE_FACT = ("p_ce", EQ(ADD(V("ncl25"), V("eqty25")), I(2250000)), "capital employed is $2,250,000 (non-current liabilities plus equity)", GF(), "material")
CE_NOTE = None

def GP_FACT(): return ("p_gp", EQ(SUB(V("sales25"), V("cogs25")), I(1440000)), "gross profit is $1,440,000", GF(), "material")

# 1 g1.2
r.add("g1.2@business-management-specialist", "bm-g1.2",
  [("nointfig","Bool","the case gives no interest figure",GS()),("expnoint","Bool","the $1,104,000 of expenses contains no interest",GI()),("pbitdef","Bool","profit before interest and tax is taken as gross profit less expenses",GI())],
  [("p_nointfig",V("nointfig"),"the case gives no interest figure",GS(),"material"),
   ("link_a",IMP(V("nointfig"),V("expnoint")),"no interest figure in the case, so expenses contain no interest",GI(),"material"),
   ("link_b",IMP(V("expnoint"),V("pbitdef")),"expenses with no interest, so profit before interest and tax is gross profit less expenses",GI(),"material")],
  ("concl", AND(V("expnoint"), V("pbitdef")), "the $1,104,000 of expenses contains no interest, so profit before interest and tax is taken as gross profit less expenses", GI()),
  "The claim is a because-clause: the missing interest figure in the case is the premise, the two specialist links lead to the expenses having no interest and to the profit definition, and the claim asserts both results.")

# 2 g1.3
r.add("g1.3@business-management-specialist", "bm-g1.3",
  [("nocash","Bool","the case gives no cash balance",GS()),("liqtest","Bool","liquidity can be tested from the case",GI())],
  [("p_nocash",V("nocash"),"the case gives no cash balance",GS(),"material"),
   ("link_a",IMP(V("nocash"),NOT(V("liqtest"))),"no cash balance means liquidity cannot be tested",GI(),"material")],
  ("concl", NOT(V("liqtest")), "liquidity cannot be tested here", GI()),
  "A because-style claim: the missing cash balance is the premise; the specialist's link says liquidity cannot be tested from it.")

# 3 g3.2 formula
r.unsupported("g3.2@business-management-specialist",
  "A formula statement: gross profit divided by sales revenue, times 100.",
  "the line is a definition of the ratio, not an assertion about the case; its only encoding restates the definition, so there is no relation to check (the figure is checked in g3.4)")

# 4 g3.3
r.add("g3.3@business-management-specialist", "bm-g3.3",
  [("sales25","Int","sales revenue 2025, $",GF()),("cogs25","Int","cost of sales 2025, $",GF())],
  [P_SALES, P_COGS],
  ("concl", EQ(SUB(V("sales25"), V("cogs25")), I(1440000)), "Gross profit = $2,400,000 - $960,000 = $1,440,000", GF()),
  "Subtraction of the two case figures; checked as exact integer arithmetic.")

# 5 g3.4
r.add("g3.4@business-management-specialist", "bm-g3.4",
  [("sales25","Int","sales revenue 2025, $",GF()),("cogs25","Int","cost of sales 2025, $",GF())],
  [P_SALES, P_COGS, GP_FACT()],
  ("concl", AND(GE(pct(1440000,2400000), R("59.995")), LT(pct(1440000,2400000), R("60.005"))),
   "Gross profit margin = $1,440,000 / $2,400,000 x 100 = 60.00%", GF()),
  "Stated to two decimal places, so the exact value must lie in [59.995, 60.005). The exact value is 60.")

# 6 g3.5
r.add("g3.5@business-management-specialist", "bm-g3.5",
  [("sales25","Int","sales revenue 2025, $",GF()),("cogs25","Int","cost of sales 2025, $",GF())],
  [P_SALES, P_COGS, GP_FACT()],
  ("concl", EQ(DIV(R(1440000), R(2400000)), R("3/5")), "60 cents of each dollar of sales is left after the cost of sales", GI()),
  "Exact ratio of gross profit to sales equals 3/5, i.e. 0.60 per dollar.")

# 7 g4.2 formula
r.unsupported("g4.2@business-management-specialist",
  "A formula statement: profit before interest and tax divided by capital employed, times 100.",
  "the line is a definition of the ratio, not an assertion about the case; its only encoding restates the definition, so there is no relation to check (the figure is checked in g4.5)")

# 8 g4.3
r.add("g4.3@business-management-specialist", "bm-g4.3",
  [("sales25","Int","sales revenue 2025, $",GF()),("cogs25","Int","cost of sales 2025, $",GF()),("exp25","Int","expenses 2025, $",GF())],
  [P_SALES, P_COGS, P_EXP],
  ("concl", EQ(SUB(SUB(V("sales25"), V("cogs25")), V("exp25")), I(336000)), "Profit before interest and tax = $1,440,000 - $1,104,000 = $336,000", GF()),
  "Exact integer arithmetic on the case figures.")

# 9 g4.4
r.add("g4.4@business-management-specialist", "bm-g4.4",
  [("ncl25","Int","non-current liabilities 2025, $",GF()),("eqty25","Int","equity 2025, $",GF())],
  [P_NCL, P_EQTY],
  ("concl", EQ(ADD(V("ncl25"), V("eqty25")), I(2250000)), "Capital employed = $500,000 + $1,750,000 = $2,250,000", GF()),
  "Capital employed as non-current liabilities plus equity, exact integer arithmetic.")

# 10 g4.5
r.add("g4.5@business-management-specialist", "bm-g4.5",
  [("pbit25","Int","profit before interest and tax 2025, $",GF()),("ncl25","Int","non-current liabilities 2025, $",GF()),("eqty25","Int","equity 2025, $",GF())],
  [PBIT_CE, CE_FACT],
  ("concl", AND(GE(pct(336000,2250000), R("14.925")), LT(pct(336000,2250000), R("14.935"))),
   "ROCE = $336,000 / $2,250,000 x 100 = 14.93%", GI()),
  "Stated to two decimal places: exact value must lie in [14.925, 14.935). The exact value is about 14.933, so the stated figure is correct to its precision.")

# 11 g4.6
r.add("g4.6@business-management-specialist", "bm-g4.6",
  [("pbit25","Int","profit before interest and tax 2025, $",GF()),("ncl25","Int","non-current liabilities 2025, $",GF()),("eqty25","Int","equity 2025, $",GF())],
  [PBIT_CE, CE_FACT],
  ("concl", AND(GE(DIV(R(336000), R(2250000)), R("0.14925")), LT(DIV(R(336000), R(2250000)), R("0.14935"))),
   "Hartwell earns 14.93 cents of profit before interest and tax on each dollar of capital employed", GI()),
  "Restates the ROCE ratio per dollar; stated to four decimal places of a dollar, so the exact value must lie in [0.14925, 0.14935).")

# 12 g4.7
r.add("g4.7@business-management-specialist", "bm-g4.7",
  [("nobench","Bool","the case gives no benchmark for ROCE",GS()),("needcomp","Bool","the ROCE must be judged against earlier years or a target",GI())],
  [("p_nobench",V("nobench"),"the case gives no benchmark",GS(),"material"),
   ("link_a",IMP(V("nobench"),V("needcomp")),"with no benchmark, the ROCE must be judged against earlier years or a target",GI(),"material")],
  ("concl", V("needcomp"), "judge this against Hartwell's earlier years or a target", GI()),
  "A because-style claim: the missing benchmark is the premise; the specialist's advice to compare with earlier years or a target is encoded as the required comparison.")

# 13 g6.1
r.add("g6.1@business-management-specialist", "bm-g6.1",
  [("keepprod1","Bool","Option 1 sells existing products",GS()),("newmkt1","Bool","Option 1 sells in new markets (Germany and the Netherlands)",GS()),
   ("md","Bool","Option 1 is market development",GK())],
  [("p_keep",V("keepprod1"),"Option 1 sells Hartwell's existing ranges",GS(),"material"),
   ("p_newmkt",V("newmkt1"),"Option 1 sells to customers in Germany and the Netherlands, new markets",GS(),"material"),
   ("def_md",IMP(AND(V("keepprod1"),V("newmkt1")),V("md")),"the Ansoff matrix: existing product in a new market is market development",GK(),"material")],
  ("concl", V("md"), "Option 1 is market development", GK()),
  "Ansoff classification: existing product plus new market gives market development. The case facts are the premises.")

# 14 g7.1
r.add("g7.1@business-management-specialist", "bm-g7.1",
  [("newprod2","Bool","Option 2 launches a new product (wooden musical instruments)",GS()),("exmkt2","Bool","Option 2 sells to existing customers in the home market",GS()),
   ("pd","Bool","Option 2 is product development",GK())],
  [("p_newprod",V("newprod2"),"Option 2 launches a new product, wooden musical instruments",GS(),"material"),
   ("p_exmkt",V("exmkt2"),"Option 2 sells to existing customers in the home market",GS(),"material"),
   ("def_pd",IMP(AND(V("newprod2"),V("exmkt2")),V("pd")),"the Ansoff matrix: new product in an existing market is product development",GK(),"material")],
  ("concl", V("pd"), "Option 2 is product development", GK()),
  "Ansoff classification: new product in an existing market gives product development.")

# 15 g7.2 restates case
r.unsupported("g7.2@business-management-specialist",
  "The line restates the case description of Option 2 (new product, existing customers, website and 46 shops).",
  "the claim restates the case text; the only encoding is the case facts themselves, so there is no inference to check")

# 16 g8.1
r.add("g8.1@business-management-specialist", "bm-g8.1",
  [("cp1","Bool","Option 1 changes the product",GS()),("cm1","Bool","Option 1 changes the market",GS()),
   ("cp2","Bool","Option 2 changes the product",GS()),("cm2","Bool","Option 2 changes the market",GS()),
   ("div1","Bool","Option 1 is diversification",GK()),("div2","Bool","Option 2 is diversification",GK())],
  [("p_cp1",NOT(V("cp1")),"Option 1 does not change the product (existing ranges)",GS(),"material"),
   ("p_cm1",V("cm1"),"Option 1 changes the market",GS(),"material"),
   ("p_cp2",V("cp2"),"Option 2 changes the product",GS(),"material"),
   ("p_cm2",NOT(V("cm2")),"Option 2 does not change the market (existing customers)",GS(),"material"),
   ("def_div1",IFF(V("div1"),AND(V("cp1"),V("cm1"))),"diversification changes both product and market (Option 1)",GK(),"material"),
   ("def_div2",IFF(V("div2"),AND(V("cp2"),V("cm2"))),"diversification changes both product and market (Option 2)",GK(),"material")],
  ("concl", AND(NOT(V("div1")), NOT(V("div2"))), "neither option is diversification, because each changes only one of the two Ansoff dimensions", GK()),
  "Because-claim: each option changes exactly one dimension; diversification requires both, so neither is diversification.")

# 17 g10.1
r.add("g10.1@business-management-specialist", "bm-g10.1",
  [("better2","Bool","Option 2 is the better choice on balance",GI()),("choose2","Bool","Hartwell should choose Option 2",GI()),
   ("safety_ok","Bool","Option 2 passes the safety tests before the $290,000 is committed",GI()),
   ("demand_ok","Bool","a trial shows demand before the $290,000 is committed",GI())],
  [("p_better2",V("better2"),"Option 2 is the better choice on balance",GI(),"material"),
   ("link_rec",IMP(AND(V("better2"),V("safety_ok"),V("demand_ok")),V("choose2")),"Option 2 is chosen once it is the better option and the safety and demand conditions are met",GI(),"material")],
  ("concl", IMP(AND(V("safety_ok"),V("demand_ok")), V("choose2")), "Hartwell should choose Option 2, provided it can pass the safety tests and show demand before it commits the $290,000", GI()),
  "Conditional recommendation: Option 2 is chosen provided the safety and demand conditions hold. The condition set is the specialist's; the 'better option' premise is the specialist's own judgement (see g15.1).",
  flags=[("condition_scope","the recommendation may also depend on the pre-Christmas peak and the 46-shop trial, which the claim does not name here", ["recommendation conditional on safety and demand only", "recommendation conditional on the full three-part condition set"])])

# 18 g11.2
r.add("g11.2@business-management-specialist", "bm-g11.2",
  [("opt1cost","Int","cost of Option 1, $",GF()),("pbit25","Int","profit before interest and tax 2025, $",GF())],
  [P_OPT1, PBIT_CE],
  ("concl", AND(GE(pct(380000,336000), R("113.05")), LT(pct(380000,336000), R("113.15"))),
   "Option 1 costs $380,000, which is 113.1% of the 2025 profit before interest and tax", GF()),
  "Stated to one decimal place: exact value must lie in [113.05, 113.15). The exact value is about 113.095.")

# 19 g11.3
r.add("g11.3@business-management-specialist", "bm-g11.3",
  [("opt2cost","Int","cost of Option 2, $",GF()),("pbit25","Int","profit before interest and tax 2025, $",GF())],
  [P_OPT2, PBIT_CE],
  ("concl", AND(GE(pct(290000,336000), R("86.25")), LT(pct(290000,336000), R("86.35"))),
   "Option 2 costs $290,000, which is 86.3% of that profit", GF()),
  "Stated to one decimal place: exact value must lie in [86.25, 86.35). The exact value is about 86.310.")

# 20 g11.4
r.add("g11.4@business-management-specialist", "bm-g11.4",
  [("opt1cost","Int","cost of Option 1, $",GF()),("opt2cost","Int","cost of Option 2, $",GF()),("pbit25","Int","profit before interest and tax 2025, $",GF())],
  [P_OPT1, P_OPT2, PBIT_CE],
  ("concl", AND(EQ(SUB(V("opt1cost"),V("opt2cost")), I(90000)), LT(V("opt2cost"),V("pbit25")), GT(V("opt1cost"),V("pbit25"))),
   "Option 2 is $90,000 cheaper, its outlay is less than a full year's profit before interest and tax, and Option 1's outlay exceeds it", GF()),
  "Three exact comparisons: the $90,000 difference, Option 2 below the profit figure and Option 1 above it.")

# 21 g11.5
r.add("g11.5@business-management-specialist", "bm-g11.5",
  [("noforecast","Bool","the case gives no sales forecast for either option",GS()),("ratiosonly","Bool","the cost-to-profit ratios are the only quantified comparison available",GI())],
  [("p_noforecast",V("noforecast"),"the case gives no sales forecast for either option",GS(),"material"),
   ("link_a",IMP(V("noforecast"),V("ratiosonly")),"with no forecast, the cost-to-profit ratios are the only quantified comparison",GI(),"material")],
  ("concl", V("ratiosonly"), "these ratios are the only quantified comparison available", GI()),
  "A because-style claim: the missing sales forecast is the premise; the cost-to-profit ratios are the only quantified comparison.")

# 22 g12.1
r.add("g12.1@business-management-specialist", "bm-g12.1",
  [("craft","Bool","customers value the toys because they are handmade, water-based painted and durable",GS()),
   ("samecust2","Bool","Option 2 sells to the same customers through the same website and shops",GS()),
   ("fitsbrand","Bool","Option 2 fits what the case says about the brand",GI())],
  [("p_craft",V("craft"),"customers value handmade, water-based painted, durable toys",GS(),"material"),
   ("p_same",V("samecust2"),"Option 2 sells to existing customers through the website and shops",GS(),"material"),
   ("link_a",IMP(AND(V("craft"),V("samecust2")),V("fitsbrand")),"a brand built on craft and existing customers fits Option 2",GI(),"material")],
  ("concl", V("fitsbrand"), "Option 2 also fits what the case says about the brand", GI()),
  "The brand-fit link is the specialist's judgement, encoded as a specialist inference over the two case facts.")

# 23 g12.2
r.add("g12.2@business-management-specialist", "bm-g12.2",
  [("craft","Bool","customers value the toys because they are handmade, water-based painted and durable",GS()),
   ("samechan","Bool","Option 2 sells to the same customers through the same website and shops",GS()),
   ("chanexist","Bool","the sales channels for Option 2 already exist",GI())],
  [("p_craft",V("craft"),"customers value handmade, water-based painted, durable toys",GS(),"material"),
   ("p_samechan",V("samechan"),"Option 2 sells to the same customers through the same website and shops",GS(),"material"),
   ("link_a",IMP(V("samechan"),V("chanexist")),"sales to the same customers through the same channels means the channels already exist",GI(),"material")],
  ("concl", AND(V("craft"), V("chanexist")), "customers value the toys for their craft, and the sales channels already exist", GI()),
  "The 'because' reason is the case fact about customers; the 'so' step is the specialist's channel link.")

# 24 g12.3 restates
r.unsupported("g12.3@business-management-specialist",
  "The line restates the case's resource needs of Option 1 (online shop, trade-fair stand, German and Dutch staff).",
  "the claim restates the case's stated requirements of Option 1; its only encoding is the case fact itself, so there is no inference to check")

# 25 g13.1
r.unsupported("g13.1@business-management-specialist",
  "The line says the case against Option 2 is market saturation at home, which restates the case's note that Ruth believes the home market is close to saturation.",
  "the claim restates a single case fact (the belief about saturation) as the argument against Option 2; the only encoding is that fact itself, so there is no inference to check",
  flags=[("attribution","the case states the saturation view as Ruth's belief, not as established fact", ["Ruth believes the home market is saturated", "the home market is saturated"])])

# 26 g14.1
r.add("g14.1@business-management-specialist", "bm-g14.1",
  [("newcust1","Bool","Option 1 reaches customers Hartwell does not serve now",GS()),
   ("nonewprod1","Bool","Option 1 sells existing ranges, with no new product",GS()),
   ("avoidsafety1","Bool","Option 1 avoids the product-safety risk",GI())],
  [("p_newcust",V("newcust1"),"Option 1 reaches Germany and the Netherlands, customers Hartwell does not serve now",GS(),"material"),
   ("p_nonew",V("nonewprod1"),"Option 1 sells existing ranges",GS(),"material"),
   ("link_a",IMP(V("nonewprod1"),V("avoidsafety1")),"with no new product there are no new instrument safety tests",GI(),"material")],
  ("concl", AND(V("newcust1"), V("avoidsafety1")), "Option 1 would reach customers that Hartwell does not serve now, and it avoids the product-safety risk", GI()),
  "Conjunction of a case fact (new customers) and the specialist's link from having no new product to avoiding the safety risk.")

# 27 g14.3
r.add("g14.3@business-management-specialist", "bm-g14.3",
  [("evid","Bool","there is evidence of demand for Option 1 abroad",GS()),
   ("untested1","Bool","Option 1 is an untested market",GI()),
   ("opt1cost","Int","cost of Option 1, $",GF()),("opt2cost","Int","cost of Option 2, $",GF())],
  [("link_a",IMP(NOT(V("evid")),V("untested1")),"without evidence of demand abroad, Option 1 is an untested market",GI(),"material"),
   P_OPT1, P_OPT2],
  ("concl", IMP(NOT(V("evid")), AND(V("untested1"), GT(V("opt1cost"),V("opt2cost")))),
   "Without such evidence, Option 1 is an untested market at a higher cost", GI()),
  "Conditional claim: without demand evidence abroad, the market is untested (specialist link) and Option 1 costs more than Option 2 (case figures).")

# 28 g15.1
r.add("g15.1@business-management-specialist", "bm-g15.1",
  [("better2","Bool","Option 2 is the better choice on balance",GI()),
   ("builds2","Bool","Option 2 builds on existing customers",GS())],
  [("p_lower",LT(V("opt2cost"),V("opt1cost")),"Option 2 costs less than Option 1 (case figures)",GF(),"material"),
   ("p_builds",V("builds2"),"Option 2 sells to existing customers",GS(),"material"),
   ("link_a",IMP(AND(LT(V("opt2cost"),V("opt1cost")),V("builds2")),V("better2")),"a lower cost and existing customers make Option 2 the better choice on balance",GI("probable"),"material")],
  ("concl", V("better2"), "On balance, Option 2 is the better choice", GI()),
  "Because-claim: the cost comparison and the existing-customer fact are the reasons; the judgement link is the specialist's. The cost relative to profit is taken as the cost comparison here, since both costs exceed or fall below the same profit figure.")
# re-declare opt symbols for g15.1
r.claims["g15.1@business-management-specialist"]["problem"]["symbols"] += [
  {"name":"opt2cost","sort":"Int","meaning":"cost of Option 2, $","grounding":GF()},
  {"name":"opt1cost","sort":"Int","meaning":"cost of Option 1, $","grounding":GF()}]

# 29 g15.2 dependency
r.unsupported("g15.2@business-management-specialist",
  "The claim states that the recommendation depends on three named conditions (costed and passed safety tests within $290,000 before machinery is bought; a trial with some of the 46 shops shows demand; launch avoids the pre-Christmas peak).",
  "the claim is a dependency statement: the only encoding asserts the dependency as a premise and as the conclusion, so it has no independent inference to check")

# 30 g15.3
r.add("g15.3@business-management-specialist", "bm-g15.3",
  [("tests_met","Bool","the safety tests can be met",GI()),("alt1","Bool","Option 1 becomes the alternative",GI()),
   ("evid","Bool","there is evidence of demand abroad",GS())],
  [("link_a",IMP(NOT(V("tests_met")),V("alt1")),"if the safety tests cannot be met, Option 1 becomes the alternative",GI(),"material"),
   ("link_b",IMP(V("alt1"),V("evid")),"Option 1 as alternative is only supported with evidence of demand abroad",GI(),"material")],
  ("concl", IMP(NOT(V("tests_met")), IMP(V("alt1"), V("evid"))),
   "If the tests cannot be met, Option 1 becomes the alternative, but only with evidence of demand abroad", GI()),
  "Conditional claim with a 'only with' restriction, encoded as an implication from the alternative to the evidence.")

# 31 g16.3 instruction
r.unsupported("g16.3@business-management-specialist",
  "An instruction to the student on where to find LEGO's figures and how to compare them with Hartwell's figures.",
  "the claim is a study instruction, not an assertion that can be true or false; the only encoding restates the instruction")

# 32 g16.4 normative
r.unsupported("g16.4@business-management-specialist",
  "A normative suggestion on what the comparison with LEGO should explain.",
  "the claim is a normative guidance statement about what the answer should discuss, not a checkable assertion about the case")

def ratio_override(cid, sym, expr_def, label, concl_expr, meaning):
    p = r.claims[cid]["problem"]
    p["symbols"].append({"name": sym, "sort": "Real", "meaning": meaning, "grounding": GF()})
    p["premises"].insert(0, {"id": "p_def_" + sym, "expr": EQ(V(sym), expr_def), "label": label, "grounding": GF(), "materiality": "material"})
    p["conclusion"]["expr"] = concl_expr
    r.claims[cid]["interpretation"]["glossary"].append({"symbol": sym, "meaning": meaning, "grounding": GF()})

ratio_override("g3.4@business-management-specialist", "gpm", pct(1440000,2400000), "gross profit margin = 1,440,000 / 2,400,000 x 100",
  AND(GE(V("gpm"), R("59.995")), LT(V("gpm"), R("60.005"))), "gross profit margin in per cent, from the printed figures")
ratio_override("g3.5@business-management-specialist", "gp_per_dollar", DIV(R(1440000), R(2400000)), "gross profit per dollar of sales = 1,440,000 / 2,400,000",
  EQ(V("gp_per_dollar"), R("3/5")), "gross profit per dollar of sales")
ratio_override("g4.5@business-management-specialist", "roce", pct(336000,2250000), "ROCE in per cent = 336,000 / 2,250,000 x 100",
  AND(GE(V("roce"), R("14.925")), LT(V("roce"), R("14.935"))), "ROCE in per cent")
ratio_override("g4.6@business-management-specialist", "roce_dollar", DIV(R(336000), R(2250000)), "ROCE per dollar = 336,000 / 2,250,000",
  AND(GE(V("roce_dollar"), R("0.14925")), LT(V("roce_dollar"), R("0.14935"))), "profit before interest and tax per dollar of capital employed")
ratio_override("g11.2@business-management-specialist", "opt1_pct", pct(380000,336000), "Option 1 cost as per cent of profit = 380,000 / 336,000 x 100",
  AND(GE(V("opt1_pct"), R("113.05")), LT(V("opt1_pct"), R("113.15"))), "Option 1 cost as per cent of 2025 profit before interest and tax")
ratio_override("g11.3@business-management-specialist", "opt2_pct", pct(290000,336000), "Option 2 cost as per cent of profit = 290,000 / 336,000 x 100",
  AND(GE(V("opt2_pct"), R("86.25")), LT(V("opt2_pct"), R("86.35"))), "Option 2 cost as per cent of 2025 profit before interest and tax")
r.write()
