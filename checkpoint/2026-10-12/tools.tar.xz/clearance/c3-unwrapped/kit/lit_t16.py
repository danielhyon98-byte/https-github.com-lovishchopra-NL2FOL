from builder import *
r = Report("lit-t16")
D = "doc-hives"
# p1-point: "The poem never names the loss, so the grief has to be read from the hive, where the father's absence is felt through his routines."
sym = [
 ("noname", "Bool", "the poem never names the loss", G("supplied_text", "established", [(D, None)])),
 ("readhive", "Bool", "the grief has to be read from the hive", G("specialist_inference", "probable")),
 ("routine_ev", "Bool", "the speaker lights the smoker the way the father showed the speaker", G("quotation", "established", [(D, "I light the smoker the way he showed me")])),
 ("absroutine", "Bool", "the father's absence is felt through his routines", G("specialist_inference", "probable")),
]
prem = [
 ("p_noname", V("noname"), "the poem never names the loss", G("supplied_text", "established", [(D, None)]), "material"),
 ("link_a", IMP(V("noname"), V("readhive")), "a poem that never names the loss makes the grief read from the hive", G("specialist_inference", "probable"), "material"),
 ("p_routine", V("routine_ev"), "the speaker lights the smoker the way the father showed", G("quotation", "established", [(D, "I light the smoker the way he showed me")]), "material"),
 ("link_b", IMP(V("routine_ev"), V("absroutine")), "the father's routine is kept up, so his absence is felt through his routines", G("specialist_inference", "probable"), "material"),
]
concl = ("point", AND(V("readhive"), V("absroutine")),
         "the grief has to be read from the hive, where the father's absence is felt through his routines",
         G("specialist_inference", "probable"))
r.add("p1-point", "p1-point", sym, prem, concl,
      "Claim read as: the poem never names the loss (supplied fact), so the grief must be read from the hive, where the father's absence shows through the routine of smoking the hive. The routine link is the specialist's reading of the quoted smoker line.")
# p1-s11: "The retreat into small talk, "I say the weather. I say it will be fine.", reinforces this, because the reassurance is one the speaker does not seem to believe."
sym2 = [
 ("smalltalk", "Bool", "the speaker retreats into small talk", G("quotation", "established", [(D, "I say the weather. I say it will be fine.")])),
 ("unbelieved", "Bool", "the reassurance is one the speaker does not seem to believe", G("specialist_inference", "probable")),
 ("reinforce", "Bool", "the small talk reinforces the reading of grief as a silence that cannot be broken", G("specialist_inference", "probable")),
]
prem2 = [
 ("p_smalltalk", V("smalltalk"), "the speaker retreats into small talk", G("quotation", "established", [(D, "I say the weather. I say it will be fine.")]), "material"),
 ("p_unbelieved", V("unbelieved"), "the reassurance is one the speaker does not seem to believe", G("specialist_inference", "probable"), "material"),
 ("link_c", IMP(V("unbelieved"), V("reinforce")), "a reassurance the speaker does not believe reinforces the silence reading", G("specialist_inference", "probable"), "material"),
]
concl2 = ("point", V("reinforce"), "the retreat into small talk reinforces this", G("specialist_inference", "probable"))
r.add("p1-s11", "p1-s11", sym2, prem2, concl2,
      "The claim is a because-clause: the reassurance the speaker does not seem to believe is the premise, the link is the specialist's, and the conclusion is that the small talk reinforces the reading. 'This' is taken as the silence reading of the stanza about telling the bees, which the claim does not name.",
      flags=[("referent_this", "the referent of 'this' is not named; the claim could mean the grief read from the hive or the silence that cannot be broken", ["grief as a silence that cannot be broken", "the grief read from the hive"])])
# p2-point: a next-step instruction, not an assertion
r.unsupported("p2-point",
  "The sentence is a next-step instruction to the student (draft a second paragraph and test a reading). It carries no assertion that could be true or false.",
  "the claim is an imperative study instruction, not a proposition; the only encoding would restate the instruction itself")
r.write()
