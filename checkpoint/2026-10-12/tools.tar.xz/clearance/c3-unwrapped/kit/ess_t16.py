from builder import *
r = Report("ess-t16")
D = "doc-halden"
TS = lambda: G("supplied_text", "established", [(D, None)])
AF = lambda: G("arithmetic_fact", "established", [(D, None)])
GK = lambda c="established": G("general_knowledge", c)
GI = lambda c="established": G("specialist_inference", c)
def rs(name, meaning, g=None): return (name, "Real", meaning, g if g is not None else AF())
def pf(pid, expr, label, g=None): return (pid, expr, label, g if g is not None else AF(), "material")

# s1.2 method statement
r.unsupported("s1.2", "A statement that the booklet is a fictional practice case and its figures are used as given.",
  "a statement about the source and the method, not a claim about Halden Moss to check")

# s2.2 volume
r.add("s2.2", "ess-s2.2",
  [rs("area_ha","area of Halden Moss, ha"), rs("area_m2","area of Halden Moss, m2"), rs("vol_m3","volume of peat, m3")],
  [pf("p_area", EQ(V("area_ha"), R("840")), "Halden Moss is 840 ha (Figure 1)", TS()),
   pf("d_m2", EQ(V("area_m2"), MUL(V("area_ha"), R("10000"))), "1 ha = 10,000 m2", GK()),
   pf("d_vol", EQ(V("vol_m3"), MUL(V("area_m2"), R("9/2"))), "volume = area x mean depth 4.5 m", AF())],
  ("concl", AND(EQ(V("area_m2"), R("8400000")), EQ(V("vol_m3"), R("37800000"))),
   "840 ha = 8,400,000 m2; 8,400,000 m2 x 4.5 m = 37,800,000 m3", AF()),
  "Unit conversion and a volume product from the Figure 1 area and depth.")

# s2.3 mass
r.add("s2.3", "ess-s2.3",
  [rs("vol_m3","volume of peat, m3"), rs("mass_kg","mass of carbon, kg"), rs("mass_t","mass of carbon, tonnes")],
  [pf("p_vol", EQ(V("vol_m3"), R("37800000")), "volume of peat is 37,800,000 m3", AF()),
   pf("d_kg", EQ(V("mass_kg"), MUL(V("vol_m3"), R("52"))), "carbon mass = volume x 52 kg per m3 (Figure 2)", TS()),
   pf("d_t", EQ(V("mass_t"), DIV(V("mass_kg"), R("1000"))), "1 tonne = 1000 kg", GK())],
  ("concl", AND(EQ(V("mass_kg"), R("1965600000")), EQ(V("mass_t"), R("1965600"))),
   "Mass of carbon = 37,800,000 m3 x 52 kg m-3 = 1,965,600,000 kg = 1,965,600 t", AF()),
  "Exact multiplication and unit conversion.")

# s2.4 answer 3 s.f.
r.add("s2.4", "ess-s2.4",
  [rs("mass_t","mass of carbon, tonnes")],
  [pf("p_mass", EQ(V("mass_t"), R("1965600")), "mass of carbon is 1,965,600 t", AF())],
  ("concl", AND(GE(V("mass_t"), R("1965000")), LT(V("mass_t"), R("1975000"))),
   "Answer: about 1.97 x 10^6 t of carbon (3 s.f.)", AF()),
  "Stated to three significant figures: the exact value must lie in [1,965,000, 1,975,000).",
  flags=[("vague_about","'about' is attached to a figure with stated 3 s.f.; the encoding uses the 3 s.f. precision", ["3 s.f. precision", "a looser tolerance"])])

# s3.1 CO2 from drained area
r.add("s3.1", "ess-s3.1",
  [rs("drained_ha","drained area, ha"), rs("co2_yr","CO2 released per year by drained peat, t")],
  [pf("p_area", EQ(V("drained_ha"), R("610")), "610 ha drained (Figure 1)", TS()),
   pf("d_co2", EQ(V("co2_yr"), MUL(V("drained_ha"), R("6"))), "drained peat releases 6.0 t CO2 per ha per year (Figure 2)", TS())],
  ("concl", EQ(V("co2_yr"), R("3660")), "Carbon dioxide released = 610 ha x 6.0 t CO2 ha-1 yr-1 = 3,660 t CO2 per year", AF()),
  "Area times the drained rate.")

# s3.2 answer restating the same computation
r.add("s3.2", "ess-s3.2",
  [rs("drained_ha","drained area, ha"), rs("co2_yr","CO2 released per year by drained peat, t")],
  [pf("p_area", EQ(V("drained_ha"), R("610")), "610 ha drained (Figure 1)", TS()),
   pf("d_co2", EQ(V("co2_yr"), MUL(V("drained_ha"), R("6"))), "drained peat releases 6.0 t CO2 per ha per year (Figure 2)", TS())],
  ("concl", EQ(V("co2_yr"), R("3660")), "Answer: 3,660 t of carbon dioxide each year", AF()),
  "The answer states the product computed in s3.1; the encoding is the same computation, not a new inference.")

# s4.2 drainage -> oxygen
r.add("s4.2", "ess-s4.2",
  [("drain","Bool","the peat was drained with ditches",TS()),("lowwt","Bool","drainage lowers the water table",GK()),
   ("oxy","Bool","oxygen reaches the peat",GK())],
  [("p_drain",V("drain"),"610 ha were drained with ditches between 1962 and 1988",TS(),"material"),
   ("l1",IMP(V("drain"),V("lowwt")),"drainage lowers the water table",GK(),"material"),
   ("l2",IMP(V("lowwt"),V("oxy")),"a lower water table lets oxygen reach the peat",GK(),"material")],
  ("concl", V("oxy"), "Drainage lowers the water table, so oxygen reaches the peat", GK()),
  "Two-step causal chain: drainage, lower water table, oxygen in the peat.")

# s4.4 compost peat
r.add("s4.4", "ess-s4.4",
  [("cutexp","Bool","peat cut for garden compost is removed and exposed to air",TS()),
   ("decomp","Bool","the carbon in the exposed peat decomposes",GK()),("released","Bool","the carbon is released as carbon dioxide",GK())],
  [("p_cut",V("cutexp"),"peat was cut for garden compost on part of the drained area and removed",TS(),"material"),
   ("l1",IMP(V("cutexp"),V("decomp")),"exposed peat decomposes",GK(),"material"),
   ("l2",IMP(V("decomp"),V("released")),"decomposing carbon is released as carbon dioxide",GK(),"material")],
  ("concl", V("released"), "Peat cut for garden compost is removed and exposed to air, so the carbon in it is released as carbon dioxide", GK()),
  "Chain from removal and exposure, through decomposition, to release as CO2.")

# s5.1 Ashmere value system
r.add("s5.1", "ess-s5.1",
  [("usepeople","Bool","the stakeholder values the land for what it gives people",GI()),
   ("anthro","Bool","Ashmere Forestry Ltd holds an anthropocentric value system",GK())],
  [("p_use",V("usepeople"),"Ashmere values the land for timber and jobs (Figure 3)",GI(),"material"),
   ("def_anth",IMP(V("usepeople"),V("anthro")),"a value system that values nature for human use is anthropocentric",GK(),"material")],
  ("concl", V("anthro"), "Ashmere Forestry Ltd: an anthropocentric value system", GK()),
  "Classification by the definition of anthropocentric values.")

# s5.2 Ashmere supporting statement (attribution of job loss not in the stakeholder text)
r.add("s5.2", "ess-s5.2",
  [rs("timber","timber value per year claimed by Ashmere, $"), rs("jobs","local jobs supported by Ashmere's conifers"),
   ("valpeople","Bool","Ashmere values the land for what it gives people",GI()),
   ("timberlost","Bool","Ashmere says the timber would be lost if the ditches were blocked",GI()),
   ("jobslost","Bool","Ashmere says the twelve jobs would be lost if the ditches were blocked",GI())],
  [pf("p_timber", EQ(V("timber"), R("310000")), "timber worth about $310,000 a year (Figure 3)", TS()),
   pf("p_jobs", EQ(V("jobs"), R("12")), "conifers support twelve local jobs (Figure 3)", TS()),
   ("p_block",V("timberlost"),"Blocking the ditches would kill the trees (Figure 3)",TS(),"material"),
   ("link_v",IMP(AND(GE(V("timber"),R("0")),V("valpeople")),V("valpeople")),"timber and jobs are the stated uses; the value is for people",GI(),"material")],
  ("concl", AND(V("valpeople"), EQ(V("timber"), R("310000")), EQ(V("jobs"), R("12")), V("timberlost"), V("jobslost")),
   "It values the land for what it gives people: timber worth about $310,000 a year and twelve local jobs, both of which it says would be lost if the ditches were blocked", GI()),
  "The claim says Ashmere says both the timber and the jobs would be lost. The booklet's Ashmere text says only that blocking the ditches would kill the trees; the job loss is not in the supplied text, so the encoding leaves it unsupported.",
  flags=[("attribution_jobs","the source attributes the loss of the trees to blocking the ditches, but the claim also attributes the loss of the twelve jobs to Ashmere", ["Ashmere says timber and jobs would be lost", "Ashmere says only the trees would be lost"]),
         ("vague_about","'about $310,000' is an approximate figure with no stated precision", ["$310,000 as stated", "a range around $310,000"])])

# s6.1 Trust value system
r.add("s6.1", "ess-s6.1",
  [("bogvalue","Bool","the Trust values the bog for its living communities and rare habitats (Figure 3)",GI()),
   ("ecoc","Bool","the Halden Moss Trust holds an ecocentric value system",GK())],
  [("p_bog",V("bogvalue"),"raised bogs are rare habitats and rewetting would bring back curlews and sundews (Figure 3)",TS(),"material"),
   ("def_eco",IMP(V("bogvalue"),V("ecoc")),"a value system that values nature for its own living communities is ecocentric",GK(),"material")],
  ("concl", V("ecoc"), "Halden Moss Trust: an ecocentric value system", GK()),
  "Classification by the definition of ecocentric values.")

# s7.1 evaluation thesis
r.add("s7.1", "ess-s7.1",
  [rs("rew","rewetted emission, t CO2 per ha per year",TS()), rs("dr","drained emission, t CO2 per ha per year",TS()),
   ("estimate","Bool","the rewetted figure is an estimate",TS()),("reduces","Bool","rewetting reduces emissions from the drained peat",GI()),
   ("costgroups","Bool","the costs fall on particular groups",GI())],
  [pf("p_rew", EQ(V("rew"), R("1.5")), "rewetted peat releases the equivalent of 1.5 t CO2 per ha per year (estimate)", TS()),
   pf("p_dr", EQ(V("dr"), R("6")), "drained peat releases 6.0 t CO2 per ha per year", TS()),
   ("p_est",V("estimate"),"the 1.5 t rewetted figure is an estimate",TS(),"material"),
   ("l_red",IMP(LT(V("rew"),V("dr")),V("reduces")),"a lower emission from rewetting reduces emissions",GK(),"material"),
   ("p_cost",V("costgroups"),"costs fall on Ashmere's jobs and the dairy farmer's fields",GI(),"material")],
  ("concl", AND(V("reduces"), V("estimate"), V("costgroups")),
   "Rewetting reduces emissions from the drained peat, but the gain rests on an estimate, and its costs fall on particular groups", GI()),
  "Evaluation thesis: three parts, each checked from the booklet figures or the specialist's stated links.")

# s8.2 fall and percentage
r.add("s8.2", "ess-s8.2",
  [rs("rew","rewetted emission, t CO2 per ha per year",TS()), rs("dr","drained emission, t CO2 per ha per year",TS()),
   rs("fall","fall in emission, t CO2 per ha per year")],
  [pf("p_rew", EQ(V("rew"), R("1.5")), "rewetted peat releases about 1.5 t CO2 per ha per year (estimate)", TS()),
   pf("p_dr", EQ(V("dr"), R("6")), "drained peat releases 6.0 t CO2 per ha per year", TS()),
   pf("d_fall", EQ(V("fall"), SUB(V("dr"), V("rew"))), "fall = drained minus rewetted", AF())],
  ("concl", AND(EQ(V("fall"), R("9/2")), EQ(DIV(V("fall"), R("6")), R("3/4"))),
   "A fall of 4.5 t ha-1 yr-1, or 75%", AF()),
  "The fall is 4.5 t; 4.5 over the drained 6.0 t is 75%.",
  flags=[("vague_about","'about 1.5 t' is stated as an estimate and the figure is given to one decimal place", ["1.5 t exactly", "1.5 t to one decimal place"])])

# s8.3 saving across area
r.add("s8.3", "ess-s8.3",
  [rs("drained_ha","drained area, ha"), rs("fall","fall in emission, t CO2 per ha per year"), rs("saving","saving across the drained area, t CO2 per year")],
  [pf("p_area", EQ(V("drained_ha"), R("610")), "610 ha drained", TS()),
   pf("p_fall", EQ(V("fall"), R("9/2")), "the fall is 4.5 t CO2 per ha per year", AF()),
   pf("d_sav", EQ(V("saving"), MUL(V("fall"), R("610"))), "saving = fall x 610 ha", AF())],
  ("concl", EQ(V("saving"), R("2745")), "Across the 610 ha drained, that is about 2,745 t CO2 a year less", AF()),
  "Product of the per-hectare fall and the drained area.",
  flags=[("vague_about","'about 2,745' is an exact product of the stated figures; 'about' is not given a precision", ["exact 2,745", "approximately 2,745"])])

# s9.1 estimate and balance
r.add("s9.1", "ess-s9.1",
  [("estimate","Bool","the 1.5 t figure is an estimate for ten years after the ditches are blocked",TS()),
   ("notmeas","Bool","the figure is not a measurement",GK()),
   ("rewflux","Real","rewetted net flux, t CO2 per ha per year (positive is release)",TS()),
   ("undflux","Real","undrained net flux, t CO2 per ha per year (positive is release)",AF()),
   ("above","Bool","the rewetted flux stays above the undrained balance",AF())],
  [("p_est",V("estimate"),"the 1.5 t figure is an estimate for ten years after the ditches are blocked (Figure 2)",TS(),"material"),
   ("def_nm",IMP(V("estimate"),V("notmeas")),"an estimate is not a measurement",GK(),"material"),
   pf("p_rewflux", EQ(V("rewflux"), R("1.5")), "rewetted peat releases the equivalent of 1.5 t CO2 per ha per year", TS()),
   pf("d_undflux", EQ(V("undflux"), SUB(R("0.6"), R("0.9"))), "undrained net flux = methane 0.6 minus removal 0.9 (positive is release)", AF()),
   pf("d_above", IFF(V("above"), GT(V("rewflux"), V("undflux"))), "'above' read as a higher net flux (release) than the undrained balance", GI("probable"))],
  ("concl", AND(V("estimate"), V("notmeas"), V("above")),
   "The 1.5 t figure is an estimate for ten years after the ditches are blocked, not a measurement, and it stays above the undrained bog's balance", GI("probable")),
  "'Above the undrained bog's balance' needs a sign convention; the encoding reads it as a higher net release.",
  flags=[("sign_convention","'above the balance' could mean a higher net release, or a higher value on a sink-positive scale", ["higher net release (CO2 positive)", "higher net sink (sink positive)"])])

# s9.2 undrained net sink
r.add("s9.2", "ess-s9.2",
  [rs("removal","CO2 removed by undrained peat, t per ha per year"), rs("methane","methane equivalent, t CO2 per ha per year"),
   rs("netsink","net sink of undrained peat, t CO2 per ha per year")],
  [pf("p_rem", EQ(V("removal"), R("0.9")), "undrained peat removes 0.9 t CO2 per ha per year (Figure 2)", TS()),
   pf("p_meth", EQ(V("methane"), R("0.6")), "methane with the warming effect of 0.6 t CO2 per ha per year (Figure 2)", TS()),
   pf("d_net", EQ(V("netsink"), SUB(V("removal"), V("methane"))), "net sink = removal minus methane equivalent", AF())],
  ("concl", AND(EQ(V("netsink"), R("3/10")), GT(V("netsink"), R("0"))),
   "Undrained peat is a net sink of about 0.3 t CO2 per ha per year", AF()),
  "Exact value 0.3; 'about' is attached to a figure with one decimal place.",
  flags=[("vague_about","'about 0.3' with no further precision; the exact value is 0.3", ["exact 0.3", "0.3 to one decimal place"])])

# s9.3 judgement from s9.1 and s9.2
r.add("s9.3", "ess-s9.3",
  [rs("rewflux","rewetted net flux, t CO2 per ha per year (positive is release)",TS()),
   rs("undflux","undrained net flux, t CO2 per ha per year (positive is release)"),
   ("restore","Bool","rewetting restores the undrained balance quickly",GI()),
   ("link_gt","Bool","the rewetted flux is above the undrained flux",AF())],
  [pf("p_rewflux", EQ(V("rewflux"), R("1.5")), "rewetted flux 1.5 t CO2 per ha per year (estimate)", TS()),
   pf("d_undflux", EQ(V("undflux"), SUB(R("0.6"), R("0.9"))), "undrained flux is -0.3 (methane 0.6 minus removal 0.9)", AF()),
   ("link_r",IMP(GT(V("rewflux"),V("undflux")),NOT(V("restore"))),"while rewetted peat stays above the undrained balance, rewetting does not restore that balance quickly",GI(),"material")],
  ("concl", NOT(V("restore")), "Rewetting therefore does not restore that balance quickly", GI()),
  "Conclusion follows from the estimate-above-balance comparison and the specialist's link.")

# s12.2 normative recommendation
r.unsupported("s12.2", "A recommendation that rewetting should go ahead only with compensation for flooding and lost jobs, with examples of payments and a managed move away from timber.",
  "the claim is a normative recommendation about policy, not a checkable assertion about the case")
r.write()
