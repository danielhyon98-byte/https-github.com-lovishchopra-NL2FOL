from builder import *
r = Report("cs-p10a")
TS = lambda: G("task_setting", "established")
GK = lambda: G("general_knowledge", "established")
GF = lambda: G("arithmetic_fact", "established")
GI = lambda c="established": G("specialist_inference", c)
COUNTS = [("tp","Int","true positives (aluminium correctly flagged), count",TS()),
          ("fp","Int","false positives (non-aluminium flagged), count",TS()),
          ("fn","Int","false negatives (aluminium missed), count",TS()),
          ("tn","Int","true negatives (non-aluminium rejected), count",TS()),
          ("total","Int","test set size, count",TS())]
CP = [("p_tp",EQ(V("tp"),I(132)),"132 aluminium items correctly identified",TS(),"material"),
      ("p_fp",EQ(V("fp"),I(18)),"18 non-aluminium items wrongly flagged",TS(),"material"),
      ("p_fn",EQ(V("fn"),I(12)),"12 aluminium items missed",TS(),"material"),
      ("p_tn",EQ(V("tn"),I(438)),"438 non-aluminium items correctly rejected",TS(),"material"),
      ("p_total",EQ(V("total"),I(600)),"test set of 600 items",TS(),"material")]
def sym_list(names):
    d = {s[0]: s for s in COUNTS}
    return [d[n] for n in names]

# c1.1 self-report
r.unsupported("c1.1", "A statement that the figures were calculated by hand without running code.",
  "a self-report about the method, not a claim about the classifier; no property to check")
# c1.2 restates
r.unsupported("c1.2", "The four test counts (TP 132, FP 18, FN 12, TN 438) restate the figures given in the task.",
  "the claim restates the task's counts; the only encoding is the task setting itself, so there is no inference to check")
# c1.3 sum check
r.add("c1.3", "cs-p10a-c1.3", sym_list(["tp","fp","fn","tn","total"]), [CP[0],CP[1],CP[2],CP[3],CP[4]],
  ("concl", EQ(ADD(V("tp"),V("fp"),V("fn"),V("tn")), I(600)), "Check: 132 + 18 + 12 + 438 = 600", GF()),
  "Sum of the four counts equals the test-set size; exact integer arithmetic.")
# c2.1 heading
r.unsupported("c2.1", "A heading introducing the confusion matrix and its axis convention.",
  "a heading, not an assertion; the matrix cells are the rows c3.2 to c3.4")
# c3.2 row aluminium
r.add("c3.2", "cs-p10a-c3.2", sym_list(["tp","fp","fn","tn","total"]), CP[:4],
  ("concl", AND(EQ(V("tp"),I(132)), EQ(V("fn"),I(12)), EQ(ADD(V("tp"),V("fn")),I(144))),
   "Actually aluminium row: 132 (TP), 12 (FN), total 144", GF()),
  "Row total is the sum of the two cells; the cell values are the task counts.")
r.add("c3.3", "cs-p10a-c3.3", sym_list(["tp","fp","fn","tn","total"]), CP[:4],
  ("concl", AND(EQ(V("fp"),I(18)), EQ(V("tn"),I(438)), EQ(ADD(V("fp"),V("tn")),I(456))),
   "Actually not aluminium row: 18 (FP), 438 (TN), total 456", GF()),
  "Row total is the sum of the two cells; the cell values are the task counts.")
r.add("c3.4", "cs-p10a-c3.4", sym_list(["tp","fp","fn","tn","total"]), CP,
  ("concl", AND(EQ(ADD(V("tp"),V("fp")),I(150)), EQ(ADD(V("fn"),V("tn")),I(450)), EQ(ADD(V("tp"),V("fp"),V("fn"),V("tn")),I(600))),
   "Column totals 150 and 450 and grand total 600", GF()),
  "Predicted-column totals and the grand total from the four counts.")

ACC = ("acc","Real","accuracy = (TP + TN) / total",GF())
PREC = ("prec","Real","precision = TP / (TP + FP)",GF())
REC = ("rec","Real","recall = TP / (TP + FN)",GF())
# c4.1 accuracy
r.add("c4.1", "cs-p10a-c4.1", sym_list(["tp","tn"]) + [ACC] + sym_list(["tp","tn"])[:0],
  [CP[0],CP[3],("d_acc",EQ(V("acc"),DIV(TOREAL(ADD(V("tp"),V("tn"))),R("600"))),"accuracy = (132 + 438) / 600",GF(),"material")],
  ("concl", AND(EQ(V("acc"),R("19/20")), GE(V("acc"),R("0.9495")), LT(V("acc"),R("0.9505"))),
   "Accuracy = 570 / 600 = 19/20 = 0.950 (3 s.f.)", GF()),
  "Exact value 19/20; the three significant figure form lies in [0.9495, 0.9505).")
# c5.1 precision
r.add("c5.1", "cs-p10a-c5.1", sym_list(["tp","fp"]) + [PREC],
  [CP[0],CP[1],("d_prec",EQ(V("prec"),DIV(TOREAL(V("tp")),R("150"))),"precision = 132 / (132 + 18)",GF(),"material"),
   ("p_150",EQ(ADD(V("tp"),V("fp")),I(150)),"TP + FP = 150",GF(),"material")],
  ("concl", AND(EQ(V("prec"),R("22/25")), GE(V("prec"),R("0.8795")), LT(V("prec"),R("0.8805"))),
   "Precision = 132 / 150 = 22/25 = 0.880 (3 s.f.)", GF()),
  "Exact value 22/25 = 0.88; the three significant figure form lies in [0.8795, 0.8805).")
# c6.1 recall (claims c4.1 and c5.1 as support)
r.add("c6.1", "cs-p10a-c6.1", sym_list(["tp","fn"]) + [REC],
  [CP[0],CP[2],("d_rec",EQ(V("rec"),DIV(TOREAL(V("tp")),R("144"))),"recall = 132 / (132 + 12)",GF(),"material"),
   ("p_144",EQ(ADD(V("tp"),V("fn")),I(144)),"TP + FN = 144",GF(),"material")],
  ("concl", AND(EQ(V("rec"),R("11/12")), GE(V("rec"),R("0.9165")), LT(V("rec"),R("0.9175"))),
   "Recall = 132 / 144 = 11/12 = 0.917 (3 s.f.)", GF()),
  "Exact value 11/12; the three significant figure form lies in [0.9165, 0.9175).")
# c7.1 formula definition
r.unsupported("c7.1", "A definition of the F1 score as the harmonic mean of precision and recall.",
  "a definition, not a claim about the classifier; its only encoding restates the definition")
# c7.2 F1 from counts
r.add("c7.2", "cs-p10a-c7.2", sym_list(["tp","fp","fn"]) + [("f1","Real","F1 score from the counts",GF())],
  [CP[0],CP[1],CP[2],
   ("p_den",EQ(ADD(MUL(I(2),V("tp")),V("fp"),V("fn")),I(294)),"2TP + FP + FN = 294",GF(),"material"),
   ("d_f1",EQ(V("f1"),DIV(TOREAL(MUL(I(2),V("tp"))),R("294"))),"F1 = 2 x 132 / 294",GF(),"material")],
  ("concl", AND(EQ(V("f1"),R("44/49")), GE(V("f1"),R("0.8975")), LT(V("f1"),R("0.8985"))),
   "F1 = 264 / 294 = 44/49 = 0.898 (3 s.f.)", GF()),
  "Exact value 44/49; the three significant figure form lies in [0.8975, 0.8985).")
# c8.1 rounded values
r.add("c8.1", "cs-p10a-c8.1",
  [("f1r","Real","F1 from the rounded precision 0.880 and recall 0.917",GI()),
   ("prec_r","Real","precision rounded to 0.880 (from b)",GI()),("rec_r","Real","recall rounded to 0.917 (from b)",GI())],
  [("t_prec",EQ(V("prec_r"),R("0.880")),"rounded precision 0.880",GI(),"material"),
   ("t_rec",EQ(V("rec_r"),R("0.917")),"rounded recall 0.917",GI(),"material"),
   ("d_f1r",EQ(V("f1r"),DIV(MUL(R("2"),R("0.880"),R("0.917")),R("1.797"))),"F1 = 2 x 0.880 x 0.917 / (0.880 + 0.917)",GF(),"material")],
  ("concl", AND(GE(V("f1r"),R("0.8975")), LT(V("f1r"),R("0.8985"))),
   "Using the rounded values gives the same answer: 2 x 0.880 x 0.917 / (0.880 + 0.917) = 0.898", GI()),
  "The rounded inputs give F1 of about 0.8981, which rounds to 0.898 as the specialist states.")
# c9.1 accuracy misleading (ambiguous 'mostly')
r.add("c9.1", "cs-p10a-c9.1",
  [("negshare","Real","share of test items that are not aluminium",GF()),
   ("maj_neg","Bool","the majority of items are not aluminium, so the accuracy mostly reflects rejection",GI("probable")),
   ("neg","Int","non-aluminium items in the test set, count",GF())] + sym_list(["fp","tn"]),
  [("p_neg",EQ(ADD(V("fp"),V("tn")),I(456)),"456 test items are not aluminium",GF(),"material"),
   ("d_neg",EQ(V("negshare"),DIV(TOREAL(V("neg")),R("600"))),"share not aluminium = 456 / 600",GF(),"material"),
   ("p_neg_def",EQ(V("neg"),ADD(V("fp"),V("tn"))),"non-aluminium count is FP plus TN",GF(),"material"),
   ("p_tn_c",EQ(V("tn"),I(438)),"438 non-aluminium items correctly rejected",TS(),"material"),
   ("p_fp_c",EQ(V("fp"),I(18)),"18 non-aluminium items wrongly flagged",TS(),"material"),
   ("link_maj",IMP(GT(V("negshare"),R("0.5")),V("maj_neg")),"when most items are not aluminium, accuracy mostly reflects how well negatives are rejected",GI("probable"),"material")],
  ("concl", AND(EQ(V("negshare"),R("19/25")), V("maj_neg")),
   "Most items are not aluminium (456 of 600, or 76%), so the 95% figure mostly reflects how well the classifier rejects ordinary items", GI("probable")),
  "The 'mostly' is vague: encoded as a majority-class effect with the specialist's probable link.",
  flags=[("vague_mostly","'mostly reflects' has no stated precision; the encoding uses majority class as the reason", ["accuracy is dominated by the majority class", "accuracy reflects both classes about equally"])])
# c9.2 all-reject classifier
r.add("c9.2", "cs-p10a-c9.2",
  [("neg","Int","non-aluminium items in the test set, count",GF()),("total","Int","test set size, count",TS()),
   ("allacc","Real","accuracy of a classifier rejecting every item",GK()),("alltp","Int","true positives of a classifier rejecting every item",GK())],
  [("p_neg",EQ(V("neg"),I(456)),"456 test items are not aluminium",GF(),"material"),
   ("p_total",EQ(V("total"),I(600)),"test set of 600 items",TS(),"material"),
   ("def_acc",EQ(V("allacc"),DIV(TOREAL(V("neg")),R("600"))),"a reject-all classifier is correct exactly on the non-aluminium items",GK(),"material"),
   ("def_tp",EQ(V("alltp"),I(0)),"a reject-all classifier flags no item as aluminium",GK(),"material")],
  ("concl", AND(EQ(V("allacc"),R("19/25")), EQ(V("alltp"),I(0))),
   "A classifier that rejected every item would score 0.76 on accuracy yet find no aluminium at all", GK()),
  "Reject-all baseline: accuracy equals the non-aluminium share, and recall is zero.")
# c9.3 this classifier
r.add("c9.3", "cs-p10a-c9.3",
  [("fn","Int","false negatives, count",TS()),("tp","Int","true positives, count",TS()),("fp","Int","false positives, count",TS()),
   ("rec","Real","recall",GF()),("prec","Real","precision",GF())],
  [("p_fn",EQ(V("fn"),I(12)),"12 aluminium items missed",TS(),"material"),
   ("p_tp",EQ(V("tp"),I(132)),"132 aluminium items correctly identified",TS(),"material"),
   ("p_fp",EQ(V("fp"),I(18)),"18 non-aluminium items wrongly flagged",TS(),"material"),
   ("d_rec",EQ(V("rec"),DIV(TOREAL(V("tp")),R("144"))),"recall = 132 / 144",GF(),"material"),
   ("d_prec",EQ(V("prec"),DIV(TOREAL(V("tp")),R("150"))),"precision = 132 / 150",GF(),"material")],
  ("concl", AND(EQ(ADD(V("tp"),V("fn")),I(144)), EQ(V("fn"),I(12)), GE(V("rec"),R("0.9165")), LT(V("rec"),R("0.9175")),
               EQ(V("fp"),I(18)), GE(V("prec"),R("0.8795")), LT(V("prec"),R("0.8805"))),
   "This classifier misses 12 of the 144 aluminium items (recall 0.917) and wrongly flags 18 non-aluminium items (precision 0.880)", GF()),
  "Counts and the two rounded ratios; the rounding bounds follow the precision rule.")

# null: 9.4 mixed, c10 handled below
r.unsupported("c9.4", "A statement that the 95% figure hides both errors and that the plant needs to know the cost of each.",
  "the first part is a general property of a single summary figure that the confusion-matrix claims already cover, and the second part is a normative statement about what the plant needs; no separate checkable assertion remains")

# c10.1 small k
r.add("c10.1", "cs-p10a-c10.1",
  [("k1","Bool","k is 1 (a small k)",GK()),("nearest1","Bool","each item is classified by its single nearest training example",GK()),
   ("noise","Bool","the boundary follows the noise in the training data",GI())],
  [("l1",IMP(V("k1"),V("nearest1")),"with k = 1 each item is classified by its single nearest training example",GK(),"material"),
   ("l2",IMP(V("nearest1"),V("noise")),"a single nearest neighbour lets the boundary follow training noise",GI(),"material")],
  ("concl", IMP(V("k1"), V("noise")), "a small k, such as k = 1, makes the boundary follow the noise in the training data", GI()),
  "The claim is about small k generally; the encoding uses k = 1, the example the claim names.",
  flags=[("scope_small_k","'small k' is general; the encoding covers only k = 1, the example named", ["small k in general", "k = 1 only"])])

# c11.1 large k
r.add("c11.1", "cs-p10a-c11.1",
  [("klarge","Bool","k is large",GI()),("majdom","Bool","the majority class dominates the vote",GK()),
   ("smooth","Bool","the boundary is too smooth to separate the materials",GI("probable"))],
  [("l1",IMP(V("klarge"),V("majdom")),"a large k lets the vote include so many neighbours that the majority class dominates",GK(),"material"),
   ("l2",IMP(V("majdom"),V("smooth")),"a dominant majority class makes the boundary too smooth",GI("probable"),"material")],
  ("concl", IMP(V("klarge"), V("smooth")), "a large k makes the boundary too smooth to separate the materials", GI("probable")),
  "Conditional chain for the large-k case; the majority-class figure (76% not aluminium) is the task context, not an extra premise.")

# null: advice
r.unsupported("c12.2", "A procedural recommendation: compare odd k values on the validation set by precision and recall, choose by priority, and prefer close training and validation results.",
  "the claim is a recommendation of what the plant should do, not a checkable assertion; its one factual part (odd k avoids ties in a two-class vote) is general knowledge that does not carry the recommendation")
r.unsupported("c12.3", "An instruction that the chosen k should be checked once on the test set.",
  "the claim is a procedural instruction, not an assertion that can be true or false")
r.write()
