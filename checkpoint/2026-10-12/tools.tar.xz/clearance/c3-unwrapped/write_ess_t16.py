import json, os

base = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c3"
with open(os.path.join(base, "tasks.json"), encoding="utf-8") as f:
    tasks = json.load(f)
task = next(t for t in tasks if t["task_id"] == "ess-t16")

response_text = """Assumption: SL, Paper 1 practice. The Halden Moss booklet is a fictional practice case, so I use its figures as given and do not check them against outside data.

(a) Volume of peat = area × mean depth
840 ha = 8,400,000 m² (1 ha = 10,000 m²); 8,400,000 m² × 4.5 m = 37,800,000 m³ [1]
Mass of carbon = 37,800,000 m³ × 52 kg m⁻³ = 1,965,600,000 kg = 1,965,600 t [1]
Answer: about 1.97 × 10⁶ t of carbon (3 s.f.)

(b) Carbon dioxide released = 610 ha × 6.0 t CO₂ ha⁻¹ yr⁻¹ = 3,660 t CO₂ yr⁻¹ [1]
Answer: 3,660 t of carbon dioxide each year

(c) 1. Drainage lowers the water table, so oxygen reaches the peat. Decomposers then break it down by aerobic respiration, releasing carbon dioxide that the waterlogged bog had kept stored. [1]
2. Peat cut for garden compost is removed and exposed to air, so the carbon in it decomposes and is released as carbon dioxide. [1]

(d) Ashmere Forestry Ltd: an anthropocentric value system. [1] It values the land for what it gives people: timber worth about $310,000 a year and twelve local jobs, both of which it says would be lost if the ditches were blocked. [1]

Halden Moss Trust: an ecocentric value system. [1] Its statement suggests that it values the bog for its living communities, which it calls "rare habitats", and wants curlews and sundews to return, rather than for its use to people. [1]

(e) Rewetting reduces emissions from the drained peat, but the gain rests on an estimate, and its costs fall on particular groups.

The strongest case is carbon. On the practice figures, rewetted peat releases about 1.5 t CO₂ ha⁻¹ yr⁻¹, against 6.0 t for drained peat: a fall of 4.5 t ha⁻¹ yr⁻¹, or 75%. Across the 610 ha drained, that is about 2,745 t CO₂ a year less. [1]

However, the 1.5 t figure is an estimate for ten years after the ditches are blocked, not a measurement, and it stays above the undrained bog's balance. Undrained peat removes 0.9 t CO₂ ha⁻¹ yr⁻¹ but releases methane equivalent to 0.6 t, so it is a net sink of about 0.3 t CO₂ ha⁻¹ yr⁻¹. Rewetting therefore does not restore that balance quickly. [1]

The costs are concentrated. Blocking the ditches would end the timber income and the twelve jobs cited by Ashmere Forestry Ltd, and the dairy farmer expects the lower fields to flood more often in winter. The booklet gives no offset for either loss. [1]

Rewetting does bring a benefit to water users. The water company says that drainage water from the peat carries dissolved organic carbon into the river, which costs it money to remove. Blocking the ditches would probably reduce that flow. [1]

On balance, rewetting is effective for cutting carbon emissions and may help water users. It should go ahead only with compensation for the flooding and the lost jobs, for example payments to the farmer and a managed move away from timber on the drained land. Without that, the losses fall on people who did not choose the change, and the strategy is less likely to last. [1]

Sources: Halden Moss resource booklet (supplied text); your question (supplied text); course notes on decomposition, value systems and evaluation (course notes)

Next step: time yourself on part (e) under the 450-word limit, and check that each point uses a figure from the booklet."""

task["response_text"] = response_text

outdir = os.path.join(base, "specialists")
os.makedirs(outdir, exist_ok=True)
outpath = os.path.join(outdir, "ess-t16.json")
with open(outpath, "w", encoding="utf-8") as f:
    json.dump(task, f, ensure_ascii=False, indent=2)
print(outpath)
