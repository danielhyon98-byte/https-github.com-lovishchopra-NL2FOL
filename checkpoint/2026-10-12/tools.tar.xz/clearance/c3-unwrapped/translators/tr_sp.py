import sys; sys.path.insert(0, "."); from tlib import *
S_INF = lambda c="established": G("specialist_inference", c)
GK = lambda c="established": G("general_knowledge", c)
BASE = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c3/translations/"

# ---- sp-t16 (report rep-sp-t16-0, request req-sp-t16)
REQ = "req-sp-t16"; D = "doc-rojas-student"; claims = {}
syms = [
 SYM("wc","Real","the word count of the student's email (as the specialist states it, about 300)", S_INF()),
 SYM("in_range","Bool","the email's length is within the 250 to 400 word range", S_INF()),
]
prem = [
 PREM("about300", AND(GE(V("wc"), R("299.5")), LT(V("wc"), R("300.5"))), "the email is about 300 words (the figure 300 read to its written precision)", S_INF()),
 PREM("range_req", IFF(V("in_range"), AND(GE(V("wc"), R(250)), LE(V("wc"), R(400)))), "the requested length is 250 to 400 words (a range the specialist states; it is not in the supplied task text)", S_INF()),
 PREM("so_link", IMP(V("about300"), V("in_range")), "about 300 words, so the length is within the range", S_INF()),
]
prem[0]["expr"] = AND(GE(V("wc"), R("299.5")), LT(V("wc"), R("300.5")))
prem[2]["expr"] = IMP(AND(GE(V("wc"), R("299.5")), LT(V("wc"), R("300.5"))), V("in_range"))
concl = CONCL("length", V("in_range"), "the length is right", S_INF())
claims["g1.3@language-b-spanish-specialist"] = TR(
 PROBLEM("sp-t16-g1-3", "g1.3@language-b-spanish-specialist", REQ, syms, prem, concl),
 "Read as: the email's length, about 300 words, falls within the 250 to 400 word range the specialist gives, so the length is right. The word count is the specialist's figure, not a count computed from the supplied email, and the 250 to 400 range is not in the supplied task text. 'About' has no stated precision; 300 is encoded to units (299.5 to 300.5) and that vagueness is flagged.",
 [FLAG("vague-figure","'about 300' has no stated precision; encoded at the written precision of 300 (units)", ["the count is exactly 300", "the count is within about 5% of 300"]),
  FLAG("source-range","the 250 to 400 word range is stated by the specialist, not by the supplied task", ["the range is a task requirement", "the range is the specialist's own guideline"])],
 ambiguous=True)

syms = [
 SYM("none_blocks","Bool","none of the errors in the email blocks its meaning", S_INF()),
 SYM("quickest","Bool","fixing the errors is the quickest route up for Language", S_INF()),
]
prem = [
 PREM("none_blocks", V("none_blocks"), "none of the errors blocks the meaning", S_INF()),
 PREM("so_link", IMP(V("none_blocks"), V("quickest")), "so fixing them is the quickest route up for Language", S_INF()),
]
concl = CONCL("quickest", V("quickest"), "fixing them is the quickest route up for Language", S_INF())
claims["g1.11@language-b-spanish-specialist"] = TR(
 PROBLEM("sp-t16-g1-11", "g1.11@language-b-spanish-specialist", REQ, syms, prem, concl),
 "Read as: the errors do not block meaning, so correcting them is the quickest route up for the Language criterion. The judgement that the errors do not block meaning is the specialist's; the link from it to 'quickest route' is the specialist's own 'so'. No quotation supports the judgement.",
 [])

syms = [
 SYM("espero_quote","Bool","the email reads 'Espero que nos vemos pronto' with the indicative 'vemos'", G("quotation","established",[REF(D,"Espero que nos vemos pronto")])),
 SYM("espero_trigger","Bool","the verb follows 'espero que' in the sentence", G("supplied_text","established",[REF(D,"Espero que nos vemos pronto")])),
 SYM("subj_required","Bool","the verb after 'espero que' must be in the subjunctive", GK()),
 SYM("correction","Bool","the verb should read 'veamos', the subjunctive form", S_INF()),
]
prem = [
 PREM("ev_quote", V("espero_quote"), "'Espero que nos vemos pronto'", G("quotation","established",[REF(D,"Espero que nos vemos pronto")])),
 PREM("trigger", V("espero_trigger"), "the verb is introduced by 'espero que'", G("supplied_text","established",[REF(D,"Espero que nos vemos pronto")])),
 PREM("rule", IMP(V("espero_trigger"), V("subj_required")), "'espero que' takes the subjunctive", GK()),
]
concl = CONCL("correction", AND(V("subj_required"), V("espero_quote")), "the indicative 'vemos' is used where the subjunctive is required, so the phrase should read 'Espero que nos veamos pronto'", S_INF())
claims["g1.22@language-b-spanish-specialist"] = TR(
 PROBLEM("sp-t16-g1-22", "g1.22@language-b-spanish-specialist", REQ, syms, prem, concl),
 "Read as: the quoted phrase uses the indicative 'vemos', and 'espero que' takes the subjunctive, so the correction to 'veamos' follows. The grammar rule is subject knowledge stated from memory and is grounded as general knowledge.",
 [])
write_report(BASE + "sp-t16.json", "rep-sp-t16-0", claims)

# ---- sp-p10d (report rep-sp-p10d-0, request req-sp-p10d)
REQ = "req-sp-p10d"; D = "doc-backofhouse"; claims = {}
claims["g1.1@language-b-spanish-specialist"] = NULLTR(
 "The claim is the title of the notes section: 'Notes on the Spanish in \"Back of House\"'.",
 "a heading of the notes: it states no proposition to check, and its only encoding restates the heading itself")

syms = [
 SYM("quema_in_poem","Bool","the poem contains 'quema' in '¡Ojo, que quema!'", G("quotation","established",[REF(D,"quema")])),
 SYM("quema_pres_ind","Bool","'quema' is the present indicative, third person singular, of quemar", GK()),
 SYM("states_fact","Bool","the clause in which 'quema' occurs states a fact", S_INF()),
 SYM("no_subj","Bool","no subjunctive is needed for 'quema'", GK()),
]
prem = [
 PREM("ev_quema", V("quema_in_poem"), "the poem contains 'quema'", G("quotation","established",[REF(D,"quema")])),
 PREM("form", V("quema_pres_ind"), "'quema' is the present indicative, 3rd person singular of quemar", GK()),
 PREM("fact", V("states_fact"), "the clause states a fact", S_INF()),
 PREM("rule", IMP(AND(V("quema_pres_ind"), V("states_fact")), V("no_subj")), "a present indicative that states a fact needs no subjunctive", GK()),
]
concl = CONCL("no_subj", V("no_subj"), "no subjunctive is needed", GK())
claims["g2.8@language-b-spanish-specialist"] = TR(
 PROBLEM("sp-p10d-g2-8", "g2.8@language-b-spanish-specialist", REQ, syms, prem, concl),
 "Read as: 'quema' is a present indicative form that states a fact, so no subjunctive is needed. The form and the rule are general knowledge; the claim that the clause states a fact is the specialist's own.",
 [])

syms = [
 SYM("echale_in_poem","Bool","the poem contains 'échale' in 'échale ganas, mijo'", G("quotation","established",[REF(D,"échale")])),
 SYM("stress_third_last","Bool","'échale' is stressed on its third-to-last syllable", GK()),
 SYM("accent_rule","Bool","a word stressed on its third-to-last syllable is written with a written accent", GK()),
 SYM("accent_written","Bool","the accent on 'échale' is written", GK()),
]
prem = [
 PREM("ev_echale", V("echale_in_poem"), "the poem contains 'échale'", G("quotation","established",[REF(D,"échale")])),
 PREM("stress", V("stress_third_last"), "the stress falls on the third-to-last syllable of 'échale'", GK()),
 PREM("rule", IMP(V("stress_third_last"), V("accent_written")), "a third-to-last stressed word is written with an accent", GK()),
]
concl = CONCL("accent", V("accent_written"), "the accent is written because the stress falls on the third-to-last syllable", GK())
claims["g2.12@language-b-spanish-specialist"] = TR(
 PROBLEM("sp-p10d-g2-12", "g2.12@language-b-spanish-specialist", REQ, syms, prem, concl),
 "Read as: the accent on 'échale' is written because the stress falls on its third-to-last syllable. The claim does not name a word; 'échale' is taken, as the specialist's own note on the same word does. 'Because' is read as the rule that makes the stress pattern require the accent, so the link is general knowledge rather than a causal claim about writers.",
 [FLAG("because-reading","'because' could be a causal explanation of why the accent is written, or a statement of the rule that licenses it", ["the accent is written by rule for this stress pattern", "the accent is written by convention, and the stress pattern is an evidential sign of it"])],
 ambiguous=True)
write_report(BASE + "sp-p10d.json", "rep-sp-p10d-0", claims)
print("wrote sp-t16, sp-p10d")
