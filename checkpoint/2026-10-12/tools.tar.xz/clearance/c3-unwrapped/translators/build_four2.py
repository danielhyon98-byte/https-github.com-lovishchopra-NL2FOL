import json, sys
from fractions import Fraction
sys.path.insert(0, "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c3/translators")
from tlib import *

BASE = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c3"
REQ_LL, REQ_PS, REQ_PH, REQ_MAA = "req-ll-t16", "req-ps-t16", "req-ph-t16", "req-maa-t16"

def RC(x):
    f = Fraction(x) if isinstance(x, str) else Fraction(x)
    s = str(f.numerator) if f.denominator == 1 else f"{f.numerator}/{f.denominator}"
    return {"op": "real", "value": s}

def defn(name, meaning, expr, kind="arithmetic_fact", refs=None):
    """A Real symbol held equal to a constant or linear expression, as a premise."""
    sym = SYM(name, "Real", meaning, G(kind, "established", refs or []))
    prem = PREM("d_" + name, EQ(V(name), expr), meaning, G(kind, "established"))
    return sym, prem

def qref(doc, ex):
    return [REF(doc, ex)]

def arith(pid, claim, req, defs, concl, label, reading, extra_syms=None, extra_prems=None):
    syms = [d[0] for d in defs] + (extra_syms or [])
    prems = [d[1] for d in defs] + (extra_prems or [])
    p = PROBLEM(pid, claim, req, syms, prems, CONCL("c", concl, label, G("arithmetic_fact", "established")))
    return TR(p, reading)

def null(reason):
    return NULLTR("Not formalised: " + reason, reason)

def chain(pid, claim, req, doc, excerpt, qsym, qmean, link_label, link_cert, csym, cmean, clabel, ccert, reading):
    syms = [SYM(qsym, "Bool", qmean, G("quotation", "established", [REF(doc, excerpt)])),
            SYM(csym, "Bool", cmean, G("specialist_inference", ccert))]
    prems = [PREM("ev_" + qsym, V(qsym), qmean, G("quotation", "established", [REF(doc, excerpt)])),
             PREM("link_" + csym, IMP(V(qsym), V(csym)), link_label, G("specialist_inference", link_cert))]
    c = CONCL("c_" + csym, V(csym), clabel, G("specialist_inference", ccert))
    return TR(PROBLEM(pid, claim, req, syms, prems, c), reading)

def boolchain(pid, claim, req, syms, prems, cid, cexpr, clabel, cg, reading):
    return TR(PROBLEM(pid, claim, req, syms, prems, CONCL(cid, cexpr, clabel, cg)), reading)

out = {}

# ---------------- LL: no argument claims; all null
ll_reason = ("the listed claim is a tutoring instruction, a statement about the student's notes, a sources list, "
             "a promise of feedback or a refusal to write the essay; it has no relation between premises and a point to check")
ll = {c: null(ll_reason) for c in ["p2-point", "p3-point", "p4-point", "p5-point", "p6-point", "p7-point", "p8-point", "p1-s01"]}
ll["p5-s03"] = null("an instruction with an inline method label ('check each claim against what appears on screen'); not a claim with a relation to check")
out["ll-t16"] = ll

# ---------------- PS
ps = {}
K = lambda k: f"{k}@psychology-specialist"
ps_doc = "doc-calmstep-s1"
ps[K("g2.3")] = TR(PROBLEM("ps-g2.3", K("g2.3"), REQ_PS,
    [SYM("stopped_app","Int","app-group students who stopped before week 6", G("quotation","established",qref(ps_doc,"Eleven students in the app group stopped using the app before week 6"))),
     SYM("stopped_wl","Int","waiting-list students who did not complete the second questionnaire", G("quotation","established",qref(ps_doc,"two students on the waiting list did not complete it")))],
    [PREM("pa", EQ(V("stopped_app"), I(11)), "eleven app-group students stopped", G("quotation","established",qref(ps_doc,"Eleven students in the app group stopped using the app before week 6"))),
     PREM("pw", EQ(V("stopped_wl"), I(2)), "two waiting-list students did not complete", G("quotation","established",qref(ps_doc,"two students on the waiting list did not complete it")))],
    CONCL("c", AND(GE(DIV(MUL(RC(100),TOREAL(V("stopped_app"))),RC(46)),RC("23.85")),
                   LT(DIV(MUL(RC(100),TOREAL(V("stopped_app"))),RC(46)),RC("23.95")),
                   GE(DIV(MUL(RC(100),TOREAL(V("stopped_wl"))),RC(46)),RC("4.25")),
                   LT(DIV(MUL(RC(100),TOREAL(V("stopped_wl"))),RC(46)),RC("4.35"))),
          "11 of 46 (23.9%) app students stopped; 2 of 46 (4.3%) waiting-list students did not complete", G("arithmetic_fact","established")))
    , "Percentages from Source 1's counts (46 per group), encoded to one decimal place. The denominator 46 is the stated group size.")

ps[K("g3.2")] = arith("ps-g3.2", K("g3.2"), REQ_PS,
    [defn("b_app","app-group mean before (13.6)", RC("13.6"), "quotation", qref(ps_doc,"13.6 (2.4)")),
     defn("a_app","app-group mean after (9.1)", RC("9.1"), "quotation", qref(ps_doc,"9.1 (3.0)")),
     defn("fall_app","fall in the app-group mean", SUB(V("b_app"),V("a_app")))],
    AND(EQ(V("fall_app"),RC("4.5")), GE(MUL(RC(100),DIV(V("fall_app"),RC("13.6"))),RC("32.5")), LT(MUL(RC(100),DIV(V("fall_app"),RC("13.6"))),RC("33.5"))),
    "fall of 4.5 points, about 33% of the starting 13.6", "Fall 13.6 - 9.1 = 4.5, and 4.5/13.6 is about 33% (nearest whole percent).")
ps[K("g3.3")] = arith("ps-g3.3", K("g3.3"), REQ_PS,
    [defn("b_wl","waiting-list mean before (13.4)", RC("13.4"), "quotation", qref(ps_doc,"13.4 (2.6)")),
     defn("a_wl","waiting-list mean after (12.8)", RC("12.8"), "quotation", qref(ps_doc,"12.8 (2.9)")),
     defn("fall_wl","fall in the waiting-list mean", SUB(V("b_wl"),V("a_wl")))],
    AND(EQ(V("fall_wl"),RC("0.6")), GE(MUL(RC(100),DIV(V("fall_wl"),RC("13.4"))),RC("3.5")), LT(MUL(RC(100),DIV(V("fall_wl"),RC("13.4"))),RC("4.5"))),
    "waiting-list fall of 0.6 points, about 4% of 13.4", "Fall 13.4 - 12.8 = 0.6, and 0.6/13.4 is about 4% (nearest whole percent).")
ps[K("g3.4")] = arith("ps-g3.4", K("g3.4"), REQ_PS,
    [defn("fall_app2","fall in the app-group mean", RC("4.5")),
     defn("fall_wl2","fall in the waiting-list mean", RC("0.6")),
     defn("diff_change","difference in change between the groups", SUB(V("fall_app2"),V("fall_wl2")))],
    EQ(V("diff_change"),RC("3.9")), "4.5 - 0.6 = 3.9 points",
    "Arithmetic of the difference in change only; the judgement that different starting levels are unlikely to explain it is not encoded.")
ps[K("g3.5")] = arith("ps-g3.5", K("g3.5"), REQ_PS,
    [defn("end_app","app-group mean at the end (9.1)", RC("9.1"), "quotation", qref(ps_doc,"9.1 (3.0)")),
     defn("end_wl","waiting-list mean at the end (12.8)", RC("12.8"), "quotation", qref(ps_doc,"12.8 (2.9)")),
     defn("end_gap","end-of-study gap, waiting list minus app", SUB(V("end_wl"),V("end_app")))],
    EQ(V("end_gap"),RC("3.7")), "At the end the app group scored 3.7 points lower (12.8 - 9.1)",
    "End-of-study gap between the two group means.")
ps[K("g3.6")] = arith("ps-g3.6", K("g3.6"), REQ_PS,
    [defn("gap37","end-of-study gap (3.7)", RC("3.7")),
     defn("sd29","standard deviation (2.9, stated in the table as the waiting-list SD at the end)", RC("2.9"), "quotation", qref(ps_doc,"12.8 (2.9)"))],
    AND(GE(DIV(V("gap37"),RC("2.9")),RC("1.25")), LT(DIV(V("gap37"),RC("2.9")),RC("1.35"))),
    "3.7 / 2.9 is about 1.3 (one decimal place)",
    "The ratio 3.7/2.9 to one decimal place. The table gives 2.9 as a waiting-list SD; the claim's 'about 2.9' is taken as that value.")
ps[K("g2.4")] = null("a judgement that the analysed groups no longer match those created by random allocation; a qualitative claim without a checkable relation over the figures")
ps[K("g2.6")] = null("a 'possible' speculation about who stayed in the study; not established by the supplied figures")
ps[K("g3.7")] = null("a conceptual claim about what a p-value does and does not show")
ps[K("g4.2")] = null("an evaluative conclusion about the strength of the evidence")
ps[K("g8.1")] = null("it restates the supplied fact that one psychologist grouped the comments, with no separate inferential link")
ps[K("g6.1")] = chain("ps-g6.1", K("g6.1"), REQ_PS, "doc-calmstep-s2", "who had helped to design the app",
    "designer", "the psychologist helped to design the app",
    "a researcher who helped design the app could shape which comments are noticed and how they are grouped", "probable",
    "reflex_risk", "the psychologist's view could shape which comments were noticed and grouped",
    "Reflexivity: the psychologist's view of the app could shape which comments were noticed and how they were grouped", "probable",
    "The designer role is quoted from Source 2; the reflexivity risk is the specialist's inference.")
ps[K("g7.1")] = chain("ps-g7.1", K("g7.1"), REQ_PS, "doc-calmstep-s2", "took notes during the interviews instead of recording them",
    "notes_not_recorded", "the psychologist took notes rather than recording the interviews",
    "students' words may be paraphrased or selectively noted when notes replace recordings", "possible",
    "paraphrase_risk", "students' words may have been paraphrased or selectively noted",
    "Recording and transcription: students' words may have been paraphrased or selectively noted", "possible",
    "The note-taking method is quoted from Source 2; the paraphrase risk is the specialist's 'possible' inference.")

# ---------------- PH
ph = {}
PHNULL = {
 "s1.1": "a marks label ('calculate, 2 marks'); no claim.",
 "s1.4": "a provisional-credit grading statement; a marking decision, not a checkable relation.",
 "s1.5": "a provisional mark; a grading decision, not a checkable relation.",
 "s2.1": "a marks label; no claim.",
 "s2.3": "the gas-law rearrangement divides by a non-constant temperature (T1); IR 1.0 allows division only by a constant.",
 "s2.4": "a provisional mark range; a grading decision.",
 "s2.5": "a marking judgement about why a mark is lost; not a relation over supplied figures.",
 "s2.6": "a statement about the markscheme, which is not supplied; not checkable.",
 "s2.9": "a size-check judgement ('fails a size check'); its arithmetic is encoded in s2.11 and is not repeated here.",
 "s3.1": "a marks label; no claim.",
 "s3.2": "a statement of what the question asks; no checkable relation.",
 "s3.4": "a judgement about which constant is correct; the claim is conceptual.",
 "s3.5": "a provisional mark; a grading decision.",
 "s3.6": "a definition of R from memory, restated without a relation to check.",
 "s3.9": "an instruction on how to write the answer with a qualitative order-of-magnitude judgement.",
 "s4.1": "a marks label; no claim.",
 "s4.2": "a statement of what the question asks as a three-link chain; the links are encoded in s4.13 and s4.15.",
 "s4.6": "a provisional mark; a grading decision.",
 "s5.2": "a cross-reference to parts 1(b) and 1(d); no relation of its own.",
 "s6.8": "a study-habit instruction; not a claim with a relation to check.",
 "s7.1": "a practice-task statement for the student to attempt; not a claim.",
 "s7.3": "a question to the student (a practice task); not a claim.",
 "s7.4": "a question to the student (a practice task); not a claim.",
}
for k, v in PHNULL.items():
    ph[k] = null(v)

P = "ph-"
ph["s1.3"] = arith("ph-s1.3", "s1.3", REQ_PH,
    [defn("pv_prod","product 3.0e5 x 2.4e-3", MUL(RC(300000),RC("2.4e-3"))),
     defn("rt_prod","product 8.31 x 290", MUL(RC("8.31"),RC(290)))],
    AND(EQ(V("pv_prod"),RC(720)), GE(V("rt_prod"),RC("2409.5")), LT(V("rt_prod"),RC("2410.5"))),
    "3.0 x 10^5 x 2.4 x 10^-3 = 720 and 8.31 x 290 = 2410",
    "The two substitutions only; the relation n = PV/RT is not encoded. 8.31 x 290 = 2409.9, written as 2410 (half-unit rounding).")
ph["s1.7"] = arith("ph-s1.7", "s1.7", REQ_PH,
    [defn("n_q","720/2410", DIV(RC(720),RC(2410)))],
    AND(GE(V("n_q"),RC("2985/10000")), LT(V("n_q"),RC("2995/10000")), GE(V("n_q"),RC("0.295")), LT(V("n_q"),RC("0.305")),
        OR(LT(V("n_q"),RC("0.325")), GT(V("n_q"),RC("0.335")))),
    "720/2410 = 0.299, so the answer is 0.30 mol, not 0.33 mol",
    "720/2410 = 0.29875, stated as 0.299 (3 d.p.) and 0.30 (2 d.p.), and not 0.33.")
ph["s1.8"] = arith("ph-s1.8", "s1.8", REQ_PH,
    [defn("chk_prod","0.30 x 2410", MUL(RC("0.30"),RC(2410)))],
    EQ(V("chk_prod"),RC(723)), "0.30 x 2410 = 723",
    "Multiply-back check. The 'close to 720' judgement is not encoded.")
ph["s1.9"] = arith("ph-s1.9", "s1.9", REQ_PH,
    [defn("kel1","17 + 273", ADD(RC(17),RC(273)))],
    EQ(V("kel1"),RC(290)), "17 + 273 = 290 K", "Kelvin conversion of 17 C. The instruction to state R is not encoded.")
ph["s1.10"] = arith("ph-s1.10", "s1.10", REQ_PH,
    [defn("pv_prod","product 3.0e5 x 2.4e-3", MUL(RC(300000),RC("2.4e-3"))),
     defn("rt_prod","product 8.31 x 290", MUL(RC("8.31"),RC(290))),
     defn("n_q","720/2410", DIV(RC(720),RC(2410)))],
    AND(EQ(V("pv_prod"),RC(720)), GE(V("rt_prod"),RC("2409.5")), LT(V("rt_prod"),RC("2410.5")),
        GE(V("n_q"),RC("0.295")), LT(V("n_q"),RC("0.305"))),
    "n = (3.0e5 x 2.4e-3)/(8.31 x 290) = 720/2410 = 0.30 mol",
    "Model answer for 1(a): the two products and the quotient to 2 d.p.")
ph["s2.2"] = arith("ph-s2.2", "s2.2", REQ_PH,
    [defn("t1k","17 + 273", ADD(RC(17),RC(273))), defn("t2k","35 + 273", ADD(RC(35),RC(273)))],
    AND(EQ(V("t1k"),RC(290)), EQ(V("t2k"),RC(308))), "T1 = 290 K and T2 = 308 K",
    "Kelvin temperatures. The proportionality P proportional to T is not encoded.")
ph["s2.8"] = arith("ph-s2.8", "s2.8", REQ_PH,
    [defn("r_k","308/290", DIV(RC(308),RC(290))), defn("r_c","35/17", DIV(RC(35),RC(17)))],
    NE(V("r_k"), V("r_c")), "The gas-law ratio is 308/290, not 35/17",
    "Checks that the kelvin ratio differs from the Celsius ratio. The value 308/290 itself is not separately asserted.")
ph["s2.10"] = arith("ph-s2.10", "s2.10", REQ_PH,
    [defn("t1k","17 + 273", ADD(RC(17),RC(273))), defn("t2k","35 + 273", ADD(RC(35),RC(273)))],
    AND(EQ(V("t1k"),RC(290)), EQ(V("t2k"),RC(308))), "T1 = 17 + 273 = 290 K and T2 = 35 + 273 = 308 K",
    "Kelvin conversions. The 'check the size' instruction is not encoded.")
ph["s2.11"] = arith("ph-s2.11", "s2.11", REQ_PH,
    [defn("t1k","17 + 273", ADD(RC(17),RC(273))), defn("t2k","35 + 273", ADD(RC(35),RC(273))),
     defn("p2k","3.0e5 x 308/290", DIV(MUL(RC(300000),V("t2k")),RC(290)))],
    AND(EQ(V("t1k"),RC(290)), EQ(V("t2k"),RC(308)), GE(V("p2k"),RC(315000)), LT(V("p2k"),RC(325000))),
    "T1 = 290 K; T2 = 308 K; P2 = 3.0e5 x 308/290 = 3.2e5 Pa",
    "P2 = 318 621 Pa, stated as 3.2e5 Pa (2 s.f., half-unit rounding).")
ph["s3.7"] = arith("ph-s3.7", "s3.7", REQ_PH,
    [defn("kb","8.31 / 6.02e23", DIV(RC("8.31"),RC(602000000000000000000000)))],
    AND(GE(V("kb"),RC("1.375e-23")), LT(V("kb"),RC("1.385e-23"))),
    "k_B = R/N_A = 1.38 x 10^-23 J K^-1",
    "N_A = 6.02e23 mol^-1 is taken as a general-knowledge constant; k_B to 3 s.f.")
ph["s3.8"] = arith("ph-s3.8", "s3.8", REQ_PH,
    [defn("e1k","1.5 x 1.38e-23 x 308", MUL(RC("1.5"),RC("1.38e-23"),RC(308)))],
    AND(LE(MUL(RC("5.5e23"),V("e1k")),RC(3840)), GE(MUL(RC("6.5e23"),V("e1k")),RC(3840))),
    "3840 J is about 6 x 10^23 times the energy of one molecule",
    "Ratio 3840 / E_k(one molecule) lies in [5.5e23, 6.5e23), i.e. about 6e23 to 1 s.f. Encoded as multiplication by constants because division by a non-constant is not allowed.")
ph["s3.10"] = arith("ph-s3.10", "s3.10", REQ_PH,
    [defn("e1k","1.5 x 1.38e-23 x 308", MUL(RC("1.5"),RC("1.38e-23"),RC(308)))],
    AND(GE(V("e1k"),RC("6.35e-21")), LT(V("e1k"),RC("6.45e-21"))),
    "E_k = (3/2) k_B T = 1.5 x 1.38 x 10^-23 x 308 = 6.4 x 10^-21 J",
    "E_k = 6.3756e-21 J, stated as 6.4e-21 J (2 s.f.).")

def ph_chain(pid, claim, excerpt, qsym, qmean, link_label, csym, cmean, clabel, lcert, reading):
    return chain(pid, claim, REQ_PH, "doc-tyre-student", excerpt, qsym, qmean, link_label, lcert, csym, cmean, clabel, lcert, reading)
ph["s2.7"] = ph_chain("ph-s2.7", "s2.7", "P2 = P1 × T2/T1 = 3.0 × 10^5 × 35/17", "e_ratio",
    "the student's working uses 35/17 for the temperature ratio",
    "a gas-law ratio built from 17 and 35 treats them as Celsius values",
    "celsius_used", "17 and 35 were used as Celsius values", "17 and 35 were used as Celsius values", "probable",
    "Quotation of the student's ratio; the Celsius reading is the specialist's inference.")
ph["s6.2"] = ph_chain("ph-s6.2", "s6.2", "3.0 × 10^5 × 35/17", "e_ratio",
    "the student's working uses 35/17 for the temperature ratio",
    "a gas-law ratio built from 17 and 35 treats them as Celsius values",
    "celsius_used", "temperatures in Celsius are used inside the gas laws", "Temperatures in degrees Celsius are used inside gas laws", "probable",
    "Same quotation as 2(b); the Celsius use inside gas laws is the specialist's inference.")
ph["s6.4"] = ph_chain("ph-s6.4", "s6.4", "Ek = 3/2 RT = 1.5 × 8.31 × 308", "e_rmol",
    "the student writes Ek = 3/2 RT with the gas constant",
    "the form 3/2 RT uses the per-mole gas constant for one molecule",
    "r_for_molecule", "the gas constant R is used where a single molecule needs k_B",
    "The gas constant R, which is per mole, is used where k_B is needed for one molecule", "probable",
    "Quotation of the student's Ek = (3/2)RT; the per-molecule misuse is the specialist's inference.")
ph["s6.6"] = ph_chain("ph-s6.6", "s6.6", "hit each other more often and harder", "e_coll",
    "the student says molecules hit each other more often and harder",
    "a statement about molecule-molecule collisions is placed where wall collisions belong",
    "collisions_placed", "collisions are placed between molecules instead of with the container walls",
    "Collisions are placed between molecules instead of with the container walls", "probable",
    "Quotation of the student's collision sentence; the placement is the specialist's reading.")
ph["s4.13"] = boolchain("ph-s4.13", "s4.13", REQ_PH,
    [SYM("hot","Bool","the temperature rises",G("task_setting","established")),
     SYM("faster","Bool","the molecules move faster",G("general_knowledge","established")),
     SYM("ke_up","Bool","the mean kinetic energy rises",G("general_knowledge","established"))],
    [PREM("p_hot", V("hot"), "the temperature rises", G("task_setting","established")),
     PREM("l1", IMP(V("hot"),V("faster")), "a higher temperature gives faster molecules", G("general_knowledge","established")),
     PREM("l2", IMP(V("faster"),V("ke_up")), "faster molecules have a higher mean kinetic energy", G("general_knowledge","established"))],
    "c", V("ke_up"), "A higher temperature means faster molecules, so their mean kinetic energy rises", G("general_knowledge","established"),
    "Chain of two general-knowledge steps from the temperature rise.")
ph["s4.15"] = boolchain("ph-s4.15", "s4.15", REQ_PH,
    [SYM("momentum_up","Bool","larger momentum changes at the wall",G("specialist_inference","probable")),
     SYM("force_up","Bool","the force on the wall rises",G("general_knowledge","established")),
     SYM("area_fixed","Bool","the area (volume) is fixed",G("task_setting","established")),
     SYM("pressure_up","Bool","the pressure rises",G("general_knowledge","established"))],
    [PREM("p_mom", V("momentum_up"), "larger momentum changes at the wall", G("specialist_inference","probable")),
     PREM("l_force", IMP(V("momentum_up"),V("force_up")), "force is the rate of change of momentum", G("general_knowledge","established")),
     PREM("p_area", V("area_fixed"), "the volume is fixed", G("task_setting","established")),
     PREM("l_press", IMP(AND(V("force_up"),V("area_fixed")),V("pressure_up")), "with area fixed, a larger force per unit area is a higher pressure", G("general_knowledge","established"))],
    "c", V("pressure_up"), "The force on the wall is the rate of change of momentum, so with the area fixed, pressure rises", G("general_knowledge","established"),
    "Chain from momentum changes to force and, with area fixed, to pressure.")

# ---------------- MAA
maa = {}
MNULL = {
 "m2.3": "a polynomial identity in the variable x (f(x) = (x+3)(x^2+bx+c)); products of non-constant terms are outside IR 1.0.",
 "m2.4": "a polynomial identity in x (expansion); products of non-constant terms are outside IR 1.0.",
 "m2.7": "a polynomial identity in x; not encodable without products of non-constant terms or quantification over x.",
 "m2.8": "a polynomial identity in x; not encodable (non-constant products).",
 "m3.1": "a derivative identity in x (f'(x) = 3(x-3)(x+1)); not encodable (non-constant products).",
 "m3.2": "a solution set (f'(x) = 0 exactly at x = 3 and x = -1) needs the statement that no other value satisfies it, which is quantification over x.",
 "m3.6": "a label for the sign analysis; no claim.",
 "m3.7": "a sign claim for all x < -1; universal quantification over x, not in IR 1.0.",
 "m3.8": "a sign claim for all -1 < x < 3; universal quantification over x.",
 "m3.9": "a sign claim for all x > 3; universal quantification over x.",
 "m3.10": "the classification of the stationary points depends on the sign analysis (quantification over x).",
 "m4.1": "the x-intercept set needs the statement that no other x is an intercept, which is quantification over x.",
 "m4.2": "crossing versus touching depends on the sign change near each root (quantification over x).",
 "m5.1": "a claim for all x in [-3, 3]; universal quantification over x.",
 "m5.2": "a region argument over all x (sign of f below -3); quantification over x.",
 "m5.3": "a definite integral; IR 1.0 has no integrals.",
 "m5.8": "restates the area from m5.6; no separate relation.",
 "m6.5": "the point-slope equation of the normal restates the slope and point; with no premise beyond the claim itself there is no relation to check.",
 "m6.9": "reads off the coefficients of the previous line; no separate relation.",
 "m6.10": "a general statement about all integer multiples of the equation (quantification over multiples).",
}
for k, v in MNULL.items():
    maa[k] = null(v)

maa["m2.1"] = arith("maa-m2.1", "m2.1", REQ_MAA,
    [defn("fm3","f(-3) from the cubic", ADD(RC(-27),RC(-27),RC(27),RC(27)))],
    EQ(V("fm3"),RC(0)), "f(-3) = 0", "Direct evaluation of the given cubic at x = -3.")
maa["m2.2"] = TR(PROBLEM("maa-m2.2", "m2.2", REQ_MAA,
    [SYM("factor_x3","Bool","(x + 3) is a factor of f(x)",G("general_knowledge","established"))],
    [PREM("ev_f", EQ(ADD(RC(-27),RC(-27),RC(27),RC(27)),RC(0)), "f(-3) = 0", G("arithmetic_fact","established")),
     PREM("l_factor", IMP(EQ(ADD(RC(-27),RC(-27),RC(27),RC(27)),RC(0)), V("factor_x3")), "by the factor theorem, f(-3) = 0 makes (x + 3) a factor", G("general_knowledge","established"))],
    CONCL("c", V("factor_x3"), "(x + 3) is a factor of f(x)", G("general_knowledge","established"))),
    "Factor theorem step: f(-3) = 0 (arithmetic) and the theorem's implication give (x + 3) as a factor.")
maa["m2.5"] = TR(PROBLEM("maa-m2.5", "m2.5", REQ_MAA,
    [SYM("b","Int","coefficient b of the quadratic factor",G("specialist_inference","established")),
     SYM("c","Int","constant c of the quadratic factor",G("specialist_inference","established"))],
    [PREM("p_b", EQ(ADD(V("b"),I(3)),I(-3)), "b + 3 = -3 (coefficient of x^2)", G("specialist_inference","established")),
     PREM("p_c", EQ(MUL(I(3),V("c")),I(27)), "3c = 27 (constant term)", G("specialist_inference","established"))],
    CONCL("c", AND(EQ(V("b"),I(-6)),EQ(V("c"),I(9))), "b = -6 and c = 9", G("arithmetic_fact","established"))),
    "Coefficient matching: b + 3 = -3 and 3c = 27.")
maa["m2.6"] = TR(PROBLEM("maa-m2.6", "m2.6", REQ_MAA,
    [SYM("b","Int","coefficient b of the quadratic factor",G("specialist_inference","established")),
     SYM("c","Int","constant c of the quadratic factor",G("specialist_inference","established"))],
    [PREM("p_b", EQ(V("b"),I(-6)), "b = -6", G("specialist_inference","established")),
     PREM("p_c", EQ(V("c"),I(9)), "c = 9", G("specialist_inference","established"))],
    CONCL("c", EQ(ADD(V("c"),MUL(I(3),V("b"))),I(-9)), "c + 3b = 9 - 18 = -9", G("arithmetic_fact","established"))),
    "Check of the x coefficient: c + 3b with b = -6 and c = 9 gives -9.")
maa["m3.3"] = arith("maa-m3.3", "m3.3", REQ_MAA,
    [defn("fm1","f(-1) from the cubic", ADD(RC(-1),RC(-3),RC(9),RC(27)))],
    EQ(V("fm1"),RC(32)), "f(-1) = 32", "Direct evaluation at x = -1.")
maa["m3.4"] = arith("maa-m3.4", "m3.4", REQ_MAA,
    [defn("f3","f(3) from the cubic", ADD(RC(27),RC(-27),RC(-27),RC(27)))],
    EQ(V("f3"),RC(0)), "f(3) = 0", "Direct evaluation at x = 3.")
maa["m3.5"] = arith("maa-m3.5", "m3.5", REQ_MAA,
    [defn("fm1","f(-1)", ADD(RC(-1),RC(-3),RC(9),RC(27))),
     defn("f3","f(3)", ADD(RC(27),RC(-27),RC(-27),RC(27))),
     defn("d1","f'(-1) = 3 + 6 - 9", ADD(RC(3),RC(6),RC(-9))),
     defn("d3","f'(3) = 27 - 18 - 9", ADD(RC(27),RC(-18),RC(-9)))],
    AND(EQ(V("fm1"),RC(32)), EQ(V("f3"),RC(0)), EQ(V("d1"),RC(0)), EQ(V("d3"),RC(0))),
    "Stationary points (-1, 32) and (3, 0)",
    "f' vanishes and the values are as stated at x = -1 and x = 3. The claim that these are the only stationary points is not encoded (quantification).")
maa["m3.11"] = arith("maa-m3.11", "m3.11", REQ_MAA,
    [defn("s_m1","f''(-1) = 6(-1) - 6", ADD(MUL(RC(6),RC(-1)),RC(-6))),
     defn("s_3","f''(3) = 6(3) - 6", ADD(MUL(RC(6),RC(3)),RC(-6)))],
    AND(EQ(V("s_m1"),RC(-12)), EQ(V("s_3"),RC(12)), LT(V("s_m1"),RC(0)), GT(V("s_3"),RC(0))),
    "f''(-1) = -12 < 0 and f''(3) = 12 > 0", "Second derivative 6x - 6 at the two points.")
maa["m5.4"] = arith("maa-m5.4", "m5.4", REQ_MAA,
    [defn("f3","F(3) for F(x) = x^4/4 - x^3 - (9/2)x^2 + 27x", ADD(RC("81/4"),RC(-27),RC("-81/2"),RC(81)))],
    EQ(V("f3"),RC("135/4")), "F(3) = 81/4 - 27 - 81/2 + 81 = 135/4", "Antiderivative evaluated at 3.")
maa["m5.5"] = arith("maa-m5.5", "m5.5", REQ_MAA,
    [defn("fm3","F(-3)", ADD(RC("81/4"),RC(27),RC("-81/2"),RC(-81)))],
    EQ(V("fm3"),RC("-297/4")), "F(-3) = 81/4 + 27 - 81/2 - 81 = -297/4", "Antiderivative evaluated at -3.")
maa["m5.6"] = arith("maa-m5.6", "m5.6", REQ_MAA,
    [defn("f3b","F(3) = 135/4", RC("135/4")), defn("fm3b","F(-3) = -297/4", RC("-297/4"))],
    EQ(SUB(V("f3b"),V("fm3b")),RC(108)), "Area = 135/4 - (-297/4) = 108",
    "Constant arithmetic of F(3) - F(-3) = 108. The integral identity and the sign argument that makes this the enclosed area are not encoded.")
maa["m5.7"] = arith("maa-m5.7", "m5.7", REQ_MAA,
    [defn("q1","6^4/4", DIV(RC(1296),RC(4))), defn("u6","324 - 864 + 648", ADD(RC(324),RC(-864),RC(648)))],
    AND(EQ(V("q1"),RC(324)), EQ(V("u6"),RC(108))),
    "[u^4/4 - 4u^3 + 18u^2] from 0 to 6 = 324 - 864 + 648 = 108",
    "Substitution check at u = 6.")
maa["m6.1"] = arith("maa-m6.1", "m6.1", REQ_MAA,
    [defn("f1","(1+3)(1-3)^2", MUL(RC(4),RC(-2),RC(-2)))],
    EQ(V("f1"),RC(16)), "f(1) = 16, so the point is (1, 16)", "Evaluation at x = 1 in factored form.")
maa["m6.2"] = arith("maa-m6.2", "m6.2", REQ_MAA,
    [defn("g1","1 - 3 - 9 + 27", ADD(RC(1),RC(-3),RC(-9),RC(27)))],
    EQ(V("g1"),RC(16)), "1 - 3 - 9 + 27 = 16", "Evaluation at x = 1 in expanded form.")
maa["m6.3"] = arith("maa-m6.3", "m6.3", REQ_MAA,
    [defn("d1","3 - 6 - 9", ADD(RC(3),RC(-6),RC(-9)))],
    EQ(V("d1"),RC(-12)), "f'(1) = -12", "Derivative at x = 1.")
maa["m6.4"] = arith("maa-m6.4", "m6.4", REQ_MAA,
    [defn("gn","-1 / (-12)", DIV(RC(-1),RC(-12)))],
    EQ(V("gn"),RC("1/12")), "gradient of the normal = -1/f'(1) = 1/12", "Negative reciprocal of f'(1) = -12.")
maa["m6.6"] = TR(PROBLEM("maa-m6.6", "m6.6", REQ_MAA,
    [SYM("x","Real","x-coordinate of a point on the normal",G("specialist_inference","established")),
     SYM("y","Real","y-coordinate of a point on the normal",G("specialist_inference","established"))],
    [PREM("p_line", EQ(SUB(V("y"),RC(16)), MUL(RC("1/12"),SUB(V("x"),RC(1)))), "y - 16 = (1/12)(x - 1)", G("specialist_inference","established"))],
    CONCL("c", EQ(SUB(MUL(RC(12),V("y")),RC(192)), SUB(V("x"),RC(1))), "12y - 192 = x - 1", G("arithmetic_fact","established"))),
    "Clearing fractions from the normal line y - 16 = (1/12)(x - 1).")
maa["m6.7"] = TR(PROBLEM("maa-m6.7", "m6.7", REQ_MAA,
    [SYM("x","Real","x-coordinate of a point on the normal",G("specialist_inference","established")),
     SYM("y","Real","y-coordinate of a point on the normal",G("specialist_inference","established"))],
    [PREM("p_line2", EQ(SUB(MUL(RC(12),V("y")),RC(192)), SUB(V("x"),RC(1))), "12y - 192 = x - 1", G("specialist_inference","established"))],
    CONCL("c", EQ(ADD(V("x"),MUL(RC(-12),V("y")),RC(191)),RC(0)), "x - 12y + 191 = 0", G("arithmetic_fact","established"))),
    "Rearranged to ax + by + d = 0 with a = 1, b = -12, d = 191.")
maa["m6.8"] = arith("maa-m6.8", "m6.8", REQ_MAA,
    [defn("v18","1 + (-12)(16) + 191", ADD(RC(1),MUL(RC(-12),RC(16)),RC(191)))],
    EQ(V("v18"),RC(0)), "1 - 12(16) + 191 = 0, so (1, 16) lies on the line", "Substitution of (1, 16).")

res = {"ll-t16": ("rep-ll-t16-0", out["ll-t16"]),
       "ps-t16": ("rep-ps-t16-0", ps), "ph-t16": ("rep-ph-t16-0", ph), "maa-t16": ("rep-maa-t16-0", maa)}
expected = {}
for t in res:
    expected[t] = json.load(open(f"{BASE}/listings/{t}.json"))
for t, (rid, cl) in res.items():
    ids = [c["claim_id"] for c in expected[t]["claims"] if c.get("eligible")]
    assert set(ids) == set(cl), (t, set(ids) ^ set(cl))
    with open(f"{BASE}/translations/{t}.json", "w", encoding="utf-8") as f:
        json.dump({"report_id": rid, "claims": cl}, f, ensure_ascii=False, indent=2); f.write("\n")
print("written", {t: len(v[1]) for t, v in res.items()})
