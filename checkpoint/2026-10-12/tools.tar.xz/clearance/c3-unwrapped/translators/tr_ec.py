import sys; sys.path.insert(0, "."); from tlib import *
BASE = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c3/translations/"
REQ = "req-ec-t16"; RID = "rep-ec-t16-0"; D = "doc-pelland"
AF = lambda refs=None: G("arithmetic_fact", "established", refs or [])
SI = lambda c="established": G("specialist_inference", c)
GK = lambda c="established": G("general_knowledge", c)
SUP = lambda ex, c="established": G("supplied_text", c, [REF(D, ex)] if ex else [])
ROW19 = "2019 | 48.0 | 2,150 | 412 | 96"; ROW25 = "2025 | 36.0 | 2,880 | 236 | 131"
claims = {}
def L(cid): return cid if "@" in cid else cid + "@economics-specialist"
def tr(key, pid, syms, prem, concl, reading, flags=None, amb=False):
    cid = L(key)
    claims[cid] = TR(PROBLEM(pid, cid, REQ, syms, prem, concl), reading, flags or [], ambiguous=amb)
def nl(key, reading, reason):
    claims[L(key)] = NULLTR(reading, reason)

# g1.2
syms = [SYM("marks_off","Bool","the printed marks (2, 3, 4, 15) do not follow the full Paper 2 pattern", SI()),
        SYM("treat_extended","Bool","the 15-mark part (d) is treated as the extended part", SI()),
        SYM("plan_only","Bool","only a plan for part (d) is given, for approval", SI())]
prem = [PREM("marks", V("marks_off"), "the marks do not follow the full Paper 2 pattern", SI()),
        PREM("link1", IMP(V("marks_off"), V("treat_extended")), "so the 15-mark part (d) is treated as the extended part", SI()),
        PREM("link2", IMP(V("treat_extended"), V("plan_only")), "so only a plan is given, for the student to approve", SI())]
concl = CONCL("plan", AND(V("treat_extended"), V("plan_only")), "I have treated the 15-mark part (d) as the extended part and give its plan only, for you to approve", SI())
tr("g1.2", "ec-t16-g1-2", syms, prem, concl, "The specialist's own decision about the paper's structure. The full Paper 2 pattern is not in the supplied text, so the mark pattern is the specialist's assertion and is encoded as such.",
   [FLAG("pattern-unsupplied", "the 'full Paper 2 pattern' that the marks are said not to follow is not in the supplied text", ["the marks are off a published pattern", "the specialist's own reading of the marks"])], amb=True)

nl("g2.1", "The claim 'Definition' is a heading of the answer.", "a heading: it states no proposition to check")
nl("g2.2", "A definition of common pool resource from subject knowledge (rivalrous and non-excludable). It is stated from memory and its only encoding would restate the definition.", "a definition stated from memory whose only possible encoding restates it; no relation to check")

# g2.3
syms = [SYM("rivalrous","Bool","a common pool resource is rivalrous and non-excludable, so one user's unit cannot be another's", GK()),
        SYM("reduces","Bool","each user's catch reduces what is left for everyone else", SI())]
prem = [PREM("gk_rival", V("rivalrous"), "a common pool resource is rivalrous, so one unit taken cannot be taken by another", GK()),
        PREM("link", IMP(V("rivalrous"), V("reduces")), "therefore each user's catch reduces what is left for others", SI())]
concl = CONCL("reduces", V("reduces"), "each user's catch therefore reduces what is left for everyone else", SI())
tr("g2.3", "ec-t16-g2-3", syms, prem, concl, "The rivalry of the resource (general knowledge) and the specialist's step to the reduction for others.")

# g4.2
syms = [SYM("catch19","Real","2019 catch in thousand tonnes (Table 1)", AF([REF(D, ROW19)]))]
prem = [PREM("fact_catch19", EQ(V("catch19"), R("48.0")), "Table 1 gives the 2019 catch as 48.0 thousand tonnes", AF([REF(D, ROW19)]), "supporting")]
concl = CONCL("tonnes", EQ(MUL(R(1000), V("catch19")), R(48000)), "catch = 48.0 thousand tonnes = 48,000 tonnes", SI())
tr("g4.2", "ec-t16-g4-2", syms, prem, concl, "Unit conversion of the 2019 catch from the table: 48.0 thousand tonnes is 48,000 tonnes.")

# g4.3
syms = [SYM("price19","Real","2019 average price in P$ per tonne (Table 1)", AF([REF(D, ROW19)]))]
prem = [PREM("fact_price19", EQ(V("price19"), R(2150)), "Table 1 gives the 2019 average price as P$2,150 per tonne", AF([REF(D, ROW19)]), "supporting")]
concl = CONCL("value", AND(EQ(MUL(R(48000), V("price19")), R(103200000)), EQ(DIV(MUL(R(48000), V("price19")), R(1000000)), R("103.2"))), "value = 48,000 × P$2,150 = P$103,200,000 (P$103.20 million)", SI())
tr("g4.3", "ec-t16-g4-3", syms, prem, concl, "Value of the 2019 catch as tonnes times price. Tonnes are written as the constant 48,000 because the product of two variables is outside the IR; the price is the table figure.")

# g5.2
syms = [SYM("catch25","Real","2025 catch in thousand tonnes (Table 1)", AF([REF(D, ROW25)]))]
prem = [PREM("fact_catch25", EQ(V("catch25"), R("36.0")), "Table 1 gives the 2025 catch as 36.0 thousand tonnes", AF([REF(D, ROW25)]), "supporting")]
concl = CONCL("tonnes", EQ(MUL(R(1000), V("catch25")), R(36000)), "catch = 36.0 thousand tonnes = 36,000 tonnes", SI())
tr("g5.2", "ec-t16-g5-2", syms, prem, concl, "Unit conversion of the 2025 catch from the table.")

# g5.3
syms = [SYM("price25","Real","2025 average price in P$ per tonne (Table 1)", AF([REF(D, ROW25)]))]
prem = [PREM("fact_price25", EQ(V("price25"), R(2880)), "Table 1 gives the 2025 average price as P$2,880 per tonne", AF([REF(D, ROW25)]), "supporting")]
concl = CONCL("value", AND(EQ(MUL(R(36000), V("price25")), R(103680000)), EQ(DIV(MUL(R(36000), V("price25")), R(1000000)), R("103.68"))), "value = 36,000 × P$2,880 = P$103,680,000 (P$103.68 million)", SI())
tr("g5.3", "ec-t16-g5-3", syms, prem, concl, "Value of the 2025 catch as tonnes times price. Tonnes are written as the constant 36,000 for the same reason as in the 2019 value.")

# g6.1
syms = [SYM("v19","Real","value of the 2019 catch in P$ million", SI()),
        SYM("v25","Real","value of the 2025 catch in P$ million", SI()),
        SYM("pct","Real","percentage change in value from 2019 to 2025", GK())]
prem = [PREM("v19", EQ(V("v19"), R("103.20")), "value of the 2019 catch is P$103.20 million (48,000 × P$2,150)", AF([REF(D, ROW19)]), "supporting"),
        PREM("v25", EQ(V("v25"), R("103.68")), "value of the 2025 catch is P$103.68 million (36,000 × P$2,880)", AF([REF(D, ROW25)]), "supporting"),
        PREM("def", EQ(V("pct"), DIV(MUL(R(100), SUB(V("v25"), V("v19"))), R("103.20"))), "percentage change = (new value − original value) ÷ original value × 100", GK())]
concl = CONCL("pct", AND(EQ(SUB(V("v25"), V("v19")), R("0.48")), GE(V("pct"), R("0.465")), LT(V("pct"), R("0.475"))), "percentage change in value = 0.48 ÷ 103.20 × 100 = 0.47%", SI())
tr("g6.1", "ec-t16-g6-1", syms, prem, concl, "Percentage change in value from the two table-derived values. The exact change is 0.4651%, which to two decimal places is 0.47%; the claim is encoded at that precision (0.465 to 0.475). The divisor is the constant 103.20 for the same reason as above.")

# g7.1
syms = [SYM("v19","Real","value of the 2019 catch in P$ million", SI()),
        SYM("v25","Real","value of the 2025 catch in P$ million", SI()),
        SYM("pct","Real","percentage change in value from 2019 to 2025", GK())]
prem = [PREM("v19", EQ(V("v19"), R("103.20")), "value of the 2019 catch is P$103.20 million", AF([REF(D, ROW19)]), "supporting"),
        PREM("v25", EQ(V("v25"), R("103.68")), "value of the 2025 catch is P$103.68 million", AF([REF(D, ROW25)]), "supporting"),
        PREM("def", EQ(V("pct"), DIV(MUL(R(100), SUB(V("v25"), V("v19"))), R("103.20"))), "percentage change = (new − original) ÷ original × 100", GK())]
concl = CONCL("rose", AND(GT(V("pct"), R(0)), GE(V("pct"), R("0.465")), LT(V("pct"), R("0.475"))), "the value of the catch rose by 0.47% between 2019 and 2025", SI())
tr("g7.1", "ec-t16-g7-1", syms, prem, concl, "A rise of 0.47% to two decimal places, from the two values in the table. Nominal values are not adjusted (see g7.2).")

# g7.2
syms = [SYM("nominal","Bool","the values in the table are nominal", SI()),
        SYM("catch19","Real","2019 catch in thousand tonnes", AF([REF(D, ROW19)])),
        SYM("catch25","Real","2025 catch in thousand tonnes", AF([REF(D, ROW25)]))]
prem = [PREM("nominal", V("nominal"), "these are nominal values (the specialist's statement; the supplied text does not say it)", SI()),
        PREM("fact19", EQ(V("catch19"), R("48.0")), "Table 1: 2019 catch 48.0 thousand tonnes", AF([REF(D, ROW19)]), "supporting"),
        PREM("fact25", EQ(V("catch25"), R("36.0")), "Table 1: 2025 catch 36.0 thousand tonnes", AF([REF(D, ROW25)]), "supporting")]
concl = CONCL("fell", AND(V("nominal"), EQ(DIV(MUL(R(100), SUB(V("catch25"), V("catch19"))), R("48.0")), R(-25))), "these are nominal values, and the quantity caught fell by 25%", SI())
tr("g7.2", "ec-t16-g7-2", syms, prem, concl, "The fall in catch is 12 of 48.0 thousand tonnes, exactly 25%. The nominal character of the values is the specialist's statement; the supplied text does not give it, so it is encoded as a specialist premise and flagged.",
   [FLAG("nominal-unsupported", "the supplied text does not say the values are nominal", ["the values are nominal as the specialist says", "the values are real and the specialist is wrong"])])

nl("g8.1", "The claim 'Diagram and explanation' is a heading of the answer.", "a heading: it states no proposition to check")

# g9.1
nl("g9.1", "The claim restates paragraph [1] of the supplied text: that any licensed boat may fish and that a tonne caught by one boat is a tonne no other boat can catch. Its only encoding would restate the quoted text, which the quotation grounding checks, so it has no relation to check here.", "a report of the supplied text whose only encoding restates the text")

# g9.2
syms = [SYM("price_above_mpc","Bool","the price of a tonne exceeds a boat's marginal private cost up to Qm", SI()),
        SYM("keeps_fishing","Bool","each boat keeps fishing while the price exceeds its own marginal private cost", GK()),
        SYM("fleet_qm","Bool","the fleet catches Qm", SI())]
prem = [PREM("price", V("price_above_mpc"), "the price of a tonne exceeds each boat's private marginal cost up to the unregulated level", SI()),
        PREM("rule", IMP(V("price_above_mpc"), V("keeps_fishing")), "each boat keeps fishing while price exceeds its marginal private cost", GK()),
        PREM("link", IMP(V("keeps_fishing"), V("fleet_qm")), "so the fleet catches Qm", SI())]
concl = CONCL("fleet", V("fleet_qm"), "each boat keeps fishing while the price of a tonne exceeds its own marginal private cost, so the fleet catches Qm", SI())
tr("g9.2", "ec-t16-g9-2", syms, prem, concl, "The unregulated fishing rule: each boat fishes while price exceeds its private marginal cost, so the fleet reaches Qm. The rule is general knowledge; the specialist's price condition and the step to Qm are its own.")

# g9.3
syms = [SYM("decides_private","Bool","each boat decides on its own private marginal cost", SI()),
        SYM("ignores_ext","Bool","the boat's decision ignores the external cost of its catch", SI()),
        SYM("catch19","Real","2019 catch in thousand tonnes", AF([REF(D, ROW19)])),
        SYM("stock19","Real","2019 breeding stock in thousand tonnes", AF([REF(D, ROW19)]))]
prem = [PREM("decides", V("decides_private"), "each boat decides on its private marginal cost", SI()),
        PREM("link", IMP(V("decides_private"), V("ignores_ext")), "it ignores the external cost, the smaller breeding stock left for others", SI()),
        PREM("fact_catch", EQ(V("catch19"), R("48.0")), "Table 1: 2019 catch 48.0 thousand tonnes", AF([REF(D, ROW19)]), "supporting"),
        PREM("fact_stock", EQ(V("stock19"), R(96)), "Table 1: 2019 breeding stock 96 thousand tonnes", AF([REF(D, ROW19)]), "supporting")]
concl = CONCL("ext", AND(V("ignores_ext"), EQ(MUL(R(2), V("catch19")), V("stock19"))), "it ignores the external cost of its catch, and in 2019 the catch of 48.0 thousand tonnes was half the breeding stock of 96 thousand tonnes", SI())
tr("g9.3", "ec-t16-g9-3", syms, prem, concl, "The 2019 catch is exactly half the 2019 breeding stock (48.0 × 2 = 96), from Table 1. The claim that the boat ignores external cost is the specialist's inference from its private-cost decision.")

# g9.4
syms = [SYM("ext_cost_pos","Bool","the external cost of each extra tonne is positive, so MSC lies above MPC", SI()),
        SYM("msc_above_qm","Bool","at Qm the cost to society of the last tonne is above its price", SI()),
        SYM("exceeds_qstar","Bool","the catch exceeds Q*, the level of overfishing", SI())]
prem = [PREM("ext", V("ext_cost_pos"), "the external cost of each extra tonne is positive (Diagram 1 as the specialist draws it)", SI()),
        PREM("link1", IMP(V("ext_cost_pos"), V("msc_above_qm")), "at Qm the MSC is above the price", SI()),
        PREM("link2", IMP(V("msc_above_qm"), V("exceeds_qstar")), "so the catch exceeds Q*", SI())]
concl = CONCL("overfish", AND(V("msc_above_qm"), V("exceeds_qstar")), "as Diagram 1 shows, at Qm the cost to society of the last tonne is above its price, so the catch exceeds Q*, the level of overfishing", SI())
tr("g9.4", "ec-t16-g9-4", syms, prem, concl, "Diagram 1 is the specialist's own drawing and is not in the supplied text, so its curves are encoded as the specialist's premise.",
   [FLAG("diagram-unsupplied", "Diagram 1 is not in the supplied text", ["the diagram matches the specialist's description", "the diagram is an illustration only"])])

nl("g10.1", "The claim 'Plan for an extended answer' is a heading of the answer.", "a heading: it states no proposition to check")

# g11.3
syms = [SYM("caps_below","Bool","the total allowable catch caps the catch below the unregulated level Qm", SI()),
        SYM("moves","Bool","the market moves from Qm towards Q* in Diagram 1", SI())]
prem = [PREM("caps", V("caps_below"), "the total allowable catch caps the catch below Qm", SI()),
        PREM("link", IMP(V("caps_below"), V("moves")), "so the market moves from Qm towards Q*", SI())]
concl = CONCL("moves", V("moves"), "Unit 1, stock recovery: the total allowable catch caps the catch below the unregulated level Qm, so the market moves from Qm towards Q* in Diagram 1", SI())
tr("g11.3", "ec-t16-g11-3", syms, prem, concl, "The cap as the specialist's reading of how a total allowable catch works, and the step to movement towards Q*. The text sets a total allowable catch but does not state the cap relative to Qm.")

# g11.4
syms = [SYM("stock19","Real","2019 breeding stock in thousand tonnes", AF([REF(D, ROW19)])),
        SYM("stock25","Real","2025 breeding stock in thousand tonnes", AF([REF(D, ROW25)]))]
prem = [PREM("fact19", EQ(V("stock19"), R(96)), "Table 1: 2019 breeding stock 96 thousand tonnes", AF([REF(D, ROW19)]), "supporting"),
        PREM("fact25", EQ(V("stock25"), R(131)), "Table 1: 2025 breeding stock 131 thousand tonnes", AF([REF(D, ROW25)]), "supporting")]
pctexpr = DIV(MUL(R(100), SUB(V("stock25"), V("stock19"))), R("96"))
concl = CONCL("stock", AND(GT(V("stock25"), V("stock19")), GE(pctexpr, R("36.455")), LT(pctexpr, R("36.465"))), "Table 1 shows the breeding stock rising from 96 to 131 thousand tonnes between 2019 and 2025, a rise of 36.46%", SI())
tr("g11.4", "ec-t16-g11-4", syms, prem, concl, "Rise of 35 on 96 is 36.4583%, which to two decimal places is 36.46%; encoded at that precision (36.455 to 36.465).")

# g11.5
syms = [SYM("few_points","Bool","the table holds only three data points", G("supplied_text", "established", [REF(D, "Year | Catch (thousand tonnes)")])),
        SYM("pre_quota","Bool","one of the data points (2019) is before the quotas", G("supplied_text", "established", [REF(D, "In 2021 the government set a total allowable catch for each year")])),
        SYM("cannot_exclude","Bool","natural variation cannot be excluded as the cause of the change", SI())]
prem = [PREM("few", V("few_points"), "there are only three data points", G("supplied_text", "established", [REF(D, "Year | Catch (thousand tonnes)")])),
        PREM("pre", V("pre_quota"), "one data point is before the 2021 quotas", G("supplied_text", "established", [REF(D, "In 2021 the government set a total allowable catch for each year")])),
        PREM("link", IMP(AND(V("few_points"), V("pre_quota")), V("cannot_exclude")), "so natural variation cannot be excluded", SI())]
concl = CONCL("excl", V("cannot_exclude"), "there are only three data points, one of them before the quotas, so natural variation cannot be excluded", SI())
tr("g11.5", "ec-t16-g11-5", syms, prem, concl, "Table 1 has three years, and 2019 precedes the 2021 quotas. The inference that natural variation cannot be excluded is the specialist's.")

# g11.7
syms = [SYM("catch19","Real","2019 catch in thousand tonnes", AF([REF(D, ROW19)])),
        SYM("catch25","Real","2025 catch in thousand tonnes", AF([REF(D, ROW25)])),
        SYM("boats19","Real","2019 number of boats", AF([REF(D, ROW19)])),
        SYM("boats25","Real","2025 number of boats", AF([REF(D, ROW25)]))]
prem = [PREM("c19", EQ(V("catch19"), R("48.0")), "Table 1: 2019 catch 48.0 thousand tonnes", AF([REF(D, ROW19)]), "supporting"),
        PREM("c25", EQ(V("catch25"), R("36.0")), "Table 1: 2025 catch 36.0 thousand tonnes", AF([REF(D, ROW25)]), "supporting"),
        PREM("b19", EQ(V("boats19"), R(412)), "Table 1: 2019 boats 412", AF([REF(D, ROW19)]), "supporting"),
        PREM("b25", EQ(V("boats25"), R(236)), "Table 1: 2025 boats 236", AF([REF(D, ROW25)]), "supporting")]
syms += [SYM("cpb19","Real","catch per boat in 2019, tonnes (48,000 ÷ 412)", AF([REF(D, ROW19)])),
         SYM("cpb25","Real","catch per boat in 2025, tonnes (36,000 ÷ 236)", AF([REF(D, ROW25)]))]
prem += [PREM("def19", EQ(V("cpb19"), DIV(R(48000), R(412))), "catch per boat 2019 = 48,000 tonnes ÷ 412 boats", GK()),
         PREM("def25", EQ(V("cpb25"), DIV(R(36000), R(236))), "catch per boat 2025 = 36,000 tonnes ÷ 236 boats", GK())]
concl = CONCL("cpb", AND(GE(V("cpb19"), R("116.45")), LT(V("cpb19"), R("116.55")), GE(V("cpb25"), R("152.45")), LT(V("cpb25"), R("152.55"))), "catch per boat rose from about 116.5 tonnes in 2019 to about 152.5 tonnes in 2025", SI())
tr("g11.7", "ec-t16-g11-7", syms, prem, concl, "Catch per boat is 48,000/412 = 116.50 tonnes in 2019 and 36,000/236 = 152.54 tonnes in 2025. 'About' has no stated precision; each figure is encoded at one decimal place.",
   [FLAG("vague-figure", "'about 116.5' and 'about 152.5' have no stated precision; encoded at one decimal place", ["within half a tonne", "within a tenth of a tonne"])], amb=True)

# g11.8
syms = [SYM("no_cost","Bool","the table holds no cost data", G("supplied_text", "established")),
        SYM("profit_unjudged","Bool","profit cannot be judged from the table", SI()),
        SYM("no_inflation","Bool","no inflation figure is given", G("supplied_text", "established")),
        SYM("price19","Real","2019 average price in P$ per tonne", AF([REF(D, ROW19)])),
        SYM("price25","Real","2025 average price in P$ per tonne", AF([REF(D, ROW25)])),
        SYM("value_pct","Real","percentage change in the value of the catch, 2019 to 2025", SI())]
prem = [PREM("no_cost", V("no_cost"), "the table holds no cost data", G("supplied_text", "established")),
        PREM("link", IMP(V("no_cost"), V("profit_unjudged")), "so profit cannot be judged", SI()),
        PREM("no_inf", V("no_inflation"), "no inflation figure is given", G("supplied_text", "established")),
        PREM("p19", EQ(V("price19"), R(2150)), "Table 1: 2019 average price P$2,150", AF([REF(D, ROW19)]), "supporting"),
        PREM("p25", EQ(V("price25"), R(2880)), "Table 1: 2025 average price P$2,880", AF([REF(D, ROW25)]), "supporting"),
        PREM("vpct", AND(GE(V("value_pct"), R("0.465")), LT(V("value_pct"), R("0.475"))), "the value of the catch rose 0.47% (the g6.1 result)", SI())]
price_rise = DIV(MUL(R(100), SUB(V("price25"), V("price19"))), R("2150"))
concl = CONCL("weigh", AND(V("profit_unjudged"), GE(price_rise, R("33.945")), LT(price_rise, R("33.955")), V("no_inflation"), LT(V("value_pct"), price_rise)),
              "the table holds no cost data, so profit cannot be judged; the price rose 33.95% in nominal terms (P$2,150 to P$2,880), with no inflation figure given, and the value of the catch rose only 0.47%", SI())
tr("g11.8", "ec-t16-g11-8", syms, prem, concl, "Price rise of 730 on 2,150 is 33.9535%, which to two decimal places is 33.95%. 'Only' is encoded as the value rise being less than the price rise. 'Nominal terms' is the specialist's description; the table gives no inflation figure.",
   [FLAG("nominal-terms", "'nominal terms' is the specialist's description; the table does not label its prices", ["the prices are nominal", "the prices are in some other terms"])])

# g11.9
syms = [SYM("alloc_landings","Bool","quotas were allocated by past landings", G("supplied_text", "established", [REF(D, "based on past landings")])),
        SYM("tradable","Bool","quota shares can be sold or leased to other owners", G("supplied_text", "established", [REF(D, "may sell or lease that share to other owners")])),
        SYM("can_concentrate","Bool","quotas can concentrate in a few companies", SI()),
        SYM("boats19","Int","2019 number of boats (Table 1)", AF([REF(D, ROW19)])),
        SYM("boats25","Int","2025 number of boats (Table 1)", AF([REF(D, ROW25)]))]
prem = [PREM("alloc", V("alloc_landings"), "quotas were allocated based on past landings", G("supplied_text", "established", [REF(D, "based on past landings")])),
        PREM("trade", V("tradable"), "quotas may be sold or leased", G("supplied_text", "established", [REF(D, "may sell or lease that share to other owners")])),
        PREM("link", IMP(AND(V("alloc_landings"), V("tradable")), V("can_concentrate")), "so they can concentrate in a few companies", SI()),
        PREM("b19", EQ(V("boats19"), I(412)), "Table 1: 412 boats in 2019", AF([REF(D, ROW19)]), "supporting"),
        PREM("b25", EQ(V("boats25"), I(236)), "Table 1: 236 boats in 2025", AF([REF(D, ROW25)]), "supporting")]
concl = CONCL("equity", AND(V("can_concentrate"), EQ(V("boats19"), I(412)), EQ(V("boats25"), I(236)), LT(V("boats25"), V("boats19")),
                            GE(DIV(MUL(R(100), SUB(TOREAL(V("boats25")), TOREAL(V("boats19")))), R("412")), R("-42.725")),
                            LT(DIV(MUL(R(100), SUB(TOREAL(V("boats25")), TOREAL(V("boats19")))), R("412")), R("-42.715"))),
              "Unit 3, equity: quotas were allocated by past landings and can be sold, so they can concentrate in a few companies, and the fleet fell from 412 to 236 boats (−42.72%)", SI())
tr("g11.9", "ec-t16-g11-9", syms, prem, concl, "Fleet change of −176 on 412 is −42.7184%, which to two decimal places is −42.72%. The concentration effect is the specialist's inference from the allocation and trading rules, which the text states.")

# g11.16
syms = [SYM("purpose_stock","Bool","the stock recovery is the purpose of the scheme", SI()),
        SYM("sustainability_decides","Bool","long-run sustainability is the deciding consideration", SI())]
prem = [PREM("purpose", V("purpose_stock"), "the stock recovery is the purpose of the scheme", SI()),
        PREM("link", IMP(V("purpose_stock"), V("sustainability_decides")), "because the stock recovery is the purpose, long-run sustainability decides", SI())]
concl = CONCL("conclusion", V("sustainability_decides"), "the deciding consideration is long-run sustainability, because the stock recovery is the purpose of the scheme", SI())
tr("g11.16", "ec-t16-g11-16", syms, prem, concl, "The specialist's concluding judgement, encoded from its stated reason. The other supporting claims weigh the options and are not part of this link; which consideration is 'deciding' is a judgement the check cannot test.",
   [FLAG("deciding-consideration", "'the deciding consideration' is a judgement: efficiency or equity could be read as deciding instead", ["sustainability decides", "efficiency or equity decides"])], amb=True)

write_report(BASE + "ec-t16.json", RID, claims)
print("wrote ec-t16", len(claims))
