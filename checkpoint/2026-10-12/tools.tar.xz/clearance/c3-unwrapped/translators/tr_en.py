import sys; sys.path.insert(0, "."); from tlib import *
REQ = "req-en-t16"; RID = "rep-en-t16-0"; D = "doc-auction"
Q = lambda ex: G("quotation", "established", [REF(D, ex)])
S_INF = lambda c="probable": G("specialist_inference", c)
claims = {}

# p2-point
syms = [
 SYM("honest_bench","Bool","the auctioneer calls the bench 'a good honest bench'", Q("a good honest bench")),
 SYM("give_forty","Bool","the auctioneer asks 'Somebody give me forty'", Q("Somebody give me forty")),
 SYM("laugh_voice","Bool","people laugh 'because that was what the voice was for'", Q("because that was what the voice was for")),
 SYM("oak_outlive","Bool","the auctioneer says \"It's oak, gentlemen, it'll outlive the lot of you\"", Q("It's oak, gentlemen, it'll outlive the lot of you")),
 SYM("goods_trade","Bool","the auctioneer's language turns the family's possessions into goods", S_INF()),
 SYM("performance_provokes","Bool","the auctioneer's performance is a means of provoking a response rather than communicating", S_INF()),
 SYM("sale_ends_hope","Bool","the sale ends something the family assumed would last", S_INF()),
 SYM("audible","Bool","the narrator makes that trade audible", S_INF()),
]
prem = [
 PREM("ev_honest", V("honest_bench"), "the bench is praised as 'a good honest bench'", Q("a good honest bench")),
 PREM("ev_give", V("give_forty"), "the call 'Somebody give me forty'", Q("Somebody give me forty")),
 PREM("ev_laugh", V("laugh_voice"), "people laugh because that was what the voice was for", Q("because that was what the voice was for")),
 PREM("ev_oak", V("oak_outlive"), "'It's oak, gentlemen, it'll outlive the lot of you'", Q("It's oak, gentlemen, it'll outlive the lot of you")),
 PREM("link_s02", IMP(AND(V("honest_bench"), V("give_forty")), V("goods_trade")), "praise and bid call reduce the bench to a price", S_INF()),
 PREM("link_s03", IMP(V("laugh_voice"), V("performance_provokes")), "the laughter presents the performance as provocation", S_INF()),
 PREM("link_s04", IMP(V("oak_outlive"), V("sale_ends_hope")), "the durability claim suggests the sale ends something lasting", S_INF()),
 PREM("link_point", IMP(AND(V("goods_trade"), V("performance_provokes"), V("sale_ends_hope")), V("audible")), "the trade is made audible by the narrator (point-level step)", S_INF()),
]
concl = CONCL("point", AND(V("goods_trade"), V("audible")), "the auctioneer's language turns the family's possessions into goods, and the narrator makes that trade audible", S_INF())
p = PROBLEM("en-t16-p2-point", "p2-point", REQ, syms, prem, concl)
claims["p2-point"] = TR(p, "Read as the point of the second paragraph: the auctioneer's language makes possessions into goods and the narrator makes that trade audible. Four quotations are the evidence; the three device links and the point-level step are the specialist's, encoded separately. The step to 'audible' is the specialist's own and has no separate evidence line, so the check exposes it as a link resting on the three device claims.")

# p3-point
syms = [
 SYM("stood_door","Bool","the father stands by the barn door with his hands in his coat pockets", Q("stood by the barn door with his hands in his coat pockets")),
 SYM("hand_looked","Bool","the father takes one hand out and looks at it, as if to check it is still his", Q("took one hand out and looked at it, as if to check that it was still his")),
 SYM("silent_sale","Bool","the father says nothing during the sale", G("supplied_text","established",[REF(D,"had not said a word since breakfast")])),
 SYM("tea_line","Bool","the father says 'They'll want tea, I suppose,'", Q("'They'll want tea, I suppose,'")),
 SYM("guard_image","Bool","the father stands as if someone had told him to guard the barn", Q("as if someone had told him to guard it")),
 SYM("body_not_speech","Bool","the narrator presents the father's body instead of his speech", S_INF()),
 SYM("loss_beyond_speech","Bool","the hand carries a loss that speech cannot", S_INF()),
 SYM("ownership_uncertain","Bool","the simile suggests ownership has become uncertain", S_INF()),
 SYM("hospitality","Bool","the tea remark turns the sale into a matter of domestic hospitality", S_INF()),
 SYM("no_role","Bool","the father has no role left at his own barn", S_INF()),
 SYM("opposite","Bool","the father's silence works in the opposite direction to the auctioneer's speech", S_INF()),
]
prem = [
 PREM("ev_stood", V("stood_door"), "the father stands by the barn door with his hands in his coat pockets", Q("stood by the barn door with his hands in his coat pockets")),
 PREM("ev_hand", V("hand_looked"), "he takes one hand out and looks at it", Q("took one hand out and looked at it, as if to check that it was still his")),
 PREM("silent", V("silent_sale"), "he says nothing through the sale", G("supplied_text","established",[REF(D,"had not said a word since breakfast")])),
 PREM("ev_tea", V("tea_line"), "his last spoken words are 'They'll want tea, I suppose,'", Q("'They'll want tea, I suppose,'")),
 PREM("ev_guard", V("guard_image"), "he stands as if someone had told him to guard it", Q("as if someone had told him to guard it")),
 PREM("link_s02", IMP(AND(V("silent_sale"), V("stood_door"), V("hand_looked")), V("body_not_speech")), "his silence and body are presented instead of speech", S_INF()),
 PREM("link_s03a", IMP(V("hand_looked"), V("loss_beyond_speech")), "the hand carries the loss that speech cannot", S_INF()),
 PREM("link_s03b", IMP(V("hand_looked"), V("ownership_uncertain")), "the simile suggests ownership is uncertain", S_INF()),
 PREM("link_s04a", IMP(V("tea_line"), V("hospitality")), "the tea remark makes the sale a matter of hospitality", S_INF()),
 PREM("link_s04b", IMP(V("guard_image"), V("no_role")), "the guard image presents a man with no role", S_INF()),
 PREM("link_point", IMP(AND(V("body_not_speech"), V("loss_beyond_speech"), V("ownership_uncertain"), V("hospitality"), V("no_role")), V("opposite")), "the supporting readings together make the silence work in the opposite direction", S_INF()),
]
concl = CONCL("point", V("opposite"), "The father's silence works in the opposite direction.", S_INF())
p = PROBLEM("en-t16-p3-point", "p3-point", REQ, syms, prem, concl)
claims["p3-point"] = TR(p, "Read as the point of the third paragraph: the father's silence and body work against the sale. Four quotations and the supplied fact that he is silent through the sale are the evidence; the specialist's device and interpretation links are separate implications, and the final link from them to the point is the specialist's own.")

# p1-s01 thesis
syms = [
 SYM("goods_trade","Bool","the auctioneer's language turns the family's possessions into goods", S_INF()),
 SYM("audible","Bool","the narrator makes that trade audible", S_INF()),
 SYM("opposite","Bool","the father's silence works in the opposite direction to the auctioneer's speech", S_INF()),
 SYM("carried_less","Bool","the loss is carried less by what is sold than by the one voice that refuses to join the sale", S_INF()),
 SYM("felt_unsaid","Bool","the family's loss is felt in what cannot be said", S_INF()),
 SYM("felt_sold","Bool","the family's loss is felt in what is sold", S_INF()),
]
prem = [
 PREM("sup_p2", AND(V("goods_trade"), V("audible")), "supporting point p2: the auctioneer's language turns possessions into goods and the narrator makes that trade audible", S_INF()),
 PREM("sup_p3", V("opposite"), "supporting point p3: the father's silence works in the opposite direction", S_INF()),
 PREM("sup_p4", V("carried_less"), "supporting point p4: the loss is carried less by what is sold than by the one voice that refuses to join the sale", S_INF()),
 PREM("link_thesis", IMP(AND(V("goods_trade"), V("audible"), V("opposite"), V("carried_less")), AND(V("felt_unsaid"), NOT(V("felt_sold")))), "the supporting points together present the loss as felt in what cannot be said, not in what is sold", S_INF()),
]
concl = CONCL("thesis", AND(V("felt_unsaid"), NOT(V("felt_sold"))), "the writer presents the family's loss as something felt in what cannot be said, not in what is sold", S_INF())
p = PROBLEM("en-t16-p1-s01", "p1-s01", REQ, syms, prem, concl)
claims["p1-s01"] = TR(p, "Read as the thesis: the writer sets the auctioneer's commercial speech against the father's silence so that the loss is felt in what cannot be said and not in what is sold. The three supporting points are encoded as premises (p2 as the conjunction of its two claims) and the fourth, non-eligible point p4 is also taken as a premise, since the thesis cites it. The thesis's link is the specialist's.")

write_report("/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c3/translations/en-t16.json", RID, claims)
print("wrote en-t16", list(claims))
