"""Builder helpers for IR 1.0 translation objects (scratch tooling, not project code)."""
import json

def V(n): return {"op": "var", "name": n}
def B(v): return {"op": "bool", "value": v}
def I(v): return {"op": "int", "value": str(v)}
def R(v): return {"op": "real", "value": str(v)}
def NOT(a): return {"op": "not", "arg": a}
def AND(*a): return {"op": "and", "args": list(a)}
def OR(*a): return {"op": "or", "args": list(a)}
def IMP(l, r): return {"op": "implies", "left": l, "right": r}
def IFF(l, r): return {"op": "iff", "left": l, "right": r}
def ADD(*a): return {"op": "add", "args": list(a)}
def MUL(*a): return {"op": "mul", "args": list(a)}
def SUB(l, r): return {"op": "sub", "left": l, "right": r}
def NEG(a): return {"op": "neg", "arg": a}
def DIV(l, r): return {"op": "div", "left": l, "right": r}
def TOREAL(a): return {"op": "to_real", "arg": a}
def EQ(l, r): return {"op": "eq", "left": l, "right": r}
def NE(l, r): return {"op": "ne", "left": l, "right": r}
def LT(l, r): return {"op": "lt", "left": l, "right": r}
def LE(l, r): return {"op": "le", "left": l, "right": r}
def GT(l, r): return {"op": "gt", "left": l, "right": r}
def GE(l, r): return {"op": "ge", "left": l, "right": r}

def G(kind, cert="established", refs=None, note=None):
    g = {"kind": kind, "certainty": cert, "source_refs": refs or []}
    if note:
        g["note"] = note
    return g

def REF(doc, excerpt=None, locator=None):
    r = {"document_id": doc}
    if locator:
        r["locator"] = locator
    if excerpt is not None:
        r["excerpt"] = excerpt
    return r

def SYM(name, sort, meaning, grounding=None):
    return {"name": name, "sort": sort, "meaning": meaning, "grounding": grounding}

def PREM(pid, expr, label, grounding, materiality="material"):
    return {"id": pid, "expr": expr, "label": label, "grounding": grounding, "materiality": materiality}

def CONCL(cid, expr, label, grounding):
    return {"id": cid, "expr": expr, "label": label, "grounding": grounding, "materiality": "material"}

def PROBLEM(pid, report_claim, req, symbols, premises, conclusion=None, query="entailment", notes=None):
    p = {"ir_version": "1.0", "problem_id": pid, "request_id": req, "claim_id": report_claim,
         "query": query, "symbols": symbols, "premises": premises}
    if conclusion is not None:
        p["conclusion"] = conclusion
    if notes:
        p["notes"] = notes
    return p

def TR(problem, reading, flags=None, ambiguous=False, unsupported=None):
    syms = problem["symbols"] if problem else []
    glossary = [{"symbol": s["name"], "meaning": s["meaning"], "grounding": s["grounding"]} for s in syms]
    return {"problem": problem,
            "interpretation": {"reading": reading, "glossary": glossary, "ambiguity_flags": flags or []},
            "ambiguous": ambiguous, "unsupported_reason": unsupported}

def NULLTR(reading, reason, flags=None):
    return {"problem": None,
            "interpretation": {"reading": reading, "glossary": [], "ambiguity_flags": flags or []},
            "ambiguous": False, "unsupported_reason": reason}

def FLAG(code, message, alternatives):
    return {"code": code, "message": message, "alternatives": alternatives}

def write_report(path, report_id, claims):
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"report_id": report_id, "claims": claims}, f, ensure_ascii=False, indent=2)
        f.write("\n")
