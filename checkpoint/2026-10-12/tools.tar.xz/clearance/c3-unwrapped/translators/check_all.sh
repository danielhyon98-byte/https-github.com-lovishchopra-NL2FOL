#!/bin/bash
F=/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c3/translations
PY=/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/z3venv/bin/python
for t in ll-t16 ps-t16 ph-t16 maa-t16; do
  ids=$($PY -I -c "import json,sys; print(' '.join(json.load(open(sys.argv[1]))['claims'].keys()))" $F/$t.json)
  for c in $ids; do
    res=$($PY -I -c "
import json,sys
from epinoic_logic.engine import parse_and_validate
d=json.load(open(sys.argv[1]))['claims'][sys.argv[2]]
if d.get('problem') is None:
    print('NULL'); sys.exit(0)
p,o=parse_and_validate(json.dumps(d['problem']))
print('OK' if o.ok else 'FAIL '+str(getattr(o,'findings',o))[:300])
" $F/$t.json "$c" 2>&1 | tail -1)
    echo "$t | $c | $res"
  done
done
