import sys; sys.path.insert(0, "."); from tlib import *
BASE = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c3/translations/"
REQ = "req-bi-t16"; RID = "rep-bi-t16-0"
AF = lambda: G("arithmetic_fact", "established")          # figure the task states
SI = lambda c="established": G("specialist_inference", c)
GK = lambda c="established": G("general_knowledge", c)
CNTS = {"ctrl": {"pro": 52, "meta": 14, "ana": 8, "tel": 14, "inter": 412},
        "ext": {"pro": 12, "meta": 21, "ana": 2, "tel": 4, "inter": 461}}
def csym(side, ph):
    n = f"{side}_{ph}"
    return SYM(n, "Int", f"{side} roots: {ph} cells out of 500 counted (task figure)", AF())
def cprem(side, ph):
    n = f"{side}_{ph}"
    return PREM(f"fact_{n}", EQ(V(n), I(CNTS[side][ph])), f"the task states {n} = {CNTS[side][ph]}", AF(), "supporting")
def sums(side, phases):
    return ADD(*[V(f"{side}_{p}") for p in phases])
MIT = ["pro", "meta", "ana", "tel"]
claims = {}

def mk(cid, pid, syms, prem, concl, reading, flags=None, amb=False):
    return PROBLEM(pid, cid, REQ, syms, prem, concl)

def tr(cid, pid, syms, prem, concl, reading, flags=None, amb=False):
    claims[cid] = TR(PROBLEM(pid, cid, REQ, syms, prem, concl), reading, flags or [], ambiguous=amb)

# s1.1
syms = [csym("ctrl", p) for p in MIT]
prem = [cprem("ctrl", p) for p in MIT]
concl = CONCL("sum", EQ(sums("ctrl", MIT), I(88)), "control roots: mitotic cells = 52 + 14 + 8 + 14 = 88", SI())
tr("s1.1", "bi-t16-s1-1", syms, prem, concl, "Sum of the four mitotic stage counts of the control roots, from the task's counts (prophase 52, metaphase 14, anaphase 8, telophase 14). Pure arithmetic on task figures.")

# s1.2
syms = [csym("ctrl", p) for p in MIT] + [SYM("mi_ctrl", "Real", "mitotic index of the control roots", SI())]
prem = [cprem("ctrl", p) for p in MIT]
prem.append(PREM("def_mi", EQ(V("mi_ctrl"), DIV(TOREAL(sums("ctrl", MIT)), R(500))), "mitotic index = mitotic cells ÷ 500 cells counted", GK()))
concl = CONCL("mi", AND(EQ(V("mi_ctrl"), R("0.176")), EQ(MUL(R(100), V("mi_ctrl")), R("17.6"))), "mitotic index = 88 ÷ 500 = 0.176 = 17.6%", SI())
tr("s1.2", "bi-t16-s1-2", syms, prem, concl, "Mitotic index of the control roots as mitotic cells over 500 counted; 88 ÷ 500 = 0.176 exactly, which is 17.6%. Exact fractions, so equality is encoded.")

# s1.3
syms = [csym("ext", p) for p in MIT]
prem = [cprem("ext", p) for p in MIT]
concl = CONCL("sum", EQ(sums("ext", MIT), I(39)), "extract roots: mitotic cells = 12 + 21 + 2 + 4 = 39", SI())
tr("s1.3", "bi-t16-s1-3", syms, prem, concl, "Sum of the four mitotic stage counts of the roots grown in the extract, from the task's counts. Pure arithmetic on task figures.")

# s1.4
syms = [csym("ext", p) for p in MIT] + [SYM("mi_ext", "Real", "mitotic index of the roots grown in the extract", SI())]
prem = [cprem("ext", p) for p in MIT]
prem.append(PREM("def_mi", EQ(V("mi_ext"), DIV(TOREAL(sums("ext", MIT)), R(500))), "mitotic index = mitotic cells ÷ 500 cells counted", GK()))
concl = CONCL("mi", AND(EQ(V("mi_ext"), R("0.078")), EQ(MUL(R(100), V("mi_ext")), R("7.8"))), "mitotic index = 39 ÷ 500 = 0.078 = 7.8%", SI())
tr("s1.4", "bi-t16-s1-4", syms, prem, concl, "Mitotic index of the extract roots: 39 ÷ 500 = 0.078 exactly, which is 7.8%. Supporting claims s1.1 to s1.3 are the counts and sums, encoded as the task facts above.")

# s2.1
syms = [SYM("pct_decrease", "Real", "percentage decrease in the mitotic index from control (17.6) to extract (7.8)", SI())]
prem = [PREM("def_pct", EQ(V("pct_decrease"), MUL(R(100), DIV(SUB(R("17.6"), R("7.8")), R("17.6")))), "percentage decrease = (17.6 − 7.8) ÷ 17.6 × 100, using the specialist's rounded indices", GK())]
concl = CONCL("pct", AND(GE(V("pct_decrease"), R("55.65")), LT(V("pct_decrease"), R("55.75")), GT(V("pct_decrease"), R(0))), "percentage decrease = 55.7%, a decrease", SI())
tr("s2.1", "bi-t16-s2-1", syms, prem, concl, "Percentage decrease from the specialist's rounded indices 17.6 and 7.8. The exact value is 55.68%; the claim '55.7%' is one decimal place, so it is encoded as 55.65 to 55.75. The inputs are the specialist's rounded indices rather than the exact 88/500 and 39/500.")

# s3.1
syms = [SYM("random_sample", "Bool", "the root-tip cells are a random sample of a continuously dividing population", G("assumption", "established")),
        SYM("equal_cycle_time", "Bool", "each cell takes the same time to pass through the cycle", G("assumption", "established")),
        SYM("proportional", "Bool", "time in a phase is proportional to the number of cells in that phase", SI())]
prem = [PREM("assume_random", V("random_sample"), "assumption: the cells are a random sample of a continuously dividing population", G("assumption", "established")),
        PREM("assume_equal", V("equal_cycle_time"), "assumption: each cell takes the same time through the cycle", G("assumption", "established")),
        PREM("link", IMP(AND(V("random_sample"), V("equal_cycle_time")), V("proportional")), "so time in a phase is proportional to the number of cells in it", SI())]
concl = CONCL("prop", V("proportional"), "time in a phase is proportional to the number of cells in it", SI())
tr("s3.1", "bi-t16-s3-1", syms, prem, concl, "Two stated assumptions, with the specialist's 'so' encoded as one implication. The assumptions carry no textual support; they are grounded as assumptions, not as facts.")

# s3.2
syms = [SYM("ctrl_meta", "Int", "control roots: metaphase cells out of 500 counted (task figure)", AF()),
        SYM("time_meta", "Real", "time spent in metaphase by a control cell, in minutes", SI()),
        SYM("proportional", "Bool", "time in a phase is proportional to the number of cells in that phase", SI())]
prem = [PREM("fact_meta", EQ(V("ctrl_meta"), I(14)), "the task states metaphase = 14 for the control roots", AF(), "supporting"),
        PREM("prop_premise", V("proportional"), "time in a phase is proportional to cell count (assumption s3.1)", SI()),
        PREM("calc_link", IMP(V("proportional"), EQ(V("time_meta"), DIV(MUL(TOREAL(V("ctrl_meta")), R(1080)), R(500)))), "time in metaphase = (14 ÷ 500) × 18 h = (14 ÷ 500) × 1080 min", SI())]
concl = CONCL("time", AND(EQ(V("time_meta"), R("30.24")), GE(V("time_meta"), R("29.5")), LT(V("time_meta"), R("30.5"))), "time in metaphase = 30.24 min, so about 30 min", SI())
tr("s3.2", "bi-t16-s3-2", syms, prem, concl, "Metaphase time for a control cell as 14/500 of an 18-hour (1080-minute) cycle, which is exactly 30.24 min. 'About 30 min' is encoded at the written precision of 30 (29.5 to 30.5), so 30.24 is within it.",
    [FLAG("vague-figure", "'about 30 min' has no stated precision; encoded to units", ["exactly 30 min", "30 min to the nearest five minutes"])], amb=True)

# s4.1
syms = [SYM("ext_inter", "Int", "extract roots: interphase cells out of 500 (task figure)", AF()),
        SYM("ctrl_inter", "Int", "control roots: interphase cells out of 500 (task figure)", AF())]
prem = [PREM("fact_ext_inter", EQ(V("ext_inter"), I(461)), "the task states interphase = 461 for the extract roots", AF(), "supporting"),
        PREM("fact_ctrl_inter", EQ(V("ctrl_inter"), I(412)), "the task states interphase = 412 for the control roots", AF(), "supporting")]
concl = CONCL("inter", AND(EQ(V("ext_inter"), I(461)), EQ(V("ctrl_inter"), I(412)), GT(V("ext_inter"), I(250)), GT(V("ext_inter"), V("ctrl_inter"))), "the extract mainly holds cells in interphase, which rises from 412 to 461 cells", SI())
tr("s4.1", "bi-t16-s4-1", syms, prem, concl, "Interphase counts from the task, with 'mainly' read as a majority of the 500 counted (more than 250) and 'rises' as an increase over the control. The supporting claims about other phases are not needed for this conclusion.",
    [FLAG("vague-figure", "'mainly' has no stated threshold; read as more than half of the 500 counted", ["more than half", "a plurality of the stages"])], amb=False)

# s4.2
syms = [csym("ctrl", p) for p in ["pro", "meta", "ana", "tel", "inter"]] + [csym("ext", p) for p in ["pro", "meta", "ana", "tel", "inter"]] + [
        SYM("pro_falls_most", "Bool", "prophase shows the largest fall from control to extract among all stages", AF()),
        SYM("fewer_mitosis", "Bool", "fewer cells progress into mitosis", SI("probable"))]
prem = [cprem(s, p) for s in ["ctrl", "ext"] for p in ["pro", "meta", "ana", "tel", "inter"]]
def dec(p): return SUB(V(f"ctrl_{p}"), V(f"ext_{p}"))
prem.append(PREM("def_falls_most", IFF(V("pro_falls_most"), AND(*[GT(dec("pro"), dec(p)) for p in ["meta", "ana", "tel", "inter"]])), "prophase's fall (52 to 12) is larger than the change in every other stage", AF()))
prem.append(PREM("link", IMP(V("pro_falls_most"), V("fewer_mitosis")), "the largest fall in prophase suggests fewer cells progress into mitosis", SI("probable")))
concl = CONCL("pro", AND(V("pro_falls_most"), V("fewer_mitosis")), "prophase falls most, from 52 to 12 cells, which suggests that fewer cells progress into mitosis", SI("probable"))
tr("s4.2", "bi-t16-s4-2", syms, prem, concl, "'Falls most' is a comparison over every stage: prophase's decrease (40 cells) exceeds the change in each other stage. The suggestion is the specialist's, encoded as a probable link.",
    [FLAG("comparison-set", "'falls most' is read over all five stages counted", ["over the four mitotic stages only", "over all stages"])], amb=False)

# s4.3
syms = [csym("ctrl", p) for p in ["meta", "ana"]] + [csym("ext", p) for p in ["meta", "ana"]] + [
        SYM("pct_ext_meta", "Real", "metaphase as a percentage of mitotic cells in the extract", SI()),
        SYM("pct_ctrl_meta", "Real", "metaphase as a percentage of mitotic cells in the control", SI())]
prem = [cprem("ctrl", "meta"), cprem("ext", "meta"), cprem("ctrl", "ana"), cprem("ext", "ana"),
        PREM("def_pct_ext", EQ(V("pct_ext_meta"), DIV(MUL(R(100), TOREAL(V("ext_meta"))), R(39))), "percentage = 100 × metaphase ÷ 39 extract mitotic cells", GK()),
        PREM("def_pct_ctrl", EQ(V("pct_ctrl_meta"), DIV(MUL(R(100), TOREAL(V("ctrl_meta"))), R(88))), "percentage = 100 × metaphase ÷ 88 control mitotic cells", GK())]
concl = CONCL("cmp", AND(GT(V("ext_meta"), V("ctrl_meta")), EQ(V("ext_meta"), I(21)), EQ(V("ctrl_meta"), I(14)), LT(V("ext_ana"), V("ctrl_ana")), EQ(V("ext_ana"), I(2)), EQ(V("ctrl_ana"), I(8)),
                          GE(V("pct_ext_meta"), R("53.5")), LT(V("pct_ext_meta"), R("54.5")), GE(V("pct_ctrl_meta"), R("15.5")), LT(V("pct_ctrl_meta"), R("16.5"))),
              "metaphase rises from 14 to 21 cells while anaphase falls from 8 to 2, so 54% of dividing cells are at metaphase, against 16% in the control", SI())
tr("s4.3", "bi-t16-s4-3", syms, prem, concl, "Counts from the task. Percentages are of the mitotic cells (39 extract, 88 control): 21/39 = 53.85%, which is 54% to the nearest whole percent, and 14/88 = 15.91%, which is 16%. Both whole-percent figures are encoded at their written precision.")

# s4.5
syms = [SYM("counted_500", "Bool", "500 cells were counted in each treatment, as single counts", G("task_setting", "established")),
        SYM("proportions_shown", "Bool", "the counts show the proportion of cells at each stage", SI()),
        SYM("durations_shown", "Bool", "the counts show how long each stage lasts", SI())]
prem = [PREM("task_counts", V("counted_500"), "500 cells counted per treatment, once each (a single count)", G("task_setting", "established")),
        PREM("link_prop", IMP(V("counted_500"), V("proportions_shown")), "single counts show the proportion of cells at each stage", SI()),
        PREM("link_dur", IMP(V("counted_500"), NOT(V("durations_shown"))), "single counts do not show how long each stage lasts", SI())]
concl = CONCL("snap", AND(V("proportions_shown"), NOT(V("durations_shown"))), "these are single counts of 500 cells per treatment, so they show the proportion of cells at each stage, not how long each stage lasts", SI())
tr("s4.5", "bi-t16-s4-5", syms, prem, concl, "The single-count design is a task setting; the two inferences (proportions shown, durations not shown) are the specialist's and encoded as separate implications.")

# s5.1
syms = [SYM("tip_meristem", "Bool", "root tips contain meristematic tissue", GK()),
        SYM("meristem_divides", "Bool", "meristematic cells divide continuously by mitosis", GK()),
        SYM("enough_mitotic", "Bool", "enough root-tip cells are in mitosis to count", SI())]
prem = [PREM("gk_tip", V("tip_meristem"), "root tips contain meristematic tissue", GK()),
        PREM("gk_divides", V("meristem_divides"), "meristematic cells divide continuously by mitosis", GK()),
        PREM("link", IMP(AND(V("tip_meristem"), V("meristem_divides")), V("enough_mitotic")), "so enough cells are in mitosis to count", SI())]
concl = CONCL("enough", V("enough_mitotic"), "root tips contain meristematic tissue, whose cells divide continuously by mitosis, so enough cells are in mitosis to count", SI())
tr("s5.1", "bi-t16-s5-1", syms, prem, concl, "Biology background stated from memory (meristem, continuous mitosis) and the specialist's inference that enough cells are in mitosis to count.")

# s5.2
syms = [SYM("older_specialised", "Bool", "older root tissue has specialised cells", GK()),
        SYM("stopped_dividing", "Bool", "those specialised cells have stopped dividing", GK()),
        SYM("index_low", "Bool", "the mitotic index of older root tissue would be too low", SI()),
        SYM("compare_unreliable", "Bool", "the mitotic index could not be compared reliably", SI())]
prem = [PREM("gk_spec", V("older_specialised"), "older root tissue has specialised cells", GK()),
        PREM("gk_stopped", V("stopped_dividing"), "those cells have stopped dividing", GK()),
        PREM("link", IMP(AND(V("older_specialised"), V("stopped_dividing")), AND(V("index_low"), V("compare_unreliable"))), "so the mitotic index would be too low to compare reliably", SI())]
concl = CONCL("low", AND(V("index_low"), V("compare_unreliable")), "older root tissue has specialised cells that have stopped dividing, so the mitotic index would be too low to compare reliably", SI())
tr("s5.2", "bi-t16-s5-2", syms, prem, concl, "Background biology stated from memory and the specialist's own inference that the index would be too low to compare reliably.")

write_report(BASE + "bi-t16.json", RID, claims)
print("wrote bi-t16", list(claims))
