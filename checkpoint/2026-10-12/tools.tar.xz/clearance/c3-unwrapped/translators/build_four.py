import json, sys
from fractions import Fraction
sys.path.insert(0, "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c3/translators")
from tlib import *

BASE = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c3"

def RC(x):
    f = Fraction(x) if isinstance(x, str) else Fraction(x)
    s = str(f.numerator) if f.denominator == 1 else f"{f.numerator}/{f.denominator}"
    return {"op": "real", "value": s}

def NULL(reason):
    return reason

def prob(pid, claim, req, symbols, premises, concl):
    return PROBLEM(pid, claim, req, symbols, premises, concl)

def chain_problem(pid, claim, req, syms, prems, concl_id, concl_expr, concl_label, concl_g):
    c = CONCL(concl_id, concl_expr, concl_label, concl_g)
    return PROBLEM(pid, claim, req, syms, prems, c)

out = {}

# ---------------- LL: all eligible claims are tutoring instructions or a refusal, not argument claims
ll_reason = ("The listed claim is a tutoring instruction, a statement about the student's notes, a sources list, "
             "a promise of feedback or a refusal to write the essay; it has no relation between premises and a point to check, "
             "so no problem is formed.")
ll_claims = ["p2-point", "p3-point", "p4-point", "p5-point", "p6-point", "p7-point", "p8-point", "p1-s01", "p5-s03"]
ll = {c: NULLTR("Not formalised: " + ll_reason, ll_reason) for c in ll_claims}
ll["p5-s03"] = NULLTR("Not formalised: an instruction with an inline method label; the label is not an argument.",
                      "A method instruction ('check each claim against what appears on screen'); not a claim with a relation to check.")
out["ll-t16"] = ll

# ---------------- PS
REQ_PS = "req-ps-t16"
ps = {}
ps_claim = lambda k: f"{k}@psychology-specialist"
def ps_(k): return ps_claim(k)

# g2.3 percentages
ps[ps_("g2.3")] = TR(prob("ps-g2.3", ps_("g2.3"), REQ_PS,
    [SYM("stopped_app","Int","students in the app group who stopped before week 6",
         G("quotation","established",[REF("doc-calmstep-s1","Eleven students in the app group stopped using the app before week 6")])),
     SYM("n_app","Int","students allocated to the app group",
         G("quotation","established",[REF("doc-calmstep-s1","n = 46")])),
     SYM("stopped_wl","Int","waiting-list students who did not complete the second questionnaire",
         G("quotation","established",[REF("doc-calmstep-s1","two students on the waiting list did not complete it")]))],
    [PREM("pa_stop", EQ(V("stopped_app"), I(11)), "eleven app-group students stopped", G("quotation","established",[REF("doc-calmstep-s1","Eleven students in the app group stopped using the app before week 6")])),
     PREM("pa_n", EQ(V("n_app"), I(46)), "46 allocated to the app", G("quotation","established",[REF("doc-calmstep-s1","n = 46")])),
     PREM("pw_stop", EQ(V("stopped_wl"), I(2)), "two waiting-list students did not complete", G("quotation","established",[REF("doc-calmstep-s1","two students on the waiting list did not complete it")]))],
    CONCL("g2.3-c", AND(GE(DIV(MUL(RC(100),TOREAL(V("stopped_app"))),RC(46)),RC("23.85")),
                        LT(DIV(MUL(RC(100),TOREAL(V("stopped_app"))),RC(46)),RC("23.95")),
                        GE(DIV(MUL(RC(100),TOREAL(V("stopped_wl"))),RC(46)),RC("4.25")),
                        LT(DIV(MUL(RC(100),TOREAL(V("stopped_wl"))),RC(46)),RC("4.35"))),
          "11 of 46 (23.9%) app students stopped and 2 of 46 (4.3%) waiting-list students did not complete",
          G("arithmetic_fact","established")),
    ), "Percentages computed from the counts in Source 1; each stated figure is encoded to its stated precision (one decimal place).",
    flags=[])
ps[ps_("g2.3")]["interpretation"]["reading"] = "Percentages computed from Source 1's counts (11 of 46 and 2 of 46), encoded to one decimal place (half-unit rounding)."

def simple_ps(k, reading, expr, label, grounding_kind="arithmetic_fact"):
    return TR(PROBLEM("ps-"+k, ps_(k), REQ_PS, [], [], CONCL("c", expr, label, G(grounding_kind,"established"))) and
              PROBLEM("ps-"+k, ps_(k), REQ_PS, [], [], CONCL("c", expr, label, G(grounding_kind,"established"))),
              reading)

def ps_arith(k, reading, expr, label):
    p = PROBLEM("ps-"+k, ps_(k), REQ_PS, [], [], CONCL("c", expr, label, G("arithmetic_fact","established")))
    return TR(p, reading)

ps[ps_("g3.2")] = ps_arith("g3.2", "Fall of 4.5 points from 13.6 to 9.1 and its percentage of the start (33%, to the nearest whole percent).",
    AND(EQ(SUB(RC("13.6"),RC("9.1")),RC("4.5")),
        GE(MUL(RC(100),DIV(RC("4.5"),RC("13.6"))),RC("32.5")),
        LT(MUL(RC(100),DIV(RC("4.5"),RC("13.6"))),RC("33.5"))),
    "The app group's mean fell 13.6 to 9.1, a fall of 4.5 points, about 33% of the starting score")
ps[ps_("g3.3")] = ps_arith("g3.3", "Waiting-list fall of 0.6 points and its share (about 4%, to the nearest whole percent).",
    AND(EQ(SUB(RC("13.4"),RC("12.8")),RC("0.6")),
        GE(MUL(RC(100),DIV(RC("0.6"),RC("13.4"))),RC("3.5")),
        LT(MUL(RC(100),DIV(RC("0.6"),RC("13.4"))),RC("4.5"))),
    "The waiting-list mean fell 13.4 to 12.8, a fall of 0.6 points, about 4%")
ps[ps_("g3.4")] = ps_arith("g3.4", "Arithmetic of the difference in change only; the claim that different starting levels are unlikely is a judgement and is not encoded.",
    EQ(SUB(RC("4.5"),RC("0.6")),RC("3.9")), "4.5 - 0.6 = 3.9 points")
ps[ps_("g3.5")] = ps_arith("g3.5", "End-of-study difference, waiting list minus app group.",
    EQ(SUB(RC("12.8"),RC("9.1")),RC("3.7")), "At the end the app group scored 3.7 points lower (12.8 - 9.1)")
ps[ps_("g3.6")] = ps_arith("g3.6", "Ratio of the difference to the stated standard deviation (about 1.3); 'about 2.9' is the stated SD and is taken as given.",
    AND(GE(DIV(RC("3.7"),RC("2.9")),RC("1.25")), LT(DIV(RC("3.7"),RC("2.9")),RC("1.35"))),
    "3.7 / 2.9 is about 1.3 (one decimal place)")
ps[ps_("g2.4")] = NULLTR("Not formalised: a judgement that the analysed groups no longer match the random allocation; a qualitative claim without a checkable relation.",
    "Qualitative methodological judgement (groups analysed differ from the allocated groups); no formal relation is encoded.")
ps[ps_("g2.6")] = NULLTR("Not formalised: a 'possible' speculation about the direction of bias; no supplied figures establish it.",
    "Speculative qualitative claim about who stayed; not encodable from the supplied figures.")
ps[ps_("g3.7")] = NULLTR("Not formalised: an interpretation of a p-value (statistical versus practical significance); the claim is conceptual.",
    "Conceptual claim about the meaning of a p-value; not a relation over supplied figures.")
ps[ps_("g4.2")] = NULLTR("Not formalised: a cautious-conclusion judgement that restates the study's limits.",
    "Evaluative conclusion about the strength of evidence; no checkable relation.")
ps[ps_("g8.1")] = NULLTR("Not formalised: restates the supplied fact that one psychologist grouped the comments; no separate relation.",
    "The claim restates a supplied fact (one person grouped the comments) without an inferential link.")

def ps_chain(k, reading, qdoc, qexcerpt, qsym, qmean, link_label, link_cert, concl_sym, concl_mean, concl_label, concl_cert):
    syms = [SYM(qsym,"Bool",qmean,G("quotation","established",[REF(qdoc,qexcerpt)])),
            SYM(concl_sym,"Bool",concl_mean,G("specialist_inference",concl_cert))]
    prems = [PREM("ev_"+qsym, V(qsym), qmean, G("quotation","established",[REF(qdoc,qexcerpt)])),
             PREM("link_"+concl_sym, IMP(V(qsym), V(concl_sym)), link_label, G("specialist_inference",link_cert))]
    c = CONCL("c_"+concl_sym, V(concl_sym), concl_label, G("specialist_inference",concl_cert))
    return TR(PROBLEM("ps-"+k, ps_(k), REQ_PS, syms, prems, c), reading)

ps[ps_("g6.1")] = ps_chain("g6.1", "The psychologist's design role is a quotation; the risk to interpretation is the specialist's inference.",
    "doc-calmstep-s2", "who had helped to design the app", "designer", "the psychologist helped to design the app",
    "a researcher who helped design the app could shape which comments are noticed and how they are grouped", "probable",
    "reflex_risk", "the psychologist's view could shape which comments were noticed and grouped",
    "Reflexivity: the psychologist's view of the app could shape which comments were noticed and how they were grouped", "probable")
ps[ps_("g7.1")] = ps_chain("g7.1", "Notes-not-recording is quoted; the paraphrase risk is the specialist's 'possible' inference.",
    "doc-calmstep-s2", "took notes during the interviews instead of recording them", "notes_not_recorded", "the psychologist took notes rather than recording the interviews",
    "students' words may be paraphrased or selectively noted when notes replace recordings", "possible",
    "paraphrase_risk", "students' words may have been paraphrased or selectively noted",
    "Recording and transcription: students' words may have been paraphrased or selectively noted", "possible")

# ---------------- PH
REQ_PH = "req-ph-t16"
ph = {}
ph_claim = lambda k: k
def ph_arith(k, reading, expr, label):
    p = PROBLEM("ph-"+k, k, REQ_PH, [], [], CONCL("c", expr, label, G("arithmetic_fact","established")))
    return TR(p, reading)
NULLREASON = {
 "s1.1": "A marks label ('calculate, 2 marks'); no claim.",
 "s1.4": "A provisional-credit grading statement; a marking decision, not a checkable relation.",
 "s1.5": "A provisional mark; a grading decision, not a checkable relation.",
 "s2.1": "A marks label; no claim.",
 "s2.4": "A provisional mark range; a grading decision.",
 "s2.5": "A marking judgement about why a mark is lost; not a relation over supplied figures.",
 "s2.6": "A statement about the markscheme, which is not supplied; not checkable.",
 "s2.9": "A size-check judgement ('fails a size check'); its arithmetic inputs are encoded in s2.11 and not repeated here.",
 "s3.1": "A marks label; no claim.",
 "s3.2": "A statement of what the question asks; no checkable relation.",
 "s3.4": "A judgement about which constant is correct; the relation in the claim is conceptual.",
 "s3.5": "A provisional mark; a grading decision.",
 "s3.6": "A definition of R from memory (general knowledge), restated without a relation to check.",
 "s3.9": "An instruction on how to write the answer, with a qualitative order-of-magnitude judgement; not encoded.",
 "s4.1": "A marks label; no claim.",
 "s4.2": "A statement of what the question asks, as a three-link chain; the links are encoded in s4.13 and s4.15.",
 "s4.6": "A provisional mark; a grading decision.",
 "s5.2": "A cross-reference to parts 1(b) and 1(d); no relation of its own.",
 "s6.8": "A study-habit instruction; not a claim with a relation to check.",
 "s7.1": "A practice-task statement for the student to attempt; not a claim.",
 "s7.3": "A question to the student (a practice task); not a claim.",
 "s7.4": "A question to the student (a practice task); not a claim.",
 "s2.3": "The gas-law rearrangement divides by a non-constant temperature (T1), which IR 1.0 does not allow (division only by a constant); not encodable.",
}
for k, v in NULLREASON.items():
    ph[k] = NULLTR(f"Not formalised: {v}", v)

ph["s1.3"] = ph_arith("s1.3", "The two substitutions only (the relation n = PV/RT is not encoded as a premise). Product 3.0e5 x 2.4e-3 = 720 exactly; 8.31 x 290 = 2409.9, written as 2410 (half-unit rounding).",
    AND(EQ(MUL(RC(300000),RC("2.4e-3")),RC(720)),
        GE(MUL(RC("8.31"),RC(290)),RC("2409.5")), LT(MUL(RC("8.31"),RC(290)),RC("2410.5"))),
    "3.0 x 10^5 x 2.4 x 10^-3 = 720 and 8.31 x 290 = 2410")
ph["s1.7"] = ph_arith("s1.7", "720/2410 = 0.29875; stated as 0.299 (3 d.p.) and 0.30 (2 d.p.), not 0.33.",
    AND(GE(DIV(RC(720),RC(2410)),RC("0.2985")), LT(DIV(RC(720),RC(2410)),RC("0.2995")),
        GE(DIV(RC(720),RC(2410)),RC("0.295")), LT(DIV(RC(720),RC(2410)),RC("0.305")),
        OR(LT(DIV(RC(720),RC(2410)),RC("0.325")), GT(DIV(RC(720),RC(2410)),RC("0.335")))),
    "720/2410 = 0.299, so the answer is 0.30 mol, not 0.33 mol")
ph["s1.8"] = ph_arith("s1.8", "Multiply-back check: 0.30 x 2410 = 723 (the 'close to 720' judgement is not encoded).",
    EQ(MUL(RC("0.30"),RC(2410)),RC(723)), "0.30 x 2410 = 723")
ph["s1.9"] = ph_arith("s1.9", "Kelvin conversion of 17 C.", EQ(ADD(RC(17),RC(273)),RC(290)), "17 + 273 = 290 K")
ph["s1.10"] = ph_arith("s1.10", "Model answer for 1(a): the two products and the quotient to 2 d.p.",
    AND(EQ(MUL(RC(300000),RC("2.4e-3")),RC(720)), GE(MUL(RC("8.31"),RC(290)),RC("2409.5")), LT(MUL(RC("8.31"),RC(290)),RC("2410.5")),
        GE(DIV(RC(720),RC(2410)),RC("0.295")), LT(DIV(RC(720),RC(2410)),RC("0.305"))),
    "n = (3.0e5 x 2.4e-3)/(8.31 x 290) = 720/2410 = 0.30 mol")
ph["s2.2"] = ph_arith("s2.2", "Kelvin temperatures used for the question (P proportional to T, the proportionality not encoded).",
    AND(EQ(ADD(RC(17),RC(273)),RC(290)), EQ(ADD(RC(35),RC(273)),RC(308))), "T1 = 290 K and T2 = 308 K")
ph["s2.7"] = None  # set below with chain
ph["s2.8"] = ph_arith("s2.8", "The correct ratio is 308/290, which differs from 35/17.",
    NE(DIV(RC(308),RC(290)), DIV(RC(35),RC(17))), "The gas-law ratio is 308/290, not 35/17")
ph["s2.10"] = ph_arith("s2.10", "Kelvin conversions written out (the 'check the size' instruction is not encoded).",
    AND(EQ(ADD(RC(17),RC(273)),RC(290)), EQ(ADD(RC(35),RC(273)),RC(308))), "T1 = 17 + 273 = 290 K and T2 = 35 + 273 = 308 K")
ph["s2.11"] = ph_arith("s2.11", "P2 = 3.0e5 x 308/290 = 318 621 Pa, stated as 3.2e5 Pa (2 s.f., half-unit rounding).",
    AND(EQ(ADD(RC(17),RC(273)),RC(290)), EQ(ADD(RC(35),RC(273)),RC(308)),
        GE(DIV(MUL(RC(300000),RC(308)),RC(290)),RC(315000)), LT(DIV(MUL(RC(300000),RC(308)),RC(290)),RC(325000))),
    "T1 = 290 K; T2 = 308 K; P2 = 3.0e5 x 308/290 = 3.2e5 Pa")
ph["s3.7"] = ph_arith("s3.7", "k_B = R / N_A with N_A = 6.02e23 mol^-1 (a constant taken as general knowledge); value 1.38e-23 to 3 s.f.",
    AND(GE(DIV(RC("8.31"),RC(602000000000000000000000)),RC("1.375e-23")),
        LT(DIV(RC("8.31"),RC(602000000000000000000000)),RC("1.385e-23"))),
    "k_B = R/N_A = 1.38 x 10^-23 J K^-1")
ph["s3.8"] = ph_arith("s3.8", "Ratio of 3840 J to one molecule's kinetic energy at 308 K (1.5 x 1.38e-23 x 308), stated to 1 s.f. (about 6e23).",
    AND(GE(DIV(RC(3840),MUL(RC("1.5"),RC("1.38e-23"),RC(308))),RC("5.5e23")),
        LT(DIV(RC(3840),MUL(RC("1.5"),RC("1.38e-23"),RC(308))),RC("6.5e23"))),
    "3840 J is about 6 x 10^23 times the energy of one molecule")
ph["s3.10"] = ph_arith("s3.10", "E_k = 1.5 x 1.38e-23 x 308 = 6.38e-21 J, stated as 6.4e-21 J (2 s.f.).",
    AND(GE(MUL(RC("1.5"),RC("1.38e-23"),RC(308)),RC("6.35e-21")),
        LT(MUL(RC("1.5"),RC("1.38e-23"),RC(308)),RC("6.45e-21"))),
    "E_k = (3/2) k_B T = 1.5 x 1.38e-23 x 308 = 6.4 x 10^-21 J")

ph["s2.7"] = ps_chain.__wrapped__ if False else None
def ph_chain(k, reading, qexcerpt, qsym, qmean, link_label, link_cert, csym, cmean, clabel, ccert):
    syms = [SYM(qsym,"Bool",qmean,G("quotation","established",[REF("doc-tyre-student",qexcerpt)])),
            SYM(csym,"Bool",cmean,G("specialist_inference",ccert))]
    prems = [PREM("ev_"+qsym, V(qsym), qmean, G("quotation","established",[REF("doc-tyre-student",qexcerpt)])),
             PREM("link_"+csym, IMP(V(qsym),V(csym)), link_label, G("specialist_inference",link_cert))]
    c = CONCL("c_"+csym, V(csym), clabel, G("specialist_inference",ccert))
    return TR(PROBLEM("ph-"+k, k, REQ_PH, syms, prems, c), reading)
ph["s2.7"] = ph_chain("s2.7", "Quotation of the student's ratio 35/17; the Celsius reading is the specialist's inference.",
    "P2 = P1 × T2/T1 = 3.0 × 10^5 × 35/17", "e_ratio", "the student's working uses 35/17 for the temperature ratio",
    "a gas-law ratio built from 17 and 35 treats them as Celsius values", "probable",
    "celsius_used", "17 and 35 were used as Celsius values", "17 and 35 were used as Celsius values", "probable")
ph["s6.2"] = ph_chain("s6.2", "Same quotation as 2(b); the Celsius use inside gas laws is the specialist's inference.",
    "3.0 × 10^5 × 35/17", "e_ratio", "the student's working uses 35/17 for the temperature ratio",
    "a gas-law ratio built from 17 and 35 treats them as Celsius values", "probable",
    "celsius_used", "temperatures in Celsius are used inside the gas laws", "Temperatures in degrees Celsius are used inside gas laws", "probable")
ph["s6.4"] = ph_chain("s6.4", "Quotation of the student's Ek = (3/2)RT; the claim that R is wrongly used per molecule is the specialist's inference.",
    "Ek = 3/2 RT = 1.5 × 8.31 × 308", "e_R", "the student writes Ek = 3/2 RT with 8.31",
    "the form 3/2 RT uses the per-mole gas constant for one molecule", "probable",
    "R_for_molecule", "the gas constant R is used where a single molecule needs k_B", "The gas constant R, which is per mole, is used where k_B is needed for one molecule", "probable")
ph["s6.6"] = ph_chain("s6.6", "Quotation of the student's collision sentence; placing collisions between molecules is the specialist's reading.",
    "hit each other more often and harder", "e_coll", "the student says molecules hit each other more often and harder",
    "a statement about molecule-molecule collisions is placed where wall collisions belong", "probable",
    "collisions_placed", "collisions are placed between molecules instead of with the container walls", "Collisions are placed between molecules instead of with the container walls", "probable")

def ph_bool(k, reading, syms, prems, c_id, c_expr, c_label, c_g):
    return TR(PROBLEM("ph-"+k, k, REQ_PH, syms, prems, CONCL(c_id, c_expr, c_label, c_g)), reading)
ph["s4.13"] = ph_bool("s4.13", "Chain: a temperature rise makes molecules faster (general knowledge), faster molecules have higher mean KE (general knowledge).",
    [SYM("hot","Bool","the temperature rises",G("task_setting","established")),
     SYM("faster","Bool","the molecules move faster",G("general_knowledge","established")),
     SYM("ke_up","Bool","the mean kinetic energy rises",G("general_knowledge","established"))],
    [PREM("p_hot", V("hot"), "the temperature rises", G("task_setting","established")),
     PREM("l1", IMP(V("hot"),V("faster")), "a higher temperature gives faster molecules", G("general_knowledge","established")),
     PREM("l2", IMP(V("faster"),V("ke_up")), "faster molecules have a higher mean kinetic energy", G("general_knowledge","established"))],
    "c", V("ke_up"), "A higher temperature means faster molecules, so their mean kinetic energy rises", G("general_knowledge","established"))
ph["s4.15"] = ph_bool("s4.15", "Chain from larger momentum changes at the wall to force (rate of change of momentum) and, with area fixed, to pressure.",
    [SYM("momentum_up","Bool","larger momentum changes at the wall",G("specialist_inference","probable")),
     SYM("force_up","Bool","the force on the wall rises",G("general_knowledge","established")),
     SYM("area_fixed","Bool","the area (volume) is fixed",G("task_setting","established")),
     SYM("pressure_up","Bool","the pressure rises",G("general_knowledge","established"))],
    [PREM("p_mom", V("momentum_up"), "larger momentum changes at the wall", G("specialist_inference","probable")),
     PREM("l_force", IMP(V("momentum_up"),V("force_up")), "force is the rate of change of momentum", G("general_knowledge","established")),
     PREM("p_area", V("area_fixed"), "the volume is fixed", G("task_setting","established")),
     PREM("l_press", IMP(AND(V("force_up"),V("area_fixed")),V("pressure_up")), "with area fixed, a larger force per unit area is a higher pressure", G("general_knowledge","established"))],
    "c", V("pressure_up"), "The force on the wall is the rate of change of momentum, so with the area fixed, pressure rises", G("general_knowledge","established"))

# ---------------- MAA
REQ_MAA = "req-maa-t16"
maa = {}
def maa_arith(k, reading, expr, label, prems=None, syms=None):
    p = PROBLEM("maa-"+k, k, REQ_MAA, syms or [], prems or [], CONCL("c", expr, label, G("arithmetic_fact","established")))
    return TR(p, reading)
MNULL = {
 "m2.3": "A polynomial identity in the variable x (f(x) = (x+3)(x^2+bx+c)); products of non-constant terms are outside IR 1.0.",
 "m2.4": "A polynomial identity in x (expansion); products of non-constant terms are outside IR 1.0.",
 "m2.7": "A polynomial identity in x (factorisation); not encodable without products of non-constant terms or quantification over x.",
 "m2.8": "A polynomial identity in x; not encodable (non-constant products).",
 "m3.1": "A derivative identity in x (f'(x) = 3(x-3)(x+1)); not encodable (non-constant products).",
 "m3.2": "A solution set (f'(x) = 0 exactly at x = 3 and x = -1) needs the statement that no other value satisfies it, which is quantification over x; not encodable.",
 "m3.6": "A label for the sign analysis; no claim.",
 "m3.7": "A sign claim for all x < -1; universal quantification over x, not in IR 1.0.",
 "m3.8": "A sign claim for all -1 < x < 3; universal quantification over x.",
 "m3.9": "A sign claim for all x > 3; universal quantification over x.",
 "m3.10": "The classification of the stationary points depends on the sign analysis (quantification over x); not encodable.",
 "m4.1": "The x-intercepts claim is a solution set; that no other x is an intercept needs quantification over x.",
 "m4.2": "Crossing versus touching depends on the sign change near each root (quantification over x).",
 "m5.1": "A claim for all x in [-3, 3]; universal quantification over x.",
 "m5.2": "A region argument over all x (sign of f below -3); quantification over x.",
 "m5.3": "A definite integral; IR 1.0 has no integrals.",
 "m5.8": "Restates the area from m5.6; no separate relation.",
 "m6.5": "The point-slope equation of the normal is a definition restated with its slope and point; with no premise beyond the claim itself there is no relation to check.",
 "m6.9": "Reads off the coefficients of the previous line; restates m6.7 without a relation.",
 "m6.10": "A general statement about all integer multiples of an equation (quantification over multiples).",
}
for k, v in MNULL.items():
    maa[k] = NULLTR(f"Not formalised: {v}", v)

maa["m2.1"] = maa_arith("m2.1", "f(-3) evaluated with the given cubic: -27 - 27 + 27 + 27 = 0.",
    EQ(ADD(RC(-27),RC(-27),RC(27),RC(27)),RC(0)), "f(-3) = 0")
maa["m2.2"] = TR(PROBLEM("maa-m2.2", "m2.2", REQ_MAA,
    [SYM("factor_x3","Bool","(x + 3) is a factor of f(x)",G("general_knowledge","established"))],
    [PREM("ev_f", EQ(ADD(RC(-27),RC(-27),RC(27),RC(27)),RC(0)), "f(-3) = 0", G("arithmetic_fact","established")),
     PREM("l_factor", IMP(EQ(ADD(RC(-27),RC(-27),RC(27),RC(27)),RC(0)), V("factor_x3")), "by the factor theorem, f(-3) = 0 makes (x + 3) a factor", G("general_knowledge","established"))],
    CONCL("c", V("factor_x3"), "(x + 3) is a factor of f(x)", G("general_knowledge","established"))),
    "Factor theorem step: f(-3) = 0 (arithmetic) and the theorem's implication, giving (x + 3) as a factor.")
maa["m2.5"] = TR(PROBLEM("maa-m2.5", "m2.5", REQ_MAA,
    [SYM("b","Int","coefficient b of x^2 in the quadratic factor",G("specialist_inference","established")),
     SYM("c","Int","constant c in the quadratic factor",G("specialist_inference","established"))],
    [PREM("p_b", EQ(ADD(V("b"),I(3)),I(-3)), "b + 3 = -3 (coefficient of x^2 in the expansion)", G("specialist_inference","established")),
     PREM("p_c", EQ(MUL(I(3),V("c")),I(27)), "3c = 27 (constant term)", G("specialist_inference","established"))],
    CONCL("c_bc", AND(EQ(V("b"),I(-6)),EQ(V("c"),I(9))), "b = -6 and c = 9", G("arithmetic_fact","established"))),
    "Coefficient matching: b + 3 = -3 and 3c = 27.")
maa["m2.6"] = TR(PROBLEM("maa-m2.6", "m2.6", REQ_MAA,
    [SYM("b","Int","coefficient b of the quadratic factor",G("specialist_inference","established")),
     SYM("c","Int","constant c of the quadratic factor",G("specialist_inference","established"))],
    [PREM("p_b", EQ(V("b"),I(-6)), "b = -6", G("specialist_inference","established")),
     PREM("p_c", EQ(V("c"),I(9)), "c = 9", G("specialist_inference","established"))],
    CONCL("c_chk", EQ(ADD(V("c"),MUL(I(3),V("b"))),I(-9)), "c + 3b = 9 - 18 = -9", G("arithmetic_fact","established"))),
    "Check of the x coefficient: c + 3b with b = -6 and c = 9 gives -9.")
maa["m3.3"] = maa_arith("m3.3", "f(-1) = -1 - 3 + 9 + 27.", EQ(ADD(RC(-1),RC(-3),RC(9),RC(27)),RC(32)), "f(-1) = 32")
maa["m3.4"] = maa_arith("m3.4", "f(3) = 27 - 27 - 27 + 27.", EQ(ADD(RC(27),RC(-27),RC(-27),RC(27)),RC(0)), "f(3) = 0")
maa["m3.5"] = maa_arith("m3.5", "Both points: f values and f' = 0 at x = -1 and x = 3 (f'(x) = 3x^2 - 6x - 9). Claimed as stationary points; no claim of exhaustiveness is encoded.",
    AND(EQ(ADD(RC(-1),RC(-3),RC(9),RC(27)),RC(32)), EQ(ADD(RC(27),RC(-27),RC(-27),RC(27)),RC(0)),
        EQ(ADD(RC(3),RC(6),RC(-9)),RC(0)), EQ(ADD(RC(27),RC(-18),RC(-9)),RC(0))),
    "Stationary points (-1, 32) and (3, 0)")
maa["m3.11"] = maa_arith("m3.11", "Second derivative 6x - 6 at x = -1 and x = 3: -12 (negative) and 12 (positive).",
    AND(EQ(ADD(MUL(RC(6),RC(-1)),RC(-6)),RC(-12)), EQ(ADD(MUL(RC(6),RC(3)),RC(-6)),RC(12)),
        LT(RC(-12),RC(0)), GT(RC(12),RC(0))),
    "f''(-1) = -12 < 0 and f''(3) = 12 > 0")
maa["m5.4"] = maa_arith("m5.4", "Antiderivative F(x) = x^4/4 - x^3 - (9/2)x^2 + 27x at x = 3.",
    EQ(ADD(RC("81/4"),RC(-27),RC("-81/2"),RC(81)),RC("135/4")), "F(3) = 81/4 - 27 - 81/2 + 81 = 135/4")
maa["m5.5"] = maa_arith("m5.5", "Antiderivative at x = -3.",
    EQ(ADD(RC("81/4"),RC(27),RC("-81/2"),RC(-81)),RC("-297/4")), "F(-3) = 81/4 + 27 - 81/2 - 81 = -297/4")
maa["m5.6"] = maa_arith("m5.6", "Constant arithmetic of F(3) - F(-3) = 108. The integral identity and the sign argument that makes this the enclosed area are not encoded.",
    EQ(SUB(RC("135/4"),RC("-297/4")),RC(108)), "Area = 135/4 - (-297/4) = 108")
maa["m5.7"] = maa_arith("m5.7", "Substitution check at u = 6: 6^4/4 = 324; 4 x 6^3 = 864; 18 x 6^2 = 648; total 108.",
    AND(EQ(DIV(RC(1296),RC(4)),RC(324)), EQ(ADD(RC(324),RC(-864),RC(648)),RC(108))),
    "[u^4/4 - 4u^3 + 18u^2] from 0 to 6 = 324 - 864 + 648 = 108")
maa["m6.1"] = maa_arith("m6.1", "f(1) = (1+3)(1-3)^2 = 16.", EQ(MUL(RC(4),RC(-2),RC(-2)),RC(16)), "f(1) = 16, so the point is (1, 16)")
maa["m6.2"] = maa_arith("m6.2", "Expanded form at x = 1.", EQ(ADD(RC(1),RC(-3),RC(-9),RC(27)),RC(16)), "1 - 3 - 9 + 27 = 16")
maa["m6.3"] = maa_arith("m6.3", "f'(1) = 3 - 6 - 9.", EQ(ADD(RC(3),RC(-6),RC(-9)),RC(-12)), "f'(1) = -12")
maa["m6.4"] = maa_arith("m6.4", "Gradient of the normal: -1 / (-12) = 1/12.", EQ(DIV(RC(-1),RC(-12)),RC("1/12")), "gradient of the normal = -1/f'(1) = 1/12")
maa["m6.6"] = TR(PROBLEM("maa-m6.6", "m6.6", REQ_MAA,
    [SYM("x","Real","x-coordinate of a point on the normal",G("specialist_inference","established")),
     SYM("y","Real","y-coordinate of a point on the normal",G("specialist_inference","established"))],
    [PREM("p_line", EQ(SUB(V("y"),RC(16)), MUL(RC("1/12"),SUB(V("x"),RC(1)))), "y - 16 = (1/12)(x - 1)", G("specialist_inference","established"))],
    CONCL("c_line", EQ(SUB(MUL(RC(12),V("y")),RC(192)), SUB(V("x"),RC(1))), "12y - 192 = x - 1", G("arithmetic_fact","established"))),
    "Clearing fractions from the normal line y - 16 = (1/12)(x - 1).")
maa["m6.7"] = TR(PROBLEM("maa-m6.7", "m6.7", REQ_MAA,
    [SYM("x","Real","x-coordinate of a point on the normal",G("specialist_inference","established")),
     SYM("y","Real","y-coordinate of a point on the normal",G("specialist_inference","established"))],
    [PREM("p_line2", EQ(SUB(MUL(RC(12),V("y")),RC(192)), SUB(V("x"),RC(1))), "12y - 192 = x - 1", G("specialist_inference","established"))],
    CONCL("c_gen", EQ(ADD(V("x"),MUL(RC(-12),V("y")),RC(191)),RC(0)), "x - 12y + 191 = 0", G("arithmetic_fact","established"))),
    "Rearranged to the form ax + by + d = 0 with a = 1, b = -12, d = 191.")
maa["m6.8"] = maa_arith("m6.8", "Substitution of (1, 16) into x - 12y + 191: 1 - 192 + 191 = 0.",
    EQ(ADD(RC(1),MUL(RC(-12),RC(16)),RC(191)),RC(0)), "1 - 12(16) + 191 = 0, so (1, 16) lies on the line")

# ---------------- assemble
def build(task, req, claims_dict, expected_ids):
    assert set(claims_dict) == set(expected_ids), (task, set(expected_ids) ^ set(claims_dict))
    return {"report_id": f"rep-{task}-0", "claims": claims_dict}

ll_ids = ll_claims
ps_ids = [ps_(k) for k in ["g2.3","g2.4","g2.6","g3.2","g3.3","g3.4","g3.5","g3.6","g3.7","g4.2","g6.1","g7.1","g8.1"]]
ph_ids = list(ph.keys())
maa_ids = list(maa.keys())
print("ps", len(ps_ids), "ph", len(ph_ids), "maa", len(maa_ids))

res = {"ll-t16": build("ll-t16", "req-ll-t16", ll, ll_ids),
       "ps-t16": build("ps-t16", REQ_PS, ps, ps_ids),
       "ph-t16": build("ph-t16", REQ_PH, ph, ph_ids),
       "maa-t16": build("maa-t16", REQ_MAA, maa, maa_ids)}
for t, obj in res.items():
    with open(f"{BASE}/translations/{t}.json", "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2); f.write("\n")
print("written")
