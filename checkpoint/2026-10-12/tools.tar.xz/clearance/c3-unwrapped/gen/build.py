import json, os, sys

C = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c3"
OUT = C + "/syntheses"

R_SOURCES = "a sources line, a note rather than a claim of the answer"
R_NEXT = "a next-step suggestion, a note rather than a claim of the answer"
R_HEAD = "a heading or label with no claim of its own"
R_QUEST = "a question or practice prompt to the student, a note rather than a claim of the answer"
R_REMARK = "a remark about the answer's presentation or use, a note rather than a claim of the answer"
R_OTHER = "marked as a note (role other) in the source, so not cited as a claim"
R_PROC = "a remark about how the answer was produced, a note rather than a claim of the answer"
R_OFFER = "an offer of help, a note rather than a claim of the answer"
R_WORDCOUNT = "a word count remark, a note rather than a claim of the answer"

DROP = {
 "bi-t16": {"s6.1": R_SOURCES},
 "hi-t16": {"h3.1": R_NEXT, "h4.1": R_SOURCES},
 "hi-p10b": {"h3.1": R_SOURCES},
 "ch-p10c": {"s1.1": R_HEAD, "s1.3": R_REMARK, "s4.1": R_HEAD, "s4.8": R_HEAD, "s7.1": R_NEXT},
 "ch-t16": {"s1.1": R_HEAD, "s8.2": R_REMARK, "s9.1": R_NEXT},
 "en-t16": {"p6-point": R_SOURCES},
 "ge-t16": {"g8.1": R_NEXT, "g9.1": R_SOURCES},
 "lit-t16": {"p2-point": R_NEXT, "p3-point": R_SOURCES},
 "ll-t16": {"p1-s02": R_OFFER, "p4-s02": R_QUEST, "p4-s04": R_QUEST, "p4-s06": R_QUEST, "p4-s07": R_QUEST, "p5-s01": R_HEAD, "p8-point": R_SOURCES},
 "cs-t16": {"c1.1": R_PROC, "c2.1": R_HEAD, "c3.1": R_HEAD, "c5.1": R_HEAD, "c7.1": R_HEAD, "c10.1": R_HEAD, "c14.1": R_NEXT, "c15.1": R_SOURCES},
 "cs-p10a": {"c1.1": R_PROC, "c2.1": R_HEAD, "c3.1": R_HEAD, "c10.3": R_OTHER, "c13.1": R_NEXT, "c14.1": R_SOURCES},
 "maa-t16": {"m1.1": R_OTHER, "m8.1": R_NEXT, "m9.1": R_SOURCES},
 "mai-t16": {"m15.1": R_HEAD, "m29.1": R_SOURCES},
 "ess-t16": {"s1.1": R_REMARK, "s4.1": R_HEAD, "s13.1": R_SOURCES, "s14.1": R_NEXT},
 "ps-t16": {"g1.1": R_REMARK, "g2.1": R_HEAD, "g3.1": R_HEAD, "g5.1": R_HEAD, "g9.1": R_NEXT, "g10.1": R_SOURCES},
 "sp-t16": {"g1.1": R_HEAD, "g1.3": R_WORDCOUNT, "g1.12": R_HEAD, "g1.16": R_HEAD, "g1.29": R_NEXT, "g1.30": R_SOURCES},
 "sp-p10d": {"g1.1": R_HEAD, "g3.1": R_SOURCES},
 "bm-t16": {"g3.1": R_HEAD, "g4.1": R_HEAD, "g17.1": R_SOURCES},
 "ec-t16": {"g1.1": R_REMARK, "g2.1": R_HEAD, "g3.1": R_HEAD, "g4.1": R_HEAD, "g5.1": R_HEAD, "g8.1": R_HEAD, "g8.2": R_OTHER, "g10.1": R_HEAD, "g13.1": R_SOURCES},
 "ph-t16": {"s1.1": R_HEAD, "s2.1": R_HEAD, "s3.1": R_HEAD, "s4.1": R_HEAD, "s6.1": R_HEAD, "s7.1": R_QUEST, "s7.2": R_QUEST, "s7.3": R_QUEST, "s7.4": R_QUEST, "s7.5": R_QUEST, "s8.1": R_SOURCES},
}

# verification labels stripped; the claim is kept as narrowed
NARROW = {
 "ch-t16": {"s2.2": "C 2 = 2; H 5 = 5; O 3 = 3; Na 1 = 1."},
 "ch-p10c": {"s2.2": "C 24 = 24; H 52 = 52; O 74 = 48 + 26.", "s5.2": "C 24 = 24; H 52 = 52; O 50 = 24 + 26."},
 "cs-p10a": {"c1.3": "132 + 18 + 12 + 438 = 600."},
 "maa-t16": {
   "m2.6": "c + 3b = 9 − 18 = −9, which matches the coefficient of x.",
   "m3.11": "f″(x) = 6x − 6, so f″(−1) = −12 < 0 (maximum) and f″(3) = 12 > 0 (minimum), which agrees.",
   "m5.7": "Substituting u = x + 3 gives the integral of u(u − 6)² from 0 to 6, which is [u⁴/4 − 4u³ + 18u²] from 0 to 6 = 324 − 864 + 648 = 108.",
   "m6.2": "From the expanded form: 1 − 3 − 9 + 27 = 16.",
   "m6.8": "1 − 12(16) + 191 = 1 − 192 + 191 = 0, so (1, 16) lies on the line."},
 "mai-t16": {
   "m1.2": "I have assumed that the current cans also hold 330 cm³.",
   "m21.1": "At the stationary point $\\dfrac{1320}{r^3} = 8\\pi$, so $\\dfrac{d^2A}{dr^2} = 12\\pi \\approx 37.7 > 0$."},
 "ph-t16": {
   "s1.10": "Model: n = PV/RT = (3.0 × 10⁵ × 2.4 × 10⁻³)/(8.31 × 290) = 720/2410 = 0.30 mol",
   "s2.11": "Model: T1 = 290 K; T2 = 308 K. P2 = P1 × T2/T1 = 3.0 × 10⁵ × 308/290 = 3.2 × 10⁵ Pa",
   "s3.10": "Model: E_k = (3/2)k_BT = 1.5 × 1.38 × 10⁻²³ × 308 = 6.4 × 10⁻²¹ J",
   "s4.13": "Model: A higher temperature means faster molecules, so their mean kinetic energy rises.",
   "s4.14": "Each molecule that hits a wall undergoes a larger change of momentum, and collisions with the walls happen more often.",
   "s4.15": "The force on the wall is the rate of change of momentum, so with the area fixed, the pressure rises"},
 "sp-p10d": {"g2.17": "\"merito\" is a diminutive-style form of \"mero\"."},
}

# other-role claims that are a decline or deferral: carried under rule 7
OTHER_CARRY = {"bm-t16": {"g16.2"}}

def main(tasks):
    for t in tasks:
        d = json.load(open(f"{C}/claims/{t}.compact.json"))
        src = {c["claim_id"]: c for c in d["claims"]}
        base = {}
        for cid in src:
            b = cid.split("@")[0]
            assert b not in base, (t, "duplicate base id", b)
            base[b] = cid
        def resolve(m):
            return {base[k]: v for k, v in m.items()}
        drop = resolve(DROP.get(t, {}))
        narrow = resolve(NARROW.get(t, {}))
        allow_other = {base[k] for k in OTHER_CARRY.get(t, set())}
        for cid in list(drop) + list(narrow):
            assert cid in src, (t, cid, "unknown id")
        claims, dropped = [], []
        for cid, c in src.items():  # listing order
            if cid in drop:
                dropped.append({"source_claim_ids": [cid], "reason": drop[cid]})
                continue
            if c["role"] == "other" and cid not in allow_other:
                raise SystemExit(f"{t}: other-role claim {cid} not dropped")
            if cid in narrow:
                claims.append({"text": narrow[cid], "source_claim_ids": [cid], "certainty": c["certainty"], "transformation": "narrowed"})
            else:
                claims.append({"text": c["text"], "source_claim_ids": [cid], "certainty": c["certainty"], "transformation": "carried"})
        # coverage: every source claim is cited once or dropped once
        cited = [i for x in claims for i in x["source_claim_ids"]]
        dropped_ids = [i for x in dropped for i in x["source_claim_ids"]]
        assert sorted(cited + dropped_ids) == sorted(src), (t, "coverage")
        assert len(set(cited)) == len(cited)
        for x in claims:
            assert x["text"].strip() and len(x["text"]) <= 4000
        out = {"claims": claims, "dropped": dropped}
        with open(f"{OUT}/{t}.json", "w", encoding="utf-8") as fh:
            json.dump(out, fh, ensure_ascii=False, indent=2)
        print(t, "claims", len(claims), "dropped", len(dropped), "narrowed", sum(1 for x in claims if x["transformation"] == "narrowed"))

if __name__ == "__main__":
    main(sys.argv[1:])
