import json
import os

SRC = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c1/tasks.json"
OUT_DIR = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c1/specialists"

RESPONSES = {
    "ph-t14": """
I have assumed HL, because the question uses orbital speed, escape speed and orbital energy, which are additional HL content. The orbit radius is the planet's radius plus the height, and the orbit is circular.

Givens, in SI:
M = 6.4 × 10²³ kg
R = 3400 km = 3.400 × 10⁶ m
h = 1600 km = 1.600 × 10⁶ m
r = R + h = 3.400 × 10⁶ m + 1.600 × 10⁶ m = 5.000 × 10⁶ m
G = 6.67 × 10⁻¹¹ N m² kg⁻² (from the question)
π = 3.14159 (standard value)

(a) [2]
g = GM/R²
g = (6.67 × 10⁻¹¹ N m² kg⁻²)(6.4 × 10²³ kg)/(3.400 × 10⁶ m)²
g = (4.2688 × 10¹³ N m² kg⁻¹)/(1.156 × 10¹³ m²) = 3.693 N kg⁻¹
g = 3.7 N kg⁻¹ (2 s.f., matching M), directed towards the centre of the planet.

(b) [3]
Gravity provides the centripetal force: GMm/r² = mv²/r, so v² = GM/r.
Speed in one orbit: v = 2πr/T, so v² = 4π²r²/T².
Substituting: 4π²r²/T² = GM/r, so T² = 4π²r³/(GM).
r³ = (5.000 × 10⁶ m)³ = 1.250 × 10²⁰ m³
T² = (4π² = 39.48)(1.250 × 10²⁰ m³)/(4.2688 × 10¹³ N m² kg⁻¹) = 1.156 × 10⁸ s²
T = √(1.156 × 10⁸ s²) = 1.075 × 10⁴ s
T = (1.075 × 10⁴ s)/(3600 s h⁻¹) = 2.99 h, which agrees with about 3 hours.

(c) [2]
Gravity provides the centripetal force: GMm/r² = mv²/r, so v = √(GM/r).
v = √((4.2688 × 10¹³ N m² kg⁻¹)/(5.000 × 10⁶ m)) = √(8.538 × 10⁶ m² s⁻²) = 2.92 × 10³ m s⁻¹
v = 2.9 × 10³ m s⁻¹ (2 s.f.)

(d) [2]
Escape is possible when the total energy at the surface is zero: ½mv² − GMm/R = 0, so v = √(2GM/R).
v = √((2 × 4.2688 × 10¹³ N m² kg⁻¹)/(3.400 × 10⁶ m)) = √(2.511 × 10⁷ m² s⁻²) = 5.01 × 10³ m s⁻¹
v = 5.0 × 10³ m s⁻¹ (2 s.f.)

(e) [3]
Drag acts opposite to the velocity, so it does negative work on the satellite and lowers its total energy.
For a circular orbit the total energy is E = E_k + E_p = GMm/(2r) − GMm/r = −GMm/(2r). Treating the orbit as circular at each stage, because drag acts for only a short time, a fall in E makes it more negative, so r decreases and the satellite moves to a lower orbit.
In the lower orbit the kinetic energy GMm/(2r) increases, so the speed v = √(GM/r) increases. The fall in gravitational potential energy is twice the gain in kinetic energy, and drag transfers the remaining energy to internal energy, so the speed rises even though drag opposes the motion.

Next step: check your answer to (c) against 2πr/T from (b), which should also give about 2.9 × 10³ m s⁻¹.

Sources: your question (supplied text); course notes on gravitational fields and orbits (course notes)
""",
    "ph-p8b": """
I take k = 50 N m⁻¹ as the restoring constant of the whole system, as the question gives it, and the trolley as released from rest, so its amplitude is 4.0 cm.

Givens, in SI:
m = 0.50 kg
k = 50 N m⁻¹
A = 4.0 cm = 4.0 × 10⁻² m
π = 3.14159 (standard value)

(a) [2]
The resultant force is −kx, so ma = −kx, which gives a = −(k/m)x = −ω²x.
ω = √(k/m) = √((50 N m⁻¹)/(0.50 kg)) = √(100 s⁻²) = 10.0 rad s⁻¹
This agrees with the value of 10 rad s⁻¹ in the question.

(b) [1]
T = 2π/ω = 2π/(10.0 rad s⁻¹) = 0.628 s
T = 0.63 s (2 s.f.)

(c) [2]
The speed is greatest at equilibrium, where the displacement is zero, so v_max = ωA.
v_max = (10.0 rad s⁻¹)(4.0 × 10⁻² m) = 0.400 m s⁻¹
v_max = 0.40 m s⁻¹ (2 s.f.)

(d) [2]
Energy is conserved. At maximum displacement the speed is zero, so the total energy is elastic potential energy: E = ½kA².
E = ½(50 N m⁻¹)(4.0 × 10⁻² m)² = ½(50)(1.6 × 10⁻³) J = 4.0 × 10⁻² J
Check: ½mv_max² = ½(0.50)(0.40)² = 4.0 × 10⁻² J, the same value.
E = 4.0 × 10⁻² J (2 s.f.)

(e) [2]
Energy conservation gives ½mv² + ½kx² = ½kA², so v = √((k/m)(A² − x²)) = ω√(A² − x²).
With x = 2.0 cm = 2.0 × 10⁻² m:
v = (10.0 rad s⁻¹)√((4.0 × 10⁻² m)² − (2.0 × 10⁻² m)²) = (10.0 rad s⁻¹)√(1.2 × 10⁻³ m²) = 0.346 m s⁻¹
v = 0.35 m s⁻¹ (2 s.f.)
Check: ½mv² = E − ½kx² = 4.0 × 10⁻² J − 1.0 × 10⁻² J = 3.0 × 10⁻² J, so v² = 2(3.0 × 10⁻² J)/(0.50 kg) = 0.12 m² s⁻², giving v = 0.35 m s⁻¹.

(f) [2]
T = 2π√(m/k), so T is proportional to √m, and k is unchanged.
T′ = 2π√(2m/k) = √2 × T = 1.414 × 0.628 s = 0.889 s, so T′ = 0.89 s (2 s.f.)
The period increases by a factor of √2, about 41%, from 0.63 s to 0.89 s. The spring still gives the same restoring force for a given displacement, but the larger mass accelerates less for that displacement, a = −(k/m)x, so ω = √(k/m) falls and the period T = 2π/ω increases.

For the modelling: x = A cos(ωt) with A = 4.0 cm (0.040 m) and ω = 10.0 rad s⁻¹, since the trolley starts at maximum displacement. T = 0.63 s; v_max = 0.40 m s⁻¹ (40 cm s⁻¹).

Sources: your question (supplied text); course notes on simple harmonic motion (course notes)
""",
}

with open(SRC, encoding="utf-8") as f:
    tasks = json.load(f)

os.makedirs(OUT_DIR, exist_ok=True)
for task in tasks:
    tid = task.get("task_id")
    if tid in RESPONSES:
        rec = dict(task)
        rec["response_text"] = RESPONSES[tid].strip()
        path = os.path.join(OUT_DIR, tid + ".json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(rec, f, ensure_ascii=False, indent=2)
            f.write("\n")
        print(path)
