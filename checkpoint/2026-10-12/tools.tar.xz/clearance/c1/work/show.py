import json, sys
for tid in sys.argv[1:]:
    d = json.load(open("/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c1/work/claims/%s.json" % tid))
    print("=== %s | report=%s | group=%s | order=%s | n=%d" % (tid, d["report_id"], d["group"], d["group_order"], len(d["claims"])))
    for c in d["claims"]:
        print("%s | %s | %s | %s | %s" % (c["claim_id"], c["role"], c["materiality"], c["certainty"], c["text"]))
