import json, os, re, sys
BASE = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c1"
W = BASE + "/work"
CERT = {"established": 3, "probable": 2, "possible": 1}
BAD_CTRL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]")
BIDI = re.compile(r"[‪-‮⁦-⁩]")
LABEL = re.compile(r"(verified|checked|\bproved\b|proven|\bcheck[:,]|\[ok\]|✓)", re.I)

def visible(s):
    return any(not ch.isspace() for ch in s)

def group_all(g):
    doc = json.load(open("%s/claims/GROUP-%s.json" % (W, g)))
    return {c["claim_id"]: c for s in doc["sources"] for c in s["claims"]}

def build(tid):
    src = json.load(open("%s/claims/%s.json" % (W, tid)))
    dec_path = "%s/dec/%s.json" % (W, tid)
    if not os.path.exists(dec_path):
        print("NO DEC", tid)
        return None
    dec = json.load(open(dec_path))
    own = src["claims"]
    by_id = {c["claim_id"]: c for c in own}
    order = [c["claim_id"] for c in own]
    gall = group_all(src["group"]) if src["group"] else None
    drop_reason = {}
    for d in dec.get("drop", []):
        for i in d["ids"]:
            assert i in by_id, (tid, "drop id not in own claims", i)
            assert i not in drop_reason, (tid, "duplicate drop", i)
            drop_reason[i] = d["reason"]
    for c in own:
        if c["role"] == "other" and c["claim_id"] not in drop_reason:
            drop_reason[c["claim_id"]] = "a note marked as role other, which is never cited in claims"
            print("AUTO-DROP role other:", tid, c["claim_id"])
    narrow = dec.get("narrow", {})
    claims_out = []
    for c in own:
        i = c["claim_id"]
        if i in drop_reason:
            assert i not in narrow, (tid, "narrowed and dropped", i)
            continue
        if i in narrow:
            old, new = narrow[i]
            assert c["text"].startswith(old), (tid, i, "prefix mismatch", c["text"][:60])
            text = new + c["text"][len(old):]
            trans = "narrowed"
        else:
            text = c["text"]
            trans = "carried"
        claims_out.append({"text": text, "source_claim_ids": [i], "certainty": c["certainty"], "transformation": trans})
    cited = [c["source_claim_ids"][0] for c in claims_out]
    assert len(cited) == len(set(cited))
    dropped_ids = [i for i in order if i in drop_reason]
    assert set(cited).isdisjoint(dropped_ids)
    assert set(cited) | set(dropped_ids) == set(order), (tid, "coverage", set(order) - set(cited) - set(dropped_ids))
    reasons = {}
    for i in dropped_ids:
        reasons.setdefault(drop_reason[i], []).append(i)
    dropped = [{"source_claim_ids": ids, "reason": r} for r, ids in reasons.items()]
    conflicts = []
    for k in dec.get("conflicts", []):
        ids = k["claim_ids"]
        assert len(ids) >= 2 and len(set(ids)) == len(ids), (tid, "conflict ids", ids)
        for i in ids:
            if gall is not None:
                assert i in gall, (tid, "conflict id not in group input", i)
            else:
                assert i in by_id, (tid, "conflict id not in input", i)
            if i in by_id:
                assert i not in drop_reason, (tid, "conflict claim dropped", i)
        conflicts.append({"claim_ids": ids, "description": k["description"]})
    for c in claims_out:
        t = c["text"]
        assert visible(t) and len(t) <= 4000, (tid, "text", c["source_claim_ids"])
        assert not BAD_CTRL.search(t) and not BIDI.search(t), (tid, "control", c["source_claim_ids"])
        assert c["transformation"] in {"carried", "paraphrased", "merged", "narrowed", "generalized"}
        assert c["certainty"] in CERT
        if LABEL.search(t):
            print("LABEL CHECK:", tid, c["source_claim_ids"], t[:110])
    out = {"claims": claims_out, "dropped": dropped}
    if conflicts:
        out["conflicts"] = conflicts
    with open("%s/syntheses/%s.json" % (BASE, tid), "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)
        fh.write("\n")
    print("WROTE", tid, "claims=%d dropped=%d conflicts=%d" % (len(claims_out), sum(len(d["source_claim_ids"]) for d in dropped), len(conflicts)))
    return out

if __name__ == "__main__":
    for tid in sys.argv[1:]:
        build(tid)
