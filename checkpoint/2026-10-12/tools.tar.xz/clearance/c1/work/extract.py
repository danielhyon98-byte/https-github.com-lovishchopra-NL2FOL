import glob, json, os, subprocess, sys

PY = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/z3venv/bin/python"
LC = "/home/user/https-github.com-lovishchopra-NL2FOL/scripts/arena/list_claims.py"
BASE = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c1"
INS = BASE + "/combinator-instructions"
SPEC = BASE + "/specialists"
OUT = BASE + "/work/claims"
os.makedirs(OUT, exist_ok=True)

def run(args):
    p = subprocess.run([PY, "-I", LC] + args, capture_output=True, text=True, cwd="/tmp")
    if p.returncode != 0:
        sys.exit("list_claims failed: %s\n%s" % (args, p.stderr))
    return json.loads(p.stdout)

specs = {}
for f in sorted(glob.glob(SPEC + "/*.json")):
    d = json.load(open(f))
    specs[d["task_id"]] = (f, d)

# group members: report_id per task from the single-file JSON view (metadata only)
groups = {}
for tid, (f, d) in specs.items():
    if d.get("group"):
        groups.setdefault(d["group"], []).append(tid)

summary = {}
for g, tids in sorted(groups.items()):
    tids = sorted(tids, key=lambda t: 0 if not specs[t][1].get("peer_of") else 1)
    files = [specs[t][0] for t in tids]
    doc = run(["--agent-view"] + files + ["--instructions", INS])
    json.dump(doc, open(OUT + "/GROUP-%s.json" % g, "w"), indent=1, ensure_ascii=False)
    single = {}
    for t in tids:
        m = run([specs[t][0], "--json", "--instructions", INS])
        single[t] = m["report_id"]
    for src in doc["sources"]:
        tid = [t for t in tids if single[t] == src["report_id"]][0]
        out = {"task_id": tid, "group": g, "report_id": src["report_id"],
               "agent_id": src["agent_id"], "subject": src["subject"], "branch": src["branch"],
               "claims": src["claims"], "view": "group-agent-view",
               "group_order": tids}
        json.dump(out, open(OUT + "/%s.json" % tid, "w"), indent=1, ensure_ascii=False)
        summary[tid] = len(src["claims"])

for tid, (f, d) in sorted(specs.items()):
    if d.get("group"):
        continue
    m = run([f, "--json", "--instructions", INS])
    out = {"task_id": tid, "group": None, "report_id": m["report_id"],
           "agent_id": d.get("agent_id"), "subject": d.get("subject"), "branch": m.get("branch"),
           "claims": m["claims"], "view": "single-json", "group_order": []}
    json.dump(out, open(OUT + "/%s.json" % tid, "w"), indent=1, ensure_ascii=False)
    summary[tid] = len(m["claims"])

print(json.dumps(dict(sorted(summary.items())), indent=0))
print("total claims:", sum(summary.values()))
