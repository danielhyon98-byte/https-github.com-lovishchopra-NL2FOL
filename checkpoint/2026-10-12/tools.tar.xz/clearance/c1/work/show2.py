import json, re, sys
FLAG = re.compile(r"(?i)(verified|checked|\bcheck\b|proved|proven|✓|\[ok\]|\bnote\b|\?|\bI\b|\bI'|\bmy\b|\bme\b|\byou\b|\bwould you\b|\bwant\b|\bcannot\b|can't|\bdecline|word count|\bwords\b|\bapprove|\breply\b|\bsources?\b|next step|question|sorry|unable|\bmark tags?\b|provisional|illustrative)")
for tid in sys.argv[1:]:
    d = json.load(open("/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c1/work/claims/%s.json" % tid))
    print("=== %s | n=%d" % (tid, len(d["claims"])))
    for c in d["claims"]:
        t = c["text"].replace("\n", " / ")
        if len(t) > 230:
            t = t[:170] + " ... " + t[-55:]
        star = "*" if (c["role"] == "other" or FLAG.search(c["text"])) else " "
        print("%s%s|%s|%s|%s|%s" % (star, c["claim_id"], c["role"][:5], c["materiality"][:4], c["certainty"][:4], t))
