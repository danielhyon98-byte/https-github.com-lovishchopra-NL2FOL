import json, glob, os, re
BASE = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c1"
W = BASE + "/work"
TRANS = {"carried", "paraphrased", "merged", "narrowed", "generalized"}
CERT = {"established", "probable", "possible"}
RANK = {"established": 3, "probable": 2, "possible": 1}
BAD = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f‪-‮⁦-⁩]")
specs = {}
for f in glob.glob(BASE + "/specialists/*.json"):
    d = json.load(open(f)); specs[d["task_id"]] = d
assert len(specs) == 24, len(specs)
outs = sorted(glob.glob(BASE + "/syntheses/*.json"))
names = sorted(os.path.basename(p)[:-5] for p in outs)
assert names == sorted(specs), (set(specs) ^ set(names))
total = 0
for tid in names:
    o = json.load(open(BASE + "/syntheses/%s.json" % tid))
    assert set(o) <= {"claims", "dropped", "conflicts"} and "claims" in o and "dropped" in o, (tid, o.keys())
    own = json.load(open(W + "/claims/%s.json" % tid))
    allc = {c["claim_id"]: c for c in own["claims"]}
    if own["group"]:
        g = json.load(open(W + "/claims/GROUP-%s.json" % own["group"]))
        allc = {c["claim_id"]: c for s in g["sources"] for c in s["claims"]}
    own_ids = {c["claim_id"] for c in own["claims"]}
    cited, seen = [], set()
    assert 1 <= len(o["claims"]) <= 512
    for c in o["claims"]:
        assert set(c) == {"text", "source_claim_ids", "certainty", "transformation"}, (tid, c.keys())
        t = c["text"]
        assert t.strip() and len(t) <= 4000 and not BAD.search(t), (tid, t[:60])
        assert c["transformation"] in TRANS and c["certainty"] in CERT
        ids = c["source_claim_ids"]
        assert 1 <= len(ids) <= 64 and len(set(ids)) == len(ids)
        for i in ids:
            assert i in own_ids, (tid, "cites id outside own report", i)
            assert allc[i]["role"] != "other", (tid, "cites role other", i)
            assert RANK[c["certainty"]] <= min(RANK[allc[i]["certainty"]] for i in ids), (tid, "certainty too strong", i)
            assert i not in seen, (tid, "cited twice", i)
            seen.add(i)
        if c["transformation"] == "carried":
            assert len(ids) == 1 and t == allc[ids[0]]["text"], (tid, "carried text differs", ids)
        assert not re.search(r"(?i)\b(verified|checked|proved|proven)\b|✓|\[ok\]|\bcheck:", t), (tid, "label left", t[:80])
    dropped = set()
    for d in o["dropped"]:
        assert set(d) == {"source_claim_ids", "reason"} and d["reason"].strip()
        for i in d["source_claim_ids"]:
            assert i in own_ids and i not in dropped and i not in seen, (tid, "drop problem", i)
            dropped.add(i)
    assert seen | dropped == own_ids, (tid, "coverage", own_ids - (seen | dropped))
    for k in o.get("conflicts", []):
        assert len(set(k["claim_ids"])) >= 2 and all(i in allc for i in k["claim_ids"]) and k["description"].strip()
        for i in k["claim_ids"]:
            assert i in allc
    total += len(o["claims"])
    print("OK %-10s claims=%3d dropped=%3d conflicts=%d" % (tid, len(o["claims"]), len(dropped), len(o.get("conflicts", []))))
print("ALL VALID; total synthesized claims:", total)
