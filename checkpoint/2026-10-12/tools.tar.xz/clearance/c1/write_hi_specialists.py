import json, os, re

base = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c1"
src = os.path.join(base, "tasks.json")
outdir = os.path.join(base, "specialists")
os.makedirs(outdir, exist_ok=True)

SOURCES = "Sources: none consulted (no retrieval in this session)"

responses = {
    "hi-t14": (
        "The Korean War was limited in its aims, scope and means, but not in its human cost. "
        "A limited war, as the term is used here, is one whose objectives, geographic scope and weapons are restrained rather than aimed at the total defeat of the enemy state. "
        "The limits were not there at the start. In early October 1950, after the Inchon landing of 15 September, United Nations forces crossed the 38th parallel to unify the peninsula; "
        "the Chinese intervention of late October 1950 ended that prospect and pushed Washington towards more restrained aims. "
        "The clearest evidence of restraint is Truman's handling of General Douglas MacArthur. "
        "MacArthur proposed bombing Chinese bases in Manchuria and extending the war beyond Korea, and Washington rejected both proposals. "
        "When he challenged the policy in public, Truman relieved him of command on 11 April 1951. "
        "This decision suggests that Washington preferred a divided peninsula to a wider war with China. "
        "The diplomacy confirms the pattern. Armistice talks opened at Kaesong on 10 July 1951, and the armistice was signed at Panmunjom on 27 July 1953, two years and seventeen days later. "
        "Neither Syngman Rhee's government nor the North Korean leadership achieved reunification, and the armistice line lay near the 38th parallel where the war had begun on 25 June 1950. "
        "A war of three years and one month therefore ended with the original aims of both sides abandoned, which is the mark of limited objectives. "
        "The judgement is qualified: the war was limited to a considerable extent in aims, scope and means, but its limits were political rather than humanitarian, "
        "because the fighting moved back and forth across the whole peninsula for three years.\n\n"
        "Casualty and cost figures are left out, because I cannot confirm exact numbers here; take them from your textbook and cite them.\n\n"
        + SOURCES
    ),
    "hi-p8c": (
        "Rosa Parks, a member of the Montgomery branch of the National Association for the Advancement of Colored People (NAACP), was arrested on 1 December 1955 "
        "for refusing to give up her bus seat to a white passenger. "
        "The Women's Political Council, led by Jo Ann Robinson, circulated leaflets calling for a boycott, which began on 5 December 1955, the day of Parks's trial. "
        "That evening, Black leaders formed the Montgomery Improvement Association (MIA) and chose the Baptist minister Martin Luther King Jr. as its president. "
        "Carpool networks, volunteer drivers and mass meetings sustained the boycott for 381 days, until 20 December 1956. "
        "The end came after the Supreme Court had upheld, in November 1956, a federal ruling against segregated buses, and the order reached Montgomery. "
        "The boycott suggests that everyday, collective refusal, organised locally, could build the pressure that led to legal change.\n\n"
        + SOURCES
    ),
}

with open(src, encoding="utf-8") as f:
    tasks = json.load(f)
by_id = {t["task_id"]: t for t in tasks}

for tid in ["hi-t14", "hi-p8c"]:
    task = dict(by_id[tid])
    task["response_text"] = responses[tid]
    path = os.path.join(outdir, tid + ".json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(task, f, ensure_ascii=False, indent=2)
        f.write("\n")
    para = responses[tid].split("\n\n")[0]
    words = len(re.findall(r"\S+", para))
    print(path, "paragraph_words=", words, "url_hits=", len(re.findall(r"http|www\.|\.com|\.org", responses[tid])))
