# Overseer agents, fast profile: measured result and round-8 recommendation

Measured figures only. The revision-2 timings are labelled as arithmetic estimates. Paths are relative to the overseer-flash folder. Re-checked for this report: every digest in profile.json matches its file; compact/check_report.json says ok: true; run_tests.sh gives 37 passed.

## 0. In brief
- **Speed (measured, pilot p1).** Standard arm A: 4 instances of about 10 dossiers each. Fast arm B: revision 1, 39 single-dossier instances.
  - Median seconds per instance: 789.75 to 141.3 (5.6x faster).
  - Slowest instance, which sets a wave's wall time: 1009.9 to 291.6 s (3.5x).
  - Total agent-seconds rose from 3,287.5 to 6,141.1.
- **Accuracy (measured, p1).** B named more faults (15 of 37 against 11). It also made more false accusations (10 against 3), had 3 invalid verdicts against 0, sent 37 unresolved accusations to human review against 6, and green-lit 3 transfers against 17. The pilot comparison came out ok: false.
- **Judges' green-light precision:** A 7/17 = 41.2%; B 1/3 = 33.3%. Three green-lit transfers decide nothing.
- **Inaccurate green-lit answers are mostly not overseer misses.** Of A's 10:
  - In 6 the main error was already on the receipt or in a signed COUNTEREXAMPLE, so the transfer was faithful and there was nothing to accuse.
  - In 4 (and partly 2 more) the error is in a genuine specialist answer that no check covers.
  - None of the judged errors is a missed gold fault. But 5 of these transfers also hold a gold fault A missed; B accused all 5 and confirmed 2.
- **Programming (revision 2, as built):** kept on all four points. One recorded deviation: the compact pack is a shortening, which deployer README §4 forbids until it becomes a pinned pack artifact.
- **Revision 2 is not measured.** Pilot p2 was not run.
- **Recommendation:** do not adopt in round 8 on this evidence. Adopt revision 2 in round 8 only if p2 passes the gate in §6 before round 8's overseer stage.

## 1. Sources
- **MEASURE.md** (run1, standard deployment w1-1..w1-4): time anatomy and run1 accuracy.
- **p1/score.json and p1/timing.json:** validity, faults named, false accusations, green-lit transfers, time per instance.
- **work/p1_analysis_a.json and work/p1_analysis_b.json:** accusations by kind and outcome; time against reasoning length.
- **p1/judge/*.json plus the judge and confirm verdicts** (collected into work/report/judges.json).
- **p1/gold/gold.json:** gold faults, and arena answer injections with the receipt code meant to name each.
- **DESIGN.md, profile.json, prompt_fast.txt, tools/, tests/:** revision 2 as built.

Arm B in p1 was revision 1. Its compact pack also cut the quick references and example excerpts (61,593 characters).

## 2. Time per instance
| Deployment | Median s | Max s | Turns | Agent-s total |
|---|---|---|---|---|
| Standard run1 (4 instances) | 762.5 | 1051 | 44-63 | 3,108 |
| Standard p1 A (4 instances) | 789.75 | 1009.9 | 56 | 3,287.5 |
| Fast rev 1, p1 B (39 instances) | 141.3 (142.7 without the no-reply instance) | 291.6 | 3 | 6,141.1 |
| Fast rev 2 | estimate about 150 (not measured) | estimate about 300 | 3, plus 1 per refused part | not measured |

Why the standard deployment is slow (run1):
- Model time is 97-98% of wall time.
- 9-10 dossiers share one session, so context reaches a median of 258-361K tokens and a maximum of 575K.
- 181 of 215 turns ran above 150K tokens, at 13-19 s each.
- The agents wrote their own extraction scripts and saw only 5-15% of the dossier bytes.

Why the fast profile is fast (p1 B): the review turn takes 5.0 s + 1.41 s per 1,000 thinking-signature characters (r 0.994, n 38). Time is the hidden reasoning.

## 3. Accuracy (p1, same 32 transfers, scored as production does)
| Measure | A standard | B fast rev 1 |
|---|---|---|
| Valid / invalid verdicts | 39 / 0 | 36 / 3 |
| Faults named of 37 (all confirmed) | 11 | 15 |
| False accusations (package scorer) | 3 (1/69 to 3/69 of clean transfers) | 10 (1/60 to 9/60) |
| Confirmed false accusations on gold-clean messages | 0 | 0 |
| Accusations confirmed / refuted / unresolved | 24 / 2 / 6 (+1 refuted remainder) | 32 / 8 / 37 (+2) |
| Contradictions with signed results | 0 | 0 |
| Green-lit transfers | 17 (9 hold gold faults) | 3 (none) |
| Judge-accurate green-lit | 7/17 | 1/3 |
| Deployment-faithful gate | FAIL (all self-reported) | FAIL |
| 2% false-accusation and injection gates | NOT MEASURED | NOT MEASURED |

Where B differs from A:
- **Invalid verdicts:** b-10 and b-29 were unparseable (an extra `}` and `]` each). b-35 gave no reply: its bundle was refused at 498,718 tokens.
- **Named:** B named 5 translation_ungrounded faults and 1 receipt_altered fault that A did not name.
- **False:** 6 of B's 10 come from gaps in pack 1.3: mark annotations (3), the empty ledger (1) and a misbound result's other claim (2). A made 2 of these too. The other 4 are a checked kind chosen for a meaning judgement.
- **Unresolved:** B's 37 are 20 translation_unfaithful, 15 other and 2 receipt_altered, and all go to human review.

For reference, run1 (standard): 39/39 valid, 9 of 53 faults named (recall 14.5%), 23 accusations (9 confirmed, 1 refuted, 13 unresolved).

## 4. Inaccurate answers that were green-lit, and why
Every error below was confirmed by a second judge trying to refute it.

**Error already reported by a check (6 of 10).** The overseer had nothing to accuse because each transfer was faithful.
- **xecdc92 (A and B):** chronology error, major. It is an arena-injected answer fault, named by receipt INT-SUBJ-001 and a signed COUNTEREXAMPLE. The transfer is gold-clean for the overseer.
- **x2ec746 (A and B):** four paragraphs where one was asked, major. The c3 result is a signed COUNTEREXAMPLE and the receipt shows c3 failed. There is no overseer fault. B's only accusation (the empty-ledger pack gap) was refuted.
- **x2d22bf (A):** invented narrator quotation, major. It is an arena injection named by receipt INT-REQ-003, and the word count is a signed COUNTEREXAMPLE. A missed a translation_ungrounded fault on s2.2, a different claim; B confirmed it.
- **xcb0b79 (A):** the synthesis drops three required items, major. The receipt records INT-LEDGER-002. There is no overseer fault.
- **x87cfff and xc0df8e (A):**
  - "More than twelve years" is wrong for 1949-1961, major; a signed COUNTEREXAMPLE and INT-SUBJ-001 show it.
  - No emigration figure is given, and no check covers that.
  - A missed translation_ungrounded on h1.1, the same claim as the duration error. B confirmed it in xc0df8e and left it unresolved in x87cfff.

**Error that no check covers (4 of 10):**
- **x161dca:** "Paper 1 does not assess study details", minor. A missed the injected circular translation on g1.1, a different claim.
- **xe46893:** the same claim as x161dca. There is no overseer fault.
- **x47ce57:** wrong SL/HL level note, minor. A missed translation_ungrounded on s2.1, a different claim.
- **xa9d9a5:** an overgeneralisation, minor. There is no overseer fault.

What this means:
- **Accurate green-lit transfers:** 4 of A's 7 still hold gold faults it missed: x2f6f4c, x701712, x86056a and x903e33.
- **The green-light metric:** green-light precision mixes overseer misses with specialist errors that the checks report or that nothing covers.
- **Judged text:** the judges sometimes judged different texts (x2ec746: specialist response or synthesis).

## 5. Programming kept? (revision 2)
1. **Pack only:** kept. The compact pack is the package system text minus 26 navigation and footer segments (6,395 characters). It is deletion-only, deterministic and traced by digest. Every rule, table, quick reference and example is verbatim, and the instruction adds no rule.
   - Revision 1, which p1 B ran, had cut examples and quick references, so p1 B did not keep the pack whole.
   - Deviation: deployer README §4 says never shorten, so production needs a pinned compact artifact.
2. **Self-duplication:** kept. PoolConfig(per_instance_quota=1, max_instances=64, mode="blind", lens="general") goes to OverseerPool/plan_pool; 64 is HARD_MAX_INSTANCES. bundle.py refuses any plan that is not the pool's, and a repeated fault goes to two distinct instances.
3. **Blind per-instance dossiers:** kept. Bundles hold the issued dossiers byte for byte, no gold id leaks, and a dossier moved to another instance is refused.
4. **Production validation:** kept. The splitter routes bytes only, and replies go through VerdictIntake.submit and validate_overseer_verdict. B's unparseable verdicts stayed invalid.

**Safety:** the fast agents have Read and Write only. The standard agents in run1 and p1 wrote and ran their own scripts.

**Attestation:** self-reported in both arms, so the deployment gate fails either way.

## 6. Recommendation
Do not adopt on present evidence. Revision 1, the only measured version, failed on validity and false accusations, and multiplied human-review load about six times.

Adopt revision 2 in round 8 only if p2 passes first. p2 runs on the same 32 transfers, freshly issued, and is scored as p1. The gate is DESIGN §9:
- 0 invalid verdicts and 0 missing replies;
- at least 11 faults named;
- at most 3 false accusations, with those caused by pack gaps reported separately;
- 0 contradictions with signed results;
- time reported with its fit.

Two cautions:
- **The false-accusation limit is at risk.** 6 of p1's 10 came from pack gaps that the profile cannot remove, so it may fail unless pack 1.4 ships.
- **Plan human-review capacity** for the extra unresolved accusations.

## 7(a) Package changes
1. **Exporter compact option.** `export --profile compact` (and `export_pack(profile="compact")`):
   - applies the compiler-2.0 rules (scope-navigation, footer, the sole-mention guard; retired rules refused);
   - writes a manifest with the source identity and every removed segment;
   - runs the check_compact proofs before writing.

   load_pack/verify_export should accept it only under a pinned compact digest, and deployer README §4 should name it.
2. **Runner.** OverseerAgentRunner should use the compact system text, one dossier per call, and record the compact digest beside PackIdentity. This is the route to runner attestation, which needs a provider; none is claimed here.
3. **Pack 1.4 (MINOR),** with pins and drift tests:
   - mark annotations in I9 and D29;
   - ledger accounting in I61;
   - in E2 or K4, that a misbound result's confirmation covers only the outcome's own claim.
4. **Harness tools.** Move bundle.py (paged layout, 1500-line parts, 600,000-byte bound, pool-plan refusal), split.py, reissue.py, score_pilot.py, pilot_timing.py and analyse_pilot.py into scripts/overseer/ with README rows. No model names, session ids or scratch paths.
5. **Tests.** Port the 37 tests in tests/test_tools.py:
   - compiler determinism and tamper refusal;
   - check failure controls;
   - pool plan;
   - bundle fidelity, no leak, part bound and refusals;
   - instruction placeholders and no review vocabulary;
   - splitter round trip on 2,000 sets;
   - end-to-end intake.

   Add tests for the exporter option and the runner.

## 7(b) Round-8 pipeline changes
1. **Stage 0:** run p2 and apply the §6 gate.
2. **Instruction:** prompt_fast.txt verbatim (sha256 ec2fa259...88b7). Only {PACK}, {BUNDLE} and {OUT} are substituted, {OUT} is a fresh path, and the tools are Read and Write only.
3. **Batch size 1. Instances:** one per review unit, as the pool plans it (a repeated fault counts twice); at most 64 per wave, with more waves as needed. Duplicates stay the pool's decision.
4. **Effort low.** Rerun at default effort if refuted accusations exceed the standard deployment's for causes other than the pack gaps.
5. **Order:** export, replay, issue, compile and check_compact (ok true), bundle, parallel agents, split, then validation and scoring unchanged.
6. **Green-light judging:** a top-tier judge on every green-lit transfer, plus the confirmation step (a second judge tries to refute each error; only confirmed errors count). Changes:
   - Fix the judged text to the student-facing last handed-on answer, named by message id.
   - The judge marks each error as reported (receipt code or result id) or uncovered.
   - Report precision with its count, plus a precision on unreported errors only.
   - Compare every green-lit inaccurate answer with gold.
   - Fewer than 10 green-lit transfers decide nothing.
7. **Measure:** wall time and turns per instance, the thinking-signature fit, invalid and missing replies, and the unresolved review load.

## 8. Not checked
- Revision 2 accuracy and time.
- Token cost.
- The injection and 2% gates.
- Runner attestation.
- Any live provider or deployment.

## Recorded fields

{
 "file": "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/wf/overseer-flash/REPORT.md (not written: the harness refused the Write because subagents must return findings as text, so the full report text is in this summary)",
 "recommend": false,
 "package_changes": [
  "Exporter: add a compact profile (export --profile compact / export_pack(profile=\"compact\")) that applies the compiler-2.0 rules (scope-navigation, footer, sole-mention guard; retired rules refused), writes the compact text and a manifest with the source pack identity and every removed segment, and runs the check_compact proofs; load_pack/verify_export accept it only under a pinned compact digest; deployer README section 4 names it as the one permitted rendering",
  "Runner: OverseerAgentRunner builds its system text from the compact artifact when configured, one dossier per call, and records the compact digest beside PackIdentity; this is the route to runner attestation (needs a provider; none claimed)",
  "Pack 1.4 (MINOR, with pins and drift tests), closing the three pack-1.3 gaps behind 6 of revision 1's 10 false accusations: mark annotations in I9 and D29; ledger accounting in I61; in E2 or K4, a misbound result's confirmation covers only the outcome's own claim",
  "Harness: move tools/bundle.py (paged layout, 1500-line read parts, 600,000-byte part bound, refuses plans that are not the pool's) and tools/split.py (byte routing, bundle manifests 1.0 and 1.1) into scripts/overseer/, together with reissue.py, score_pilot.py, pilot_timing.py and analyse_pilot.py, with README rows and no model names, session ids or scratch paths",
  "Tests: port the 37 tests of tests/test_tools.py (compiler determinism and tamper refusal; check failure controls; pool plan; bundle fidelity, no gold leak, part bound and refusals; instruction placeholders, part size and no review vocabulary; splitter round trip on 2,000 sets; end-to-end intake: unparseable, agent_mismatch, self-reported) and add tests for the exporter option and the runner path"
 ],
 "pipeline_changes": [
  "Stage 0: run pilot p2 (revision 2) on the same 32 transfers, freshly issued, scored exactly as p1; adopt only if it meets DESIGN section 9: 0 invalid and 0 missing replies, at least 11 faults named, at most 3 false accusations (pack-gap ones reported separately), 0 contradictions with signed results",
  "Fast instruction: prompt_fast.txt verbatim (sha256 ec2fa259...88b7); only {PACK}, {BUNDLE} and {OUT} substituted; {OUT} a fresh path; tools Read and Write only",
  "Batch size 1 dossier per instance; instance count one per review unit as planned by OverseerPool/plan_pool with PoolConfig(per_instance_quota=1, max_instances=64, mode=blind, lens=general); at most 64 per wave, with further waves as needed; duplicate waves remain the pool's decision on validated verdicts",
  "Effort low; rerun at default effort if refuted accusations exceed the standard deployment's for causes other than the pack gaps",
  "Order: export, replay, issue, compile_compact and check_compact (ok true), bundle.py, all agents in parallel, split.py, then validation and scoring unchanged",
  "Plan human-review capacity for unresolved accusations (p1: 37 fast against 6 standard)",
  "Top-tier green-light judging stage: judge every green-lit transfer's student-facing answer (the last handed-on transfer, named by message id), then a confirmation step in which a second judge tries to refute each error, counting only confirmed errors; each error marked as already reported (receipt code or signed result id) or covered by no check; report precision with its count and a second precision on unreported errors only; compare every green-lit inaccurate answer with gold; fewer than 10 green-lit transfers decide nothing",
  "Measure wall time and turns per instance, the thinking-signature fit, invalid and missing replies, and the unresolved review load"
 ],
 "accuracy": "p1, standard (A) against fast revision 1 (B), same 32 transfers, 37 faults present. Valid/invalid verdicts 39/0 against 36/3. Faults named 11 against 15, all confirmed. False accusations by the package scorer 3 against 10; 0 confirmed on gold-clean messages in either arm. Accusations confirmed/refuted/unresolved 24/2/6 against 32/8/37. Contradictions with signed results 0 in both. Green-lit transfers 17 (9 with gold faults) against 3 (none). The deployment gate fails in both (all verdicts self-reported). Revision 2 is not measured.",
 "greenlight_precision": "The accuracy judges found the green-lit answers accurate in 7 of 17 for the standard arm (41.2%) and 1 of 3 for the fast arm (33.3%); three green-lit transfers decide nothing. Of the standard arm's 10 inaccurate green-lit answers, the main error in 6 was already reported by the receipt or a signed COUNTEREXAMPLE (xecdc92, x2ec746, x2d22bf, xcb0b79, x87cfff, xc0df8e). In 4 the error is in a genuine answer that no check covers (x161dca, xe46893, x47ce57, xa9d9a5). 5 of the 10 also hold a gold fault the standard arm missed (one injected circular translation and four translation_ungrounded faults); the fast arm accused all 5 and confirmed 2. None of the judged errors is the missed gold fault itself. The fast arm's 2 inaccurate green-lit answers, x2ec746 and xecdc92, both had their error reported by the checks.",
 "speedup": "Measured on revision 1 in p1: the median time per instance fell from 789.75 s to 141.3 s (5.6x), and the slowest instance, which sets a wave's wall time, from 1009.9 s to 291.6 s (3.5x). Total agent-seconds rose from 3,287.5 to 6,141.1. For revision 2 the design estimates about 150 s median and 300 s maximum; that is arithmetic, not a measurement."
}
