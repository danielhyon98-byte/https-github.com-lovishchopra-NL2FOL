#!/usr/bin/env python3
"""One bundle file per overseer-agent instance, holding exactly the blind dossiers the package's intake issued to it.

    python -I bundle.py --root RUN_DIR --out BUNDLE_DIR [--layout paged|runner|canonical] [--width 1000] [--src SRC_DIR]

``RUN_DIR`` is a wave as the harness writes it: ``records/pool_plan.json`` (the plan the package's ``OverseerPool``
made), ``records/issues.jsonl`` (one issue record per dossier the intake issued: instance, dossier path, issue) and the
dossier files. Nothing here decides how many instances there are or who reviews what: the plan is validated with the
package's own ``PoolPlan`` model and followed exactly, and the bundle tool refuses the wave (exit status 2, with the
reason) unless all of this holds:

* the plan is exactly the one the package's ``plan_pool`` makes for the plan's own items, configuration and pack (so it
  was decided by the pool, within its maximum, and not edited by hand);
* every issued dossier answers one assignment of the plan (its ``channel_uid`` is a plan key and its instance is one the
  plan assigns to that key), and every assignment of the plan has exactly one issued dossier: the plan's instances,
  loads and duplicates (a repeated-fault dossier to two distinct instances) are the bundles' instances, sizes and
  duplicates;
* every dossier file is the canonical JSON the intake issued (strict parse, no duplicate key, bytes equal to its
  canonical form), its digest recomputes, and its header is its issue's: ``agent_id`` is the instance it is bundled for,
  ``dossier_sha256``, ``pack``, ``lens`` and ``mode`` are the issue's and the plan's; a blind dossier carries no
  ``auditor`` and no ``consolidations``;
* no dossier digest, and no (instance, channel), appears twice: a dossier issued to one instance is never handed to
  another.

Each bundle (``<instance>.bundle.txt``) is opaque: its only lines outside the dossiers are the fixed lines below, its
name is the instance id the dossiers' own header carries, and each dossier is the issued one, unchanged as data: the
block between ``<<<DATA dossier>>>`` and ``<<<END dossier>>>`` (the runner's delimiters, which the master prompt
describes) parses back to the issued dossier, whose canonical form is the issued file byte for byte (checked for every
block). Layouts of the block:

* ``paged`` (default): the dossier's canonical JSON with line breaks between members and elements of every container
  longer than ``--width`` characters, one space of indentation per level; a value that fits stays on one line. Same
  tokens as the canonical form, no line longer than the longest single string of the dossier, so a reader can take it
  whole or page through it by lines;
* ``runner``: exactly the user text the package's ``OverseerAgentRunner`` sends for the dossier (``render_dossier_block``);
* ``canonical``: the issued file's own bytes on one line (needs a reader that takes very long lines whole).

In every layout U+0085, U+2028 and U+2029 inside strings are written as JSON escapes (the runner's rule), so no line can
be taken for a delimiter.

    === BUNDLE D1 D2 ===
    === DOSSIER D1 ===
    <<<DATA dossier>>>
    ...the dossier...
    <<<END dossier>>>
    === DOSSIER D2 ===
    ...
    === END BUNDLE ===

**Read parts.** An instance reads its bundle whole in one Read call when it fits the room one turn has (about 400,000
tokens were taken in pilot p1; 498,718 were refused). When a call is refused, the fast instruction has the agent read
that file in parts of ``PART_LINES`` lines (offset 1, 1 + PART_LINES, ...), one part per turn, up to its last line (for a
bundle, ``=== END BUNDLE ===``). The tool computes those parts for every bundle and refuses the wave (exit status 2)
when any part is over ``PART_MAX_BYTES``, so a bundle is never issued that its agent could not read by the
instruction's own rule. Parts cut the file by lines only; the agent reads every part, so it still reads every line of
every dossier.

``bundles.json`` (for the harness, never for an agent) records per instance its bundle's SHA-256, size, an estimate of
its tokens (bytes / 2, the ratio measured on dossier JSON), whether one Read call is expected to take it whole, and its
read parts (line range and bytes), and per dossier its tag, digest, issue id, source file (relative to ``RUN_DIR``) and
SHA-256, and the block's line range. It holds no gold, no variant and no path outside the two directories.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Optional

FORMAT = "overseer-bundles/1.1"
#: The part size the fast instruction names (``prompt_fast.txt``: "in parts of 1500 lines"). A test keeps the two equal.
PART_LINES = 1500
#: The largest part a single Read call must take: about 300,000 tokens at the measured two bytes a token, well inside
#: the room of one turn (a Read call was refused at 498,718 tokens with 438,734 left, and took 400,000 in pilot p1).
PART_MAX_BYTES = 600_000
#: Above this estimate (bytes / 2) the agent is expected to need the parts (informational; the agent always tries the
#: whole file first and pages only when that call is refused). Pilot p1: bundles of about 400,000 tokens were taken whole
#: beside the pack, one of 498,718 tokens was refused.
SINGLE_READ_TOKENS = 420_000
LAYOUTS = ("paged", "runner", "canonical")
OPEN, CLOSE = "<<<DATA dossier>>>", "<<<END dossier>>>"
_ESCAPES = {"\u0085": "\\u0085", " ": "\\u2028", " ": "\\u2029"}


class BundleError(ValueError):
    """A wave the bundle tool refuses. The message is the tool's own text, never dossier text."""


def _escape(text: str) -> str:
    for ch, esc in _ESCAPES.items():
        text = text.replace(ch, esc)
    return text


def _canon(value: Any) -> str:
    return _escape(json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False))


def render_paged(dossier: dict, width: int) -> list[str]:
    """The dossier's canonical JSON, broken between members and elements of every container longer than ``width``."""
    out: list[str] = []

    def emit(prefix: str, value: Any, depth: int, trailing: str) -> None:
        indent = " " * depth
        flat = _canon(value)
        if not isinstance(value, (dict, list)) or not value or len(indent) + len(prefix) + len(flat) + len(trailing) <= width:
            out.append(indent + prefix + flat + trailing)
            return
        if isinstance(value, dict):
            out.append(indent + prefix + "{")
            items = sorted(value.items())
            for k, (key, val) in enumerate(items):
                emit(_canon(key) + ":", val, depth + 1, "," if k < len(items) - 1 else "")
            out.append(indent + "}" + trailing)
        else:
            out.append(indent + prefix + "[")
            for k, val in enumerate(value):
                emit("", val, depth + 1, "," if k < len(value) - 1 else "")
            out.append(indent + "]" + trailing)

    emit("", dossier, 0, "")
    return out


def render_block(dossier: dict, raw: str, layout: str, width: int) -> list[str]:
    """The lines of one dossier block, delimiters included."""
    if layout == "runner":
        from epinoic_logic.overseer.runner import render_dossier_block
        return render_dossier_block(dossier).split("\n")
    if layout == "canonical":
        return [OPEN, _escape(raw.rstrip("\n")), CLOSE]
    if layout == "paged":
        return [OPEN, *render_paged(dossier, width), CLOSE]
    raise BundleError(f"unknown layout {layout!r}")


def _strict_loads(text: str) -> Any:
    from epinoic_logic.ir.canonical import strict_object_pairs

    def no_constant(name: str) -> Any:
        raise ValueError(f"non-finite number {name}")
    return json.loads(text, object_pairs_hook=strict_object_pairs, parse_constant=no_constant)


def _read_issues(root: Path) -> list[dict]:
    rows = []
    for n, line in enumerate((root / "records" / "issues.jsonl").read_text(encoding="utf-8").split("\n"), 1):
        if line.strip():
            try:
                rows.append(_strict_loads(line))
            except ValueError:
                raise BundleError(f"issues.jsonl line {n} is not one strict JSON object") from None
    if not rows:
        raise BundleError("issues.jsonl holds no issue")
    return rows


def _safe_rel(root: Path, rel: str) -> Path:
    p = (root / rel).resolve()
    if root.resolve() not in p.parents or p.is_symlink():
        raise BundleError(f"the dossier path {rel!r} leaves the run directory")
    return p


def build_bundles(root: Path, layout: str = "paged", width: int = 1000) -> tuple[dict[str, str], dict]:
    """``({bundle file name: text}, bundles manifest)``. Raises :class:`BundleError` on any fault listed in the module
    docstring; nothing is returned half-built."""
    from epinoic_logic.ir.canonical import canonical_json
    from epinoic_logic.overseer.dossier import verify_dossier_digest
    from epinoic_logic.overseer.pool import PoolPlan
    from epinoic_logic.overseer.verdicts import PackIdentity

    if layout not in LAYOUTS:
        raise BundleError(f"unknown layout {layout!r}")
    if width < 80:
        raise BundleError("width must be at least 80 characters")
    try:
        plan = PoolPlan.model_validate(_strict_loads((root / "records" / "pool_plan.json").read_text(encoding="utf-8")))
    except (ValueError, OSError) as exc:
        raise BundleError(f"the pool plan does not validate against the package's PoolPlan ({type(exc).__name__})") from None
    # the plan must be the one the package's pool makes for its own items under its own configuration: never hand-made
    from epinoic_logic.overseer.pool import plan_pool
    try:
        remade = plan_pool(plan.items, plan.config, plan.pack)
    except (TypeError, ValueError):
        raise BundleError(f"the package's pool refuses the configuration of plan {plan.plan_id}") from None
    if remade.model_dump(mode="json") != plan.model_dump(mode="json"):
        raise BundleError(f"plan {plan.plan_id} is not the plan the package's pool makes for its items under its configuration")
    issues = _read_issues(root)
    by_instance: dict[str, list[dict]] = defaultdict(list)
    seen_digest: set[str] = set()
    seen_channel: set[tuple[str, str]] = set()
    covered: Counter = Counter()
    for row in issues:
        try:
            inst, rel, iss = row["instance"], row["dossier"], row["issue"]
            agent, uid, digest, task = iss["agent_id"], iss["channel_uid"], iss["dossier_sha256"], iss["task_id"]
            pack = PackIdentity.model_validate(iss["pack"])
        except (KeyError, TypeError, ValueError):
            raise BundleError("an issue record lacks instance, dossier or its issue fields") from None
        if inst != agent:
            raise BundleError(f"an issue record names instance {inst!r} but was issued to {agent!r}")
        if inst not in plan.instances:
            raise BundleError(f"{inst!r} is not an instance of plan {plan.plan_id}")
        if uid not in plan.assignments or inst not in plan.assignments[uid]:
            raise BundleError(f"plan {plan.plan_id} does not assign dossier key {uid!r} to {inst!r}")
        if pack != plan.pack or iss["lens"] != plan.config.lens or iss["mode"] != plan.config.mode:
            raise BundleError(f"the issue of {rel!r} names another pack, lens or mode than plan {plan.plan_id}")
        if digest in seen_digest:
            raise BundleError(f"dossier {digest[:16]}... is issued twice: a dossier goes to one instance only")
        if (inst, uid) in seen_channel:
            raise BundleError(f"{inst!r} holds two dossiers of one channel")
        seen_digest.add(digest)
        seen_channel.add((inst, uid))
        covered[(uid, inst)] += 1
        by_instance[inst].append(row)
    wanted = {(uid, a) for uid, insts in plan.assignments.items() for a in insts}
    if set(covered) != wanted or any(n != 1 for n in covered.values()):
        missing = len(wanted - set(covered))
        raise BundleError(f"the issued dossiers do not answer plan {plan.plan_id} one for one ({missing} assignment(s) without a dossier)")
    for inst in plan.instances:
        if len(by_instance[inst]) != plan.loads[inst] or not by_instance[inst]:
            raise BundleError(f"{inst!r} holds {len(by_instance[inst])} dossiers; plan {plan.plan_id} gives it {plan.loads[inst]}")

    texts: dict[str, str] = {}
    records = []
    for inst in plan.instances:
        rows = by_instance[inst]
        tags = [f"D{k}" for k in range(1, len(rows) + 1)]
        lines = ["=== BUNDLE " + " ".join(tags) + " ==="]
        entries = []
        for tag, row in zip(tags, rows):
            path = _safe_rel(root, row["dossier"])
            raw_bytes = path.read_bytes()
            try:
                raw = raw_bytes.decode("utf-8")
                d = _strict_loads(raw)
            except (UnicodeDecodeError, ValueError):
                raise BundleError(f"{row['dossier']} is not strict UTF-8 JSON") from None
            iss = row["issue"]
            if not isinstance(d, dict) or not verify_dossier_digest(d):
                raise BundleError(f"{row['dossier']}: the dossier digest does not recompute")
            if raw != canonical_json(d) + "\n":
                raise BundleError(f"{row['dossier']} is not the canonical JSON the intake issues")
            if d["agent_id"] != inst or d["dossier_sha256"] != iss["dossier_sha256"] or d["task"]["task_id"] != iss["task_id"]:
                raise BundleError(f"{row['dossier']} is not the dossier issued to {inst!r}")
            if PackIdentity.model_validate(d["pack"]) != plan.pack or d["lens"] != iss["lens"] or d["mode"] != iss["mode"]:
                raise BundleError(f"{row['dossier']}: its pack, lens or mode is not its issue's")
            if d["mode"] == "blind" and ("auditor" in d or d.get("consolidations")):
                raise BundleError(f"{row['dossier']} is marked blind but carries audit findings or consolidations")
            block = render_block(d, raw, layout, width)
            body = "\n".join(block[1:-1])
            if layout != "runner":
                if _strict_loads(body) != d or canonical_json(_strict_loads(body)) + "\n" != raw:
                    raise BundleError(f"{row['dossier']}: the {layout} block does not parse back to the issued dossier")
            elif canonical_json(_strict_loads(body)) + "\n" != raw:
                raise BundleError(f"{row['dossier']}: the runner block does not parse back to the issued dossier")
            if block[0] != OPEN or block[-1] != CLOSE or any(line in (OPEN, CLOSE) or line.startswith("=== ") for line in block[1:-1]):
                raise BundleError(f"{row['dossier']}: a line of the dossier could be read as a delimiter")
            lines.append(f"=== DOSSIER {tag} ===")
            first = len(lines) + 1
            lines.extend(block)
            entries.append({"tag": tag, "dossier_sha256": d["dossier_sha256"], "issue_id": iss["issue_id"], "task_id": iss["task_id"],
                            "source": row["dossier"], "source_sha256": hashlib.sha256(raw_bytes).hexdigest(), "source_bytes": len(raw_bytes),
                            "first_line": first, "last_line": len(lines)})
        lines.append("=== END BUNDLE ===")
        text = "\n".join(lines) + "\n"
        name = f"{inst}.bundle.txt"
        texts[name] = text
        parts = read_parts(text)
        big = [x for x in parts if x["bytes"] > PART_MAX_BYTES]
        if big:
            raise BundleError(f"{inst!r}: its bundle's part of lines {big[0]['first_line']}-{big[0]['last_line']} is {big[0]['bytes']} bytes, "
                              f"over the {PART_MAX_BYTES} one Read call must take")
        size = len(text.encode("utf-8"))
        records.append({"agent_id": inst, "bundle": name, "sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(),
                        "bytes": size, "lines": len(lines), "longest_line": max(len(x) for x in lines),
                        "approx_tokens": size // 2, "single_read_expected": size // 2 <= SINGLE_READ_TOKENS,
                        "part_lines": PART_LINES, "parts": parts, "verdicts_file": f"{inst}.verdicts.txt", "dossiers": entries})
    manifest = {"format": FORMAT, "layout": layout, "width": width, "plan_id": plan.plan_id, "pack": plan.pack.model_dump(mode="json"),
                "prompt_version": f"{plan.pack.name}/{plan.pack.version}+{plan.pack.sha256[:16]}",
                "pool_config": plan.config.model_dump(mode="json"), "instances": records,
                "dossiers": sum(len(r["dossiers"]) for r in records), "max_dossiers_per_bundle": max(len(r["dossiers"]) for r in records)}
    return texts, manifest


def read_parts(text: str, part_lines: int = PART_LINES) -> list[dict]:
    """The parts the fast instruction reads a bundle in when one Read call cannot take it: lines 1 to ``part_lines``,
    then the next ``part_lines``, up to the last line (``=== END BUNDLE ===``), with each part's UTF-8 size as the Read
    tool returns it (its lines and their newlines)."""
    lines = text.split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    out = []
    for start in range(0, len(lines), part_lines):
        chunk = lines[start:start + part_lines]
        out.append({"first_line": start + 1, "last_line": start + len(chunk), "bytes": sum(len(x.encode("utf-8")) + 1 for x in chunk)})
    return out


def render_manifest(manifest: dict) -> str:
    return json.dumps(manifest, indent=1, sort_keys=True, ensure_ascii=False) + "\n"


def main(argv: Optional[list[str]] = None) -> int:
    ap = argparse.ArgumentParser(description="One bundle per overseer instance, holding exactly the dossiers issued to it.")
    ap.add_argument("--root", required=True, type=Path, help="the wave directory (records/pool_plan.json, records/issues.jsonl, dossiers)")
    ap.add_argument("--out", required=True, type=Path, help="output directory for the bundles and bundles.json")
    ap.add_argument("--layout", default="paged", choices=LAYOUTS)
    ap.add_argument("--width", default=1000, type=int)
    ap.add_argument("--src", type=Path, help="a source tree's src directory to import the package from")
    args = ap.parse_args(argv)
    if args.src is not None:
        sys.path.insert(0, str(args.src.resolve()))
    try:
        texts, manifest = build_bundles(args.root, args.layout, args.width)
    except BundleError as exc:
        print(json.dumps({"ok": False, "error": str(exc)}))
        return 2
    args.out.mkdir(parents=True, exist_ok=True)
    for name, text in texts.items():
        (args.out / name).write_text(text, encoding="utf-8", newline="\n")
    (args.out / "bundles.json").write_text(render_manifest(manifest), encoding="utf-8", newline="\n")
    print(json.dumps({"ok": True, "plan_id": manifest["plan_id"], "instances": len(manifest["instances"]), "dossiers": manifest["dossiers"],
                      "max_dossiers_per_bundle": manifest["max_dossiers_per_bundle"], "layout": manifest["layout"],
                      "bundle_bytes": {r["agent_id"]: r["bytes"] for r in manifest["instances"]}}))
    return 0


if __name__ == "__main__":
    sys.exit(main())
