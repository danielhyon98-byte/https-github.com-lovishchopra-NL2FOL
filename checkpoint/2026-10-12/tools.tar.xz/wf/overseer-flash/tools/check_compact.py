#!/usr/bin/env python3
"""Prove that a compact pack keeps what the overseer agent's programming needs, and nothing else changed.

    python -I check_compact.py --pack EXPORTED_PACK_DIR --compact OUT_DIR/<pack>-<version>.compact.txt [--src SRC_DIR] [--out REPORT.json]

The source pack is loaded by the package's own loader. Every check re-derives its facts from the SOURCE documents (never
from the compiler's own bookkeeping alone) and reports ``pass`` or ``fail`` with what failed; the exit status is 0 only
when every check passes. The checks:

* ``identity``: the source pack is pinned by the package; the compact manifest names it (pack digest, system digest)
  next to the compact file's own SHA-256, and the compact file has that digest.
* ``deterministic``: compiling the source pack again gives the same compact bytes and the same manifest.
* ``deletion_only``: the compact pack holds the source documents in system order, the master prompt byte for byte, and
  each document's lines are its source lines with exactly the recorded removals taken out; putting the removed segments
  back gives the source system text exactly. Nothing is added, reworded or reordered.
* ``removals_by_rule``: every removed segment has the shape of a rule the compiler applies (``scope-navigation`` or
  ``footer``; no segment under a retired rule) and holds no coded rule, no table row, no fenced block and no heading.
* ``decision_procedure``: the master prompt is byte-identical, and its order, its order in detail (steps 1 to 7), its
  non-negotiables, lens and mode, several instances, when in doubt and authority order are each present verbatim.
* ``kinds_and_codes``: every kind and every code of the source Kinds and codes document (each ``OVS-*``, ``INT-*`` and
  branch code, each code family, each ``-SRC-`` suffix) occurs in the compact pack's Kinds and codes; every line of its
  sections 2 to 8 is kept; its kinds table equals the package's ``KIND_CHECKS`` and ``KIND_CODE_QUALIFIERS``.
* ``never_and_when_unsure``: every rule of Never (N*) and When unsure (U*), as its whole block (sub-items and code blocks
  included), occurs verbatim in the compact pack, and the compact pack defines no other N or U rule.
* ``every_coded_rule``: the same for every coded rule of every document (T, D, I, E, V, K, X, N, U).
* ``codes_and_kinds_per_document``: every code, code family and accusation kind any source document names is still
  named by the same compact document.
* ``tables``: every table row of every source document occurs verbatim.
* ``quick_references_kept``: every ``## 2. Quick reference`` section of the source occurs verbatim in its document.
* ``examples_whole``: every worked example section (``## N. Example K: ...``: type, rules shown, dossier excerpt, what
  to notice, correct verdict, why) and the wrong-verdicts section occur verbatim in Examples.
* ``verdict_format``: the verdict skeleton is kept verbatim; every correct verdict kept in Examples parses and validates
  against the verdict contract, and as many are kept as the source holds.
* ``references_resolve``: every rule code, ``Example N`` and ``§N`` the compact pack cites exists in the compact pack.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Callable, Optional

sys.path.insert(0, str(Path(__file__).resolve().parent))
import compile_compact as C  # noqa: E402  (the compiler beside this script)

_DEF_RE = re.compile(r"^\s*- \*\*([TDIEVKNUX])(\d{1,3}) ")
_CITE_RE = re.compile(r"(?<![A-Za-z0-9_+-])([TDIEVKNUX])(\d{1,2})(?![0-9])")
_SECTION_RE = re.compile(r"(?:(Role and trust|Dossier guide|Inspection|Evidence rule|Verdict format|Kinds and codes|Examples|Never|When unsure),? )?§(\d+)")
_CODE_RE = re.compile(r"\b(?:OVS|INT|CORE|HI|ES|GEN|ST)-[A-Z]+-\d{3}\b")
_FAMILY_RE = re.compile(r"`((?:OVS|INT|CORE|HI|ES|GEN|ST)(?:-[A-Z]+)?-\*)`|\b((?:OVS|INT)-[A-Z]+-\*)")
_SUFFIX_RE = re.compile(r"`(-[A-Z]+-\d{3})`")
_KIND_ROW_RE = re.compile(r"^\| `([a-z_]+)` \| .* \| ([^|]+) \|$")
_EXAMPLE_HEAD = re.compile(r"^## \d+\. Example \d+: ", re.M)
#: The master prompt's blocks that hold the decision procedure and the rules over every other document.
MASTER_PROMPT_BLOCKS = ("CORE OPERATING PRINCIPLE", "THE KNOWLEDGE DOCUMENTS", "THE INPUT", "Every verdict MUST follow this order:",
                        "THE ORDER IN DETAIL", "NON-NEGOTIABLES (CRITICAL)", "LENS AND MODE (CRITICAL)", "SEVERAL INSTANCES",
                        "WHEN IN DOUBT", "AUTHORITY ORDER (CONFLICT RESOLUTION)")


def split_system_text(text: str, separator: str) -> list[tuple[str, str]]:
    """``[(path, document text without its trailing newline)]`` of a system text built by the package's rule."""
    head, tail = separator.split("{path}")
    pat = re.compile("^" + re.escape(head) + r"(\S+)" + re.escape(tail) + "$", re.M)
    marks = list(pat.finditer(text))
    out = []
    for k, m in enumerate(marks):
        start = m.end() + 1
        end = marks[k + 1].start() if k + 1 < len(marks) else len(text)
        body = text[start:end]
        if k + 1 < len(marks):
            if not body.endswith("\n\n"):
                raise ValueError(f"document {m.group(1)} is not followed by one blank line")
            body = body[:-2]
        else:
            if not body.endswith("\n"):
                raise ValueError("the system text does not end with a newline")
            body = body[:-1]
        out.append((m.group(1), body))
    return out


def rule_blocks(text: str) -> dict[str, str]:
    """``{code: block}``: each coded rule's whole block, from its definition line up to the next definition, the next
    heading or the footer, without trailing blank lines (a table or code block inside a rule, as in D2 and U1, is part of
    it)."""
    lines = text.split("\n")
    starts = [(i, m.group(1) + m.group(2)) for i, line in enumerate(lines) if (m := _DEF_RE.match(line))]
    out: dict[str, str] = {}
    for k, (i, code) in enumerate(starts):
        j = i + 1
        stop = starts[k + 1][0] if k + 1 < len(starts) else len(lines)
        while j < stop and not lines[j].startswith("#") and not lines[j].startswith("Pack version "):
            j += 1
        block = lines[i:j]
        while block and block[-1] == "":
            block.pop()
        out[code] = "\n".join(block)
    return out


def section_text(text: str, number: int) -> str:
    m = re.search(rf"^## {number}\. .*$", text, re.M)
    if not m:
        return ""
    nxt = re.search(r"^## \d+\. ", text[m.end():], re.M)
    return text[m.start(): m.end() + (nxt.start() if nxt else len(text) - m.end())]


def sections_by_heading(text: str) -> list[tuple[str, str]]:
    """``[(heading line, whole section without the footer and trailing blank lines)]`` of every ``## N.`` section."""
    lines = text.split("\n")
    heads = [i for i, line in enumerate(lines) if re.match(r"^## \d+\. ", line)]
    out = []
    for k, i in enumerate(heads):
        j = heads[k + 1] if k + 1 < len(heads) else len(lines)
        body = [line for line in lines[i:j] if not line.startswith("Pack version ")]
        while body and body[-1] == "":
            body.pop()
        out.append((lines[i], "\n".join(body)))
    return out


def master_prompt_block(text: str, title: str) -> str:
    """The master prompt's block that opens with the line ``title``, up to the next block title or the end."""
    lines = text.split("\n")
    titles = {i for i, line in enumerate(lines) if any(line == t for t in MASTER_PROMPT_BLOCKS)}
    start = next((i for i, line in enumerate(lines) if line == title), None)
    if start is None:
        return ""
    end = next((i for i in sorted(titles) if i > start), len(lines))
    block = lines[start:end]
    while block and block[-1] == "":
        block.pop()
    return "\n".join(block)


class Report:
    def __init__(self) -> None:
        self.checks: dict[str, dict[str, Any]] = {}

    def run(self, name: str, fn: Callable[[], tuple[list[str], dict]]) -> None:
        try:
            problems, facts = fn()
        except Exception as exc:  # a check that cannot run fails
            problems, facts = [f"the check could not run: {type(exc).__name__}: {exc}"], {}
        self.checks[name] = {"result": "pass" if not problems else "fail", "problems": problems[:50], "problem_count": len(problems), **facts}

    @property
    def ok(self) -> bool:
        return all(c["result"] == "pass" for c in self.checks.values())


def check(pack_path: Path, compact_path: Path) -> Report:
    from epinoic_logic.overseer.pack import PACK_DIGESTS, build_system_text, load_pack
    from epinoic_logic.overseer.verdicts import KIND_CHECKS, KIND_CODE_QUALIFIERS, AgentVerdict

    pack = load_pack(pack_path)
    ident = pack.identity
    separator = pack.manifest.system_separator
    source_docs = [(p, t.rstrip("\n")) for p, t in pack.documents]
    src = dict(source_docs)
    compact_text = compact_path.read_text(encoding="utf-8")
    manifest_path = compact_path.with_name(compact_path.name[: -len(".txt")] + ".json")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    cdocs = split_system_text(compact_text, separator)
    cmp_ = dict(cdocs)
    r = Report()

    def identity():
        p = []
        if PACK_DIGESTS.get((ident.name, ident.version)) != ident.sha256:
            p.append("the source pack's digest is not the one the package pins")
        sp = manifest.get("source_pack", {})
        for k, v in (("name", ident.name), ("version", ident.version), ("sha256", ident.sha256), ("system_sha256", pack.manifest.system_sha256)):
            if sp.get(k) != v:
                p.append(f"the compact manifest's source_pack.{k} is {sp.get(k)!r}, not {v!r}")
        if C.sha256_text(compact_text) != manifest.get("compact", {}).get("sha256"):
            p.append("the compact file's SHA-256 is not the one its manifest records")
        if manifest.get("compact", {}).get("file") != compact_path.name:
            p.append("the manifest names another compact file")
        if manifest.get("format") != C.FORMAT:
            p.append(f"the manifest's format is {manifest.get('format')!r}, not {C.FORMAT!r}")
        return p, {"source_pack": f"{ident.name} {ident.version} {ident.sha256}", "compact_sha256": C.sha256_text(compact_text)}

    def deterministic():
        again, again_manifest = C.compile_pack(pack, manifest["compiler"]["sha256"])
        p = []
        if again != compact_text:
            p.append("compiling the source pack again gives other compact bytes")
        if C.render_manifest(again_manifest) != manifest_path.read_text(encoding="utf-8"):
            p.append("compiling the source pack again gives another manifest")
        if manifest["compiler"]["sha256"] != C.compiler_sha256():
            p.append("the manifest was written by another version of the compiler than the one beside this script")
        return p, {}

    def deletion_only():
        p = []
        if [x for x, _ in cdocs] != [x for x, _ in source_docs]:
            return [f"the compact pack's documents {[x for x, _ in cdocs]} are not the source system order"], {}
        if cmp_["master_prompt.txt"] != src["master_prompt.txt"]:
            p.append("the master prompt is not byte-identical")
        records = {d["path"]: d for d in manifest["documents"]}
        rebuilt_docs = []
        for path, text in source_docs:
            lines = text.split("\n")
            removed = sorted(records[path]["removed"], key=lambda x: x["first_line"])
            drop = set()
            for x in removed:
                seg = lines[x["first_line"] - 1: x["last_line"]]
                if C.sha256_text("\n".join(seg)) != x["sha256"] or len(seg) != x["lines"]:
                    p.append(f"{path}: the recorded removal at lines {x['first_line']}-{x['last_line']} is not that source segment")
                drop |= set(range(x["first_line"] - 1, x["last_line"]))
            kept = [line for i, line in enumerate(lines) if i not in drop]
            if kept != cmp_[path].split("\n"):
                p.append(f"{path}: the compact document is not its source lines minus the recorded removals")
            # put the removed segments back into the compact document: the source comes back exactly
            out, ci = [], iter(cmp_[path].split("\n"))
            for i in range(len(lines)):
                out.append(lines[i] if i in drop else next(ci, ""))
            rebuilt_docs.append((path, "\n".join(out) + "\n"))
        if build_system_text(rebuilt_docs, separator) != pack.system_text():
            p.append("putting the removed segments back does not give the source system text")
        return p, {"source_chars": len(pack.system_text()), "compact_chars": len(compact_text),
                   "removed_segments": sum(len(d["removed"]) for d in manifest["documents"]),
                   "removed_chars": len(pack.system_text()) - len(compact_text)}

    def removals_by_rule():
        p = []
        counts: dict[str, int] = {}
        for d in manifest["documents"]:
            lines = src[d["path"]].split("\n")
            for x in d["removed"]:
                rule, seg = x["rule"], lines[x["first_line"] - 1: x["last_line"]]
                counts[rule] = counts.get(rule, 0) + 1
                where = f"{d['path']} lines {x['first_line']}-{x['last_line']}"
                if rule not in C.RULES or rule == "sole-mention":
                    p.append(f"{where}: rule {rule} is not a removal rule this compiler applies")
                    continue
                for line in seg:
                    if _DEF_RE.match(line) or line.startswith("| ") or line.startswith("```") or line.startswith("#"):
                        p.append(f"{where}: the removed segment holds a coded rule, a table row, a fenced block or a heading: {line[:80]!r}")
                        break
                if rule == "scope-navigation":
                    ok = (seg[0].startswith("**It covers") or seg[0].startswith("**It does not cover")) and all(
                        line == "" or line.startswith("- ") or line.startswith("  ") for line in seg[1:]) and x["section"] == "## 1. Scope"
                else:  # footer
                    ok = x["last_line"] == len(lines) and re.match(r"^Pack version ", seg[-1]) is not None and all(line == "" for line in seg[:-1])
                if not ok:
                    p.append(f"{where}: the segment does not have the shape of rule {rule}")
        return p, {"removed_by_rule": counts}

    def decision_procedure():
        p = []
        mp_src, mp_cmp = src["master_prompt.txt"], cmp_.get("master_prompt.txt", "")
        if mp_cmp != mp_src:
            p.append("the master prompt is not byte-identical")
        found = 0
        for title in MASTER_PROMPT_BLOCKS:
            block = master_prompt_block(mp_src, title)
            if not block:
                p.append(f"the source master prompt has no block {title!r}")
            elif block not in compact_text:
                p.append(f"the master prompt block {title!r} is not in the compact pack verbatim")
            else:
                found += 1
        steps = re.findall(r"^([1-7])\. ", master_prompt_block(mp_src, "THE ORDER IN DETAIL"), re.M)
        if steps != [str(k) for k in range(1, 8)]:
            p.append(f"the order in detail has steps {steps}, not 1 to 7")
        return p, {"blocks": found, "steps": len(steps)}

    def kinds_and_codes():
        p = []
        s, c = src["06-kinds-and-codes.md"], cmp_["06-kinds-and-codes.md"]
        kinds = re.findall(r"^\| `([a-z_]+)` \|", section_text(s, 3), re.M)
        codes = sorted(set(_CODE_RE.findall(s)))
        families = sorted({a or b for a, b in _FAMILY_RE.findall(s)})
        suffixes = sorted(set(_SUFFIX_RE.findall(s)))
        for k in kinds:
            if not re.search(rf"^\| `{re.escape(k)}` \|", c, re.M):
                p.append(f"kind {k} is not in the compact Kinds and codes table")
        for code in codes + families + suffixes:
            if code not in c:
                p.append(f"code {code} of Kinds and codes is not in the compact pack's Kinds and codes")
        for n in range(2, 9):
            for line in section_text(s, n).split("\n"):
                if line and not line.startswith("Pack version ") and line not in c.split("\n"):
                    p.append(f"Kinds and codes §{n} line not kept: {line[:80]!r}")
        rows = []
        for line in section_text(c, 3).split("\n"):
            m = _KIND_ROW_RE.match(line)
            if m:
                col = m.group(2).strip()
                rows.append((m.group(1), tuple(re.findall(r"OVS-[A-Z]+-\d{3}", col)),
                             {cd: q for cd, q in re.findall(r"(OVS-[A-Z]+-\d{3}) \((INT-[A-Z]+-\d{3})\)", col)}))
        if [(k, cs) for k, cs, _ in rows] != list(KIND_CHECKS.items()):
            p.append("the compact kinds table differs from the package's KIND_CHECKS (kinds and codes, in order)")
        if {(k, cd): (q,) for k, _cs, qs in rows for cd, q in qs.items()} != dict(KIND_CODE_QUALIFIERS):
            p.append("the compact kinds table's qualified codes differ from the package's KIND_CODE_QUALIFIERS")
        return p, {"kinds": len(kinds), "codes": len(codes), "families": len(families), "suffix_codes": len(suffixes)}

    def coded_rules(docs: tuple[str, ...]):
        def run():
            p = []
            whole = compact_text
            n = 0
            for path in docs:
                sb, cb = rule_blocks(src[path]), rule_blocks(cmp_[path])
                for code, block in sb.items():
                    n += 1
                    if block not in whole:
                        p.append(f"{path} rule {code} is not in the compact pack verbatim")
                    if cb.get(code) != block:
                        p.append(f"{path} rule {code} differs in the compact {path}")
                for code in sorted(set(cb) - set(sb)):
                    p.append(f"the compact {path} defines {code}, which the source does not")
            return p, {"rules": n}
        return run

    def tokens_per_document():
        p, n = [], 0
        kinds = frozenset(re.findall(r"^\| `([a-z_]+)` \| ", src["06-kinds-and-codes.md"], re.M))
        for path, text in source_docs:
            body = "\n".join(line for line in text.split("\n") if not line.startswith("Pack version "))
            missing = C.protected_tokens(body, kinds) - C.protected_tokens(cmp_[path], kinds)
            n += len(C.protected_tokens(body, kinds))
            p += [f"{path} names {t}, which the compact {path} no longer names" for t in sorted(missing)]
        return p, {"tokens": n}

    def tables():
        p, n = [], 0
        for path, text in source_docs:
            clines = set(cmp_[path].split("\n"))
            for line in text.split("\n"):
                if line.startswith("| "):
                    n += 1
                    if line not in clines:
                        p.append(f"{path}: table row not kept: {line[:80]!r}")
        return p, {"table_rows": n}

    def quick_references_kept():
        p, n = [], 0
        for path, text in source_docs:
            for head, body in sections_by_heading(text):
                if head == "## 2. Quick reference":
                    n += 1
                    if body not in cmp_[path]:
                        p.append(f"{path}: its quick reference is not kept verbatim")
        return p, {"quick_references": n}

    def examples_whole():
        p, n = [], 0
        s, c = src["07-examples.md"], cmp_["07-examples.md"]
        for head, body in sections_by_heading(s):
            if _EXAMPLE_HEAD.match(head) or head.endswith("Wrong verdicts and the right ones"):
                n += 1
                if body not in c:
                    p.append(f"Examples: section {head!r} is not kept whole")
        source_examples = len(_EXAMPLE_HEAD.findall(s))
        if len(_EXAMPLE_HEAD.findall(c)) != source_examples:
            p.append("the compact Examples does not hold every example")
        return p, {"sections": n, "examples": source_examples}

    def verdict_format():
        p = []
        sk = section_text(src["05-verdict-format.md"], 3)
        if sk.strip() not in cmp_["05-verdict-format.md"]:
            p.append("the verdict skeleton (Verdict format §3) is not kept verbatim")
        n = 0
        for block in re.findall(r"^```json\n(.*?)\n```$", cmp_["07-examples.md"], re.S | re.M):
            obj = json.loads(block)
            if isinstance(obj, dict) and "contract" in obj:
                AgentVerdict.model_validate(obj)
                n += 1
        source_n = len([b for b in re.findall(r"^```json\n(.*?)\n```$", src["07-examples.md"], re.S | re.M) if '"contract"' in b])
        if n != source_n:
            p.append(f"{n} example verdicts kept of {source_n}")
        return p, {"example_verdicts_validated": n}

    def references_resolve():
        p = []
        defined = set()
        for _path, text in cdocs:
            defined |= set(rule_blocks(text))
        titles = {"Role and trust": "01-role-and-trust.md", "Dossier guide": "02-dossier.md", "Inspection": "03-inspection.md",
                  "Evidence rule": "04-evidence.md", "Verdict format": "05-verdict-format.md", "Kinds and codes": "06-kinds-and-codes.md",
                  "Examples": "07-examples.md", "Never": "08-never.md", "When unsure": "09-when-unsure.md"}
        examples = set(re.findall(r"^## \d+\. Example (\d+): ", cmp_["07-examples.md"], re.M))
        for path, text in cdocs:
            for m in _CITE_RE.finditer(text):
                if m.group(1) + m.group(2) not in defined:
                    p.append(f"{path} cites {m.group(1) + m.group(2)}, which the compact pack does not define")
            for doc, num in _SECTION_RE.findall(text):
                target = titles[doc] if doc else path
                if not re.search(rf"^## {num}\. ", cmp_[target], re.M):
                    p.append(f"{path} cites §{num} of {target}, which the compact pack does not hold")
            for num in re.findall(r"Example (\d+)\b", text):
                if num not in examples:
                    p.append(f"{path} cites Example {num}, which the compact pack does not hold")
        return p, {"rules_defined": len(defined)}

    r.run("identity", identity)
    r.run("deterministic", deterministic)
    r.run("deletion_only", deletion_only)
    r.run("removals_by_rule", removals_by_rule)
    r.run("decision_procedure", decision_procedure)
    r.run("kinds_and_codes", kinds_and_codes)
    r.run("never_and_when_unsure", coded_rules(("08-never.md", "09-when-unsure.md")))
    r.run("every_coded_rule", coded_rules(tuple(p for p, _ in source_docs if p != "master_prompt.txt")))
    r.run("codes_and_kinds_per_document", tokens_per_document)
    r.run("tables", tables)
    r.run("quick_references_kept", quick_references_kept)
    r.run("examples_whole", examples_whole)
    r.run("verdict_format", verdict_format)
    r.run("references_resolve", references_resolve)
    return r


def main(argv: Optional[list[str]] = None) -> int:
    ap = argparse.ArgumentParser(description="Prove a compact pack keeps every rule, kind, code, table and example of its source pack.")
    ap.add_argument("--pack", required=True, type=Path)
    ap.add_argument("--compact", required=True, type=Path)
    ap.add_argument("--src", type=Path)
    ap.add_argument("--out", type=Path, help="write the report here as JSON")
    args = ap.parse_args(argv)
    if args.src is not None:
        sys.path.insert(0, str(args.src.resolve()))
    rep = check(args.pack, args.compact)
    report = {"ok": rep.ok, "checks": rep.checks}
    text = json.dumps(report, indent=1, sort_keys=True, ensure_ascii=False) + "\n"
    if args.out:
        args.out.write_text(text, encoding="utf-8")
    print(text, end="")
    return 0 if rep.ok else 1


if __name__ == "__main__":
    sys.exit(main())
