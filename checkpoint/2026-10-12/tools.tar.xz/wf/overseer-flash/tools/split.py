#!/usr/bin/env python3
"""Split an instance's ONE verdicts file into the per-dossier reply files production validation reads.

    python -I split.py --bundles BUNDLE_DIR/bundles.json --instance AGENT_ID --verdicts FILE --out REPLIES_DIR
    python -I split.py --bundles BUNDLE_DIR/bundles.json --verdicts-dir DIR --out REPLIES_DIR     (each DIR/<instance>.verdicts.txt)
        [--mirror-out DIR] [--compact-manifest PACK.compact.json] [--no-info] [--force]

The splitter routes bytes; it never parses, validates, edits, completes or reorders a verdict. Each reply file holds,
byte for byte, what the agent wrote for that dossier; the package's intake then takes it exactly as it takes any reply
(strict parse, header and pack binding, signed envelope), so a verdict that does not parse stays invalid.

The format the agent writes, one block per dossier of its bundle (``bundles.json`` gives the tags):

    === VERDICT D1 ===
    {...the verdict of D1...}
    === VERDICT D2 ===
    {...}

Rules:

1. A label line is a line that is exactly ``=== VERDICT Dk ===`` (a trailing CR allowed), where Dk is a tag of this
   instance's bundle, at its FIRST occurrence. Every other line is verdict text: a repeated label line and a label for a
   tag the bundle does not hold included, so they stay inside the verdict they appear in.
2. A tag's reply runs from the end of its label line to the start of the next label line. The newline just before the
   next label line, and one newline at the end of the file, belong to the separator.
3. Text before the first label line belongs to the reply that follows it: the first reply starts at the beginning of the
   file, only the label line itself cut out. Nothing an agent wrote around a verdict is dropped, so a verdict with prose
   around it stays invalid, as it would be in production. A file with no label line is, whole, the reply of the bundle's
   first dossier (D1).
4. A tag without a label line has no reply: no file is written for its dossier, which counts as not reviewed.

Outputs in ``REPLIES_DIR``: ``<dossier_sha256>.json`` (the reply bytes; the scorer's and the intake's input), unless
``--no-info`` also ``<dossier_sha256>.info.json`` (bookkeeping, never evidence: ``prompt_version`` in the runner's form
naming the pack the dossier was issued under, and the deployment record: profile, bundle, verdicts file and, with
``--compact-manifest``, the compact pack's SHA-256 next to the source pack's), and ``split-<instance>.json`` (what was
found: labels in order, replies with their sizes and SHA-256, tags missing, text before the first label, label lines
read as verdict text). ``--mirror-out DIR`` also writes each reply to ``DIR/<the dossier's source path without its first
directory>`` (``dossiers/f1-1/d01.json`` -> ``DIR/f1-1/d01.json``) for evaluations that pair replies with dossier paths.

``join`` is the inverse: ``split(join(replies)) == replies`` for every set of replies none of which holds a label line
of a bundle tag (``join`` refuses one that does).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Iterable, Optional

PROFILE = "overseer-fast/2"
#: Bundle manifests this splitter reads: 1.1 adds the read parts, which the splitter does not use.
BUNDLE_FORMATS = ("overseer-bundles/1.0", "overseer-bundles/1.1")
_LABEL = re.compile(rb"=== VERDICT (D[1-9][0-9]{0,5}) ===\r?")
_TAG = re.compile(r"D[1-9][0-9]{0,5}")


class SplitError(ValueError):
    """A verdicts file or bundle manifest the splitter refuses. The message is the splitter's own text."""


def _lines_with_offsets(data: bytes) -> Iterable[tuple[int, int, int, bytes]]:
    """``(start, end of content, end including the newline, content)`` of every line."""
    pos, n = 0, len(data)
    while True:
        nl = data.find(b"\n", pos)
        if nl == -1:
            yield pos, n, n, data[pos:]
            return
        yield pos, nl, nl + 1, data[pos:nl]
        pos = nl + 1


def label_lines(data: bytes, tags: Iterable[str]) -> tuple[list[tuple[str, int, int]], int, int]:
    """``([(tag, start of the label line, end of it including its newline)], repeated label lines, unknown label lines)``."""
    tags = set(tags)
    out: list[tuple[str, int, int]] = []
    seen: set[str] = set()
    repeated = unknown = 0
    for start, _end, after, line in _lines_with_offsets(data):
        m = _LABEL.fullmatch(line)
        if not m:
            continue
        tag = m.group(1).decode("ascii")
        if tag not in tags:
            unknown += 1
        elif tag in seen:
            repeated += 1
        else:
            seen.add(tag)
            out.append((tag, start, after))
    return out, repeated, unknown


def split_bytes(data: bytes, tags: list[str]) -> tuple[dict[str, bytes], dict]:
    """``({tag: reply bytes}, facts)`` by rules 1 to 4."""
    if not tags or any(not _TAG.fullmatch(t) for t in tags) or len(set(tags)) != len(tags):
        raise SplitError("the bundle's tags are not D1, D2, ... once each")
    labels, repeated, unknown = label_lines(data, tags)
    facts = {"labels": [t for t, _s, _e in labels], "label_lines_repeated": repeated, "label_lines_unknown": unknown,
             "prefix_bytes": labels[0][1] if labels else len(data), "unlabelled": not labels}
    if not labels:
        return {tags[0]: data}, facts
    replies: dict[str, bytes] = {}
    for k, (tag, _start, after) in enumerate(labels):
        if k + 1 < len(labels):
            nxt = labels[k + 1][1]
            seg = data[after: max(after, nxt - 1)]
        else:
            seg = data[after:]
            if seg.endswith(b"\n"):
                seg = seg[:-1]
        replies[tag] = (data[:labels[0][1]] + seg) if k == 0 else seg
    return replies, facts


def join(replies: dict[str, bytes], tags: list[str]) -> bytes:
    """The canonical verdicts file of ``replies`` (bundle tag order). Refuses a reply holding a label line of a tag."""
    known = set(tags)
    parts = []
    for tag in tags:
        if tag not in replies:
            continue
        for _s, _e, _a, line in _lines_with_offsets(replies[tag]):
            m = _LABEL.fullmatch(line)
            if m and m.group(1).decode("ascii") in known:
                raise SplitError(f"the reply for {tag} holds a label line; it cannot be joined unambiguously")
        parts.append(b"=== VERDICT " + tag.encode("ascii") + b" ===\n" + replies[tag] + b"\n")
    unknown = set(replies) - known
    if unknown:
        raise SplitError(f"replies for tags the bundle does not hold: {sorted(unknown)}")
    return b"".join(parts)


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _write(path: Path, data: bytes, force: bool) -> None:
    if path.exists() and path.read_bytes() != data and not force:
        raise SplitError(f"{path.name} already exists with other content (use --force to replace it)")
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_bytes(data)
    tmp.replace(path)


def split_instance(manifest: dict, instance: str, verdicts: Path, out: Path, *, mirror_out: Optional[Path] = None,
                   compact: Optional[dict] = None, info: bool = True, force: bool = False, bundle_dir: Optional[Path] = None) -> dict:
    rec = next((r for r in manifest["instances"] if r["agent_id"] == instance), None)
    if rec is None:
        raise SplitError(f"{instance!r} has no bundle in this manifest")
    if bundle_dir is not None:
        bundle = bundle_dir / rec["bundle"]
        if not bundle.is_file() or _sha(bundle.read_bytes()) != rec["sha256"]:
            raise SplitError(f"the bundle of {instance!r} is missing or is not the one the manifest records")
    data = verdicts.read_bytes()
    tags = [d["tag"] for d in rec["dossiers"]]
    replies, facts = split_bytes(data, tags)
    by_tag = {d["tag"]: d for d in rec["dossiers"]}
    written = {}
    for tag, reply in replies.items():
        d = by_tag[tag]
        _write(out / f"{d['dossier_sha256']}.json", reply, force)
        if info:
            deployment = {"profile": PROFILE, "agent_id": instance, "tag": tag, "bundle_sha256": rec["sha256"], "layout": manifest["layout"],
                          "verdicts_sha256": _sha(data), "reply_sha256": _sha(reply)}
            if compact is not None:
                deployment["compact_pack_sha256"] = compact["compact"]["sha256"]
                deployment["source_pack_sha256"] = compact["source_pack"]["sha256"]
            body = {"prompt_version": manifest["prompt_version"], "deployment": deployment}
            _write(out / f"{d['dossier_sha256']}.info.json", (json.dumps(body, indent=1, sort_keys=True) + "\n").encode("utf-8"), force)
        if mirror_out is not None:
            rel = Path(d["source"])
            parts = rel.parts[1:] if len(rel.parts) > 1 else rel.parts
            target = (mirror_out / Path(*parts)).resolve()
            if mirror_out.resolve() not in target.parents:
                raise SplitError("a mirrored path would leave the mirror directory")
            _write(target, reply, force)
        written[tag] = {"dossier_sha256": d["dossier_sha256"], "bytes": len(reply), "sha256": _sha(reply)}
    report = {"format": "overseer-split/1.0", "agent_id": instance, "bundle_sha256": rec["sha256"], "verdicts_sha256": _sha(data),
              "verdicts_bytes": len(data), **facts, "replies": written, "missing": [t for t in tags if t not in replies]}
    _write(out / f"split-{instance}.json", (json.dumps(report, indent=1, sort_keys=True) + "\n").encode("utf-8"), True)
    return report


def main(argv: Optional[list[str]] = None) -> int:
    ap = argparse.ArgumentParser(description="Split one verdicts file per instance into per-dossier reply files.")
    ap.add_argument("--bundles", required=True, type=Path, help="bundles.json written by bundle.py")
    ap.add_argument("--instance", help="one instance (with --verdicts)")
    ap.add_argument("--verdicts", type=Path, help="that instance's verdicts file")
    ap.add_argument("--verdicts-dir", type=Path, help="a directory of <instance>.verdicts.txt files (every instance)")
    ap.add_argument("--out", required=True, type=Path, help="the replies directory")
    ap.add_argument("--mirror-out", type=Path)
    ap.add_argument("--compact-manifest", type=Path)
    ap.add_argument("--no-info", action="store_true")
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args(argv)
    try:
        manifest = json.loads(args.bundles.read_text(encoding="utf-8"))
        if manifest.get("format") not in BUNDLE_FORMATS:
            raise SplitError(f"the bundles manifest is not of a format this splitter reads ({', '.join(BUNDLE_FORMATS)})")
        compact = json.loads(args.compact_manifest.read_text(encoding="utf-8")) if args.compact_manifest else None
        if compact is not None and compact["source_pack"]["sha256"] != manifest["pack"]["sha256"]:
            raise SplitError("the compact pack was compiled from another pack than the one the dossiers were issued under")
        jobs = []
        if args.instance or args.verdicts:
            if not (args.instance and args.verdicts):
                raise SplitError("--instance and --verdicts go together")
            jobs.append((args.instance, args.verdicts))
        elif args.verdicts_dir:
            for r in manifest["instances"]:
                p = args.verdicts_dir / r["verdicts_file"]
                jobs.append((r["agent_id"], p))
        else:
            raise SplitError("give --instance with --verdicts, or --verdicts-dir")
        args.out.mkdir(parents=True, exist_ok=True)
        reports, absent = [], []
        for inst, path in jobs:
            if not path.is_file():
                absent.append(inst)
                continue
            reports.append(split_instance(manifest, inst, path, args.out, mirror_out=args.mirror_out, compact=compact,
                                          info=not args.no_info, force=args.force, bundle_dir=args.bundles.parent))
    except (SplitError, OSError, KeyError, ValueError) as exc:
        print(json.dumps({"ok": False, "error": f"{type(exc).__name__}: {exc}"}))
        return 2
    print(json.dumps({"ok": True, "instances_split": len(reports), "instances_without_verdicts_file": absent,
                      "replies": sum(len(r["replies"]) for r in reports), "missing": sum(len(r["missing"]) for r in reports),
                      "with_text_before_first_label": sum(1 for r in reports if r["labels"] and r["prefix_bytes"]),
                      "unlabelled": sum(1 for r in reports if r["unlabelled"])}))
    return 0


if __name__ == "__main__":
    sys.exit(main())
