"""Score a two-arm overseer pilot: rebuild the intake from records/, validate every verdict with the package's own
intake and validation (score_verdicts.assess_export, as production does), combine per transfer with combine_verdicts,
and score each arm separately with the package's scorer against gold/.

    python -I score_pilot.py TREE PILOT_DIR OUT.json [TIMING.json]

Reply text is data: it goes to the intake unchanged and is never executed."""
import json
import sys
from collections import defaultdict
from pathlib import Path

TREE = Path(sys.argv[1]); R = Path(sys.argv[2]); OUTF = Path(sys.argv[3])
TIMING = Path(sys.argv[4]) if len(sys.argv) > 4 else None
sys.path.insert(0, str(TREE / "scripts" / "overseer"))
import ovs_harness as H  # noqa: E402
import score_verdicts as S  # noqa: E402
from epinoic_logic.overseer.combine import combine_verdicts  # noqa: E402

arms = H.read_json(R / "records" / "arms.json")
gold = H.read_json(R / "gold" / "gold.json")["transfers"]


def replies_for(arm: str, issues: list[dict]):
    replies, infos, missing = {}, {}, []
    if arm == "a":   # verdicts/a-<i>/dNN.json answers dossiers/a-<i>/dNN.json
        for i in issues:
            vp = R / i["dossier"].replace("dossiers/", "verdicts/", 1)
            if vp.is_file():
                replies[i["issue"]["dossier_sha256"]] = vp.read_text(encoding="utf-8", errors="replace")
            else:
                missing.append(i["dossier"])
    else:            # verdicts/b-<i>/<dossier_sha256>.json, written by split.py
        for i in issues:
            d = R / "verdicts" / Path(i["dossier"]).parts[1]
            r, inf, _ign = S.read_replies(d) if d.is_dir() else ({}, {}, [])
            sha = i["issue"]["dossier_sha256"]
            if sha in r:
                replies[sha] = r[sha]
                if sha in inf:
                    infos[sha] = inf[sha]
            else:
                missing.append(i["dossier"])
    return replies, infos, missing


def score_arm(arm: str) -> dict:
    rec_dir = R / arms[arm]
    wave = H.read_json(rec_dir / "wave.json")
    plan = H.read_json(rec_dir / "pool_plan.json")
    pack = H.load_exported_pack(Path(wave["pack_dir"]))
    assert pack.identity.model_dump() == wave["pack"], "pack identity differs from the wave's"
    issues = []
    for line in (rec_dir / "issues.jsonl").read_text(encoding="utf-8").splitlines():
        if line.strip():
            i = json.loads(line)
            i["variant_id"] = i["transfer"]       # gold is keyed by opaque transfer id
            issues.append(i)
    export = S.Export(root=R, meta={"pack": wave["pack"]}, issues=issues, gold=gold, index=H.read_json(rec_dir / "index.json"))
    replies, infos, missing = replies_for(arm, issues)
    assessed = S.assess_export(export, {pack.identity}, S.text_responder(replies, infos))
    scores = S.score(assessed, gold)
    per = next(iter(scores["per_pack"].values())) if len(scores["per_pack"]) == 1 else None

    rows = []
    for a in assessed:
        r = {"dossier": a.issue["dossier"], "transfer": a.variant_id, "agent_id": a.agent_id, "status": a.status, "reason": a.reason}
        if a.assessment is not None:
            r["valid"] = a.assessment.valid
            r["invalid_reason"] = getattr(a.assessment, "invalid_reason", None)
            r["accusations"] = [{"id": x.accusation_id, "kind": x.kind, "outcome": x.outcome, "refuted_by": x.refuted_by}
                                for x in a.assessment.accusations]
        rows.append(r)
    valid = [a for a in assessed if a.status == "assessed" and a.assessment is not None and a.assessment.valid]
    invalid_rows = [r for r in rows if not (r["status"] == "assessed" and r.get("valid"))]

    by_t = defaultdict(list)
    for a in valid:
        by_t[a.variant_id].append(a)
    per_transfer, greenlit = {}, []
    faults_present = faults_named = faults_confirmed = 0
    fa_made_unaccepted = fa_accepted = 0
    for oid, g in sorted(gold.items()):
        group = by_t.get(oid, [])
        faults = [f for f in g.get("faults", []) if f.get("agent_scorable", True) and S.fault_visible(f, "blind")]
        faults_present += len(faults)
        named, confirmed = set(), set()
        entry = {"verdicts_valid": len(group), "instances": sorted(a.agent_id for a in group), "gold_clean": bool(g.get("clean"))}
        if group:
            r2m = group[0].receipt_to_message
            faulty = S._faulty_messages(g.get("faults", []), r2m)
            for a in group:
                for x in a.assessment.accusations:
                    ai = {k: set(v) for k, v in x.identifiers.items()}
                    for k in S.ID_KINDS + ("receipt_ids",):
                        ai.setdefault(k, set())
                    hit = [f for f in g.get("faults", []) if f.get("agent_scorable", True)
                           and S.matches(x.kind, ai, f, r2m, claim_reports=getattr(x, "claim_report_ids", None))]
                    for f in hit:
                        named.add(f["fault_id"])
                        if x.outcome == "confirmed":
                            confirmed.add(f["fault_id"])
                    msgs = S._acc_messages(ai, r2m)
                    on_clean = bool(msgs) and not (msgs & faulty)
                    if not hit and on_clean:
                        if x.outcome == "confirmed":
                            fa_accepted += 1
                        else:
                            fa_made_unaccepted += 1
            comb = combine_verdicts([a.assessment for a in group], intake=group[0].intake)
            outs = [gr.outcome for gr in comb.groups]
            entry["groups"] = [{"kind": gr.kind, "outcome": gr.outcome, "support": gr.support, "outcome_support": gr.outcome_support}
                               for gr in comb.groups]
            entry["review_queue"] = len(comb.review_queue)
            entry["outcome"] = ("confirmed" if "confirmed" in outs else "unresolved" if "unresolved" in outs
                                else "refuted" if outs else "no_accusation")
        else:
            entry["outcome"] = "not_judged"
        nf = len([f for f in faults if f["fault_id"] in named])
        faults_named += nf
        faults_confirmed += len([f for f in faults if f["fault_id"] in confirmed])
        entry.update(faults_present=len(faults), faults_named=nf)
        # green-lit: judged, and the combined outcome raises nothing (no confirmed and no unresolved group)
        entry["greenlit"] = entry["outcome"] in ("no_accusation", "refuted")
        if entry["greenlit"]:
            greenlit.append(oid)
        per_transfer[oid] = entry

    fa = per["false_accusations"] if per else {}
    status_counts = defaultdict(int)
    for a in assessed:
        status_counts["assessed_invalid" if a.status == "assessed" and not a.assessment.valid else a.status] += 1
    return {
        "arm": arm, "plan_id": plan["plan_id"], "pool_config": wave.get("pool_config"),
        "instances": len(plan["instances"]), "dossiers_issued": len(issues), "verdict_files": len(replies),
        "verdict_files_missing": missing, "status": dict(status_counts),
        "verdicts_valid": len(valid), "verdicts_invalid": len(issues) - len(valid), "not_validated": invalid_rows,
        "transfers": len(gold), "transfers_judged": sum(1 for e in per_transfer.values() if e["outcome"] != "not_judged"),
        "faults_present": faults_present, "faults_named": faults_named, "faults_confirmed": faults_confirmed,
        "false_accusations": {"package_scorer": {k: v for k, v in fa.items() if k != "unadjudicated"},
                              "on_gold_clean_messages_confirmed": fa_accepted,
                              "on_gold_clean_messages_not_confirmed": fa_made_unaccepted},
        "greenlit": greenlit,
        "greenlit_with_gold_faults": [t for t in greenlit if per_transfer[t]["faults_present"]],
        "contradictions_with_signed_results": per.get("contradictions_with_signed_results") if per else None,
        "gates": per.get("gates") if per else None,
        "per_transfer": per_transfer, "assessments": rows, "package_scores": scores,
    }


result = {"format": "overseer-pilot-score/1.0", "pilot": "p1",
          "greenlit_definition": "a judged transfer whose combined outcome (combine_verdicts over that arm's valid verdicts) has no confirmed and no unresolved group",
          "arms": {arm: score_arm(arm) for arm in ("a", "b")}}
if TIMING is not None:
    t = H.read_json(TIMING)
    for arm in ("a", "b"):
        result["arms"][arm]["timing"] = t.get(arm)
OUTF.write_text(json.dumps(result, indent=1, sort_keys=True, default=str) + "\n", encoding="utf-8")
for arm, r in result["arms"].items():
    print(arm, json.dumps({k: r[k] for k in ("instances", "dossiers_issued", "verdict_files", "status", "verdicts_valid", "verdicts_invalid",
                                             "transfers_judged", "faults_present", "faults_named", "faults_confirmed", "false_accusations",
                                             "contradictions_with_signed_results", "greenlit", "greenlit_with_gold_faults")}, default=str))
    print(" invalid:", json.dumps([{k: x.get(k) for k in ("dossier", "status", "reason", "invalid_reason")} for x in r["not_validated"]], default=str)[:3000])
