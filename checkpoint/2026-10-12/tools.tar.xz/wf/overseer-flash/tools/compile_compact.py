#!/usr/bin/env python3
"""Compile an exported overseer knowledge pack into ONE compact pack file, deterministically.

    python -I compile_compact.py --pack EXPORTED_PACK_DIR_OR_ZIP --out OUT_DIR [--src SRC_DIR]

The pack is loaded by the package's own loader (``epinoic_logic.overseer.pack.load_pack``): every file is checked
against the manifest and the manifest against the digest the package pins, so a pack the package does not accept is
refused and a compact pack always descends from a pinned pack. ``--src`` puts another source tree's package first on
the import path (its own pins then apply).

The compact pack is the pack's system text, built by the package's own rule and separator (``build_system_text``: the
master prompt, then the numbered documents in system order), with ONLY the segments below removed, each by one fixed
rule. Nothing is added, reworded or reordered: every line of the compact pack is a line of the source system text, in
the same order, and putting the removed segments back gives the source system text exactly (``check_compact.py`` proves
both). The master prompt is never touched. The deployer README, the two schemas and the manifest are not part of the
system text and never reach the agent.

Rules of compiler version 2 (each removed segment is addressed to no reviewer: it says where a document's subject is
handled, or which pack version printed the page):

* ``scope-navigation``: in each ``## 1. Scope`` section, the ``**It covers...`` list and the ``**It does not cover.**``
  list, which only say which document holds what (the master prompt's own list of documents says it once). The lead
  paragraph and every other paragraph of the section (the ``(enforced)`` notes, the conventions of Examples) are kept.
* ``footer``: the closing ``Pack version ...`` line (pack metadata; the compact manifest records the identity instead).

Retired rules of compiler version 1, recorded in the manifest with the reason: ``quick-reference`` (each document's
``## 2. Quick reference``) and ``example-excerpt`` (the dossier excerpt of each worked example). Pilot p1 measured that
an instance's time is set by its hidden reasoning, not by the length of what it reads, so the 61,593 characters those
two rules removed bought no speed; they are the pack's own restatement of its core rules and its concrete worked
dossiers (nine of them genuine, with an empty verdict), so version 2 keeps them.

Guard (``sole-mention``): a candidate segment is NOT removed when it names a code (``OVS-*``, ``INT-*``, branch codes),
a code family (``OVS-AGENT-*``) or an accusation kind that the kept text of its own document no longer names, so every
code, family and kind a document states survives in that document (Kinds and codes keeps the Scope line that names the
``OVS-AGENT-*`` family). Removals never hold a coded rule's definition.

A pack whose structure differs from what these rules expect (a document that does not open with its Scope, a Scope
without both lists, a footer that does not name the pack) is refused with the reason, so a changed pack is never
compacted by rules written for another one.

Outputs, in ``OUT_DIR`` (nothing is written anywhere else, and nothing holds a path outside it):

* ``<pack>-<version>.compact.txt``: the compact pack (UTF-8, LF);
* ``<pack>-<version>.compact.json``: the compact manifest: the compact file's SHA-256 next to the source pack's identity,
  pack digest and system digest, every removed segment (rule, document, section, line range, size, SHA-256), the rules,
  the retired rules and the compiler's version and SHA-256. No timestamp: the same pack and compiler give the same bytes.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any, Optional

FORMAT = "overseer-compact-pack/2.0"
COMPILER = "compile_compact"
COMPILER_VERSION = "2.0"
MASTER_PROMPT = "master_prompt.txt"

#: The removal rules, by id. The compact manifest carries this text, so a reader of the manifest knows each rule.
RULES: dict[str, str] = {
    "scope-navigation": "In a '## 1. Scope' section, the '**It covers' list and the '**It does not cover.**' list (which document holds "
                        "what) are removed; the lead paragraph and every other paragraph are kept.",
    "footer": "The closing 'Pack version ...' line of a document is removed (pack metadata; the compact manifest records the identity).",
    "sole-mention": "Guard on every rule above: a segment that names a code, a code family or an accusation kind that the kept text of its "
                    "own document no longer names is kept.",
}

#: Rules of compiler version 1 that version 2 no longer applies, and why. Recorded in the manifest.
RETIRED_RULES: dict[str, str] = {
    "quick-reference": "Version 1 removed each '## 2. Quick reference' (a numbered restatement of the document's core rules). Kept since "
                       "version 2: pilot p1 measured that time is set by hidden reasoning, not by the length read, so the removal bought "
                       "no speed, and the restatement is the pack's own emphasis of the rules a fast reviewer most needs.",
    "example-excerpt": "Version 1 removed each worked example's dossier excerpt. Kept since version 2: the excerpts are the pack's concrete "
                       "calibration of what is and is not a fault (nine examples are genuine dossiers with an empty verdict), and their "
                       "removal bought no measurable speed in pilot p1.",
}

_H2 = re.compile(r"^## (\d+)\. (.+)$")
_FOOTER = re.compile(r"^Pack version (?P<version>[0-9]+\.[0-9]+) · (?P<name>[a-z0-9-]+) · .+$")
_CODE = re.compile(r"\b(?:OVS|INT|CORE|HI|ES|GEN|ST)-[A-Z]+-\d{3}\b")
_FAMILY = re.compile(r"\b(?:OVS|INT|CORE|HI|ES|GEN|ST)(?:-[A-Z]+)?-\*")
_KIND_ROW = re.compile(r"^\| `([a-z_]+)` \| ", re.M)
KINDS_DOCUMENT = "06-kinds-and-codes.md"


def protected_tokens(text: str, kinds: frozenset[str]) -> set[str]:
    """The codes, code families and accusation kinds a text names."""
    out = set(_CODE.findall(text)) | set(_FAMILY.findall(text))
    out |= {k for k in re.findall(r"`([a-z_]+)`", text) if k in kinds}
    return out


class CompileError(ValueError):
    """A pack these rules were not written for, or one the package refuses. The message is the compiler's own text."""


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _sections(lines: list[str]) -> list[tuple[int, int, int, str]]:
    """``(start, end, number, title)`` of every ``## N. Title`` section; ``end`` exclusive."""
    heads = [(i, int(m.group(1)), m.group(2)) for i, line in enumerate(lines) if (m := _H2.match(line))]
    return [(i, heads[k + 1][0] if k + 1 < len(heads) else len(lines), n, t) for k, (i, n, t) in enumerate(heads)]


def _scope_drops(path: str, lines: list[str], start: int, end: int) -> list[tuple[int, int]]:
    drops: list[tuple[int, int]] = []
    seen = {"covers": False, "not": False}
    i = start + 1
    while i < end:
        line = lines[i]
        if line.startswith("**It covers") or line.startswith("**It does not cover"):
            seen["covers" if line.startswith("**It covers") else "not"] = True
            j = i + 1
            while j < end and (lines[j] == "" or lines[j].startswith("- ") or lines[j].startswith("  ")):
                j += 1
            drops.append((i, j))
            i = j
        else:
            i += 1
    if not all(seen.values()):
        raise CompileError(f"{path}: its Scope section does not hold both the 'It covers' and the 'It does not cover' list")
    return drops


def _drop_set(ranges: list[tuple[str, int, int, str]]) -> set[int]:
    return {i for _rule, a, b, _sec in ranges for i in range(a, b)}


def plan_removals(documents: list[tuple[str, str]], pack_name: str, pack_version: str) -> dict[str, list[tuple[str, int, int, str]]]:
    """``{path: [(rule, first index, end index exclusive, section heading)]}`` over each document's lines
    (``text.rstrip('\\n').split('\\n')``), sorted by position. The master prompt has none."""
    if not documents or documents[0][0] != MASTER_PROMPT:
        raise CompileError("the system order does not open with the master prompt")
    texts = {p: t.rstrip("\n").split("\n") for p, t in documents}
    candidates: dict[str, list[tuple[str, int, int, str]]] = {}
    for path, lines in texts.items():
        if path == MASTER_PROMPT:
            candidates[path] = []
            continue
        out: list[tuple[str, int, int, str]] = []
        secs = _sections(lines)
        if not secs or secs[0][2] != 1 or secs[0][3] != "Scope":
            raise CompileError(f"{path}: the document does not open with '## 1. Scope'")
        start, end, _num, _title = secs[0]
        out += [("scope-navigation", a, b, lines[start]) for a, b in _scope_drops(path, lines, start, end)]
        m = _FOOTER.match(lines[-1])
        if m is None or (m.group("name"), m.group("version")) != (pack_name, pack_version):
            raise CompileError(f"{path}: the last line is not the footer naming {pack_name} {pack_version}")
        a = len(lines) - 1
        while a > 0 and lines[a - 1] == "":
            a -= 1
        out.append(("footer", a, len(lines), lines[secs[-1][0]]))
        candidates[path] = out
    # guard sole-mention: a segment naming a code, family or kind its document's kept text no longer names stays, until stable
    kinds = frozenset(_KIND_ROW.findall(dict(documents).get(KINDS_DOCUMENT, "")))
    if not kinds:
        raise CompileError(f"{KINDS_DOCUMENT} has no kinds table")
    changed = True
    while changed:
        changed = False
        for path in candidates:
            lines = texts[path]
            for seg in list(candidates[path]):
                dropped = _drop_set(candidates[path])
                kept_text = "\n".join(line for i, line in enumerate(lines) if i not in dropped)
                if protected_tokens("\n".join(lines[seg[1]:seg[2]]), kinds) - protected_tokens(kept_text, kinds):
                    candidates[path].remove(seg)
                    changed = True
    for path in candidates:
        candidates[path].sort(key=lambda r: r[1])
        last = -1
        for _rule, a, b, _sec in candidates[path]:
            if a < last or b <= a:
                raise CompileError(f"{path}: removals overlap or are empty (lines {a + 1}-{b})")
            last = b
    return candidates


def compile_documents(documents: list[tuple[str, str]], separator: str, pack_name: str, pack_version: str) -> tuple[str, list[dict]]:
    """``(compact text, per-document records)``. Pure: the same documents give the same bytes."""
    from epinoic_logic.overseer.pack import build_system_text

    removals = plan_removals(documents, pack_name, pack_version)
    compact_docs: list[tuple[str, str]] = []
    records: list[dict] = []
    for path, text in documents:
        lines = text.rstrip("\n").split("\n")
        dropped = _drop_set(removals[path])
        kept = [line for i, line in enumerate(lines) if i not in dropped]
        compact_docs.append((path, "\n".join(kept) + "\n"))
        records.append({
            "path": path, "source_lines": len(lines), "kept_lines": len(kept), "source_chars": len(text.rstrip("\n")),
            "compact_chars": len("\n".join(kept)),
            "removed": [{"rule": rule, "section": sec, "first_line": a + 1, "last_line": b, "lines": b - a,
                         "chars": len("\n".join(lines[a:b])), "sha256": sha256_text("\n".join(lines[a:b]))}
                        for rule, a, b, sec in removals[path]],
        })
    return build_system_text(compact_docs, separator), records


def compile_pack(pack: Any, compiler_sha256: str) -> tuple[str, dict]:
    """``(compact text, compact manifest)`` for a pack loaded by ``load_pack``."""
    ident = pack.identity
    documents = [(p, t) for p, t in pack.documents]
    compact, records = compile_documents(documents, pack.manifest.system_separator, ident.name, ident.version)
    files = {f.path: f.sha256 for f in pack.manifest.files}
    stem = f"{ident.name}-{ident.version}"
    compact_sha = sha256_text(compact)
    source_system = pack.system_text()
    manifest = {
        "format": FORMAT,
        "trace": f"compact {compact_sha} compiled from {ident.name} {ident.version} pack {ident.sha256}",
        "compact": {"file": f"{stem}.compact.txt", "sha256": compact_sha, "bytes": len(compact.encode("utf-8")), "chars": len(compact),
                    "lines": compact.count("\n"), "approx_tokens_chars_div_4": len(compact) // 4},
        "source_pack": {"name": ident.name, "version": ident.version, "sha256": ident.sha256, "system_sha256": pack.manifest.system_sha256,
                        "system_chars": len(source_system), "system_separator": pack.manifest.system_separator,
                        "system_order": list(pack.manifest.system_order),
                        "documents": [{"path": p, "sha256": files[p]} for p in pack.manifest.system_order],
                        "prompt_version": pack.prompt_version},
        "compiler": {"name": COMPILER, "version": COMPILER_VERSION, "sha256": compiler_sha256, "rules": RULES, "retired_rules": RETIRED_RULES},
        "documents": records,
    }
    return compact, manifest


def render_manifest(manifest: dict) -> str:
    return json.dumps(manifest, indent=1, sort_keys=True, ensure_ascii=False) + "\n"


def compiler_sha256() -> str:
    return hashlib.sha256(Path(__file__).read_bytes()).hexdigest()


def load_source_pack(pack_path: Path) -> Any:
    from epinoic_logic.overseer.pack import PackError, load_pack
    try:
        return load_pack(pack_path)
    except PackError as exc:
        raise CompileError(f"the package refuses the pack ({exc.reason})") from None


def _write(path: Path, text: str) -> None:
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(text, encoding="utf-8", newline="\n")
    tmp.replace(path)


def main(argv: Optional[list[str]] = None) -> int:
    ap = argparse.ArgumentParser(description="Compile an exported overseer knowledge pack into one compact pack file.")
    ap.add_argument("--pack", required=True, type=Path, help="exported pack directory (or zip) the package's loader accepts")
    ap.add_argument("--out", required=True, type=Path, help="output directory")
    ap.add_argument("--src", type=Path, help="a source tree's src directory to import the package from (default: the installed one)")
    args = ap.parse_args(argv)
    if args.src is not None:
        sys.path.insert(0, str(args.src.resolve()))
    try:
        pack = load_source_pack(args.pack)
        compact, manifest = compile_pack(pack, compiler_sha256())
    except CompileError as exc:
        print(json.dumps({"ok": False, "error": str(exc)}))
        return 2
    args.out.mkdir(parents=True, exist_ok=True)
    stem = f"{pack.identity.name}-{pack.identity.version}"
    _write(args.out / f"{stem}.compact.txt", compact)
    _write(args.out / f"{stem}.compact.json", render_manifest(manifest))
    print(json.dumps({"ok": True, "compact": manifest["compact"], "source_pack": {k: manifest["source_pack"][k] for k in ("name", "version", "sha256",
                      "system_sha256", "system_chars")}, "removed": sum(len(d["removed"]) for d in manifest["documents"])}))
    return 0


if __name__ == "__main__":
    sys.exit(main())
