"""Per-arm wall seconds and turns of pilot overseer transcripts (label pilot-overseer:<pilot>:<arm>-<i>).
    python -I pilot_timing.py WORKFLOWS_DIR PILOT OUT.json
Wall = last minus first transcript timestamp; turns = distinct assistant message ids."""
import collections, datetime, glob, json, re, statistics, sys
D, P, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
lab = re.compile(r"pilot-overseer:%s:([A-Za-z])-(\d+)$" % re.escape(P))
ts = lambda s: datetime.datetime.fromisoformat(s.replace("Z", "+00:00"))
per = collections.defaultdict(list)
for meta in sorted(glob.glob(D + "/*/agent-*.meta.json")):
    m = json.load(open(meta)); mm = lab.fullmatch(m.get("description", ""))
    if not mm:
        continue
    lines = [json.loads(l) for l in open(meta[: -len(".meta.json")] + ".jsonl") if l.strip()]
    T = [ts(l["timestamp"]) for l in lines if "timestamp" in l]
    ids = {l["message"].get("id") for l in lines if l.get("type") == "assistant"}
    per[mm.group(1).lower()].append({"instance": f"{mm.group(1).lower()}-{mm.group(2)}", "wall_s": round((max(T) - min(T)).total_seconds(), 1) if T else None,
                                     "turns": len(ids), "workflow": meta.split("/")[-2]})
out = {}
for arm, rows in sorted(per.items()):
    rows.sort(key=lambda r: int(r["instance"].split("-")[1]))
    w = [r["wall_s"] for r in rows if r["wall_s"] is not None]
    out[arm] = {"transcripts": len(rows), "instances_distinct": len({r["instance"] for r in rows}),
                "seconds_median": statistics.median(w), "seconds_max": max(w), "turns_median": statistics.median(r["turns"] for r in rows),
                "seconds_sum": round(sum(w), 1), "per_instance": rows}
json.dump(out, open(OUT, "w"), indent=1, sort_keys=True)
print(json.dumps({a: {k: v for k, v in r.items() if k != "per_instance"} for a, r in out.items()}))
for a, r in out.items():
    print(a, [(x["instance"], x["wall_s"], x["turns"]) for x in r["per_instance"]])
