#!/usr/bin/env python3
"""Re-plan a recorded wave under another pool configuration and re-issue its blind dossiers through the package's intake.

    python -I reissue.py --tree TREE --from RUN_DIR --out NEW_RUN_DIR [--quota 1] [--max-instances 64] [--base-agent-id ovs-f1]

This measures the fast profile on the same material as a recorded wave. Nothing here decides the plan: the pool items
(one per channel, keyed by channel uid, with the repeated faults the recorded plan carries) go to the package's
``OverseerPool`` under the new ``PoolConfig`` (``per_instance_quota``, ``max_instances``; mode and lens stay the recorded
plan's), and its ``plan`` decides how many instances there are and which instance reviews which channel, duplicates
included. For every assignment, the channel is rebuilt from its transfer record with the package's harness tooling
(``ovs_harness.load_record`` and ``rebuild``: the record's signed audit must verify) and a ``VerdictIntake`` of that
channel issues one dossier to that instance (``intake.issue``), exactly as the recorded wave was issued. The dossier's
digest is checked against the intake's issue record, and the file is the intake's canonical JSON.

Outputs, in ``NEW_RUN_DIR`` (the recorded wave is only read): ``records/transfers/`` (the opaque transfer records,
copied), ``records/pool_plan.json``, ``records/issues.jsonl``, ``records/index.json``, ``records/wave.json`` and
``dossiers/<instance>/dNN.json`` (opaque names: the instance id and a number). ``--copy-gold`` copies the recorded
``gold/gold.json`` byte for byte (it is keyed by the same opaque transfer ids) and writes a new ``gold/opaque_map.json``
for the new dossier names; this tool never parses the gold.
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path
from typing import Optional


def main(argv: Optional[list[str]] = None) -> int:
    ap = argparse.ArgumentParser(description="Re-plan a recorded wave under another pool configuration and re-issue its dossiers.")
    ap.add_argument("--tree", required=True, type=Path, help="the source tree (its src/ and scripts/overseer/ are used read-only)")
    ap.add_argument("--from", dest="src", required=True, type=Path, help="the recorded wave directory")
    ap.add_argument("--out", required=True, type=Path, help="the new wave directory (must not exist or be empty)")
    ap.add_argument("--quota", type=int, default=1, help="PoolConfig.per_instance_quota")
    ap.add_argument("--max-instances", type=int, default=64, help="PoolConfig.max_instances (the pool refuses more than its hard maximum)")
    ap.add_argument("--base-agent-id", default="ovs-f1")
    ap.add_argument("--wave", default="f1")
    ap.add_argument("--copy-gold", action="store_true")
    args = ap.parse_args(argv)
    sys.path.insert(0, str((args.tree / "src").resolve()))
    sys.path.insert(0, str((args.tree / "scripts" / "overseer").resolve()))
    import ovs_harness as H  # noqa: E402
    from epinoic_logic.overseer import VerdictIntake  # noqa: E402
    from epinoic_logic.overseer.dossier import dossier_json  # noqa: E402
    from epinoic_logic.overseer.pool import OverseerPool, PoolConfig, PoolItem, PoolPlan  # noqa: E402

    src, out = args.src, args.out
    if out.exists() and any(out.iterdir()):
        print(json.dumps({"ok": False, "error": "the output directory is not empty"}))
        return 2
    if out.resolve() == src.resolve() or src.resolve() in out.resolve().parents:
        print(json.dumps({"ok": False, "error": "the output directory is inside the recorded wave"}))
        return 2
    wave = H.read_json(src / "records" / "wave.json")
    old = PoolPlan.model_validate(H.read_json(src / "records" / "pool_plan.json"))
    pack = H.load_exported_pack(Path(wave["pack_dir"]))
    if pack.identity != old.pack:
        print(json.dumps({"ok": False, "error": "the recorded plan names another pack than the wave's exported pack"}))
        return 2
    uid_to_record: dict[str, str] = {}
    for line in (src / "records" / "issues.jsonl").read_text(encoding="utf-8").splitlines():
        if line.strip():
            row = json.loads(line)
            uid_to_record.setdefault(row["issue"]["channel_uid"], row["transfers"])
    if set(uid_to_record) != {it.key for it in old.items}:
        print(json.dumps({"ok": False, "error": "the recorded issues do not cover the recorded plan's items"}))
        return 2

    (out / "records").mkdir(parents=True, exist_ok=True)
    shutil.copytree(src / "records" / "transfers", out / "records" / "transfers")

    def no_provider(agent_id: str):
        raise RuntimeError("re-issue only: no provider is ever called here")
    config = PoolConfig(max_instances=args.max_instances, per_instance_quota=args.quota, lens=old.config.lens, mode=old.config.mode,
                        base_agent_id=args.base_agent_id)
    pool = OverseerPool(pack, no_provider, config=config)
    plan = pool.plan([PoolItem(key=it.key, repeated_faults=it.repeated_faults) for it in old.items])

    per_instance: dict[str, list[tuple[str, dict, dict]]] = {a: [] for a in plan.instances}
    for it in plan.items:
        rel = uid_to_record[it.key]
        lr = H.load_record(out / rel)
        aud, uid = H.rebuild(lr.events, lr.keyring)
        try:
            if uid != it.key:
                raise SystemExit(f"the record {rel} rebuilds channel {uid}, not {it.key}")
            view = aud.view(uid)
            intake = VerdictIntake(lr.keyring, accepted_packs={pack.identity})
            for agent_id in sorted(plan.instances_for(it.key)):
                d = intake.issue(view, agent_id=agent_id, lens=plan.config.lens, mode=plan.config.mode, pack=pack.identity, audit=None)
                rec = intake.issue_record(agent_id, d["task"]["task_id"])
                if rec is None or rec.dossier_sha256 != d["dossier_sha256"]:
                    raise SystemExit("the intake's issue record does not name the dossier it issued")
                per_instance[agent_id].append((rel, d, rec.model_dump(mode="json")))
        finally:
            aud.close()

    issues, batches, dmap, dirs = [], [], {}, {}
    for i, agent_id in enumerate(plan.instances, 1):
        idir = f"{args.wave}-{i}"
        dirs[idir] = agent_id
        paths = []
        for n, (rel, d, rec) in enumerate(per_instance[agent_id], 1):
            p = out / "dossiers" / idir / f"d{n:02d}.json"
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(dossier_json(d) + "\n", encoding="utf-8")
            prel = str(p.relative_to(out))
            paths.append(prel)
            transfer = Path(rel).name
            issues.append({"instance": agent_id, "dossier": prel, "transfer": transfer, "transfers": rel,
                           "keyring_profile": H.read_json(out / rel / "record.json")["keyring_profile"], "issue": rec})
            dmap[prel] = transfer
        batches.append(paths)
    with (out / "records" / "issues.jsonl").open("w", encoding="utf-8") as fh:
        for row in issues:
            fh.write(json.dumps(row, sort_keys=True) + "\n")
    H.write_json(out / "records" / "index.json", {r["issue"]["dossier_sha256"]: r["dossier"] for r in issues})
    H.write_json(out / "records" / "pool_plan.json", plan.model_dump(mode="json"))
    H.write_json(out / "records" / "wave.json", {
        "format": "overseer-wave/1.0", "wave": args.wave, "pack": pack.identity.model_dump(), "pack_dir": wave["pack_dir"],
        "pool_config": plan.config.model_dump(mode="json"), "plan_id": plan.plan_id, "max_instances": plan.config.max_instances,
        "instances": {a: f"{args.wave}-{i}" for i, a in enumerate(plan.instances, 1)}, "dossiers": len(issues), "transfers": len(plan.items),
        "reissued_from": {"plan_id": old.plan_id, "pool_config": old.config.model_dump(mode="json")}, "batches": batches})
    if args.copy_gold:
        (out / "gold").mkdir(exist_ok=True)
        shutil.copyfile(src / "gold" / "gold.json", out / "gold" / "gold.json")
        H.write_json(out / "gold" / "opaque_map.json", {"dossier_to_transfer": dmap, "instance_dirs": dirs})
    print(json.dumps({"ok": True, "plan_id": plan.plan_id, "instances": len(plan.instances), "dossiers": len(issues), "review_units": plan.review_units,
                      "needed_instances": plan.needed_instances, "capped": plan.capped, "over_quota": plan.over_quota,
                      "max_load": max(plan.loads.values()), "reasons": plan.reasons}))
    return 0


if __name__ == "__main__":
    sys.exit(main())
