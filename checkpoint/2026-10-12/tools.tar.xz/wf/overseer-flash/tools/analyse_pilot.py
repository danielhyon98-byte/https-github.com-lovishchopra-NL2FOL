#!/usr/bin/env python3
"""Where a pilot arm's accuracy and time went: one JSON file from the scored pilot, its verdicts, its gold and the agents'
transcripts.

    python -I analyse_pilot.py --pilot PILOT_DIR --arm b --transcripts WORKFLOWS_DIR --label-prefix pilot-overseer:p1 --out OUT.json

Reads only: ``PILOT_DIR/score.json`` (the scored arm: per assessment the transfer, status and per accusation its kind
and outcome), the arm's verdict files (``verdicts/<arm>-<i>/<digest>.json`` as split, or ``verdicts/<arm>-<i>/dNN.json``),
``PILOT_DIR/gold/gold.json`` (the faults of each transfer) and the transcripts labelled ``<label-prefix>:<ARM>-<i>``
(``WORKFLOWS_DIR/*/agent-*.meta.json`` and the ``.jsonl`` beside it). Nothing is executed or evaluated; every text is
data.

Per instance: the transfer, the verdict status, the gold faults present (agent-scorable), the accusations (kind,
severity, outcome, identifiers) and the turn anatomy of its transcript: wall seconds, turns, and for the longest turn
its duration, the input tokens it took and the length of its thinking signature (the hidden reasoning is not readable;
the signature's length grows with it). Per arm: outcome counts by kind and outcome, faults named and missed by class,
and the least-squares fit of the longest turn's seconds on the signature length and on the input tokens.

The output names no model and no path outside the pilot directory.
"""
from __future__ import annotations

import argparse
import datetime
import glob
import json
import re
import statistics
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Optional


def _ts(s: str) -> datetime.datetime:
    return datetime.datetime.fromisoformat(s.replace("Z", "+00:00"))


def turn_anatomy(jsonl: Path) -> dict[str, Any]:
    lines = [json.loads(x) for x in jsonl.read_text(encoding="utf-8").splitlines() if x.strip()]
    stamps = [_ts(x["timestamp"]) for x in lines if "timestamp" in x]
    msgs: dict[str, dict] = {}
    order: list[str] = []
    prev = None
    for x in lines:
        if x.get("type") == "assistant":
            mid = x["message"]["id"]
            if mid not in msgs:
                msgs[mid] = {"start": prev or _ts(x["timestamp"]), "end": _ts(x["timestamp"]), "sig": 0, "tools": [],
                             "usage": x["message"].get("usage") or {}, "write_chars": 0}
                order.append(mid)
            e = msgs[mid]
            e["end"] = _ts(x["timestamp"])
            for c in x["message"].get("content", []):
                if c.get("type") == "thinking":
                    e["sig"] += len(c.get("signature", ""))
                elif c.get("type") == "tool_use":
                    e["tools"].append(c["name"])
                    if c["name"] == "Write":
                        e["write_chars"] += len(str(c["input"].get("content", "")))
        if "timestamp" in x:
            prev = _ts(x["timestamp"])
    if not order:
        return {"wall_s": None, "turns": 0}
    longest = max(order, key=lambda k: (msgs[k]["end"] - msgs[k]["start"]).total_seconds())
    e = msgs[longest]
    u = e["usage"]
    return {"wall_s": round((max(stamps) - min(stamps)).total_seconds(), 1), "turns": len(order),
            "longest_turn_s": round((e["end"] - e["start"]).total_seconds(), 1), "longest_turn_thinking_signature_chars": e["sig"],
            "longest_turn_input_tokens": int((u.get("input_tokens") or 0) + (u.get("cache_read_input_tokens") or 0) + (u.get("cache_creation_input_tokens") or 0)),
            "tools": [t for k in order for t in msgs[k]["tools"]], "write_chars": sum(msgs[k]["write_chars"] for k in order)}


def _fit(xs: list[float], ys: list[float]) -> Optional[dict]:
    if len(xs) < 3 or len(set(xs)) < 2:
        return None
    mx, my = statistics.mean(xs), statistics.mean(ys)
    sxx = sum((x - mx) ** 2 for x in xs)
    sxy = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    syy = sum((y - my) ** 2 for y in ys)
    slope = sxy / sxx
    return {"slope": round(slope, 4), "intercept": round(my - slope * mx, 2), "r": round(sxy / (sxx * syy) ** 0.5, 3) if syy else None, "n": len(xs)}


def _verdict_files(pilot: Path, dossier_rel: str) -> list[Path]:
    """The reply to one dossier: ``verdicts/<instance dir>/dNN.json`` beside the dossier's own name, or, for a split
    bundle, ``verdicts/<instance dir>/<dossier_sha256>.json``."""
    rel = Path(dossier_rel)
    if rel.parts and rel.parts[0] == "dossiers":
        rel = Path(*rel.parts[1:])
    same = pilot / "verdicts" / rel
    if same.is_file():
        return [same]
    try:
        digest = json.loads((pilot / dossier_rel).read_text(encoding="utf-8"))["dossier_sha256"]
    except (OSError, ValueError, KeyError):
        return []
    split = pilot / "verdicts" / rel.parent / f"{digest}.json"
    return [split] if split.is_file() else []


def _load_verdict(p: Path) -> Optional[dict]:
    text = p.read_text(encoding="utf-8").strip()
    m = re.fullmatch(r"```(?:json)?\n(.*)\n```", text, re.S)
    try:
        v = json.loads(m.group(1) if m else text)
    except ValueError:
        return None
    return v if isinstance(v, dict) else None


def analyse(pilot: Path, arm: str, transcripts: Optional[Path], label_prefix: str) -> dict:
    score = json.loads((pilot / "score.json").read_text(encoding="utf-8"))
    A = score["arms"][arm]
    gold = json.loads((pilot / "gold" / "gold.json").read_text(encoding="utf-8"))["transfers"]
    anatomy: dict[str, dict] = {}
    if transcripts is not None:
        lab = re.compile(re.escape(label_prefix) + r":%s-(\d+)$" % re.escape(arm.upper()))
        for meta in sorted(glob.glob(str(transcripts / "*" / "agent-*.meta.json"))):
            m = lab.fullmatch(json.loads(Path(meta).read_text(encoding="utf-8")).get("description", ""))
            if m:
                anatomy[m.group(1)] = turn_anatomy(Path(meta[: -len(".meta.json")] + ".jsonl"))
    rows = []
    by_kind_outcome: Counter = Counter()
    named_by_class: Counter = Counter()
    present_by_class: Counter = Counter()
    for a in sorted(A["assessments"], key=lambda x: int(x["agent_id"].rsplit("-", 1)[1])):
        idx = a["agent_id"].rsplit("-", 1)[1]
        t = a["transfer"]
        faults = [f for f in gold[t]["faults"] if f.get("agent_scorable")]
        outcomes = {x["id"]: x for x in (a.get("accusations") or [])}
        accs = []
        for p in _verdict_files(pilot, a["dossier"]):
            v = _load_verdict(p)
            for acc in (v or {}).get("accusations", []) or []:
                o = outcomes.get(acc.get("accusation_id"), {})
                accs.append({"id": acc.get("accusation_id"), "kind": acc.get("kind"), "severity": acc.get("claimed_severity"),
                             "outcome": o.get("outcome"), "refuted_by": o.get("refuted_by"), "claim_ids": acc.get("claim_ids", []),
                             "result_ids": acc.get("result_ids", []), "document_ids": acc.get("document_ids", [])})
                by_kind_outcome[(acc.get("kind"), o.get("outcome"))] += 1
        rows.append({"instance": a["agent_id"], "transfer": t, "status": a["status"], "reason": a.get("reason"),
                     "gold_faults": [{"class": f["class"], "codes": f["expected_codes"], "claim_ids": f.get("identifiers", {}).get("claim_ids", [])} for f in faults],
                     "accusations": accs, **({"anatomy": anatomy[idx]} if idx in anatomy else {})})
    for t, pt in A["per_transfer"].items():
        for f in gold[t]["faults"]:
            if f.get("agent_scorable"):
                present_by_class[f["class"]] += 1
        # faults named per class: a confirmed group of the class's kind names it (the package scorer's own count is the total)
        for g in pt.get("groups", []):
            if g["outcome"] == "confirmed":
                named_by_class[g["kind"]] += 1
    replied = {r["instance"].rsplit("-", 1)[1] for r in rows if r["status"] != "no_reply"}
    timed = [x for k, x in sorted(anatomy.items()) if k in replied and x.get("longest_turn_s") is not None]  # one point per instance
    fits = {"longest_turn_s_on_thinking_signature_kchars": _fit([x["longest_turn_thinking_signature_chars"] / 1000 for x in timed], [x["longest_turn_s"] for x in timed]),
            "longest_turn_s_on_input_ktokens": _fit([x["longest_turn_input_tokens"] / 1000 for x in timed], [x["longest_turn_s"] for x in timed])}
    walls = [x["wall_s"] for x in timed]
    return {"format": "overseer-pilot-analysis/1.0", "arm": arm, "instances": len(rows),
            "statuses": dict(Counter(r["status"] for r in rows)),
            "accusations_by_kind_and_outcome": {f"{k}:{o}": n for (k, o), n in sorted(by_kind_outcome.items(), key=lambda x: (str(x[0][0]), str(x[0][1])))},
            "faults_present_by_class": dict(present_by_class), "confirmed_groups_by_kind": dict(named_by_class),
            "package_scorer": {k: A.get(k) for k in ("faults_present", "faults_named", "verdicts_valid", "verdicts_invalid")} | {"false_accusations": A.get("false_accusations", {}).get("package_scorer", {}).get("count")},
            "time": {"wall_s_median": statistics.median(walls) if walls else None, "wall_s_max": max(walls) if walls else None, "fits": fits},
            "per_instance": rows}


def main(argv: Optional[list[str]] = None) -> int:
    ap = argparse.ArgumentParser(description="Where a pilot arm's accuracy and time went.")
    ap.add_argument("--pilot", required=True, type=Path)
    ap.add_argument("--arm", required=True)
    ap.add_argument("--transcripts", type=Path, help="the workflows directory holding the agents' transcripts (optional)")
    ap.add_argument("--label-prefix", default="pilot-overseer:p1")
    ap.add_argument("--out", required=True, type=Path)
    args = ap.parse_args(argv)
    out = analyse(args.pilot, args.arm, args.transcripts, args.label_prefix)
    args.out.write_text(json.dumps(out, indent=1, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({k: out[k] for k in ("arm", "instances", "statuses", "package_scorer", "time")}, sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
