# Overseer agents, last end-to-end run: where the time went

Sources: the four overseer-agent transcripts (w1-1..w1-4), the exported pack (overseer-knowledge-docs 1.3),
the issued dossiers, the verdicts and score.json of run1-overseer. Scripts: measure.py, measure2.py, measure3.py
(same folder). Times are transcript timestamps (first to last line).

## 1. Per instance

| instance | wall s | turns | tool calls | pack reads | dossier reads | writes/edits | other | model s | tool s | ctx first / median / max (tokens) | ctx summed | generated chars |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| w1-1 | 532 (8.9 min) | 48 | 51 | 16 | 35 | 0 (verdicts via shell) | 0 | 512 | 20 | 50.8K / 258K / 369K | 11.3M | 94K |
| w1-2 | 1051 (17.5 min) | 60 | 68 | 15 | 43 | 0 (verdicts via shell) | 10 shell (own helper scripts) | 1026 | 25 | 50.8K / 361K / 575K | 20.7M | 135K |
| w1-3 | 824 (13.7 min) | 63 | 65 | 17 | 3 | 0 (verdicts via shell) | 37 shell + 8 reads of its own extracts | 802 | 22 | 50.8K / 319K / 534K | 19.5M | 105K |
| w1-4 | 701 (11.7 min) | 44 | 58 | 17 | 18 | 4 writes + 8 edits (helper scripts) | 5 shell + 6 reads of its own extracts | 688 | 14 | 50.7K / 316K / 495K | 13.3M | 91K |

"pack reads" = cat/Read of pack files (07-examples.md alone took 4-5 chunked reads in three instances);
"dossier reads" = commands that open dossier JSON (almost all are agent-written Python filters, not whole reads);
"other" = commands on the agent's own extracted text files and helper scripts.

Phase timing (minutes from start): pack read finished at 0.4-1.0 min in every instance; first verdict written at
5.4 (w1-1), 16.9 (w1-2), 13.0 (w1-3), 11.3 (w1-4). w1-1 then spent 3 more minutes re-checking.

Latency per turn by context size (all four): context < 150K: 34 turns, 2-3.6 s each; 150-300K: 69 turns,
12.7-18.7 s each; > 300K: 112 turns, 13-18 s each. Longest single turns: 113 s (543K context, 20K chars
generated: a verdict-building script), 85 s (461K, 20K chars), 53 s, 51 s.

## 2. Pack (14 files, 325,067 bytes; system text about 269K characters, ~67K tokens)

| file | bytes | holds |
|---|---|---|
| 07-examples.md | 124,466 | worked dossiers with correct verdicts (38% of pack) |
| 03-inspection.md | 47,174 | what to check per transfer kind (request, response, response_text, relay_*, translations, consolidations, STEM) |
| dossier.schema.json | 32,859 | dossier JSON schema (not for the model) |
| 02-dossier.md | 29,787 | the dossier field by field, lenses, modes, pointers, facts to rely on |
| 06-kinds-and-codes.md | 22,144 | accusation kinds, choosing between them, receipt codes |
| README.md | 11,183 | deployment guide (not for the model): one dossier per call, input budget, runner |
| master_prompt.txt | 9,689 | core operating principle and document order |
| verdict.schema.json | 8,999 | verdict schema (structured output; not for the model as instructions) |
| 01-role-and-trust.md | 8,717 | role, trust, what a verdict is worth, several instances |
| 05-verdict-format.md | 7,851 | the one JSON verdict, final check |
| 04-evidence.md | 7,091 | identifiers, evidence items, engine statements |
| 09-when-unsure.md | 6,642 | rules when unsure |
| 08-never.md | 5,462 | prohibitions |
| manifest.json | 3,003 | file digests, system order, pack digest |

Every instance read the deployment README, and two read the schemas/manifest, which the README says are not for the
model; the agents loaded the pack by tool calls rather than as the fixed system text.

## 3. Dossiers (39 issued; 10/10/10/9 per instance)

- total 11.0 MB; median 300,442 bytes; min 50,981; max 818,210 (two dossiers over 800 KB).
- per instance total / median: w1-1 2.54 MB / 271 KB; w1-2 3.22 MB / 348 KB; w1-3 2.49 MB / 284 KB; w1-4 2.76 MB / 331 KB.
- 31 dossiers hold 2 transfers, 7 hold 5, 1 holds 6.
- Bytes by field: transfers 71% (of which receipt.outcomes 50% of all bytes; outcome.translation 31%,
  outcome.verification 9%, outcome.summary 9%), results (signed engine results) about 28%, index 2%, links 2% (shares approximate: measured on re-serialised JSON).
- The pack README budgets 36-301 KB per dossier and a 160K-token window for one dossier per call; 23 of 39 dossiers
  exceed 300 KB, and the run handed each instance 9-10 dossiers in one session, so the session context reached
  369K-575K tokens.
- Dossier text actually returned to the agents: 19K-202K characters per instance directly, plus 48K-290K through their
  own extracts, against 2.5-3.2 MB issued: roughly 5-15% of the dossier bytes were ever seen by the model.

## 4. Verdicts and score

- 39 verdict files (0.6-4.7 KB), all 39 validated by the intake (invalid 0, not validated 0, reissue mismatch 0),
  identifier accuracy 23/23. All 39 self-reported (runner-attested 0: deployment gate FAIL).
- Gold faults present (agent-scorable, blind): 53; named 9; all 9 confirmed by checks. Recall by mode 9/62 = 14.5%
  (CI 7.8-25.3%), macro-average over classes 48.8%.
- Per class: translation_ungrounded 1/46; translation_circular 2/2; formal_status_wrong 1/1; peer_document_altered 1/1;
  result_from_other_problem 1/1; self_certification_as_content 1/1; result_unsigned_or_forged 1/2; quotation_absent 1/3;
  receipt_status_wrong 0/2; receipt_altered 0/1; finding_missing 0/1; translation_invalid 0/1. Without
  translation_ungrounded: 8/16.
- Accusations 23: confirmed 9, refuted 1, unresolved 13 (unresolved rate 56.5%); precision 9/23 = 39%.
- False accusations accepted 0 (0/60 clean transfers falsely accused); made but not accepted 4+2: 1 refuted, 1 refuted
  remainder, 4 unadjudicated "other"/meaning warnings sent to review (upper bound 6.7% of clean transfers).
- Contradictions with signed results 0. Contested transfers 4, resolved by duplicates 1; duplicates spawned by the
  pool 0. Per instance: w1-1 2 accusations (1 confirmed); w1-2 7 (3 confirmed); w1-3 6 (3 confirmed);
  w1-4 8 (2 confirmed, 1 refuted). Kappa vs auditor 0.31 (agent-only 2, auditor-only 41, both 10).

## 5. Bottlenecks (why one instance takes 9 to 17 minutes)

1. Model latency, not tools: 97-98% of wall time is model time (512-1026 s); tools take 14-25 s per instance.
2. Context growth in one long session: 9-10 dossiers per session instead of one dossier per call. The pack
   (~67K tokens) plus tool outputs accumulate; median context 258K-361K, max 575K. Turns above 150K context cost
   13-19 s each versus 2-4 s below 150K; 181 of 215 turns ran above 150K. Summed context processed: 11-21M tokens
   per instance.
3. Dossiers too large to read whole (median 300 KB, max 818 KB; half the bytes are receipt outcomes, mostly the
   translation record). Agents instead write and debug their own extraction scripts: 91K-135K generated characters
   per instance, 44-63 turns, the longest turns being script generation (up to 113 s).
4. Pack loaded by 15-17 tool calls, including the deployment README, schemas and manifest, with 07-examples.md read
   in 4-5 chunks; fast in wall time (under 1 min) but it adds ~80K tokens to every later turn.
5. Verdict assembly via generated scripts and rework at the end (w1-4 build script with four edits; w1-1 3 minutes
   of re-checks after writing).

Accuracy link: the agents saw only ~5-15% of dossier bytes through their own filters, and the class they mostly
missed (translation_ungrounded, 1 of 46) lives in exactly the largest field (outcome.translation). Validity and
precision of what they did say were good (39/39 valid, 0 accepted false accusations, 0 contradictions).
