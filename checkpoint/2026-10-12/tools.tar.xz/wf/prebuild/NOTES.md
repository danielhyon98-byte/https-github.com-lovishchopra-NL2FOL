
# Pre-build step: integration protocol and integration kit (branch integ-prebuild)

Written by the pre-build step that implements INTEGRATION_KIT_DESIGN.md sections 3, 4, 5, 6.3 (6.1/6.2 as patch
files in the kit), 7.1/7.4/7.5/7.7, 8 and the fifth port (flash router, epinoic.integration.router-port.v1).
Append-only; earlier and later steps keep their own sections.

## State of this tree (what is NOT here, by design of the pre-build)

- No overseer package (src/epinoic_logic/overseer absent), no named-policy allowlist (engine.policies has no
  NAMED_POLICIES / named_policy), contract 0.2 in docs/integration-contract.md, no argument diagnostics, no closed
  transformation values, no combinator, no flash-router sub-project. Nothing in the kit stands in for any of them.
- Consequence on this tree: `EPINOIC_PROFILE=integration-sim python -m epinoic_logic.integration preflight` refuses with
  `KIT-HS-006 named_policies_unavailable` (exit 2). After phase 2 merges contract 0.3 it refuses with
  `KIT-HS-007 overseer_unavailable` until the overseer port adapter exists; only then does it start.
- The contract tests run against fixtures: tests/integration/helpers.py has RecordingPort (a TEST DOUBLE of the overseer
  port, not importable by the package) and FixtureProbes (replaces only the named-policy and overseer probes).

## What phase 2 must connect (exactly)

1. Named policies (contract 0.3). `Probes.named_policies()` (src/epinoic_logic/integration/preflight.py) requires
   `epinoic_logic.engine.policies.NAMED_POLICIES` (a mapping whose keys are exactly joint, linear, nonlinear) and a
   callable `epinoic_logic.engine.policies.named_policy`. If 0.3 names them differently, change ONLY this probe and
   `selftest.resolve_policy` (which today resolves linear/nonlinear through PACK_POLICIES and joint through
   JOINT_LIMITS); then recompute nothing: the self-test's pinned digests are build-independent and must stay equal
   (tests/integration/test_selftest.py recomputes them; a difference means the policy semantics changed).
2. Overseer port adapter: module `epinoic_overseer.port` (env EPINOIC_OVERSEER_PORT, default that name) exposing
   `connect(config) -> port`. config = {engine_key, engine_key_id, overseer_secret, replay_mode: "process", agents}.
   The port object must implement (integration/overseer_port.py, class OverseerPort):
   - hello() -> epinoic.integration.overseer-hello.v1 (port_version 1.0, mode embedded, auditor_version, pack_digests =
     the exported pack's PACK_DIGESTS, key_ids incl. overseer-audit, replay_mode process, inline_final_release false,
     max_pending_wait_ms <= 250, agents off|async, profiles [standard] or [standard, fast]);
   - new_hub(signing_key, key_id, verify_claim_fn, config) -> a RouterHub with a TransferAuditor attached (KeyRing of
     the engine key + the overseer secret's subkeys; replay_mode "process");
   - clearance(hub, task_id, message_id, receipt, wait_ms) -> overseer-clearance.v1 from hub.clearance +
     policy.act_decision, waiting at most 250 ms; receipt_sha256 MUST equal turn.receipt_sha256(receipt)
     (= sha256 of ir.canonical.canonical_json(receipt)); if the overseer journals `receipt_digest` differently, phase 2
     changes turn.receipt_sha256 to the overseer's function and keeps the equality test;
   - close(hub, task_id) -> overseer-final-audit.v1 from hub.close_task (scope FINAL, signed under overseer-audit,
     channel_uid, journal_head, engine scope statement and the TR6 sentence verbatim);
   - deliver(hub, task_id, mode, synthesis=None) -> overseer-delivery.v1 from hub.consolidate +
     delivery_decision(..., hub=hub) (kind consolidation) or release_decision (kind release, synthesis only);
   - view(hub, task_id) (hub.view), repeats(hub, task_id) -> {transfer key (message id): repeated-fault count}
     (hub.repeats; feeds the flash router's request), review(hub, task_id, admission) -> overseer-review-ticket.v1
     (asynchronous overseer-agent review under the admitted plan; never on the critical path).
   - Map EVERY reason the overseer's delivery_decision / release_decision gives onto exactly one label of
     protocol.OVERSEER_REFUSALS (clearance_failed, clearance_pending, final_audit_not_passed, signature_invalid,
     custody_failed, stale, consolidation_conflicting, no_deliverable_output, receipt_error_findings, not_deliverable);
     an unmapped reason must be a test failure, never a silent "not_deliverable".
   - Run the RecordingPort-based TurnChecker tests against the real adapter too (tests/integration/test_turn_checker.py:
     parametrize the port fixture), and the overseer tampering suite T1-T22 must still name its codes.
3. TR6 sentence: protocol.AUDIT_SCOPE_STATEMENT is restated verbatim; tests/integration/test_protocol_constants.py pins
   it to a literal. Phase 2 adds the assertion `AUDIT_SCOPE_STATEMENT == <overseer constant>` (the overseer is absent
   here, so that half of the pin cannot exist yet).
4. Flash router: sub-project `flash-router/`, package `epinoic_flash_router`, module `epinoic_flash_router.port`
   (env EPINOIC_FLASH_ROUTER; `none` detaches it) exposing `hello() -> str` (router-hello.v1 JSON) and
   `plan(request_json: str) -> str` (routing-plan.v1 JSON). The planner the overseer rebuild is building moves there.
   The kit never imports it except through router_port.attach_router; the floor (router_port.FLOOR_RULES,
   minimum-oversight-floor/1) stays in the translator and is enforced whatever the router says. The router's identity
   (name, version, rules_sha256, cost_data_sha256) must be stable per release; integration/router-port/CONFORMANCE.md
   lists what the sub-project's own tests must show. Model ids are never in a plan (KIT-RT-009).
5. Argument diagnostics: routing_features.OutputRecord.diagnostics is () today. Phase 2 passes the named diagnostic
   codes of each output (codes only, matching the finding-code pattern). They only escalate (risk signals).
6. Repeated faults: TurnChecker._review reads port.repeats(); RecordingPort returns {} by default.
7. Closed transformation values: combinator_port.VOCABULARY (5 values) is the kit's draft; phase 2 replaces it with the
   end-to-end fixes' closed values (KIT-CB-003 for anything else) and regenerates the schemas
   (python integration/tools/generate.py; then python integration/tools/vectors.py; then the MANIFEST).
8. Combinator: Probes.combinator() reports available=false, so the checks port never offers `combined` (KIT-REQ-002).
   Phase 2 connects the combinator sub-project (provider call with a pinned instruction pack) and the release path
   (TurnChecker step 6, currently a no-cover raise).
9. Delivery rule: delivery.decide is the kit's decision table; phase 2 checks it against the rebuilt overseer's
   delivery rule on the same vectors (integration/vectors/decision-table) and records any difference as a decision.
10. Merge conflicts to expect: src/epinoic_logic/cli.py (engine imports moved into the commands; KEEP the lazy imports,
    tests/integration/test_bootstrap.py fails otherwise), src/epinoic_logic/channel/bus.py (stem_budget_s() and
    TranslatorChannel.stem_budget_s; keep both), src/epinoic_logic/service/app.py (create_app(..., integration=None)).
11. Contract version: protocol.INTEGRATION_CONTRACT_VERSION = "0.4" and COMPATIBILITY.json components.contract ["0.4"].
    docs/integration-contract.md keeps its "Contract version" line as it is on this tree (0.2) and adds a section
    "Integration protocol (contract 0.4)" stating that 0.4 takes effect when phase 2 merges 0.3; phase 2 updates the
    version line to 0.4 after the merge (playbook step 5 greps for it).
12. Live providers: runtime.live_verifier uses a 20 s per-call timeout and has never been run live (no provider call
    was made). Phase 2 sets per-call timeouts from the measured budget and keeps the cheapest tier; model ids stay a
    decision placeholder (DECISIONS.md D3).
13. Website base P: not built (COMPATIBILITY.json website_bases.P). Patch set P needs a base-P website.
14. Fixture verifier parity: the sim's fixture verifier is called as fn(claim, report) WITHOUT a task, exactly as
    scripts/arena/run_arena.py does, so it serves the same fixtures (tests/integration/test_fixture_parity.py).
15. Sim solver configuration: integration-sim uses the arena's SolverConfig (4000 ms per call, no memory limit) so the
    G-EQ-ARENA comparison compares like with like (runtime.solver_config_for).
