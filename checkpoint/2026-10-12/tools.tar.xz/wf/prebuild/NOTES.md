
# Pre-build step: integration protocol and integration kit (branch integ-prebuild)

Written by the pre-build step that implements INTEGRATION_KIT_DESIGN.md sections 3, 4, 5, 6.3 (6.1/6.2 as patch
files in the kit), 7.1/7.4/7.5/7.7, 8 and the fifth port (flash router, epinoic.integration.router-port.v1).
Append-only; earlier and later steps keep their own sections.

## State of this tree (what is NOT here, by design of the pre-build)

- No overseer package (src/epinoic_logic/overseer absent), no named-policy allowlist (engine.policies has no
  NAMED_POLICIES / named_policy), contract 0.2 in docs/integration-contract.md, no argument diagnostics, no closed
  transformation values, no combinator, no flash-router sub-project. Nothing in the kit stands in for any of them.
- Consequence on this tree: `EPINOIC_PROFILE=integration-sim python -m epinoic_logic.integration preflight` refuses with
  `KIT-HS-006 named_policies_unavailable` (exit 2). After phase 2 merges contract 0.3 it refuses with
  `KIT-HS-007 overseer_unavailable` until the overseer port adapter exists; only then does it start.
- The contract tests run against fixtures: tests/integration/helpers.py has RecordingPort (a TEST DOUBLE of the overseer
  port, not importable by the package) and FixtureProbes (replaces only the named-policy and overseer probes).

## What phase 2 must connect (exactly)

1. Named policies (contract 0.3). `Probes.named_policies()` (src/epinoic_logic/integration/preflight.py) requires
   `epinoic_logic.engine.policies.NAMED_POLICIES` (a mapping whose keys are exactly joint, linear, nonlinear) and a
   callable `epinoic_logic.engine.policies.named_policy`. If 0.3 names them differently, change ONLY this probe and
   `selftest.resolve_policy` (which today resolves linear/nonlinear through PACK_POLICIES and joint through
   JOINT_LIMITS); then recompute nothing: the self-test's pinned digests are build-independent and must stay equal
   (tests/integration/test_selftest.py recomputes them; a difference means the policy semantics changed).
2. Overseer port adapter: module `epinoic_overseer.port` (env EPINOIC_OVERSEER_PORT, default that name) exposing
   `connect(config) -> port`. config = {engine_key, engine_key_id, overseer_secret, replay_mode: "process", agents}.
   The port object must implement (integration/overseer_port.py, class OverseerPort):
   - hello() -> epinoic.integration.overseer-hello.v1 (port_version 1.0, mode embedded, auditor_version, pack_digests =
     the exported pack's PACK_DIGESTS, key_ids incl. overseer-audit, replay_mode process, inline_final_release false,
     max_pending_wait_ms <= 250, agents off|async, profiles [standard] or [standard, fast]);
   - new_hub(signing_key, key_id, verify_claim_fn, config) -> a RouterHub with a TransferAuditor attached (KeyRing of
     the engine key + the overseer secret's subkeys; replay_mode "process");
   - clearance(hub, task_id, message_id, receipt, wait_ms) -> overseer-clearance.v1 from hub.clearance +
     policy.act_decision, waiting at most 250 ms; receipt_sha256 MUST equal turn.receipt_sha256(receipt)
     (= sha256 of ir.canonical.canonical_json(receipt)); if the overseer journals `receipt_digest` differently, phase 2
     changes turn.receipt_sha256 to the overseer's function and keeps the equality test;
   - close(hub, task_id) -> overseer-final-audit.v1 from hub.close_task (scope FINAL, signed under overseer-audit,
     channel_uid, journal_head, engine scope statement and the TR6 sentence verbatim);
   - deliver(hub, task_id, mode, synthesis=None) -> overseer-delivery.v1 from hub.consolidate +
     delivery_decision(..., hub=hub) (kind consolidation) or release_decision (kind release, synthesis only);
   - view(hub, task_id) (hub.view), repeats(hub, task_id) -> {transfer key (message id): repeated-fault count}
     (hub.repeats; feeds the flash router's request), review(hub, task_id, admission) -> overseer-review-ticket.v1
     (asynchronous overseer-agent review under the admitted plan; never on the critical path).
   - Map EVERY reason the overseer's delivery_decision / release_decision gives onto exactly one label of
     protocol.OVERSEER_REFUSALS (clearance_failed, clearance_pending, final_audit_not_passed, signature_invalid,
     custody_failed, stale, consolidation_conflicting, no_deliverable_output, receipt_error_findings, not_deliverable);
     an unmapped reason must be a test failure, never a silent "not_deliverable".
   - Run the RecordingPort-based TurnChecker tests against the real adapter too (tests/integration/test_turn_checker.py:
     parametrize the port fixture), and the overseer tampering suite T1-T22 must still name its codes.
3. TR6 sentence: protocol.AUDIT_SCOPE_STATEMENT is restated verbatim; tests/integration/test_protocol_constants.py pins
   its start and its end. Phase 2 adds the assertion `AUDIT_SCOPE_STATEMENT == <overseer constant>` (the overseer is absent
   here, so that half of the pin cannot exist yet).
4. Flash router: sub-project `flash-router/`, package `epinoic_flash_router`, module `epinoic_flash_router.port`
   (env EPINOIC_FLASH_ROUTER; `none` detaches it) exposing `hello() -> str` (router-hello.v1 JSON) and
   `plan(request_json: str) -> str` (routing-plan.v1 JSON). The planner the overseer rebuild is building moves there.
   The kit never imports it except through router_port.attach_router; the floor (router_port.FLOOR_RULES,
   minimum-oversight-floor/1) stays in the translator and is enforced whatever the router says. The router's identity
   (name, version, rules_sha256, cost_data_sha256) must be stable per release; integration/router-port/CONFORMANCE.md
   lists what the sub-project's own tests must show. Model ids are never in a plan (KIT-RT-009).
5. Argument diagnostics: routing_features.OutputRecord.diagnostics is () today. Phase 2 passes the named diagnostic
   codes of each output (codes only, matching the finding-code pattern). They only escalate (risk signals).
6. Repeated faults: TurnChecker._review reads port.repeats(); RecordingPort returns {} by default.
7. Closed transformation values: combinator_port.VOCABULARY (5 values) is the kit's draft; phase 2 replaces it with the
   end-to-end fixes' closed values (KIT-CB-003 for anything else) and regenerates the schemas
   (python integration/tools/generate.py; then python integration/tools/vectors.py; then the MANIFEST).
8. Combinator: Probes.combinator() reports available=false, so the checks port never offers `combined` (KIT-REQ-002).
   Phase 2 connects the combinator sub-project (provider call with a pinned instruction pack) and the release path
   (TurnChecker step 6, currently a no-cover raise).
9. Delivery rule: delivery.decide is the kit's decision table; phase 2 checks it against the rebuilt overseer's
   delivery rule on the same vectors (integration/vectors/decision-table) and records any difference as a decision.
10. Merge conflicts to expect: src/epinoic_logic/cli.py (engine imports moved into the commands; KEEP the lazy imports,
    tests/integration/test_bootstrap.py fails otherwise), src/epinoic_logic/channel/bus.py (stem_budget_s() and
    TranslatorChannel.stem_budget_s; keep both), src/epinoic_logic/service/app.py (create_app(..., integration=None)).
11. Contract version: protocol.INTEGRATION_CONTRACT_VERSION = "0.4" and COMPATIBILITY.json components.contract ["0.4"].
    docs/integration-contract.md keeps its "Contract version" line as it is on this tree (0.2) and adds a section
    "Integration protocol (contract 0.4)" stating that 0.4 takes effect when phase 2 merges 0.3; phase 2 updates the
    version line to 0.4 after the merge (playbook step 5 greps for it).
12. Live providers: runtime.live_verifier uses a 20 s per-call timeout and has never been run live (no provider call
    was made). Phase 2 sets per-call timeouts from the measured budget and keeps the cheapest tier; model ids stay a
    decision placeholder (DECISIONS.md D3).
13. Website base P: not built (COMPATIBILITY.json website_bases.P). Patch set P needs a base-P website.
14. Fixture verifier parity: the sim's fixture verifier is called as fn(claim, report) WITHOUT a task, exactly as
    scripts/arena/run_arena.py does, so it serves the same fixtures (tests/integration/test_fixture_parity.py).
15. Sim solver configuration: integration-sim uses the arena's SolverConfig (4000 ms per call, no memory limit) so the
    G-EQ-ARENA comparison compares like with like (runtime.solver_config_for).

## Pre-build step, continued: what else phase 2 must connect or re-check

16. Simulation drivers: integration/sim/website-driver.mjs and agents-driver.mjs stop at their prerequisite checks
    (exit 3, "connected in phase 2"). Phase 2 writes the replay loop over integration/sim/users.json on a patched
    disposable export (apply.mjs) with options.verified.inner = createSpecialistOrchestrator over the agents copy's
    createOfflineTestRuntime + synthetic bundle (authorizedGenerate returns each corpus item's response_text), and
    feeds gates.py: website projections from the evidence tap (compare.receipt_projection of the specialist_to_router
    receipt with the item's fixture ids), the fault replay, the invariants, the displayed labels, the verdicts, the
    handler-level W-T1..W-T8. Until then run_sim.py reports all eight gates NOT RUN and exits 1 (tested).
17. G-EQ across request ids: the website path's request id is the attempt id, the arena's is req-<item>. The fixture
    provider re-keys problem.request_id to the claim's request id (verifier.RekeyingFixtureProvider; a no-op in the
    arena), and compare.result_digests normalises the problem's request id before hashing (engine's own problem_digest
    and binding_digest_of). tests/integration/test_fixture_parity.py shows the normalised digests equal on both paths.
    If the overseer journals digests of the raw problem, phase 2 keeps this normalisation in the comparison only.
18. Synthetic corpus: History answers end with the runtime synthetic gate's sources line ("Sources: none consulted (no
    retrieval in this session)") so the website path's runtime gate passes; the parser makes it a NOT_ELIGIBLE claim.
19. Website patch material (base M, 2cd3182): 39 blocks + 107 copied files, tested on a disposable export: 354/357
    (the baseline's 3 Playwright failures only), apply --verify exact, rollback rehearsal 4 PASS + base P NOT RUN.
    tests/integration/test_website_kit.py fails when any copied kit file changes after RESULT.sha256 was written:
    re-run the cycle (fresh export -> apply --write-result -> website suite -> fresh export --verify) and update
    TESTED.json. Under the verified backend the handler always sends X-Chat-Simulated: 1 (M1 never has both parts
    live); base P must derive it from outcome.kit.simulated. W5 (usage/caps migration) is not built. Live routing
    under the verified backend is covered by the disclosure test only, not by a handler test.
20. Agents: A2 (integration/agents/checks-port/) built and tested on an archive copy (3/3, portable, runtime suite
    120/120 unchanged); A1 and A4 are prose for that repository's owner; A3 (check_answer.py reading the public view)
    and A5 (adjudicator advisory flag) are connected in phase 2.
21. Patch set P (website base P) and the W0 docs patch are not built; the W*.patch files are not published (D20).
22. Request ids of the website (turnId/attemptId) must match the protocol's Id pattern; the website's ID_PATTERN
    ^[A-Za-z0-9_-]{8,100}$ is a subset, so no mapping is needed (D11).

## Repair 1 of the protocol pre-build (verification findings M1-M5, L1-L5, playbook lens): what phase 2 must know

The findings list handed to this step was cut off after the playbook item "playbook-no-rollback-step" (its fix text ends
mid-sentence at "apply.mjs --base M --target"); later items, if any, were not visible here and are not addressed.

23. Flash router sub-project (user request: a separate, independent agent in a sub repository, edited apart from the
    Z3 infrastructure): `flash-router/` now exists in the translator repository as a project of its own
    (`pyproject.toml` name `epinoic-flash-router` 0.1.0, no runtime dependency, package `epinoic_flash_router` with
    `port.py` hello/plan, `planner.py`, `rules.py` = rules/1 + parameters + a cost model of planning estimates, its own
    `tests/` with CONFORMANCE items 1-6 and an independence test). It is a sub-project directory, not a separate git
    repository or submodule (no remote was available and nothing is pushed); `git subtree split --prefix flash-router`
    makes one if the owners want it. The kit's `integration/tools/vectors.py` copies the router-port vectors into
    `flash-router/tests/vectors/router-port/` (drift-tested). The overseer rebuild has no planner (deferred), so this
    is THE flash router; if a planner appears later it moves into this sub-project as a new version (new identity).
24. NOTES item 4 is superseded on two points: (a) the default of `EPINOIC_FLASH_ROUTER` is now `none` (attached only
    when named; ROLLBACK "remove the variable" and D28 now agree with settings.py); (b) the router never runs in the
    service process: `router_port.run_router` starts `python -I router_child.py` per call with the service's sys.path
    (sent in the job), cwd = the service's cwd, env = only `router_port.CHILD_ENV_NAMES` (no EPINOIC_ variable, no
    provider key), stderr discarded, at most HELLO_TIMEOUT_S = 10 s for the hello and min(PLAN_TIMEOUT_S = 3 s, budget
    left) per plan, answer at most 1 MiB, killpg of its session on a timeout. ASSUMPTIONS for phase 2: the service runs
    on POSIX; `sys.executable` of the service can import the router module (installed, or on the service's sys.path);
    the hosted image installs `flash-router/` only if D28 says hosted environments attach it.
25. Codes (decided here, PROTOCOL 7a.5 is normative): `route()` refuses a router that raises, exits, times out or
    answers with a non-text value / non-JSON text with KIT-RT-016 (the one existing test that pinned KIT-RT-001 for
    "not json" through route() now expects 016, with a comment; `check_plan` called directly on non-JSON text still
    says 001). A configured but unimportable module is detached with KIT-RT-016 (L3; that test now expects 016 instead
    of None); not configured stays refusal None. A module without hello()/plan() is 015 at attach time.
26. Step 10 of the TurnChecker (M1): every failure of the review (router, port.repeats, port.review, a ticket out of
    contract or for another plan) leaves `review.queued = false`, is recorded as `evidence["review_error"]` (type and
    code only), and never changes the decision or its reasons. `check_review_ticket(..., origin=, plan_id=, refusal=)`
    now requires the ticket to name the admitted plan (KIT-OP-010 otherwise): the embedded adapter's `review()` must
    echo `admission.origin`, `admission.effective.plan_id` and `admission.refusal` (RecordingPort does), and must queue
    without waiting (overseer-port CONFORMANCE item 6). `CheckerConfig.router_timeout_s` (default 3 s) is the cap.
27. M5: `delivery.counts_problem` and `release-gate.js countsProblem` (same rule both sides): listed counts are lower
    bounds; exact when every claim is listed; every count but claims_total exact when every material claim is listed;
    the counts must be coherent (eligible + not_eligible == material, attempted/definitive/unavailable within eligible,
    positive <= definitive, permitted <= positive, definitive - positive <= blocking <= material). New verdict-binding
    vectors: truncated-list-bound (ok), truncated-list-hides-timeout, -hides-counterexample, -inflates-permitted,
    more-listed-than-counted, counts-incoherent (kit_dl_030). Phase 2 invariant to keep: the verdict's listed claims are
    a sub-multiset of the counted claims with the same (materiality, formal, attempt, release_permitted) fields.
28. Badge (playbook high + L1): `checksBadge(summary)` in the website's chat-contract.js (block 01), used by block 13;
    copy recorded under D27 (still open): passed for formally_checked/partly_checked/formal_only, "Not formally checked"
    for not_formally_checkable and unknown, "Some checks unavailable" for incomplete. Vectors chat-contract/labels.json
    gained `badges` and `unknown_summary_badge`. Website patch set M re-tested on fresh exports of 2cd3182: baseline
    287/290 (3 Playwright), patched 356/359 (same 3), 69 new tests, --verify exact, check-website --anchors all
    expected, rollback rehearsal 1-4 PASS, 5 NOT RUN; RESULT.sha256 and TESTED.json rewritten.
29. Readiness (M3): `check.py --router` now BLOCKs unless every router-port vector's plan is ADOPTED (origin router,
    no refusal; refusal codes listed per vector) and adds a determinism row. The fixture router of
    tests/integration/helpers.py (`write_router_module` default body) was made floor-conforming (all five agreement
    signals, N_FOLD for a combined synthesis): the old one passed only because the check was vacuous.
30. L2: `router_port.MODEL_FAMILIES` refuses a plan_id or router name naming a model family (KIT-RT-009; hello 015).
31. Vocabulary: REASON_CODES gained `risk_diagnostics` and `risk_unverified_dependencies` (routing-plan.v1 schema
    regenerated) so a router's escalations on features the floor does not read are named honestly.
32. L5 floor/2: `minimum-oversight-floor/1` is unchanged (same digest); it reads neither diagnostics nor unverified
    dependencies; the flash router escalates on both. Phase 2 decides floor/2 (D29) when the argument diagnostics are
    connected; until then the floor's digest pinned in the vectors and capabilities stays the same.
33. L4 (for phase 2): preflight must compare the overseer hello's `pack_digests` with the overseer package's own
    `PACK_DIGESTS`, imported independently of the adapter module (or pinned in COMPATIBILITY.json), and refuse
    `KIT-HS-007` on a mismatch; `check_hello` alone only checks the digests' shape (helpers use "ab"*32).
34. Playbook: step 7a is no longer "connected in phase 2" (runs the sub-project's suite, then check.py --router with
    PYTHONPATH=<kit>/flash-router/src); new step 11a (rollback rehearsal on base, W1-only and full exports) and step
    11b (configuration by NAME only: service and Worker variable names, owner actions, no value set or read).
35. Repair 1 committed on integ-prebuild as 067da31 ("Integration: fix the protocol pre-build verification findings
    (round 1)"), on top of 3dcee98. Measured on the committed tree: full suite 5822 passed, 45 deselected, 4 xfailed;
    flash-router/ own suite 19 passed; arena r1 30/30, r1-adv 150/151, r2-r6 46/46, r7 177/177 on fresh copies, every
    record identical to the pre-build run (wf/prebuild/arena-repair-protocol-1/compare.txt); hygiene grep empty.

## Repair 2 of the protocol pre-build (verification findings V2-M1, V2-M2, V2-L1 to V2-L5, V2-01 to V2-06)

The findings list handed to this step was cut off inside V2-06 ("The --start ..."; its fix text was not visible). V2-06 was
fixed from its visible problem statement; later items, if any, were not visible here and are not addressed.

36. V2-M1 (router secrets): NOTES 24's "no key, secret or token reaches it" held only for the router's OWN environment. The
    router's process runs as the service's user and could read /proc/<ppid>/environ (verifier probe as uid 0). Now:
    `router_child.py` holds both sides of the process boundary (stdlib only; `router_port.run_router` delegates to
    `router_child.launch`; `RouterFailure`, `CHILD_ENV_NAMES`, `_child_env` re-exported from router_port). Before every
    router process `router_child.protect_service()` marks the service non-dumpable on Linux (prctl PR_SET_DUMPABLE 0,
    checked with PR_GET_DUMPABLE); if Linux refuses, no router process starts (KIT-RT-016). Measured here: a uid-65534
    stand-in service with synthetic EPINOIC_ variables in its start environment: unmarked, its router reads them; marked,
    PermissionError for /proc/<ppid>/environ and /proc/<ppid>/mem. Root (CAP_SYS_PTRACE) still reads them, so
    `router_child.boundary_problem()` names root, CAP_SYS_PTRACE (CapPrm/CapEff/CapAmb bit 19) and non-Linux, and the
    HOSTED profile (`integration`) attaches a router only when it returns None (`attach_router(...,
    require_secret_boundary=True)` from `Probes.router`); `integration-sim`, check.py --router and direct calls attach it
    anyway (ephemeral keys; no secret claim). Docs corrected to "a fault boundary, not a sandbox" (PROTOCOL 7a, 14.1,
    CONFORMANCE, D28, flash-router README/__init__/port docstrings, container README, PLAYBOOK 7a).
    ASSUMPTIONS for phase 2: the hosted service runs on Linux as a non-root user without CAP_SYS_PTRACE (the proposed
    Dockerfile's USER epinoic), launched with exec (entrypoint.sh) so no other process holds the secrets, with keys only
    in its environment; files and other processes of that user stay readable by a router (documented, D28 decides a
    separate user or sandbox). The pytest process itself becomes non-dumpable after the first router test (harmless).
37. V2-01 (high) + V2-M2 (badge): the page badge is now conservative until Bruno decides D27: "Automatic checks passed"
    (is-ok) ONLY for formally_checked; partly_checked -> "Partly checked", formal_only -> "Partly checked (encoding only)",
    both with no tone; not_formally_checkable and unknown -> "Not formally checked"; incomplete -> "Some checks
    unavailable". The summary values and the decision table are unchanged (no verdict schema change). labels.json gained
    `badge_cases` (7 delivered cases incl. 1-positive-of-8 encoding-only, ambiguous+positive, permitted+invalid) run on
    both sides; new decision vector deliver-formal-only-one-positive-of-eight. G-HON (sim gates) now also refuses a
    displayed badge that says "passed" for any summary but formally_checked (display fields `badge`, `summary`, optional:
    phase 2's website driver must pass them). Under D6 (fidelity off) no v1 answer says "passed".
38. V2-L1: check_plan applies each per-transfer rule (007 method shape + hello methods, 010, 012, 013 cost) to every
    transfer before the next rule, and 004/006/005 over all keys first; codes no longer depend on transfer order.
39. V2-L3: protocol.RouterPortCaps validates coherence (attached exactly with an identity; no refusal when attached;
    refusal in protocol.ROUTER_ATTACH_REFUSALS = KIT-RT-015, KIT-RT-016); verification.js mirrors it (KIT-HS-001); five
    handshake vectors router-* added (one positive: router-refused-changes-nothing). Schema description regenerated.
40. V2-L4: overseer_port.load_port returns (hello, port), validates the hello once, and maps EVERY failure inside the
    adapter (an IntegrationError such as KIT-OP-001 from connect(), SystemExit, a hello() that raises, a KIT-OP refusal of
    the hello) to KIT-HS-007 with the inner code or exception type in the detail. Probes.overseer returns that pair, so
    phase 2's adapter's hello is read once. NOTES item 2's adapter contract (connect(config) -> port) is unchanged.
41. V2-L5: decision-table row 5 continues only under verified-v1-qualify (delivery.QUALIFY_POLICY, decision-table.js
    QUALIFY_POLICY); every other policy string refuses (vector row5-unlisted-policy-refuses, property test).
42. V2-02: verification.js honours KIT_SIMULATION only in local development (APP_ENV development or unset); on staging,
    production or any other APP_ENV it is configProblem "simulation_on_hosted" (logged kit_config:simulation_on_hosted)
    and workerEnvOf never returns "sim" there. Website ASSUMPTION: hosted Workers always set APP_ENV (wrangler.jsonc of
    2cd3182: production at top level, staging and development per env).
43. V2-03/V2-04: PLAYBOOK has "A pre-build commit is not a published kit" (a named commit only, detached worktree at that
    commit, recorded "not a published kit: <commit>", steps 3-14 as a rehearsal reported "blocked by G1"); step 5 names
    contract 0.4 / 0.3 merge; steps 6 and 11b say what a pre-build commit shows (KIT-HS-006). check.py marks a BLOCKER
    "(connected in phase 2: ...)" only when the phase-2 part is actually absent (contract < 0.4 without named policies; no
    overseer package; preflight KIT-HS-006 without NAMED_POLICIES or KIT-HS-007 without the overseer package): after
    phase 2 those marks disappear by themselves, and an unmarked BLOCKER is a defect.
44. V2-06: check.py's service environment puts <kit>/flash-router/src after <kit>/src on PYTHONPATH (when present), so
    `EPINOIC_FLASH_ROUTER=epinoic_flash_router.port check.py --start-service` attaches the router (playbook step 7, phase 2).
45. V2-L2/V2-05 (sub repository, coupling): NOT changed beyond docs. The router stays a sub-project directory (no remote,
    no push; a separate repository or submodule needs the owners: D28 now names the repository form and whether the
    translator's suite keeps running the router's own suite). The translator suite still runs the router's whole suite
    and requires ADOPTED plans on every vector: decoupling it would remove the router's own tests from the translator's
    suite, which this step's rules treat as weakening; the user (Daniel) should say whether he wants it. Playbook step 7a
    now names the router release by its own identity (name, version, digests), apart from the kit tag.
46. Website patch set M re-tested on fresh exports of 2cd3182 (Node v22.22.0): baseline 287/290 (3 Playwright), patched
    358/361 (the same 3), 71 new tests, --verify exact, check-website --anchors all expected, rollback rehearsal 1-4 PASS,
    5 NOT RUN; RESULT.sha256 rewritten, TESTED.json counts updated (copied files 121, after the KIT-RT-015 handshake vector).
47. Repair 2 committed on integ-prebuild as af10b4a ("Integration: fix the protocol pre-build verification findings
    (round 2)"), on top of 067da31. Measured on the committed tree: full suite 5849 passed, 45 deselected, 4 xfailed;
    flash-router/ own suite 19 passed; check.py --router 3 PASS (epinoic-flash-router 0.1.0, identity unchanged); arena
    r1 30/30, r1-adv 150/151, r2-r6 46/46, r7 177/177 on fresh copies, every record identical to repair 1's run
    (wf/prebuild/arena-repair-protocol-2/compare.txt); hygiene grep empty.

## Combinator step (the combinator as a separate sub-project and agent): merge of the end-to-end fixes

48. The end-to-end fixes (8a78efe) are merged into integ-prebuild as f2e6953 ("Merge the end-to-end fixes into the
    integration pre-build"). One textual conflict, src/epinoic_logic/cli.py: kept the lazy engine imports (the bootstrap
    tests need `import epinoic_logic.cli` without Z3) and the named `--policy` of contract 0.3; the parser cannot import
    engine.policies, so `cli.POLICY_NAMES_HELP = "joint|linear|nonlinear"` is written out and pinned to
    `engine.policies.NAMED_POLICIES` by a new test in tests/service/test_cli.py (`--policy` default None = linear).
    bus.py (stem_budget_s) and service/app.py (create_app(..., integration=None)) merged cleanly with both sides.
49. Semantic consequence (as the kit prescribes): contract 0.3's NAMED_POLICIES are now on the pre-build tree, so
    docs/integration-contract.md's version line says 0.4 (section 9a and section 11 "0.3 to 0.4" updated); the
    preflight on this tree now stops at KIT-HS-007 (no overseer port adapter), with keys missing at KIT-HS-008, no longer
    at KIT-HS-006. tests/integration/test_readiness.py's two "on this tree" tests are state-aware (before the 0.3 merge:
    three marked G1 BLOCKERs and KIT-HS-006; after it: only "G1 overseer package", preflight KIT-HS-007, both still
    marked "(connected in phase 2: ...)"); docs/INTEGRATION_PROTOCOL.md, integration/README.md, integration/sim/README.md
    and PLAYBOOK steps 5 and 11b say which state applies; kit MANIFEST regenerated. Phase 2: NOTES items 1, 11 and the
    KIT-HS-006 expectation of item "State of this tree" are superseded by this merge (named policies present).
50. Measured on the merged tree before committing: full suite 6253 passed, 45 deselected, 4 xfailed;
    scripts/arena/test_arena_rules.py 39 passed; hygiene grep empty.

## Combinator step: the combinator as a separate sub-project and agent (pre-build)

51. Sub-project `combinator/` (package `epinoic_combinator` 0.1.0, `pyproject.toml` name `epinoic-combinator`, no
    run-time dependency, own README, docs/DESIGN.md, LICENSE, tests). Instruction pack `combinator-instructions` 1.0
    (package data `pack/INSTRUCTIONS.md` + `pack/output-format.json`, identity = SHA-256 of canonical
    {name, version, files: {name: sha256(bytes)}}); exporter `python -m epinoic_combinator.export --out <dir>` (writes the
    two files + MANIFEST.json, prints the manifest; exit 2 in one line on a bad target; `read_export` refuses a
    tampered export). Runner `runner.run(input, provider)`: cheapest tier only, one call, no retry, never raises
    (KeyboardInterrupt goes through), output validated against the published contract copy before it leaves; refusal
    reasons -> KIT-CB codes in `combinator_port.REFUSAL_REASONS` (no new KIT code: kit-codes.json and the website
    RESULT.sha256 are untouched). Providers: `Provider` protocol, `ScriptedProvider`, `FaithfulFakeProvider`; NO live
    provider (D23). Port module: `epinoic_combinator.port.hello()` (combinator-hello.v1), `combine(input_json, provider)`.
52. Kit (translator) side, all in `src/epinoic_logic/integration/combinator_port.py`: new messages `CombinatorHello`,
    `CombinatorRefusal` (closed reasons; ids null only for input_not_json/input_invalid, optional for internal_error);
    `CombinatorOutput.conflicts` (optional; >= 2 distinct claim ids + description; cited ids checked, KIT-CB-004); claim
    ids of the port use `CLAIM_ID_PATTERN` `^[A-Za-z0-9._:@-]{1,128}$` because the generic parser writes
    `g4.2@economics-specialist` (the protocol's Id pattern has no '@': without this no combined answer with a generic-branch
    specialist could be built; the verdict's ClaimEntry still uses Id and only lists such claims as counted, as before);
    `check_hello(raw, contract_sha256=...)`, `check_refusal(raw, inp)`, `synthesis_payload(out, inp, ...)` (the
    synthesis/1.0 mapping: claims s0.. never reusing a source id, dropped -> ledger 'dropped', conflicts -> 'unresolved'
    records, optional `evidence_refs` hook per claim index), `source_report`, `build_input`, `vocabulary_document()`
    (from integrity.contracts, imported lazily), `port_rules_document()`, `contract_documents()`, `contract_digest()`.
    VOCABULARY is pinned to `integrity.contracts.SYNTHESIZED_CLAIM_TRANSFORMATIONS` by test (NOTES 7 done: same 5 values).
    Published contract = `integration/schemas/combinator-{input,output,hello,refusal}.v1.schema.json`,
    `synthesis-vocabulary.v1.json`, `combinator-port.v1.json`; `generate.py` copies them into
    `combinator/src/epinoic_combinator/contract/` (only while `combinator/` exists); `vectors.py` writes
    `integration/vectors/combinator-port/` (52 vectors, incl. a generic-parser claim id) and copies them and
    `canonical/` into `combinator/tests/vectors/` (only while `combinator/` exists). New kit doc
    `integration/combinator-port/CONFORMANCE.md`; PROTOCOL.md section 7 rewritten; DECISIONS.md D33 (open).
53. ASSUMPTIONS for phase 2 (combinator attachment, NOT built here): the service attaches the sub-project through the
    port by module name (`EPINOIC_COMBINATOR=epinoic_combinator.port`; `settings.combinator` already reads it, default
    `none`); `Probes.combinator()` still returns available=false (so `combined` is never offered and TurnChecker step 6
    still raises KIT-REQ-002). Phase 2 must: (a) decide the process model (the router's `router_child` model cannot be
    reused as is: a combinator with a live provider needs a credential, which the router's empty environment withholds;
    D33); (b) call `check_hello(hello, contract_sha256=contract_digest())` and report `instruction_pack` in
    CombinatorPortCaps; (c) in step 6 build the input with `build_input`/`source_report` from the delivered reports, run
    `combine`, read the answer with `check_output` or `check_refusal`, relay `synthesis_payload(...)` through the hub with
    its own clearance, then `release_decision`; (d) attach evidence references with the arena's rule
    (`run_arena.reproduced_evidence_refs`, the references of cited MATERIAL sources whose excerpts the claim reproduces)
    through `synthesis_payload(evidence_refs=...)`, or a faithful synthesis of a quoted material claim is charged
    INT-LEDGER-004 (the agent neither sees nor writes references); (e) contract_digest() is computed from the models at
    run time: a pydantic version that renders the schemas differently changes it (the hello would then be refused with
    KIT-CB-002) -- pin the digest in the release or compare with the published files.
54. Hub change (Z3 side) needed for "carried self-certification is caught": on this tree the hub accepted a synthesis
    carrying "VERIFIED: all claims checked and confirmed." with no finding (measured). Ported VERBATIM from the
    argument-diagnosis branch argdiag-a (72173b9, fixer a, "combinator-faults-3"): `ledger._SELF_REPORT_SENTENCE_RE`,
    `_SELF_REPORT_SENTENCE_CHARS`, `_self_report_sentences`, `_self_report_findings` and the call
    `f += _self_report_findings(synthesis)` before the ledger loop in `check_synthesis_ledger`, plus its integrity
    README row (INT-LEDGER-029, warning). Phase 2: when the argument diagnostics merge, keep argdiag's final version
    (the hunk should be identical); CODE COLLISION to resolve before merging: the overseer rebuild (overseer-build
    ef4ba9f, preserve/.../overseer-rebuild-wip d149738) uses INT-LEDGER-029 for name substitution and 030/031 for other
    rules, argdiag-a uses 029 for self-reports and 030 for unchecked evidence documents. The tests that reference
    INT-LEDGER-029 here: tests/integrity/test_synthesis_self_reports.py, tests/integration/test_combinator_subproject.py
    (test_a_carried_self_certification_is_caught_by_the_hub), combinator/src/epinoic_combinator/pack/output-format.json
    (a rule names the code; change the pack -> new pack digest).
55. Finding for phase 2 (hub credit rules and protocol agent ids): `adapters.sources.specialist_names` recognises "the
    History specialist" only for agent ids of the form `<subject>-specialist`. The TurnChecker gives the hub the
    protocol slugs (`history`, `english-a-literature`) as agent ids, so INT-LEDGER-025's credit form, INT-LEDGER-026's
    view credit (and INT-REQ-014/015) do not fire on the website path (measured: "The Economics specialist dates ..."
    caught with `economics-specialist`, missed with `economics`). The combinator hub tests use `-specialist` ids, as the
    arena does. Phase 2: name hub agents `<slug>-specialist` in WorkPlan/dispatch, or teach `specialist_names` the slugs.
56. Arena tooling: `scripts/arena/list_claims.py` now prints `synthesis_format` from the combinator's exported pack
    (`--instructions <dir>`, else it runs the sub-project's exporter in its own `python -I` process; never imports it),
    verifies the export against its manifest and the pack digest, and refuses (exit 2) a pack whose transformation
    values/meanings or certainty words differ from integrity.contracts. New plain-output line (second to last) names
    the pack. `run_arena.group_synthesis` passes a member's `conflicts` through as unresolved conflict records
    (`<prefix>k<n>`), and adds no `conflicts` key when none is disclosed (recorded rounds: identical mapping).
    scripts/arena/README.md "Synthesis format" now briefs the agent with the exported pack.
57. Test command: the documented `python -m pytest -q` (repository root) runs the combinator's suite through
    tests/integration/test_combinator_subproject.py (subprocess, PYTHONPATH=combinator/src:src, nothing skipped).
    Overlay venv (install only there): `/usr/bin/python3.13 -m venv --system-site-packages --without-pip
    wf/prebuild/venv` + a .pth naming z3venv's site-packages; install `z3venv/bin/python -m pip --python
    wf/prebuild/venv/bin/python install --no-deps <copy of combinator/>` (build isolation: the system setuptools 68
    is a distro build that fails under python3.13 with --no-build-isolation, AttributeError install_layout). The
    installed wheel runs with `python -I` and ships pack/ and contract/.
58. Combinator step, measured before the commit (final tree):
    - prescribed command (z3venv, PYTHONPATH=<wt>/src): 6277 passed, 45 deselected, 4 xfailed, exit 0, no skip
      (the node kit tests ran). Arena rules (scripts/arena/test_arena_rules.py, outside testpaths): 41 passed.
      Combinator suite (`cd combinator`, PYTHONPATH=combinator/src:src): 172 passed, nothing skipped.
    - documented command in the overlay venv: `cd <wt> && <overlay>/bin/python -m pytest -q -p no:cacheprovider`
      (no PYTHONPATH) -> 6277 passed, 45 deselected, 4 xfailed, exit 0. The overlay holds the translator installed
      editable from the worktree (`z3venv/bin/python -m pip --python <overlay>/bin/python install --no-deps -e <wt>`;
      pip left z3venv's own epinoic-logic alone, "outside environment"; z3venv's site-packages listing unchanged;
      the install wrote the ignored `src/epinoic_logic.egg-info/` into the worktree) and the combinator from a copy.
      A first overlay run WITHOUT the translator installed gave 2 failures, both environmental:
      tests/engine/test_overseer_round1.py::test_minimum_memory_budget_then_default_requests_never_crash_the_process
      and tests/service/test_overseer_round1.py::test_memory_budget_request_followed_by_normal_requests_leaves_the_process_alive
      spawn `sys.executable -I` (PYTHONPATH ignored) and need the translator installed, as the documented
      `pip install -e` does. FINDING (pre-existing, not changed here): under the prescribed z3venv command those two
      `-I` children import z3venv's editable translator, i.e. the MAIN checkout's src, not the worktree's; they
      exercise this tree only where the tree is installed (the overlay run above does).
    - split-ready, measured in a scratch clone only (`git clone --no-local` of integ-prebuild + the working tree
      copied in + a scratch commit): the README's `git subtree split --prefix combinator -b combinator-split`
      gives one commit of 91 files, byte-identical to combinator/; that tree alone (overlay python, no translator):
      166 passed, 6 skipped (the conformance tests, saying why); with PYTHONPATH=<wt>/src: 172 passed; its exporter
      under `python -I` writes INSTRUCTIONS.md, output-format.json, MANIFEST.json. No branch in the real repository,
      no repository created, nothing pushed.
    - arena on fresh copies (before the commit, final tree): r1 30/30, r1-adv 150/151, r2-r6 46/46, r7 177/177, all
      exit 0; every record identical to the run of the 8a78efe tree (git archive copy); versus the pre-merge
      receipts only r7 changed, 18 records, all from the merged end-to-end fixes (mai-t13 x9: ST-UNDEC-001 findings
      11 -> 7, integer powers beyond 12 now decided; maa-p7b x9: three new STEM checks stem-mod-1..3 SATISFIABLE).
59. Committed on integ-prebuild: c7a716e18e01ac8c3727600dd95f7508a382d787 "Integration: the combinator as a separate
    sub-project and agent (pre-build)" (parent f2e6953; 172 files; hygiene grep empty on the working tree and on the
    index). After the commit, in a fresh scratch clone only: `git subtree split --prefix combinator -b
    combinator-split` -> one commit whose tree 282c882b16f714a04a6383da660509ba0b57bfaf is exactly HEAD:combinator
    (91 files). The real repository has no split branch; nothing pushed. The flash router sub-project (`flash-router/`,
    D28, NOTES 23) is unchanged at this commit: its own suite 19 passed; the translator does not import it.
    Main checkout: its MERGE_HEAD is gone because its own workflow committed that merge as 8a78efe (an octopus merge,
    reflog "commit (merge): Fix the end-to-end simulation findings", 10:41:45 UTC), the commit this step merged; two
    later hourly "Testing README" commits there are another process's. This step ran no git command in the main
    checkout (read-only file reads of its reflog only).

## Repair 1 of the combinator pre-build (verification findings M1, L1, L2, L3)

60. M1 (medium, verification labels). Cause: the self-report reading (`is_self_certification`, `SELF_CERT_RE`) read only
    whole-sentence self-certifications, so a label on a content sentence ("Verified: ...", "... (verified).", "[verified]
    ...", "Checked: ...", "..., as formally verified.") was named neither at delivery nor in a synthesis (measured on the
    unrepaired tree: no finding at all on History, Economics, English, Physics, Mathematics; a sentence that was nothing
    but "[verified]" or "Verified." even became a paragraph's point or a supporting claim). Fix, one reading for the
    class: `adapters.markdown.verification_label(sentence) -> VerificationLabel(position, label) | None` (positions
    whole/before/after/inside; quotations masked; checking participles with adverbs and joins, credited to the
    infrastructure or the writer, "against the supplied text", and the status forms "Verification: passed"; never a
    participle under negation or a modal, one credited to another agent, one followed by more content, a question,
    "proved" or an accuracy adjective; lower-case "checked:" in front is code, not a label).
    - `is_self_certification` reads a sentence that is NOTHING BUT a label as a self-certification, so every parser roles
      it `other` with the advisory flag (INT-HANDOFF-006). Consequence through `split_note_clauses`: a parenthetical
      "(verified)" or a "; checked" / "— verified" clause is set apart as an inline note (content kept). The History
      parser now words such a note as a self-report, not as a from-memory label, and keeps its existing inline-label
      certainty cap at 'probable' (conservative); the other parsers' inline-note wordings were already neutral.
    - A label ATTACHED TO CONTENT is not a self-certification of the sentence: the content keeps the role and the
      materiality it has without the label (tested: 5 branches x 5 forms), so a label never takes content out of the
      checks (the round-3 doctrine for paragraphs, now for labels).
    - Hub: CORE-SELF-001 (core pack, every branch, SI reading included) names the label on the claim that holds it, with
      a whole-label or label-on-content message that never repeats the label; its message for the vocabulary
      (`SELF_CERT_RE`) is unchanged. INT-LEDGER-029 (`ledger._self_report_sentences(text, labels)`,
      `_self_report_findings`) names a label on a synthesized claim (message: the label is the self-report, the content
      is still accounted for); its message for a whole self-report is unchanged. No new code.
    - NOT changed, for the parser owners (pre-existing, recorded here): (a) a capital status word anywhere
      (`SELF_CERT_RE`: "VERIFIED: <content>", "<content> (all figures checked)") still demotes the whole sentence,
      content included, to `other` on every branch (CORE-SELF-001 says so); the same evasion shape round 3 closed for
      paragraphs; (b) the English parser's short meta block (at most 25 words opening with a META_LABEL_RE label such as
      "Verified:" or "Checked:") excludes the whole paragraph's content (ES-META-001; CORE-SELF-001 now also names the
      sentence, with no claim id since no claim exists).
    - CODE COORDINATION (NOTES 54): the INT-LEDGER-029 hunk of ledger.py now differs from argdiag's (argdiag-integ
      5faa68f still holds the version ported verbatim). When phase 2 merges the argument diagnostics, keep THIS version of
      `_self_report_sentences` / `_self_report_findings` (the label reading, the `labels` list, the two messages). The
      collision with the overseer rebuild (INT-LEDGER-029 = name substitution there; 030/031 other rules) is unchanged
      and must be resolved before merging; the tests that name INT-LEDGER-029 now also include
      tests/integrity/test_synthesis_self_reports.py (label cases) and tests/integration/test_combinator_subproject.py
      (test_a_self_certification_label_on_a_content_claim_is_caught_by_the_hub, test_a_label_the_specialist_wrote_...).
    - Probe (the verifier's probe_hub.py, run on the repaired tree): 'self-cert prefixed to material claim' OK
      (INT-LEDGER-029 on s0). Its two remaining MISSes are L3 ('stronger certainty (probably)') and 'dropped' written as a
      claim transformation (named INT-LEDGER-009 by the hub, not refused; not among the findings handed to this step).
61. L2 (low): the port model `combinator_port.SynthClaim` requires distinct `source_claim_ids` (KIT-CB-002, decided with
    the schema, before the request, the pack and the citations; a repeated unknown id is 002, not 004); the combinator's
    `contract.check_output` has the same rule at the same place; `port_rules_document().output_check_order` says so;
    schemas regenerated (combinator-output.v1: SynthClaim description; combinator-port.v1: the order line) and copied into
    combinator/; the contract digest changed (computed at run time, pinned nowhere); vectors
    output-source-claim-cited-twice and output-unknown-claim-cited-twice (both KIT-CB-002) written and copied; kit
    MANIFEST regenerated. NOT done (hub side, for the hub owners with the code allocation): a 'merged' or 'generalized'
    claim with ONE distinct source (not duplicated) is still accepted by the port and named by no hub rule
    (INT-LEDGER-010 names 'carried' only); no recorded synthesis of r1-r7 has that shape.
62. Combinator release 0.1.1 with instruction pack combinator-instructions 1.1 (digest 5ca521be...): the instructions
    and output-format.json now state the repeated-citation rule and the label rule ("never put a verification label on a
    claim; a source claim that carries one is written without it, as 'narrowed'"). Pins moved with the release (combinator
    test_pack_and_export: the identity pin to 1.1 and the "another version changes the digest" check computed from the
    release's own version; scripts/arena/test_arena_rules.py reads the version from the manifest). D33 says 0.1.1 / 1.1.
63. L1 (low): `scripts/arena/list_claims.py` compares a given export's `instruction_pack` (name, version, sha256) with an
    isolated export of the sub-project while `combinator/` is in this repository, and refuses a mismatch (exit 2) unless
    `--allow-other-release` (then a note on standard error). Order: manifest, contract format, release identity, so the
    earlier refusals keep their messages. Without `combinator/` here only the manifest and output-format.json are checked
    (scripts/arena/README.md says so). Re-measured with fresh 1.1 exports: tamper-a 2 (manifest), tamper-b 2 (format),
    tamper-c 2 (not this release; both digests named), tamper-c with the flag 0 (stderr note).
64. L3 (low): NOT changed; the fix belongs to the parser owners, outside this step. The History parser records
    'probably'/'likely' and the generic parser 'probably'/'possibly'/'may have' as established, so INT-LEDGER-003 is blind
    to certainty inflation over such sources (only INT-LEDGER-026's hedge check remains). Phase 2 or the parser owners: map
    those hedges to probable/possible in both parsers, with tests; expect recorded receipts to change (certainties of
    source claims and INT-LEDGER-003 findings on syntheses over them).
65. The flash router (user request: a separate, independent agent in a sub repository) is unchanged at this repair:
    `flash-router/` stays its own sub-project (NOTES 23, 45); its suite runs within the translator suite.
66. Repair 1 of the combinator pre-build, measured on the final tree before the commit:
    - prescribed command (z3venv, PYTHONPATH=<wt>/src, `-p no:cacheprovider`): 6414 passed, 45 deselected, 4 xfailed,
      exit 0, nothing skipped (6277 before: +137 new tests). scripts/arena/test_arena_rules.py: 42 passed (+1).
      combinator/ own suite (PYTHONPATH=combinator/src:src): 176 passed, nothing skipped (+4). flash-router/: 19 passed.
    - the new label tests fail on the unrepaired tree (tests/channel/test_verification_labels_at_delivery.py: 30 of 35
      fail there, the 5 controls pass; tests/adapters/test_verification_labels.py cannot import the new reading).
    - arena on fresh copies (wf/prebuild/arena-repair-combinator-1): r1 30/30, r1-adv 150/151, r2-r6 46/46, r7 177/177,
      all exit 0; every record and every top-level field identical to the combinator step's run (arena-combinator,
      compare.txt there): no receipt changed (no recorded answer or synthesis carries a label form; the one hit, r1-adv
      hi-t2-fake-receipt "VERIFIED by the Z3 engine: ...", was already a whole self-report).
    - verifier probes on the repaired tree: probe_hub 2 MISS left (L3 and 'dropped' as a claim transformation, see 60),
      probe_input 4000 inputs 0 mismatches, probe_out_fuzz 3000 outputs 0 mismatches 0 leaks, probe_runner unchanged
      from the unrepaired tree (its one "DIFFERENT CODE" line, the agent writing the port's instruction_pack_sha256 key,
      is the agent format being stricter than the port, by design).
    - hygiene grep empty.
67. Committed on integ-prebuild: ecd5a58fee04231ef6fb83784809866aeca497d3 "Integration: fix the combinator pre-build
    verification findings (round 1)" (parent c7a716e; 40 files; hygiene grep empty on the working tree, the index and
    HEAD). Nothing pushed; no command was run in the main checkout.

## Repair 2 of the combinator pre-build (verification findings V2-M1 to V2-M3, V2-L1 to V2-L5)

68. V2-M1 (medium, self-reports and labels on syntheses). Cause, two readings: (a) the hub read a synthesis with the
    specialists' self-certification reading, whose "answer itself" is "this answer", "this paragraph", "the figures here":
    the combinator's own product ("the synthesis", "this synthesis", "the combined answer") was never a subject; (b) the
    label reading had no check marks, no compound participles ("source-checked"), no "against the sources" (only "against
    the supplied/original/source/given/provided <text>"), no status noun ("accuracy confirmed"), no verdict ("proven
    correct") and no "Accuracy:" status key. Fix:
    - `adapters.markdown.verification_label` (every branch: CORE-SELF-001 at delivery, the parsers' notes, INT-LEDGER-029)
      reads check marks (✓ ✔ ☑ ✅, alone, before, after or inside content), compound participles ("source-checked",
      "spot-checked", "Z3-verified", "formally-verified"), "against/with the sources, the specialists' reports, the
      original(s)", status nouns ("(accuracy confirmed)", "(facts checked)", "Figures verified."), verdicts ("Formally proven
      correct.", "(verified correct)", "shown to be accurate", "Checked and correct.") and "Accuracy: confirmed". After a
      bare comma at the end only a label with a complement, a verdict or a status noun counts (", checked against the
      sources."), since ", checked." may close a sentence about history. Controls kept: negation ("(not source-checked)",
      "(accuracy not confirmed)"), a check credited to another agent ("(verified by the History specialist)"), against a
      record the writer names ("(checked against the Registrar General's returns)"), a cross ("✗"), a quoted mark,
      "Proved." alone, an accuracy adjective alone. A label on content still leaves the content a claim (round-1 doctrine);
      a sentence that is nothing but one is a note.
    - `adapters.markdown.is_synthesis_self_certification` (new; the hub's reading of a synthesis, used by
      `ledger._self_report_sentences`): the specialists' rules plus the combined product as the answer itself ("The
      synthesis has been verified.", "This synthesis is correct.", "Every synthesized claim was checked against the
      sources.", "All claims in this synthesis were verified.", "The combined answer accurately reflects the sources.",
      "This synthesis has passed every check.", "Z3 has verified this synthesis.", "Nothing in this synthesis needs
      checking."), with the structural limits (copula + participle/adjective closing the clause; never under negation or a
      modal; never a check credited to another agent, "checked by the History specialist"; never quoted; never "the
      synthesis of ammonia"). DESIGN DECISION, recorded for the verifiers: `is_self_certification` (the specialists'
      reading) still returns False for "The synthesis has been verified." on purpose: on a specialist's branch "the
      synthesis" is chemistry or biology content ("This synthesis was confirmed by NMR"), and a false self-certification
      there would take content out of the checks; the combinator's words are read with the synthesis reading, which is
      what the hub uses (the verifier's selfcert.py prints False in its first column and True in its third for those two
      sentences, by design).
    - `ledger._self_report_findings`: a self-report sentence written beside a claim's content ("<content>. The synthesis
      has been verified.") gets its own message ("states a verification status of the answer beside its content ... its
      content is still accounted for"), no longer "no material content" (the whole-self-report and label messages are
      unchanged).
    - Linear time: a check mark is excluded from the label's punctuation class and a run of marks is one possessive unit
      that starts only where a run starts (a first draft took minutes on 20,000 marks; measured < 0.01 s now, test
      `test_a_long_run_of_check_marks_is_read_in_linear_time`). PRE-EXISTING, NOT changed (for the parser owners):
      `markdown._TERMINAL_RE.search` in `_split_note_clauses` is quadratic on a long run of terminal punctuation ("!" x
      20,000 + " x": 9.6 s on the unrepaired tree, 7.2 s without the mark); every parser runs it per sentence.
69. V2-M2 (medium, dropped qualifiers). Cause: `dropped_hedges` read the hedge vocabulary only ("suggests", "may have",
    "probably"); the pack's rule 4 also lists "only" and "to a limited extent", and an approximation dropped in front of a
    figure was read only when an exact word replaced it ("exactly 60"). Fix: `ledger.dropped_qualifiers` (called from
    `meaning_differences`, so INT-LEDGER-026, warning, lexical), read on the clause of the synthesized claim that restates
    the source's clause (half of its content words or more, three at least): a restricting qualifier ("only", "merely",
    "solely", "exclusively", "just" before a quantity; "not only" and "if only" excluded) whose restricted word the clause
    keeps; a degree limit ("to a limited/certain/small/lesser extent", "to some extent", "to a degree", "partly",
    "partially", "in part" but never "in part (a)", "somewhat", "up to a point", "in some respects"); an approximation in
    front of a figure ("about", "around", "roughly", "approximately", "nearly", "almost", "some", "c.", "circa", "just
    over/under", "an estimated") dropped while the same value with the same unit or scale word is kept and no cited source
    states it exactly. Quotations are masked. And `_OPPOSED` gained minority/majority ("a minority or a majority").
    Integrity README row INT-LEDGER-026 updated. Two false positives of a first draft, caught by the pinned guard
    tests/integrity/test_round7_integrity.py::test_every_r7_synthesis_is_read_without_a_false_re_pairing_or_meaning_change
    (not changed), were fixed at their cause: a comparison or bound ("far fewer than 1,000" in r7 cs-t13, whose 1,000 is
    exact) is no approximation, and a qualifier in front of a formula ("Checking only t = 0 and t = 8", r7 maa-p7b) has no
    lexical scope (the scope is the first token after the qualifier that is no function word; a variable or symbol there
    means the qualifier is not read).
70. V2-M3 (medium, wrong attribution). Cause: the view credit (`adapters.sources.credited_agents`) read a specialist only
    with a possessive or as the subject of a crediting verb; a statement credited to a text without quotation marks was
    read by nothing (INT-LEDGER-025 needs a quotation). Fix: `credited_agents` also reads "according to", "in the view /
    words / opinion of", "as noted / argued / ... by", "per", a clause-initial "For <specialist>, ...", and verbs of view
    ("believes", "considers", "rejects", ...); new `adapters.sources.unquoted_credits` (statements credited without
    quotation marks to a named source: "According to X, ...", "..., according to X.", "In X's view, ...", "As X notes,
    ...", "X states / says / records / declares ... that ...") and `ledger._text_credit` (INT-LEDGER-026): a credit is named
    when none of the cited source claims names the source and, for a text in scope (named by author, title, a word of its
    title such as "the treaty", or its kind when it is the one literary text), the text does not hold the statement either
    (half of its content words, three at least). Not read: a source named by a pronoun or a group ("It", "Historians"),
    a specialist or a specialist's report (the view credit's), the request or the infrastructure. Phase 2 (NOTES 55,
    unchanged): the credit rules still recognise a specialist only for agent ids `<subject>-specialist`. Linear time: a
    first draft of the trailing form ("..., according to X.") backtracked for 15 s on 4,000 spaces; that form is now found
    by its comma and the clause before it read in code, the other forms open on at most eight marks read possessively, and
    the words before a specialist's name are read in a bounded window that starts with a word character where it cuts the
    text (so "paper the" never reads as "per the"). Each qualifier's scope and its "not"/"if" lead are read in bounded
    windows too (test `test_the_new_readings_take_linear_time_on_adversarial_text`).
71. V2-L1 (low, certainty of hedged sources; NOTES 64 done). New `adapters.markdown.hedged_certainty` (the writer's hedges,
    quotations masked: possible for "may/might/could (well) have", "may/might be", "possibly", "perhaps", "conceivably",
    "it is possible that"; probable for "probably", "most/very/highly/quite likely", "in all likelihood", "it is
    likely/probable that", "likely to have", "presumably", "arguably", "apparently", "plausibly", "appears/seems to",
    "suggest(s/ed)"; a bare adjective "likely", "unlikely", "provisional" is content, "could be" may be an option). The
    History parser's `certainty_of` keeps the weaker of its own cues and this reading (never raises a certainty); the
    generic parser records it (it recorded "established" for every claim before). STEM and English parsers unchanged.
    On the recorded rounds this changes three generic-branch source claims, all to probable (r7 bm-p7a g7.4 "probably",
    r7 ge-t13 g8.4 "a suggested process", r7 ps-t13 g2.4 "This suggests"), and no History claim, and no receipt (item 78:
    the recorded r7 generic syntheses cite ids without the parser's "@agent" suffix, so the hub already names them
    INT-LEDGER-001 and compares no certainty; the bm-p7a and ge-t13 syntheses label "established" a merged claim whose own
    text keeps the hedge, which a synthesis citing the current ids would be charged INT-LEDGER-003 for).
72. V2-L2 (low, parsed objects). Cause: `Contract._parsed` (combinator) and `combinator_port._data` (kit) parsed text
    strictly but passed a parsed object through unchecked, so a dict input whose claim text held a lone surrogate reached
    `sha256_text` and the runner refused it as its own internal error (KIT-CB-002), and `check_output` on such a dict
    raised UnicodeEncodeError. Fix, both sides the same: a non-text message is held to the protocol JSON rules first
    (`check_value`: lone surrogate, float, non-string key, non-JSON value, unsafe integer) and refused as not protocol JSON
    (input_not_json KIT-CB-001; output_not_json KIT-CB-002), before the transformation rule, so the codes agree even for a
    dict that is both. `port_rules_document().output_check_order` says so (combinator-port.v1.json regenerated and copied
    into combinator/; the contract digest changed; it is computed at run time and pinned nowhere). Combinator release
    0.1.2 (pyproject, __version__, D33), instruction pack unchanged (combinator-instructions 1.1, same digest). Tests:
    combinator/tests/test_contract.py (six parsed values, the runner's refusal names no request) and test_conformance.py
    item 7 (both sides one code).
73. V2-L3 (low, arena briefing). `scripts/arena/list_claims.py --agent-view <files of one group>` prints the document the
    runner gives its agent ("What you receive" of INSTRUCTIONS.md), built with `combinator_port.source_report` /
    `build_input` under the exported pack's identity and rendered by the combinator's own `prompt.render` in its own
    `python -I` process (the script still never imports the sub-project). The port takes two to sixteen sources, so a
    single report is refused (exit 2) and the arena README says how its `--json` listing maps onto request/sources and
    that the agent writes no `report_id` (the runner refuses it; the recorded rounds' `report_id` predates the
    sub-project and the harness does not read it). INSTRUCTIONS.md is NOT changed (the pack describes the runner's input,
    which the arena now gives for a group; changing it would only add arena tooling to the production pack). Test:
    tests/integration/test_combinator_subproject.py (the printed view equals `prompt.agent_view` of the input; a single
    report refused). list_claims' default outputs are unchanged (scripts/arena/test_arena_rules.py 42 passed).
74. V2-L4 (low, non-formal contradictions): docs only, as the finding allows. INT-CONFLICT-002 is named between formalized
    claims only; a contradiction in prose ("signed in June 1919" against "signed in July 1919") is never in
    `conflicts_seen`, and a synthesis that merges it or keeps one side is named only through the figures it changes or
    drops (INT-LEDGER-023/024). Stated in combinator/README.md, combinator/docs/DESIGN.md,
    integration/combinator-port/CONFORMANCE.md, integration/PROTOCOL.md section 7, the integrity README row,
    scripts/arena/README.md and tests/README.md. A lexical same-subject conflict reading is left to the hub owners.
75. V2-L5 (low, split-ready trees): `combinator/.gitignore` and, for the same split-ready shape of the user's separate
    flash-router agent, `flash-router/.gitignore` (__pycache__/, *.py[cod], .pytest_cache/, .hypothesis/, *.egg-info/,
    build/, dist/, .venv/); test `test_the_split_ready_trees_ignore_what_a_test_run_leaves`.
76. The flash router (user request: a separate, independent agent in a sub repository, edited apart from the Z3
    infrastructure) is otherwise unchanged at this repair: `flash-router/` stays its own sub-project (NOTES 23, 45, 65), its
    own suite 19 passed, the translator does not import it; it now ignores its test caches in a split repository too.
77. CODE COORDINATION for phase 2 (adds to NOTES 54 and 60): ledger.py changed again in the INT-LEDGER-029 hunk
    (`_self_report_sentences` reads with `is_synthesis_self_certification` and takes a `content` list; a third message) and
    in INT-LEDGER-026 (`dropped_qualifiers`, `_dropped_approximations`, `_text_credit`, the minority/majority class);
    keep THIS version when the argument diagnostics or the overseer rebuild merge (their ledger.py hunks may collide; the
    INT-LEDGER-029 code collision of NOTES 54 is unchanged).
78. Repair 2 of the combinator pre-build, measured on the final tree before the commit:
    - prescribed command (z3venv, PYTHONPATH=<wt>/src, `-p no:cacheprovider`): 6615 passed, 45 deselected, 4 xfailed, exit 0
      (6414 before: +201 new tests); it runs both sub-projects' own suites (combinator 184 passed, nothing skipped;
      flash-router 19 passed). scripts/arena/test_arena_rules.py (outside testpaths): 42 passed.
    - the new tests fail on the unrepaired tree (a `git archive` of ecd5a58 with only the new test files copied in): 91 of
      the translator-side cases fail there, tests/adapters/test_synthesis_self_certification.py cannot import there (the
      new readings), and 8 of the combinator's new contract and conformance cases fail there; every control passes on both.
    - the first full run had one failure, the pinned r7 guard of item 69 (two false positives of the first draft); fixed at
      the cause, the guard unchanged.
    - arena on fresh copies (wf/prebuild/arena-repair-combinator-2, compare.txt there): r1 30/30, r1-adv 150/151, r2-r6
      46/46, r7 177/177, all exit 0; every record and every top-level field identical to repair 1's run
      (arena-repair-combinator-1): no receipt changed. No recorded answer or synthesis carries the new label forms, "the
      synthesis" or "according to" (scanned); for L1 see item 71.
    - verifier probes on the final tree: probe_hub2 35 OK, 0 MISS (5 INFO lines carry no expectation); selfcert_hub names all
      five with INT-LEDGER-029; probe_runner2 BAD 0, the parsed dict with a lone surrogate refused input_not_json
      KIT-CB-001 with no ids; contra.py unchanged (conflicts_seen empty: item 74, documented).
    - split-ready, in a scratch clone only (`git clone --no-local` of integ-prebuild, the working tree copied in, a scratch
      commit): `git subtree split --prefix combinator` and `--prefix flash-router`; standalone, the combinator tree gives 184
      passed with a translator importable and 177 passed + 7 skipped (the conformance tests, saying why) with none, the
      flash-router tree 19 passed, and `git status --porcelain` is empty in both after the runs (their caches are ignored).
      No branch in the real repository, nothing pushed.
    - generate.py, vectors.py, build_corpus.py and manifest.py `--check`: all 0 (kit MANIFEST regenerated: the port rules
      file, PROTOCOL.md, CONFORMANCE.md, DECISIONS.md, combinator_port.py); the website patch material is untouched (it copies
      no combinator-port file; RESULT.sha256 unchanged).
    - hygiene grep empty.
79. Committed on integ-prebuild: 5697a62bdfa86991e9796a1abde3fa493667a574 "Integration: fix the combinator pre-build
    verification findings (round 2)" (parent ecd5a58; 30 files; hygiene grep empty on the working tree, the index and
    HEAD). After the commit, in a fresh scratch clone only: `git subtree split --prefix combinator` gives a tree identical to
    HEAD:combinator (94 files, .gitignore included) and `--prefix flash-router` one identical to HEAD:flash-router (21
    files). Nothing pushed; no command was run in the main checkout (all git commands used -C on the worktree, or ran in
    scratch clones).
