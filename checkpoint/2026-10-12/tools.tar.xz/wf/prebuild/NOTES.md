
# Pre-build step: integration protocol and integration kit (branch integ-prebuild)

Written by the pre-build step that implements INTEGRATION_KIT_DESIGN.md sections 3, 4, 5, 6.3 (6.1/6.2 as patch
files in the kit), 7.1/7.4/7.5/7.7, 8 and the fifth port (flash router, epinoic.integration.router-port.v1).
Append-only; earlier and later steps keep their own sections.

## State of this tree (what is NOT here, by design of the pre-build)

- No overseer package (src/epinoic_logic/overseer absent), no named-policy allowlist (engine.policies has no
  NAMED_POLICIES / named_policy), contract 0.2 in docs/integration-contract.md, no argument diagnostics, no closed
  transformation values, no combinator, no flash-router sub-project. Nothing in the kit stands in for any of them.
- Consequence on this tree: `EPINOIC_PROFILE=integration-sim python -m epinoic_logic.integration preflight` refuses with
  `KIT-HS-006 named_policies_unavailable` (exit 2). After phase 2 merges contract 0.3 it refuses with
  `KIT-HS-007 overseer_unavailable` until the overseer port adapter exists; only then does it start.
- The contract tests run against fixtures: tests/integration/helpers.py has RecordingPort (a TEST DOUBLE of the overseer
  port, not importable by the package) and FixtureProbes (replaces only the named-policy and overseer probes).

## What phase 2 must connect (exactly)

1. Named policies (contract 0.3). `Probes.named_policies()` (src/epinoic_logic/integration/preflight.py) requires
   `epinoic_logic.engine.policies.NAMED_POLICIES` (a mapping whose keys are exactly joint, linear, nonlinear) and a
   callable `epinoic_logic.engine.policies.named_policy`. If 0.3 names them differently, change ONLY this probe and
   `selftest.resolve_policy` (which today resolves linear/nonlinear through PACK_POLICIES and joint through
   JOINT_LIMITS); then recompute nothing: the self-test's pinned digests are build-independent and must stay equal
   (tests/integration/test_selftest.py recomputes them; a difference means the policy semantics changed).
2. Overseer port adapter: module `epinoic_overseer.port` (env EPINOIC_OVERSEER_PORT, default that name) exposing
   `connect(config) -> port`. config = {engine_key, engine_key_id, overseer_secret, replay_mode: "process", agents}.
   The port object must implement (integration/overseer_port.py, class OverseerPort):
   - hello() -> epinoic.integration.overseer-hello.v1 (port_version 1.0, mode embedded, auditor_version, pack_digests =
     the exported pack's PACK_DIGESTS, key_ids incl. overseer-audit, replay_mode process, inline_final_release false,
     max_pending_wait_ms <= 250, agents off|async, profiles [standard] or [standard, fast]);
   - new_hub(signing_key, key_id, verify_claim_fn, config) -> a RouterHub with a TransferAuditor attached (KeyRing of
     the engine key + the overseer secret's subkeys; replay_mode "process");
   - clearance(hub, task_id, message_id, receipt, wait_ms) -> overseer-clearance.v1 from hub.clearance +
     policy.act_decision, waiting at most 250 ms; receipt_sha256 MUST equal turn.receipt_sha256(receipt)
     (= sha256 of ir.canonical.canonical_json(receipt)); if the overseer journals `receipt_digest` differently, phase 2
     changes turn.receipt_sha256 to the overseer's function and keeps the equality test;
   - close(hub, task_id) -> overseer-final-audit.v1 from hub.close_task (scope FINAL, signed under overseer-audit,
     channel_uid, journal_head, engine scope statement and the TR6 sentence verbatim);
   - deliver(hub, task_id, mode, synthesis=None) -> overseer-delivery.v1 from hub.consolidate +
     delivery_decision(..., hub=hub) (kind consolidation) or release_decision (kind release, synthesis only);
   - view(hub, task_id) (hub.view), repeats(hub, task_id) -> {transfer key (message id): repeated-fault count}
     (hub.repeats; feeds the flash router's request), review(hub, task_id, admission) -> overseer-review-ticket.v1
     (asynchronous overseer-agent review under the admitted plan; never on the critical path).
   - Map EVERY reason the overseer's delivery_decision / release_decision gives onto exactly one label of
     protocol.OVERSEER_REFUSALS (clearance_failed, clearance_pending, final_audit_not_passed, signature_invalid,
     custody_failed, stale, consolidation_conflicting, no_deliverable_output, receipt_error_findings, not_deliverable);
     an unmapped reason must be a test failure, never a silent "not_deliverable".
   - Run the RecordingPort-based TurnChecker tests against the real adapter too (tests/integration/test_turn_checker.py:
     parametrize the port fixture), and the overseer tampering suite T1-T22 must still name its codes.
3. TR6 sentence: protocol.AUDIT_SCOPE_STATEMENT is restated verbatim; tests/integration/test_protocol_constants.py pins
   its start and its end. Phase 2 adds the assertion `AUDIT_SCOPE_STATEMENT == <overseer constant>` (the overseer is absent
   here, so that half of the pin cannot exist yet).
4. Flash router: sub-project `flash-router/`, package `epinoic_flash_router`, module `epinoic_flash_router.port`
   (env EPINOIC_FLASH_ROUTER; `none` detaches it) exposing `hello() -> str` (router-hello.v1 JSON) and
   `plan(request_json: str) -> str` (routing-plan.v1 JSON). The planner the overseer rebuild is building moves there.
   The kit never imports it except through router_port.attach_router; the floor (router_port.FLOOR_RULES,
   minimum-oversight-floor/1) stays in the translator and is enforced whatever the router says. The router's identity
   (name, version, rules_sha256, cost_data_sha256) must be stable per release; integration/router-port/CONFORMANCE.md
   lists what the sub-project's own tests must show. Model ids are never in a plan (KIT-RT-009).
5. Argument diagnostics: routing_features.OutputRecord.diagnostics is () today. Phase 2 passes the named diagnostic
   codes of each output (codes only, matching the finding-code pattern). They only escalate (risk signals).
6. Repeated faults: TurnChecker._review reads port.repeats(); RecordingPort returns {} by default.
7. Closed transformation values: combinator_port.VOCABULARY (5 values) is the kit's draft; phase 2 replaces it with the
   end-to-end fixes' closed values (KIT-CB-003 for anything else) and regenerates the schemas
   (python integration/tools/generate.py; then python integration/tools/vectors.py; then the MANIFEST).
8. Combinator: Probes.combinator() reports available=false, so the checks port never offers `combined` (KIT-REQ-002).
   Phase 2 connects the combinator sub-project (provider call with a pinned instruction pack) and the release path
   (TurnChecker step 6, currently a no-cover raise).
9. Delivery rule: delivery.decide is the kit's decision table; phase 2 checks it against the rebuilt overseer's
   delivery rule on the same vectors (integration/vectors/decision-table) and records any difference as a decision.
10. Merge conflicts to expect: src/epinoic_logic/cli.py (engine imports moved into the commands; KEEP the lazy imports,
    tests/integration/test_bootstrap.py fails otherwise), src/epinoic_logic/channel/bus.py (stem_budget_s() and
    TranslatorChannel.stem_budget_s; keep both), src/epinoic_logic/service/app.py (create_app(..., integration=None)).
11. Contract version: protocol.INTEGRATION_CONTRACT_VERSION = "0.4" and COMPATIBILITY.json components.contract ["0.4"].
    docs/integration-contract.md keeps its "Contract version" line as it is on this tree (0.2) and adds a section
    "Integration protocol (contract 0.4)" stating that 0.4 takes effect when phase 2 merges 0.3; phase 2 updates the
    version line to 0.4 after the merge (playbook step 5 greps for it).
12. Live providers: runtime.live_verifier uses a 20 s per-call timeout and has never been run live (no provider call
    was made). Phase 2 sets per-call timeouts from the measured budget and keeps the cheapest tier; model ids stay a
    decision placeholder (DECISIONS.md D3).
13. Website base P: not built (COMPATIBILITY.json website_bases.P). Patch set P needs a base-P website.
14. Fixture verifier parity: the sim's fixture verifier is called as fn(claim, report) WITHOUT a task, exactly as
    scripts/arena/run_arena.py does, so it serves the same fixtures (tests/integration/test_fixture_parity.py).
15. Sim solver configuration: integration-sim uses the arena's SolverConfig (4000 ms per call, no memory limit) so the
    G-EQ-ARENA comparison compares like with like (runtime.solver_config_for).

## Pre-build step, continued: what else phase 2 must connect or re-check

16. Simulation drivers: integration/sim/website-driver.mjs and agents-driver.mjs stop at their prerequisite checks
    (exit 3, "connected in phase 2"). Phase 2 writes the replay loop over integration/sim/users.json on a patched
    disposable export (apply.mjs) with options.verified.inner = createSpecialistOrchestrator over the agents copy's
    createOfflineTestRuntime + synthetic bundle (authorizedGenerate returns each corpus item's response_text), and
    feeds gates.py: website projections from the evidence tap (compare.receipt_projection of the specialist_to_router
    receipt with the item's fixture ids), the fault replay, the invariants, the displayed labels, the verdicts, the
    handler-level W-T1..W-T8. Until then run_sim.py reports all eight gates NOT RUN and exits 1 (tested).
17. G-EQ across request ids: the website path's request id is the attempt id, the arena's is req-<item>. The fixture
    provider re-keys problem.request_id to the claim's request id (verifier.RekeyingFixtureProvider; a no-op in the
    arena), and compare.result_digests normalises the problem's request id before hashing (engine's own problem_digest
    and binding_digest_of). tests/integration/test_fixture_parity.py shows the normalised digests equal on both paths.
    If the overseer journals digests of the raw problem, phase 2 keeps this normalisation in the comparison only.
18. Synthetic corpus: History answers end with the runtime synthetic gate's sources line ("Sources: none consulted (no
    retrieval in this session)") so the website path's runtime gate passes; the parser makes it a NOT_ELIGIBLE claim.
19. Website patch material (base M, 2cd3182): 39 blocks + 107 copied files, tested on a disposable export: 354/357
    (the baseline's 3 Playwright failures only), apply --verify exact, rollback rehearsal 4 PASS + base P NOT RUN.
    tests/integration/test_website_kit.py fails when any copied kit file changes after RESULT.sha256 was written:
    re-run the cycle (fresh export -> apply --write-result -> website suite -> fresh export --verify) and update
    TESTED.json. Under the verified backend the handler always sends X-Chat-Simulated: 1 (M1 never has both parts
    live); base P must derive it from outcome.kit.simulated. W5 (usage/caps migration) is not built. Live routing
    under the verified backend is covered by the disclosure test only, not by a handler test.
20. Agents: A2 (integration/agents/checks-port/) built and tested on an archive copy (3/3, portable, runtime suite
    120/120 unchanged); A1 and A4 are prose for that repository's owner; A3 (check_answer.py reading the public view)
    and A5 (adjudicator advisory flag) are connected in phase 2.
21. Patch set P (website base P) and the W0 docs patch are not built; the W*.patch files are not published (D20).
22. Request ids of the website (turnId/attemptId) must match the protocol's Id pattern; the website's ID_PATTERN
    ^[A-Za-z0-9_-]{8,100}$ is a subset, so no mapping is needed (D11).

## Repair 1 of the protocol pre-build (verification findings M1-M5, L1-L5, playbook lens): what phase 2 must know

The findings list handed to this step was cut off after the playbook item "playbook-no-rollback-step" (its fix text ends
mid-sentence at "apply.mjs --base M --target"); later items, if any, were not visible here and are not addressed.

23. Flash router sub-project (user request: a separate, independent agent in a sub repository, edited apart from the
    Z3 infrastructure): `flash-router/` now exists in the translator repository as a project of its own
    (`pyproject.toml` name `epinoic-flash-router` 0.1.0, no runtime dependency, package `epinoic_flash_router` with
    `port.py` hello/plan, `planner.py`, `rules.py` = rules/1 + parameters + a cost model of planning estimates, its own
    `tests/` with CONFORMANCE items 1-6 and an independence test). It is a sub-project directory, not a separate git
    repository or submodule (no remote was available and nothing is pushed); `git subtree split --prefix flash-router`
    makes one if the owners want it. The kit's `integration/tools/vectors.py` copies the router-port vectors into
    `flash-router/tests/vectors/router-port/` (drift-tested). The overseer rebuild has no planner (deferred), so this
    is THE flash router; if a planner appears later it moves into this sub-project as a new version (new identity).
24. NOTES item 4 is superseded on two points: (a) the default of `EPINOIC_FLASH_ROUTER` is now `none` (attached only
    when named; ROLLBACK "remove the variable" and D28 now agree with settings.py); (b) the router never runs in the
    service process: `router_port.run_router` starts `python -I router_child.py` per call with the service's sys.path
    (sent in the job), cwd = the service's cwd, env = only `router_port.CHILD_ENV_NAMES` (no EPINOIC_ variable, no
    provider key), stderr discarded, at most HELLO_TIMEOUT_S = 10 s for the hello and min(PLAN_TIMEOUT_S = 3 s, budget
    left) per plan, answer at most 1 MiB, killpg of its session on a timeout. ASSUMPTIONS for phase 2: the service runs
    on POSIX; `sys.executable` of the service can import the router module (installed, or on the service's sys.path);
    the hosted image installs `flash-router/` only if D28 says hosted environments attach it.
25. Codes (decided here, PROTOCOL 7a.5 is normative): `route()` refuses a router that raises, exits, times out or
    answers with a non-text value / non-JSON text with KIT-RT-016 (the one existing test that pinned KIT-RT-001 for
    "not json" through route() now expects 016, with a comment; `check_plan` called directly on non-JSON text still
    says 001). A configured but unimportable module is detached with KIT-RT-016 (L3; that test now expects 016 instead
    of None); not configured stays refusal None. A module without hello()/plan() is 015 at attach time.
26. Step 10 of the TurnChecker (M1): every failure of the review (router, port.repeats, port.review, a ticket out of
    contract or for another plan) leaves `review.queued = false`, is recorded as `evidence["review_error"]` (type and
    code only), and never changes the decision or its reasons. `check_review_ticket(..., origin=, plan_id=, refusal=)`
    now requires the ticket to name the admitted plan (KIT-OP-010 otherwise): the embedded adapter's `review()` must
    echo `admission.origin`, `admission.effective.plan_id` and `admission.refusal` (RecordingPort does), and must queue
    without waiting (overseer-port CONFORMANCE item 6). `CheckerConfig.router_timeout_s` (default 3 s) is the cap.
27. M5: `delivery.counts_problem` and `release-gate.js countsProblem` (same rule both sides): listed counts are lower
    bounds; exact when every claim is listed; every count but claims_total exact when every material claim is listed;
    the counts must be coherent (eligible + not_eligible == material, attempted/definitive/unavailable within eligible,
    positive <= definitive, permitted <= positive, definitive - positive <= blocking <= material). New verdict-binding
    vectors: truncated-list-bound (ok), truncated-list-hides-timeout, -hides-counterexample, -inflates-permitted,
    more-listed-than-counted, counts-incoherent (kit_dl_030). Phase 2 invariant to keep: the verdict's listed claims are
    a sub-multiset of the counted claims with the same (materiality, formal, attempt, release_permitted) fields.
28. Badge (playbook high + L1): `checksBadge(summary)` in the website's chat-contract.js (block 01), used by block 13;
    copy recorded under D27 (still open): passed for formally_checked/partly_checked/formal_only, "Not formally checked"
    for not_formally_checkable and unknown, "Some checks unavailable" for incomplete. Vectors chat-contract/labels.json
    gained `badges` and `unknown_summary_badge`. Website patch set M re-tested on fresh exports of 2cd3182: baseline
    287/290 (3 Playwright), patched 356/359 (same 3), 69 new tests, --verify exact, check-website --anchors all
    expected, rollback rehearsal 1-4 PASS, 5 NOT RUN; RESULT.sha256 and TESTED.json rewritten.
29. Readiness (M3): `check.py --router` now BLOCKs unless every router-port vector's plan is ADOPTED (origin router,
    no refusal; refusal codes listed per vector) and adds a determinism row. The fixture router of
    tests/integration/helpers.py (`write_router_module` default body) was made floor-conforming (all five agreement
    signals, N_FOLD for a combined synthesis): the old one passed only because the check was vacuous.
30. L2: `router_port.MODEL_FAMILIES` refuses a plan_id or router name naming a model family (KIT-RT-009; hello 015).
31. Vocabulary: REASON_CODES gained `risk_diagnostics` and `risk_unverified_dependencies` (routing-plan.v1 schema
    regenerated) so a router's escalations on features the floor does not read are named honestly.
32. L5 floor/2: `minimum-oversight-floor/1` is unchanged (same digest); it reads neither diagnostics nor unverified
    dependencies; the flash router escalates on both. Phase 2 decides floor/2 (D29) when the argument diagnostics are
    connected; until then the floor's digest pinned in the vectors and capabilities stays the same.
33. L4 (for phase 2): preflight must compare the overseer hello's `pack_digests` with the overseer package's own
    `PACK_DIGESTS`, imported independently of the adapter module (or pinned in COMPATIBILITY.json), and refuse
    `KIT-HS-007` on a mismatch; `check_hello` alone only checks the digests' shape (helpers use "ab"*32).
34. Playbook: step 7a is no longer "connected in phase 2" (runs the sub-project's suite, then check.py --router with
    PYTHONPATH=<kit>/flash-router/src); new step 11a (rollback rehearsal on base, W1-only and full exports) and step
    11b (configuration by NAME only: service and Worker variable names, owner actions, no value set or read).
