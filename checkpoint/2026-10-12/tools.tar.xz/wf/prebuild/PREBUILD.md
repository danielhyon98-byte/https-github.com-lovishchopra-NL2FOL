# Pre-build hand-off for phase 2, first integration step

Phase 2's first integration step merges the local branch `integ-prebuild` into the integrated tree and adapts it there.
This file was written read-only. No command changed the main checkout or the worktree.

- Branch: `integ-prebuild` (worktree `/home/user/https-github.com-lovishchopra-NL2FOL/.worktrees/integ-prebuild`, clean)
- Tip: `5697a62bdfa86991e9796a1abde3fa493667a574`
- Merge base with `claude/z3-verification-engine-plan-nk3luq`: `8a78efe` (the end-to-end fixes octopus merge). That
  branch has moved on since then, to `7991e8b`, so expect the merge to bring in newer integrated work.
- Nothing has been pushed. Neither part is verified (`verified: false`). Both parts still have open findings from the last
  verification round (see below).

## Commits (`git log --oneline claude/z3-verification-engine-plan-nk3luq..integ-prebuild`)

```
5697a62 Integration: fix the combinator pre-build verification findings (round 2)
ecd5a58 Integration: fix the combinator pre-build verification findings (round 1)
c7a716e Integration: the combinator as a separate sub-project and agent (pre-build)
f2e6953 Merge the end-to-end fixes into the integration pre-build
af10b4a Integration: fix the protocol pre-build verification findings (round 2)
067da31 Integration: fix the protocol pre-build verification findings (round 1)
3dcee98 Integration: integration protocol and integration kit (pre-build)
```

## Merge command

From the integrated tree's checkout, with a clean index and working tree:

```
git merge --no-commit --no-ff integ-prebuild
```

Conflicts to expect (NOTES 10, 48):
- `src/epinoic_logic/cli.py`: keep the lazy engine imports and `POLICY_NAMES_HELP`.
- `src/epinoic_logic/channel/bus.py`: keep `stem_budget_s`.
- `src/epinoic_logic/service/app.py`: keep `create_app(..., integration=None)`.
- `ledger.py`: keep THIS branch's INT-LEDGER-029 and INT-LEDGER-026 hunks (NOTES 54, 60, 77). The INT-LEDGER-029 code
  collides with the overseer rebuild (ef4ba9f / d149738), which uses 029 for name substitution. Resolve that collision
  before those branches merge.

## Part 1: protocol and kit (3dcee98, 067da31, af10b4a; merge f2e6953)

- Complete as a pre-build: yes. By design, the phase-2 parts are absent and nothing stands in for them.
- Verified: no. The last verification round on 3dcee98 left these findings open:
  - V3-M1 (medium): the service decides KIT-DL-013 over all claims, but the Worker re-derives it from listed claims only.
    It misses claims without an excerpt and claims beyond the first 32.
  - V3-M2 (medium): `TurnChecker.check` and the step-10 review catch only `Exception`. A BaseException escapes the
    "never raises" guarantee and the "never change the decision" guarantee.
  - Low findings V3-L1 to V3-L7:
    - L1: the router is a sub-project directory, not a repository (D28).
    - L2: the floor's reserved identity is accepted in `check_hello`.
    - L3: `CheckerConfig` has no `repr=False` on its keys.
    - L4: turn.js does not bind `result.text` to `answer_sha256`.
    - L5: no review is queued on the early-refusal path.
    - L6: a misspelled `EPINOIC_PROFILE` silently starts the plain service.
    - L7: `post_outcomes` imports an adapter module chosen by text from the request.
  - Playbook findings PB3-01 to PB3-08:
    - PB3-01: the apply command is missing from step 10.
    - PB3-02 and PB3-03: BLOCKER rows have no phase-2 marks, and `--website-copy` is unused.
    - PB3-04: a stderr-only `--check` failure says "fresh".
    - PB3-05: the router is a sub-project, not a repository, with two couplings left.
    - PB3-06: there is no fetch date when FETCH_HEAD is missing, and the W0 draft is unchecked.
    - PB3-07: the G-TAMPER reason is misleading.
    - PB3-08: step-order and branch issues in steps 1, 6 and 8.

## Part 2: combinator sub-project (c7a716e, ecd5a58, 5697a62)

- Complete as a pre-build: yes.
  - `combinator/` holds package `epinoic_combinator` 0.1.1 and instruction pack `combinator-instructions` 1.1.
  - It has a port module (`hello`/`combine`), its own suite (184 passed), and a `.gitignore`, so it is ready to be split
    off.
  - The kit side is in `src/epinoic_logic/integration/combinator_port.py`.
  - It is not attached to the service: combined mode is never offered.
- Verified: no. The last verification round on c7a716e left these findings open:
  - V3-H1 (high): a source claim that delivery marked role 'other' (a note) can be carried word for word into a synthesis.
    The hub accepts it with no finding, because the ledger never checks the role of cited claims.
  - V3-M1 (medium): dropped hedges are missed on short claims and on irregular participles (the 3-shared-key threshold).
  - V3-M2 (medium): a unit or SI-prefix rescaling is not named by INT-LEDGER-023, because only numerals and scale words
    are compared.
  - V3-M3 (medium): some credit forms are not read: parenthetical tags, label prefixes, credit to both specialists,
    credit to an answer, and self-reference.
  - V3-L1 (low): conflict records are never checked for substance, and bare transformation words are accepted as
    dropped reasons.
  - V3-L2 (low): the finding text was truncated in the status handed to this step.
- Measured at 5697a62 (NOTES 78-79, historically reported, not re-run here):
  - Full suite: 6615 passed, 45 deselected, 4 xfailed.
  - Arena: r1 30/30, r1-adv 150/151, r2-r6 46/46, r7 177/177, with every receipt the same as the previous run.
  - `git subtree split --prefix combinator` and `--prefix flash-router` both give trees identical to HEAD (tried only in
    a scratch clone).

## The flash router (the user's request)

- `flash-router/` is its own sub-project. The package is `epinoic_flash_router`, `pyproject.toml` names it
  `epinoic-flash-router` 0.1.0, and it uses the standard library only. It has its own suite of 19 tests and a
  `.gitignore`.
- The translator never imports it, except through `router_port.attach_router` by module name (`EPINOIC_FLASH_ROUTER`,
  default `none`).
- The router runs in a separate `python -I router_child.py` process. That process boundary is a fault boundary, not a
  sandbox.
- It is NOT yet a separate git repository or submodule; that repository form is the owners' decision under D28/D33. Two
  couplings remain. First, the translator suite runs the router suite. Second, `vectors.py` copies the router-port
  vectors into `flash-router/tests/vectors/`.
- `git subtree split --prefix flash-router` produces the standalone tree.

## What phase 2 must connect (from NOTES.md)

1. **Rebuilt overseer port and planner** (NOTES 2, 3, 26, 33, 40):
   - Build module `epinoic_overseer.port.connect(config) -> port`, with `hello`, `new_hub`, `clearance`, `close`,
     `deliver`, `view`, `repeats` and `review`.
   - `receipt_sha256` must equal `turn.receipt_sha256` (the sha256 of `canonical_json`).
   - Map every overseer delivery/release reason onto exactly one `OVERSEER_REFUSALS` label. An unmapped reason must fail
     a test.
   - Parametrize the TurnChecker tests over the real adapter, and keep tampering suite T1-T22 naming its codes.
   - Add the assertion `AUDIT_SCOPE_STATEMENT == <overseer constant>`.
   - Preflight must compare the hello's `pack_digests` with the overseer package's own `PACK_DIGESTS` (KIT-HS-007 on a
     mismatch).
   - `review()` must echo origin, plan_id and refusal, and must queue without waiting.
   - Any planner the overseer rebuild builds moves into `flash-router/` as a new release with a new identity.
2. **Flash router sub-project behind the router port** (NOTES 4, 23, 24, 36, 44, 45):
   - Attach it with `EPINOIC_FLASH_ROUTER=epinoic_flash_router.port`. `check.py` puts `flash-router/src` on PYTHONPATH.
   - The floor (`minimum-oversight-floor/1`) stays in the translator and is enforced whatever the router says.
   - The hosted profile attaches the router only when `boundary_problem()` returns None. That needs Linux, a non-root
     user, and no CAP_SYS_PTRACE.
   - D28 decides the repository form, the maintainer, and whether the translator suite keeps running the router suite.
3. **Argument diagnostics** (NOTES 5, 32, 54, 60, 77):
   - Pass each output's named diagnostic codes into `routing_features.OutputRecord.diagnostics`. Today it is `()`.
   - Decide floor/2 (D29).
   - Keep this branch's ledger.py INT-LEDGER-029 version, and resolve the 029/030/031 code collision with the overseer
     rebuild.
4. **Delivery rule** (NOTES 9, 27, 41):
   - Check `delivery.decide` against the rebuilt overseer's delivery rule on `integration/vectors/decision-table`, and
     record any difference as a decision.
   - Keep the invariant that the listed claims are a sub-multiset of the counted claims.
   - Row 5 applies only under verified-v1-qualify.
5. **Combinator attachment** (NOTES 8, 53, 55):
   - D33 is open: the process model and the provider credential.
   - Call `check_hello(contract_sha256=contract_digest())` and report `instruction_pack` in CombinatorPortCaps.
   - TurnChecker step 6 then runs these steps in order:
     - `build_input` / `source_report`
     - `combine`
     - `check_output` / `check_refusal`
     - relay `synthesis_payload(evidence_refs=...)` through the hub with its own clearance
     - `release_decision`
   - Pin `contract_digest()`.
   - Name hub agents `<slug>-specialist`, or teach `specialist_names` the slugs.
6. **Also open**:
   - Repeated faults: `port.repeats` (6).
   - Simulation replay loops for the website and agents drivers. All eight gates are NOT RUN until then (16).
   - Agents A3 and A5 (20).
   - Website patch set P, the W0 docs patch, and W5 (13, 19, 21).
   - Live-provider timeouts (12). No live provider is wired (D23), and none has ever been called.
   - Parser hedge certainty mapping, for the parser owners (64).
   - Deployment: deploy/container is PROPOSED only. Nothing has been deployed.
