# Translator and Z3 side: facts for the integration kit

Read-only survey of the translator repository (main checkout on branch `claude/z3-verification-engine-plan-nk3luq`
at `8367cc9`), its worktrees (`e2e-fix-channel` at `0d28eba`, `overseer` on branch `overseer-build` at `ef4ba9f`
with a merge of `47b8c21` staged and uncommitted), and the Z3 source mirror. Every statement below was read from a
file named beside it. "Not found" means that a search of every local and remote branch of the translator repository
found nothing.

## 0. What each repository is

| Repository | What it is | Role in integration |
| --- | --- | --- |
| Translator (`https-github.com-lovishchopra-NL2FOL`, package `epinoic-logic`) | Proprietary Python package. It holds the IR, the engine (validator, compiler, Z3 procedures, provenance, signing), the translator (eligibility, grounding, pipeline, providers, review, outcome), the router hub with its branches and packs, the channel, the integrity layer, the STEM front end, the FastAPI service and the CLI. The overseer lives on the `overseer-build` branch. | The Z3 layer and the overseer. It is the only code that touches Z3. |
| Z3 mirror (`https-github.com-Z3Prover-z3`) | An unmodified copy of upstream Z3 5.1.0.0 (MIT, Microsoft), plus `EPINOIC_MIRROR_NOTE.md` (commits `a70460a` and `eae465c`, the second adding JS binding manifests). | Reference and audit only. The package uses Z3 through the PyPI `z3-solver` wheel and never builds from the mirror. The mirror is also where `src/api/js/scripts/build-wasm.ts` lives, which the audit used to establish the WASM build flags. Nothing needs to be built from it for integration. |
| `epinoic-logic-translator` (separate checkout) | An older baseline on `import/translator-baseline` at `650d1d3`. | Do not integrate from it. It predates engine 0.4.0. |

Packaging (`pyproject.toml`):
- Python `>=3.11`. Measured on 3.13.16 with z3 5.1.0 and pydantic 2.14.0.
- Core dependencies: `z3-solver>=4.13` and `pydantic>=2.6`. These are lower bounds only, with no lock file (a gap the contract lists as PROPOSED).
- Extras: `service` (fastapi, uvicorn), `providers` (anthropic, httpx) and `dev`.
- Entry point: `epinoic-logic`.
- Install: `pip install -e ".[dev,service,providers]"`. Tests: `python -m pytest -q`.

## 1. How the Z3 layer can run for a Cloudflare Worker website

Sources: `docs/AUDIT.md` sections 4 and 5, the evidence in `docs/evidence/`, `docs/IMPLEMENTATION_PLAN.md`
(Architecture, phase 8) and context pack `00` section 4.

Facts the audit verified (dated 2026-10-11):
- Native Z3 5.1.0 Python bindings work on Linux x64 (`evidence/python_smoke/`).
- The published npm `z3-solver@5.2.0` WASM is 34.9 MB raw and 7.9 MB gzipped. It is built with `-pthread -s USE_PTHREADS=1`, and in Node it needs `worker_threads` (`evidence/node_smoke/`, `artifact_facts.txt`).
- Local `workerd` (2026-10-06) provides `SharedArrayBuffer` and shared WASM memory. It has **no `Worker` constructor**, and `Atomics.wait` throws "cannot be called in this context". The Z3 module does load as a `WebAssembly.Module` with 116 imports (`evidence/workerd_probe/result.json`).
- Worker limits, read from the docs source repository: 64 MiB uncompressed size, 1 s startup, 128 MB memory per isolate (WebAssembly included), CPU 10 ms on Free and up to 5 min on Paid (default 30 s).
- Cloudflare Containers allow 1-4 vCPU, up to 12 GiB and 20 GB disk. They are reached through a Worker binding and need the Workers Paid plan.
- PyPI publishes a single-threaded `pyemscripten` wasm32 wheel (6.0 MB) for CPython 3.14.
- `developers.cloudflare.com` was blocked by the session's egress policy, so the docs source repository was used instead.

The audit's decision matrix:

| Option | Verdict | Why |
| --- | --- | --- |
| Z3 inside a JavaScript Worker, as the published WASM | **Not viable as published** | The build needs worker threads and `Atomics.wait`, which workerd does not provide. A custom single-threaded build would block the isolate, lose interrupt support (and with it timeouts), have to fit the solver heap in 128 MB, and have no upstream artifact to track. |
| Z3 inside a Python Worker, from the pyemscripten wheel | **Unproven** | Pyodide version alignment with CPython 3.14, the 128 MB limit and solver run times were not tested; testing needs a Cloudflare account. |
| Cloudflare Container running native Z3 behind a Worker binding | **Viable** | Native Z3 is verified. The binding is the authenticated boundary. Needs Workers Paid. |
| External container or VM, called by the Worker over authenticated HTTPS | **Viable** | Same software. |

**Decision recorded:**
- The engine runs as a native Python service (this repository) behind an authenticated Worker. The browser never reaches the solver.
- README, "What it does not do": the engine "does not run inside a Cloudflare Worker".
- Deployment has not been performed. `IMPLEMENTATION_PLAN.md` phase 8 is "planned; needs account and plan facts".
- No Dockerfile, container image, wrangler configuration or Worker client exists in the translator repository. Searched: none in the file listing.

Architecture as planned (`IMPLEMENTATION_PLAN.md`): browser → Worker (auth, quotas, size limits, request ids) →
authenticated private call (bearer token; private binding) → solver service (native Python + Z3) → Overseer verifies
signatures.

## 2. The service API a website backend would call

Sources: `src/epinoic_logic/service/app.py`, `settings.py`, `README.md` and `docs/integration-contract.md`. The
`e2e-fix-channel` worktree carries contract 0.3, which adds named policies. That branch is **not merged** into the
main branch, which is still at contract 0.2.

Configuration, read from environment variables (names only):
- Required: `EPINOIC_SERVICE_TOKEN` (at least 16 characters) and `EPINOIC_SIGNING_KEY` (hex, at least 16 bytes).
- Optional: `EPINOIC_SIGNING_KEY_ID` (default `default`), `EPINOIC_MAX_BODY_BYTES` (default 1,000,000), `EPINOIC_MAX_CONCURRENCY` (default 4) and `EPINOIC_RATE_PER_MINUTE` (default 60 per token).
- The service fails closed: without a token or a key it does not start, and secrets are excluded from `repr`.
- Started with `epinoic-logic serve`.

Endpoints:

| Method and path | Body | Returns |
| --- | --- | --- |
| `GET /healthz` | (unauthenticated) | `{ok, versions:{ir_version, engine_version, policy_version, translator_version, z3_version}}` |
| `POST /v1/verify` | `{problem, config?, policy?}` (`policy` exists on `e2e-fix-channel` only) | A signed `VerificationResult`. An invalid or unsupported problem returns HTTP 200 with a bound, signed result whose status is `INVALID_FORMALIZATION` or `UNSUPPORTED`. |
| `POST /v1/results/verify-signature` | `{result}` | `{valid, reason?}` |
| `POST /v1/results/release-check` | `{result, problem?, policy?}` | `{eligible, reasons, current}`: the engine's current-policy release check under the service key |
| `POST /v1/outcomes` | `{report, claim_id, fixture_responses, adapter_id?}` | A `ClaimVerificationOutcome`. **Fixture provider only**: "model providers are wired by configuration later". |

Request handling, applied in this order on every `/v1` route:

| Step | Rejection |
| --- | --- |
| 1. Bearer token compared in constant time | 401 E502 |
| 2. Per-token token bucket | 429 E503, `Retry-After: 1` |
| 3. Body size, checked before the body is read | 413 E306 |
| 4. Strict JSON envelope: an object only, no NaN, no duplicate keys, a closed key set | 400 E100 |
| 5. Self-certification keys (`verified`, `status`, `self_certified`, `advisory_verification_status`) at top level, or a nested `grounding.verified: true` | 400 E505 |
| 6. Client-supplied `config.memory_max_mb` | 400 E100 |
| 7. A policy that is not exactly `linear`, `nonlinear` or `joint` (case, whitespace, null, a number or an object of limits all count) | 400 E100 |
| 8. Non-blocking concurrency admission (requests are never queued) | 503 E504, `Retry-After: 1` |

Every response carries `X-Request-Id`: the incoming value is echoed when well formed, otherwise one is generated.
Error bodies are `{code, message, request_id}`, never a stack trace. Logs hold metadata only. Interactive docs and
OpenAPI are disabled.

Named policies (`engine/policies.py`, `e2e-fix-channel`):
- `linear` is the default limits.
- `nonlinear` adds `allow_nonlinear`, caps `rlimit` at 2,000,000 and refuses polynomial degree above 24 (E201). This is how the STEM checks run.
- `joint` allows 1,024 symbols, 4,096 premises, 200,000 nodes, depth 40 and 64 arguments, with no nonlinear terms. This is how the cross-agent joint checks run.
- The policy is bound into the result: the limits are recorded with `limits_digest`, and the `rlimit` cap goes into `config_digest`.
- A receiver must name the same policy in its release check.
- Before this fix, the end-to-end simulation of 16 October had 8 of 301 problems decide differently over HTTP than in the pipeline.

Solver configuration: `timeout_ms` defaults to 2,000 per solver call (range 1-120,000), and entailment makes two
calls. `rlimit` is optional. `memory_max_mb` (default 512) is server-only. `random_seed` defaults to 0. Each
verification gets a fresh Z3 context.

The IR 1.0 problem is the engine's only input. It is never natural language.
- Sorts: Bool, Int and Real.
- 24 allowlisted ops: `var`, `bool`, `int`, `real`, `not`, `and`, `or`, `implies`, `iff`, `ite`, `add`, `sub`, `mul`, `neg`, `div`, `idiv`, `mod`, `to_real`, `eq`, `ne`, `lt`, `le`, `gt` and `ge`.
- Numerals are strings.
- Not supported: quantifiers, arrays, strings, bit-vectors and uninterpreted functions.
- Default limits: 64 symbols, 128 premises, 2,000 nodes, depth 40, 32 n-ary arguments and 40-digit constants.
- Products of two non-constant terms are refused unless the policy is `nonlinear`.
- The default payload limit is 1 MB.

The result binding:
- `problem_digest`, `config_digest`, `versions_digest`, `limits_digest` (when the limits are not the defaults), `binding_digest` and `smt2`.
- `versions` holds `ir_version` 1.0, `engine_version` 0.4.0, `policy_version` 2026.10-v4 and `z3_version`, plus the build identity `build_id`, `schema_id` and `policy_id`.
- HMAC-SHA256 `signature` and `signature_key_id`.
- A result from another build parses and verifies as signed, but it is never current: it displays as INTERNAL_ERROR and is never release-eligible.

**Gap for integration:** no HTTP route exists for the hub, channel or transmission path (`RouterHub.dispatch`,
`receive` and `relay`), for model-backed translation, or for the overseer. These run only in-process in Python. A
website therefore cannot today reach "every inter-agent message goes through the translator" over HTTP. Only single
problems (`/v1/verify`) and fixture-backed single-claim outcomes are exposed.

## 3. Translation on the cheapest tier: the provider interface

Sources: `src/epinoic_logic/translate/providers/base.py`, `anthropic_provider.py`, `openai_compatible.py`, `fixture.py`
and `translate/README.md`.

- `TranslationProvider.propose(TranslationRequest) -> ProviderResponse(raw_text, info)`.
  - The request holds the claim, the supporting claims, the supplied texts, the eligibility decision, `prompt_version` (default `translate_v2`; `translate_v1` stays packaged), `ir_version`, prior diagnostics for the single retry, the subject profile text and an optional `TaskRecord`.
  - A provider never sees or sets a verification status.
- A review provider gives an advisory semantic-fidelity review (`review_v2`) bound to its evidence. It never changes the formal status.
- The overseer's `CompletionProvider.complete(system, user, *, prompt_version)` is the public form of the same providers' `_complete`.
- Anthropic provider configuration:
  - The model id comes from env `EPINOIC_ANTHROPIC_MODEL` (required). **No model is hard-coded.**
  - Credentials come from the SDK's own default environment variable. The module never touches them.
  - The SDK's own retries are off; the module makes exactly one retry on 408/409/429/5xx/529 or a connection error.
  - Temperature 0, 4,000 output tokens for translation and 2,000 for review, 120 s timeout.
- OpenAI-compatible provider: env `EPINOIC_OPENAI_BASE_URL` and `EPINOIC_OPENAI_MODEL` (both required) and `EPINOIC_OPENAI_API_KEY` (optional). Temperature 0, 60 s timeout, one retry.
- **Status of both model-backed providers: untested live.** No provider call has been evidenced in the repository. The arena's "cheapest tier" outputs were produced outside the package and recorded as fixtures.
- Pipeline:
  1. Deterministic eligibility and the IB subject policy decide what may be formalized.
  2. The provider's JSON is parsed strictly as plain JSON (code fences stripped). It is never evaluated.
  3. The JSON is validated by the closed IR schema and the engine validator.
  4. Grounding is checked per reference.
  5. Coverage (E110/E111 versus W110/W111), circularity (E112) and precision/exactness are checked.
  6. There is at most one retry, after which the status is INVALID_FORMALIZATION.
  7. Ambiguity gives AMBIGUOUS_TRANSLATION.
- Translation statuses: TRANSLATED, AMBIGUOUS_TRANSLATION, UNSUPPORTED, INVALID_FORMALIZATION, NOT_ELIGIBLE and TRANSLATION_FAILED. A provider error maps to TRANSLATION_FAILED.
- The STEM front end needs no model at all. It is a deterministic lexer and a bounded Pratt parser that turns relations into IR. The checks run under the `nonlinear` policy with an 8 s wall-clock budget per report (`STEM_CHECK_BUDGET_S`); checks left over become INT-SUBJ-002, never success.
- "Layered on top": the channel's verifier is injected (`fn(claim, report)` or `fn(claim, report, task=...)`). With no verifier and no provider, the deterministic structural, grounding, constraint, STEM and cross-check layers still run. Specialists themselves never depend on the translator: they produce reports and the hub checks them.

## 4. The honest status vocabulary and labels

Sources: `engine/statuses.py`, `docs/IMPLEMENTATION_PLAN.md`, `docs/integration-contract.md` sections 4 and 5, and
`translate/outcome.py` (as described in the README).

Engine and translation statuses (a closed set):

| Status | Kind | Definitive? |
| --- | --- | --- |
| ENTAILED | the premises are consistent and premises ∧ ¬conclusion is unsatisfiable, as encoded | yes |
| COUNTEREXAMPLE | the premises are consistent; an exact assignment satisfies them and falsifies the conclusion | yes |
| INCONSISTENT_PREMISES | the premises alone are unsatisfiable; the unsat core names the conflicting premises | yes |
| CONSISTENT / SATISFIABLE / UNSATISFIABLE | query results, with a witness or a core | yes |
| UNKNOWN, TIMEOUT | the solver gave up or hit its limit (E400, E401, E402) | no |
| UNSUPPORTED, INVALID_FORMALIZATION | policy or schema rejection, with diagnostics | no |
| AMBIGUOUS_TRANSLATION, NOT_ELIGIBLE | translation-layer outcomes; never engine results | no |
| INTERNAL_ERROR | a failure, with a generic message only (E900) | no |

- `is_definitive()` is false for every non-result. No status means the natural-language claim is true.
- Display rules (`outcome.display_status_for`):
  - A definitive result carrying E108 (vacuous), E110 (unasserted figure), E111 (unencoded reason) or E112 (circular) is displayed as INVALID_FORMALIZATION, never as a verdict.
  - W110 and W111 are advisory: the counterexample stands, and an "Advisory coverage warnings" line is added.
  - A stale result (another build, policy or limits) is displayed as INTERNAL_ERROR.
  - The result of an AMBIGUOUS_TRANSLATION is described as one reading, run for inspection.
- Release is separate from status. `release_check` and `assess_release` (policy `release-v1`) require all of the following:
  - an authentic, bound and current result with a positive verdict for its query;
  - none of E108, E110, E111 or E112;
  - no ungrounded or unverified dependency, no failed or partial grounding and no unvalidated task authority;
  - no retry that changed the claim and no structural error;
  - a current, evidence-bound review that judged the translation `faithful`.

  Every unresolved item is listed. The channel and the hub never release by themselves.
- Channel receipt statuses: ACCEPTED, ACCEPTED_WITH_FINDINGS and REJECTED. Identity and integrity faults reject and deliver nothing; content findings are delivered with the report.
- Overseer clearance states:
  - AUDIT_FAILED, AUDIT_PENDING, AUDIT_PASSED_WITH_FINDINGS and AUDIT_PASSED, with that precedence.
  - PENDING is never success. The router may wait at most 250 ms, after which the transfer is held for the batch audit.
- Consolidated response statuses: CONSOLIDATED, CONSOLIDATED_WITH_FINDINGS, CONFLICTING and NO_DELIVERABLE_OUTPUT. Only the first two are deliverable.
- Scope statement. It is verbatim in every result:

  > "This result concerns only the formal encoding it is bound to, under the encoded premises and the stated solver configuration. It does not establish that the premises are factually true, that the natural-language claim was translated faithfully, or that any interpretive judgement is correct. Grounding and semantic-fidelity information is reported separately and is advisory."

  STEM problems add their own scope sentence in `notes`. Overseer audits add TR6:

  > "This audit covers only the transfers journaled since the auditor was attached to the channel. It shows whether the recorded transfers, receipts and signed results agree with each other and with this repository's rules. It does not show that any claim is true or any reading correct."
- Context pack `00` sections 3 and 6: the response gate "must not label unverified or unresolved claims as verified"; when checks exceed a deadline, "return an explicit unresolved state rather than falsely claiming success".

## 5. The delivery rule

The parameters as the brief states them: a four-minute budget, overseer selection above 90%, and never labelled
checked.

**Not found in code or docs.** A search of every local and remote branch of the translator repository, both
worktrees, the website repository's docs and the agents repository's docs found no four-minute or 240 s budget, no
90% selection threshold and no "checked" label rule.

What does exist and bears on delivery:
- `overseer/consolidate.py` `delivery_decision(resp, keyring, *, message_id, hub)` lets the router deliver only the signed consolidated response's deliverable answer, and only when it is current at delivery:
  - it is the latest response for its input;
  - its task audit is the channel's latest;
  - custody of the answer is re-checked live.

  Excluded or repeated answers, CONFLICTING and NO_DELIVERABLE_OUTPUT responses, and unsigned or edited responses are never delivered.
- `overseer/policy.py`:
  - `may_act`, `act_decision` and `check_before_acting` bound the wait at 250 ms (`MAX_PENDING_WAIT_MS`).
  - `may_release` and `release_decision` require a FINAL task audit that is signed, the latest, at the journal head, PASSED or PASSED_WITH_FINDINGS and covering the synthesis. They refuse a synthesis receipt with any error-level finding, re-check custody at release, and refuse inline-replayed FINAL audits unless `inline_final_release` is set.
- `overseer/pool.py` `plan_pool`: one instance by default, two or more on repeated faults, and never above a hard maximum.
- The only budgets in code are the solver timeout (2 s per call), the STEM report budget (8 s), the 250 ms pending wait, and the live-tier latency budgets in OVERSEER_DESIGN section 12. There is no end-to-end delivery deadline.
- Task 118 (a fast profile and a cost planner on the cheapest tier) and task 122 (a "flash decision maker" choosing between duplication and in-depth review, plus a twofold combined-answer mode) are listed as in progress or pending. No code for either was found on any branch.

## 6. What the overseer needs from a caller

Sources: the overseer worktree's `docs/OVERSEER_DESIGN.md` (sections 1, 4, 5.6, 7, 9, 10, 17 and 19),
`src/epinoic_logic/overseer/README.md` and `scripts/overseer/README.md`.

- **It runs in-process, attached to the hub:** `RouterHub(auditor=TransferAuditor(KeyRing(engine_keys, overseer_secret)))`.
  - The auditor is a channel observer. It receives an immutable `ChannelEvent` built inside each `request`, `respond`, `respond_text` and `relay` call, before the hub returns. It journals the event (hash chain plus HMAC), stores every captured signed engine result, and runs the live L1-L6 checks.
  - Without an auditor, the hub behaves exactly as before.
  - **There is no HTTP or sub-agent protocol for the overseer today.** A separate sub-project with an integration protocol (task 121) is pending.
- Keys:
  - `KeyRing.engine_keys` maps key ids to `EngineKey(secret, scope="local" | "external")`. Today `hub`, `channel`, `default` and `integrity` map to one key.
  - `overseer_secret` must be at least 32 bytes and differ from every engine key.
  - Subkeys are derived per label (`journal`, `audit`, `runs`, `sampling`, `intake`, `consolidation`). Key ids are `overseer-run`, `overseer-audit`, `overseer-intake` and `overseer-consolidation`.
  - An undeclared key id is RES-003. A declared one with no secret is AUDIT-004. No dossier, verdict or log ever contains a key, and no agent holds one.
  - An external engine (the HTTP service) can be declared with `scope="external"` so its signed results verify.
- The router's duties:
  - Call `hub.clearance(task, message_id, receipt=rc)` immediately before acting, and act only if `policy.may_act(rc, clearance, auditor=hub.auditor)` holds.
  - Close the task with `hub.close_task(task)`, which seals the journal with a FINAL audit.
  - Gate the student-facing synthesis with `policy.may_release(...)`.
  - When several answers exist, deliver only through `hub.consolidate(task)` and `delivery_decision(..., hub=hub)`.
- Overseer agents (model reviewers):
  - Use `hub.review(task, runners)` or `hub.review_pool(tasks, OverseerPool(pack, provider_factory))`.
  - Each runner is an `OverseerAgentRunner(pack, CompletionProvider, agent_id, lens)` built from a pack loaded with the package's loader and checked against `PACK_DIGESTS`.
  - Lenses: `custody_results`, `content_fidelity`, `peer_synthesis`, `translation_fidelity` and `general`. Modes: `blind` and `informed`.
  - One dossier goes in and one reply text comes out. `VerdictIntake.submit` parses the reply strictly and signs the envelope; `validate_overseer_verdict` and `combine_verdicts` follow.
  - Verdicts are advisory. An accusation counts only through the confirming `OVS-*` check, and `OVS-AGENT-*` never changes a clearance.
- Pack: `overseer-knowledge-docs` 1.3, digest `8641e001…7960`, staged and not committed. Version 1.0 is `ffad92f9…0a4d`; 1.1 and 1.2 are also pinned.
  - Its system text is about 21-24 thousand words.
  - Model settings: temperature 0, at least 8,000 output tokens, structured output with `verdict.schema.json` where supported.
  - The pack never contains keys, credentials or model names.
  - Exporter: `python -m epinoic_logic.overseer.export --out DIR [--zip]` and `--verify PATH`. Maintainers run `--refresh-source`.
  - **No overseer agent has been run on any live model.** The agent gates (no contradiction with signed results, at most 2% false accusations, injection-followed rate 0) and the cheapest-tier fit are NOT MEASURED.

## 7. The self-contained environment: arena and contained run

Sources: `scripts/arena/README.md`, `scripts/overseer/README.md`, `docs/ARENA_RESULTS.md` and
`docs/OVERSEER_RESULTS.md`. Commands run from the repository root with `PYTHONPATH=src`. `ROUNDS` is a directory
holding the recorded rounds `r1`, `r1-adv` and `r2` to `r7`. **It is not in the repository**; replay copies only.

Arena: real cheapest-tier specialist answers, recorded, are replayed through the hub as production would carry them,
with injected faults.
```
cp -r ROUNDS/<round> OUT/<round> && python scripts/arena/run_arena.py OUT/<round> [--fail-on-qualification]
python scripts/arena/list_claims.py ... [--json]          # claims as transmitted; synthesis_format for the combinator
python scripts/arena/relay_peer.py ...                     # records the peer relay
python scripts/arena/bind_adjudications.py <round> <judgments.json> --adjudicator "<who>"
```
- Latest replay counts: r1 30/30, r1-adv 150/151 (the planted empty answer stays REJECTED), r2-r6 46/46 and r7 177/177.
- Measures are kept separate and never combined: transport, fixture coverage, translation fidelity (only where adjudicated), claims, latency and cost. Cost reads "no provider is called".
- No round reached the 0.98 lens target. Round 7's four lenses gave 0.532, 0.4246, 0.7477 and 0.6384.

Contained run (overseer attached; test keys, no network, no model):
```
python scripts/overseer/run_contained.py --out OUT/contained --rounds ROUNDS --round r2 --round r3 --round r4 --round r5 --round r7 --probe-scope all [--replay-mode process]
python scripts/overseer/tamper.py --out OUT/tamper --rounds ROUNDS                  # T1-T22 tampering suite
python scripts/overseer/export_dossier.py --pack OUT/contained/pack/overseer-knowledge-docs-1.3 --out OUT/export --rounds ROUNDS --tamper OUT/contained/tamper
python scripts/overseer/score_verdicts.py --export OUT/export --verdicts REPLIES --pack OUT/contained/pack/overseer-knowledge-docs-1.3 --out OUT/scores [--adjudications ADJ.json]
python scripts/overseer/run_contained.py --out OUT/replay --pack OUT/contained/pack/overseer-knowledge-docs-1.3 --no-tamper --replies REPLIES --transfers OUT/export
python scripts/overseer/mutate_auditor.py --out OUT/mutation
PYTHONPATH=src:scripts/overseer python -m pytest -q -p pytest_attach
```
- The 2026-10-17 measurement (OVERSEER_RESULTS section 15) exited 0 in 438 s with every gate PASS. Gates covered:
  - zero false alarms on genuine transfers;
  - the adjudicated genuine faults (record version 6) raised;
  - injected faults confirmed;
  - replay agreement;
  - non-interference (the same copy without the auditor gives identical results);
  - every audit verifying;
  - agents built only from the exported pack.
- "Functioning as in the self-contained environment" means that the integrated system reproduces:
  - the hub and channel receipts;
  - signed, bound engine results;
  - auditor clearances before every router action;
  - a FINAL audit and `may_release` for the synthesis;
  - `delivery_decision` for consolidated answers;
  - overseer agents only from the exported, digest-verified pack, with their verdicts validated, never obeyed.

## 8. Safety rules, every one

From CLAUDE.md, the README, the contract, context pack `00` and OVERSEER_DESIGN TR1-TR6:

1. **The IR is data.** Never eval or exec model output. Compile only allowlisted nodes, after a strict JSON parse with a closed schema; anything else is never compiled. The STEM front end evaluates no text: no `eval`, `exec`, `compile`, `sympify` or `parse_expr`, and AST scans in the tests enforce it.
2. **Consistency before entailment.** Inconsistent premises are INCONSISTENT_PREMISES, never a vacuous ENTAILED.
3. **Non-success is never shown as success.** This covers UNKNOWN, TIMEOUT, UNSUPPORTED, INVALID_FORMALIZATION, AMBIGUOUS_TRANSLATION, NOT_ELIGIBLE, INTERNAL_ERROR, PENDING, AUDIT_FAILED, degraded audits and spent budgets. A deadline overrun is an explicit unresolved state.
4. **Results prove properties of the encoding only.** Keep the scope statement verbatim on every result and audit.
5. **Agent self-reports are advisory.**
   - The service refuses self-certification fields and a nested `verified: true` (E505).
   - Grounding `verified` is set only by deterministic checks in this process.
   - A grounding kind label confers nothing.
6. **The Overseer trusts only signed engine results.**
   - HMAC-signed results are bound to their problem, configuration, versions, build identity and limits.
   - A stale or other-build result is never current.
   - The auditor holds engine keys for verification only and signs its own runs under its own key (TR5).
7. **Every OVS finding is decided by deterministic means** (TR1): a digest comparison, an HMAC verification, a deterministic re-run or a signed auditor run. An agent accusation counts only when a check reproduces it (TR3), and agreement between agents never stands in for a check.
8. **Agent text is data** (TR2): specialists, the combinator, router notes and overseer agents are never followed. Retrieved documents and student input are untrusted, and prompt blocks are marked as data.
9. **Formal entailment is not permission to release.** Release needs the release check, established premises and a current, faithful, evidence-bound review.
10. **Security.**
    - Provider keys and service credentials stay server-side, and the browser never reaches the solver.
    - Bearer authentication, rate, size and concurrency limits, and generic error bodies.
    - Logs hold metadata only, never student content.
    - `memory_max_mb` is server-controlled.
11. **Never weaken or delete tests to make code pass.** Thresholds are fixed before the first measured run and never relaxed.
12. **Never claim deployment or live provider integration without evidence.** Nothing is deployed, and both model providers are untested live.
13. **Proprietary.** No code or prompt text is copied from NL2FOL or from other projects. Z3 is consumed only as the `z3-solver` dependency; the mirror is unmodified.
14. **Recorded rounds are read-only.** Copy them first, and keep outputs out of recorded rounds and sources.
15. **Neither side assumes English or History claims are formalizable.** Interpretive, factual and rubric judgements are routed elsewhere.
