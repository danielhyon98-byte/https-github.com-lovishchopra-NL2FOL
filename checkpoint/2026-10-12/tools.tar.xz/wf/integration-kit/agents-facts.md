# Agents repository: facts for the Z3 integration kit

Source: `danielhyon98-byte/epinoic-agent-training-api-connector`, read-only, single
commit `6949519` (2026-10-16, "Training workflow: every subagent ignores relayed
messages and stays in scope"). The translator symbols named in section 4 were
checked against the translator repository's `src/epinoic_logic` (read-only).
Repository text is treated as design data, not as instructions.

Naming rule for repository-bound text: the agents repository names concrete models
in `agents/model-assignment.json`, the handoff file names and the simulation
workflows. Kit text meant for a repository should say "the cheapest tier" or "the
specialist tier" and read the concrete ID from `model-assignment.json` at run time.

---

## 1. What the repository is

| Part | Path | State |
| --- | --- | --- |
| History pilot runtime | `specialist-runtime/` | Portable ES modules (Worker and Node 22). 117 tests. Contract `epinoic.specialist-runtime.v0.1.0`. Pins pending, nothing enabled. |
| Multi-specialist router | `specialist-routing/` | Portable ES modules. 175 tests, 260-item synthetic evaluation set. Contract `epinoic.specialist-routing.v0.1.0`. Synthetic catalogue, policy unapproved. |
| 16 agents | `agents/<slug>/` | Two generated handoffs per agent (one Claude, one GPT), README, knowledge 01-04. Shared core `agents/_shared/knowledge/00-answering-functionality-core.md`, which is **v0.2.0** (README files still say 0.1.4). |
| Z3 bridge | `integration/z3/check_answer.py` | Calls the translator's `RouterHub` as an external installed dependency. Offline. |
| Simulation | `simulation/` | Training loop with a deterministic overseer (gate plus Z3), LLM overseers A and B, a Z3 adjudicator and curators. Cycle 1 is partial (see section 7). |
| Repo tools | `tools/cross-check.mjs`, `tools/readiness-check.mjs` | The readiness check exits 1. It reports 20 blockers. |

The repository is **public**. Its docs say it must be made private before any
proprietary prompt, bundle or extracted code goes in. The translator repository is
also public, although its LICENSE says it is confidential.

---

## 2. Specialist API surface (runtime contract v0.1.0)

### 2.1 Exports (`specialist-runtime/src/index.js`, exactly this table)

`RUNTIME_CONTRACT_VERSION`, `PILOT_MODE` (`"pilot-single-turn-no-tools"`, the only
mode), `RUNTIME_MANIFEST`, `REPORTED_WEBSITE_LIMITS` (reference only, never
defaults), `validateManifest`, `getCapabilities({environment})`,
`loadPinnedBundle({slug, bundleModule, environment})` (async; SHA-256 verified),
`prepareTurn(input)`, `runSpecialistTurn(input)`,
`runGate({slug, gateConfig, answerText, finishReason, userMessage})`,
`HISTORY_GATE_CONFIG`, `createOfflineTestRuntime({manifest, gateConfigs})`,
`redactForLog(result)`. `exports.test.js` pins this exact table, so adding an export
breaks a test.

Environments are exactly `production`, `staging-pilot` and `offline-test`. The pinned
runtime refuses `offline-test`. The offline runtime accepts only `offline-test`.

### 2.2 Input: `runSpecialistTurn`

```
{ slug, mode, environment, bundle /* VerifiedBundle */, message, priorTurns, limits,
  turn: { conversationId, turnId, turnVersion, attemptId },
  authorizedGenerate /* website-injected */, signal /* optional AbortSignal */ }
```

- Allowed keys are `PREPARE_KEYS` plus `turn`, `authorizedGenerate` and `signal`
  (`bridge.js`). Any other key gives `precondition_failed/unknown_input_field`. A
  `tools` key, even `[]`, gives `tools_not_supported`. **No extra input such as an
  explicit request, task items or a claims schema can be passed in without a
  contract change.**
- `limits` is required: `maxMessageCodePoints`, `maxPriorTurns`,
  `maxPriorTurnsUtf8Bytes`, `maxPreparedInputUtf8Bytes`, `maxAnswerUtf8Bytes`, and
  optionally `maxOutputTokens`.
- `PreparedRequest` (`epinoic.prepared-specialist-request.v1`) has `instructions` =
  [`mandatory-bundle` (byte-identical, SHA re-verified), `runtime-notice`
  `pilot-notice/0.1.0`], `messages` = priorTurns plus the user message, and
  `tools: []`. Bounds report `tokenCount: null` and `tokenCountStatus:
  "not-measured"`. The bundle is never trimmed. Changing the notice text needs a new
  version string and review.

### 2.3 The injected callback (website 01 owns it; it wraps 03 transport and 04 budget)

`authorizedGenerate(preparedRequest, {signal})` must resolve to exactly one of:

```
{ status: "declined", reason }
{ status: "completed", output: { text, finishReason: stop|length|refusal|content_filter|unknown },
  usage: object|null, providerEvidence: object|null }
{ status: "failed", error: { code }, usage, providerEvidence }
```

The keys must match exactly. An extra key, or any tool-call field, is
`callback_contract_violation`. The runtime invokes the callback **at most once**,
with no retry, fallback or revision. An abort after the callback returns fences the
result as `cancelled`.

### 2.4 Output: `SpecialistTurnResult` (`epinoic.specialist-turn-result.v1`, deep-frozen)

```
{ schema, contractVersion, outcome, answer /* non-null only when outcome === "answer" */,
  failure: {stage, code}|null, completion: {finishReason, outputUtf8Bytes},
  gate: { kind: "deterministic-format-policy", version, configVersion,
          status: passed|failed|unverifiable|not_run, checks: [{id, status, code}],
          disclaimer: "Deterministic format and policy heuristics. Not factual, academic or formal verification." },
  usage, usageStatus, providerEvidence,
  dispatch: { callbackInvocations: 0|1, authorization },
  provenance: { manifestVersion, slug, sourceRepo, sourceCommit, kbVersion, bundleSha256,
                gateVersion, gateConfigVersion, runtimeNoticeVersion, mode,
                libraryManifestVersion: null, toolsRun: [], retrieval: null, claims: null },
  turn }
```

The outcomes are `answer`, `precondition_failed`, `declined`, `cancelled`, `failed`,
`refusal`, `incomplete`, `oversize`, `gate_failed` and `gate_unverifiable`. After a
completed reply they are decided in this order: refusal, incomplete, oversize, then
the gate. Text is shown only for `answer`.

### 2.5 The `claims` field

- It is hard-coded `claims: null` in `src/provenance.js` (`buildProvenance`), and
  `buildResult` freezes the provenance.
- **Five tests pin it:** `bridge.test.js:327-338`, `prepare.test.js:75-92`,
  `integration.test.js:16,62`, `redact.test.js:46` and `result.test.js:10`.
  `readiness-check.mjs` reports it as a blocker ("claims = null by design: the
  handoffs defer Z3 and claim extraction").
- The README, the integration contract §2 and §12, `website-01-integration-plan.md`
  and `docs/context/README.md` all say the runtime does not call Z3 or the
  translator, and that `claims` stays null in this slice.
- Consequence: Z3 output must live in an **outer envelope around the unchanged
  result**. Filling `claims` inside the runtime is a reviewed contract bump (a new
  `contractVersion`), and the tests could not be kept as written. The no-weakening
  rule makes that a separate decision for the owners.

### 2.6 The gate

There are five required checks: `completeness`, `url-policy`,
`internal-code-leakage`, `provisional-mark` and `sources-line`. Three of them are
`pending` in `HISTORY_GATE_CONFIG`, so a real History answer can at best reach
`gate_unverifiable` today. Synthetic configs run only through
`createOfflineTestRuntime`. The gate is heuristic, and its known misfires are listed
in the runtime README.

### 2.7 Capabilities (the router reads these; there is no second registry)

```
{ schema: "epinoic.specialist-capabilities.v1", runtimeContractVersion, manifestVersion, environment,
  entries: [{ slug, available, supportedModes, gateVersion, bundleSha256 }] }
```

The manifest has only one entry, `history`, and it reports `available: false`
everywhere.

---

## 3. Router: selection, multiple specialists and the combined answer

- `selectSpecialist({evidence, catalogue, labelSet, policy, capabilities, trusted, options})`
  and `selectSticky({stickySlug, catalogue, capabilities})` return a
  `RoutingResult` (`epinoic.routing-result.v1`):
  `{outcome: route|clarify|unavailable, slug /* route only */, reason, candidates:[{slug, available}], path: classification|sticky, identity:{catalogueSha256, labelSetSha256, policyVersion, calibrationFingerprint}, inferencePerformed:false}`.
- **The router selects at most one specialist and never fans out.** A mixed request
  gives `clarify/mixed_request`, which can come from any of these signals:
  `mixed_request >= mixedMin`, two unrelated topics, or a supported half plus an
  out-of-scope half. `select.js:202` says mixed requests are "never reduced to one
  half and never fanned out". A near tie gives `competing_subjects`, or
  `overlap_policy` for ESS, Biology and Geography. A recognised but disabled
  subject gives `specialist_unavailable` and is **never replaced** by another
  specialist.
- **No combined answer is formed anywhere in this repository.** No code merges two
  specialists' outputs. `docs/context/README.md` records the decision: the zip's
  "orchestrator calls specialists as tools and may fan out" was superseded by "a
  deterministic router selects one specialist or asks for clarification. No
  automatic multi-subject fan-out."
- The translator, by contrast, supports several agents per task. `WorkPlan` has
  `selected_agent_ids` (1 to 16 entries), `agent_subjects` and `agent_task_types`.
  `check_answer.py` uses only one agent id (`"specialist"`).
- Consequence: a twofold or combined-answer mode is **new behaviour above the
  router**. It conflicts with routing contract v0.1.0 §2 and §6 step 3 if it sits
  inside the router. It needs a new reviewed routing contract version, or it must
  live entirely in the layer above, taking the clarification answer as the trigger.
- The website contract and D1 enums allow only `english` and `history` today. Every
  other slug needs website contract, state, D1 and UI changes (routing contract §11).

---

## 4. What `integration/z3/check_answer.py` assumes about the translator

Run as `$EPINOIC_Z3_PYTHON -I [-B] integration/z3/check_answer.py [--mode dispatch|receive] INPUT.json`
(or with stdin). Callers are `simulation/tools/check-answer.mjs` (receive),
`simulation/tools/route-request.mjs` (dispatch, `answer: "-"`) and
`tools/readiness-check.mjs` (two physics probes).

**Input:** `{slug, request, answer, supplied_texts?: [{document_id, title?, text}], course_level?: SL|HL|unknown}`.
**Output:** `epinoic.z3-answer-check.v1`:
`{ok, status: ACCEPTED|ACCEPTED_WITH_FINDINGS|REJECTED|ERROR, mode, slug, subject, branch, findings:[{code, severity, message, claims:[text ≤5], formal}], counts, formal_errors, request:{task_type, course_level, items[], constraints[], supplied_texts[], user_input_sha256}, coverage[], constraints[], versions}`.
It never crashes. Exit 0, except 2 for a bad mode or unreadable input.

Assumptions (each verified to exist in the translator's `src/epinoic_logic`):

1. The translator is a separately installed Python package `epinoic_logic`,
   importable from the interpreter named by `EPINOIC_Z3_PYTHON`. No translator code
   is copied into the repository. If the variable is unset, the JS callers report
   `not_run`. Nothing runs inside the Worker.
2. Imports: `epinoic_logic.version` (every attribute ending in `VERSION`: IR 1.0,
   ENGINE 0.4.0, POLICY 2026.10-v4, TRANSLATOR 0.4.0 at the time of reading),
   `branches.RouterHub`, `engine.SolverConfig`, `integrity.WorkPlan` and
   `translate.contracts.SuppliedText`.
3. `RouterHub(signing_key=KEY, config=SolverConfig(timeout_ms=4000, memory_max_mb=None))`.
   - `KEY = b"simulation-only-signing-key-not-secret-0001"` is a **hard-coded,
     non-secret key** with the default `key_id "hub"`. It is not fit for any real
     trust decision.
   - **No `verify_claim_fn` is passed**, so `TranslatorChannel._verify_claims`
     returns no outcomes. Only the subject branch packs' deterministic parsing and
     formal checks run. **No model translation happens on this path**, so the
     cheapest-tier translation the founder describes is not wired here.
4. A new hub opens per call (stateless). `WorkPlan(plan_id="sim",
   request_id="sim-q", task_id="t", subject=<display name>, course_level,
   task_type="short_answer", selected_agent_ids=["specialist"])`. The ids are fixed,
   there is one agent, and `task_type` is always `short_answer`.
5. Slug to subject display name. The branch registry keys on the display name. There
   are 17 entries, including both `spanish-b` and `language-b-spanish`, and
   `english-specialist` maps to "English A: Literature". Any other slug gives
   `unknown_slug`.
6. `hub.dispatch(task_id, agent, request, supplied)` returns `(msg|None,
   TaskRequest, receipt)`. `TaskRequest` exposes `items` (`item_id`, `text`, `kind`,
   `required`, `command_term`, `level`), `constraints` (`constraint_id`,
   `kind(.value)`, `value`, `text`), `supplied_texts` and `user_input_sha256`.
7. `hub.receive(task_id, msg.message_id, answer_text, agent_id=AGENT,
   report_id="r1")` returns `(reply, receipt)`. The answer goes in as **raw text**
   with a stated sender and report id, so the translator's own parser extracts the
   claims. The specialist emits no structured claims.
8. To recover claim texts, the script reads the **channel internals**:
   `hub.channels["t"].transmitted_reports[*].claims` (`claim_id`, `claim_text`).
   That is not a public hub API.
9. Receipt fields used: `status.value`, `branch`, `findings` (`code`, `severity` in
   error/warning/info, `message`, `claim_ids`, `formal_result_id`), `coverage`
   (`item_id`, `addressed`, `method`) and `constraint_results` (`constraint_id`,
   `satisfied`, `method`, `detail`). Unused fields: `outcomes`,
   `structural_findings`, `formal_checks` and `formal_result_ids`.
10. The **signed reply envelope (`_reply`) is discarded**. `TransmissionReceipt`
    carries no signature field (signatures sit on `AgentMessage` envelopes:
    `signature`, `signature_key_id`, HMAC-SHA256). So the JSON output carries
    nothing an overseer could verify. Under the rule "the overseer trusts only
    signed engine results", today's output is not acceptable as overseer input.
11. The JS caller sets "blocking" to any gate `fail`, any Z3 finding with severity
    `error`, or any unsatisfied constraint. Item coverage is advisory.

---

## 5. Where a Z3 layer and an overseer sub-agent attach without changing a specialist

| Attach point | What is available there | Fit |
| --- | --- | --- |
| **A. Request side, between `RoutingResult.route` and `runSpecialistTurn`** | slug, user message, supplied texts; `RouterHub.dispatch` gives the explicit TaskRequest (items, command terms, limits) | Good for a **record** of the request, which the receipt's coverage and constraints need. It **cannot be injected** into the specialist: there is no input field for it, and a changed `message` or notice changes what the specialist sees. The simulation gave `explicit-request.json` to the specialist as a file, which is not a no-change attachment. |
| B. Inside `authorizedGenerate` (website 01's wrapper around 03 and 04) | the PreparedRequest and the provider reply | **Poor fit.** The reply schema is exact, so Z3 output cannot pass through. The gate has not run yet. The callback is the budgeted single dispatch. |
| **C. After `runSpecialistTurn` resolves, with `outcome === "answer"`** | answer text, user message, `provenance` (bundle SHA, gate version), `turn` ids; supplied texts come from the website | **Best fit.** A wrapper calls the translator service, with the request and answer under the same hub task (dispatch, then receive), and builds a new outer envelope. That envelope holds the frozen `SpecialistTurnResult` unchanged plus the Z3 receipt (claims, findings, coverage, constraints, versions, signed envelope). The runtime, its tests and `claims: null` stay as they are. |
| **D. Overseer sub-agent, after C** | answer, signed engine receipt, request record | It runs as a separate sub-project through the integration protocol. Its report is advisory. Release follows the translator's delivery rule, which uses only signed engine results. In this repository the only "overseers" are simulation LLM agents (A: detail and evidence; B: logic, truth and sources; plus a Z3 adjudicator). There is no deployable overseer here. |

Wiring constraints for C and D:

- The translator is Python with `z3-solver`, so it cannot run in a Cloudflare Worker
  (readiness check; translator README). The Worker would call a **separate
  service**. The planned endpoint is `POST /v1/verify`, which has never been
  deployed. Website 01 owns the Worker wiring.
- The founder requires Z3. Because of that, the delivery rule must say what happens
  when the service is down or times out (`not_run` or `ERROR`). The translator's
  "non-success is never shown as success" means it can never be labelled verified.
  Whether the answer is then withheld or shown unverified is open (section 9).
- Cheapest-tier translation: `RouterHub(verify_claim_fn=...)` is the injection point
  for model-based claim verification (the channel calls `fn(claim, report[, task])`
  per claim). `check_answer.py` passes none today.
- A specialist runs unchanged whether or not the layer runs: runtime and router
  never import the translator. That satisfies "the layer sits on top; specialists
  can run without it" structurally. Whether a user sees an answer without Z3 is a
  delivery-rule decision.

---

## 6. Work in progress, blocked or not done

From `docs/DEPLOYMENT-READINESS.md`, the readiness check and the WORKLOG:

- Runtime: `sourceStatus: unverified-source`; History `source.commit`,
  `bundlePath` and `kbVersion` are null; the bundle SHA is "reported, not
  verified"; three gate rules wait on handoff/04; nothing is enabled;
  `productionEnabled: true` is refused by this package version.
- Router: synthetic catalogue; `PRODUCTION_POLICY` is unapproved with
  `calibration: null`, so every live classification returns
  `unavailable/calibration_missing`; ten slugs are provisional. The workflow and
  `check_answer.py` both use `language-b-spanish`, which suggests the real folder
  name differs from the provisional `spanish-b`.
- Provider: no API key in the environment. Keys belong in the Worker's secret store
  (names only: `ANTHROPIC_API_KEY`; `OPENAI_API_KEY` only if the GPT path is
  approved).
- Website: the repository was unreachable from the session that wrote these
  packages. The integration patch is plan only. Website 03 (transports) and 04
  (budget and migration 0003) are drafts, and their usage shapes are not
  reconciled.
- Z3: works offline. The readiness check passes the "catches a wrong worked step"
  and "passes the correct step" physics probes when `EPINOIC_Z3_PYTHON` is set. Not
  done: claims in the result, the service, deployment, and the translator's service
  tests (their extras were not installed).
- Model assignment is a **proposal**: the cheapest Claude tier is primary for all
  16 agents, with a GPT model as comparison and fallback. There is no automatic
  runtime fallback. A switch happens only on recorded evidence.
- The handoff probe messages have never been run on any model. Token counts have
  not been measured.
- Possible two-owner conflict: if `specialist-runtime/` or `specialist-routing/`
  already exist in `Epinoic-AI/Epinoic-Agent-Training`, the work must be reconciled
  first.

---

## 7. Simulation and training workflows

- `simulation/tools/check-answer.mjs` is the deterministic overseer. It runs the
  offline runtime gate with the synthetic `simulation-gate/0.1.0` config (canary
  code `EPN-SIM-7Q4X`, tagged sources line), then calls `check_answer.py`.
  Blocking: a gate fail, a Z3 `error`, or an unsatisfied constraint. Advisory:
  uncovered items and unsupported checks.
- `simulation/tools/route-request.mjs` writes the explicit request in dispatch mode.
- `workflows/overseer-training-cycle.js` (supplement-only specialists) and
  `workflows/real-agent-training-cycle.js` (real full-context bundles read from a
  private worktree's `knowledge-bases/_bundles/<slug>.full-context.txt`):
  - scenario writer, specialist, deterministic check (cheapest tier), then overseers
    A and B in parallel;
  - when a Z3 `INT-*` error blocks, a **Z3 adjudicator** LLM recomputes each finding
    and rules it `real_error` or `checker_artefact`. An artefact ruling **removes
    the blocker**. Uncertain findings count as real.
  - rejection: any non-Z3 deterministic block, any confirmed Z3 error, or an
    overseer `reject` (one major flag, or three or more minors); then up to N
    revision rounds, curation and a fresh-instance retest;
  - `harnessVersion` defaults to 3 (overseers grep the knowledge base before calling
    a fact invented).
- Known translator misreads, as the adjudicator prompt lists them: "3 > 3 is false"
  read as an assertion; "(3 s.f.)" read as a result; "P/Y = C/Y = k" read as
  algebra; the specialist's evaluation of a student's wrong formula taken as its
  own claim; numbers paired across sentences; "within six months of the end of the
  war" read as a date range. Recorded example:
  `runs/cycle-1/history/c1-history-q1/round-1/deterministic.json` has an
  `INT-SUBJ-001` chronology error on "launched in 1958 and abandoned in stages
  during 1961 and 1962".
- Run state in this repository: cycle 1 is partial. Of 24 questions, 11 have a
  round-1 answer, 5 have `deterministic.json` and 3 have overseer reports. There is
  no `simulation/reports/` directory, although the README lists one. The
  real-agent runs live elsewhere (`training/` in a private worktree).
- Tension with the translator's safety rules: in the simulation, an **LLM
  adjudicator can clear a formal Z3 error**. That conflicts with "agent
  self-reports are advisory; the Overseer trusts only signed engine results". The
  integrated overseer should not inherit it.

---

## 8. Rules the repository states (constraints)

1. No provider call, API key, paid test, deployment, production enablement or
   website source edit from this repository. Website 01, 03 and 04 wire things in
   after review.
2. History is the only pilot specialist. Every other specialist stays disabled. A
   knowledge folder or handoff file does not mean an agent is enabled or tested.
3. The coordination handoffs say: no Z3, claim extraction or formal-check badges in
   this slice, and `claims` stays null. A later channel may **wrap** the runtime
   result "without changing this package's accepted-answer rules"
   (`docs/related-projects/logic-translator-nl2fol.md`).
4. Synthetic fixtures are labelled synthetic, and are never presented as provider
   observations or accuracy. The evaluator numbers are policy mechanics, not
   accuracy.
5. Runtime: one admitted turn calls the callback at most once. No retry, fallback,
   revision, streaming, tools or retrieval. Answer text is shown only for `answer`.
   An oversized answer is withheld, never truncated. Log only
   `redactForLog(result)`. The bundle is never trimmed or edited. Enablement needs
   verified pins, and production enablement is refused.
6. Router: select at most one specialist; never fan out; never substitute an
   unavailable specialist; browser route IDs and prompt text are never inputs;
   availability comes only from runtime capabilities; mixed requests are never
   reduced to one half.
7. A gate pass is not a review ("Deterministic format and policy heuristics. Not
   factual, academic or formal verification"). The suggested disclosure: "Checked
   by automated format rules, not reviewed by a teacher. Marks are provisional."
8. Keys only in the Worker secret store, never in the repository, the browser, a
   handoff or a chat. Never borrow anyone's credentials.
9. The repository is public: no proprietary prompts, bundle text or extracted
   internal codes until it is private. `dist/` is git-ignored. No translator code
   was copied in, and the translator is called as an external dependency.
10. The master prompt and knowledge base in the private Agent-Training repository
    are authoritative. Supplements are proposals, and the master prompt wins.
    Curators must never weaken non-negotiables, integrity or provisional-marking
    rules, or the source policy, and must never teach an agent to word answers for
    the checker.
11. Shared answering core v0.2.0: no URLs; one exact `Sources:` line with tags
    `(supplied text)`, `(course notes)` or `(recalled, not consulted)`; provisional
    label in the same sentence as any mark; checkable claims (dates, units, shown
    working, quotes only from supplied text); never fabricate.
12. Chats do not share memory, so give readers exact commits. The workflow
    subagents ignore relayed mid-task messages and stay in scope.
13. Generated handoffs: edit `agents.json`, `model-assignment.json` or
    `handoff-spec.json`, then run `generate-handoffs.mjs`. `--check` must pass, and
    generated files must not be edited by hand.

---

## 9. Open questions

1. What does the user see when the required Z3 layer is unreachable or returns
   `ERROR` or `not_run`? Is the answer withheld, or shown marked "not verified"? The
   founder's "not optional" conflicts with "specialists can run without it".
2. Should the envelope be a new outer schema (for example a verified-turn result
   wrapping `epinoic.specialist-turn-result.v1`), or a runtime contract v0.2.0 that
   fills `provenance.claims`? The second would need the five pinning tests replaced
   under review.
3. Where does the explicit TaskRequest go? Is it a record only, or a new
   `runtime-notice` version that the specialist sees? The second changes the
   specialist's input and needs review.
4. Who owns the translator service (`POST /v1/verify`), where does it run (it
   cannot be in the Worker), and how does the Worker authenticate to it? Which
   secret name holds the signing key that replaces the hard-coded simulation key?
5. Combined or twofold answers: the router contract forbids fan-out. Does the
   founder's multi-specialist mode need a routing contract v0.2.0, or does it sit
   above the router, starting after a `clarify/mixed_request` and an explicit
   student choice?
6. Should `check_answer.py` stop reading `channels[...].transmitted_reports` and use
   a public hub API, and forward the signed reply envelope so the overseer can
   verify it?
7. Cheapest-tier translation: which `verify_claim_fn` or provider adapter is
   injected, who holds its key, and how is its spend budgeted under 04?
8. Real slugs: is `language-b-spanish` the real folder name? Nine other slugs are
   still provisional.
9. Should the integrated overseer drop the simulation's LLM adjudicator power to
   clear Z3 errors, keeping adjudications advisory only?
10. Which repository is canonical for `specialist-runtime/` and `specialist-routing/`
    (this public connector, or a port into private Agent-Training)? Where does the
    Z3 adapter package live?
