# Integration kit: decisions of record, D1 to D27

**Decided 17 October 2026** under Daniel's delegation of that day: "determine yourself on all the rest of the
decisions". Every decision D1 to D27 of the kit design (section 10) is decided below with concrete values.

How to read this record:
- **A decision is documentation.** It never deploys, changes DNS, enables a paid call, changes production access, sets
  a secret, runs `wrangler d1` against a remote database or a production migration, or changes the website repository.
  Each such action is listed under "Who acts, when" with its owner, and happens only at the programme's last task
  (the website integration), with that owner's own go. The full list, in M2 order, closes this record.
- **Authority.** Where the kit design named Bruno or the founder as the decider, the entry below is the programme's
  decision of record, which the kit implements. Each such entry says in one line that Bruno may override it for his own
  repository.
- **Limits that hold whatever is decided.** The IR is data and is never executed. Consistency comes before entailment.
  A non-success status is never shown as success. Results prove properties of the logic encoding only, and the scope
  statement is kept verbatim. Agent self-reports are advisory; only signed engine results are trusted. No test is
  weakened. No deployment or live integration is claimed without evidence. Required review must pass before an answer is
  released, and a mock `passed` label is not a review. Z3 is required on the delivery path and must integrate
  seamlessly. No optimisation work now. No new GitHub repository. No spending limit is ever raised.
- **Models** are named only by tier ("the cheapest tier", "the specialist tier") and by their entry in the agents
  repository's `agents/model-assignment.json`. The concrete identifier is set by its owner as service configuration.
- **References.** F1 to F31 are the kit design's facts, and section numbers are the design's (`integration/PROTOCOL.md`
  restates sections 3 and 8). "Base M" is the website's `main` without the History pilot stack. "Base P" is `main`
  after the pilot stack (#21 to #24). M1 is the local simulation. M2 is the staging pilot. M3 is asynchronous delivery,
  which is decided here (D16) and built after M2.

---

## Summary

| # | Decision | Who acts |
|---|---|---|
| D1 | Z3 is required on the website's delivery path. The 12 October deferral is superseded, and W0 records this in the website repository | Bruno merges W0 (last task) |
| D2 | On every hosted environment, an incomplete check on a material eligible claim withholds the answer (`verified-v1`). INVALID_FORMALIZATION counts as incomplete. `verified-v1-qualify` is allowed only in development and `sim` | nobody: the kit implements it |
| D3 | COUNTEREXAMPLE, INCONSISTENT_PREMISES or UNSATISFIABLE on a material claim blocks the answer, including COUNTEREXAMPLE with only the advisory W110/W111 | nobody: the kit implements it |
| D4 | AMBIGUOUS_TRANSLATION on a material claim withholds the answer on hosted environments (422 `review_unresolved`, KIT-DL-012). It is qualified, with its label, only in development and `sim` | nobody: the kit implements it |
| D5 | No revision in synchronous delivery (M2). One bounded revision in asynchronous delivery (M3), inside the four-minute formal budget | nobody now; Bruno approves the revision budget at M3 |
| D6 | Wire the translator's existing semantic-fidelity reviewer on the cheapest tier: shadow mode on staging, `on` only after a measured precision of at least 0.98 and a new kit tag | the kit implements it; Daniel switches it on after M2 |
| D7 | M2 hosting: one external HTTPS container per environment, operated by Daniel: 1 instance, 4 slots, 60 calls per minute, at least 2 GiB. The Container binding comes later, with Bruno | Daniel hosts; Bruno sets the Worker token (last task) |
| D8 | Claims are extracted by the translator's branch parsers in the service. Specialists keep `claims: null`, and the website never extracts | nobody: the kit implements it |
| D9 / D10 | Only History on staging. `english` maps to `english-a-literature` in development and `sim` only. No website STEM route before M3; the service checks STEM | nobody: the kit implements it; Bruno schedules W7 |
| D11 | `task_id` = turnId, `request_id` = attemptId | nobody: the kit implements it |
| D12 | HMAC-SHA256 under three distinct keys, rotated every 90 days. Ed25519 is deferred to protocol 1.1 | Daniel generates the keys (last task) |
| D13 | The kit's label, disclosure and error copy is adopted. An answer is `simulated` unless both the specialist and the checks are live | Bruno merges it with patch set P (last task) |
| D14 | Conservative ceilings. Staging: 100 verified turns a day, 20 per principal. Service: 2,000 provider calls and 2,000,000 output tokens a day, and 25 overseer reviews a day. A hard limit of USD 25 a month on each new staging key. Production: zero. W5 is a `checks` reservation kind | Bruno (website budget), Daniel (service key) (last task) |
| D15 | The service keeps no request or response bodies, and its metadata logs are kept at most 30 days. The provider must not train on inputs and must keep them at most 30 days. Only Access-protected testers use staging. The licensed corpus ships only once the repository is private | Daniel (provider terms), Bruno (website notice) (last task) |
| D16 | Synchronous delivery for M2. Asynchronous delivery (protocol 1.1) is the M3 target that carries the four-minute budget | nobody now; Bruno designs the website side at M3 |
| D17 | Daniel's rule is confirmed. The four-minute formal budget applies in asynchronous delivery. An answer whose formal checks did not complete may be shown only when the overseer selects it with accuracy above 0.90, on two validated reviews; it is never labelled checked, and otherwise it is withheld. The fallback stays off on hosted environments until measured. Synchronous delivery withholds within 65 s | the kit implements it; Daniel enables the fallback after measurement |
| D18 | The overseer is embedded in v1. A sidecar replaces it only after passing the conformance suite. Overseer agents run asynchronously and are advisory. The simulation adjudicator's power to clear formal errors is removed | the kit implements it; Daniel applies A5 in the agents repository (last task) |
| D19 | The website uses single mode only. Duplicate mode never runs on the website. Combined mode only from M3, with the student's consent, W8, a connected combinator and the N_FOLD floor | nobody now |
| D20 | No new repositories. Sub-projects live on `subproject/<name>` branches of the development repository. The tag and the pointer go on `origin`, and the mirror gets no pointer. The development repository becomes private. Agents changes go on a branch of the agents repository | Daniel (visibility, tag) (last task) |
| D21 | `verified` is the only hosted path to real specialist answers (pinned) | Bruno merges the pins with patch set P (last task) |
| D22 | Overseer-agent findings after delivery are recorded as metadata with a weekly summary. Nothing retracts a delivered answer automatically. No per-item human queue in v1 | nobody: the kit implements it; Daniel reads the summary |
| D23 | Approve the `policy.defaultPrimary` entry (cheapest tier) of `model-assignment.json` version 2026-10-13.1 for every deployed role. The comparison entry is not approved. There is no runtime fallback | Daniel sets the service's model id; Bruno sets the specialist's model id (last task) |
| D24 | The website decides prior-turn context. The kit never sends prior turns to the service | Bruno (website 01) |
| D25 | Base P staging deadline: 100 s from receipt. Specialist ≤ 20 s, checks ≤ 65 s, settle margin 5 s, completion reserve 2 s | Bruno sets the pilot deadline (last task) |
| D26 | Refusals after the specialist call are final. `review_unresolved` (422) and `checks_incomplete` (503) are not retryable, with the kit's copy | Bruno merges them with patch set P (last task) |
| D27 | The review value is `checks:integration.v1`, and the badge follows `checksSummary` (conservative copy). An M3 fallback answer gets `selected:integration.v1` | Bruno merges them with patch set P (last task) |

---

## How the coupled decisions fit

### A. What blocks, what qualifies, and what may be labelled checked (D2, D3, D4, D6, D21)

One rule covers the website and the service: **on a hosted environment an answer is released only when the
deterministic review passed and every material eligible claim reached a definitive result that is not negative.**
- **The deterministic review** is the receipt, the clearances, the FINAL audit and the overseer's `delivery_decision` or
  `release_decision`. It always runs, Z3 included. A failure there is `refuse_integrity` (502) or `refuse_incomplete`
  (503).
- **Blocks (withheld, final):**
  - a negative definitive result on a material claim (D3, row 4, `refuse_unresolved`, 422);
  - AMBIGUOUS_TRANSLATION on a material claim (D4, row 6, `refuse_unresolved`, 422);
  - UNKNOWN, TIMEOUT, INTERNAL_ERROR, INVALID_FORMALIZATION or NOT_ATTEMPTED on a material eligible claim (D2, row 5, `refuse_incomplete`, 503).
- **Qualified (released with "not formally checked" labels):** a material claim that is NOT_ELIGIBLE or UNSUPPORTED.
  These claims lie outside what the encoding can express, so the formal path has finished with them. Without this, no
  History answer could ever be released, since most of its claims are interpretive.
- **Labelled checked:** only a positive definitive result with `release_permitted`, which needs a faithful,
  evidence-bound fidelity review (D6). The badge says "Automatic checks passed" only when the summary is
  `formally_checked` (D27). While D6 is in shadow mode, no hosted answer can reach that badge; the best it can say is
  "Partly checked (encoding only)". That is the honest consequence, and it is stated in the page copy (D13).
- **Only path:** on hosted environments, `verified` is the only backend that serves real specialist answers (D21). A
  configuration with no checks is refused, not served.
- **Development and `sim`** may also use `verified-v1-qualify`, which releases incomplete or ambiguous answers with
  "Check unavailable" or "more than one reading" labels. This is for tests and for measuring refusal rates only. The
  service refuses that policy on staging and production (KIT-REQ-003).

### B. Delivery and timing (D16, D17, D25, with D5)

Daniel's delivery rule: a four-minute formal budget; if it does not complete, an overseer-selected fallback above 90%
accuracy; otherwise the answer is withheld. The website's clocks decide what is buildable:
- the page gives up after 190 s (F8);
- `waitUntil` keeps work alive for at most 30 s after a disconnect (F24, F26);
- the pilot's draft deadline is 25 s (F26);
- the timing invariant `specialist_ceiling + checks_min + settle + completion_reserve ≤ deadline` (section 2.6).

A 240 s budget therefore cannot be synchronous. Overseer agents take 30 to 90 s per instance, unmeasured live (F17), so
the fallback cannot fit a synchronous turn either. The decision is:

| | M1 (base M, `sim`, development) | M2 staging (base P, synchronous) | M3 asynchronous (staging first, then production) |
|---|---|---|---|
| Deadline | 180 s after admission (`TURN_DEADLINE_MS`, unchanged) | **100 s from receipt** (pilot `deadlineAt`) | the job's ceiling is **420 s**; the page shows a pending state and reads the result from history |
| Specialist ceiling | 60 s | 20 s (`min(20 s, deadlineAt − now − 5 s)`, the pilot's own rule) | 20 s per call |
| Formal checks budget | `min(65 s, deadlineAt − now − 15 s)` | `min(65 s, deadlineAt − now − 5 s)`; `checks_min_ms` 3,000 | **240 s** in total (Daniel's four minutes), shared by the original and any revision |
| Revision (D5) | none | none | at most one, started only if at least 90 s of the formal budget remain |
| Overseer-selected fallback (D17) | exercised in the simulation and the arena | **not offered**: incomplete means withheld | `verified-v1-fallback`, at most 120 s, two independent validated reviews; **off until measured** |
| Worst case | 3 + 5 + 60 + 65 + 2 = 135 s | 3 + 5 + 20 + 65 + 5 + 2 = **100 s** | 20 + 240 + 20 + 120 + margins ≤ 420 s |

**Why this is honest.** No path labels an incomplete check as checked. The synchronous milestones withhold rather than
pretend. The only cost is refusals, which D22 reports as measured. The 240 s budget and the fallback arrive only with a
delivery mode that can actually carry them. **Production** keeps `CHAT_BACKEND=none` until Bruno's own production go,
given after M2 evidence (section F of the owner actions). When enabled, production first runs the M2 synchronous
configuration, and moves to M3 when M3 has run on staging.

### C. Hosting, caps, data terms and model tiers (D7, D14, D15, D23)

- **Who runs what.** Daniel runs the verification service on an external HTTPS container host for development and
  staging (D7). Bruno owns the Worker, its secret and its budget module.
- **Spending.** Nothing is spent until Daniel enables live calls on the service. That step is a separate owner action,
  just before staging switches to `verified`. A new service setting, `EPINOIC_PROVIDER_CALLS_PER_DAY`, defaults to 0;
  with a live provider and the default, the service refuses to start (KIT-HS-009). The caps (D14) are ceilings: the
  service's call and token caps, the Worker's turn caps, and a USD 25 per month hard limit at the provider on each new
  staging key. A cap reached is a withheld answer (`NOT_ATTEMPTED`, `provider_unavailable`, 503 `checks_incomplete`),
  never an unchecked one.
- **Data (D15).** The data that leaves the Worker is already minimised (section 2.8). The service keeps no bodies.
  The provider terms must allow at most 30 days of retention, matching the website's 30-day delete copy.
- **Models (D23).** Every deployed agent (specialist, translator, fidelity reviewer, combinator, overseer agents) runs on
  the cheapest tier, as Daniel's rule requires. It is the `policy.defaultPrimary` entry of `model-assignment.json`
  version 2026-10-13.1, whose identifier status reads "published model ID, pin exactly". The comparison entry is
  unverified and is not approved, and there is no automatic fallback (that file's own `fallbackRule`). The flash router
  is deterministic and calls no model.

### D. Signing (D12)

HMAC stays for v1. The Worker never holds a key (brief invariant 22). In v1 the Worker trusts the authenticated channel
(TLS plus the bearer token), checks the bindings and re-derives the decision. That re-derivation is what makes the
Worker's release safe, not the signature. Ed25519 would let a party without the secret verify a verdict. Nobody needs
that yet, and it adds a dependency. So it is deferred to protocol 1.1, triggered by the first consumer of verdicts off
the service host (an external auditor, or a sidecar overseer on another host).

### E. Overseer, twofold modes and findings after delivery (D18, D19, D22, with D17)

- **Synchronous milestones.** The deterministic overseer core is embedded and gates delivery. Overseer agents run after
  delivery, are advisory and never change a clearance (D18). Their findings are recorded and summarised weekly (D22).
- **M3 fallback.** The agents become a *necessary but never sufficient* condition for releasing an answer that would
  otherwise be withheld. They can never block or override the formal path. They can never upgrade a status. A fallback
  answer is labelled "not formally checked".
- **Twofold modes (D19).** None runs on the website before M3. A combined answer then gets the N_FOLD review: per
  specialist before combination, then a merged review of the combinator's output (the floor, D29 in the appendix).

### F. Repositories (D20)

- **No new GitHub repositories**: Daniel's latest instruction ("just dont create new repos. just create sub branches")
  supersedes the 13:25 go-ahead for separate repositories.
- The overseer, combinator and flash router each live in their sub-project directory on the development branch. Each
  verified version is published, by a fast-forward-only subtree split, to the branch `subproject/<name>` of the
  development repository (`origin`).
- `subproject/flash-router` already exists (`fcf2381`, a split of `flash-router/` at `af10b4a`).
- The kit tag and its pointer go on `origin` only.
- The development repository becomes private, matching its LICENSE. Only after that may the website patch files and the
  licensed corpus be published there.

### G. Retry semantics and the review value (D26, D27)

- **Refusals after the specialist call are final.** A re-arm would pay for a second generation, and the withheld text is
  never stored.
- The review value names what ran, and the badge follows the summary, so the word "passed" appears only when every
  material eligible claim is positive with its release permitted.
- An M3 fallback answer carries its own review value and never the checked one.

---

## The records

### D1. Record "Z3 is required" in the website repository

- **Decision:** Z3 is required on the website's delivery path. Bruno's 12 October deferral, brief invariant 25 and the
  two deferral notices are superseded by the 17 October requirement ("z3 is not optional"). The website records this
  through the docs change W0 (section 6.1). G0's positive marker is the string `epinoic.integration.v1` in
  `docs/current-state.md`.
- **Why:** The deferral is in force in five places on `origin/main` = `2cd3182` (F9). The website's `AGENTS.md` makes
  quoted instructions reference material only (website facts §0). So a fresh session follows the deferral until the
  website itself records the change. Without W0, the requirement cannot integrate seamlessly (P6).
- **What the kit changes:** The default stays as it is: G0 is evaluated on `origin/main` only, and a fresh session
  without G0 makes no website branch and writes W0 only as a patch file (playbook step 4). The W0 text the playbook
  prepares now also:
  - names this record ("decisions D1 to D27 decided 17 October 2026");
  - states the D25 deadline and the D21 pin;
  - adds the notes that the website's `AGENTS.md` asks for to `docs/current-state.md` and `docs/architecture.md`.

  `integration/DECISIONS.md` marks D1 "decided; W0 pending (Bruno)".
- **Who acts, when:** Bruno merges W0 on the website's `main`, at the last task, with his own go. That merge deploys
  staging (F10), so it goes after the staging prerequisites listed below, or as its own reviewed pull request. No session
  ever applies W0.
- **How to reverse:** Bruno restores the deferral sentences in a docs change. G0 is then in force again, and every fresh
  session stops at step 4.
- **Authority:** the kit named Bruno. This is the programme's decision of record; Bruno may override it for his own
  repository.

### D2. When checks cannot complete for a material eligible claim

- **Decision:**
  - **Staging and production:** withhold the answer (`verified-v1`): 503 `checks_incomplete`, final.
    INVALID_FORMALIZATION on a material eligible claim now counts as an incomplete check, alongside UNKNOWN, TIMEOUT,
    INTERNAL_ERROR and NOT_ATTEMPTED.
  - **`verified-v1-qualify`** (release labelled "Check unavailable") is allowed only where `service_env` is
    `development` or `sim`.
  - **M3:** `verified-v1-fallback` (D17) may replace the withholding only after its measurement.
- **Why:**
  - Daniel's delivery rule withholds an answer that is neither formally checked nor overseer-selected.
  - With no synchronous fallback (D17), withholding is the only honest synchronous outcome.
  - INVALID_FORMALIZATION means that the cheapest-tier translation of an eligible claim failed validation. Like
    TRANSLATION_FAILED, which already maps to INTERNAL_ERROR (section 7.1), that is a check that did not complete, not a
    claim beyond the encoding. UNSUPPORTED and NOT_ELIGIBLE stay qualified (section A).
  - Risk 6, more refusals, is accepted and measured (D22).
- **What the kit changes:**
  - **Decision table** (`delivery.decide`, `website/src/verify/decision-table.js`): row 5 adds INVALID_FORMALIZATION.
    New vector `decision-table/row5-invalid-formalization.json` (refuse under `verified-v1`), and a qualify-policy
    twin that continues with the label "Not formally checked".
  - **Policies by environment:** `COMPATIBILITY.json` gains
    `"verdict_policies_by_env": {"development": ["verified-v1", "verified-v1-qualify"], "sim": ["verified-v1", "verified-v1-qualify"], "staging": ["verified-v1"], "production": ["verified-v1"]}`.
    - The service refuses a policy outside its environment's list with KIT-REQ-003 `policy_unknown`.
    - `capabilities.policies` lists only the allowed ones.
    - The Worker's `verification.js` refuses a capabilities response that offers qualify on a hosted environment
      (`kit_hs_mismatch`).
    - `with-verification.js` keeps `verified-v1` as its only default.
  - Generated files are regenerated: `compat.py`, `compat.js`, the schemas, the vectors and the MANIFEST.
  - `PROTOCOL.md` section 8 row 5, and `DECISIONS.md`.
- **Who acts, when:** nobody: the kit implements it.
- **How to reverse:** a new kit tag that lists `verified-v1-qualify` for an environment in `verdict_policies_by_env`.
  The decision-table rows do not change.
- **Authority:** the kit named the founder with Bruno. This is the programme's decision of record; Bruno may override it
  for his own repository.

### D3. Negative definitive results on a material claim

- **Decision:** COUNTEREXAMPLE, INCONSISTENT_PREMISES and UNSATISFIABLE on a material claim of the deliverable block it:
  422 `review_unresolved`, final, with reasons KIT-DL-010 and KIT-DL-002, -007 and -008 as now. This includes a
  COUNTEREXAMPLE that carries only the advisory W110/W111. A negative result on a supporting claim does not block,
  which is unchanged (vector `deliver-with-supporting-blocking-claim`).
- **Why:**
  - Consistency before entailment: a refuted encoding of a material claim is the strongest signal the engine gives.
  - W110 and W111 say the encoding may be weak, but nothing tells a weak encoding from a wrong claim.
  - Showing the answer would mean either labelling a refuted claim or hiding the refutation. Withholding misleads no one.
  - False refusals (risk 6) are measured on staging (D22), and the M3 revision (D5) is the remedy, not a weaker rule.
- **What the kit changes:** nothing. Row 4 already blocks. `DECISIONS.md` marks D3 decided, and `PROTOCOL.md` section 8
  states that W110/W111 do not soften row 4.
- **Who acts, when:** nobody: the kit implements it.
- **How to reverse:** a new kit tag with a policy whose row 4 releases a W110/W111-only COUNTEREXAMPLE with a label. That
  is a new policy name; `verified-v1` never changes meaning.
- **Authority:** the kit named the founder. This is the programme's decision of record; Bruno may override it for his
  own repository.

### D4. AMBIGUOUS_TRANSLATION on a material claim

- **Decision:**
  - **Staging and production** (`verified-v1`): withhold the answer, with 422 `review_unresolved`, final, and reason
    KIT-DL-012 `ambiguous_material_claim`. The raw code `kit_dl_012` already maps to `review_unresolved`.
  - **`verified-v1-qualify`** (development and `sim` only): continue, labelled "Not formally checked: more than one
    reading".
  - There is no website-authored clarification in v1.
- **Why:**
  - An ambiguous material claim has more than one formal reading, and one of them may be refuted. It has not reached a
    definitive result, so Daniel's rule withholds it, as D2 does.
  - A website-authored clarification needs new contract fields and UI. Under the final-refusal rule (D26) it would also
    need the withheld text, which is never stored.
- **What the kit changes:**
  - Row 6 becomes: under `verified-v1`, `refuse_unresolved` with KIT-DL-012; under qualify, continue. KIT-DL-012 is no
    longer only reserved.
  - Vector `deliver-ambiguous-material-claim-labelled.json` moves to the qualify policy (same expected labels).
  - New vector `row6-ambiguous-default-policy-refuses.json`.
  - `PROTOCOL.md` section 8 row 6, and `website/src/verify/decision-table.js` with its tests.
- **Who acts, when:** nobody: the kit implements it.
- **How to reverse:** a new kit tag with a policy that continues on row 6. The label copy already exists.
- **Authority:** the kit named the founder with Bruno. This is the programme's decision of record; Bruno may override it
  for his own repository.

### D5. Bounded revision

- **Decision:**
  - **Synchronous delivery (M1, M2):** no revision; `revise` is never produced.
  - **Asynchronous delivery (M3):** at most one revision per turn.
    - **Trigger:** row 4 on a material claim, or a receipt error finding.
    - **Feedback:** the revision notice is built by code from finding codes and claim excerpts only, never agent text.
      This is Daniel's specialist-feedback function, in the form the overseer feedback design allows: trusted sources
      only; never steering toward entailment, inventing premises, widening numbers or dropping claims.
    - **Re-check:** the revision is re-checked in full, and a second `revise` becomes `refuse_unresolved` with
      KIT-DL-020.
    - **Time:** it starts only if at least 90 s of the 240 s formal budget remain.
    - **Cost:** it reserves one more specialist generation in the turn's budget (D14).
- **Why:**
  - At 100 s, a second specialist call plus a second checks call (20 + 65 s) does not fit (section B).
  - At 240 s it does, and a revision is the remedy for the false refusals that D3 accepts.
  - On base P a revision is a second paid generation, so it needs a budget reservation (section 3.10).
- **What the kit changes:**
  - No change for v1 policies.
  - The M3 policy `verified-v1-fallback` (D17) allows one revision. Protocol 1.1 adds
    `limits.revision_min_budget_ms: 90000`.
  - `PROTOCOL.md` section 10 states the M3 rule.
- **Who acts, when:** nobody now. At M3, Bruno approves the extra generation in the website's budget module (D14) as
  part of the M3 website change.
- **How to reverse:** a policy without revision, which is every v1 policy.
- **Authority:** the kit named the founder with Bruno (budget). This is the programme's decision of record; Bruno may
  override it for his own repository.

### D6. A cheapest-tier fidelity reviewer

- **Decision:** Wire the translator's existing advisory `SemanticReviewer` (`translate/review.py`) through the
  cheapest-tier provider. The reviewer runs as a separate call: it never sees the translator's chain of reasoning, and
  it is given the claim, the problem, the interpretation record and the evidence bundle. It runs in parallel with Z3
  inside the same checks budget, with at most 8 reviews per answer (one per translated claim).

  Modes, set by the new `EPINOIC_FIDELITY_REVIEW`:

  | Mode | Behaviour |
  |---|---|
  | `off` (default) | as today: `fidelity: missing` |
  | `shadow` | the review runs, and its verdict is kept out of the TurnVerdict: `fidelity` stays `missing` and `release_permitted` stays false. Counts are logged as metadata only |
  | `on` | the review decides `fidelity`, so `release_permitted` can become true under `outcome.assess_release` |

  - **Development and `sim`:** `on`, with fixture reviews from the corpus, so that the `formally_checked` labels are
    exercised.
  - **Staging:** `shadow`.
  - **Production:** `off`.
  - **Switching `on` on a hosted environment** requires a measured precision of the reviewer's `faithful` of at least
    0.98 (Daniel's fidelity target), on at least 200 translations from the arena rounds and the sealed hold-out
    corpora, judged blind by the strongest tier. Then a new kit tag lifts the refusal.
- **Why:**
  - Without fidelity review, nothing can be labelled formally checked (risk 7, section 3.5.3). Daniel's formal path
    labels an answer `formally_checked` only when its claims are clean.
  - A model's "faithful" is advisory (the module says so). Letting it upgrade a hosted label before it is measured would
    trust an unmeasured agent judgement.
  - Shadow mode gathers the measurement at a bounded cost: at most 8 calls per answer, counted in the D14 caps.
- **What the kit changes:**
  - `settings.py`: `EPINOIC_FIDELITY_REVIEW` (`off`, `shadow` or `on`; default `off`).
  - `preflight.py`: refuses `on` when `service_env` is `staging` or `production` (KIT-HS-009, with detail
    `fidelity_review_unmeasured`) in kit v1.
  - `protocol.py`: `translation.reviewer` becomes `none`, `fixture`, `shadow` or `live`, replacing the `none`-only
    literal. The schemas and the handshake vectors are regenerated.
  - `turn.py`: wires the reviewer into the task-aware verifier.
  - New tests: shadow mode never changes a verdict byte; `on` in `sim` reaches `formally_checked` on the corpus;
    preflight refuses `on` when hosted.
  - `PROTOCOL.md` section 5.3, and `DECISIONS.md`.
- **Who acts, when:** the kit implements shadow mode. After M2, Daniel records the measurement in `DECISIONS.md`
  under a new kit tag and sets `EPINOIC_FIDELITY_REVIEW=on` on the staging service host. Production follows with
  Bruno's production go.
- **How to reverse:** set `EPINOIC_FIDELITY_REVIEW=shadow` or `off` on the service host. Labels fall back to "encoding
  only" at once, and stored answers are replayed unchanged.
- **Authority:** the kit named the founder (Daniel). Decided under his delegation.

### D7. Hosting

- **Decision:**
  - **M2 (staging):** an external Linux container host over HTTPS with a bearer token, operated by Daniel. It runs the
    kit image `integration/deploy/container/Dockerfile`, built from the kit tag, as its non-root user `epinoic`.
  - **One deployment per environment:** development (loopback), `sim` (loopback, in the simulation), staging (hosted),
    and production (not deployed in M2). Each has its own token and keys.
  - **Capacity:** 1 instance; `EPINOIC_MAX_CONCURRENCY=4`; `EPINOIC_RATE_PER_MINUTE=60`;
    `EPINOIC_MAX_BODY_BYTES=1000000`; at least 2 GiB of memory (4 slots × 512 MB of Z3) and 2 vCPU.
  - **Host requirements:** a secret store for environment variables, TLS-terminated HTTPS, and no logging of request
    bodies by the host (D15).
  - **After M2:** the Cloudflare Container behind a Worker binding is the target hosting. It moves to Bruno's account,
    with the deliberate change to the staging-keys pin, and only after M2 has run.
- **Why:**
  - Z3 cannot run in a Worker (F11).
  - External HTTPS adds no binding beyond PR S's `CHAT_DB` (section 2.7), so M2 changes the staging-keys pin only
    once, through PR S.
  - One token per process (F12) means one deployment per environment.
  - The daily caps (D14) keep traffic far below 60 calls a minute.
  - The non-root user is required for the router boundary on hosted environments (D28), even while the router is
    detached.
- **What the kit changes:**
  - `deploy/container/README.md` records these values, and `TRANSLATOR_MODE=http` for staging.
  - `readiness/check.py --live` lists the host requirements as owner rows: names only, no values.
  - The `binding` transport stays built and tested, unused.
- **Who acts, when:** at the last task:
  - Daniel builds and deploys the staging image and sets the service variables by name on the host.
  - Bruno sets `TRANSLATOR_SERVICE_TOKEN` on the staging Worker (`wrangler secret put`, which deploys).
  - Bruno merges `TRANSLATOR_MODE=http` and `TRANSLATOR_BASE_URL` for staging in the final reviewed pull request.
- **How to reverse:**
  - Set staging `TRANSLATOR_MODE=none` through a reviewed pull request. The Worker then refuses verified turns with
    `chat_unavailable` before admission.
  - Stop the container.
  - Bruno deletes the token secret.
- **Authority:** the kit named the founder, Daniel and Bruno. This is the programme's decision of record; Bruno may
  override it for his own repository and his Cloudflare account.

### D8. Who extracts claims

- **Decision:** The translator's branch parsers extract claims inside the service, from the answer as raw text
  (section 3.5.2, step 5). Specialists keep `provenance.claims: null`, pinned by five tests (agents facts §2.5). The
  website never extracts claims and never decides eligibility.
- **Why:** A claims field inside the runtime would be a reviewed contract bump, and the five pinning tests could not be
  kept as written (no weakening). The parsers already carry the STEM front end and the packs. Keeping extraction in one
  place keeps G-EQ-ARENA comparable with the arena.
- **What the kit changes:** nothing. The specialist port already refuses a non-null `claims` (KIT-REQ-011).
  `DECISIONS.md` marks D8 decided.
- **Who acts, when:** nobody: the kit implements it.
- **How to reverse:** a runtime contract v0.3.0 that fills `claims`, with a new specialist pair in
  `COMPATIBILITY.json`. The service would still re-extract the claims and treat the runtime's as untrusted data.
- **Authority:** the kit named the founder (Daniel). Decided under his delegation.

### D9 / D10. Subjects, slugs and STEM on the website

- **Decision:**
  - **Website routes:**
    - `history` maps to `history` in development, `sim` and staging. It is the only route served on staging.
    - `english` maps to `english-a-literature` in development and `sim` only. On staging it answers
      `specialist_unmapped` (503 `chat_unavailable`), because the runtime has no English entry.
  - **STEM:**
    - No website STEM route before M3.
    - The service requires all three STEM branches at start-up (KIT-HS-005) and checks STEM for the agents driver and
      the simulation.
    - When Bruno schedules W7, the programme recommends an additive migration that keeps the legacy `route_id` CHECK and
      adds no table rebuild. That migration is Bruno's design.
  - **Spanish:** `spanish-b` is the canonical slug. `language-b-spanish` stays a service-only alias, as the subject map
    already has it.
- **Why:**
  - The runtime manifest has one entry, `history` (agents facts §2.7).
  - The website's subjects are a closed pair, and a third needs a table rebuild that the migration pins forbid (F6,
    website facts §0).
  - `english-a-literature` is the subject map's existing `sim` mapping, and it is what `check_answer.py` calls
    "English A: Literature".
- **What the kit changes:** none to `subject-map.json` (version 2026-10-17.2, unchanged digest). The English row stays
  `provisional: true` until an English specialist exists in the runtime. `DECISIONS.md` marks D9/D10 decided.
- **Who acts, when:** nobody: the kit implements it. Bruno decides when W7 happens, and its migration is his.
- **How to reverse:** a new subject-map version (a new digest and a new kit tag) that adds environments to a row.
- **Authority:** the kit named Bruno with Daniel. This is the programme's decision of record; Bruno may override it for
  his own repository.

### D11. Identifier mapping

- **Decision:** `task_id` = turnId; `request_id` = attemptId; `plan_id` = `plan-` + attemptId; `report_id` and
  `agent_id` as in section 3.2. `X-Request-Id` is a log label only.
- **Why:** turnId is stable across retries and re-arms, while attemptId fences each attempt's checks (section 3.2). The
  website's ID pattern is a subset of the protocol's, so no mapping function is needed (pre-build note 22).
- **What the kit changes:** nothing. `DECISIONS.md` marks D11 decided.
- **Who acts, when:** nobody: the kit implements it.
- **How to reverse:** a new protocol major version. Ids are bound into every verdict.
- **Authority:** the kit named Bruno. This is the programme's decision of record; Bruno may override it for his own
  repository.

### D12. Signing the verdict

- **Decision:**
  - **v1 signing:** HMAC-SHA256.
  - **Keys:** three distinct secrets of at least 32 random bytes each, all different: the engine signing key, the
    verdict key and the overseer secret (preflight already refuses equal or short keys, KIT-HS-007 and KIT-HS-008).
  - **Key ids:** dated, for example `engine-202610`, `verdict-202610`.
  - **Rotation:** every 90 days, and at once on any suspected exposure.
  - **The Worker** trusts TLS plus the bearer token, checks the bindings and re-derives the decision. It never claims to
    have verified the HMAC.
  - **Ed25519** verdict signing is deferred to protocol 1.1. It is adopted when the first consumer of verdicts off the
    service host appears: an external auditor, or a sidecar overseer on another host.
- **Why:**
  - Brief invariant 22 keeps keys out of the Worker.
  - The Worker's safety comes from the binding checks and the re-derivation (section 3.9, rows 10 to 13), which a forged
    signature could not pass anyway without matching every bound digest.
  - Within the service, the overseer trusts only signed engine results, and HMAC does that.
  - Risk 9 (the overseer holds the engine secret) is limited by TR5 and by the overseer staying embedded on the same
    host (D18).
  - Ed25519 would add a Python dependency for no current consumer.
- **What the kit changes:**
  - `deploy/container/README.md` and `rollback/ROLLBACK.md` add the rotation procedure: set the new key ids, restart,
    and let the handshake cache refresh within 60 s. Verdicts are not re-signed; stored results are replayed as they
    are.
  - `PROTOCOL.md` section 5.4 keeps the signature scope sentence. `DECISIONS.md` marks D12 decided.
- **Who acts, when:** at the last task, Daniel generates the staging keys in the service host's secret store. No key
  ever reaches the Worker, a repository, a log or a chat.
- **How to reverse:** none is needed for HMAC. Adopting Ed25519 is a protocol minor version with its own vectors.
- **Authority:** the kit named the founder (Daniel). Decided under his delegation.

### D13. Display copy and the `simulated` semantics

- **Decision:** Adopt the kit's proposals as they stand in the patch blocks and the vectors
  (`vectors/chat-contract/labels.json`):
  - **Per-claim labels:** as in section 3.8.
  - **Scope statement:** the engine scope statement, shown once per answer whenever a formal status is shown.
  - **Banned words:** no label ever says "verified", "true", "proven" or "Reviewed".
  - **Checks box title:** "Automatic checks of the logic encoding".
  - **`simulated`:** true unless the specialist and the checks are both live. Live means a live specialist provider,
    and a live translation provider on a service whose `service_env` is `staging` or `production`. Anything other than
    an explicit `false` counts as simulated.
  - **Disclosure copy:**
    - M1: "Prototype — simulated specialist; answers pass automatic checks, including formal checks of their logic
      encoding, before they are shown."
    - M2 staging, once both parts are live: "Pilot — answers come from an AI specialist and pass automatic checks,
      including formal checks of their logic encoding, before they are shown. The checks cover the logic encoding
      only; they are not a teacher's review."
- **Why:**
  - The page's current copy says no reviewer is called, which is false under `verified` (R7).
  - "Simulated" must be truthful (website rules, item 9).
  - The scope statement must be kept (the translator repository's safety rules).
  - The M2 sentence adds the scope limit, so that a positive formal result is never read as fact-checking.
- **What the kit changes:**
  - The verified-mode disclosure block (W4) gains the M2 variant, selected when `outcome.kit.simulated === false`, and
    fails closed exactly as now.
  - New vector entries for the M2 disclosure.
  - `DECISIONS.md` marks D13 decided.
- **Who acts, when:** Bruno merges the copy with patch set P, in the reviewed pull request at the last task.
- **How to reverse:** a copy-only website change by Bruno. The closed statuses and vectors keep the meaning, so the copy
  may be reworded but never upgraded.
- **Authority:** the kit named Bruno. This is the programme's decision of record; Bruno may override it for his own
  repository.

### D14. Budgets and caps

- **Decision:** All values are **ceilings**. Nothing is spent before the owner enables live calls, and no programme step
  ever raises a limit.

  **Website, staging, in base P's budget module (website task 04):**
  - 100 verified turns a day in total, and 20 per principal a day;
  - at most 3 attempts per turn (existing);
  - one specialist generation per attempt (the runtime calls its callback at most once), with the pilot's own
    per-generation limits unchanged;
  - one checks call per attempt;
  - a per-isolate concurrency limit of 4 in the checks client.

  **Verification service, staging (new settings, every default fails closed):**

  | Setting | Value |
  |---|---|
  | `EPINOIC_PROVIDER_CALLS_PER_DAY` | 2,000 (default 0; with a live provider, 0 refuses to start, KIT-HS-009) |
  | `EPINOIC_OUTPUT_TOKENS_PER_DAY` | 2,000,000 (default 0) |
  | `EPINOIC_OVERSEER_REVIEWS_PER_DAY` | 25 (default 0) |

  Per answer: at most 4,000 output tokens per call; at most 8 translated claims, at most 4 in flight; per claim, the
  pipeline's one retry and the provider's one transient retry; at most 8 fidelity reviews (D6). The worst case is 40
  cheapest-tier calls per answer.

  **Provider hard limits:** USD 25 a month on the new staging verification provider key (Daniel), and USD 25 a month on
  the new staging specialist provider key (Bruno, website task 03).

  **Production:** zero. No key, no calls, `CHAT_BACKEND=none`.

  **Form of W5:** a `checks` reservation kind in base P's `src/budget/`, reserved at admission and within the
  36-statement pin. Parallel `usage_daily` columns are not used.
- **Why:**
  - Daniel's rule: never raise a spending limit, and keep caps conservative.
  - These caps are also the honest fail-closed point. A cap reached becomes NOT_ATTEMPTED `provider_unavailable`, which
    withholds the answer (D2) and never releases it unchecked.
  - 100 turns a day at the worst case of 40 calls would exceed 2,000 calls. The service cap binds first, by design, and
    refusals are counted (D22).
  - The budget module already exists in base P (F25). One reservation kind avoids a second accounting scheme.
- **What the kit changes:**
  - `settings.py` adds the three settings, with metadata-only counters that reset at 00:00 UTC.
  - `preflight.py` refuses a live provider with a call cap of 0 (KIT-HS-009, detail `live_calls_not_enabled`).
  - `turn.py` makes the verifier return no outcome once a cap is reached (`provider_unavailable`).
  - Patch set P adds the `checks` reservation kind and its caps as values Bruno approves when he merges.
  - `DECISIONS.md` marks D14 decided.
- **Who acts, when:** at the last task. Bruno approves the website caps by merging patch set P. Daniel sets the service
  caps on the host, and sets the provider-console hard limit on the new key before the first live call. Bruno does the
  same for the specialist key.
- **How to reverse:** set `EPINOIC_PROVIDER_CALLS_PER_DAY=0`, which refuses live service at start-up. Lowering a cap is
  always allowed. Raising one is outside this programme and is the owner's own decision.
- **Authority:** the kit named Bruno (website task 04) and the founder. This is the programme's decision of record;
  Bruno may override it for his own repository.

### D15. Data terms, retention and the kit corpus

- **Decision:**
  - **What leaves the Worker:** only what section 2.8 lists (the student's message, the answer, a log-safe runtime
    projection, digests and ids). Prior turns never leave it (D24).
  - **The service:**
    - persists no request or response body;
    - keeps metadata-only logs for at most 30 days;
    - keeps an asynchronous overseer-review dossier in memory only, until its review ends;
    - keeps the evidence tap in `sim` only (KIT-HS-012 elsewhere).
  - **Providers:** the cheapest-tier provider is used only under terms that exclude training on inputs and keep them for
    at most 30 days (zero retention where the provider offers it).
  - **Who uses staging:** only testers behind Bruno's Access policy, with synthetic or self-written prompts, until Bruno
    records the student-data terms in the website's docs.
  - **The licensed corpus:** recorded arena rounds may ship as `integration/sim/corpus/licensed/`, re-keyed and listed
    by digest. They contain no student data. They ship only after the development repository is private (D20); until
    then the kit carries the synthetic corpus only.
- **Why:**
  - Risk 16: the website's delete copy promises recovery copies for at most 30 days, so no verifier copy may outlive
    that.
  - The website's rule 20 keeps real text away from providers until terms are decided.
  - Risk 18: G-EQ on recorded material, and real translations, need the recorded rounds.
  - The repository's public visibility is the only obstacle to shipping them (F21).
- **What the kit changes:**
  - `integration/sim/corpus/DATA-TERMS.md` states these terms.
  - `deploy/container/README.md` lists the host and provider terms as owner preconditions.
  - `build_corpus.py` gains `--licensed`, which refuses to write while `COMPATIBILITY.json`
    `repositories.translator_visibility` is not `private` (a new field, default `public`).
  - `DECISIONS.md` marks D15 decided.
- **Who acts, when:** at the last task. Daniel accepts the provider's data terms for the new staging key before enabling
  live calls. Bruno records the pilot's data notice in the website docs (part of W0 or patch set P). Daniel makes the
  repository private (D20), after which the programme may build the licensed subset.
- **How to reverse:** remove the licensed corpus under a new kit tag (published tags stay). Retention can only be made
  shorter.
- **Authority:** the kit named the founder and Daniel. Decided under his delegation.

### D16. Synchronous or asynchronous delivery

- **Decision:**
  - **M1 and M2:** synchronous, within the base's deadline (section B; D25 for base P).
  - **M3:** asynchronous delivery is adopted as the target that carries Daniel's four-minute formal budget, the one
    revision (D5) and the gated fallback (D17).
    - The service side is protocol `epinoic.integration.v1` minor 1.1: `POST /v1/turns/check` with
      `delivery: "async"` answers 202 with a `turn-ticket.v1`, and `GET /v1/turns/check/<request_id>` returns
      `pending` or the signed verdict.
    - The website side is a pending turn state, a background job and a page that reads the result from history. It is
      Bruno's design, written as W9, after M2.
    - The Cloudflare mechanism (Queues, Durable Objects or alarms) must be re-checked against current documentation
      (general).
- **Why:**
  - A 240 s budget exceeds the page's 190 s timeout, and the 30 s `waitUntil` window rules out long synchronous work
    after a disconnect (F8, F24).
  - Synchronous delivery is buildable now, and an asynchronous design avoids the 30 s risk (section 2.6, option c).
- **What the kit changes:**
  - Nothing for v1: `capabilities` gains `delivery: ["sync"]`.
  - `PROTOCOL.md` gains a "1.1 (planned)" note describing the asynchronous messages. Nothing is built until M2 has run.
  - `DECISIONS.md` marks D16 decided.
- **Who acts, when:** nobody now. At M3, Bruno designs and merges the website side, and the programme builds protocol
  1.1 in the translator.
- **How to reverse:** stay synchronous. Protocol 1.1 is additive, and `delivery` lists what the service offers.
- **Authority:** the kit named Bruno and the founder. This is the programme's decision of record; Bruno may override it
  for his own repository.

### D17. The delivery-rule parameters

- **Decision:** Daniel's delivery rule is confirmed and given exact terms.
  1. **The formal path.**
     - **Synchronous (M1, M2):** the formal budget is the checks budget of section B, at most 65 s.
     - **Asynchronous (M3):** the formal budget is 240 s.
     - **Outcome:** an answer whose material eligible claims all reach a positive definitive result is delivered
       through the decision table, labelled by its summary.
  2. **The overseer-selected fallback.** Policy `verified-v1-fallback`, asynchronous only.
     - **When it is considered:** only when the formal path ends in `refuse_incomplete` (row 5) or with an ambiguous
       material claim (row 6), and the deterministic review passed, and no material claim has a negative definitive
       result.
     - **Who reviews:** overseer agents built only from the exported pack, on the cheapest tier, standard profile. Each
       candidate gets at least two independent complete reviews (the floor's DUPLICATE 2), each verdict validated by the
       deterministic intake. A candidate is the original answer or its one revision.
     - **Accuracy:** the share of the candidate's material claims that both validated reviews find accurate, with no
       deterministic finding against them. A candidate qualifies only when its accuracy is strictly greater than 0.90.
     - **Choice:** the candidate with the highest accuracy is delivered, with review value `selected:integration.v1`
       (D27) and summary `overseer_selected`. It is never labelled checked, and its unfinished claims keep the "Check
       unavailable" label.
     - **Overseer deadline:** 120 s. If it passes, the answer is withheld.
  3. **Otherwise the answer is withheld,** with the existing codes.
  4. **"An answer whose required checks did not complete is never labelled checked"** is always on, under every policy.
  5. **Enablement.** The fallback policy enters a hosted environment's allowlist (D2's `verdict_policies_by_env`) only
     after a measurement of its green-light precision, judged blind by the strongest tier on the arena rounds and the
     sealed hold-out corpora (never on student data). The lower bound of its 95% Wilson interval must be at least 0.90,
     over at least 200 green-lit candidates. Until then the policy is listed for `sim` and development only.
- **Why:**
  - Daniel's rule, as recorded in the programme's standing instructions: four minutes, above 90%, else withheld, and a
    fallback never labelled checked.
  - It is implemented and tested in the translator's delivery step and the arena rounds 8 to 10. No repository yet
    carries it (inspected: no branch defines it).
  - Overseer agents take 30 to 90 s per instance (F17), so the fallback needs asynchronous delivery.
  - Agent verdicts are advisory. Using them to *permit* a release that the formal path would withhold needs measured
    evidence, not an assumption. Even then they never upgrade a status and never override a deterministic refusal.
    This keeps "only signed engine results are trusted" for every status and every checked label.
- **What the kit changes:**
  - The policy name `verified-v1-fallback`, the summary `overseer_selected` and the review value
    `selected:integration.v1` are reserved in `protocol.py`, `codes.js` and the vectors.
  - They are implemented with protocol 1.1. The handshake refuses the policy (KIT-REQ-003) unless `delivery` includes
    `async` and the environment's allowlist names it.
  - The fallback's decision vectors must equal the translator's delivery-rule vectors from the programme's delivery step
    (one shared set).
  - `PROTOCOL.md` section 9 states the fallback as a separate path that is never "checked".
  - `DECISIONS.md` marks D17 decided.
- **Who acts, when:** the kit implements it in M3. After the measurement, Daniel records it under a new kit tag that adds
  the policy to staging's allowlist. Production follows with Bruno's production go.
- **How to reverse:** remove the policy from an environment's allowlist with a new kit tag. Answers already delivered
  stay as stored, with their own review value.
- **Authority:** the kit named the founder (Daniel). Decided under his delegation.

### D18. The overseer: embedded, sidecar, agents, adjudicator

- **Decision:**
  - **Embedded in v1:** the overseer core is embedded in the service process, connected through
    `EPINOIC_OVERSEER_PORT=epinoic_overseer.port`.
  - **Sidecar:** a sidecar replaces it only after passing `integration/overseer-port/CONFORMANCE.md` on every vector,
    the simulation corpus and the tampering cases T1 to T22, with identical results. It is published first on
    `subproject/overseer` (D20) and enabled by a new kit tag.
  - **Overseer agents:** they run asynchronously after delivery and are advisory.
    - Staging: `EPINOIC_OVERSEER_AGENTS=async`, capped at 25 reviews a day (D14).
    - Production: `off` until Bruno's production go.
    - The one exception is the measured M3 fallback (D17).
  - **The simulation's model adjudicator** can no longer clear a formal error in integrated runs. Agents change A5 adds
    `--adjudicator advisory` as the default for integrated runs.
- **Why:**
  - P7, the overseer port (section 3.6) and its trust rules TR1 to TR6.
  - "Agent self-reports are advisory; the Overseer trusts only signed engine results" (the translator repository's safety rules). An adjudicator that
    removes a blocker breaks that rule (agents facts §7).
  - Async agents on staging produce the data that the D17 and D22 measurements need, within a cap.
- **What the kit changes:**
  - Settings defaults stay (`off`). The staging value is recorded in `deploy/container/README.md`.
  - `agents/PATCH-PLAN.md` A5 states the flag and its default.
  - `DECISIONS.md` marks D18 decided.
- **Who acts, when:**
  - The programme connects the embedded adapter (phase 2).
  - At the last task, Daniel sets `EPINOIC_OVERSEER_AGENTS=async` on the staging host and gives his go for agents
    changes A1 to A5 on a branch of the agents repository.
- **How to reverse:** set `EPINOIC_OVERSEER_AGENTS=off`. Deliveries do not change, because the agents never gate them in
  v1.
- **Authority:** the kit named the founder and Daniel. Decided under his delegation.

### D19. Twofold modes

- **Decision:**
  - **Single mode only** on the website in M2. No website route uses duplicate mode, which costs twice as much.
    Duplicate and combined modes are exercised in the simulation and the agents driver.
  - **Combined mode** comes to the website only in M3, and only when all of these hold:
    - it starts above the router, after `clarify/mixed_request` and the student's explicit choice of both subjects (no
      routing contract change);
    - W8 adds the contract field and the consent UI;
    - the combinator is connected (D33);
    - the overseer reviews it at the N_FOLD floor: each specialist's answer before combination, then the combinator's
      output with the bounded temporary context;
    - there are no half answers.
- **Why:**
  - The router never fans out (agents facts §3), and the v1 website cannot present a disclosed conflict (section 3.11).
  - Combined answers need two generations and a synthesis, which do not fit 100 s.
  - N_FOLD is Daniel's twofold review, and the floor enforces it (section 7a.4).
- **What the kit changes:** nothing. `capabilities.ports.checks.modes` omits `combined` while
  `EPINOIC_COMBINATOR=none`, and the Worker sends `single` only. `DECISIONS.md` marks D19 decided.
- **Who acts, when:** nobody now. At M3, Bruno designs W8.
- **How to reverse:** not applicable; enabling a mode later is additive.
- **Authority:** the kit named the founder and Bruno. This is the programme's decision of record; Bruno may override it
  for his own repository.

### D20. Repositories and visibility

- **Decision:**
  1. **No new GitHub repositories.**
  2. **Sub-projects:** the overseer, the combinator and the flash router stay sub-project directories of the translator
     development branch. Each verified version is published, by a fast-forward-only subtree split, to `origin` branch
     `subproject/<name>`, for example `subproject/flash-router` (`fcf2381`, already published).
  3. **T1 base:** the overseer rebuild commit, plus `0d28eba` (contract 0.3, the named policies), plus the end-to-end
     fixes (`8a78efe`), the argument-diagnostics commit when it lands, and this pre-build branch. Contract 0.3 or later
     must win the merge.
  4. **Canonical translator remote:** `origin` (the danielhyon98-byte development repository) carries the annotated tag
     `integration-kit-v1` and `INTEGRATION_KIT.md` on its default branch. The mirror gets no pointer: its default
     branch is never touched, and it only receives the publishers' `verified-updates`.
  5. **Canonical agents repository:** the public connector (runtime v0.1.0). Website PR #24's vendored v0.2.0 is accepted
     through the v2 pair. Agents changes A1 to A5 go on a branch of the agents repository, never a new repository. A2
     holds only envelope code and synthetic vectors, no translator code or prompt text.
  6. **Visibility:** the translator development repository becomes **private**, consistent with its LICENSE. Only after
     that may the `W*.patch` files and the licensed corpus be published in it. Until then only `apply.mjs`, the
     kit-authored blocks, `ANCHORS.md` and `RESULT.sha256`.
- **Why:**
  - Daniel's latest instruction ("just dont create new repos. just create sub branches") supersedes the 13:25 go-ahead,
    and the attempt at three repositories had been refused anyway.
  - A tag on one remote is what the playbook finds (step 2).
  - The repository is publicly clonable although its LICENSE says it is confidential (F21). The website patch files
    would copy restricted website source into it (risk 15).
- **What the kit changes:**
  - `integration/README.md` and the combinator and flash-router READMEs replace "separate repository" with the
    `subproject/<name>` branches, and record how to split one.
  - `COMPATIBILITY.json` gains `repositories.translator_visibility` (`public` until changed) and
    `repositories.subproject_branches`.
  - The playbook's step 2 is unchanged.
  - `DECISIONS.md` marks D20 decided, along with D28 and D33's repository form.
- **Who acts, when:**
  - The programme pushes the verified `subproject/*` branches to `origin` (Daniel's 17 October instruction).
  - At the last task, Daniel makes the development repository private. Then Daniel pushes the kit tag and commits the
    pointer (T10).
- **How to reverse:** a published tag is never moved; a corrected kit gets a new tag. Visibility can be changed back by
  Daniel, and patch files are then removed under a new tag.
- **Authority:** the kit named Daniel, with Bruno for the website files. Decided under Daniel's delegation; Bruno may
  override the publication of website-derived files.

### D21. `verified` as the only hosted path to real answers

- **Decision:** On staging and production, no backend other than `verified` may serve a real specialist answer. On
  base P, the pilot entry cannot be combined with a live provider without verification. The mock stays local and
  Access-protected-staging only, under its existing gates.
- **Why:** "Z3 is not optional" (P1). A specialist backend without checks would be a silent path around the required
  review (website `AGENTS.md`).
- **What the kit changes:** nothing; this is already pinned in `tests/verify-release.test.js` (W4). `DECISIONS.md`
  marks D21 decided.
- **Who acts, when:** at the last task, Bruno merges the pin with patch set P.
- **How to reverse:** a reviewed website pull request that removes the pin. Under this record, that pull request would
  also make Z3 optional, which the programme does not decide.
- **Authority:** the kit named the founder (Daniel). Decided under his delegation; Bruno may override it for his own
  repository.

### D22. Overseer-agent findings after delivery

- **Decision:**
  - **Records:** every asynchronous review result is recorded by the service as metadata only: the verdict id, the plan
    origin, the codes, and the counts by decision, KIT-DL reason and OVS-AGENT kind. No content.
  - **Weekly summary:** written to the service's log store. It covers refusal rates, the false-refusal suspects (row 4
    with W110/W111), unresolved accusations such as `translation_unfaithful`, and dropped reviews. Daniel reads it as the
    service operator.
  - Nothing ever retracts a delivered answer automatically, and students are not notified in v1.
  - **No per-item human review queue in v1:** no reviewer role exists, and the service retains no content (D15). It is
    revisited at Bruno's production go.
- **Why:** Agent verdicts are advisory (section 3.6). A confirmed accusation is already held by a deterministic check.
  The summary feeds the D3, D6 and D17 measurements without retaining student text.
- **What the kit changes:**
  - The service adds a metadata-only `review_result` log event and a weekly summary command, `python -m
    epinoic_logic.integration summary --week`, which reads the logs and prints counts only.
  - `DECISIONS.md` marks D22 decided.
- **Who acts, when:** nobody: the kit implements it. Daniel reads the summary weekly once staging runs.
- **How to reverse:** not applicable; adding a queue later is additive.
- **Authority:** the kit named the founder (Daniel). Decided under his delegation.

### D23. Model identifiers

- **Decision:**
  - **Approved:** the `policy.defaultPrimary` entry of `agents/model-assignment.json`, assignment version 2026-10-13.1
    (agents commit `5b60229`), the cheapest tier, for every deployed role: the History specialist, cheapest-tier
    translation, the fidelity reviewer, the combinator and the overseer agents. Its identifier is pinned exactly, as
    that entry's status requires.
  - **Not approved for runtime:** the `policy.defaultComparison` entry, whose identifier status is "UNVERIFIED".
  - **No automatic runtime fallback** (the file's `fallbackRule`).
  - **Switching** follows that file's `switchRule`: a reviewed comparison, recorded next to the change.
  - The flash router names no model, and its plans are refused if they do (KIT-RT-009).
- **Why:**
  - Daniel's rule: every deployed agent runs on the cheapest tier, and the strongest tier only judges, fixes and
    verifies.
  - F22 and F23: the assignment is a proposal, and the provider is untested live. Pinning the exact identifier avoids
    alias drift.
- **What the kit changes:**
  - Model identifiers stay configuration only: `EPINOIC_ANTHROPIC_MODEL` on the service host, and website task 03's
    configuration for the specialist.
  - `readiness/check.py --live` reports whether a model is configured (a name check, never a value) and that the
    assignment version is 2026-10-13.1.
  - `DECISIONS.md` marks D23 decided and names the entry, never the identifier.
- **Who acts, when:** at the last task:
  - Daniel sets `EPINOIC_TRANSLATION_PROVIDER=anthropic` and `EPINOIC_ANTHROPIC_MODEL` to the approved entry's
    identifier on the staging service host.
  - Bruno sets the specialist's model configuration in website task 03.
- **How to reverse:** unset the model variable. The service then refuses to start live (KIT-HS-009). A switch follows
  the `switchRule`.
- **Authority:** the kit named Bruno (website task 03) and the founder. This is the programme's decision of record; Bruno
  may override it for his own repository.

### D24. Conversation context for follow-ups

- **Decision:** Website 01 decides `priorTurns` and its storage under KEEP and hard delete. The kit never sends prior
  turns to the verification service: `task.user_text` is the current message only. A follow-up claim that depends on
  earlier context is checked as written, which may make it NOT_ELIGIBLE or UNSUPPORTED (labelled as such).
- **Why:** data minimisation (D15, section 2.8). The specialist runtime receives `priorTurns` from the website and is
  unaffected.
- **What the kit changes:** a new test, `tests/verify-orchestrator.test.js`, asserts that a turn with prior turns sends
  a `turn-check` whose `user_text` equals the current message and which contains no prior-turn text. `DECISIONS.md`
  marks D24 decided.
- **Who acts, when:** Bruno, within website 01; no kit action.
- **How to reverse:** a protocol minor version adding an optional context digest. Text would still never be sent
  without a new D15 decision.
- **Authority:** the kit named Bruno. This is the programme's decision of record; Bruno may override it for his own
  repository.

### D25. Timing of a verified turn on base P

- **Decision:** Option (b), a longer synchronous deadline, for M2 staging:
  - `deadlineAt` is **100 s** from the request's receipt;
  - specialist provider timeout `min(20 s, deadlineAt − now − 5 s)`, the pilot's rule, unchanged;
  - checks client timer `min(65 s, deadlineAt − now − 5 s)`;
  - `checks_min_ms` 3,000, settle margin 5 s, completion reserve 2 s.

  The invariant holds (20 + 3 + 5 + 2 = 30 ≤ 100), and the worst case is exactly 100 s (section B). After a client
  disconnect, a turn that outlives the 30 s `waitUntil` window ends `lease_expired`. Base P answers that with the final
  `answer_failed`: the answer is lost, never charged twice and never mislabelled. If the pilot keeps 25 s, the verified
  backend keeps refusing with `KIT-HS-016`, as now. Option (a) is rejected because 6 s of checks would withhold most
  answers with eligible claims. Option (d) is rejected because it releases before the required checks finish. Option
  (c) is M3 (D16).
- **Why:**
  - Section 2.6.
  - F26: the 25 s draft comes from the 30 s window.
  - The page waits 190 s (F8), so 100 s is well inside it.
  - The service's own `checks_max_ms` is 65 s, so a longer deadline would buy nothing synchronous.
- **What the kit changes:**
  - `COMPATIBILITY.json` `timing.bases.P` becomes
    `{"deadline_ms": 100000, "specialist_ceiling_ms": 20000, "checks_tail_ms": 5000}`, replacing 25,000.
  - `vectors/handshake/base-p-timing.json` becomes feasible at 100 s, and a new vector keeps 25 s → `KIT-HS-016`.
  - `compat.py` and `compat.js` are regenerated.
  - `website/PATCH-PLAN.md` (patch set P) names the pilot constant to change.
  - `DECISIONS.md` marks D25 decided.
- **Who acts, when:** at the last task, Bruno sets the pilot deadline to 100 s in the reviewed patch-set-P pull request.
- **How to reverse:** Bruno restores 25 s. The verified backend then refuses with `KIT-HS-016` and never shortens the
  checks.
- **Authority:** the kit named Bruno with the founder. This is the programme's decision of record; Bruno may override it
  for his own repository.

### D26. Retry semantics after the specialist call

- **Decision:**
  - **Final refusals:** every refusal after the specialist call has been sent is final. There is no re-arm, so nothing
    is paid twice, and an unchanged resend answers the same code.
  - **Pre-send codes re-arm:** `kit_hs_*`, `specialist_unmapped` and `specialist_unavailable`, through `REARM_CODES`
    on base P.
  - **Public codes:**

    | Code | Status | Copy |
    |---|---|---|
    | `review_unresolved` | 422, not retryable | "This answer didn't pass its automatic checks, so it isn't shown. Ask again in a new conversation." |
    | `checks_incomplete` | 503, not retryable | "This answer's automatic checks couldn't be completed, so it isn't shown. Ask again in a new conversation." |
- **Why:**
  - Base P's rule (F26): once a provider request may have been sent, every error is final.
  - Withheld text is never stored, so the same answer cannot be re-checked.
  - The copy tells the truth, and says what the student can do.
- **What the kit changes:** nothing. This is already in the blocks (`09-w1-errors.block`, `10-w1-error-copy.block`) and
  in the codes table. `DECISIONS.md` marks D26 decided.
- **Who acts, when:** at the last task, Bruno merges it with patch set P.
- **How to reverse:** a website change making these codes re-armable at the cost of a second generation. It would need
  a D14 budget for that.
- **Authority:** the kit named Bruno. This is the programme's decision of record; Bruno may override it for his own
  repository.

### D27. The review value and its badge

- **Decision:**
  - **Review value:** `checks:integration.v1`, append-only in `REVIEW_STATES`.
  - **Badge**, which follows `checksSummary` (the kit's conservative copy):

    | Summary | Badge |
    |---|---|
    | `formally_checked` | "Automatic checks passed", success tone |
    | `partly_checked` | "Partly checked", no success tone |
    | `formal_only` | "Partly checked (encoding only)", no success tone |
    | `not_formally_checkable`, or any unknown summary | "Not formally checked" |
    | `incomplete` (development and `sim` only) | "Some checks unavailable" |

  - **M3 fallback:** reserved review value `selected:integration.v1` with the badge "Not formally checked — selected by
    automated reviewers", no success tone, never "passed".
  - The verified backend never produces `passed` or `not_required`.
- **Why:**
  - Base P's convention of naming what ran (F26).
  - "Passed" may appear only when every material eligible claim is positive with its release permitted (section 9,
    rule 13).
  - A fallback answer must be distinguishable from a checked one (D17).
- **What the kit changes:**
  - `selected:integration.v1` and its badge are added to the reserved vectors (`chat-contract/labels.json`), unused
    until protocol 1.1.
  - The existing blocks stay as they are.
  - `DECISIONS.md` marks D27 decided.
- **Who acts, when:** at the last task, Bruno merges it with patch set P.
- **How to reverse:** copy changes by Bruno. A review value is never removed once rows carry it (rollback rule: keep
  the reader W1).
- **Authority:** the kit named Bruno. This is the programme's decision of record; Bruno may override it for his own
  repository.

---

## Appendix: decisions D28 to D33, added by the built kit

The pre-build's `integration/DECISIONS.md` added six decisions. They fall under the same delegation and are decided
here briefly, in the same form.

### D28. The flash router as a separate sub-agent

- **Decision:**
  - **Repository form:** a sub-project directory on the development branch, published to `subproject/flash-router`
    (D20). It is maintained and released by Daniel under its own version and identity.
  - **Hosted environments:** not attached in M2 (`EPINOIC_FLASH_ROUTER=none`); the floor plan runs.
  - **Attachment later:** only on the hosted Linux non-root image, where the process boundary holds (KIT-RT-016
    otherwise), after the overseer agents' data shows a need.
  - The translator's suite keeps running the router's own suite while it lives in the tree.
- **Why:** The router is advisory and never required (section 7a). Detaching it costs no oversight, because the floor is
  enforced.
- **What the kit changes:** documentation only (the README and DECISIONS mention the sub-branch).
- **Who acts, when:** nobody beyond the programme's sub-branch publishing.
- **How to reverse:** set the variable to the module.

### D29. The minimum-oversight floor

- **Decision:**
  - `minimum-oversight-floor/1` stays as it is now.
  - `minimum-oversight-floor/2` is adopted when the argument diagnostics are connected in phase 2. It adds two agreement
    signals that call for 2 reviews: an error-level named diagnostic, and an unverified dependency.
  - The new floor has its own digest and its own vectors. A floor is only ever raised.
- **Why:** Risk signals only escalate. Diagnostics name exactly the leaps and gaps that a single review misses.
- **What the kit changes:** `FLOOR_RULES/2`, its digest and its vectors, in phase 2.
- **Who acts, when:** nobody: the kit implements it.
- **How to reverse:** pin floor/1 under a new kit tag.

### D30. Overseer-agent profiles

- **Decision:** `standard` only. `fast` is not offered.
- **Why:** The flash pilot named more faults with `fast` (15 of 37 against 11 of 37), but made 10 false accusations
  against 3. It was not adopted, and no optimisation work is done now.
- **What the kit changes:** the overseer hello lists `["standard"]`.
- **Who acts, when:** nobody.
- **How to reverse:** a measured profile adopted under a new kit tag.

### D31. Task type

- **Decision:** `short_answer` until the website carries a task type. Bruno may add a closed field later.
- **Why:** The website sends none (pre-build), and `check_answer.py` uses `short_answer`.
- **What the kit changes:** nothing.
- **Who acts, when:** nobody.
- **How to reverse:** a protocol minor version.

### D32. Live provider timeout

- **Decision:** 20 s per cheapest-tier call (`runtime.PROVIDER_TIMEOUT_S`), always bounded by the budget left.
- **Why:** Two parallel rounds of 4 calls fit the 65 s budget. The provider is unmeasured live (F23).
- **What the kit changes:** nothing.
- **Who acts, when:** nobody.
- **How to reverse:** a measured value under a new kit tag. Thresholds are never relaxed after a measurement; a miss is
  reported.

### D33. The combinator as a separate agent

- **Decision:**
  - **Repository form:** a sub-project directory published to `subproject/combinator` once its pre-build verification
    is clean (D20).
  - **Hosted environments:** not connected in M1 or M2 (`EPINOIC_COMBINATOR=none`, so `combined` is not offered).
  - **When connected (M3, D19):** it runs in its own process. That process receives only the cheapest-tier provider
    credential and the model configuration (D23): no signing key, verdict key, overseer secret or service token.
  - The translator never imports it, and the hub decides every synthesis.
  - The translator's suite keeps running its suite.
- **Why:** Section 7. It follows the router's fault-boundary pattern.
- **What the kit changes:** the M3 process launcher, documented now and built at M3.
- **Who acts, when:** nobody now.
- **How to reverse:** set the variable to `none`.

---

## Owner actions, in M2 order

No action below has happened. Each happens only at the programme's last task (the website integration), with the named
owner's own go, in this order.

**Programme, before the last task (Daniel's repository, already authorized by his instructions):** implement the kit
changes above in phase 2's protocol step. This includes the T1 base, with contract 0.3 or later winning the merge
(D20). Then publish the verified `subproject/*` branches (D20).

1. **Daniel:** make the translator development repository private (D20, D15).
2. **Daniel:** publish the kit: the annotated tag `integration-kit-v1` on the kit commit, pushed to `origin` only, plus
   `INTEGRATION_KIT.md` and the one-line README pointer on `origin`'s default branch (T10, D20).
3. **Daniel:** give his go for agents changes A1 to A5 on a branch of the agents repository, with `--adjudicator advisory`
   as the integrated default (D18, D20).
4. **Bruno:** merge W0 on the website's `main`, recording "Z3 is required" and lifting G0 (D1). This deploys staging.
5. **Bruno:** review and merge PR S (#17): the staging `CHAT_DB` binding, `CHAT_STATE=d1`, and the migrations applied by
   the reviewed staging workflow.
6. **Bruno:** merge base P (#21 to #24): provider transports, the generation budget and the History pilot.
7. **Bruno:** set the pilot deadline to 100 s from receipt (D25). It goes into the patch-set-P pull request of step 11.
8. **Daniel:** host the staging verification service (D7, D12). Build the image from the kit tag and run it as the
   non-root user. Set, by name, in the host's secret store:
   - `EPINOIC_PROFILE=integration`, `EPINOIC_SERVICE_ENV=staging`;
   - `EPINOIC_SERVICE_TOKEN`;
   - `EPINOIC_SIGNING_KEY` / `_ID`, `EPINOIC_VERDICT_KEY` / `_ID`, `EPINOIC_OVERSEER_SECRET` (three distinct keys of
     32 bytes or more);
   - `EPINOIC_OVERSEER_AGENTS=async`, `EPINOIC_FLASH_ROUTER=none`, `EPINOIC_COMBINATOR=none`,
     `EPINOIC_FIDELITY_REVIEW=shadow`;
   - the D14 caps.

   Leave `EPINOIC_PROVIDER_CALLS_PER_DAY` at 0 for now: no live calls.
9. **Bruno:** set `TRANSLATOR_SERVICE_TOKEN` on the staging Worker with `wrangler secret put` (D7). This deploys a new
   version.
10. **Bruno:** approve the D14 website caps and the `checks` reservation kind (W5), and the D23 specialist model
    configuration (website task 03). Set the USD 25 a month hard limit on the new staging specialist key.
11. **Bruno:** review and merge patch set P, including:
    - the D13 copy, the D21 pins and the D26/D27 codes and values;
    - the 100 s deadline;
    - W5 at the next free migration number, applied to staging only by the reviewed workflow step.
12. **Daniel:** enable live calls on the staging service (D14, D15, D23):
    1. accept the provider's data terms for a new key;
    2. set its USD 25 a month hard limit;
    3. set the provider key, `EPINOIC_TRANSLATION_PROVIDER=anthropic` and `EPINOIC_ANTHROPIC_MODEL` to the
       `policy.defaultPrimary` entry's identifier;
    4. set `EPINOIC_PROVIDER_CALLS_PER_DAY=2000`, `EPINOIC_OUTPUT_TOKENS_PER_DAY=2000000` and
       `EPINOIC_OVERSEER_REVIEWS_PER_DAY=25`.
13. **Bruno:** review and merge the pull request that sets staging `CHAT_BACKEND=verified`, `TRANSLATOR_MODE=http` and
    `TRANSLATOR_BASE_URL`. It changes the pinned staging `CHAT_BACKEND === "mock"` assertion on purpose, with the kit's
    guards. Merging it deploys staging. It is the M2 activation.

**After M2: not part of M2, each with its owner's go.**
- **Daniel:** fidelity review `on` on staging, after the 0.98 measurement and a new kit tag (D6).
- **Bruno:** the M3 website design (W9 asynchronous delivery; W8 combined mode). **Programme:** protocol 1.1 (D16, D19).
- **Daniel:** the overseer-selected fallback on staging, after its measurement and a new kit tag (D17).
- **Bruno:** the Container binding target, with the staging-keys pin change (D7).
- **Bruno:** the production go. It needs M2 evidence (at least 200 verified turns, zero honesty-gate violations, measured
  latency and refusal rates in the D22 summary), the student-data terms recorded (D15) and production caps decided. No
  production key or call exists before then.
