# Integration kit design: required Z3 and STEM checks on top of the specialist APIs

This is the design that the translator repository (the "Z3 repository") will implement as an
**integration kit**. A later step builds the kit there. A later, fresh assistant session applies
it to the website and agents repositories by following the playbook in section 5.

**Status: design only.** Nothing in this document is implemented, tested or deployed. It was
written on 17 October 2026 from a read-only inspection of these commits:

| Repository | Commit read | Notes |
|---|---|---|
| Translator, package `epinoic-logic` (remotes `origin` = danielhyon98-byte/https-github.com-lovishchopra-NL2FOL, `epinoic` = Bruno-ios/Epinoic-Logic-Translator) | `main` = `8367cc9` (`22d6a5b` plus `tests/README.md`); `e2e-fix-channel` = `0d28eba` (contract 0.3, named policies); `overseer-build` = `ef4ba9f`, with a merge of `47b8c21` staged and uncommitted | `0d28eba` and `ef4ba9f` are on **no remote branch** (`git branch -r --contains` finds nothing) |
| Z3 source mirror | `eae465c` | Reference and audit only; the engine uses the PyPI `z3-solver` wheel |
| Website, `epinoic-ai-website` (Bruno-ios/Epinoic-Ai-Website) | `main` = `2cd3182` (shallow clone) | |
| Agents, `danielhyon98-byte/epinoic-agent-training-api-connector` | `6949519` | Public repository |

Evidence labels used below:
- **inspected**: read in code or configuration at the commit above.
- **doc**: stated in a repository document; it may be stale.
- **general**: platform knowledge that must be re-checked against current Cloudflare documentation before anyone relies on it.
- **proposed**: introduced by this design.

**Text rule for repository-bound parts.** Section 3 becomes `integration/PROTOCOL.md`, section 5
becomes `integration/PLAYBOOK.md`, and section 10 seeds `integration/DECISIONS.md`. None of them
may contain model names, session identifiers or scratch paths. A model identifier is read at
configuration time from the agents repository's `agents/model-assignment.json` (status
"PROPOSAL. Not approved.") and set as service configuration by the owner. Repository text says
"the cheapest tier" or "the specialist tier".

---

## 0. The requirement, and what the kit must make true

The founder wrote on 17 October 2026: "z3 is not optional but it should be able to integrate
seamlessly as long as a new instance [...] has the z3 repositories along with the website
repository and the agents repository." Earlier instructions said:
- the Z3 layer is integrated **on top of** the specialist agents and their APIs;
- it uses the cheapest model tier for translation;
- it is not built so that specialists cannot run without it;
- once integrated, it must work the way it works in the self-contained environment (the translator repository's arena, overseer and delivery rule);
- the overseer becomes a separate sub-project that runs as a sub-agent through an integration protocol.

The kit turns these instructions into seven properties that can be tested:

| # | Property | How the kit makes it true |
|---|---|---|
| P1 | **Z3 is required on the delivery path.** No answer reaches a student unless the checks port ran on that exact answer text and the delivery rule allowed it. | The verification service will not start without Z3, STEM, the named policies, the overseer core and its signing keys; a startup self-test enforces this. The Worker admits no turn while its handshake is out of date. The release gate refuses any answer that lacks a bound, current verdict with the decision `deliver`. No hosted path falls back to unchecked answers. |
| P2 | **On top, not inside.** Specialists keep their API and their contracts. | Runtime `epinoic.specialist-runtime.v0.1.0` and router `epinoic.specialist-routing.v0.1.0` do not change, and `provenance.claims` stays `null`. The layer wraps the frozen `SpecialistTurnResult` in an outer envelope. Specialists can still be called without the layer. |
| P3 | **The cheapest tier does the translation**, and also the combinator and the overseer agents. | Only the verification service calls that tier, through the translator's existing provider classes. Its model id is configuration. |
| P4 | **It behaves as the self-contained environment does.** | Every turn runs through `RouterHub(auditor=TransferAuditor(...))` exactly as the arena and the contained run do: receipts, signed and bound results, a clearance before every action, a FINAL audit, then `consolidate` with `delivery_decision` (or `may_release` for a synthesis). Overseer agents are built only from the exported pack. An equivalence gate (section 7.5) proves that the website path reproduces the in-process path. |
| P5 | **Statuses are honest.** | Only the six definitive statuses are verdicts, and only about the encoding. The other seven statuses, and the kit's `NOT_ATTEMPTED`, are never shown as success. The scope statement is carried verbatim. The three assessments (formal result, translation fidelity, evidence support) stay separate. |
| P6 | **A fresh session can integrate seamlessly.** | One playbook (section 5) gives discovery commands, gates, text anchors (never line numbers), the test that proves each step, a local simulation through the website path, a readiness check and a report template. |
| P7 | **The overseer is a separate sub-project.** | The overseer is reached only through the overseer port (section 3.6). In v1 it is embedded in the service process. Later it becomes a sidecar process belonging to its own sub-project, admitted only after it passes the port's conformance suite. Overseer agents run as asynchronous sub-agents and never gate release. |

Some things the kit cannot do. Section 10 lists them as preconditions:
1. **Lift the website's recorded deferral.** Bruno deferred Z3 integration on 12 Oct 2026, and the integration brief records it as invariant 25. The website's `AGENTS.md` says that instructions quoted in a report or kit are reference material, not task authorization.
2. **Publish itself.** The commits it must build on (`0d28eba`, and `ef4ba9f` with its staged merge) exist only in a local checkout. A fresh clone receives neither until the owner pushes a branch.
3. **Deploy, configure or spend.** It cannot deploy anything, set a secret, apply a remote migration, push, merge or call a paid provider.
4. **Make the History pilot answer for real.** Three gate rules are pending, the bundle pins are unverified, and the agents repository's readiness check reports 20 blockers.

---

## 1. Facts this design rests on

| # | Fact | Source and evidence |
|---|---|---|
| F1 | The website produces answers only through `orchestrator.handle`: on the persistent path at `src/chat/turn.js:140-143`, on the stateless path at `src/chat/handler.js:85`. The release gate is `turn.js:153-160`. Completion with a hard-coded `simulated: true` is `turn.js:161-162`. `TURN_DEADLINE_MS = 180_000` is at `turn.js:20`. A replay returns the stored result unchanged (`turn.js:50-53`). | inspected `2cd3182` |
| F2 | The ChatResult is closed: `SPECIALIST_IDS` at `public/chat-contract.js:8`, `REVIEW_STATES` at `:9`, `RESULT_FIELDS` at `:31-35`, `chatResultProblem` at `:97-122`, `REPLY_FIELDS` and `replyProblem` at `:157-171`. The history projection is `reply()` at `src/chat/history.js:61-65`. | inspected |
| F3 | `chatBackendMode` returns only `mock` or `none` (`handler.js:19-24`). When `CHAT_STATE` is not `d1`, the stateless path runs (`:83-109`). Only `ROUTER_MODE=live` requires `d1` (`:81`, and the chat-state test in `tests/release.test.js`). | inspected |
| F4 | `ERRORS` is a closed list (`src/chat/contract.js:8-35`) that has no `review_unresolved` or `checks_incomplete`. `errorResult` turns an unknown code into `internal_error`. | inspected |
| F5 | Pins in the tests:<br>- staging keys are exactly `name`, `routes`, `vars` (`tests/release.test.js:34`);<br>- the development vars equal production's;<br>- the staging vars equal production's plus five;<br>- at most 36 D1 statements per request (`tests/chat-persistence.test.js:868`);<br>- the log key sets are pinned (`:869`; `tests/chat-api.test.js:283`);<br>- migrations are pinned by SHA-256, `DROP` and `PRAGMA` are banned, and the table list is exact (`tests/migrations.test.js`). | inspected |
| F6 | `route_id` is constrained by `CHECK (route_id IN ('english','history'))` (`migrations/0001_chat_state.sql:15, :54`). `usage_daily` counts only turns and classifier calls and tokens. | inspected |
| F7 | `src/router/fastino.js` sets the conventions for outbound clients: closed failure codes with `retryable`, `redirect: "manual"`, a timer plus an `AbortController` with the turn signal forwarded, no retries, a per-isolate concurrency limit, an injectable `fetchImpl`, provider error bodies never read, and size-capped JSON. | inspected |
| F8 | The disclosure rewrite fails closed (`src/disclosure.js`). The page labels answers "Reviewed" and "(simulated)" (`public/chat.js:250-252`). The client timeout is 190 s (`public/chat-logic.js:8`). | inspected |
| F9 | The deferral is recorded in five places:<br>- `docs/current-state.md:11` ("Z3 remains deferred.") and `:19`;<br>- `docs/architecture.md:59`;<br>- the notice at the top of `docs/drafts/chat-architecture-design.md`;<br>- the notice at the top of `docs/handoff/04-logic-translator.md`;<br>- brief §9, invariant 25 ("Website Z3 integration stays deferred").<br>`AGENTS.md` says quoted instructions are not authorization. | inspected |
| F10 | Any push to `main` deploys staging (`.github/workflows/staging.yml`, `on: push: branches: [main]`). | inspected |
| F11 | Z3 cannot run inside a Worker: workerd has no `Worker` constructor, `Atomics.wait` throws, and an isolate is capped at 128 MB. Two hosts are viable: a Cloudflare Container behind a Worker binding (Workers Paid), or an external host over HTTPS. | doc: translator `docs/AUDIT.md` §4-5 and `docs/evidence/` |
| F12 | The service applies, in order: bearer authentication, a per-token rate limit, a body-size limit, strict JSON, refusal of self-certification (E505), a server-only `memory_max_mb`, an allowlist of named policies, and non-blocking concurrency (`service/app.py` at `0d28eba`). It accepts one token per process (`settings.py`). It fails closed without a token and a key. | inspected |
| F13 | No HTTP route exists for the hub, the channel or the overseer. The only HTTP routes are `/v1/verify` (single problems), `/v1/outcomes` (fixture-only claim outcomes) and two result-checking routes. | inspected |
| F14 | `RouterHub` offers `open_task`, `dispatch`, `receive` and `receipts`. `WorkPlan` allows 1 to 16 agents and has `agent_subjects`. The channel calls the injected `verify_claim_fn(claim, report[, task])` **one claim at a time** (`channel/bus.py:1956-2004`). | inspected |
| F15 | STEM subjects route to three branches, `sciences`, `mathematics` and `computer_science` (`branches/registry.py`). The STEM front end is deterministic, runs under the `nonlinear` policy, and has a budget of `STEM_CHECK_BUDGET_S = 8.0` per report (`bus.py:141`). | inspected |
| F16 | On `overseer-build`:<br>- `RouterHub(auditor=...)` offers `clearance`, `close_task` (which issues the FINAL audit and seals the journal), `consolidate` and `review_pool`;<br>- `delivery_decision(resp, keyring, hub=hub)` needs the hub that issued the response;<br>- `release_decision` accepts only a `relay_synthesis` transfer (`policy.py:266`);<br>- consolidation accepts a group of one (group basis `single`, `consolidate.py:124`);<br>- `MAX_PENDING_WAIT_MS = 250`. | inspected |
| F17 | Overseer agents are built from knowledge pack 1.3, pinned by digest. The runner takes one dossier and returns one verdict, and verdicts are advisory. The in-progress "fast profile", which is not committed, targets 30-90 s per instance; this has not been measured live. | inspected and doc |
| F18 | The commits the kit needs are local only: `0d28eba` (contract 0.3) and `ef4ba9f` (overseer). The remote `main` holds `22d6a5b` plus a README commit. | inspected |
| F19 | The translator's `CLAUDE.md` lists `docs/DESIGN.md` and `docs/STATUS.md` among the files to read first. They exist on no branch. | inspected |
| F20 | Agents runtime v0.1.0:<br>- input keys are closed;<br>- the callback is called at most once;<br>- the result is frozen;<br>- `claims: null` is pinned by five tests;<br>- the exports table is pinned.<br>The router never fans out. `integration/z3/check_answer.py`:<br>- uses a hard-coded non-secret key (`:50`);<br>- passes no `verify_claim_fn` (`:81`);<br>- reads channel internals (`:109`);<br>- discards the signed reply (`:107`). | inspected `6949519` |
| F21 | The agents repository is public. The translator repository is publicly cloneable, but its `LICENSE` says it is confidential. | doc |
| F22 | `agents/model-assignment.json` is a proposal and is not approved. | inspected |
| F23 | The Anthropic translation provider reads its model from `EPINOIC_ANTHROPIC_MODEL`, has a 120 s timeout, makes one retry and uses temperature 0. It is untested live. | inspected |
| F24 | Worker limits: 128 MB memory, 30 s CPU by default on Paid (up to 5 min), and no HTTP duration limit. `waitUntil` lasts at most 30 s after a client disconnects. | doc (translator AUDIT §4; website identity design); general, re-check |

**Corrections to the facts gathered before this design.**
- **Website line numbers.** The gathered facts give line numbers in `src/chat/turn.js` and `public/chat-contract.js` that do not match the files at `2cd3182`. For example, `orchestrator.handle` is at `turn.js:140-143`, not `:290-293`, and `RESULT_FIELDS` is at `chat-contract.js:31-35`, not `:115-119`. The playbook therefore locates every insertion point by a text anchor and stops when an anchor is missing.
- **Missing read-first files.** `docs/DESIGN.md` and `docs/STATUS.md`, both named in `CLAUDE.md`, are absent. The playbook says so, so that a fresh session neither stalls nor invents them.
- **Single answers cannot use `may_release`.** It can release only a synthesis. A single answer is delivered as a one-member consolidation through `delivery_decision`, which already exists and is tested.
- **Parallel translation needs a prefetch.** The channel verifies claims one after another, so cheapest-tier translation can run in parallel only through a prefetch (section 3.5.3).

---

## 2. Topology

### 2.1 Components

| Component | Where it runs | Code comes from | What it may hold | What it may call |
|---|---|---|---|---|
| Student page | Browser | website `public/` | nothing secret | the Worker only (`connect-src 'self'`) |
| Website Worker (the edge) | Cloudflare Worker. Staging Worker `epinoic-ai-website-staging`. Production keeps `CHAT_BACKEND=none`. | website `src/`, plus the kit adapter (`src/verify/`), plus the vendored agents runtime | the Worker secret `TRANSLATOR_SERVICE_TOKEN` (proposed); the specialist provider key (website task 03); **never a signing key** | Fastino classifier; specialist provider (through the 03 transport); verification service |
| Specialist runtime | inside the Worker (vendored ES modules) | agents `specialist-runtime/`, **unchanged** | the verified bundle | only the injected `authorizedGenerate` |
| Router | inside the Worker: the website router today; agents `specialist-routing/` later | website / agents | nothing | nothing (pure functions) |
| Verification service (checks port) | Container behind a Worker binding (target), or an external container or VM over HTTPS (first milestone). One deployment per environment. | translator `epinoic_logic` plus the new `epinoic_logic.integration` | engine signing key, verdict key, overseer secret, cheapest-tier provider key, service token | the cheapest-tier provider; nothing else |
| Z3 engine and STEM front end | inside the service process (native `z3-solver`) | translator | n/a | n/a |
| Cheapest-tier provider | the provider's API | provider SDK, through `translate/providers/` | n/a | n/a |
| Overseer core (the deterministic auditor and the delivery rule) | **v1:** embedded in the service process. **Later:** a sidecar process of the overseer sub-project. | translator `epinoic_logic.overseer`, later its own sub-repository (planned) | overseer secret (with derived subkeys); engine keys, for verification only | nothing (the sidecar will receive the journal stream) |
| Overseer agents (sub-agents) | asynchronous worker in the service, or in the sidecar, **off the student's critical path** | overseer runner plus the exported pack | n/a | the cheapest-tier provider: one dossier in, one verdict out |
| Combinator (combined mode only) | a provider call from the service (v1). It is planned as its own sub-project, so it gets its own port (section 3.7). | translator integration package, plus a versioned instruction pack | n/a | the cheapest-tier provider |
| Delivery rule | runs twice, on purpose: in the service, as `delivery_decision` or `release_decision` over its own hub and journal, recorded in the signed verdict; and in the Worker, as a thin binding check and re-derivation of the decision | translator, and the kit's website adapter | n/a | n/a |

### 2.2 Picture

```
student browser ──HTTPS, same origin, JSON, non-streaming──► Website Worker (Cloudflare)
  access gate → principal → admission (D1 caps, attempt id) → route (classifier or mock)   [existing]
  verified orchestrator                                                                     [kit]
    1. specialist port: runSpecialistTurn (vendored runtime, unchanged)
         └─ authorizedGenerate ──► specialist provider (website 03 transport, 04 budget)
    2. checks port ──HTTPS + bearer, or Container binding──► Verification service (Python, native Z3)
         one fresh RouterHub(auditor) per call:
         dispatch → receive (branch parsers, packs, STEM front end) → [combined: relay synthesis]
         → clearance before each action → close_task (FINAL audit) → consolidate → delivery_decision
         verify_claim_fn ──► cheapest-tier provider (prefetched in parallel, budgeted)
         engine: validator → compiler → Z3 under the named policies; HMAC-signed results
         overseer core (embedded in v1 | sidecar later)
         asynchronous: overseer agents (sub-agents, cheapest tier, from the exported pack)
    3. decision table (same golden vectors as the service) → compose ChatResult + checks[]
  thin release gate in turn.js (binding, re-derivation)                                     [kit]
  completeTurn (fenced by attempt id) → result_json, replayed unchanged                     [existing]
```

### 2.3 Edges: transport, authentication, limits, timeouts

| Edge | Transport | Authentication | Limits | Timeout | Retries |
|---|---|---|---|---|---|
| Browser → Worker | HTTPS, same origin, JSON | Access (staging); dev principal (loopback); production chat off | body 32 KiB; 12,000 code points; result 64 KiB | page 190 s | the page's "Try again" reuses `clientTurnId` |
| Worker → specialist runtime | in-process call | bundle SHA-256 verified by the runtime | runtime `limits`, with `maxAnswerUtf8Bytes` at most 48 KiB (proposed, leaving room for `checks`) | stage 60 s | none: the callback runs at most once |
| Runtime → specialist provider | website 03 transport | Worker secret | 04 budget | inside the 60 s stage | none (no fallback) |
| Worker → service: handshake | `GET /v1/capabilities` | `Authorization: Bearer`, with `X-Request-Id` | response read cap 16 KiB | 3 s | none. The result is cached per isolate for 60 s; a failed refresh leaves the service not ready. |
| Worker → service: turn check | `POST /v1/turns/check` over HTTPS, or the Container binding's `fetch` (general: Containers are reached through a Durable Object binding) | bearer token, plus the binding's privacy | request cap 256 KiB (Worker side; the service allows 1,000,000 bytes); response read cap 128 KiB | min(65 s, remaining − 15 s) | none in the adapter. A failure becomes a closed code and then `checks_incomplete` or `upstream_invalid`. |
| Service → cheapest-tier provider | provider SDK over HTTPS | key in the service host's secret store | 4,000 output tokens; at most 8 translated claims per answer; parallelism 4 | 20 s per call (proposed; the existing default is 120 s) | the provider's one transient retry and the pipeline's one translation retry, both bounded by the remaining budget |
| Service → Z3 | native, in-process | n/a | named-policy limits; 512 MB per verification, process-wide | 2 s per call (entailment makes 2 calls); STEM 8 s per report | none: UNKNOWN and TIMEOUT are not retried without a recorded change of configuration |
| Service ↔ overseer core | observer in the same process (v1); a local socket with JSON lines later | overseer secret subkeys; engine keys for verification only | journal 4,096 entries or 64 MB per channel; store 8,192 results | sync checks ≈1-2 ms per transfer (doc); wait for PENDING ≤ 250 ms | none |
| Overseer core → overseer agents | `CompletionProvider` | provider key | one dossier per instance; the pool's hard maximum | ≈90 s per instance (fast-profile target, not measured live) | none. Asynchronous; never gates release. |

### 2.4 Why this is feasible for a Cloudflare Worker website

1. **The Worker never solves.** Z3 cannot run there (F11), so the Worker only orchestrates I/O. Time spent waiting on `fetch` does not count as CPU time, and Workers have no HTTP duration limit (F24; general, re-check). The 180 s turn and its abort machinery already exist (F1).
2. **Few subrequests.** A turn makes at most five: the classifier, the specialist provider, a handshake refresh, the checks call, and one more for a revision or a duplicate. That is within the Free plan's 50 (website doc) and far below the Paid limits (general).
3. **Little memory.** The Worker holds at most a 128 KiB verdict and a 48 KiB answer. The 128 MB isolate limit is not at risk.
4. **D1 cost is bounded.** The verified path adds at most two single-statement reads that check the attempt is still pending (before the specialist call and before the checks call). The pin of at most 36 statements per request is measured, not assumed (section 7.2). Usage counters reuse the admission statements through additive columns (migration 0003).
5. **The result fits.** An answer of at most 48 KiB plus at most 12 check entries of at most 200 characters each stays under the 64 KiB result cap and the database's `CHECK (length(result_json) <= 65536)`.
6. **The browser never reaches the solver.** CSP `connect-src 'self'` does not change.
7. **The secrets fit the existing rules.** The Worker gains one new secret, set by Bruno, with its own vars-exclusion pin. Translation provider keys live only on the service host.
8. **The plan is right.** The account is on Workers Paid (website doc), which Containers require (F11).

### 2.5 Time budget (the 180 s turn starts after admission)

| Stage | Ceiling (proposed default) | Enforced by | Notes |
|---|---|---|---|
| Route | 5 s | existing classifier timeout | |
| Specialist (one runtime call) | 60 s | Worker timer plus the turn signal | the deferred design's figure (doc) |
| Checks call | min(65 s, remaining − 15 s) | Worker client timer. The service budget is the client timer minus 5 s, and the service stops starting new provider calls once it is spent. | Inside the call: the hub takes under 1 s (doc: 61-202 ms per task); STEM up to 8 s per report; translation of at most 8 claims, 4 at a time, at most 20 s per call; Z3 2 s per call |
| Overseer core (sync tier) | 1 s | service | clearance ≈0.3 ms (doc); PENDING wait ≤ 250 ms; FINAL audit with process replays (doc: ≈50 ms per recorded task) |
| One bounded revision (off by default) | 60 s + 30 s, only when at least 95 s remain | Worker | It rarely fits (decisions D5, D16) |
| Compose and `completeTurn` | 2 s | existing | |
| **Worst case without a revision** | **5 + 60 + 65 + 2 = 132 s** | | 48 s of margin under 180 s and 58 s under the page's 190 s |
| Overseer agents | asynchronous | service background queue | never on the critical path |

All figures above are design ceilings, not measurements. Cheapest-tier translation latency has
never been measured live (F23). Following the overseer design's rule, thresholds are fixed
before the first measured run and are never relaxed. A miss is fixed by moving work between
tiers or by optimisation, and the miss is reported. After a disconnect, `waitUntil` keeps the
work alive for at most 30 s (F24). A turn that needs longer ends as `lease_expired`, and the
next attempt starts again; this is existing behaviour. Asynchronous delivery is decision D16.

### 2.6 Hosting and environments

- **Two hosting options.**
  - A Cloudflare Container reached through a Worker binding. This is the target. It changes the staging-keys pin (F5) deliberately, with equivalent guards.
  - An external container or VM over HTTPS with a bearer token. This is the smaller first milestone: the website gains only vars and a secret.
  - The kit's Worker client supports both behind one closed interface (`TRANSLATOR_MODE` = `none | http | binding`).
- **One deployment per environment** (development, staging, production; plus `sim` for the local simulation). The reasons: the service accepts one bearer token per process (F12), and the handshake compares the service's environment label with the Worker's.
- **Capacity.** The rate limiter and the concurrency slots are per process and do not span replicas. The defaults are 60 calls per minute per token and 4 slots (F12). A turn check holds a turn slot for up to 65 s, so one process carries about four concurrent turns. Sizing is decision D7 and belongs to the operator.
- **Image.** The kit ships a proposed `integration/deploy/container/Dockerfile`, with Python 3.11 or later, the pinned `z3-solver`, and no secrets. It is built and deployed only on the owner's explicit go-ahead.

### 2.7 Data flow, minimisation and logging

- **What reaches the service:** the student's message, the specialist's answer text, a log-safe projection of the runtime result (`redactForLog(result)`, the runtime's own export, without its `turn` and `usage` members), digests, and the protocol ids (`turnId` and `attemptId` as `task_id` and `request_id`). The website has no supplied texts in v1.
- **What never reaches the service:** owner keys, emails, conversation ids, and the provider evidence or usage objects.
- **What reaches the cheapest-tier provider:** claim texts, supporting claims and the subject profile, through the translator's existing renderer. Retention terms are decision D15.
- **Website logs** keep their pinned key sets (F5). The kit adds one log event, `chat_check`, with its own pinned key set of labels only: `event`, `requestId`, `decision`, `summary`, `claimsTotal`, `claimsDefinitive`, `serviceMs`, `ms`.
- **Service logs** stay metadata-only (existing): the request id is the website's `requestId`, which correlates the two sides without exposing content.

---

## 3. The integration protocol `epinoic.integration.v1` (repository-bound: `integration/PROTOCOL.md`)

### 3.1 Conventions

- **JSON shape.** Every message is a JSON object with a closed key set, identified by `schema` (for example `epinoic.integration.turn-verdict.v1`) and by `protocol: "epinoic.integration.v1"`. Parsing is strict: no NaN or Infinity, no duplicate keys, UTF-8 only.
- **No floats.** No float appears in any object that is digested or signed (integers and strings only).
- **Timestamps** are RFC 3339 and end in `Z`.
- **Canonical JSON.** Keys are sorted. All protocol keys are ASCII, so code-point order and UTF-16 order agree. Separators are `,` and `:` with no whitespace. Non-ASCII is written raw. Lone surrogates are refused. This is the translator's `ir.canonical.canonical_json`, restated so that the JavaScript side reproduces it byte for byte. Golden vectors in `integration/vectors/canonical/` prove that both sides agree.
- **Digests** are lowercase hex SHA-256: of the canonical JSON for an object, and of the exact UTF-8 bytes for a text.
- **Ids** match `^[A-Za-z0-9._:-]{1,128}$`.
- **Headers:** `Authorization: Bearer <token>`, `X-Request-Id` (the website `requestId`, used as a label), `Content-Type: application/json`, and `Epinoic-Protocol: integration.v1`.
- **Versioning.** A receiver refuses an unknown major version. A minor version only adds optional fields, and announces them in `capabilities`. Fields are never removed within a major version.

### 3.2 Identifiers

| Protocol id | Website source | Why |
|---|---|---|
| `task_id` | `turnId` (`t_` + 32 hex, server-made, stable across the turn's retries and re-arms) | `requestId` changes on every retry and replay; `clientTurnId` is client-made |
| `request_id` | `attemptId` (`a_` + 32 hex, new at each admission or re-arm) | each attempt's checks are distinct and fenced |
| `plan_id` | `plan-` + `attemptId` | |
| `report_id` | `rep_<turnId>_<agent>_v<n>` (at most 70 characters; n ≤ 9) | inside the 128-character cap |
| `agent_id` | the agents slug (`history`); `<slug>@a` and `<slug>@b` in duplicate mode | WorkPlan agent ids must be distinct |
| HTTP `X-Request-Id` | the website `requestId` | a log label only, never part of a binding |

`turnId` and `attemptId` do not reach the orchestrator today (F1). The website patch adds them to
the orchestrator's context (W3).

### 3.3 Capability handshake

Three places refuse to start, each with a named error from section 3.12.

1. **When the service starts** (`epinoic-logic serve` with `EPINOIC_PROFILE=integration` or `integration-sim`):
   - Before it binds a socket, the service checks Z3, the STEM branches, the named policies, the overseer package and its pack digests, the keys, the provider configuration, the subject map and the limits.
   - It then runs a **self-test**: three fixed problems decided by the real engine (one linear entailment, one STEM check under `nonlinear`, one joint consistency check). Each must give its expected status and binding digest.
   - On any failure it prints one line, `KIT-HS-0xx <name>`, without secrets, and exits with status 2.
   - The default profile `engine` keeps today's behaviour exactly and adds no routes.
2. **On every capabilities request** (`GET /v1/capabilities`, authenticated). The service returns:

```
{ schema: "epinoic.integration.capabilities.v1", protocol, service_env: development|staging|production|sim,
  versions: {ir, engine, policy, translator, z3, contract}, build: {build_id, schema_id, policy_id},
  selftest: {passed: true, digests: [3 binding digests]},
  ports: {
    specialist: {version: "1.0", accepted_results: ["epinoic.specialist-turn-result.v1"],
                 accepted_runtime_contracts: ["epinoic.specialist-runtime.v0.1.0"]},
    checks: {version: "1.0", modes: [single, duplicate?, combined?], named_policies: [linear, nonlinear, joint],
             stem: {branches: [sciences, mathematics, computer_science], report_budget_s: 8}},
    overseer: {version: "1.0", mode: embedded|sidecar, auditor_version, pack_digests: [...],
               replay_mode: process, inline_final_release: false, agents: off|async},
    translation: {provider: fixture|anthropic|openai_compatible, tier: "cheapest", live: bool, reviewer: none|...},
    combinator: {available: bool} },
  subject_map: {version, sha256},
  policies: ["verified-v1", "verified-v1-qualify"],
  limits: {max_body_bytes, max_answer_bytes, max_answers, max_translated_claims, checks_budget_ms_max, turn_slots},
  signing: {verdict_alg: "hmac-sha256", verdict_key_id, engine_key_id},
  issued_at }
```

3. **In the Worker, before admission** (`verification.ready()`, called where `routing.ready()` is called today, `handler.js:122-125`):
   - The Worker requires a capabilities response less than 60 s old that matches its pinned compatibility set (`src/verify/compat.js`, generated from `integration/COMPATIBILITY.json`), with `selftest.passed`.
   - It also requires a translation tier that matches the environment: development and `sim` accept the fixture provider; staging and production require a live provider.
   - The routed slug must be `available` in the runtime's `getCapabilities({environment})`.
   - If any of this fails, the Worker returns `503 chat_unavailable` before admission, so nothing is stored or charged. It logs only the label `kit_not_ready:<code>`.

### 3.4 Specialist port (`epinoic.integration.specialist-answer.v1`)

The port wraps the runtime's existing output and never changes it.

| Field | Content |
|---|---|
| `schema`, `agent_id` | as in section 3.2 |
| `runtime` | `{schema: result.schema, contract_version: result.contractVersion}` |
| `log` | `redactForLog(result)` (`epinoic.specialist-turn-log.v1`), the runtime's own log-safe projection (outcome, gate, provenance, completion, dispatch; no text), **without its `turn` and `usage` members**. The website's conversation id therefore never leaves the Worker; the protocol ids travel only in `ids` (section 3.2). |
| `answer` | `result.answer`, unchanged |
| `answer_sha256` | SHA-256 of the answer's UTF-8 bytes |
| `result_sha256` | SHA-256 of the canonical JSON of the whole frozen result, computed in the Worker. It is opaque to the service, which echoes it but never recomputes it. |

Rules:
- The Worker builds an envelope only when `outcome === "answer"`; that outcome already implies `gate.status === "passed"` (F20). Every other outcome maps to a closed website error without calling the checks port.
- The service re-validates the schema and contract against `capabilities.ports.specialist`, the outcome, `answer_sha256`, and that `log.provenance.slug` matches the subject map. The gate is a format precondition, never evidence of verification; the runtime's own disclaimer says so.
- Self-certification fields at the envelope's top level are refused, as E505 does today.

### 3.5 Checks port (required): `POST /v1/turns/check`

#### 3.5.1 Request (`epinoic.integration.turn-check.v1`)

| Field | Rule |
|---|---|
| `mode` | `single`, `duplicate` or `combined`. It must appear in `capabilities.ports.checks.modes`. Single takes 1 answer; duplicate and combined take 2. |
| `ids` | `{task_id, request_id}` |
| `task` | `{route, slug, subject, course_level, task_type, user_text, user_text_sha256, supplied_texts: []}`. Slug and subject come from the subject map. `user_text` is at most 48 KiB. |
| `answers` | specialist-answer envelopes (section 3.4) |
| `policy` | one name from `capabilities.policies`, never limits or a free-form object |
| `budget_ms` | at most `checks_budget_ms_max` |
| `revision_of` | a `verdict_id`, or `null` |
| `options` | `{include_evidence: bool}`: `true` is accepted only by the `integration-sim` profile and by an operator token (decision D15). The website client never sets it, because its response read cap is 128 KiB. |

#### 3.5.2 Processing order inside the service (normative)

One call uses one fresh `RouterHub(signing_key, verify_claim_fn, config, auditor=TransferAuditor(KeyRing(...), replay_mode="process"))`:

1. **Validate the envelope and the answers.** On failure, return HTTP 400 with a `KIT-REQ-*` code. Nothing runs.
2. **Build and seal a `WorkPlan`.** The subject display name comes from the subject map, `selected_agent_ids` from the answers, `agent_subjects` is set in combined mode, and `deadline_at` is now plus the budget.
3. **Open the task and dispatch** the student's message to each agent. Check `may_act` on each dispatch receipt. A REJECTED dispatch is an integrity failure.
4. **Prefetch translations** (section 3.5.3).
5. **Receive each answer** as raw text, with its `agent_id` and `report_id`. The branch parser extracts the claims, so the specialists emit no structured claims. Call `check_before_acting` on each response receipt, waiting at most 250 ms.
6. **Combined mode only:** the combinator port (section 3.7) writes a synthesis from the delivered claims. It is relayed through the hub, and `check_before_acting` is called on the synthesis receipt.
7. **`close_task`**, which issues the FINAL audit, signed under `overseer-audit`.
8. **Deliver.** In single and duplicate modes, call `hub.consolidate(task)` and then `delivery_decision(resp, keyring, hub=hub)`. In combined mode, call `release_decision(synthesis_receipt, final_audit, keyring, audits=..., journal=..., message=synthesis_message)`.
   - The kit's tests confirm the order. Because `delivery_decision` refuses a stale consolidation, a wrong order fails closed: the answer is not delivered.
9. **Build the per-claim entries.** They come from the authoritative journal view (`hub.view(task)`), plus the receipts' outcomes and formal checks; channel internals are never read. Then apply the decision table (section 3.8) under the named policy.
10. **Sign the `TurnVerdict`** with HMAC under the verdict key, return it, and queue the asynchronous overseer-agent review if it is enabled. The queue is bounded and drops work when full; drops are counted.

**Budget.**
- A monotonic deadline covers steps 3 to 9. Once it has passed, the verifier returns `None` for the remaining claims, so the channel records no outcome for them. Each eligible claim left that way becomes `NOT_ATTEMPTED`, with the reason `skipped_budget`.
- The deterministic steps still complete, since they are fast.
- An unexpected exception produces a verdict with the decision `refuse_incomplete` and the reason `KIT-DL-900`. It never produces `deliver`.

#### 3.5.3 Cheapest-tier translation, prefetched

- **Prefetch.** Before `receive`, the service runs the same branch parser on the same inputs to list the claims the channel will deliver, and computes their eligibility deterministically: the eligibility rules plus the subject policy, with no model call for a claim that is NOT_ELIGIBLE. It then requests translations for up to `max_translated_claims` eligible material claims, in document order, with at most 4 in flight.
- **Serving.** The verifier (`fn(claim, report, task=...)`, which calls `verify_claim(..., task=task)`) serves the proposals from a cache keyed by (claim-text SHA-256, prompt version, attempt). This is how the arena serves recorded translations. A claim the prefetch did not foresee is translated on demand while budget remains.
- **Non-interference test:** with prefetch on and with it off, the receipts must be identical, ignoring volatile fields, for the same provider responses.
- **Fidelity review** (decision D6) is off by default. Without it, `ReleaseAssessment.fidelity` is `missing`, so `release_permitted` is false, and a positive formal result can be labelled only "formal check of the encoding". It is never labelled "checked".

#### 3.5.4 Response (`epinoic.integration.turn-verdict.v1`)

```
{ schema, protocol, verdict_id, issued_at,
  ids: {task_id, request_id, plan_id, channel_uid},
  bound: {user_text_sha256, policy, mode,
          answers: [{agent_id, answer_sha256, result_sha256, report_id, message_id}]},
  service: {service_env, versions, build, subject_map_sha256},
  delivery: {decision: deliver|revise|refuse_unresolved|refuse_incomplete|refuse_integrity,
             deliverable: {agent_id|"synthesis", answer_sha256, message_id} | null,
             reasons: [KIT-DL-*], consolidation: {id, status, basis} | null, synthesis: {id, receipt_status} | null},
  overseer: {mode, final_audit_id, state: AUDIT_PASSED|AUDIT_PASSED_WITH_FINDINGS|AUDIT_PENDING|AUDIT_FAILED,
             error_codes: [OVS-* at error level], delivery_allowed: bool, refusal: closed label | null},
  receipt: {status: ACCEPTED|ACCEPTED_WITH_FINDINGS|REJECTED, error_codes: [...], warning_count, branch},
  claims: [ {claim_id, materiality, role, excerpt (≤ 200 chars, a verbatim substring of the answer),
             source: translation|branch_check|stem,
             formal: one of the 13 statuses | NOT_ATTEMPTED,
             attempt: attempted|not_eligible|skipped_cap|skipped_budget|provider_unavailable|stem_budget,
             fidelity: faithful|unfaithful|uncertain|missing|stale|unbound|without_evidence,
             evidence_resolved: bool, release_permitted: bool, result_id?, binding_digest?} ],  (at most 32, material first)
  counts: {claims_total, material, eligible, attempted, definitive, positive, blocking, unavailable, not_eligible},
  summary: formally_checked|partly_checked|formal_only|not_formally_checkable|incomplete,
  scope_statement: <the engine scope statement, verbatim>, audit_scope_statement: <TR6, verbatim>,
  timings: {total_ms, translation_ms, solver_ms, overseer_ms},
  signature: {alg: "hmac-sha256", key_id, value} }
```

`receipt` and `claims` describe the **deliverable**:
- single mode: the one answer;
- duplicate mode: the consolidation's representative, with the excluded answers counted in `consolidation`;
- combined mode: the synthesis receipt, and the synthesized claims together with the outcomes of their source claims.

With `include_evidence`, the response also carries an evidence bundle: full receipts, outcomes,
signed `VerificationResult`s, the FINAL audit, the consolidated response and the journal head.
It is bounded at 900 KB and used by the simulation and by operators only.

The simulation obtains evidence for a website-path turn by repeating the same call with the
same inputs, ids and fixture provider. The engine and the hub are deterministic for the same
inputs, apart from timestamps and random ids, so the repeated call's binding digests and finding
multisets must equal those behind the Worker's verdict. That equality is part of the G-EQ gate.

**Signature scope.** The website never holds a signing key (invariant 22). So in v1 the Worker:
- trusts the authenticated channel (bearer token, and the binding where one is used);
- checks the bindings;
- re-derives the decision.

It does not claim to have verified the HMAC. The signature lets operators, and the overseer, audit
the verdict later. Signing the verdict with Ed25519, which the Worker could verify with a public
key, is decision D12. It adds a Python dependency.

### 3.6 Overseer port (`epinoic.integration.overseer-port.v1`)

The overseer is reached only through this port, which is what lets it become a separate sub-project.

| Operation | Embedded mode (v1): the existing calls | Sidecar mode (later): message over a local authenticated socket |
|---|---|---|
| `hello` | read `auditor_version`, `PACK_DIGESTS`, key ids | `hello` → `{port_version, auditor_version, pack_digests, key_ids, replay_mode}` |
| `attach` | `RouterHub(auditor=TransferAuditor(KeyRing({engine_key_id: EngineKey(secret, "local")}, overseer_secret)))` | the hub gets an observer that forwards each immutable `ChannelEvent`, plus the captured signed results, as `event` messages; the sidecar journals them |
| `clearance` | `hub.clearance(task, message_id, receipt=rc, wait_ms≤250)` and `policy.act_decision` | `clearance_req` → `TransferClearance` |
| `close` | `hub.close_task(task)` → the FINAL `OverseerAudit` | `close_req` → signed audit |
| `deliver` | `hub.consolidate` + `delivery_decision(..., hub=hub)`; or `release_decision` | `deliver_req` → decision. The sidecar asks the service for live-custody probes, so `live_custody` keeps working across processes. |
| `review` (asynchronous) | `hub.review_pool(tasks, OverseerPool(pack, provider_factory))` → dossiers → runners on the cheapest tier → intake → validation → combination → signed verdicts-scope audit | `review_req` → `ticket`; `review_result` later |

Trust rules carried over unchanged:
- Only deterministic `OVS-*` findings affect clearance (TR1 to TR3).
- `OVS-AGENT-*` never changes a clearance.
- The auditor holds engine keys only to verify, and signs under its own subkeys (TR5).
- Every audit carries the engine scope statement and the TR6 sentence.
- Overseer agents are built only from the exported pack, checked against its digests, and their verdicts are validated, never obeyed.
- The simulation's language-model "Z3 adjudicator", which could clear a formal error, is **not** part of the integrated overseer (decision D18).

**What happens to agent reviews.** They run after delivery. A confirmed accusation means a
deterministic check already holds the finding. An accusation of a kind no check decides, such as
`translation_unfaithful`, stays unresolved and goes to a human review queue (decision D22).
Nothing retracts a delivered answer automatically.

**Admission of a sidecar.** A sidecar replaces the embedded mode only after it passes the
conformance suite. The suite requires the same clearances, audit states, consolidation statuses,
delivery decisions and refusal reasons as the embedded mode on all vectors, on the simulation
corpus and on the tampering cases T1-T22. Until then, the handshake reports `overseer.mode = embedded`.

### 3.7 Combinator port (combined mode only; `epinoic.integration.combinator-port.v1`)

**Input.** The `synthesis_format` built from the delivered claims (the arena's contract,
`list_claims.py --json`): claim ids, texts, digests and the closed transformation vocabulary.

**Output.** One synthesis JSON, which the hub validates as untrusted data
(INT-REQ-009/INT-SYNTH-014 for a bad vocabulary; INT-LEDGER-* for the ledger).

**v1 implementation.** A provider call from the service on the cheapest tier, with a versioned
instruction pack pinned by digest, like the overseer pack. A combinator sub-project, which is
planned, may implement the same port later. When no combinator is configured,
`capabilities.ports.checks.modes` omits `combined`.

### 3.8 Statuses and the decision table (identical in the service and the Worker)

**Per claim.**
- **The six positive or negative verdicts.**
  - Positive for the query: ENTAILED, CONSISTENT, SATISFIABLE.
  - Negative: COUNTEREXAMPLE, INCONSISTENT_PREMISES, UNSATISFIABLE.
  - All six are verdicts about the encoding only.
- **The seven non-results:** UNKNOWN, TIMEOUT, UNSUPPORTED, INVALID_FORMALIZATION, AMBIGUOUS_TRANSLATION, NOT_ELIGIBLE, INTERNAL_ERROR.
- **NOT_ATTEMPTED** is the kit's marker for an eligible claim that was skipped by the cap or the budget, or because the provider was unavailable. It is a non-result.

**Per answer.** Rows are evaluated in order, the first match wins, and only material claims
count where a row says so:

| # | Condition | Decision | Reason | Website reply |
|---|---|---|---|---|
| 1 | The Worker's binding checks fail (protocol, shape, ids ≠ turnId/attemptId, `answer_sha256` ≠ SHA-256 of the text to release, scope statement differs from the pinned constant) | `refuse_integrity` | KIT-DL-030 (Worker only) | 502 `upstream_invalid` |
| 2 | The receipt is REJECTED; or the overseer state is AUDIT_FAILED; or delivery was refused for a signature, custody or staleness reason | `refuse_integrity` | KIT-DL-001, -003, -006 | 502 `upstream_invalid` |
| 3 | The overseer state is AUDIT_PENDING after the bounded wait (the transfer was held) | `refuse_incomplete` | KIT-DL-004 | 503 `checks_incomplete` |
| 4 | The deliverable's receipt has error-level findings; or the consolidation is CONFLICTING or NO_DELIVERABLE_OUTPUT; or a material claim of the deliverable is COUNTEREXAMPLE, INCONSISTENT_PREMISES or UNSATISFIABLE. (In duplicate mode, an answer the consolidation excluded does not block when another answer is delivered.) | `revise`, when the policy allows one revision that has not yet happened; otherwise `refuse_unresolved` | KIT-DL-002, -007, -008, -010 | 422 `review_unresolved` |
| 5 | A material eligible claim is UNKNOWN, TIMEOUT, INTERNAL_ERROR or NOT_ATTEMPTED | policy `verified-v1` (default): `refuse_incomplete`; policy `verified-v1-qualify`: continue | KIT-DL-011, -013 | 503 `checks_incomplete`, or continue |
| 6 | A material claim is AMBIGUOUS_TRANSLATION | default: continue, labelled; a blocking policy: `refuse_unresolved` | KIT-DL-012 | continue, or 422 |
| 7 | Otherwise | `deliver` | n/a | 200 answer, `review: "passed"`, with `checks` and `checksSummary` |

NOT_ELIGIBLE, UNSUPPORTED and INVALID_FORMALIZATION neither block nor make the checks
incomplete. They are labelled as not formally checked.

**`summary`** is computed only for `deliver`:
- `incomplete`: some material eligible claim has no definitive result (reachable only under the qualify policy).
- `not_formally_checkable`: no material claim is eligible and no branch check exists.
- `formally_checked`: every material eligible claim is a positive definitive result with `release_permitted`.
- `partly_checked`: some, but not all, are.
- `formal_only`: there are positive definitive results, but none has `release_permitted` (no fidelity review, or the evidence is unresolved).

**Website mapping** (proposed, decision D13):
- `checks` holds at most 12 entries `{claim, formal, fidelity}` for material claims. The labels are written by the website from the closed statuses, never from the service's prose.
- A positive result with fidelity `faithful` and evidence resolved reads: "Formally checked: in its logic encoding, this claim follows from its stated premises."
- A positive result otherwise reads: "The logic encoding passed a formal check; the encoding and its premises were not independently established."
- NOT_ELIGIBLE reads: "Not eligible for a formal check (reviewed in context)."
- UNSUPPORTED and INVALID_FORMALIZATION read: "Not formally checked."
- AMBIGUOUS_TRANSLATION reads: "Not formally checked: more than one reading."
- UNKNOWN, TIMEOUT, INTERNAL_ERROR and NOT_ATTEMPTED read "Check unavailable" (qualify policy only).
- The engine scope statement is shown verbatim once per answer.
- No label ever says "verified", "true" or "proven".

### 3.9 The delivery rule (normative)

An answer, whether a single answer, a consolidated duplicate or a combined synthesis, is shown
to a student only when every condition below holds. They are checked by code, in this order, and
the first one that fails names the refusal.

1. The handshake is current and compatible (section 3.3).
2. The attempt is still pending: the Worker checks this before the specialist call and before the checks call. The fenced completion re-checks it at the end.
3. Every contributing specialist's outcome is `answer`.
4. The verdict is well formed and bound to this `task_id`, this `request_id`, this `user_text_sha256` and these answer digests.
5. The receipt is not REJECTED and carries no error-level finding. The FINAL audit passed (AUDIT_PASSED or AUDIT_PASSED_WITH_FINDINGS).
6. The overseer's delivery decision allowed delivery: `delivery_decision` for single and duplicate modes, `release_decision` for combined mode.
7. Decision-table rows 3 to 6 do not refuse under the named policy.
8. The Worker re-derives the same decision from the verdict's fields. Any disagreement is `refuse_integrity`, logged as `kit_decision_mismatch`.
9. The text being released is byte-identical to the checked deliverable (digest comparison).
10. The ChatResult passes `chatResultProblem`, `specialist === route.routeId`, and its size is at most 64 KiB.
11. The labels are truthful: nothing non-definitive is labelled checked; the scope statement is present whenever a formal status is shown; and `simulated` is true unless both the specialist and the checks are live.

Only then does `completeTurn` store the result, which is then replayed unchanged.

**The rule holds in every case.** An answer whose required checks did not complete is never
labelled as checked, whatever the policy.

### 3.10 Bounded revision (off by default, decision D5)

When the decision is `revise` and the policy allows one revision, the orchestrator may run one
more specialist turn, but only when at least 95 s remain:
- The new turn's message carries a revision notice built by code. It lists finding codes and the affected claim excerpts, and never includes agent text.
- The mandatory bundle comes with it as usual.
- The orchestrator then sends a new checks call with `revision_of` set.

A second `revise` becomes `refuse_unresolved` with KIT-DL-020. A revision is a new runtime call
with its own budget; the specialist's code does not change.

### 3.11 Twofold modes (the overseer's consolidation and synthesis paths)

- **Duplicate** (two instances of one specialist, for redundancy):
  - The orchestrator runs two runtime turns of the same slug in parallel. Each has its own `authorizedGenerate` budget.
  - It sends a checks call with mode `duplicate` and agents `<slug>@a` and `<slug>@b`, both given the same input.
  - The service runs `consolidate`, which does exclusion, grouping by identical text or by material claims the engine confirms, and picks the earliest clean representative. It then calls `delivery_decision`.
  - CONFLICTING and NO_DELIVERABLE_OUTPUT lead to `refuse_unresolved`, because the v1 website cannot present a disclosed conflict.
  - The student sees the representative's text. The website contract does not change.
- **Combined** (two different specialists on a cross-subject request):
  - It starts only after the router's `clarify/mixed_request` **and** an explicit choice by the student. This needs a website contract change (decision D19). The router itself still never fans out and never reduces a mixed request to one half.
  - Two runtime turns run in parallel. If either is not an answer, the result is `refuse_unresolved`; there are no half answers.
  - The checks call has mode `combined`, `agent_subjects` is set, and the combinator port writes a synthesis.
  - The hub runs its ledger and conflict checks, then `close_task`, then `release_decision` on the synthesis receipt.
  - The deliverable is the synthesis text.
- **The decision maker** (pending; "duplication versus in-depth"):
  - The default is deterministic: `single`. Duplicate is used only for the routes the policy lists.
  - An optional cheapest-tier advisory proposal `{mode, overseer_depth}` may be added. It is validated against availability, the remaining time, the caps and the policy allowlist, and recorded in the journal as data.
  - The proposal never changes a clearance or a release.
  - "In-depth" means more overseer-agent instances in the asynchronous review (the pool plan). It never touches the critical path.

### 3.12 Closed error codes

**Handshake and start-up** (`KIT-HS`):

| Code | Name | Meaning |
|---|---|---|
| 001 | `protocol_unsupported` | protocol major or minor version not accepted |
| 002 | `component_versions_mismatch` | ir, engine, policy, translator or contract version not in `COMPATIBILITY.json` |
| 003 | `z3_unavailable` | Z3 not importable, or its version is outside the accepted range |
| 004 | `selftest_failed` | the startup self-test did not give the expected results |
| 005 | `stem_unavailable` | a STEM branch or the `nonlinear` policy is missing |
| 006 | `named_policies_unavailable` | contract older than 0.3 |
| 007 | `overseer_unavailable` | overseer package missing, pack digest mismatch, overseer secret invalid or equal to an engine key, or a sidecar that is not conformant |
| 008 | `signing_unconfigured` | engine signing key or verdict key missing or too short |
| 009 | `translation_provider_unconfigured` | a live profile without a provider or model, or the sim profile with a live provider |
| 010 | `subject_map_mismatch` | the subject maps differ |
| 011 | `specialist_contract_unsupported` | the specialist runtime contract or result schema is not accepted |
| 012 | `environment_mismatch` | the service's environment label differs from the Worker's, or the sim profile is bound to a non-loopback address |
| 013 | `limits_incompatible` | the service limits cannot carry the Worker's largest request, or the budgets exceed the turn |
| 014 | `transport_unconfigured` | Worker: mode `none` or invalid, a base URL that is not https outside loopback, a missing or malformed token, or an absent binding |
| 015 | `handshake_unreachable` | Worker: the capabilities call failed |

**Request validation** (`KIT-REQ`; the service answers HTTP 400):

| Code | Name |
|---|---|
| 001 | `envelope_invalid` |
| 002 | `mode_unsupported` |
| 003 | `policy_unknown` |
| 004 | `ids_invalid` |
| 005 | `self_certification_rejected` |
| 006 | `too_large` |
| 010 | `specialist_schema_unsupported` |
| 011 | `specialist_contract_unsupported` |
| 012 | `specialist_not_an_answer` |
| 013 | `specialist_gate_not_passed` |
| 014 | `answer_digest_mismatch` |
| 015 | `subject_unmapped` |

**Delivery reasons** (`KIT-DL`):

| Code | Name |
|---|---|
| 001 | `receipt_rejected` |
| 002 | `receipt_error_findings` |
| 003 | `clearance_failed` |
| 004 | `clearance_pending` |
| 005 | `final_audit_not_passed` |
| 006 | `delivery_refused` |
| 007 | `consolidation_conflicting` |
| 008 | `no_deliverable_output` |
| 010 | `blocking_formal_result` |
| 011 | `checks_incomplete` |
| 012 | `ambiguous_material_claim` |
| 013 | `budget_spent` |
| 020 | `revision_exhausted` |
| 030 | `worker_binding_mismatch` |
| 900 | `internal_error` |

**Worker client failures** (closed, in the style of `CLASSIFIER_FAILURES`):
- `verifier_not_configured`
- `verifier_not_ready`
- `verifier_busy`
- `verifier_cancelled`
- `verifier_timeout`
- `verifier_network`
- `verifier_redirect`
- `verifier_auth`
- `verifier_rate_limited`
- `verifier_capacity`
- `verifier_rejected`
- `verifier_error`
- `verifier_malformed`
- `verifier_binding_mismatch`

`verifier_malformed` and `verifier_binding_mismatch` become `upstream_invalid`. Every other
client failure becomes `checks_incomplete`. The raw code stays in D1 for operators, as the
existing pattern does.

**New public website codes** (proposed): `review_unresolved` (422, not retryable) and
`checks_incomplete` (503, retryable).

### 3.13 Compatibility and change rules

- `integration/COMPATIBILITY.json` pins:
  - the protocol;
  - the accepted component versions (IR 1.0, engine 0.4.0, policy 2026.10-v4, translator 0.4.0, contract 0.3 or 0.4);
  - the specialist runtime contracts and result schemas;
  - the routing contract;
  - the subject-map digest;
  - the policy names.

  It records the build identity but does not require it to match, because every source change alters `build_id`.
- **One generated copy per side.** The website's `src/verify/compat.js` and the service's `integration/compat.py` are generated from the JSON, and drift tests compare them with it.
- **Changes to the rules.** Changing a status meaning or removing a field needs a new major version and the agreement of the receiving owner, as the integration contract §11 already requires. Adding the protocol endpoints raises the translator's integration contract to 0.4; the component versions do not change.

---

## 4. Kit layout in the translator repository

```
integration/                                  the kit; not installed with the package (like scripts/)
  README.md                                   entry point: what the kit is, its status, where to start; links PLAYBOOK.md
  PLAYBOOK.md                                 section 5 of this design (repository-bound text)
  PROTOCOL.md                                 section 3 (normative)
  DECISIONS.md                                section 10: each decision, its default, who decides, its status
  COMPATIBILITY.json                          the pinned compatibility set (section 3.13)
  subject-map.json                            website route ↔ agents slug ↔ translator subject ↔ branch (appendix B)
  schemas/                                    JSON Schemas generated from the pydantic models; drift-tested
  vectors/                                    golden vectors shared by all three repositories (synthetic data only)
    canonical/ specialist-port/ handshake/ decision-table/ verdict-binding/ chat-contract/
  website/                                    adapter code to vendor into the website (website conventions)
    src/verify/compat.js                      generated pins
    src/verify/canonical-json.js, sha256.js   canonical JSON and crypto.subtle digests (vector-tested)
    src/verify/translator-client.js           outbound client following fastino.js conventions; http and binding transports
    src/verify/specialist-port.js             wraps the frozen SpecialistTurnResult (section 3.4)
    src/verify/router-port.js                 website route or agents RoutingResult → plan; never fans out
    src/verify/subject-map.js                 generated from subject-map.json
    src/verify/decision-table.js              section 3.8; the same vectors as the service
    src/verify/verified-orchestrator.js       orchestrator.handle: specialist → checks → decide → compose
    src/verify/release-gate.js                thin gate for turn.js (bindings, re-derivation, closed codes)
    public/chat-checks.js                     page labels from closed statuses (textContent only)
    tests/verify-*.test.js                    node:test files with flat names (the website runs tests/*.test.js)
    PATCH-PLAN.md                             section 6.1
  agents/
    PATCH-PLAN.md                             section 6.2 (the agents-side adapter is written in that repository; D20)
  sim/                                        local end-to-end simulation through the website path
    corpus/synthetic/                         simulated users, questions, answers, recorded translations, expected outcomes (labelled synthetic)
    run_sim.py                                starts the service on loopback with ephemeral test keys and the fixture provider, runs both drivers, compares, gates
    website-driver.mjs                        run against a website checkout: in-process handleChat, node:sqlite D1, loopback-only fetch
    agents-driver.mjs                         runtime → port → service, without the website (STEM and combined cases)
    equivalence.py                            reference in-process RouterHub(auditor) against the integrated path
    tamper_web.py                             website-path tampering cases W-T1 to W-T8
    README.md
  readiness/
    locate.sh                                 finds the four repositories by marker files; prints paths, branches, HEADs
    check.py                                  translator and service readiness (read-only; exit 1 on blockers)
    check-website.mjs, check-agents.mjs       run against those checkouts (read-only)
  overseer-port/
    CONFORMANCE.md                            what a sidecar must reproduce; how the suite runs
  deploy/container/
    Dockerfile, entrypoint.sh, README.md      PROPOSED; built and deployed only on the owner's go-ahead; no secrets
  rollback/ROLLBACK.md                        section 8; prints commands, runs nothing
src/epinoic_logic/integration/                installed package: the service side of the protocol
  __init__.py, protocol.py (pydantic models, extra="forbid", frozen), canonical.py, errors.py (KIT-* codes)
  capabilities.py, selftest.py, handshake.py, compat.py (generated)
  turn.py (TurnChecker: hub, auditor, verifier, budget, prefetch), verifier.py (provider factory: fixture | anthropic | openai_compatible)
  delivery.py (decision table, delivery rule, verdict signing), overseer_port.py (embedded adapter; sidecar client stub)
  combinator_port.py, subject_map.py, README.md
src/epinoic_logic/service/app.py              + GET /v1/capabilities, POST /v1/turns/check (integration profiles only); existing routes unchanged
src/epinoic_logic/service/settings.py         + profile, environment label, provider choice, budgets, overseer secret, verdict key (names only, fail closed)
tests/integration/                            pytest: models, canonical vectors, handshake refusals (one per KIT-HS code), self-test,
                                              turn checks per mode, decision-table vectors, delivery rule, prefetch non-interference,
                                              overseer-port conformance (embedded), service routes, equivalence on the synthetic corpus
docs/integration-contract.md                  + section "Integration protocol" (contract 0.4); component versions unchanged
README.md                                     + one line pointing to integration/README.md
```

**Conventions for each target.**
- **Website adapter.**
  - Plain ES modules, with Worker code in `src/`, browser code in `public/`, and tests in `tests/*.test.js` (`node:test`, `node:assert/strict`).
  - No new dependencies.
  - Only `crypto.subtle`, `TextEncoder`, `AbortController` and `fetch`, with frozen constants and closed failure codes.
  - An injectable `fetchImpl`, and log objects of labels only.
  - A header comment that states the invariants.
- **Agents-side code**, written in that repository, follows its portability rule: only `globalThis.crypto.subtle`, `TextEncoder`/`TextDecoder`, `atob`/`btoa` and `AbortSignal`, checked by its `check:portable` tool.
- **Python.** Version 3.11 or later; pydantic models with `extra="forbid"`; nothing raises at a boundary; logs carry metadata only.
- **Licensing.** No NL2FOL code or prompt text anywhere.

---

## 5. Playbook for a fresh session (repository-bound: `integration/PLAYBOOK.md`)

> You are a fresh assistant session. You have four repositories and nothing else: the
> translator (Z3 engine), the Z3 source mirror, the website, and the agents repository. This
> playbook is reference material. It does not authorize edits, pushes, deploys, migrations,
> secrets or paid calls in any repository. Only the owner's own messages in your conversation
> authorize work. Each repository's own rules (`AGENTS.md`, `CLAUDE.md`) take precedence over this
> playbook: if a step conflicts with them, stop and report. Each step lists **Do**, **Expect**,
> **Proof** and **Stop if**. Never skip a gate.

**Step 0. Rules you keep throughout.**
- **Never:**
  - `git push`, merging, or changing a default branch;
  - `wrangler deploy` without `--dry-run`, or `wrangler secret`, `versions secret` or `--secrets-file`;
  - `wrangler d1` against a remote database, `d1 create`, or `wrangler dev --remote`;
  - calling a model provider;
  - reading secret values (names only), or editing synced `sources/`;
  - bare `git stash`;
  - deleting or weakening a test.
- **Work** in new local branches and worktrees that you create. Preserve uncommitted work you find. Commit locally, once per step, so the owner can review and revert each step.
- **Report evidence** as inspected, reproduced or not checked. Never claim a dry run proves a deployment.

**Step 1. Locate the repositories.**
- **Do:** `bash <translator>/integration/readiness/locate.sh`. If you do not yet know where the translator is, run this marker search instead:
  ```
  find / -xdev -maxdepth 6 \( -name EPINOIC_MIRROR_NOTE.md -o -name pyproject.toml -o -name package.json \) \
       -not -path '*/node_modules/*' 2>/dev/null
  ```
  Then keep:
  - the `pyproject.toml` whose `name = "epinoic-logic"` (translator);
  - the directory holding `EPINOIC_MIRROR_NOTE.md` (Z3 mirror);
  - the `package.json` whose `"name": "epinoic-ai-website"` (website);
  - `specialist-runtime/package.json` with `"name": "@epinoic/specialist-runtime"` (agents; use its parent).
- **Expect:** exactly one git top-level checkout per repository. A worktree under `.worktrees/` or a scratch copy does not count.
- **Proof:** record each path, branch, `git rev-parse HEAD` and `git status --short`.
- **Stop if:** a repository is missing, or two candidates remain after excluding worktrees. Ask the owner which one to use.

**Step 2. Read, in this order.**
- **Translator:** `CLAUDE.md`, `docs/context-pack/00_PROJECT_CONTEXT_AND_ARCHITECTURE.md`, `README.md`, `docs/AUDIT.md` (§4-5), `docs/integration-contract.md`, then `integration/README.md`, `PROTOCOL.md` and `DECISIONS.md`.
  - `CLAUDE.md` names `docs/DESIGN.md` and `docs/STATUS.md`. At the time of writing they exist on no branch: record "absent" and continue. Do not create them.
- **Website:** `AGENTS.md`, `README.md`, `docs/current-state.md`, `docs/architecture.md`, and `docs/handoff/05-integration-planning-brief.md` §7-9.
- **Agents:** `README.md`, `docs/STATUS-AND-ACCESS.md`, `docs/DEPLOYMENT-READINESS.md`, `specialist-runtime/README.md`, `docs/handoff/website-specialist-integration.md`, `specialist-routing/README.md`.
- **Expect:** you can state each repository's test command, its deploy triggers, and what it says about Z3.
- **Stop if:** `integration/` is absent from the translator checkout. The kit is not on this branch: ask the owner which branch carries it.

**Step 3. Gate G0: is the website's Z3 deferral lifted?**
- **Do:**
  ```
  grep -n "Z3 remains deferred" docs/current-state.md
  grep -n "Z3 logic translator is \*\*deferred\*\*" docs/architecture.md
  grep -n "Website Z3 integration stays deferred" docs/handoff/05-integration-planning-brief.md
  head -3 docs/handoff/04-logic-translator.md | grep -n "Deferred by Bruno"
  ```
  All four run in the website checkout. Alternatively, run `node <translator>/integration/readiness/check-website.mjs <website>`.
- **Expect:** no match. A match means the deferral is still in force.
- **If it is in force:**
  - Steps 4 to 7 (translator and agents, read-only) and the simulation in step 13 may still run in scratch worktrees.
  - Website changes may be prepared only as a local branch for review, and only if the owner asks you to in your own conversation.
  - Report "blocked by G0" and offer the docs change W0 (section 6.1) as a draft for Bruno.
  - Never merge or push it.

**Step 4. Gate G1: the translator base.**
- **Do:**
  - `grep -n "Contract version:\*\* 0\." docs/integration-contract.md`, which must show 0.3 or later;
  - `test -f src/epinoic_logic/overseer/__init__.py`;
  - `grep -n "computer_science" src/epinoic_logic/branches/registry.py`;
  - `cat integration/COMPATIBILITY.json`.
- **Expect:** contract ≥ 0.3, the overseer package present, the STEM branches present.
- **Stop if:** any is missing. The kit then reports `KIT-HS-006`, `KIT-HS-007` or `KIT-HS-005`, and only the owner can supply the right base branch.

**Step 5. Translator environment and suite.**
- **Do:**
  ```
  python3 -m venv <scratch>/venv
  <scratch>/venv/bin/pip install -e "<translator>[dev,service,providers]"
  ```
  Then, from the translator root: `python -m pytest -q`, followed by `python integration/readiness/check.py --translator .`.
- **Expect:** every test passes (record the counts) and the translator section of the readiness check passes.
- **Stop if:** the install needs a network you do not have, or any test fails. Report it; never edit tests or code to make them pass.

**Step 6. Service handshake on loopback.**
- **Do:** `python integration/readiness/check.py --start-service --profile integration-sim`. It generates ephemeral test keys under a scratch directory, starts `epinoic-logic serve --host 127.0.0.1` on a free port, requests `/v1/capabilities` and stops the service. Then run `python -m pytest -q tests/integration/test_handshake.py`.
- **Expect:**
  - `selftest.passed`;
  - modes include `single`;
  - STEM branches listed;
  - `overseer.mode = embedded`;
  - `translation.provider = fixture`;
  - one refusal test per `KIT-HS` code passes.
- **Stop if:** the service refuses to start. Report the `KIT-HS` line it printed.

**Step 7. Agents repository, unchanged parts.**
- **Do:**
  ```
  (cd specialist-runtime && npm test && npm run check:portable)
  (cd specialist-routing && npm test && npm run evaluate && npm run check:portable)
  node tools/cross-check.mjs
  node <translator>/integration/readiness/check-agents.mjs .
  ```
- **Expect:**
  - 117 runtime tests and 175 router tests pass, or the counts the repository's README states now;
  - `claims: null` is still pinned;
  - the runtime and routing contract versions are in `COMPATIBILITY.json`.
- **Note:** `node tools/readiness-check.mjs` is expected to exit 1 and report its blockers. Record them; do not "fix" them.

**Step 8. Website scratch worktree and baseline** (only if the owner asked for website work).
- **Do:**
  ```
  git -C <website> worktree add <scratch>/website-kit -b kit/verified-backend
  ```
  Then, in `<scratch>/website-kit`: `./run.sh install --frozen-lockfile`, `./run.sh test`, `./run.sh check`, `./run.sh check:staging`.
- **Expect:** the baseline passes. Tests that need the Playwright devDependency or browsers may fail only for that reason; record them as not run.
- **Stop if:** any other baseline failure appears. It is not yours to fix.

**Step 9. Apply W1, the contract reader (section 6.1).**
- **Do:** apply the patch outline. Locate each insertion by its anchor, never by line number:
  - `export const REVIEW_STATES` and `const RESULT_FIELDS` in `public/chat-contract.js`;
  - `function reply(resultJson)` in `src/chat/history.js`;
  - `const ERRORS = Object.freeze({` in `src/chat/contract.js`;
  - `const ERROR_COPY` in `public/chat-logic.js`.

  Copy `integration/vectors/chat-contract/` to `tests/fixtures/kit/` and add the W1 test files.
- **Proof:** `./run.sh test`: all old tests pass unchanged, and the new contract tests pass, including "an old stored row without `checks` still replays".
- **Stop if:** an anchor is not found exactly once.

**Step 10. Apply W2 (the client) and W3 (the orchestrator and gate).**
- **Do:**
  - Copy `integration/website/src/verify/*.js` to `src/verify/` and `public/chat-checks.js` to `public/`.
  - Patch these anchors:
    - `export function chatBackendMode(` and `const orchestrator = options.orchestrator ?? createMockOrchestrator();` in `src/chat/handler.js`;
    - `const outcome = await orchestrator.handle(`, `// 3. Never store or release a malformed, foreign or mis-routed result.` and `simulated: true` in `src/chat/turn.js`;
    - `readAttempt:` in `src/state/sql.js`, with a new store method `attemptPending`.
  - Add the `tests/verify-*.test.js` files.
- **Proof:** `./run.sh test` is green. Then check that:
  - `tests/verify-gate.test.js` refuses each tampered verdict;
  - the decision-table vectors give 100% agreement;
  - the verified backend refuses to run without `CHAT_STATE=d1`;
  - statements per request stay at 36 or fewer, measured.
- **Stop if:** the statement budget is exceeded. Report it; do not raise the pin (that is the owner's decision).

**Step 11. Apply W4, configuration and pins.**
- **Do:**
  - Add `TRANSLATOR_MODE: "none"` and `TRANSLATOR_BASE_URL: ""` to all three var blocks in `wrangler.jsonc`.
  - Add the new pin tests to a new test file. Do not edit the existing tests.
  - Add the names-only lines to `.dev.vars.example`.
  - Update `docs/current-state.md` and `docs/architecture.md` to say "planned, local only".
- **Proof:** `./run.sh test`, `./run.sh check` and `./run.sh check:staging` all pass. The staging and production vars stay inert.

**Step 12. Apply W6, the logging pin.**
- **Do:** add the `chat_check` event and its pinned key-set test.
- **Proof:** the suite is green, and the logs contain no message, claim or answer text (the test greps for the strings).

**Step 13. Run the simulation.**
- **Do:** `python <translator>/integration/sim/run_sim.py --website <scratch>/website-kit --agents <agents> --out <scratch>/sim-out`. Add `--rounds <dir>` only if the owner gives you recorded rounds; the script copies them first.
- **Expect:** `<scratch>/sim-out/summary.md` with every gate PASS: G-EQ, G-INV, G-HON, G-DEL, G-TAMPER and G-OVS (section 7.5). `results.json` holds the denominators.
- **Proof:** exit status 0. Network use was loopback only; the drivers' fetch refuses any other host.
- **Stop if:** any gate fails. Report the failing cases from `results.json`. Never change a gate or a vector.

**Step 14. Agents changes** (only with the owner's go-ahead, and after decision D20).
- **Do:** apply A1 to A4 from section 6.2 on a new local branch.
- **Proof:** the runtime and router suites are unchanged and green, and the new port tests pass.

**Step 15. Readiness.**
- **Do:** `python <translator>/integration/readiness/check.py --all --website <scratch>/website-kit --agents <agents>`.
- **Expect:** a PASS/BLOCKER table and "Integration ready (local): YES/NO" and "Live ready: NO". The live prerequisites are owner actions: hosting, secrets, approved caps and model, data terms, the History gate rules and bundle pins.

**Step 16. Report, then stop.** Report, for each repository:
- the branch, the local commits and the files changed;
- the commands run, with their counts;
- the simulation gate table;
- the readiness blockers;
- the decisions from `DECISIONS.md` that are still open.

Offer the owner the local branches for review and the W0 docs draft for Bruno. Do not push.

---

## 6. Minimal change plans (patch outlines, file by file)

### 6.1 Website

Milestone M1 (local simulation green) needs W0 to W4 and W6. Milestone M2 (staging pilot) adds W5,
the hosting and the owner's actions. W7 and W8 wait for their decisions.

- **W0. Docs** (only Bruno decides; a draft may be prepared):
  - `docs/current-state.md`: record the 17 Oct decision; replace "Z3 remains deferred" at `:11` and the "Deferred" bullet at `:19`.
  - `docs/architecture.md:59`: replace the deferral paragraph with a short description of the verified backend.
  - The notices at the top of `docs/drafts/chat-architecture-design.md` and `docs/handoff/04-logic-translator.md`: mark them superseded by protocol `epinoic.integration.v1` (a named translator commit) and keep them as reference.
  - `docs/handoff/05-integration-planning-brief.md` §9, invariant 25: replace it with "Every released answer requires the checks port; integration follows `epinoic.integration.v1`." Add pointers to the decisions in §10.
- **W1. Contract reader** (additive; it **ships before any writer**):
  - `public/chat-contract.js`:
    - add `CHECK_STATUSES` (13 plus `NOT_ATTEMPTED`), `FIDELITY_STATES`, `CHECK_SUMMARIES`, `SCOPE_STATEMENT` (verbatim) and `CHECK_LIMITS {maxChecks: 12, maxClaimChars: 200}`;
    - add the optional `checks` and `checksSummary` to `RESULT_FIELDS.answer` and to `REPLY_FIELDS.answer`;
    - `chatResultProblem` validates them: both present or both absent, closed enums, bounds.
  - `src/chat/history.js` `reply()`: copy both fields when they are present.
  - `public/chat.js`, plus the new `public/chat-checks.js`: render the labels of section 3.8 with `textContent`, and show the scope statement once. When `checksSummary` is present, the badge reads "Checked automatically" (copy to be decided, D13) instead of "Reviewed".
  - `public/chat-logic.js` `ERROR_COPY`: add entries for the two new codes.
  - `src/chat/contract.js` `ERRORS`: add `review_unresolved: [422, false, …]` and `checks_incomplete: [503, true, …]`.
  - New `tests/checks-contract.test.js` and `tests/fixtures/kit/` vectors.
- **W2. Outbound client:** `src/verify/translator-client.js`, `canonical-json.js`, `sha256.js`, `compat.js` and `subject-map.js`, and a new `tests/verify-client.test.js`. It covers, with a fake `fetchImpl`: 200, 3xx closed, 401, 429 with `Retry-After` capped at 3600, 503 E504, a timeout, an abort, an oversized body, a malformed body, and a binding mismatch.
- **W3. Orchestrator and gate:**
  - New `src/verify/specialist-port.js`, `router-port.js`, `decision-table.js`, `verified-orchestrator.js` and `release-gate.js`.
  - `src/chat/handler.js`:
    - `chatBackendMode` returns `verified` only when `CHAT_BACKEND=verified`, `chatStateMode === "d1"`, and the host is loopback development or protected staging with verified access. So the stateless path can never run the verified backend.
    - The handler builds the verified backend from `env` and `fetchImpl`.
    - `verification.ready()` runs before admission.
    - It sends the headers `X-Chat-Backend: verified` and `X-Chat-Simulated: 1|0`.
  - `src/chat/turn.js`:
    - add `turn: {turnId, attemptId}`, `stillPending` and `log` to the orchestrator's context;
    - a verified orchestrator's error results must come from `ERROR_CODES`;
    - after the existing gate, add `releaseGateProblem(outcome, result, admitted)`, which turns any problem into `upstream_invalid`;
    - pass `simulated: outcome.kit?.simulated ?? true`;
    - `outcome.kit` is never stored or returned.
  - `src/state/store.js` and `src/state/sql.js`: add `attemptPending(principal, admitted)`, one owner-scoped statement reusing `SQL.readAttempt`.
  - New tests: `tests/verify-orchestrator.test.js`, `verify-gate.test.js`, `verify-vectors.test.js`.
  - Vendoring the agents runtime and bundle (the agents repository's website-01 plan) is an M2 step. In M1, the specialist is injected.
- **W4. Configuration and pins:**
  - `wrangler.jsonc`: add `TRANSLATOR_MODE: "none"` and `TRANSLATOR_BASE_URL: ""` to all three blocks.
  - A new `tests/verify-release.test.js`, which pins that:
    - `verified` requires `CHAT_STATE=d1`, a mode other than `none`, and an environment other than production;
    - modes are limited to `none`, `http` and `binding`;
    - URLs are https, or http only on loopback;
    - no `TRANSLATOR` token appears in any vars block;
    - **no hosted environment may serve real specialist answers through any backend other than `verified`** (Z3 is not optional).
  - `.dev.vars.example`: names only.
  - `src/disclosure.js`: verified-mode anchors, failing closed, for M2, with tests.
- **W5. Usage and caps** (before any real provider call):
  - `migrations/0003_usage_verified.sql`: `ALTER TABLE usage_daily ADD COLUMN specialist_calls INTEGER NOT NULL DEFAULT 0 CHECK (specialist_calls >= 0)` and `… checks_calls …`.
  - Pin it by SHA in `tests/migrations.test.js`. The table list does not change.
  - `src/state/limits.js`: `CAPS.verified`, as unapproved proposals.
  - `src/state/sql.js`: `capsOk` and `charge` reserve at admission, within the 36-statement pin.
- **W6. Logs:** the `chat_check` event, with a pinned key-set test.
- **W7. A STEM subject** (decision D9): a third route needs either a table rebuild, which the current pins forbid, or an additive-column scheme, plus changes to `SPECIALIST_IDS`, the router and the UI. It is not part of M1. The service already checks STEM, and the agents driver exercises it.
- **W8. Twofold modes on the website** (decision D19): a contract field for two contributing specialists, a consent step after `clarify/mixed_request`, and UI.

### 6.2 Agents

- **A0.** `specialist-runtime/` and `specialist-routing/`: **no change**. The runtime keeps its 117 tests and the router its 175. `claims: null` stays, and so do its five pinning tests.
- **A1. Docs:**
  - `docs/related-projects/logic-translator-nl2fol.md`: Z3 is required on the website path; the layer wraps the runtime result in an outer envelope; `claims` stays `null` by design; add the port's name and version.
  - `README.md`: reword the line "No Z3, claim extraction or formal-check badges": the runtime stays free of Z3, and the required checks run outside it.
  - `docs/DEPLOYMENT-READINESS.md`: reword the claims row to "by design".
- **A2. `integration/checks-port/` (new; written fresh in this repository, subject to D20):**
  - `package.json`;
  - `src/envelope.js`, which validates the result's schema and contract, `outcome === "answer"`, and computes the digests;
  - `test/envelope.test.js`, which uses `createOfflineTestRuntime` with the synthetic bundle, wraps an unchanged frozen result, and checks the refusals for every non-answer outcome;
  - `vectors/` (synthetic data);
  - its own `check:portable`.
- **A3. `integration/z3/check_answer.py`:**
  - replace the reads of `hub.channels[...].transmitted_reports` with the public view or verdict API;
  - forward the signed reply's id and digest;
  - keep the hard-coded key behind an explicit `--simulation` flag (the default), and refuse to run otherwise;
  - optionally add `--service URL` to call the local checks port for parity.
- **A4. `tools/readiness-check.mjs`:** add rows for the kit's compatibility. They read a `KIT_COMPATIBILITY` path, and the existing blockers stay.
- **A5.** Decision D18: integrated runs treat the simulation's Z3 adjudicator as advisory, so it can no longer remove a blocker. This needs a flag and documentation.

### 6.3 Translator (the later step that builds the kit)

- **T1. Base.** Create an `integration-kit` branch from a base that carries the overseer package (`overseer-build`, with its staged merge committed by its owner), the review fixes of `22d6a5b`, and contract 0.3 (`0d28eba`). Without that base, build against `0d28eba`, and the overseer port then reports `KIT-HS-007`.
- **T2.** The `src/epinoic_logic/integration/` models, canonical JSON, errors, and compatibility generation.
- **T3.** The service profiles, the settings (fail closed; secrets kept out of `repr`), the self-test and `GET /v1/capabilities`.
- **T4.** `TurnChecker` (the order in section 3.5.2, the budget, the prefetch), the decision table, the delivery rule and verdict signing.
- **T5.** `POST /v1/turns/check`. Existing routes and behaviour do not change. The default profile stays `engine`.
- **T6.** The overseer port's embedded adapter, the conformance suite, and the asynchronous review queue: the pack is loaded through `load_pack` and the `PACK_DIGESTS` check, and the runner is `OverseerAgentRunner`.
- **T7.** The website adapter and its tests (run with Node 22 when it is present; otherwise readiness reports "not run"), and the vectors.
- **T8.** The simulation, the website tampering cases and the readiness scripts.
- **T9.** Docs: `integration/*.md`, the integration contract 0.4, and the README pointer. Engine and policy semantics do not change, so `ENGINE_VERSION` and `POLICY_VERSION` stay as they are.
- **T10.** Publishing: the owner pushes the kit branch to the translator remote that fresh sessions clone (decision D20). Until then, a fresh clone has no kit.

---

## 7. Tests and acceptance criteria

### 7.1 Translator
- `python -m pytest -q` passes, with no test weakened or deleted and the count equal to the previous count plus the new tests. `PYTHONPATH=src:scripts/overseer python -m pytest -q -p pytest_attach` also passes.
- **Handshake:** one test per `KIT-HS` code. Each removes or mismatches exactly one required part (Z3, STEM, named policies, overseer pack, keys, provider, subject map, environment, limits) and expects that code and exit status 2.
- **Self-test:** three fixed problems give their expected statuses and binding digests. A tampered digest fails the self-test.
- **TurnChecker per mode:**
  - single: clean, with warnings, with an error finding, REJECTED;
  - duplicate: identical answers, merged material claims, CONFLICTING;
  - combined: a clean synthesis, an INT-LEDGER error, a bad transformation vocabulary;
  - the budget spent half-way: NOT_ATTEMPTED leading to `refuse_incomplete`;
  - a provider failure: TRANSLATION_FAILED, shown as INTERNAL_ERROR, leading to `refuse_incomplete`.
- **Decision table:** every vector agrees. A property test over all combinations of statuses shows that a non-definitive status never produces `deliver` with the summary `formally_checked`.
- **Prefetch non-interference:** receipts are identical with prefetch on and off.
- **Overseer-port conformance (embedded):** clearances, audits, consolidations and delivery decisions are the same as direct calls to the hub. The tampering suite T1-T22 still names its expected codes.
- **Service routes:** authentication, rate limiting, body size, E505 and concurrency apply unchanged to `/v1/turns/check`. The `engine` profile exposes no new route.

### 7.2 Website (all offline: fake `fetchImpl`, `node:sqlite` D1)
- All existing tests pass **unchanged**, and the new tests pass.
- **Contract:** old rows without `checks` replay and appear in history. New rows validate. Unknown statuses, extra keys, more than 12 entries, a claim over 200 characters, or only one of the two fields present are all refused. A result never exceeds 64 KiB.
- **Gate:** each tampering case is refused with its code:
  - wrong `task_id`;
  - wrong `answer_sha256`;
  - `decision: deliver` alongside a blocking claim (re-derivation mismatch);
  - a scope statement that differs;
  - an answer altered after the check.
- **Flow:**
  - checks refused lead to 422 `review_unresolved`, with nothing stored as an answer;
  - the checks service down leads to 503 `checks_incomplete`, the failed turn is stored with the raw code, and a retry is admitted;
  - a handshake that is not ready leads to 503 `chat_unavailable`, with no turn row and no charge;
  - a cancel before the checks call means no checks call and `turn_cancelled`;
  - a replay makes no service call and returns the stored result unchanged;
  - the deadline is honoured;
  - D1 statements stay at 36 or fewer, measured;
  - the log key sets are pinned and the logs contain no content strings.
- **Pins:** the stateless path never runs `verified`, production is inert, the token is never a var, and the Z3-not-optional pin holds.

### 7.3 Agents
- The runtime's 117 tests, the router's 175, `cross-check`, the handoff `--check` and the knowledge check all pass unchanged. The new port tests pass, and `check:portable` passes.

### 7.4 Cross-repository vectors
- Canonical JSON and digests agree byte for byte between Python and JavaScript.
- Specialist-port, handshake, decision-table, verdict-binding and chat-contract vectors pass on every side that reads them.

### 7.5 Simulation gates (`integration/sim/run_sim.py`)

The corpus is synthetic and labelled as such: at least 24 simulated users with sessions of one to
four turns. It includes:
- History with consistent dates, and History with a planted chronology error;
- an English interpretive answer (not eligible);
- a follow-up (sticky);
- a retry (replay), a cancel, and two concurrent sends;
- the service stopped mid-run, and a service slower than the budget;
- a handshake mismatch;
- a mixed subject (clarify);
- STEM correct and STEM wrong (agents driver);
- duplicate clean and duplicate conflicting;
- combined (agents driver).

| Gate | Pass condition |
|---|---|
| G-EQ | For every case, the integrated path and the reference in-process `RouterHub(auditor)` give identical results (volatile fields excluded) for: receipt status, multisets of finding codes, display statuses, `problem_digest`/`config_digest`/`limits_digest`, clearance states, FINAL audit state, consolidation status and delivery decision. **0 differences.** |
| G-INV | No answer is stored without `deliver`. Replays are unchanged and make no service call. Cancels fence. Every result is at most 64 KiB and every request uses at most 36 statements. Logs carry labels only. Only loopback hosts are fetched. |
| G-HON | Every displayed label is allowed for its status. The scope statement is present whenever a formal status is shown. `simulated` is true for every simulated answer. No non-definitive status is labelled checked. |
| G-DEL | Every delivered answer has a passed FINAL audit and an allowed `delivery_decision`/`release_decision`. Every refusal names its first failing condition. |
| G-TAMPER | Website-path cases W-T1 to W-T8 (a tampered decision, a substituted answer, an old verdict replayed for another attempt, a changed scope statement, an extra field, a forged clearance state, a status shown as success, a stripped signature) are each refused with the expected code. |
| G-OVS | Overseer agents, using probe or recorded replies, are built only from the exported pack. Verdicts are validated. Delivery is identical with and without the asynchronous review (non-interference). |

Latency per stage is reported for information. It is not a gate, and it does not measure capacity.

### 7.6 Dry run of a fresh session on scratch clones (acceptance for "seamless")
1. Make scratch clones of the four repositories, with the translator at the kit commit. No other files, no notes and no conversation history are present.
2. Start a fresh session. Give it only the owner's instruction "integrate the Z3 kit following `integration/PLAYBOOK.md`" and the owner's go-ahead for local website and agents branches.
3. Acceptance:
   - (a) the session reaches step 16;
   - (b) the simulation exits 0 with every gate PASS;
   - (c) the report names the open blockers and decisions correctly;
   - (d) a transcript audit finds **no** `git push`, `wrangler deploy` without `--dry-run`, `wrangler secret`, `--remote`, `d1 create`, provider host, read of `.dev.vars` values, or test deletion or weakening;
   - (e) every change sits on a local branch it created.
4. **Negative dry runs**, each of which must stop at the right gate with the right name:
   - a translator branch without contract 0.3 stops at step 4 with `KIT-HS-006`;
   - the website deferral still present gives "blocked by G0", with patches only on request;
   - Z3 removed from the venv gives `KIT-HS-003`;
   - an anchor renamed in `turn.js` stops at step 10 with "anchor not found".

### 7.7 Rollback rehearsal
- With W1 only (the reader) applied to a database holding rows written by W3, replay and history still work.
- Removing W3 (the writer) leaves every stored row valid.
- The service rolled back to an incompatible version leads to `chat_unavailable` before admission, never to unchecked answers.

---

## 8. Rollback (`integration/rollback/ROLLBACK.md`)

- **Website:**
  1. Set `CHAT_BACKEND` back to `mock` (staging) through a reviewed PR. A merge deploys staging.
  2. Revert the writer (W3) if needed. Keep the reader (W1) for good once any row with `checks` exists. Removing it would make those replays fail with 500.
  3. Migration 0003 stays, being additive; its columns become unused.
  4. Bruno removes `TRANSLATOR_SERVICE_TOKEN` with `wrangler secret delete`, on his own go-ahead. Removing it deploys.
- **Service:** redeploy the previous image tag. If its versions fall outside the Worker's compatibility set, the Worker fails closed (`chat_unavailable`).
- **Agents:** nothing to roll back in the runtime or router. Revert the docs, port and test PRs if needed.
- **The kit itself:** delete the `integration-kit` branch. The engine and the existing routes never changed, because the default profile is `engine`.

---

## 9. Risks

1. **The deferral blocks the website.** Until Bruno records the decision, a fresh session must follow the website's deferral. The kit cannot lift it.
2. **The kit is unreachable.** The required translator commits (`0d28eba`, `ef4ba9f` with its uncommitted staged merge) are on no remote. Two translator remotes exist (origin, and the Bruno-ios mirror), and the canonical one is unstated.
3. **The overseer branch is unfinished.** Its staged merge is uncommitted, and the branch lacks `22d6a5b` and `0d28eba`. A wrong merge base would change the engine's build identity, and the equivalence gate would then catch differences.
4. **The time budget may not hold.** Real specialist outputs (the agents repository proposes up to 32,000 tokens) and live cheapest-tier translation have never been measured. They may not fit 132 s. The 30 s `waitUntil` window after a disconnect can waste checks already paid for.
5. **Fail-closed may refuse too often.** Under the default `fail` policy, every outage of the checks service or the provider becomes a 503 for students. False COUNTEREXAMPLE results from weak encodings (W110/W111 advisory cases) would show as 422 refusals.
6. **Labels may never reach "formally checked".** Without a fidelity reviewer, `release_permitted` is always false.
7. **The cheapest tier is untested live.** The provider sends `temperature: 0`. The agents repository notes, without having tested it, that non-default sampling parameters may be rejected by newer models. No live provider call is evidenced anywhere.
8. **HMAC limits who can verify.** Verifying a signature requires the secret, so the Worker cannot verify the verdict, and the overseer (or a sidecar) must hold the engine secret. TR5 limits its use but cannot prevent misuse by an insider (the T11 case).
9. **Capacity is low.** One bearer token per process means one deployment per environment, with 60 calls per minute and 4 slots per process by default, and limiters that do not span replicas.
10. **The contract rollout has an order.** If a writer ships before the reader, or the reader is rolled back after rows with `checks` exist, replays and history fail with 500.
11. **The D1 budget is tight.** The pin of 36 statements and the 64 KiB result cap leave little room. A STEM subject needs a table rebuild that the pins forbid.
12. **There is no History answer yet.** Three gate rules are pending and the bundle pins are unverified. A real History answer cannot pass the runtime today, so staging stays mock until the agents-side blockers clear.
13. **Repository visibility.** The agents repository and the translator repository are public while the translator's licence says confidential. Copying kit material into the public agents repository needs an owner decision.
14. **Two owners.** `specialist-runtime/` and `specialist-routing/` may also exist in the private Agent-Training repository.
15. **Data protection.** Student text and answers leave the Worker for the verification host and the provider, and the retention terms are undecided. The delete copy ("recovery copies up to 30 days") may become incomplete.
16. **Overseer agents are slow.** At 30-90 s per instance, unmeasured, they must stay asynchronous. Their findings arrive after delivery, and there is no product process for them yet.
17. **Recorded rounds may be missing.** They are not in the repository, so G-EQ on recorded material runs only when the owner supplies them. The synthetic corpus is always available.
18. **Anchors and docs drift.** Line numbers in existing reports are already stale (section 1), and `CLAUDE.md` names files that do not exist.
19. **Cloudflare facts may be stale.** The limits and the Container binding mechanics come from documentation sources (developers.cloudflare.com was blocked in earlier sessions) and must be re-checked before M2.
20. **The translator has known defects.** It records four expected-failure (xfail) defects, and its arena never reached its 0.98 lens target. The checks are useful, not complete.

---

## 10. Decisions for the founder (seeds `integration/DECISIONS.md`)

Each decision states the default the kit implements until the founder decides. Every default
fails closed. None of them is decided here.

| # | Decision | Kit default until decided |
|---|---|---|
| D1 | Record "Z3 is required" in the website repository: lift the 12 Oct deferral, invariant 25 and the two notices. **Bruno decides.** | Website work stays as local drafts |
| D2 | When checks cannot complete for a material eligible claim: refuse (503 `checks_incomplete`) or release qualified, labelled "check unavailable" | Refuse (`verified-v1`) |
| D3 | Do COUNTEREXAMPLE, INCONSISTENT_PREMISES and UNSATISFIABLE on a material claim block the answer, including COUNTEREXAMPLE with only advisory W110/W111? | Block |
| D4 | AMBIGUOUS_TRANSLATION on a material claim: qualify, block, or a clarification written by the website | Qualify, labelled |
| D5 | One bounded revision, or none | None |
| D6 | Wire a cheapest-tier fidelity reviewer. Without one, nothing can be labelled "formally checked"; it costs one more call per translated claim. | Not wired (`formal_only` at best) |
| D7 | Hosting: a Container behind a binding, or external HTTPS; who operates it; per-environment deployments and tokens; capacity (rate, slots, instances) | External HTTPS for M2; no deployment until approved |
| D8 | Who extracts claims | The translator's branch parsers in the service. Specialists keep `claims: null`; the website never extracts. |
| D9 / D10 | Mapping subjects to slugs. Which specialist `english` means. STEM subjects on the website (table rebuild and pin change). | History only. `english` refused under `verified` until decided. STEM service-only. |
| D11 | Mapping ids: `task_id` = turnId, `request_id` = attemptId | As stated |
| D12 | Signing the verdict: HMAC plus an authenticated channel plus Worker binding checks, or Ed25519 (a new dependency; the Worker verifies with a public key) | HMAC |
| D13 | Display: `checks` and `checksSummary`, label copy, the meaning of `review: "passed"` under `verified`, disclosure copy, `simulated` semantics | Section 3.8 proposals; simulated unless both parts are live |
| D14 | Budgets and caps for specialist calls, checks calls and provider calls, and who approves them | No caps approved, so no live calls |
| D15 | Data terms and retention for the verification host and provider; retention of the evidence bundle | Nothing retained; synthetic text only |
| D16 | Delivery: synchronous within 180 s, or asynchronous (needed for revisions, reviewers, combined mode at scale, or a longer budget) | Synchronous, with the stage ceilings |
| D17 | Delivery-rule parameters seen in the brief but in no repository: "a four-minute budget", "overseer selection above 90%", "never labelled checked". Confirm or replace them. | A budget bounded by 180 s; no selection threshold; "an answer whose required checks did not complete is never labelled checked" always on |
| D18 | The overseer: embedded for v1; when a sidecar may replace it; agents asynchronous and advisory; removing the simulation adjudicator's power to clear formal errors | Embedded, asynchronous, power removed |
| D19 | Twofold modes: which routes use duplicate (cost ×2); combined mode's contract and router path (above the router, after `clarify/mixed_request` and explicit consent, or a routing contract v0.2.0) | Single only on the website; duplicate and combined in the simulation only |
| D20 | Repositories: the translator base commit and the remote that carries the kit; the canonical agents repository; making it private; the licence for kit material that goes into a public repository | No kit material copied into the public agents repository |
| D21 | `verified` as the only real-answer backend on hosted environments (no specialist backend without checks) | Pinned |
| D22 | What happens to overseer-agent findings after delivery (a human review queue, notification) | Recorded only |
| D23 | Approving model identifiers from `model-assignment.json` for the specialist tier and the cheapest tier (translation, combinator, overseer agents) | None approved |
| D24 | Conversation context for follow-ups (`priorTurns`), and where it is stored under KEEP and hard delete | Website 01 decides; the kit is unaffected |

---

## Appendix A. Statements carried verbatim

- **Engine scope statement** (`engine/statuses.py`): "This result concerns only the formal encoding it is bound to, under the encoded premises and the stated solver configuration. It does not establish that the premises are factually true, that the natural-language claim was translated faithfully, or that any interpretive judgement is correct. Grounding and semantic-fidelity information is reported separately and is advisory."
- **Audit scope sentence** (overseer TR6): "This audit covers only the transfers journaled since the auditor was attached to the channel. It shows whether the recorded transfers, receipts and signed results agree with each other and with this repository's rules. It does not show that any claim is true or any reading correct."
- **Specialist gate disclaimer** (runtime): "Deterministic format and policy heuristics. Not factual, academic or formal verification."

## Appendix B. Subject map draft (`integration/subject-map.json`, version 2026-10-17.1)

| Website route | Agents slug | Translator subject | Branch | Status |
|---|---|---|---|---|
| `history` | `history` | History | history | pilot |
| `english` | D10: `english-a-literature`, `english-a-lang-lit` or `english-specialist` | English A: Literature, or English A: Language and Literature | english | decision pending |
| none (W7) | `physics`, `chemistry`, `biology`, `ess` | Physics, Chemistry, Biology, Environmental Systems and Societies | sciences | service only; the slugs are provisional |
| none (W7) | `mathematics-aa`, `mathematics-ai` | Mathematics: Analysis and Approaches, Mathematics: Applications and Interpretation | mathematics | service only |
| none (W7) | `computer-science` | Computer Science | computer_science | service only; provisional |
| none | `economics`, `business-management`, `psychology` | Economics, Business Management, Psychology | economics, business_management, psychology | service only; provisional |
| none | `geography`, `spanish-b` (alias `language-b-spanish`) | Geography, Language B: Spanish | generic | service only; provisional |

A kit test asserts that every row's branch equals `RouterHub.branch_for(subject)`. The subject
names are the agents repository's `check_answer.py` mapping.

## Appendix C. What the fresh session's report contains

- For each repository: the path, branch, HEAD, the local commits created and the files changed.
- Gates G0 and G1: their state, and the evidence behind it.
- The commands run, with their pass and fail counts. Anything not run, and why.
- The simulation gate table, with its denominators and the failing case ids, if any.
- The readiness table (local and live).
- The decisions still open (D1 to D24), and the owner actions needed for M2.
