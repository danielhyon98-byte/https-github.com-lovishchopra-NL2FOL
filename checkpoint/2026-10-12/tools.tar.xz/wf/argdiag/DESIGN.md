# Named diagnostics and the end-to-end false errors: design

Base: `22d6a5b5cbeac15306b0e45af29e504ff5e4ec1c` ("Fix the external review findings"): engine 0.4.0, policy
2026.10-v4, translator 0.4.0, IR 1.0, integration contract 0.2. Nothing here is implemented. The main checkout was
read only through `git show`, `git diff` and `git log`. All experiments ran in this folder:

| Probe | What it is |
| --- | --- |
| `design_probes/merged/` | A scratch clone. It holds 22d6a5b merged with `review-stem-checks` (50611e6) and `review-stem-channel` (eb66038), as commit da9cef4. Both branches start at 83e97e9, not at 22d6a5b. The only textual conflict was `docs/STEM_DESIGN.md`: both branches add a section 21, and the second is renumbered 22. |
| `runs/merged_review.json` | The dev corpus run on that merged tree. |
| `runs/merged_full_suite.txt` | The full suite on that merged tree (0.1). |
| `p1_issue1.py` | Label-only circularity and Bool task settings (0.2). |
| `p2_r0_prototype.py` | The issue-2 re-check and its structural rules, run on the translator's real grounded problems. Output in `runs/p2_r0_prototype*.txt` and `runs/p2_r0_b8.txt`. |
| `p3_security.py` | The security re-checks, with output in `runs/p3_security.txt`. |
| `p4b_report_rules.py` | The three report-level rules of A.3, run on the merged run records. Output in `runs/p4b_report_rules.txt`. |
| `p5_review_merge.py` | The finding behind the merged-tree review test failures (0.1). |

The holdout corpus was not read.

**Scope statement**, kept everywhere: every result and every diagnostic below proves a property of the encoding and
of this code only. It never shows that a premise is true, that a translation is faithful, or that an interpretation is
correct. No live provider was called. Nothing is deployed.

**Case names.** Cases are named by their dev corpus ids. Where two ids share a prefix, a short form is used:

| Short form | Corpus id |
| --- | --- |
| c01-mp | c01_modus_ponens |
| c01-econ | c01_control_econ_table |
| c01b-econ | c01b_control_econ_table_short_excerpts |
| c02-mt | c02_modus_tollens |
| c02-hist | c02_control_history_quotes |
| c03-dich | c03_true_dichotomy |
| c03-psych | c03_control_psych_study |
| c04-quote | c04_quoted_transcription |
| c04-eng | c04_control_english_quote |
| c05-chem | c05_consistent_chemistry |
| c06-givens | c06_consistent_givens_stem |

Every other id is unique by its prefix (f01, e04a, i02c, s03dk, e2e-B8-ps and so on).

**Repository hygiene for the fixers.** Repository code, docs and tests never name a model, a session or a scratch path,
and never copy code or prompt text from NL2FOL or any other project. The dev cases go into the repository as data
(A.9). The holdout never does.

---

## 0. What was re-checked on 22d6a5b, and the decisions that follow

### 0.1 Baseline, the review branches, and the merge

| Tree | named | caught, unnamed | missed | false alarms | controls clean |
| --- | --- | --- | --- | --- | --- |
| 22d6a5b (given baseline) | 9 | 25 | 10 | 41 | 16 |
| 22d6a5b + both STEM review branches | 9 | 26 | 9 | 40 | 17 |

The review branches move exactly two cases:

- `s03dk_control_symbolic_bindings`: false alarm to clean.
- `s03d_unit_symbolic_bindings`: missed to caught. It is named `stem_arithmetic_slip`, not `stem_unit_error`.

Both changes come from review fix 2, which reads a symbol's binding units in substitutions. The branches also add
INT-HIST-001 (relay history). It re-carries a report's unresolved warning and error findings onto later receipts, so it
disappears wherever the underlying false alarm is fixed.

**The merge is textually clean but not semantically clean.** On the merged tree, 8 tests of
`tests/stem/test_review_stem_checks.py` fail:

- S2 exactness: 3 tests;
- S5 root sets: 4 tests;
- S7 absolute value: 1 test.

On `review-stem-checks` alone the same file passes 76/76. The other four review test files pass on the merged tree.

The cause, from `p5_review_merge.py`: the merged receipts carry INT-REQ-004 ("request item i1 appears unaddressed")
for genuine one-line answers, for example "1/2 = 0.50" to "Calculate 1/2 exactly, without rounding.". The tightened
item-coverage rules come from `review-stem-channel`, which changes `stem/hub_hooks.py` (+287 lines) and
`channel/bus.py` (+235 lines). Fixer c resolves this at its cause in Phase 0 (B.3).

The full suite on the merged tree, with that file and the stress tests left out: 5328 passed, 4 xfailed (the B26 and
B27 strict xfails), none failed. So the 8 review tests are the only Phase 0 breakage.

### 0.2 Issue 1 (unchecked source labels): probe `p1_issue1.py`

| Restating premise (p proves p) | 22d6a5b today |
| --- | --- |
| `task_setting`, `rubric_rule` or `arithmetic_fact`, no figure, task record given | refuted (`numeric_in_task`, verified False), so it counts as ungrounded and E112 fires |
| the same kinds, no task record (a two-argument verifier) | verified None, so it counts as unverified and E112 is suppressed |
| `supplied_text` with an empty excerpt or no excerpt | `locator_exists` None, unverified, **E112 suppressed** |
| `knowledge_document` | `not_checkable`, unverified, **E112 suppressed** |
| a joined quotation `walls AND trapped` (f07) | the excerpt verifies the whole conjunction, **E112 suppressed** |

So circularity still clears whenever a source label sits on a premise that no check verified.

The same code causes false alarms. A Bool `task_setting` premise that the task does state ("the forces on it are
balanced") is *refuted*, because the absence of a figure is read as refutation. This is the GROUNDING:FAILED false
alarm on c02-mt and c03-dich, and it also appears on f03, f03b and f04.

The translator discards a provider's own `verified: true` silently: `grounding.check_grounding` resets it with no
record. Only the engine's `_demote_asserted_verification` records E505, and by the time the engine sees the problem
the translator has already reset the flag. So e08b's self-certified premise leaves no trace.

Two tests pin the old circularity rule:

- `tests/engine/test_round7_engine.py::test_a_restated_task_setting_is_a_transcription_not_a_circle` runs fixture
  ph-t13/g1.1, whose premise `mk1` is a `task_setting` with verified None.
- It pins exactly the hole issue 1 describes, and is rewritten to the stricter rule (B.1).

### 0.3 Issue 2 (the missing link written in as a premise): prototype `p2_r0_prototype.py`

The prototype decides the conclusion again from the premises a check verified, minimises the writer's premises the
proof needs, then applies structural rules.

| Case | Engine | Prototype output | Needed rule |
| --- | --- | --- | --- |
| c01-mp, c02-mt, c03-dich, c05-chem (controls) | ENTAILED | info: needs `general_knowledge` rules and facts and one `specialist_inference` link | info only |
| c04-quote, c02-hist, c03-psych, c04-eng, i00, i02c (controls) | ENTAILED | info: needs one writer link (L1, l_way and l_trap, P_rule, L_cause) | info only |
| f01 | COUNTEREXAMPLE | no premise mentions the point | warning, `leap_in_logic` |
| f01b | ENTAILED | needs the writer's link `l_so` | info, named with the missing link (not releasable) |
| f02 | COUNTEREXAMPLE | the missing bridge `e_dir => vel_changes` | warning, `leap_in_logic` |
| f03, f03b | CE, ENTAILED | the converse of `l_plant_wall` | warning, `affirming_the_consequent` |
| f04 | COUNTEREXAMPLE | denies the antecedent of `l_raise_falls` | warning, `denying_the_antecedent` |
| f10 | ENTAILED | the writer's either/or, not exhaustive by logic | warning, `false_dilemma` (c03-dich's `general_knowledge` disjunction does not fire) |
| f06b, f09b, i02, i03a | ENTAILED | needs one writer link; structure alone cannot name it | gloss rules (paraphrase, universal, causal, sense) |
| i03b | CE (AMBIGUOUS) | the bridge `P_theory => evo_everyday_theory` | warning, `equivocation` (the bridge joins two senses of one head noun) |
| e06b | CE | the verified table entails the negated point | `contradiction`, and better `cherry_picked_data` |
| e01, e02, e04a, e05a, e07, e08a, e08b | ENTAILED | needs unestablished *facts* (P_borrow, P_growth, ...) | evidence rules (graded by task) |
| 7 B8 counterexamples | COUNTEREXAMPLE | the falsified conjuncts are only unlinked atoms, and the linked part is ENTAILED | never a COUNTEREXAMPLE on display |

The prototype needed at most 4 derived runs per case. Structure decides the formal patterns. It cannot separate f01b
(a non sequitur written with "so") from c03-psych or c04-eng (a valid interpretive link written with "which shows"):

- both are evidence followed by one writer link to the point;
- only relevance differs, and relevance needs meaning.

So the generic "rests on the writer's own link" diagnostic is **info**, carries the missing link, and leaves the
result not releasable. Warnings come only from rules that name a pattern.

### 0.4 Issue 3 (no reference knowledge for STEM method)

These remain after the review branches:

- s02 and s02b (½mv): missed.
- s03a (bare numbers of unit bindings): missed.
- s03b and s03d: named `stem_arithmetic_slip`, not `stem_unit_error`.
- s04 (rounding flips the verdict): caught, unnamed.
- s05 (stated operation wrong, right answer): missed.
- s06 (one symbol for two speeds): missed.
- s07 (extrapolation): caught, unnamed.
- s08 (no working): missed.
- f05b (contradictory givens): missed.

### 0.5 End-to-end items, re-checked on 22d6a5b (dev corpus cases `e2e-*` and code inspection)

| Item | State on 22d6a5b | Owner |
| --- | --- | --- |
| B2 | reproduces: all six `e2e-B2-*` cases give an INT-SUBJ-001 error | c |
| B3 | reproduces: `scripts/arena/run_arena.py::relay_peer` writes `peer_receipt` (every finding and message) into the file the dependent specialist reads | d |
| B4 | reproduces: five `e2e-B4-*` INT-REQ-005 errors | d |
| B5 | reproduces: `e2e-B5-sp` gives 7 INT-REQ-003 errors (the corrected forms after "→") and CORE-SRC-003 | a |
| B6 | reproduces: `e2e-B6-en` ES-SRC-001 and INT-REQ-003 on `without "like" or "as"` | a |
| B7 | reproduces: `e2e-B7-ph` INT-CONFLICT-001 | c |
| B8 | reproduces: six ps counterexamples and the en p4-point counterexample | b |
| B11 | pack text only, for the overseer later (section D) | — |
| B13 | the gate exists only in the scratch e2e harness; the repository has no response gate | d |
| B15 | reproduces: `POST /v1/verify` refuses nested `verified: true` with 400 E505, while contract §2 says it is "discarded, with diagnostic E505" | d |
| B16 | ess reproduces (GROUNDING:FAILED on q_h81, q_h82, q_ratio). hi changed: h1.2 is now INVALID_FORMALIZATION by the precision step, which rejects `[1.545, 1.555]` against the stated `[1.545, 1.555)` | a: grounding; b: precision |
| B17 | not in the corpus; fixer c reproduces it first with a two-agent STEM task | c |
| B18 | reproduces: `e2e-B18-*` INT-REQ-004; "Please my exact words" (the word "quote" is lost); the single-item INT-REQ-004 on c03-dich, c04-quote and i02c is the same rule | d |
| B19 | reproduces: `e2e-B19-ll` | d |
| B20 | reproduces: no notice when the two encodings of one claim disagree | d |
| B21 | **does not reproduce as reported**: g4.1 is INVALID_FORMALIZATION by the exactness rule (0.92 widened), not ENTAILED. The general rule is still missing, so a constructed test is needed | b |
| B22 | **reproduces in substance**: s7.2's interval `[2,294,000, 2,298,000)` is narrower than the stated 2.3 × 10⁶ (2 s.f.) and passes the precision step. It is displayed AMBIGUOUS only because of an unrelated provider flag (`therefore_link`) | b |
| B23 | reproduces: `e2e-B23-bm` GROUNDING:FAILED on p_student | a |
| B25 | reproduces: CORE-QNT-001 on every worked line of bm, ec, ge and ps, and on i02c's "fell by 30%" (which the extract states word for word) | c |
| B26 | reproduces (strict xfail) | a |
| B27 | reproduces (strict xfail) | a |

The other workflow's commit `0d28eba` on `e2e-fix-channel` covers B1, B1b and bug 8 (B14). It touches these files:

- `channel/bus.py`, `service/app.py`, `engine/policies.py`, `engine/identity.py` and `integrity/contracts.py`;
- `scripts/arena/run_arena.py`, `scripts/arena/list_claims.py` and `docs/integration-contract.md`, which it moves to
  contract 0.3.

Section E covers the merge.

### 0.6 How the corpus scores modes, and what follows

The runner has three properties that shape the design:

- It scores a defect by its **worst** mode.
- It reads every `defect` field anywhere in the dumped receipt, including the engine result nested in an outcome, at
  that record's own severity.
- In a defect case that is caught (refused, flagged or not releasable), any hit of the wanted label names it, even
  at info. On a control, only warnings and errors are false alarms.

In text mode the generic parser often makes the concluding sentence a standalone analysis claim. Such a claim is
NOT_ELIGIBLE and gets no translation: e01, e04a, e08a, e08b and i02c. Some claims get no outcome at all, such as
i01b's only claim (a judgement) and e01's g1.2. Two decisions follow.

1. **Report-level rules.** Rules that need an engine result cannot name those modes, so three rules run over the
   delivered claims and the request instead (A.3, report layer). Prototype `p4b`:
   - ARG-BARE-001 fires on i01 and i01b in both modes, and on no control;
   - EVD-LACK-002 fires on e01 in all three modes;
   - EVD-SRC-002 fires on e04a and e08b in all three modes;
   - the only other hit is EVD-LACK-002 (info) on a quoted word ("avoid "dropped"") in three e2e psychology answers,
     which masking quotations removes.
2. **One severity per diagnostic.** A cap applied only when the outcome is composed would leave an uncapped copy inside
   the signed engine result, where the runner, the overseer and any reader would see it. So a cap is applied where the
   diagnostic is made, and recorded (A.2, `capped_from`).

---

## A. The contract

### A.1 Rules every diagnostic obeys

1. **Diagnostics only add.** A diagnostic never changes an engine status, a display status, a dependency list, a
   grounding check or an existing finding. It never turns a non-success into success and never weakens a check.
   It may only:
   - add a line, a record or a receipt finding;
   - move a receipt from ACCEPTED to ACCEPTED_WITH_FINDINGS;
   - make a result **not** releasable.

   Two display rules change what is displayed, and both move toward "nothing verified", never toward success:
   - the B8 and B21 flags turn a counterexample built on an unlinked or dropped part of the claim into
     AMBIGUOUS_TRANSLATION;
   - B13 counts an ENTAILED that rests on any unestablished premise as unresolved.

   Section E argues that neither is a weakening.
2. **Non-success is never shown as success.**
   - A test reads every message template. None contains the words valid, sound, correct, passed, proves, proven or
     success.
   - "Verified" appears only in the phrases "a check verified" and "no check verified".
   - The scope statement stays last in every summary.
3. **The IR is data.**
   - Rules read validated `Problem` objects, signed `VerificationResult`s, `GroundingCheck` records, `ClaimRecord`
     structure and the request text.
   - Labels, meanings and texts are read only as strings, through the shared tokenizer `lexis.py`, by bounded linear
     scans. There are no regexes with nested quantifiers. Inputs are already bounded by the schemas: labels and
     meanings at most 1,000 characters, claims at most 4,000.
   - A derived problem is built only by copying validated expression dicts into the allowlisted wrappers `implies`,
     `not`, `and` and `iff`.
   - Every derived problem passes the engine validator. Nothing is evaluated or executed.
4. **Deterministic.**
   - Rules run in a fixed order with a fixed solver seed.
   - Derived runs are bounded (A.8). A derived TIMEOUT or UNKNOWN never fires a rule.
   - An exhausted budget is recorded, never read as "none found".
5. **One positive test and one clean control for every code.** Each control stays free of warning-level diagnostics.
6. **Works without the engine.** `named.py` and `lexis.py` import neither z3 nor the engine package. So receipts,
   translation records and the overseer can carry and read diagnostics where Z3 is absent.
   - When no engine ran, there is no engine-layer diagnostic and no `argument_rules`.
   - That reads as "not computed", never as "none found".

### A.2 The model: `src/epinoic_logic/named.py` (written once by the Contract step)

The model is a top-level module because `epinoic_logic/engine/__init__.py` imports z3 eagerly (through compiler,
procedures and runner). A model inside the engine package could not be imported without Z3. `BUILD_SOURCES` gains
`"named.py"` and `"lexis.py"`, so `build_id` still covers everything the engine's diagnosis depends on.

```python
DEFECT_LABELS: tuple[str, ...] = (   # the 28 canonical labels, exactly as the corpus scores them
    "leap_in_logic", "affirming_the_consequent", "denying_the_antecedent", "hasty_generalisation", "false_dilemma",
    "circular_reasoning", "equivocation", "causal_leap", "bare_assertion", "contradiction", "vacuous_argument",
    "lack_of_evidence", "unchecked_source", "source_mismatch", "altered_quotation", "invented_figure",
    "cherry_picked_data", "uncheckable_authority", "stem_wrong_formula", "stem_unit_error", "stem_dimension_error",
    "stem_arithmetic_slip", "stem_invalid_step", "stem_rounding_changes_conclusion", "stem_extrapolation",
    "stem_missing_working", "stem_contradictory_givens", "stem_symbol_conflict")
DefectLabel = Literal[...]        # the same 28
Severity = Literal["error", "warning", "info"]
Layer = Literal["engine", "claim", "report", "stem", "channel"]
Derivation = Literal[
    "engine_status",      # restates the engine's own status or diagnostic (E108, E112, INCONSISTENT_PREMISES)
    "engine_recheck",     # derived engine runs over the same bound problem (A.8)
    "ir_structure",       # a shape rule over the validated IR (expressions, recorded grounding kinds)
    "ir_glosses",         # a bounded token rule over the IR's own meanings and labels
    "grounding_record",   # GroundingCheck records made in this process
    "source_text",        # a bounded token rule over the claim, the request or a supplied text
    "claim_structure",    # claim roles and supporting_claim_ids of the report
    "stem_reference",     # the closed STEM reference data (stem/reference_data.py)
    "stem_engine",        # a STEM check decided by the engine
    "request_reading"]    # the request parser

class EvidenceSpan(BaseModel):            # frozen, extra="forbid"
    source_kind: Literal["claim", "supporting_claim", "supplied_text", "task", "answer", "premise_label", "symbol_meaning"]
    source_id: str = Field(max_length=200)
    start: Optional[int] = None           # character offsets when the span is located
    end: Optional[int] = None
    text: str = Field(max_length=300)     # the span itself, cut, never paraphrased

class MissingLink(BaseModel):             # frozen, extra="forbid"
    premise_ids: list[str] = []           # the writer's premises standing in for the link ([] when the link is absent: a bridge)
    antecedent: str = Field(max_length=300)   # rendered from symbol meanings
    consequent: str = Field(max_length=300)
    text: str = Field(max_length=600)     # "if <antecedent> then <consequent>" (or "either ... or ..., and nothing else")
    expr: Optional[dict] = None           # the step as IR data (implies/iff/or of validated nodes); never evaluated

class NamedDiagnostic(BaseModel):         # frozen, extra="forbid"; dumps leave out empty optional fields
    code: str                             # ^[A-Z]{2,5}-[A-Z]{2,8}-\d{3}$ and a key of NAMED_CODES
    defect: DefectLabel                   # key name fixed: the corpus runner and the Overseer read "defect"
    severity: Severity                    # as shown everywhere; never above NAMED_CODES[code].max_severity
    capped_from: Optional[Severity] = None    # the severity before a cap (A.4.2); release reads it (A.6)
    cap_reason: Optional[Literal["ambiguous_translation", "not_source_bound"]] = None
    layer: Layer
    claim_ids: list[str] = []             # claims concerned ([] = request level)
    assertion_ids: list[str] = []         # premises and conclusion concerned (IR level)
    missing_link: Optional[MissingLink] = None
    evidence: list[EvidenceSpan] = Field(default_factory=list, max_length=8)
    derivation: Derivation
    derived_problem_digests: list[str] = Field(default_factory=list, max_length=24)  # sha256 of each derived problem
    related_result_ids: list[str] = []    # separately signed engine results consulted (claim, report, stem, channel layers)
    rule_version: str = ARG_RULES_VERSION # "argdiag-1", defined in version.py
    message: str = Field(max_length=600)  # display text (A.5)

@dataclass(frozen=True)
class CodeSpec:
    code: str; defect: str; max_severity: str; layer: str; owner: str; precedence: int; meaning: str
NAMED_CODES: Mapping[str, CodeSpec]            # read-only (MappingProxyType); the complete table of A.3
DEFECT_OF_CODE: tuple[tuple[str, Optional[str], Optional[str]], ...]  # (code regex, message regex, label) for EXISTING codes
```

The Contract step writes these helpers once, in the same module:

- `named_diagnostic(code, *, severity=None, **fields)`: takes `defect`, `layer` and the maximum severity from the
  table, and lowers a requested severity, never raises it.
- `cap(diags, level, reason)`: lowers each severity above `level` to `level`, sets `capped_from` and `cap_reason`, and
  leaves a diagnostic at or below the level untouched.
- `effective_severity(d)`: the higher of `severity` and `capped_from`. Release uses it.
- `merge(*lists)`: removes duplicates by `(code, claim_ids, assertion_ids)` and keeps the highest effective severity.
- `ordered(diags)`: sorts by claim, then code precedence, then assertion ids.
- `suppress_dominated(diags)`: a warning of a more specific code on the same assertions suppresses the less specific
  warnings of the same family (for example, ARG-HG-001 suppresses ARG-NS-001 on f09). Info records are always kept.
- `defect_of(code, message)`: reads DEFECT_OF_CODE.
- `from_finding(finding, layer)`: turns a structural or integrity finding that carries a `defect` into a
  NamedDiagnostic.

Per-claim bounds: at most 32 diagnostics per claim and 256 per receipt. Any overflow is counted in the summary,
never dropped silently.

`src/epinoic_logic/lexis.py` (Contract step, frozen) is the one tokenizer every lexical rule uses:

- `tokens(text)`: lower-case words and numbers, linear;
- `stem(word)`: A.8.4;
- `content_stems(text)`: stems minus the function and frame words of A.8.4;
- `has_cue(tokens, table)`: token-sequence match on word boundaries, linear in the input;
- `negated(tokens)`: the negation rule of A.8.4.

The cue *tables* stay with their owners: `engine/argument_cues.py` (b), the evidence module (a), `stem/reference_data.py`
(c) and `channel/cues.py` (d).

### A.3 The code table (the whole of NAMED_CODES, written by the Contract step; fixers implement the rules)

Severity column: the maximum. A rule may emit less, never more. "Warn/info" means warning in a source-bound task
(A.4.3) and info otherwise; the cap records `cap_reason="not_source_bound"`.

**Engine layer**: `engine/argument.py`, owner b. These diagnostics are signed with the result. All derived runs are those
of A.8.

| Code | Label | Sev | Rule (decided from the bound problem and its result alone) |
| --- | --- | --- | --- |
| ARG-LINK-001 | leap_in_logic | info | The re-check (R0): the conclusion does not follow from the premises a check verified. It follows only with the writer's link(s) in W* (implications, biconditionals, disjunctions or numeric relations that no check established, whatever their label). Each one is given as a `missing_link`. |
| ARG-FACT-001 | lack_of_evidence | info | R0: the proof also needs fact premises in W* (atoms, comparisons, assignments) that no check established. They are listed; the evidence layer grades them. |
| ARG-NS-001 | leap_in_logic | warning | COUNTEREXAMPLE with at least one premise, where no premise mentions any symbol of any conclusion conjunct: no reason given touches the point (f01). |
| ARG-NS-002 | leap_in_logic | warning | COUNTEREXAMPLE that one bridge `E ⇒ A` makes ENTAILED. A is the antecedent of a conditional whose consequent shares the point's symbols; E is a stated fact other than A. The bridge is the `missing_link` (f02). |
| ARG-PART-001 | leap_in_logic | info | COUNTEREXAMPLE whose falsified conjuncts all consist of symbols no premise mentions, while the remaining conjuncts are ENTAILED (the B8 shape). It names the unlinked judgement. |
| ARG-INV-001 | leap_in_logic | warning | COUNTEREXAMPLE with premises that mention the point, where no more specific code fires: "does not follow from its encoded reasons; shape not named". |
| ARG-REFUTE-001 | contradiction | warning | COUNTEREXAMPLE where the verified premises entail the negated conclusion: the stated evidence refutes the point (e06b). |
| ARG-AC-001 | affirming_the_consequent | warning | Either form. (a) COUNTEREXAMPLE with a premise P→Q, a stated fact Q and the conclusion P, where adding the converse makes it ENTAILED (f03). (b) ENTAILED, where a writer link Q→P in W* is the converse of another premise P→Q (f03b). |
| ARG-DA-001 | denying_the_antecedent | warning | Either form. (a) COUNTEREXAMPLE with P→Q, a stated fact ¬P and the conclusion ¬Q (f04). (b) ENTAILED, where a writer link ¬P→¬Q in W* stands beside P→Q. |
| ARG-FD-001 | false_dilemma | warning | ENTAILED, with a disjunction in W* whose kind is `specialist_inference`, `assumption` or none. The disjunction is not valid on its own (a derived check), and no two disjuncts are complementary (`p`/`¬p`; `x<a`/`x≥a`) (f10). A `general_knowledge` rule such as c03-dich's "every bit is 0 or 1" never fires. |
| ARG-HG-001 | hasty_generalisation | warning | Either form. (i) ENTAILED: a writer link in W* whose consequent gloss carries an open universal cue (A.8.4) absent from every antecedent gloss, and whose antecedent atoms are instance facts. (ii) COUNTEREXAMPLE where ARG-NS-001 holds, the conclusion gloss is universal and the premises are instances (f09, f09b). |
| ARG-CL-001 | causal_leap | warning | A writer link in W* whose consequent gloss carries a causal cue, and whose antecedent holds a temporal sequence: two comparisons of one quantity at two times (meanings equal except for a year or date token), or a sequence cue in the link label. No premise label or meaning in the problem may carry a control cue (i02 fires; i02c stays clean). |
| ARG-CIRC-001 | circular_reasoning | warning | E112 is on the result (layer engine), or the pipeline refused the translation as circular (layer claim; the same rule, `circular_premises`). Fixer a's authority rule (B.1) makes either fire whenever the restating premise is not established, whatever its label (f06, f07, and p proves p with any label). |
| ARG-CIRC-002 | circular_reasoning | warning | ENTAILED, and the conclusion is equivalent to one unestablished premise of W* (`premise ⟺ conclusion` is valid, decided by a derived check) without being syntactically E112. |
| ARG-CIRC-003 | circular_reasoning | warning | A writer link A→C in W*, where C is the conclusion and A a single fact atom whose gloss paraphrases C's: every content stem of C's gloss is among A's, the extra words of A are only frame words, and the polarity matches (A.8.4; f06b). |
| ARG-EQ-002 | equivocation | warning | ARG-NS-002's bridge joins two symbols whose meanings have the same head noun, and at least one meaning carries a sense marker. The missing link is "the two senses of 'N' are the same" (i03b). |
| ARG-EQ-003 | equivocation | warning | One symbol, two senses. The symbol's meaning qualifies a head noun N with a sense qualifier, a parenthetical or "in the ... sense" (A.8.4). A writer link in W* that uses the symbol has a label that is a bare generic definition of N ("a theory is an unproven guess") without that qualifier (i03a). |
| ARG-VAC-001 | vacuous_argument | warning | E108 is on the result (f08). |
| ARG-CONTRA-001 | contradiction | error | INCONSISTENT_PREMISES; names the core. The receipt already carries INT-REQ-007, so no INT-ARG-001 is added for it. |

**Claim layer, argument**: `translate/diag_argument.py` (`RULES`), owner b. These rules need the translation record.

| Code | Label | Sev | Rule |
| --- | --- | --- | --- |
| ARG-EQ-001 | equivocation | warning | The translation's ambiguity flag has a code in {EQUIVOCATION, SENSE_SPLIT, TWO_SENSES} (case-insensitive). The flag's message is cut to 160 characters and kept as evidence. Like ARG-EQ-002 and 003, it is not capped on AMBIGUOUS, because the ambiguity is the defect (i03b). |

**Report layer, argument**: `translate/diag_argument.py` (`REPORT_RULES`), owner b. These rules read the delivered
claims and the request, once per report. An *answer section* is the claims of one paragraph group, or the whole
answer when the record has no paragraphs.

| Code | Label | Sev | Rule |
| --- | --- | --- | --- |
| ARG-BARE-001 | bare_assertion | warning | A delivered claim C, where all of these hold: (i) a request item's command term asks for reasons (explain, evaluate, discuss, justify, to what extent, analyse or analyze, examine, assess, why); (ii) C is material, its role is not evidence, quotation, quantitative or given, and no claim cites C as support; (iii) C has no supporting_claim_ids, and its own text (quotations masked) has no reason connective (A.8.4); (iv) no other claim of its answer section has a supporting role (evidence, quotation, quantitative, given, analysis, link), a reason connective or supporting_claim_ids. It needs no outcome, so it fires on i01b, whose only claim gets none. Prototype: i01 and i01b in both modes, no control. c03-dich (two of its three sentences are quantitative) and f06's text mode are exempt by (iv). |

**Claim layer, evidence**: `translate/diag_evidence.py` (`RULES`), owner a. EVD-SRC-001, EVD-SRC-003, EVD-LACK-001,
EVD-FIG-001 and EVD-AUTH-001 apply only to ENTAILED results, and grade the facts in W* (from ARG-FACT-001) or, when R0
did not run, the core. EVD-CHERRY-001 applies to every decided result. EVD-SRC-004 applies to every translation.

| Code | Label | Sev | Rule |
| --- | --- | --- | --- |
| EVD-SRC-001 | unchecked_source | warn/info | A needed fact premise whose kind claims a text or task authority (`quotation`, `supplied_text`, `knowledge_document`, `library_source`, `task_setting`, `rubric_rule`, `arithmetic_fact`) that no check verified: a label with no excerpt, an empty excerpt, or an excerpt no check located (e04a, e08b). |
| EVD-SRC-003 | source_mismatch | warning | The point is ENTAILED, and a needed premise's grounding check failed (verified False): the point rests on a source that does not say it (e03, e04b; strengthens the existing codes). |
| EVD-SRC-004 | unchecked_source | info | The translation's provider asserted `verified` on a grounding (recorded at parse time, A.4.2), and the flag was discarded because only checks set it (e08b). |
| EVD-LACK-001 | lack_of_evidence | warn/info | A needed fact premise claiming no source (`general_knowledge`, `specialist_inference`, `assumption`, none) that no check verified (e01). |
| EVD-FIG-001 | invented_figure | warn/info | A needed assignment premise whose figure (a typed quantity) occurs in no supplied text and not in the task record. Its FigureReading is not the result of a written calculation over figures that do occur there (`calculated` None, no calculation cue), and its claim carries no from-memory label (`is_memory_label`). Warning when the task is source-bound or supplies data texts (e02). |
| EVD-AUTH-001 | uncheckable_authority | warning | A needed premise's label or meaning, or its claim's text, has an unattributed authority or data cue (A.8.4), and no check verified the premise (e05a, e07). |
| EVD-CHERRY-001 | cherry_picked_data | warning | The point names a period (from or between Y1 and Y2, Y1–Y2), and a supplied text pairs values with both endpoint years. The encoding or the evidence claim uses only inner years. With the endpoint values read from the text, the point's stated direction (falling or rising, or the conclusion's comparison) fails. The omitted endpoints are named (e06a, e06b; c01-econ stays clean). |

**Report layer, evidence**: `translate/diag_evidence.py` (`REPORT_RULES`), owner a.

| Code | Label | Sev | Rule |
| --- | --- | --- | --- |
| EVD-SRC-002 | unchecked_source | info | A claim attributes content X to a named supplied document ("Source A shows / suggests / states / says / reveals / indicates that X"; "the extract / table / text / passage / study shows that X"). (i) No quotation in the same answer section is located in any supplied text, and (ii) X has at least 3 content stems, of which fewer than 60 % occur in the document. Info only: a paraphrase cannot be checked deterministically, so the record says the attribution was not checked, never that it is false. e04a and e08b fire; c02-hist is exempt by (i). |
| EVD-LACK-002 | lack_of_evidence | info | In a task with supplied texts, a claim states a change in a quantity (a trend verb, A.8.4) with no figure other than a year or date (quotations masked). No content stem of the verb's subject (the words before the verb within its clause) occurs in any supplied text or in the request. e01 fires; c01-econ, i00 and i02c are exempt (they state figures, or the subject occurs in the text). |

**STEM layer**: owner c. These are STEM pack findings with a `defect`, or engine-decided STEM checks.

| Code | Label | Sev | Rule |
| --- | --- | --- | --- |
| ST-REF-001 | stem_wrong_formula | warning | The answer's law for a symbol whose reference quantity is fixed (B.3) has a right-hand dimension (numeric coefficients dropped, whatever their spelling) other than that quantity's. The data-booklet formula is named (s02, s02b; s00 clean). |
| ST-UNIT-003 | stem_unit_error | warning | Either case. (1) Bare numbers in the working equal the numbers of non-SI bindings (`d = 2.5 km`, `t = 10 min`), the result carries an SI unit, the as-written reading holds and the SI reading fails (s03a). (2) An INT-SUBJ-001 whose SI reading fails while its as-written reading holds (s03b, s03d); its FormalCheck carries `defect="stem_unit_error"`. |
| ST-STEP-001 | stem_invalid_step | warning | A line states an operation (add or subtract k on both sides; multiply or divide both sides by k; square both sides; take the root of both sides). Applying it to the previous equation does not give the next line: one side is not identically equal, decided by the engine as an identity check (s05; s05c clean). |
| ST-STEP-002 | stem_invalid_step | info | A solving step that is not reversible under the stated domain guards (division by an expression with no `≠ 0` guard, squaring), where the engine shows that the two equations' solution sets differ. |
| ST-ROUND-001 | stem_rounding_changes_conclusion | warning | A comparison against a threshold uses a value the working itself rounded (an ≈ link in the chain). The same comparison with the unrounded chain value has the opposite truth; the engine decides both (s04; s04c clean). |
| ST-RANGE-001 | stem_extrapolation | warning | A model the answer states is evaluated at an input outside [min, max] of a data series the request gives (three or more values of one quantity in one unit), with no extrapolation caveat (A.8.4) (s07; s07c clean). |
| ST-WORK-001 | stem_missing_working | warning | The request asks for working ("show (your/full) working", "showing your working"), or its command term is calculate, determine or show with 2 or more marks. The answer's STEM document has a result statement but no formula, substitution or working line (s08; s08c clean). |
| ST-GIVEN-002 | stem_contradictory_givens | warning | A symbol bound in a Given or Data statement is bound again to a different value in the same part, with no new symbol (subscript or prime), and a later check or the stated result uses the second value (f05b; c06-givens clean). |
| ST-SCOPE-002 | stem_symbol_conflict | warning | A symbol bound twice in one part to different values, where the two bindings' noun phrases name different quantities ("the car's speed" and "the speed of sound"), with no change marker, and a later substitution uses one of them (s06; s06c clean). |

**Existing codes given a label** (DEFECT_OF_CODE, Contract step; the bus applies it):

| Codes | Label |
| --- | --- |
| INT-REQ-007; INT-CONFLICT-001; INT-CONFLICT-005 | contradiction (INT-CONFLICT-004 stays unlabelled: it is a translation fault) |
| INT-REQ-003; ES-SRC-001, CORE-SRC-001, GEN-SRC-001 | altered_quotation when the message says altered, else source_mismatch |
| CORE-SRC-005, ES-SRC-008, INT-LEDGER-025, INT-REQ-015 | source_mismatch |
| CORE-SRC-003, CORE-SELF-001 | unchecked_source |
| CORE-SRC-002, HI-SRC-004 | lack_of_evidence |
| PS-SRC-001, HI-SRC-003 | uncheckable_authority |
| ST-DIM-001, ST-DIM-002 | stem_dimension_error |
| ST-SCOPE-001 (info) | stem_symbol_conflict |
| INT-SUBJ-001 and INT-SUBJ-004 | `FormalCheck.defect` when set. Otherwise by kind: `stem_conversion` → stem_unit_error; `stem_algebra` → stem_invalid_step; `stem_given` → stem_contradictory_givens; `stem_comparison`, `stem_target`, `stem_balance` → none; other `stem_*`, `arithmetic`, `percentage`, `pair_direction` → stem_arithmetic_slip |

**Channel codes** (IntegrityFinding, no NamedDiagnostic):

| Code | Sev | Owner | Meaning |
| --- | --- | --- | --- |
| INT-ARG-001 | the diagnostic's | Contract | the receipt finding for a warning or error NamedDiagnostic on a material claim; carries its `defect` |
| INT-REQ-017 | warning | d | the answer passes a system check result to the reader as subject content (B3) |
| INT-XENC-001 | warning | d | two encodings of one claim (a branch formal check and the translation) reach opposite definitive answers (B20) |

### A.4 Where diagnostics appear

**A.4.1 The engine result** (`engine/results.py`, `engine/runner.py`; Contract step). Two fields are added to
`VerificationResult`, both left out of every dump while `None`, like `limits`:

- `named_diagnostics: Optional[list[NamedDiagnostic]]`, set only when non-empty;
- `argument_rules: Optional[str]`, set whenever the diagnosis ran, even when it found nothing:
  - `"argdiag-1"` when it finished;
  - `"argdiag-1/incomplete:<reason>"` when the budget ran out or a rule raised.

Absent means not computed, which is never read as "none found". This is the lesson of the `produce_unsat_core` flaw.

The signature becomes
`verify(problem_or_raw, config, limits, signing_key, key_id, *, diagnose=True, severity_cap=None)`.

- The keywords are Python only, never reachable from HTTP or `SolverConfig`.
- `runner.verify` calls `argument.diagnose(problem, proc, compiled, config, enforced_limits, diagnostics)` after the
  decision and before binding and signing.
- When `severity_cap` is given (the translator passes `("info", "ambiguous_translation")` for an ambiguous
  translation), `cap()` is applied before signing, except to the equivocation codes.
- So both fields, and the cap with its `capped_from`, are covered by the HMAC signature.

Every derived problem is a deterministic function of the bound problem and the rule version, and its digest is recorded
in `derived_problem_digests`. `policy_manifest()` gains `"argument_rules": "argdiag-1"` and `"named_codes"` (the
digest of NAMED_CODES as data). So the versions digest binds the rules that produced the diagnostics: this is "its
signed binding".

**Call sites.** The Contract step sets `diagnose` at every call outside the engine:

| Call site | diagnose |
| --- | --- |
| `translate/outcome.py` (the claim's verification), `service/app.py` `POST /v1/verify`, `cli.py` verify | True (the default) |
| `translate/precision.py` (three probe calls) and `translate/pipeline.py` `_stated_figures` (the internal probes) | False |
| `integrity/cross_check.py` (all eight joint and cross-claim checks) | False |
| `channel/bus.py`: the branch formal checks and the two constraint-bound checks (code-built checks, not specialist arguments) | False |

A result without `argument_rules` is refused by `release_check` (rule 9).

The circular, vacuous and inconsistent cases are surfaced from the engine's own status and diagnostics. R0 never runs
on them.

**A.4.2 The translation record** (`translate/contracts.py`, Contract step):

| Field | Holds |
| --- | --- |
| `TranslationResult.premise_roles: list[PremiseRole]` | written at translation time by `translate/roles.py` (A.8.3): the marking record of issue 2 |
| `TranslationResult.asserted_verified: list[str]` | the paths where the provider's JSON wrote `verified`, from `parsing.asserted_verified_paths()` (a stub returning [] until fixer a). Each path also adds the translation diagnostic "E505: the translation asserted verified=true at <path>; discarded: only checks set it". |
| `ClaimVerificationOutcome.named_diagnostics: list[NamedDiagnostic]` | the engine's diagnostics (only when the result binds and is trusted, `display != INTERNAL_ERROR`) merged with the claim layer's |
| `ClaimVerificationOutcome.diagnosis_incomplete: list[str]` | each rule that raised or ran out of budget, named |
| `StructuralFinding.defect: Optional[DefectLabel]` | left out while None |

`translate/diag_core.py` (Contract step) has two entry points:

- `claim_diagnostics(ctx)` is called from `outcome.compose_outcome` for every outcome, NOT_ELIGIBLE included. `ctx` is
  a frozen `DiagContext` with:
  - the claim, its supporting claims and the report;
  - the task record, the translation and the trusted verification;
  - the display status, `premise_roles` and the engine diagnostics;
  - the needed premises from R0.

  It runs `diag_argument.RULES`, then `diag_evidence.RULES`.
- `report_diagnostics(report, task, outcomes)` is called by the bus once per delivered report. It runs
  `diag_argument.REPORT_RULES`, then `diag_evidence.REPORT_RULES`.

Every rule is guarded: a rule that raises is named in `diagnosis_incomplete` and fires nothing. Both entry points apply
the caps and the suppression. The Contract step creates both rule modules with every tuple empty.

The caps:

1. **AMBIGUOUS_TRANSLATION.** Every ARG-* and EVD-* code is capped at info, because the encoding is one assumed
   reading. The exceptions are ARG-EQ-001, 002 and 003. The engine applies the cap through `severity_cap`; the claim
   layer applies `cap()`. The message adds "on the translator's assumed reading".
2. **Not source-bound.** The warn/info codes of A.3 are capped at info outside a source-bound task.
3. **Untrusted result.** An engine result that does not bind, is stale or has a bad signature contributes nothing.
4. **Non-material claim.** A claim with materiality "supporting" keeps its severities but gets no INT-ARG-001 on the
   receipt.

**A.4.3 Source-bound tasks** (helper `source_bound(task_text) -> bool` in `translate/diag_evidence.py`, owner a). A
request is source-bound when an item names supplied material as the basis of the answer. The closed cue list:

- "using (the) (extract | source | text | passage | table | data | figure | study summary | graph | article)";
- "with reference to (Source | the extract ...)";
- "according to the (text | extract | source)";
- "what does (Source X | the extract) (suggest | show | reveal | tell us)";
- "in (this | the) (extract | passage | poem)";
- "from the (table | data | extract)";
- "refer to".

Without a task record (a two-argument verifier) a request is never source-bound, so its diagnostics are info. This is
conservative.

**A.4.4 The receipt** (`channel/contracts.py`, `channel/bus.py`; Contract step):

- `TransmissionReceipt.named_diagnostics: list[NamedDiagnostic]`, left out while empty. It holds:
  - every outcome's diagnostics;
  - the report-level diagnostics;
  - `from_finding(...)` for each structural or integrity finding that carries a `defect`.
- `IntegrityFinding.defect: Optional[DefectLabel]`, left out while None. The bus sets it through DEFECT_OF_CODE when
  it builds the receipt. INT-SUBJ-001 and INT-SUBJ-004 take `FormalCheck.defect` first.
- For every warning or error NamedDiagnostic on a material claim there is one finding:
  `IntegrityFinding(code="INT-ARG-001", severity=<the diagnostic's>, message="<defect> [<code>]: <message>", claim_ids, formal_result_id=<result id when layer engine>, related_result_ids, deterministic=True, defect=<label>)`.
  The exception is a code whose condition already has a finding (ARG-CONTRA-001 has INT-REQ-007).
- Info diagnostics stay off `findings`, so they never change the receipt status.
- `FormalCheck.defect: Optional[str] = None` is added in `branches/base.py`.

The receipt summary adds "Argument diagnosis: N named on K claims (W warning or error, I info; rules argdiag-1)".

### A.5 How a diagnostic is shown

`outcome.build_summary` (Contract step) puts this section directly after the verification lines:

```
Argument diagnosis (advisory; the status above is unchanged; rules argdiag-1):
- warning affirming_the_consequent [ARG-AC-001] on l_so, l_plant_wall: the writer's link l_so (the observed cell has a
  cell wall -> it is a plant cell) is the converse of the stated rule l_plant_wall (plant cell -> cell wall). Missing
  link: if the observed cell has a cell wall then the observed cell is a plant cell.
- info leap_in_logic [ARG-LINK-001] on l_so: the point does not follow from the premises a check verified (none); it
  follows only with the writer's own link l_so, which no source or rule states.
```

- When nothing was found: "Argument diagnosis: none found (rules argdiag-1)".
- When the diagnosis did not finish: "Argument diagnosis incomplete (<reason>); no rule fired".
- When it was not computed: "Argument diagnosis: not computed".
- A capped line ends "(capped from warning: <reason>)".
- At most 6 lines are shown, then "and N more".
- The scope statement stays last.

The display status is never changed by a diagnostic. The only display changes are the pipeline's AMBIGUOUS flags for
B8 and B21 (B.2).

### A.6 How release treats a diagnostic

`engine/release.py`, Contract step, adds two rules:

- **Rule 8:** no named diagnostic of effective severity (A.2) warning or error ("named defect: ARG-AC-001
  (affirming_the_consequent)"). A capped diagnostic therefore still blocks release: a cap changes what is shown, never
  what is permitted.
- **Rule 9:** the argument diagnosis was computed by this build. `argument_rules` must be present and equal
  `"argdiag-1"`; a result whose diagnosis was incomplete is refused.

Rule 9 costs nothing in practice. R0 runs only when the core holds an unestablished premise, and rule 7 already refuses
such a result. So a result that rules 1 to 7 allow always has a complete diagnosis. Rule 9 refuses only
`diagnose=False` results and results that are already refused. Any existing test that builds a result by hand and
expects release is rewritten to carry `argument_rules`, which is the stricter rule; the Contract step lists each one.

`outcome.assess_release` (policy `release-v2`, Contract step) adds "named defect on this claim: <codes>" for warning
and error diagnostics of every layer, by effective severity.

A load-bearing premise that R0 marks as the writer's own, or as unsupported, already blocks release through the
dependency rule (rule 7). ARG-LINK-001 and ARG-FACT-001 make the reason explicit. Info diagnostics never block on their
own and never permit anything: a result can only become less releasable.

The gate (B13, fixer d) counts a claim carrying a warning-level diagnostic as **unresolved**. It counts it as failed only
when the display is an engine-confirmed negative (COUNTEREXAMPLE, INCONSISTENT_PREMISES).

### A.7 Versions and identities

The Contract step bumps all of these, once. The fixers bump nothing.

| What | From | To | Why |
| --- | --- | --- | --- |
| ENGINE_VERSION | 0.4.0 | 0.5.0 | the argument stage; authority-based circularity (a); validator anchoring and surrogates (a); model completion (a) |
| POLICY_VERSION | 2026.10-v4 | 2026.10-v5 | the dependency policy (`assumed_for_circularity: not_established`); the named-code table and argument rules in the manifest; release rules 8 and 9; a figureless task premise unvalidated, not refuted; compound propositions verified per literal |
| TRANSLATOR_VERSION | 0.4.0 | 0.5.0 | the `translate_v3` prompt; premise roles; grounding rules; the B8 and B21 flags; precision ties (B22); diagnostics |
| IR_VERSION | 1.0 | 1.0 | unchanged. The validators now enforce the documented patterns (`^[a-z][a-z0-9_]{0,63}$` never meant a trailing newline). No field, operator or sort changes |
| ARG_RULES_VERSION (new) | — | argdiag-1 | the rule version every diagnostic carries |
| BUILD_SOURCES | version.py, ir, engine | adds named.py and lexis.py | the engine's diagnosis depends on them |
| release policy | release-v1 | release-v2 | rule 8 in the assessment |
| prompts | translate_v2 | translate_v3 | `translate_v1`, `translate_v2` and `review_v2` stay packaged unchanged |
| `build_id`, `schema_id`, `policy_id` | — | change | computed: the engine sources, the VerificationResult schema (two fields) and the manifest change |
| integration contract | 0.2 (0.3 once 0d28eba lands) | the next minor (0.4 if 0.3 has landed, else 0.3) | new section "Named diagnostics"; the HTTP E505 row (B15, d) |

Golden results of earlier releases still parse and serialise byte-identically, because the new fields are left out
while None, and they stay stale through their identity. The Contract tests assert both.

### A.8 The key Z3 check for issue 2, and how a writer's link is marked

**A.8.1 R0: decide the conclusion again from the verified premises only.** `engine/argument.py`, owner b.

```
input: the validated problem, the procedure outcome (status, core), the config and enforced limits
skip:  not an entailment query; status not ENTAILED; any NO_VERDICT code (E108, E110, E111, E112) on the result
core = the result's unsat core when produced, else every premise
V  = [p for p in premises if has_authority(p.grounding)]       # verified by a check in this process, whatever the kind
W  = [pid for pid in core if pid not in V]                     # the writer's and the unchecked premises the proof used
if W empty: no diagnostic (the proof rests on established premises)
run D0 = entailment(V, conclusion)                             # derived run 1
if D0 is ENTAILED: no diagnostic (the core was not minimal)
if D0 is TIMEOUT/UNKNOWN: argument_rules incomplete; stop
W* = W; for w in the first 16 of W, in premise order:          # deletion minimisation, derived runs 2..17
    if entailment(V + (W* - {w}), conclusion) is ENTAILED: W* = W* - {w}
(any premise of W beyond 16 stays in W*, and the record says "partly minimised")
links = [w in W* if expr op in {implies, iff, or} or numeric_shape(expr) == "relation"]
facts = W* - links
emit ARG-LINK-001(assertion_ids=links, missing_link per link, evidence=D0's counterexample values)   if links
emit ARG-FACT-001(assertion_ids=facts)                                                                 if facts
then the ENTAILED pattern rules over links (A.3: AC b, DA b, FD, HG i, CL, CIRC-002, CIRC-003, EQ-003)
```

The `missing_link` of a link w comes from its expression:

- `implies(A, B)` reads "if ⟨gloss A⟩ then ⟨gloss B⟩";
- a disjunction reads "either ⟨a⟩ or ⟨b⟩, and nothing else".

The gloss of an atom is its symbol's `meaning`, otherwise its name. `not`, `and` and `or` render as words, and a
comparison as `lhs op rhs` with the meanings in parentheses. Each part is cut to 300 characters.

The COUNTEREXAMPLE rules (ARG-NS-001, NS-002, PART-001, INV-001, REFUTE-001, AC a, DA a, HG ii, EQ-002) use these
derived runs:

| Rule | Derived runs |
| --- | --- |
| bridge | one per (conditional, fact) pair, at most 8 |
| converse | one per conditional, at most 4 |
| negated goal | 1 |
| linked part | 1 |

**Bounds.**

- At most 24 derived runs per result.
- Each run takes `min(config.timeout_ms, 1000)` and the config's `rlimit`, under the same enforced limits, so
  nonlinear problems are re-decided under the nonlinear policy.
- The total wall-clock budget is `min(4 × config.timeout_ms, 8000 ms)`.
- Precedence decides which rule runs first, so the cheapest decisive rule wins.

Exhausting the budget is recorded and fires nothing. Over HTTP, the service's admission, rate and concurrency limits
bound the total. A test asserts that a 128-premise problem with every premise unverified finishes within the budget.

**A.8.2 Why info for the generic case.** The prototype (0.3) shows that structure cannot separate f01b from valid
interpretive links: c03-psych, c04-eng, c02-hist, i02c, c04-quote and c05-chem. A warning there would add 6 to 10
false alarms on the controls.

The generic case is therefore info, named, with the missing link. The result is not releasable (rule 7), and the gate
counts it unresolved, so it never "passes". Warnings come only from the pattern rules, each with a clean control.

The overseer agents get the info record as their screen (section D).

**A.8.3 How the translation marks a writer's link, and how an unmarked one is still found.**

*Marking* (b writes it into `translate/prompts/translate_v3.md`):

1. Every inferential step the writer asserts is its own premise. The writer may state it as a rule or imply it with
   "so", "because", "since", "therefore", "as ... shows", "which shows" or "this means". Such a premise has grounding
   kind `specialist_inference`, a `grounding.note` of the form `link: <the connective as written>`, and a label that
   quotes the writer's own words for the step.
2. A general rule the writer states from subject knowledge is `general_knowledge` with `note: "rule"`.
3. A rule the task or a text states carries that source's kind and the exact excerpt, so a check can verify it.
4. A step the writer never states is never added. The bridge search (ARG-NS-002) finds it.
5. A premise that restates the conclusion in other words uses the conclusion's symbol: one proposition, one symbol.
   E112 then decides it.
6. One word used in two senses gets two symbols, and an EQUIVOCATION ambiguity flag naming the word and both senses.
7. Scope words ("all", "every", "some", "most", "never") and causal verbs are kept in the meanings exactly as written.
   Instance facts keep their instance ("in Loftus and Palmer's study").
8. Every conclusion conjunct is linked to the claim's stated reasons. Otherwise the reading says it is unlinked.
9. Every premise of a task or text kind carries the excerpt, with `document_id` set to the supplied text or to
   `"task"`. A Bool task fact ("the forces on it are balanced") is quoted from the task.
10. Every constant the writer assumes (12 months a year) is stated as an `assumption` premise. The provider never
    writes `verified`.

*Recording* (`translate/roles.py`, Contract step): `premise_roles(problem, checks) -> list[PremiseRole]`.

| Field | Values |
| --- | --- |
| `role` | fact, link, either_or, definition, figure_relation; read from the expression, never from the label |
| `authority` | established, unverified, refuted, writer_own; read from `verified` and the kind |
| `marked` | `translator_link` (`specialist_inference` with a `link:` note), `translator_rule` (`general_knowledge`), `fact`, `unmarked_link`, `label_conflict` |
| `connective` | the connective from the note |

`unmarked_link` is a link-shaped premise with any other kind that no check verified. `label_conflict` is a link whose
label claims a source kind while no record states the relation.

*Finding an unmarked link*:

- R0 never uses the label to decide authority. A premise counts as verified only by `has_authority`.
- It counts as a link by its expression: an implication, a biconditional, a disjunction, or a numeric relation that
  combines symbols.
- So a link the translator labelled `task_setting`, `quotation` or `general_knowledge`, whose relation no source
  states, is still in W* and is still named.
- The grounding check already refuses to verify a numeric relation unless a record states it (`relation_in_source`).
  Fixer a extends the same rule to propositional compounds (B.1), so a quotation located for one atom no longer
  verifies an `and`, `or`, `if` or `iff` that joins it to the writer's own proposition.

**A.8.4 The closed cue tables.** Each is a tuple of lower-case token sequences, matched by `lexis.has_cue` on word
boundaries over a tokenised gloss or text, in time linear in its length.

| Table | Contents |
| --- | --- |
| open universal | all, every, always, never, none, no one, nobody, everyone, everything, any, each, in general, universally, without exception. It is not open when a number or number word follows within two tokens ("all three", "both", "each of the four") |
| instance | in X's study, in this case, one, a, this, the study, named studies, a year or date |
| causal | caused, causes, cause of, led to, leads to, resulted in, result of, due to, because of, responsible for, produced, brought about, the effect of, made X rise or fall |
| sequence | after, then, following, subsequently, since (with a date), before |
| control | random, randomly, randomised, randomized, control group, control, controlled, compared with, comparison group, matched, placebo, trial |
| frame words (paraphrase) | be, is, are, was, cannot, can not, upon, shown, the fact that, true, indeed, really, clearly, in fact |
| negation | not, no, never, cannot; the prefixes un-, in-, im-, il-, ir-, non- and dis- before an -able, -ible, -ful or -ent stem of 4 or more letters |
| stems | lower-case; strip -ing, -ed, -es, -s, -able, -ible, -ly; `ied` → `y`; after stripping, a final `i` → `y`. So "relied" and "unreliable" share the stem "rely", the second negated (f06b) |
| reason connective | because (not "because of"), since, so, therefore, thus, hence, given that, due to the fact that, which shows / means, this shows / means / suggests, as ... shows / suggests, as shown by, as seen in, as demonstrated by, as evidenced by |
| sense qualifier | scientific, everyday, ordinary, colloquial, legal, technical, mathematical, statistical, literal, figurative, biological, economic; any parenthetical; "in the ... sense" |
| trend verb | rose, risen, rises, fell, fallen, falls, increased, increases, decreased, decreases, grew, grown, grows, declined, declines, dropped, drops, climbed, doubled, halved, slowed, accelerated |
| attribution | Source [A-Z], the extract, the table, the text, the passage, the study, the source; followed by shows, suggests, states, says, reveals, indicates or proves (that) |
| authority or data cue | (leading, most, many, some) experts, economists, scientists, historians, researchers, psychologists, studies, research, surveys, survey data, statistics or data, followed by agree, show(s), suggest(s), prove(s), confirm(s), indicate(s), or have/has shown; also "it is widely / generally / commonly accepted / agreed / known / believed" and "according to experts / research / studies". A named author with a year is not anonymous |
| extrapolation caveat | extrapolat, outside the (measured) range, beyond the (data, range), assuming the trend continues, may not hold, if the trend continues |
| quotation mention frames | without, with no, instead of, rather than, never uses, does not use, no; the function words like, as, and, but, or, the, a, an, of, to, in, so, if, because |

The tables are data. A unit test pins each one. Changing a table in `engine/argument_cues.py` or `lexis.py` changes
`build_id`. Changing one in the evidence module changes the translator version.

### A.9 The Contract step: files and tests

**Files**, created or edited once, then frozen or handed to their owner:

| Kind | Files |
| --- | --- |
| Created and frozen | `named.py`, `lexis.py`, `translate/roles.py`, `translate/diag_core.py` |
| Created as stubs, handed over | `engine/argument.py` (b: `diagnose()` returns no diagnostics and `"argdiag-1"`); `translate/diag_argument.py` (b: `RULES = ()`, `REPORT_RULES = ()`); `translate/diag_evidence.py` (a: the same, and `source_bound()` returning False) |
| Edited and frozen | `version.py`, `engine/identity.py`, `engine/results.py`, `engine/runner.py`, `engine/release.py`, `translate/contracts.py`, `translate/outcome.py`, `integrity/contracts.py` |
| Edited, then handed to the owner | `translate/pipeline.py` (b: premise roles, `asserted_verified` plumbing, `_stated_figures` with diagnose=False); `translate/precision.py` (b: three probes with diagnose=False); `translate/parsing.py` (a: the stub `asserted_verified_paths()`); `adapters/markdown.py` (a: the stub `quotation_role()` returning "quotation", and `cited_quotation_spans()`); `integrity/cross_check.py` (c: diagnose=False); `branches/base.py` (c: `FormalCheck.defect`); `channel/contracts.py` (d: the receipt field); `channel/bus.py` (d: diagnose=False on three calls, DEFECT_OF_CODE, `FormalCheck.defect` onto INT-SUBJ-001 and 004, INT-ARG-001, `receipt.named_diagnostics`, the report-level hook, the summary line); `docs/integration-contract.md` (d: the section "Named diagnostics") |
| Test data, frozen | `tests/data/argdiag_dev_cases.json` (the dev corpus cases as data, with no scratch paths and never the holdout) and its loader `tests/argdiag_cases.py` |

**The quotation call sites.** Every call that checks or attributes a quoted span's words against a source switches to
`cited_quotation_spans`:

- the quotation checks in `bus.py`;
- the synthesis quotations in `ledger.py`;
- the CORE-SRC checks in `packs.py`;
- the attribution lookups in `sources.py`;
- the evidence-reference builders of the parsers (`english_specialist/parser.py`, `history_specialist/parser.py`,
  `branches/generic_parser.py`, `stem_specialist/parser.py`).

Every call that masks text or tests a position keeps `find_quotation_spans`, so masking still covers every quoted span.
With the stub both functions return the same spans, so behaviour is unchanged. Fixer a then fills in the roles in
`markdown.py` alone.

**Tests** (in `tests/contract/`):

1. The model: the 28 labels equal the canonical list; every NAMED_CODES entry has a canonical label, a layer and an
   owner; `named_diagnostic()` lowers a severity but never raises it; `cap()` sets `capped_from`; `merge()` is
   deterministic; dumps leave out empty optional fields.
2. No Z3: in a fresh subprocess, importing `epinoic_logic.named` and `epinoic_logic.lexis` leaves neither `z3` nor
   `epinoic_logic.engine` in `sys.modules`.
3. Result fields:
   - a result from `verify()` carries `argument_rules == "argdiag-1"` and no `named_diagnostics` key while it is empty;
   - a golden result of the previous release re-serialises byte-identically;
   - editing or removing `named_diagnostics` breaks `verify_signature`.
4. Release:
   - a `diagnose=False` result is refused by rule 9;
   - a stub rule injected in the test (monkeypatched `argument.diagnose`) that emits a warning is refused by rule 8;
   - the same warning capped to info is still refused (effective severity).
5. Display: the section text; no success words; "none found", "incomplete" and "not computed"; at most 6 lines; the
   scope statement last.
6. Receipt plumbing:
   - a warning on a material claim gives exactly one INT-ARG-001 with its `defect`;
   - an info diagnostic gives none and leaves an otherwise clean receipt ACCEPTED;
   - each DEFECT_OF_CODE row has a positive case, and one unmapped code is the control;
   - `FormalCheck.defect` reaches INT-SUBJ-001;
   - the report-level hook runs once per report.
7. Premise roles: each kind and shape; `unmarked_link` and `label_conflict`.
8. The quotation stub: `cited_quotation_spans` equals `find_quotation_spans` on the existing quotation fixtures.
9. Probes: a spy on `verify` shows the internal probes pass diagnose=False and `verify_claim` does not.

Acceptance of the Contract step:

- the full suite passes, and any test rewritten to a stricter rule is listed;
- the dev corpus verdicts are unchanged from the Phase 0 run, because every rule is still a stub.

---

## B. The four fixers

### B.0 Order and ownership

Three steps run in order:

1. **Phase 0 (fixer c, sequential).**
   - Merge `review-stem-checks`, then `review-stem-channel`, onto the branch head. If 0d28eba has landed, base the
     merge on it.
   - Resolve `docs/STEM_DESIGN.md` by keeping both section 21s and renumbering the second as 22.
   - Fix the semantic interaction of 0.1 at its cause (B.3).
   - Run the five review test files, then the full suite, and commit:
     - `tests/stem/test_review_stem_checks.py`;
     - `tests/channel/test_stem_review_coverage.py`;
     - `tests/channel/test_relay_history.py`;
     - `tests/branches/test_stem_review_claim_map.py`;
     - `tests/integrity/test_stem_review_ledger.py`.
2. **The Contract step** runs on top of that commit and writes A.2 to A.9 once. The order matters:
   `review-stem-channel` edits `channel/bus.py`, `channel/contracts.py`, `integrity/ledger.py` and `stem/hub_hooks.py`,
   which the Contract step and fixers a and d also edit.
3. **Fixers a, b, c and d in parallel**, each on its own branch from the Contract commit. Then the integration step
   merges them and measures.

If the workflow cannot run Phase 0 first, the Contract step performs the merge as its first commit, on c's behalf, and
c re-runs those tests and fixes the interaction as its first action.

A fixer that needs a change in a frozen file, or in a file it does not own, does not make it. It writes the exact change
into its handoff, and the integration step applies it. Every test file a fixer creates is its own. No fixer edits
another fixer's tests.

| Fixer | Owns (beyond its new test files) |
| --- | --- |
| a | `engine/authority.py`, `engine/validator.py`, `engine/procedures.py`, `engine/errors.py`, `ir/schema.py`, `translate/grounding.py`, `translate/quantities.py`, `translate/parsing.py`, `translate/diag_evidence.py`, `service/app.py`, `service/settings.py`, `adapters/markdown.py`, `adapters/sources.py`, `integrity/ledger.py`; docs `engine/README.md`, `translate/README.md`, `service/README.md`, `adapters/README.md`, `integrity/README.md`, `REVIEW_FIXES_README.md` (append); existing tests `tests/engine/test_round7_engine.py` (one test rewritten) and `tests/engine/test_pack_policies.py` (two xfail markers removed) |
| b | `engine/argument.py`, `engine/argument_cues.py` (new), `engine/ARGUMENT.md` (new), `translate/diag_argument.py`, `translate/pipeline.py`, `translate/precision.py`, `translate/subjects.py`, `translate/prompts/translate_v3.md` (new), `translate/prompts/__init__.py`, `adapters/english_specialist/structural.py`, `translate/ARGUMENT_DIAGNOSTICS.md` (new) |
| c | `stem/*` (including the new `stem/reference.py` and `stem/reference_data.py`, `stem/README.md` and `stem/ENCODINGS.md`), `branches/stem_pack.py`, `branches/packs.py`, `branches/quant.py`, `branches/base.py`, `branches/README.md`, `adapters/stem_specialist/*`, `integrity/cross_check.py`, `docs/STEM_DESIGN.md`, `docs/STEM_RESULTS.md` |
| d | `channel/bus.py`, `channel/request_parser.py`, `channel/contracts.py`, `channel/cues.py`, `channel/gate.py` (new), `channel/README.md`, `scripts/arena/run_arena.py`, `scripts/arena/README.md`, `docs/integration-contract.md`, `README.md` (top level) |

No file is in two rows. After the Contract step these are read-only for every fixer:

- the frozen files of A.9;
- `adapters/english_specialist/parser.py`, `adapters/history_specialist/*`, `branches/generic_parser.py`,
  `branches/hub.py`, `branches/registry.py`;
- `translate/coverage.py`, `assertion.py`, `relations.py`, `eligibility.py`, `review.py`, `common.py`, `providers/*`;
- `engine/policies.py`, `compiler.py`, `statuses.py`, `provenance.py`;
- `integrity/handoff.py`, `envelope.py`, `cli.py`;
- `docs/AUDIT.md`, `docs/STATUS.md`, `docs/DESIGN.md` and `docs/IMPLEMENTATION_PLAN.md`, which the integration step
  updates.

**One deliberate deviation from the family split.** The c03-psych PS-SRC-001 false alarm belongs to the evidence family
(a's), but it lives in `branches/packs.py`, which c owns for B25. So c fixes it, and no file has two owners.

### B.1 Fixer a: unchecked sources, security, and the evidence-family false alarms

**Issue 1: only a check in this process confers authority**

1. `engine/authority.py`: `assumed_grounding(g) = not has_authority(g)`. Any premise that no check established is the
   writer's own *for circularity*. `dependency_policy()` gains `"assumed_for_circularity": "not_established"`.
   - This changes E112 in the runner and the pipeline's `_circularity` refusal together, because both import it.
   - A verified task setting, rubric rule or text excerpt stays a transcription.
   - p proves p with `task_setting`, `rubric_rule`, `supplied_text` (no excerpt) or `knowledge_document` becomes E112.
2. `translate/grounding.py::_check_authority`: a figureless task-kind premise with no excerpt is **unvalidated**
   (`verified=None`, detail "no excerpt and no figure: no record was checked"), never refuted. Refutation is kept only
   for a stated conflicting figure.
   - This removes the GROUNDING:FAILED false alarms on c02-mt and c03-dich, and the same noise on f03, f03b and f04.
   - Together with item 1, the label-only circle stays caught.
3. `translate/grounding.py::_check_assertion`: a located excerpt verifies a propositional premise only when the premise
   is a literal (an atom or its negation). For an `and`, `or`, `implies` or `iff` of propositions:
   - the result is `verified=None`;
   - a new `relation_in_source` check records the detail "the excerpt states '<atom>'; the connective joining it to
     '<other>' is the writer's own".

   f07 is then refused as circular. A compound whose every atom is a literal premise verified separately is unaffected,
   because each literal keeps its own check.
4. `translate/parsing.py::asserted_verified_paths(raw)`: the paths of every `verified` key in the provider's groundings,
   from the parsed JSON object (a walk over dicts and lists, bounded by the parse limits). It feeds EVD-SRC-004 and the
   E505 translation diagnostic (A.4.2).
5. `adapters/markdown.py::SELF_CERT_RE`: widen it to "I have verified / checked / confirmed (it) against", "verified
   against", "checked against" and "confirmed with". CORE-SELF-001 (CorePack, in c's file, unchanged) then fires on
   e08a, labelled unchecked_source through DEFECT_OF_CODE.
6. `translate/diag_evidence.py`:
   - `RULES`: EVD-SRC-001, EVD-SRC-003, EVD-SRC-004, EVD-LACK-001, EVD-FIG-001, EVD-AUTH-001 and EVD-CHERRY-001;
   - `REPORT_RULES`: EVD-SRC-002 and EVD-LACK-002;
   - `source_bound()` (A.4.3).

   Located-text tests use the grounding locators (`locate_quotation`, `quantities.literal_matches`) and `lexis`.

**Evidence-family false alarms**

- `integrity/ledger.py`, INT-LEDGER-020. The dict `have = {(document, locator): ref}` keeps one excerpt per key, so
  two excerpts of one table with no locator ("2022: 6.4%", "2023: 3.9%") read as altered. The fix compares, per key,
  the *set* of excerpts: an excerpt is preserved when it occurs among the synthesis's excerpts for that key. This
  removes the INT-LEDGER-020 false alarms:
  - c01-econ and c01b-econ (report and merged modes);
  - c02-hist (text and merged);
  - c03-psych (report and merged);
  - c04-eng (merged).
- PS-SRC-001 on c03-psych (text mode) is fixed by c (B.0). a's handoff checks that it is clean.

**End-to-end items**

- **B5 and B6.** `adapters/markdown.py::quotation_role(text, start, end)` gives each quoted span one role, and
  `cited_quotation_spans()` returns only role `quotation`. The call sites already route through it (A.9).

  | Role | When |
  | --- | --- |
  | `quotation` | the default |
  | `correction` | the span follows `→`, `->`, `=>`, "should be", "becomes", "change to" or "correct form:", or sits under a "Model:", "Corrected:" or "Better:" label (B5: the right-hand side of each arrow) |
  | `suggestion` | the span follows "you could write / add / use", "try", "instead write", "add", or "Suggestion" (B5 'para ayudar') |
  | `mention` | a quoted function word from the closed list (A.8.4), or any quoted span after a negating frame (B6: `without "like" or "as"`, `with no "like" or "as"`) |

  A content word under "the word" or "the verb" stays a quotation, so "the verb 'smashed'" is still checked. A span
  with another role is recorded as the writer's own words, with no source reference. It is never presented as a
  quotation, and if the writer attributes it to a text with a citation, the citation is checked as before.
- **B16, grounding half.** In `translate/grounding.py` (`_figures_check`) and `translate/quantities.py`
  (`stated_intervals`, `literal_matches`), a premise interval grounds when it equals the half-unit enclosure of a
  figure the excerpt states, closed or half-open at either end. The recorded derivation reads "1.259 states [1.2585,
  1.2595) at its written precision".
  - This covers ×10ⁿ in superscript and caret forms ("6.31 × 10⁻⁹", "6.31×10^-9") and figures after "≈" or "about".
  - Wider or narrower intervals still fail.
  - Exactness of the claim's own figure is precision's decision (b), not grounding's.
- **B23.** A figure the *request* states (the student's own 1,800 or "9 %"), cited as a quotation of a supplied
  document that does not hold it, is re-checked against the task record.
  - If the task record states it, the check verifies it as task material (`method="numeric_in_task"`, detail "stated by
    the request, cited as doc-luma") and does not refute it.
  - This respects the request-figure rule of the parallel repair: a request figure verifies a premise only where the
    request states it as a given, never inside a question, a negation or an answer requirement.
  - "9 %" grounds 0.09 through the existing per-cent derivation, and the B23 test pins it.
  - An unstated constant (12 months) stays unverified, and the v3 prompt asks for it to be stated as an assumption.
- **B26.** In `ir/schema.py`, `IDENT_RE`, `ASSERTION_ID_RE`, `INT_RE`, `RATIONAL_RE` and `DECIMAL_RE` are applied with
  `fullmatch`. Then grep `src/` for `re.match` or `^...$` validators of untrusted text and convert them the same way.
  Remove the strict xfail marker on `test_trailing_newline_is_not_part_of_an_identifier_or_literal` (three
  parametrised cases): the test is unchanged and now passes, which is the stricter behaviour.
- **B27.** In `engine/validator.py::_decode_text`, `raw.encode("utf-8")` sits in `try/except UnicodeEncodeError`,
  giving E100 "payload contains a lone surrogate". Remove the strict xfail on
  `test_a_lone_surrogate_in_a_text_payload_is_an_invalid_formalization`.
- The security fixes are listed in section C.

**Tests rewritten to a stricter rule** (the handoff says so):

- `tests/engine/test_round7_engine.py::test_a_restated_task_setting_is_a_transcription_not_a_circle` becomes two
  tests:
  - (i) with the task record and `check_problem_grounding`, `mk1` is verified and there is no E112;
  - (ii) the same problem label-only (verified None) gives E112.
- Any test pinning `verified=False` for a figureless task premise, or `verified=True` for a quoted compound premise,
  is rewritten to the new outcome, with the reason in its docstring. A grep at 22d6a5b found none besides the round-7
  test.

**New tests** (positive and control, for each label and each fix):

| Test file | Positive | Control |
| --- | --- | --- |
| `tests/engine/test_authority_circularity.py` | p proves p under each of the seven non-writer kinds, label-only, gives E112 | each with a verifying check gives none |
| `tests/translate/test_unchecked_sources.py` | e04a and e08b give EVD-SRC-001 at warning (source-bound); e08b gives EVD-SRC-004 and the E505 translation diagnostic | c02-mt and c03-dich (task facts, not source-bound): info only, and **no** GROUNDING:FAILED; a proposal without `verified` gives no EVD-SRC-004 |
| `tests/translate/test_evidence_diagnostics.py` | e01 lack_of_evidence; e02 invented_figure; e05a and e07 uncheckable_authority; e06a and e06b cherry_picked_data; e03 and e04b source_mismatch | c01-econ, c01b-econ, c02-hist, c03-psych, c04-eng, i00, i02c, s04c: no evidence warning; a figure the answer calculates from the extract's figures gives no EVD-FIG-001 |
| `tests/translate/test_evidence_report_rules.py` | text-mode e01 (EVD-LACK-002), e04a and e08b (EVD-SRC-002) | c02-hist (located quotations), c01-econ (figures), i02c (subject in the extract), a trend verb inside quotation marks |
| `tests/translate/test_joined_quotation.py` | f07 is refused as circular (INVALID_FORMALIZATION with E112) | c04-quote (a verified atomic quotation plus links) stays ENTAILED with no E112 |
| `tests/adapters/test_quotation_roles.py` | e2e-B5-sp corrections and 'para ayudar'; e2e-B6-en `without "like"` | an invented single content word quoted after "the word" still gives INT-REQ-003; an altered quotation still gives INT-REQ-003; masking still covers a correction span |
| `tests/translate/test_stated_precision_grounding.py` | the ess q_h81, q_h82 and q_ratio forms and "≈ 1.55" ground | `[1.25, 1.27)` for "1.259" fails; `[1.2580, 1.2595)` fails |
| `tests/translate/test_request_figures_b23.py` | bm 1,800 and 9 % ground as request figures | a figure in no record still fails; a request figure inside a question does not verify |
| `tests/integrity/test_ledger_excerpt_sets.py` | an altered excerpt under the same key still gives INT-LEDGER-020 | c01-style two excerpts per document give none |
| `tests/service/test_security_round8.py` | section C | section C |

The cases come from `tests/data/argdiag_dev_cases.json` (A.9).

### B.2 Fixer b: formal and informal fallacies, R0, prompt v3, and the B8, B21 and B22 false errors

**Engine** (`engine/argument.py`, `engine/argument_cues.py`)

- R0 exactly as in A.8.1, plus every engine-layer rule of A.3 with its precedence and bounds, and the cap of A.4.1.
- Pattern rules decide only from the bound problem: expressions, recorded kinds and verified flags, meanings and
  labels, plus derived runs.

**Claim and report rules** (`translate/diag_argument.py`)

- `RULES`: ARG-EQ-001, which reads `interpretation.ambiguity_flags`.
- `REPORT_RULES`: ARG-BARE-001.

**Pipeline** (`translate/pipeline.py`), after `_process` accepts an attempt. Each flag is an `AmbiguityFlag` that sets
AMBIGUOUS_TRANSLATION; the engine still runs for inspection, and `verify_claim` passes the cap.

1. **B8, UNLINKED_CONJUNCT.** At least one conclusion conjunct shares no symbol with any premise, and at least one
   other conjunct does. Message: "the conjunct(s) '<glosses>' share no symbol with any premise: the encoding gives them
   no reason, so it cannot decide the claim as written". The six ps counterexamples and en p4-point are no longer
   displayed as COUNTEREXAMPLE, and ARG-PART-001 (info) names each judgement.
2. **B8 guard, UNENCODED_REASON.** Every conjunct is unlinked (the f01 shape), but the claim's own text holds a
   reason-connective clause (A.8.4) that shares fewer than 2 content stems with every premise label and meaning. The
   claim gave a reason the translation left out. f01's "because of the Treaty" is a cause phrase, not a reason clause,
   so f01 stays COUNTEREXAMPLE with ARG-NS-001 (warning).
3. **B21, PARTIAL_ENCODING.** The claim text splits at "but", "however", "although", "while", "whereas" or ";" into
   clauses. One clause has 3 or more content stems, none of which occurs in the conclusion label, the conclusion
   symbols' meanings or any premise label. The summary says "the encoding covers only: '<clause>'". A partial encoding
   is never displayed as the whole claim.
4. **The circularity message.** `_circularity` names the rule as "premise(s) ... restate the conclusion, and no check
   in this process established them (whatever their label)", to match fixer a's authority rule.

**Precision** (`translate/precision.py`)

- **B22.** An interval premise is tied to a stated figure when its range lies inside exactly one stated figure's
  rounding interval in the claim or a supporting claim. The figure must have the same unit, or a symbol meaning that
  names the same quantity. The stated-precision rule then applies: a narrower or wider interval that changes the
  verdict is rejected, with the stated bounds fed back once. s7.2's `[2,294,000, 2,298,000)` against "2.3 × 10⁶"
  (2 s.f.) is rejected.
- **B16, precision half.** An interval equal to the stated enclosure except for the closure of one end ("[1.545,
  1.555]" against "[1.545, 1.555)") is accepted when one derived run gives the same verdict under both closures. h1.2
  (hi) is then decided, not rejected.

**Formal and informal false alarms**

- `adapters/english_specialist/structural.py`: `structural_checks` runs `strand_findings` (ES-STR-001, two strands per
  body paragraph) only when the task type is an analytical paragraph or essay, or the request asks for a paragraph or
  essay (it already receives `request_text`). That clears c04-quote's short-answer false alarm and f07's.
- The INT-REQ-004 on c04-quote and c03-dich belongs to d (B18).

**Prompt v3** (`translate/prompts/translate_v3.md`, `TRANSLATE_PROMPT_VERSION = "translate_v3"`)

- v2's text, plus the ten marking rules of A.8.3.
- `translate/subjects.py` profile texts gain one line each on scope words and causal verbs for argued subjects.
- The text is the project's own wording. Nothing is copied from NL2FOL or any other project.

**New tests**

| Test file | Positive | Control |
| --- | --- | --- |
| `tests/engine/test_argument_diagnostics.py` | every engine code on its corpus problem: f01 NS-001; f02 NS-002 with missing link e_dir ⇒ vel_changes; f03 and f03b AC-001; f04 DA-001; f04b (new, "not P, so not Q") DA-001; f05 CONTRA-001; f06 and f07 CIRC-001; f06b CIRC-003; f08 VAC-001; f09 and f09b HG-001 (NS-001 suppressed); f10 FD-001; i02 CL-001; i03a EQ-003; i03b EQ-002; e06b REFUTE-001; f01b LINK-001 at info with the missing link; a constructed "either P or Q, so P" INV-001; a constructed equivalence restatement CIRC-002 | c01-mp, c02-mt, c03-dich, c04-quote, c05-chem, c02-hist, c03-psych, c04-eng, i00, i02c: no warning. c03-dich gives no FD-001; i02c gives no CL-001; c04-quote gives no CIRC-003; a biconditional stated in both directions gives no AC-001; "all three parts are correct" gives no HG-001; a bridge between two meanings with one head noun and no sense marker gives NS-002, not EQ-002; a symbol whose qualified meaning is used consistently gives no EQ-003 |
| same file: bounds, caps and determinism | a 128-premise all-unverified problem stays within the budget, and a budget of 0 records "incomplete" with no rule fired; two runs give identical diagnostics; a derived TIMEOUT fires nothing; with `severity_cap` a warning becomes info with `capped_from="warning"`, inside the signature | — |
| `tests/translate/test_argument_rules.py` | i03b ARG-EQ-001; i01 and i01b ARG-BARE-001 in both modes (report rule, no outcome needed) | an ambiguity flag with another code gives no ARG-EQ-001; i01c (a supported judgement), c03-dich and f06's text mode give no ARG-BARE-001 |
| `tests/translate/test_partial_encodings.py` | B8: all seven e2e counterexample shapes give AMBIGUOUS with UNLINKED_CONJUNCT, and ARG-PART-001 at info | f01 stays COUNTEREXAMPLE with ARG-NS-001 at warning |
| same file | UNENCODED_REASON: a claim "X, because Y" with Y unencoded gives AMBIGUOUS | the f01 control above |
| same file | B21: a g4.1-shaped claim with only its first clause encoded (otherwise valid) gives AMBIGUOUS with PARTIAL_ENCODING | both clauses encoded gives TRANSLATED |
| `tests/translate/test_precision_b16_b22.py` | B22: s7.2 rejected with the stated bounds | the stated-precision interval is accepted |
| same file | B16-hi: the closure variant is accepted when it changes no verdict | a closure variant that changes the verdict is still rejected |
| `tests/translate/test_prompt_v3.py` | v3 is packaged, v1 and v2 are byte-identical, the version is bound into ProviderInfo, the ten rules are present | — |
| `tests/adapters/test_english_strands_scope.py` | ES-STR-001 on an analytical paragraph | none on a short answer (c04-quote) |

### B.3 Fixer c: STEM reference knowledge and the STEM false errors (Phase 0 first)

**Phase 0** (B.0), then the interaction of 0.1:

- In the merged tree, a genuine one-line answer ("1/2 = 0.50", "x = ±2", "|-2| = 2") to a one-item request no longer
  addresses its item, so INT-REQ-004 turns the receipt to ACCEPTED_WITH_FINDINGS.
- c finds the cause in the coverage rules `review-stem-channel` added, most likely the STEM coverage hook in
  `stem/hub_hooks.py` or its use in `channel/bus.py`. An answer that computes from the item's own figures or notation
  addresses the item.
- c fixes it so that both review test files pass unchanged, and `test_stem_review_coverage.py` keeps rejecting
  unrelated arithmetic.
- No test of either branch is weakened. Since Phase 0 runs before the ownership split, this fix may touch `bus.py`.

**Closed reference** (`stem/reference_data.py` as data, `stem/reference.py` as readers, both following the pattern of
`stem/constants.py`)

- `QUANTITIES`: (symbol, IB subject profile(s), quantity name, dimension, SI unit, ambiguous-with). Examples:
  - E_k → kinetic energy, J;
  - p → momentum, but ambiguous with pressure;
  - v → velocity;
  - F → force;
  - a → acceleration;
  - P → power, but ambiguous with pressure;
  - V → potential difference, but ambiguous with volume;
  - Q → heat, but ambiguous with charge;
  - c → specific heat capacity, but ambiguous with the speed of light;
  - T → temperature, but ambiguous with period;
  - λ, f, ρ, I, R and the rest of the guide's symbols.
- `FORMULAS`: (quantity, profile, the data-booklet right-hand side as a small expression tree over reference symbols,
  its dimension). Examples: E_k = ½mv², p = mv, F = ma, W = Fs, P = W/t, V = IR, Q = mcΔT, E_p = mgh, v = fλ, ρ = m/V,
  n = m/M and pH = −log[H⁺].
- Every entry is exact data, built from `units.Dimension`. Nothing is evaluated.
- A quantity's identity is fixed only when all of these hold:
  - the symbol is unambiguous in the profile, or the stated result's unit decides it, or the request names it
    ("Calculate its kinetic energy");
  - the dimension guard agrees.

  Otherwise no ST-REF-001 is emitted.

**New checks** (the A.3 rows)

- ST-REF-001; ST-UNIT-003 in both cases (on an INT-SUBJ-001, set `FormalCheck.defect="stem_unit_error"`).
- ST-STEP-001 and ST-STEP-002.
- ST-ROUND-001, ST-RANGE-001, ST-WORK-001, ST-GIVEN-002 and ST-SCOPE-002.
- "Units carried through symbolic evaluation with exact scale factors" is mostly done by review fix 2 (0.1). c extends
  it to ST-UNIT-003's bare-number case.
- The ST-DIM-001 coefficient fix: `0.5 × m × v` and `m × v / 2` are dimensionless-scaled like `½mv`.
- The steps run under the engine's identity check: a satisfiability check of `lhs_next ≠ lhs_op` under the stated
  domain guards, where UNSATISFIABLE means identical.

**B2 classes** (one regression test per quoted sentence of E2E §6.1)

| Class | Example | Fix |
| --- | --- | --- |
| a count noun before an operator | "4 categories − 1 = 3" | read as 4 − 1, or withhold; never "− 1 = 3" |
| a mixed-unit compound | "4 min 30 s = (4×60+30) s" | read as 270 s |
| scientific notation in a ratio | "5.166 × 10⁵ J / 5.94 × 10⁵ J = 0.870 (87%)" | `m × 10ⁿ` binds as one atom inside a division |
| a chain cut at "…" or `\ldots` | maa m2.5, m4.2 | the trailing ellipsis continues the side; the stated value is a truncation, so its interval is [v, v + one unit of the last place) |
| a figure from another chain | ch "0.1 pH"; ess "26 %"; ess "1" from "(1.259 − 1)" | a restatement must be of the same quantity: same symbol, unit or chain; a figure inside a parenthesised operand is never a restated result |
| bit groups | cs "1011 is B and 0110 is 6" | digit groups in a base-conversion context are numerals of that base |
| a quoted failing test | cs "the final test (2 <= 1) fails" | a comparison followed by "fails", "is false" or "no" is negated, or mentioned |
| a pair whose end is an expression | ec "falls from $1.60 to $2.00 − $0.60 = $1.40" | read the end after the written arithmetic, or withhold (`branches/quant.py`) |

**Other end-to-end items**

- **B7**, `integrity/cross_check.py`. Two claims may *derive* one symbol by different routes, each stating it at a
  precision (FigureReading `rounded` or `calculated`), as ph s2.1 and s2.2 do at 24.0 Ω. Such a symbol is either pooled
  as the stated value's interval, or renamed apart per route (in the style of `split_by_gloss`) with the cross-claim
  relation `|R1 − R2| ≤ h1 + h2`. INT-CONFLICT is then charged only when the stated values disagree beyond their
  stated precision.
- **B17.** STEM claim ids are namespaced by agent (`s1.1@<agent>`) whenever two agents deliver in one task, as the
  generic branch does. A test first reproduces INT-REQ-016 on two STEM reports.
- **B25**, `branches/packs.py` and `branches/quant.py`:
  - CorePack sends the worked equations (`=` chains) of the non-STEM branches through the STEM chain checker
    (`stem.build_document` and `build_checks` on the equation lines, under the STEM tolerance rule) instead of
    reporting CORE-QNT-001 "not decided". This covers bm, ec, ge and ps.
  - A derived figure that a supplied text states word for word ("fell by 30%" in i02c's extract) is a transcription,
    not the writer's arithmetic, so it gets no CORE-QNT-001.
- **PS-SRC-001** (an evidence false alarm in c's file): a study attribution whose author and year occur in a supplied
  text is grounded by that text, so it gets no PS-SRC-001 (c03-psych in text mode). A named study in no text (e05b)
  still fires.

**New tests**

| Test file | Positive | Control |
| --- | --- | --- |
| `tests/stem/test_review_merge_interaction.py` | the 0.1 one-line answers address their item on the merged tree | unrelated arithmetic still leaves the item unaddressed |
| `tests/stem/test_reference_formulas.py` | s02, s02b ST-REF-001 | s00 clean; an ambiguous p with no unit gives no ST-REF-001 |
| `tests/stem/test_units_symbolic.py` | s03a ST-UNIT-003; s03b and s03d labelled stem_unit_error | s03k and s03dk clean |
| `tests/stem/test_steps_operations.py` | s05 ST-STEP-001; an unguarded division gives ST-STEP-002 at info | s05c clean |
| `tests/stem/test_rounding_range_working.py` | s04 ST-ROUND-001; s07 ST-RANGE-001; s08 ST-WORK-001 | s04c, s07c, s08c clean; an extrapolation with a caveat is clean |
| `tests/stem/test_givens_symbols.py` | f05b ST-GIVEN-002; s06 ST-SCOPE-002 | c06-givens and s06c clean; a rebinding in part (b) is clean (part scope) |
| `tests/stem/test_e2e_b2_classes.py` | the twelve sentences: no error each | a wrong twin of each still fails |
| `tests/integrity/test_pooled_precision_b7.py` | 24.033 and 24.045, both stated 24.0, give no INT-CONFLICT-001 | 24.0 against 26.0 still conflicts |
| `tests/branches/test_stem_ids_b17.py` | two-agent STEM ids are distinct | single-agent ids unchanged |
| `tests/branches/test_core_equations_b25.py` | a wrong worked line in Business gives INT-SUBJ-001 | correct lines are decided with no CORE-QNT-001; i02c gives no CORE-QNT-001; e05b keeps PS-SRC-001 and c03-psych has none |

### B.4 Fixer d: the channel and the response gate

- **B3.**
  - `scripts/arena/run_arena.py::relay_peer` writes only the delivered payload into `relayed/<task>.json`, which the
    dependent specialist reads. The router-side receipt goes to `relayed/<task>.router.json`, which is never part of a
    specialist bundle.
  - A new channel check, INT-REQ-017 (warning), in `bus.py`. A delivered answer gets it when its supplied texts include
    a peer document and it states a system check result as content. The closed phrase list: "a formal check", "the
    check (failed|holds)", "INT-", "engine", "counterexample", "the receipt", "was flagged", "do not copy those". The
    finding names the sentence.
- **B4.**
  - `Constraint.scope` is added in `channel/contracts.py`, with
    `{kind: whole|part|each_part|answer_proper|paragraph, parts: [labels]}`.
  - `request_parser.extract_constraints` binds each bound to its scope:
    - a part label leading its sentence or its request part ("(e) under 150 words");
    - "each" over the listed parts ("(e) and (f) under 120 words each");
    - "for the answer" or "the answer" excludes plan or outline blocks;
    - "the paragraph" or "ONE ... paragraph" applies to the paragraph, not to side answers.
  - "N words max" and "max N words" are recognised.
  - `bus._constraints` measures the scoped span: the answer's own part sections by label, each part separately for
    "each", and plan blocks left out for the answer proper.
- **B19.** One meta-text classifier, `request_parser.is_meta_text(block)`, is shared by `count_paragraphs` and
  `measure_answer_words`. It recognises "Limit:", "Word count:", "(249 words)", "Next step:", "Note:" and a trailing
  one-line note.
- **B18.**
  - An item with no command term, no question mark and no imperative is a stem, not an item: "Selvaria has ...", "1.
    Priya buys a car ...", "2. The Python code ... is pasted below.".
  - A bare part label ("(a)") is no item.
  - A part-labelled item is covered by the answer's section with that label.
  - A table or truth-table block counts for "construct the table".
  - A meta-instruction about the response language or format is no content item ("Explain in English pls").
  - A request with exactly one item and an answer with a material claim (and not INT-REQ-011 or INT-REQ-012) has that
    item addressed. This clears c03-dich, c04-quote and i02c.
  - Stems match y to ies (burglary, burglaries).
  - **The lost word.** `strip_constraint_spans` removes only the constraint's own words. "Please quote my exact words"
    is an instruction that keeps "quote", and the constraint `must_cite_supplied_text` is still extracted.
- **B13** (the new `channel/gate.py`):
  - `assess_response(receipts, synthesis_receipt=None, *, synthesis_required: bool, threshold=0.90) -> ResponseGate`.
  - It classifies every check as passed, failed or unresolved:

    | Situation | Classification |
    | --- | --- |
    | a positive display whose engine result rests on no ungrounded or unverified dependency and carries no warning diagnostic (by effective severity) | passed |
    | an ENTAILED that rests on any ungrounded or unverified premise | **unresolved** |
    | COUNTEREXAMPLE or INCONSISTENT displays; findings with a `formal_result_id` of a definitive engine result; deterministic source-integrity errors (INT-REQ-003, CORE-SRC-005, INT-LEDGER-025) | failed |
    | heuristic findings (INT-REQ-004, *-STR-*, CORE-QNT-001, INT-GLOSSARY-005, INT-XENC-001) | unresolved, never failed |
    | warning-level named diagnostics | unresolved |
    | AMBIGUOUS, UNSUPPORTED, INVALID or NOT_ELIGIBLE | unresolved, or not required |

  - The synthesis check exists only when `synthesis_required` (the plan routes to a combinator).
  - VERIFIED needs every required check passed. DELIVERED_UNVERIFIED needs accuracy (passed / (passed + failed)) above
    the threshold, and is never labelled checked. Otherwise the answer is WITHHELD.
  - It never raises, and its invariants match the scratch harness's (re-implemented in the repository, never imported
    from scratch).
- **B15.** `docs/integration-contract.md` §2 and the HTTP row state both behaviours:
  - in process, a `verified: true` payload is discarded with E505;
  - over HTTP, `POST /v1/verify` refuses it with 400 E505 before anything runs. The refusal is kept because it is
    stricter.

  A test pins both, and the contract text names the test.
- **B20.** In `bus._finish`: a claim may carry both a branch formal check and a translation outcome. When one definitive
  answer passes and the other fails, add INT-XENC-001 (warning) naming both result ids. The gate treats that claim as
  unresolved. The INT-SUBJ-001 error is kept, not demoted.

**New tests**

| Test file | Positive | Control |
| --- | --- | --- |
| `tests/channel/test_constraint_scopes_b4.py` | the bm, ec, ps, en and hi bounds are measured on their scope: no error | a genuinely over-length (e) part still gives INT-REQ-005 |
| `tests/channel/test_meta_text_b19.py` | the ll-e1 note is not a paragraph | two real paragraphs still give the warning |
| `tests/channel/test_request_items_b18.py` | the ten B18 items; "quote" kept; the single-item rule on c03-dich, c04-quote and i02c | an unaddressed real part still warns |
| `tests/channel/test_response_gate_b13.py` | the B13 decisions of E2E §3 for ll, sp, lit, ec, ps: delivered, not verified, once the false findings are gone; the fast path needs no synthesis | a COUNTEREXAMPLE answer is withheld; an ENTAILED resting on an unestablished premise is never VERIFIED; a capped warning still counts unresolved; the invariants |
| `tests/channel/test_relay_b3.py` | the relayed file has no `peer_receipt`; INT-REQ-017 on hi-e1a's "do not copy those two lines" | a peer answer quoting the peer's figures gives no INT-REQ-017 |
| `tests/channel/test_encoding_disagreement_b20.py` | a ph s3.1-style disagreement gives INT-XENC-001 and an unresolved claim | agreement gives none |
| `tests/service/test_e505_contract_b15.py` | both behaviours | — |

---

## C. Security fixes, in order (all fixer a, except as noted)

Each finding was re-checked on 22d6a5b, with output in `design_probes/runs/p3_security.txt`. SEC-2 is already fixed
(E108 survives `produce_unsat_core=false`) and is listed as evidence only.

| # | Sev | Finding on 22d6a5b | Fix | Test |
| --- | --- | --- | --- | --- |
| 1 | high | **B26 / SEC-1.** `^…$` validators accept a trailing newline, so `x` and `x\n` are two symbols, and premise ids can impersonate each other | `fullmatch` for every IR validator (B.1, B26); grep `src/` for other `re.match(r"^…$")` validators of untrusted text and convert them | the unchanged strict-xfail test passes, marker removed; the r01 problem gives E100 |
| 2 | med-high | **SEC-3.** `parsing._FENCE_RE` is quadratic on unclosed openers: 10/20/40 KB took 0.17/0.71/3.06 s | a linear scan: find the first opener, then `str.find` the closer; cap provider text at 64 KB before parsing (TRANSLATION_FAILED "provider output too large") | a 1 MB opener run parses in < 50 ms; 64 KB + 1 is refused; a normal fenced reply is unchanged |
| 3 | medium | **SEC-4.** `result.claim_id` (and the `/v1/outcomes` `claim_id`) is logged raw, so CR/LF forges a `result_status=ENTAILED` line (reproduced) | `_log_safe()` escapes every C0 and C1 control and the backslash, and cuts each field to 128 characters; applied to every logged value | the forged payload is one log line with `\n` escaped |
| 4 | medium | **SEC-6.** `POST /v1/outcomes` takes client `fixture_responses`, so any authenticated client acts as the translation provider (reproduced) | setting `allow_client_fixtures` (default False; env `EPINOIC_ALLOW_CLIENT_FIXTURES`), otherwise 403 with a new code `E506` ("client fixtures disabled", in `engine/errors.py`) before parsing | the default refuses; test-enabled passes |
| 5 | medium | **SEC-5.** `model_completion=false` gives signed counterexamples whose values are symbol names (`y = 'y'`), in process and over HTTP (reproduced) | add `model_completion` to `SERVER_CONTROLLED_CONFIG_KEYS` (400 E100, like `memory_max_mb`); `procedures` always extracts models with completion, and the option is documented as having no effect on evidence | HTTP gives 400 E100; in process every value is a literal |
| 6 | low | **SEC-8.** `adapter_id` reaches `importlib.import_module("epinoic_logic.adapters.<id>")` before the allowlist. The import is confined to the package, but an arbitrary module name is probed per request | a closed allowlist built at app creation from the registered adapters; unknown, overlong or non-`[a-z0-9_.-]` ids are refused before any import | "..x", "service.app" and "x" × 5000 are refused and `import_module` is never called (monkeypatched) |
| 7 | low | **B27.** a lone surrogate in a text payload gives INTERNAL_ERROR (E900) | catch `UnicodeEncodeError` in `_decode_text` and return E100 | the unchanged strict-xfail test passes, marker removed |
| 8 | design | **New stage bounds (SEC-7).** derived runs could amplify a client's timeout | the A.8.1 bounds (24 runs, at most 1 s each, at most 8 s in total); derived problems built only by allowlisted wrappers over validated nodes; diagnostics, caps and `capped_from` signed with the result; `diagnose` and `severity_cap` reachable from Python only | the budget test; a tampered result with `named_diagnostics` removed or a `capped_from` edited fails `verify_signature`; a `diagnose=False` result is refused by `release_check` |
| 9 | doc | **B15** (fixer d): the service refuses what the contract says is discarded | contract text (B.4) | `tests/service/test_e505_contract_b15.py` |

---

## D. What the overseer build needs later (not now)

**Knowledge pack 1.4**

1. A new document, `10-named-diagnostics.md`, covering every code of A.3:
   - what it proves about the encoding and what it does not;
   - its derivation and layer;
   - that info is a record, never an accusation, and that a capped line keeps blocking release;
   - that ARG-LINK-001 on a valid interpretive link (c04-quote, c03-psych) is no fault;
   - that EVD-SRC-002 and EVD-LACK-002 say "not checked", never "false".
2. The dossier and `dossier.schema.json` gain:
   - an `argument` block: `premise_roles`, R0's W* with missing links, the derived counterexample, the named
     diagnostics with `capped_from`, and `argument_rules`;
   - a `screens` block for the agents (relevance overlap of a link's antecedent and consequent glosses, and the causal,
     universal and sense cues), which is never a finding.
3. Advisory kinds for what stays undecidable: `argument_irrelevant_reason` (f01b), `argument_unwarranted_step`,
   `argument_causal_leap`, `argument_hasty_generalisation`, `argument_equivocation`, `argument_circular_paraphrase`,
   `argument_false_dilemma`, `argument_cherry_picked` and `attribution_paraphrase_unfaithful` (EVD-SRC-002's follow-up).
4. `08-never.md` gains:
   - never accuse on a screen alone;
   - never treat an info record as a fault;
   - never call a stated step wrong only because no source states it;
   - never pass a system check result to the student as subject advice (S1, S2).
5. B11: a confirmable kind `finding_false`, with deterministic confirmations:
   - re-read the claim substring the check encoded;
   - the correction-arrow and mention rules of B5 and B6;
   - same-quantity restatement;
   - the B2 classes;
   - the gate's heuristic list.

   Restrict I3 ("a named fault is not accused") to true findings.
6. O1 to O3: pack examples for T1, T22a and the e2e false findings.

**Deterministic overseer checks**

| Code | Sev | When it fires |
| --- | --- | --- |
| OVS-ARG-001 | error | a re-derived warning is missing from the receipt, or is weaker there without a recorded cap |
| OVS-ARG-002 | error | a derived-problem digest does not match the rule's rebuild |
| OVS-ARG-003 | warning | the receipt carries a diagnostic the re-derivation does not reproduce |
| OVS-ARG-004 | error | a result presented as current has no `argument_rules`, or another rule version |

The tamper suite gains T23 (drop an INT-ARG-001), T24 (swap a derived digest), T25 (forge a diagnostic) and T26 (cap
a warning with no `capped_from`).

**Scoring (B12).** Gold comes from adjudicated truth: false auditor findings are removed, and false receipt findings
are added as faults.

**The user's new overseer protocol.** It is built in the separate overseer sub-repository, not here. It covers the
flash decision maker (split the work across duplicated agents, or one agent in depth) and the twofold mode for a
two-subject combined answer: one pass per specialist report before combination, then a merge with temporary context to
examine the combinator's synthesis. From this design it can read these deterministic inputs, and none of them needs
Z3:

- warning and info counts per family, per layer and per report, by effective severity;
- whether the plan routes to a combinator (`synthesis_required`, the B13 gate input);
- the receipts' `named_diagnostics`, including the report-level ones;
- `argument_rules` (present, incomplete or absent).

Because `named.py` is free of Z3 (A.1, rule 6), a deployment without the Z3 engine still carries the claim, report,
STEM and channel layers, and reads "not computed" for the engine layer. This is what the user's "integrate seamlessly
without the full Z3 infrastructure" requirement needs from this contract.

---

## E. Risks and how each rule avoids them

1. **False alarms on valid arguments: the central risk.**
   - The generic writer-link record is info by design (A.8.2).
   - Every warning rule needs a specific shape and has a named control:
     - AC and DA need the converse or inverse of a *different* stated premise; the controls are a biconditional stated
       both ways, and modus tollens;
     - FD excludes `general_knowledge` disjunctions and complementary pairs (c03-dich);
     - HG needs an *open* universal absent from every antecedent gloss, and exempts closed enumerations;
     - CL needs a time-sequence antecedent and no control cue anywhere in the problem (i02c);
     - CIRC-003 needs full containment, frame-only residue and matching polarity (c04-quote, c02-hist);
     - EQ-002 and EQ-003 need an explicit sense marker or qualifier (f02 does not fire);
     - EVD warnings need a source-bound task (c02-mt, c03-dich and s04c stay info);
     - ARG-BARE-001 needs an answer section with nothing but the assertion (c03-dich, i01c and f06 are exempt).
   - The two attribution and trend rules (EVD-SRC-002, EVD-LACK-002) are info only, so they can never be a false alarm.
     They are noise at most, and the p4b run shows a single noisy pattern (a quoted word), which masking removes.
   - The cue tables are English. A non-English answer gets fewer warnings, never more: a miss, not a false alarm.
2. **Label trust.** FD's exemption reads the translator's kind. A mislabelled false dilemma is missed (a naming gap),
   but it stays not releasable (rule 7) and unresolved at the gate. Labels never *confer* authority anywhere (A.8.3).
3. **B8 and B21 are not weakenings.** The withdrawn counterexample falsified only conjuncts that the encoding left
   free. That is an artefact of the encoding, not a check of the claim.
   - The judgement is still named (ARG-PART-001), the claim is AMBIGUOUS (never verified, never released), and the gate
     counts it unresolved.
   - f01 (the whole point unlinked, with no stated reason) keeps its COUNTEREXAMPLE and gains a warning.
   - B21 also turns some correct ENTAILED displays into AMBIGUOUS, for example a valid point with an unencoded
     concession clause ("although prices were still rising"). That is honest about what was checked, and it is not a
     flag. The v3 prompt asks for every clause to be encoded.
   - B13's "an ENTAILED that rests on an unestablished premise is unresolved" removes credit that was too generous.
   - B20 keeps the INT-SUBJ-001 error.
4. **Caps never hide anything from release.** A cap lowers the displayed severity on an ambiguous translation or
   outside a source-bound task. It is recorded in `capped_from`, signed, and still read by rule 8, assess_release and the
   gate. So a capped diagnostic can stop a release but never allow one.
5. **Quotation roles could be abused** by a writer who disguises an invented quotation as a correction or mention. The
   roles apply only to closed frames (arrows, correction labels, negating frames, function words). A span with another
   role is never presented as a quotation, and a span the writer attributes to a text with a citation is checked as
   before. The B5 and B6 controls pin both properties.
6. **Stricter grounding breaks tests or arena replays.**
   - Compound quotations become unverified, figureless task premises unvalidated, and label-only circles E112.
   - Fixer a rewrites the round-7 test (0.2) and any other test found, each to the stricter rule, with the reason stated.
   - The integration step re-runs every recorded arena round on copies and documents each changed record: new
     INT-ARG-001 findings, E112 on label-only circles, AMBIGUOUS on B8 shapes.
7. **Merge conflicts.**
   - Phase 0 itself has a semantic conflict (0.1). c fixes it before anything else starts.
   - `review-stem-channel` overlaps bus, ledger and contracts; Phase 0 handles it.
   - `0d28eba` overlaps several owners:
     - `bus.py` (d);
     - `service/app.py` (a);
     - `engine/policies.py` and `identity.py` (the Contract step; the manifest gains keys from both);
     - `integrity/contracts.py` (Contract; INT-SYNTH-014 sits apart from the new `defect` field);
     - `run_arena.py` (d; a different function);
     - the integration contract (d; renumber the version).
   - The open "repair 5/1" work (request figures in a negation, question or answer requirement never verify a
     premise) touches `translate/grounding.py` (a). Fixer a merges it before editing, or the integrator replays a's
     grounding tests after it. B23 is written to respect that rule (B.1).
   - The Contract step checks the branch head at start, and bases Phase 0 on it when 0d28eba has landed.
8. **Cost.**
   - R0 runs only on ENTAILED results with unestablished premises in the core. The prototype needed at most 4 derived
     runs per claim; the hard cap is 24 runs and 8 s.
   - STEM checks (all premises verified) add nothing, and every internal probe, cross check, branch formal check and
     constraint check passes `diagnose=False` (A.4.1).
   - Z3 is 66 % of deterministic time (P1) and may rise. The e2e request budget (240 s) has two orders of magnitude of
     headroom (0.81 s at most per request).
9. **Determinism of derived runs.** The seed and the order are fixed, and the rlimit is applied. A timeout is
   "incomplete", never a finding. A test runs the diagnosis twice and compares.
10. **Receipt churn.** INT-ARG-001 moves defect receipts to ACCEPTED_WITH_FINDINGS; info records never do. The harness
    and the overseer compare records field by field, so the integration step documents the new fields as expected
    additions.
11. **Lexical rules over model-written glosses.** A translator that paraphrases glosses can hide HG, CL or CIRC-003 (a
    miss). In rare wordings it could trigger one (a false alarm), which the controls guard against. The v3 prompt asks
    for scope and causal words to be kept as written. The overseer agents get the same screens as advisory input.
12. **The reference STEM table is incomplete.** An unknown quantity or an ambiguous symbol gives no ST-REF-001 (a miss,
    never a false alarm). The table covers the IB data-booklet formulas and is extended as data.
13. **The corpus is the dev set only.** The rules were calibrated against `corpus/dev`; the holdout was not read. Every
    threshold is a closed rule with a control, not tuned to case wording. The integration step runs the holdout once,
    at the end.

---

## Appendix: acceptance on the dev corpus (worst mode counts)

After Phase 0, the Contract step and all four fixers, every case below is expected to reach the verdict shown. Each
fixer measures its own rows on its branch; the integration step measures all of them merged.

| Case | Modes | Expected | Named by (owner) |
| --- | --- | --- | --- |
| f01 | text | named | ARG-NS-001 (b) |
| f01b | text | named | ARG-LINK-001, info on a not-releasable claim (b) |
| f02 | text | named | ARG-NS-002 (b) |
| f03, f03b | text | named | ARG-AC-001 a / b (b) |
| f04 | text | named | ARG-DA-001 a (b) |
| f05, f06, f08 | text | named (already) | INT-REQ-007 / E112 / E108, plus ARG-CONTRA, CIRC, VAC |
| f05b | text | named | ST-GIVEN-002 (c) |
| f06b | text | named | ARG-CIRC-003 (b) |
| f07 | text | named | the circularity refusal, E112 (a), with ARG-CIRC-001 |
| f09, f09b | text | named | ARG-HG-001 ii / i (b) |
| f10 | text | named | ARG-FD-001 (b) |
| e01 | report, text, merged | named | EVD-LACK-001 warning (report, merged); EVD-LACK-002 info (text) (a) |
| e02 | all three | named | EVD-FIG-001 (a) |
| e03, e04b, e05b, e07 | all three | named (already) | existing codes, plus EVD-SRC-003 or EVD-AUTH-001 |
| e04a | all three | named | EVD-SRC-001 (report, merged); EVD-SRC-002 (text) (a) |
| e05a | all three | named | EVD-AUTH-001 (a) |
| e06a, e06b | all three | named | EVD-CHERRY-001 (a); e06b also ARG-REFUTE-001 |
| e08a | all three | named | CORE-SELF-001 through the widened SELF_CERT_RE (a) |
| e08b | all three | named | EVD-SRC-001 and EVD-SRC-004 (report, merged); EVD-SRC-002 (text) (a) |
| i01, i01b | report, text | named | ARG-BARE-001 (b) |
| i02 | report, text | named | ARG-CL-001 (b) |
| i03a | report, text | named | ARG-EQ-003 (b) |
| i03b | report, text | named | ARG-EQ-001 (b) |
| s01, s03c | text | named (already) | INT-SUBJ-001, ST-DIM-001 |
| s02, s02b | text | named | ST-REF-001 (c) |
| s03a, s03b, s03d | text | named | ST-UNIT-003 (c) |
| s04 | text | named | ST-ROUND-001 (c) |
| s05 | text | named | ST-STEP-001 (c) |
| s06 | text | named | ST-SCOPE-002 (c) |
| s07 | text | named | ST-RANGE-001 (c) |
| s08 | text | named | ST-WORK-001 (c) |
| c01-mp, c05-chem, c06-givens, i00, i01c, every s-control | as recorded | clean (already) | must stay clean |
| c01-econ, c01b-econ, c02-hist, c04-eng | all three | clean | INT-LEDGER-020 (a) |
| c02-mt | text | clean | GROUNDING:FAILED (a) |
| c03-dich | text | clean | GROUNDING:FAILED (a); INT-REQ-004 (d) |
| c03-psych | all three | clean | INT-LEDGER-020 (a); PS-SRC-001 and its INT-HIST-001 (c) |
| c04-quote | text | clean | ES-STR-001 (b); INT-REQ-004 (d) |
| i02c | report, text | clean | CORE-QNT-001 and its INT-HIST-001 (c); INT-REQ-004 (d) |
| e2e-B2-* | text | clean | c |
| e2e-B4-*, e2e-B18-*, e2e-B19-ll, e2e-B13-ll | text | clean | d |
| e2e-B13-ec, e2e-B13-ps, e2e-B13-sp | text | clean | d (the constraint bounds), plus c for ec's INT-SUBJ-001, b for ps's B8 counterexample, and a for sp's B5 quotations |
| e2e-B5-sp, e2e-B6-en, e2e-B16-ess, e2e-B23-bm | text | clean | a |
| e2e-B7-ph | text | clean | c |
| e2e-B8-* | text | clean | b |
| e2e-B20-* | text | clean | c for the false INT-SUBJ-001; d adds INT-XENC-001 only where the two encodings truly disagree |
| e2e-B13-lit, e2e-B16-hi, e2e-B21-ge, e2e-B22-ph | text | clean (already) | must stay clean; b adds the B16-hi closure, B21 and B22 fixes with constructed tests |
