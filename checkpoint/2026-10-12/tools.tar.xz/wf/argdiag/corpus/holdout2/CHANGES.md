# Hold-out 2: label audit changes

An independent auditor read all 136 cases. Each case was judged on its own text only, with no system output consulted. The audit
checked four things: whether each defect really is an instance of its expected label (and whether the acceptable labels cover
correct alternative names), whether each control is sound, whether each encoded translation is faithful to the answer, and
whether any case copies a dev shape. The arithmetic of every STEM case and every derived figure was recomputed by hand. Three
dev files were opened for comparison: `s04_rounding_flips_conclusion`, `s07_extrapolation` and
`e08a_self_certified_premise_specialist`.

## Corrections in place

1. `h2_d_dim_phys_suvat_dropped_t`: acceptable_labels changed from `[stem_wrong_formula]` to `[stem_arithmetic_slip]`.
   The answer writes the correct formula, s = ut + ½at². The fault comes in the substitution: t is dropped from ut, giving
   3.0 + 16 = 19 m where the correct value is 28 m. "Wrong formula" therefore misnames the fault. A substitution slip is a
   correct second name, and the expected label stays `stem_dimension_error`, since a velocity is added to a length.
2. `h2_d_loe_geog_rainfall`: `causal_leap` added to acceptable_labels. Besides the unsourced 30% rainfall figure (the expected
   `lack_of_evidence`), the answer claims that the rainfall fall "explains the fall in yield". That single-cause attribution is
   also unsupported, so naming it is correct.
3. `h2_c_fullrange_geog_tourism` (control): answer and claim c2 changed. "recovery by 2023" became "a return above the 2019
   level only in 2024". The table gives 1.5 million for 2023, below the 1.8 million of 2019, so a careful examiner would fault
   "recovery by 2023". The control has to be sound. The translation still matches c2 and is unchanged.
4. `h2_c_quote_hist_right_source` (control): claim c1 changed from "warns that 'the harvest is failing'" to "argues that 'Only
   the harvest will save the republic, and the harvest is failing.'" (its excerpt was updated to match). The encoded premise
   `q1` (Source B: 'Only the harvest will save the republic') was not stated anywhere in the answer, so the translation was not
   faithful to the text it encodes. The answer's conclusion, that the sources disagree on "the harvest itself or discipline",
   also had no stated basis. Both quotations are now verbatim from the source each is credited to.

## Removed and replaced

5. Removed `h2_d_extrap_bio_enzyme_70` (stem_extrapolation) and its paired control `h2_c_bio_interpolation`. Both reuse the
   scenario of dev `s07_extrapolation`: a linear enzyme-rate trend over 10 to 30 or 40 °C, predicted at a temperature where the
   enzyme denatures. That is copying a dev shape. They were replaced in a new shape and subject (Geography, rainfall-runoff):
   - `h2_d_extrap_geog_storm_runoff` (stem_extrapolation): a line fitted on 10 to 40 mm storms is used for a 150 mm storm with
     no caveat. The arithmetic is correct (1.6 × 150 + 4 = 244).
   - `h2_c_geog_runoff_interpolation` (control): the same line is used for a 25 mm storm, which lies inside the range. The answer
     says so, and the arithmetic is correct (1.6 × 25 + 4 = 44).

## Reviewed, no change

All other cases were confirmed as written. The rounding pair (`h2_d_round_*`) and the self-certification cases
(`h2_d_unch_bm_checked_figures`, `h2_d_unch_psych_self_verified`) share only their defining mechanism with dev `s04` and `e08a`.
Their scenario, subject, wording and figures differ, so they were kept.

## Counts after the audit

136 cases: 70 defects and 66 controls. Every label has at least two defects (stem_extrapolation: 2). By family: formal 18/11,
informal 8/5, evidence 18/14, stem 26/36 (defects/controls). Subjects: Biology 8, Geography 12; all other subjects unchanged.
