import json
import os

BASE = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad"
ARENA = os.path.join(BASE, "arena", "r7")
TASKS = os.path.join(ARENA, "tasks.json")
RESPONSE = os.path.join(BASE, "bi-t13-response.txt")
OUT_DIR = os.path.join(ARENA, "specialists")
OUT = os.path.join(OUT_DIR, "bi-t13.json")

with open(TASKS, encoding="utf-8") as fh:
    tasks = json.load(fh)

selected = [t for t in tasks if t.get("task_id") == "bi-t13"]
if len(selected) != 1:
    raise SystemExit("expected exactly one bi-t13 task, found %d" % len(selected))

task = dict(selected[0])
with open(RESPONSE, encoding="utf-8") as fh:
    task["response_text"] = fh.read().rstrip("\n")

os.makedirs(OUT_DIR, exist_ok=True)
with open(OUT, "w", encoding="utf-8") as fh:
    json.dump(task, fh, ensure_ascii=False, indent=2)
    fh.write("\n")

with open(OUT, encoding="utf-8") as fh:
    check = json.load(fh)
print(sorted(check.keys()))
print(len(check["response_text"].split()), "words in response_text")
print(OUT)
