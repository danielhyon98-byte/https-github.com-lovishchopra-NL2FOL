import json, os

base = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2"
tasks = json.load(open(os.path.join(base, "tasks.json"), encoding="utf-8"))
task = next(t for t in tasks if t["task_id"] == "bm-t15")
spec = json.load(open(os.path.join(base, "specialists", "bm-t15.json"), encoding="utf-8"))
orig = spec["response_text"]

old = ("Pellow Cycles' sales revenue rose by 10.0%, but the market grew by 25.0%, "
       "so its market share fell from 15.0% to 13.2%.")
new = ("Pellow Cycles' sales revenue rose by 10.0% ($18,000 ÷ $180,000 × 100 = 10.0%), "
       "but the market grew by 25.0% ($300,000 ÷ $1,200,000 × 100 = 25.0%), "
       "so its market share fell from 15.0% to 13.2%. The same result follows from the growth rates: "
       "new share = old share × (1 + sales growth) ÷ (1 + market growth) = "
       "15.0% × 1.10 ÷ 1.25 = 15.0% × 0.88 = 13.2%.")
assert orig.count(old) == 1, orig.count(old)
revised = orig.replace(old, new)

feedback_handled = [
    {
        "flaw_id": "f1",
        "code": "INT-SUBJ-001",
        "action": "kept_with_working_shown",
        "what_changed": ("Kept the flagged sentence as written and added the step that gives each figure: "
                         "the sales rise $18,000 ÷ $180,000 = 10.0%, the market rise $300,000 ÷ $1,200,000 = 25.0%, "
                         "and the growth-rate form of the share, 15.0% × 1.10 ÷ 1.25 = 13.2%. "
                         "Nothing else in the answer was altered."),
        "why": ("The stated result holds: 180,000 to 198,000 is a rise of 10.0%; 1,200,000 to 1,500,000 is a rise of 25.0%; "
                "198,000 ÷ 1,500,000 = 13.2% and 180,000 ÷ 1,200,000 = 15.0%. Because the arithmetic is correct, "
                "the claim was kept and its step shown, as the revision rules direct for a flagged result that is right. "
                "The engine's counterexample does not match any arithmetic error in the passage."),
    }
]

out = dict(task)
out["response_text"] = revised
out["feedback_handled"] = feedback_handled

dest_dir = os.path.join(base, "revisions")
os.makedirs(dest_dir, exist_ok=True)
dest = os.path.join(dest_dir, "bm-t15.json")
with open(dest, "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=2)
print(dest)
print(len(revised), "chars")
