"""Five-minute watchdog for the workflow subagents (Daniel: no token consumption without progress).

Reads only the workflow journals and agent transcripts on disk; no model is called. Prints one line per NEW
anomaly (remembered in watchdog-state.json so it is reported once) and nothing when all is healthy:
  STALL    a workflow has agents in flight but no transcript has been written for STALL_MIN minutes
  LOOP     an agent's last LOOP_N tool calls are identical (same tool, same input): it is spinning
  LONG     an agent has run longer than its role's limit
  ENDED    a workflow has no agent in flight and its journal has not moved for ENDED_MIN minutes
Exit status 0 always; the caller loops.
"""
import glob
import json
import os
import sys
import time

S = os.path.dirname(os.path.abspath(__file__))
WF = "/root/.claude/projects/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/subagents/workflows"
STATE = os.path.join(S, "watchdog-state.json")
STALL_MIN, ENDED_MIN, LOOP_N = 10, 12, 5
LONG_MIN = {"haiku": 30, None: 100}  # deployed agents vs checking agents (fixers and overseer lenses run long)
RECENT_H = 3


def tail_records(path, nbytes=400_000):
    try:
        with open(path, "rb") as fh:
            fh.seek(0, 2)
            size = fh.tell()
            fh.seek(max(0, size - nbytes))
            data = fh.read().decode("utf-8", "replace")
    except OSError:
        return []
    out = []
    for line in data.splitlines()[1:] if size > nbytes else data.splitlines():
        try:
            out.append(json.loads(line))
        except ValueError:
            pass
    return out


def first_timestamp(path):
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            rec = json.loads(fh.readline())
        return rec.get("timestamp")
    except (OSError, ValueError):
        return None


def iso_to_epoch(ts):
    try:
        return time.mktime(time.strptime(ts[:19], "%Y-%m-%dT%H:%M:%S")) - time.timezone
    except (TypeError, ValueError):
        return None


def main():
    now = time.time()
    try:
        state = json.load(open(STATE))
    except (OSError, ValueError):
        state = {}
    alerts = []
    for jpath in glob.glob(os.path.join(WF, "wf_*", "journal.jsonl")):
        if now - os.path.getmtime(jpath) > RECENT_H * 3600:
            continue
        wf = os.path.basename(os.path.dirname(jpath))
        started, done, labels = {}, set(), {}
        for line in open(jpath, encoding="utf-8", errors="replace"):
            try:
                e = json.loads(line)
            except ValueError:
                continue
            if e.get("type") == "started":
                started[e["key"]] = e.get("agentId")
                labels[e["key"]] = e.get("label", "?")
                done.discard(e["key"])  # a resumed step reuses its key and is in flight again
            elif e.get("type") in ("result", "failed"):  # a failed step is not in flight
                done.add(e["key"])
        inflight = [(k, started[k]) for k in started if k not in done and started[k]]
        # Several resumes can leave older 'started' entries for the same label; only the newest per label is live.
        newest = {}
        for k, a in inflight:
            newest[labels[k]] = (k, a)
        live = []
        for label, (k, a) in newest.items():
            tpath = os.path.join(WF, wf, f"agent-{a}.jsonl")
            if os.path.exists(tpath) and now - os.path.getmtime(tpath) < 3 * 3600:
                live.append((label, a, tpath))
        jage = (now - os.path.getmtime(jpath)) / 60
        if not live:
            if jage > ENDED_MIN:
                alerts.append((f"ended:{wf}:{int(os.path.getmtime(jpath))}", f"ENDED {wf}: no agent in flight; journal unchanged for {jage:.0f} min"))
            continue
        newest_write = max(os.path.getmtime(t) for _, _, t in live)
        if (now - newest_write) / 60 > STALL_MIN:
            alerts.append((f"stall:{wf}:{int(newest_write)}", f"STALL {wf}: {len(live)} agent(s) in flight ({', '.join(l for l, _, _ in live)[:200]}) but no transcript written for {(now - newest_write) / 60:.0f} min"))
        for label, a, tpath in live:
            meta = {}
            try:
                meta = json.load(open(os.path.join(WF, wf, f"agent-{a}.meta.json")))
            except (OSError, ValueError):
                pass
            limit = LONG_MIN["haiku"] if meta.get("model") == "haiku" else LONG_MIN[None]
            start = iso_to_epoch(first_timestamp(tpath))
            active = (now - os.path.getmtime(tpath)) / 60 <= STALL_MIN  # only an agent still writing is consuming tokens
            if active and start and (now - start) / 60 > limit:
                alerts.append((f"long:{wf}:{a}", f"LONG {wf}: {label} ({meta.get('model') or 'strongest tier'}) running {(now - start) / 60:.0f} min (limit {limit})"))
            calls = []
            for rec in tail_records(tpath):
                msg = rec.get("message") or {}
                content = msg.get("content") if isinstance(msg, dict) else None
                if isinstance(content, list):
                    for block in content:
                        if isinstance(block, dict) and block.get("type") == "tool_use":
                            calls.append(json.dumps([block.get("name"), block.get("input")], sort_keys=True)[:4000])
            if len(calls) >= LOOP_N and len(set(calls[-LOOP_N:])) == 1:
                alerts.append((f"loop:{wf}:{a}:{len(calls)}", f"LOOP {wf}: {label} repeated the same tool call {LOOP_N} times in a row ({calls[-1][:160]})"))
    fresh = [(k, m) for k, m in alerts if k not in state]
    for k, m in fresh:
        state[k] = int(now)
        print(time.strftime("%H:%M:%S", time.gmtime(now)) + " " + m, flush=True)
    json.dump(state, open(STATE, "w"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
