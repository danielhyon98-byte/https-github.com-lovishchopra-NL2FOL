import sys
sys.path.insert(0, "/home/user/https-github.com-lovishchopra-NL2FOL")
from tests.channel.r7_support import Run
from tests.channel.test_round7_fixes import POOLED
for g in ["p7b", "cs-t13"]:
    run = Run(g, pooled=POOLED[g])
    for rc in run.receipts.values():
        for o in rc.outcomes:
            print(g, o.claim_id, o.translation.status.value, o.display_status.value, o.translation.diagnostics[:2])
    print(list(run.ch.formalized))
