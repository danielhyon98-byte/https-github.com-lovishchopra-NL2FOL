#!/usr/bin/env bash
# Quarter-hour status snapshot (Daniel, 19:39 UTC: "status update every 15 minutes at 15, 30, 45, and 00").
# Started a minute or two early by the quarter-hour routine; waits until the next hh:15:00, hh:30:00 or hh:45:00 UTC
# (immediately if started more than 10 minutes early, or with --now), then prints the snapshot the update is written from.
# Reads files and journals only; no model is called. The hh:00 update follows the hourly push (hourly_push.sh).
set -uo pipefail
S=$(cd "$(dirname "$0")" && pwd)
if [ "${1:-}" != "--now" ]; then
  python3 -I -c "
import time
now = time.time()
target = (int(now) // 900 + 1) * 900
if target - now > 600:
    target = now
time.sleep(max(0, target - now))
"
fi
python3 -I "$S/status.py" 2>&1
S2=$(python3 -I -c "import json,sys; print(json.load(open(sys.argv[1])).get('stem-merge') or '')" "$S/runs.json")
J=/root/.claude/projects/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/subagents/workflows/$S2/journal.jsonl
[ -n "$S2" ] && [ -s "$J" ] && echo "- stem-merge journal: $(grep -c '"type":"result"' "$J") result(s), $(grep -c '"type":"failed"' "$J") failure(s)"
echo "- presim cache: $(ls -t "$S/simcache" 2>/dev/null | head -3 | while read f; do echo -n "$f=$(grep -o '^SIMULATION [A-Z]*' "$S/simcache/$f" | tail -1 | cut -d' ' -f2) "; done)"
echo "- snapshot taken $(date -u +%H:%M:%S) UTC"
