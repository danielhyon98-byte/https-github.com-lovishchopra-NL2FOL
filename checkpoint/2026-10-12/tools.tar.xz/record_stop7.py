#!/usr/bin/env python3
"""Record the weekly-limit stop of phase 2 (9 Nov) in runs.json: time, labels done, agents in flight, R dirty count."""
import json, subprocess, time, sys
S = '/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad'
J = '/root/.claude/projects/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/subagents/workflows/wf_eee12853-0ae/journal.jsonl'
R = '/home/user/https-github.com-lovishchopra-NL2FOL'
lab, st, dn, ids, nulls = {}, [], [], {}, 0
for l in open(J):
    d = json.loads(l)
    if d.get('type') == 'started':
        lab[d['key']] = d.get('label'); st.append(d.get('label')); ids[d.get('label')] = d.get('agentId')
    elif d.get('type') == 'result':
        dn.append(lab.get(d.get('key')))
        if d.get('result') in (None, 'null', ''):
            nulls += 1
inflight = [s for s in st if s not in dn]
dirty = subprocess.run(['git', '-C', R, 'status', '--porcelain'], capture_output=True, text=True).stdout.splitlines()
rec = {'time': time.strftime('%Y-%m-%dT%H:%MZ', time.gmtime()), 'labels_done': len(dn), 'null_results': nulls,
       'killed_in_flight': [{'label': s, 'agent': ids.get(s)} for s in inflight], 'R_dirty_paths': len(dirty),
       'reason': 'weekly limit (Daniel 9 Nov: full throttle on round 9; stop just before the limit to keep the resume clean)',
       'resume': 'Workflow scriptPath S/wf-scripts/phase2-cont.js, resumeFromRunId wf_eee12853-0ae, args = contents of S/wf/phase2-cont-args.json (after Fri 13 Nov 16:00 UTC)'}
d = json.load(open(S + '/runs.json'))
d['phase2-cont']['stopped7'] = rec
d['phase2-cont']['status'] = 'STOPPED for the weekly limit at ' + rec['time'] + ' (see stopped7); resume after the reset'
json.dump(d, open(S + '/runs.json', 'w'), indent=1)
print(json.dumps(rec, indent=1))
