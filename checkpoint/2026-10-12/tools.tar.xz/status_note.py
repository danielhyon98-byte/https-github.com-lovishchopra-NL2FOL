"""Write the note for an hourly update that carries no new final code (Daniel, 2026-10-12: "push updates every hour
regardless of progress whilst creating a backup of the previous iteration; do not upload dysfunctional code; always run
a simulation").

The note says the code is unchanged (and which verified source it is), gives the simulation run on exactly the uploaded
tree, and the measured progress since the previous update, taken from the hourly Progress entries in tests/README.md on
the development branch. Scratch paths, session ids and model names are removed.

Usage: status_note.py --repo R --dev BRANCH --since ISO --source SHA --source-update N --number N --sim FILE --out FILE
       [--index PATH ...]
"""
import argparse
import datetime
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import update_notes as U  # noqa: E402

ENTRY = re.compile(r"^\*\*(\d{4}-\d{2}-\d{2} \d{2}:\d{2}) UTC\.\*\*\s*$")


def progress_entries(text, since):
    """Progress entries ('**YYYY-MM-DD HH:MM UTC.**' blocks) written after `since`."""
    lines = text.split("\n")
    try:
        start = next(i for i, l in enumerate(lines) if l.startswith("## Progress"))
    except StopIteration:
        return []
    out, cur = [], None
    for line in lines[start + 1:]:
        if line.startswith("## "):
            break
        m = ENTRY.match(line.strip())
        if m:
            cur = [m.group(1), []]
            out.append(cur)
        elif cur is not None:
            cur[1].append(line)
    return [(when, "\n".join(body).strip()) for when, body in out if when > since]


def main():
    ap = argparse.ArgumentParser()
    for k in ("repo", "dev", "since", "source", "sim", "out"):
        ap.add_argument("--" + k, required=True)
    ap.add_argument("--number", type=int, required=True)
    ap.add_argument("--source-update", default="")
    ap.add_argument("--index", nargs="*", default=[])
    a = ap.parse_args()
    now = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    subj = U.git(a.repo, "log", "-1", "--format=%s", a.source).strip()
    readme = U.git(a.repo, "show", f"{a.dev}:tests/README.md")
    since = a.since[:16].replace("T", " ")
    entries = progress_entries(readme, since)
    sim = [l.rstrip() for l in open(a.sim, encoding="utf-8", errors="replace") if l.strip()]
    verdict = next((l for l in reversed(sim) if l.startswith("SIMULATION ")), "SIMULATION result missing")
    md = [f"# Update {a.number}: Hourly update, {now}", "",
          "No new final translator code this hour, so the code on this branch is unchanged. It is exactly the code "
          f"verified at source commit `{a.source[:7]}` ({U.clean(subj)})"
          + (f", first published in update {a.source_update}" if a.source_update else "") + ". "
          "This update carries the hourly progress and a fresh functional simulation of that code. Work-in-progress "
          "code is never uploaded.", "",
          "Results prove properties of the encoded problems only, never that a specialist's premises are true.", "",
          "## Simulation before this upload", "",
          "Run on exactly the uploaded tree: the full test suite, then every recorded arena round replayed through the "
          "translator (recorded specialist outputs; no model is called). The upload is refused if anything fails.", ""]
    md += [f"- {U.clean(l)}" for l in sim if not l.startswith("SIMULATION ")] + ["", f"Result: {U.clean(verdict)}", ""]
    md += ["## Progress since the previous update", ""]
    if entries:
        for when, body in entries:
            md += [f"### {when} UTC", "", U.clean(body), ""]
    else:
        md += ["No progress entry was recorded since the previous update.", ""]
    if a.index:
        md += ["## Earlier updates", ""] + [f"- {p}" for p in a.index] + [""]
    with open(a.out, "w", encoding="utf-8") as fh:
        fh.write("\n".join(md).rstrip() + "\n")


if __name__ == "__main__":
    main()
