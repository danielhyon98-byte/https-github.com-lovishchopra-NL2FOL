#!/usr/bin/env python3
"""After record_stop7.py: rewrite RESUME.md's title and insert the stop section (backup RESUME.md.before-stop7).
Usage: python3 update_resume_stop7.py <weekly percent at the stop> <combinator 'fixed/left' or 'killed'>"""
import json, shutil, sys
S = '/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad'
pct, comb = sys.argv[1], sys.argv[2]
st = json.load(open(S + '/runs.json'))['phase2-cont']['stopped7']
t = st['time'][11:16]
killed = ', '.join(k['label'] for k in st['killed_in_flight']) or 'none'
P = S + '/RESUME.md'
shutil.copy(P, P + '.before-stop7')
lines = open(P).read().split('\n')
assert lines[0].startswith('# Resume after the weekly limit of 9 Nov 2026'), lines[0][:80]
lines[0] = (f'# Resume after the weekly limit of 9 Nov 2026 (phase 2 STOPPED at {t} UTC Mon 9 Nov at weekly {pct}%, '
            'at a clean point; the weekly window resets Fri 13 Nov 16:00 UTC). Older sections below are history.')
i = next(n for n, l in enumerate(lines) if l.startswith('## 9 Nov 00:2x UTC'))
sec = f"""## 9 Nov {t} UTC: PHASE 2 STOPPED FOR THE WEEKLY LIMIT (round 9 fix stage: all six owner fixers done; the handoff fixer is next)
- Stop: TaskStop on task wxij9jbhz at {t} UTC (weekly {pct}%), recorded in S/runs.json phase2-cont.stopped7 (labels done
  {st['labels_done']}, null results {st['null_results']}; killed in flight: {killed}). R holds the six fixers' UNCOMMITTED edits
  ({st['R_dirty_paths']} paths; the checkpoint's wip carries them as patches + untracked files). Never commit them by hand: the
  resumed workflow's handoff fixer, verify and commit own them (hourly step A stays skipped while R is dirty).
- Round 9 (c2) fix stage: 196 findings (142 from the five lenses + 54 carried): overseer 26 fixed/12 left, parsers 14/10,
  stem 20/9, core 19/23, harness 6/10, combinator {comb}; every fixer wrote cross-owner handoffs
  (S/wf/phase2/clearance-c2/handoff-*.md; handoff-pushcheck.md holds the 6 items of the c4f276c push check).
  Failures the fixers saw on the shared working tree, for the handoff fixer and verify to settle: 40 overseer push-check
  tests (the parsers fixer's note-reader change), test_clearance_c2_overseer[note by negation], test_stem_completion[maa-t13]
  (14 checks vs a pinned 16), scripts/arena/test_arena_rules.py::test_a_mutation_of_the_second_stem_report_... (STEM change).
- RESUME after Fri 13 Nov 16:00 UTC: if the container is fresh, restore first (section 1 below and KNOWLEDGE/04-PROCEDURES).
  Then Workflow with scriptPath S/wf-scripts/phase2-cont.js (sha256 a7db87ad82f4edc5...), resumeFromRunId wf_eee12853-0ae,
  args = the contents of S/wf/phase2-cont-args.json (continueAfterRound8 true; NOT the r8only file). Every finished agent
  replays from the journal; the first live call is fix:handoffs:clearance-c2, then verify, commit "Fix the c2 clearance
  findings", push-check:c2, push:c2 (the installed gate uploads after its simulation), readme:c2, then round 10 (c3).
  Re-arm the watchdog Monitor (bash S/watchdog_monitor.sh; milestones in S/watch-milestones.txt). Mark stopped7 resumed in runs.json.
- Also after the reset: task #238 (rewrite and fact-check the handoff documents for c4f276c / pin 1c2fb5c, publish, read
  back; release_prototype.sh needs a deliberate tag-name change: ask Daniel).
"""
lines[i:i] = sec.split('\n')
open(P, 'w').write('\n'.join(lines))
print('RESUME.md updated:', lines[0][:120])
