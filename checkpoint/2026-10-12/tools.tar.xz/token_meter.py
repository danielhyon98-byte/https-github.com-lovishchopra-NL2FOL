"""Measure token usage and wall time per workflow agent from the agent transcripts (read-only).

Usage: token_meter.py WORKFLOWS_DIR [RUN ...]   -> JSON on stdout: per run, per agent (label, model, start, end, tokens)
Each API message is counted once (by message id; the largest usage seen for it).
"""
import glob, json, os, sys
from datetime import datetime


def ts(s):
    return datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp()


def agent_usage(path):
    msgs, first, last, model = {}, None, None, None
    blocks = {}
    for line in open(path, errors="replace"):
        try:
            e = json.loads(line)
        except ValueError:
            continue
        t = e.get("timestamp")
        if t:
            first = t if first is None else min(first, t)
            last = t if last is None else max(last, t)
        if e.get("type") != "assistant":
            continue
        m = e.get("message") or {}
        u = m.get("usage") or {}
        mid = m.get("id") or e.get("uuid")
        blocks[(mid, e.get("apiBlockIndex"))] = sum(len(json.dumps(c)) for c in (m.get("content") or []))
        model = m.get("model") or model
        cc = u.get("cache_creation") or {}
        cur = {
            "input": u.get("input_tokens", 0) or 0,
            "cache_write_5m": cc.get("ephemeral_5m_input_tokens", u.get("cache_creation_input_tokens", 0)) or 0,
            "cache_write_1h": cc.get("ephemeral_1h_input_tokens", 0) or 0,
            "cache_read": u.get("cache_read_input_tokens", 0) or 0,
            "output": u.get("output_tokens", 0) or 0,
        }
        prev = msgs.get(mid)
        if prev is None or cur["output"] >= prev["output"]:
            msgs[mid] = cur
    tot = {k: sum(v[k] for v in msgs.values()) for k in ("input", "cache_write_5m", "cache_write_1h", "cache_read", "output")}
    tot["api_calls"] = len(msgs)
    tot["out_chars"] = sum(blocks.values())
    return model, first, last, tot


def main():
    wdir = sys.argv[1]
    runs = sys.argv[2:] or sorted(os.path.basename(p) for p in glob.glob(os.path.join(wdir, "wf_*")))
    out = {}
    for run in runs:
        rd = os.path.join(wdir, run)
        labels, done = {}, set()
        jp = os.path.join(rd, "journal.jsonl")
        if os.path.exists(jp):
            for line in open(jp, errors="replace"):
                try:
                    e = json.loads(line)
                except ValueError:
                    continue
                if e.get("type") == "started" and e.get("agentId"):
                    labels[e["agentId"]] = e.get("label")
        agents = []
        for p in sorted(glob.glob(os.path.join(rd, "agent-*.jsonl"))):
            aid = os.path.basename(p)[len("agent-"):-len(".jsonl")]
            model, first, last, tot = agent_usage(p)
            if first is None:
                continue
            label = labels.get(aid)
            if label is None:
                try:
                    label = json.load(open(p[:-len(".jsonl")] + ".meta.json")).get("description")
                except (OSError, ValueError):
                    label = "?"
            agents.append({"agent": aid, "label": label, "model": model, "start": first, "end": last,
                           "minutes": round((ts(last) - ts(first)) / 60, 1), **tot})
        out[run] = sorted(agents, key=lambda a: a["start"])
    json.dump(out, sys.stdout, indent=1)


if __name__ == "__main__":
    main()
