#!/usr/bin/env bash
# Compress superseded intermediate outputs of the finished overseer rebuild (committed 502fcff) to free disk space.
# Each directory is archived, the archive tested, and only then the directory removed. Final evidence (eval, final,
# audit, stem/repair12) is left untouched.
set -uo pipefail
R=$1; OUT=$2
for d in stem/repair3 stem/repair4 stem/repair5 stem/repair6 stem/repair7 stem/repair8 stem/repair9 stem/repair10 stem/repair11 r4fix r5fix r6fix contained-rep1 contained-rep2 contained-rep3 contained-rep4 contained-repair2 contained-repair2b; do
  [ -d "$R/$d" ] || continue
  name=$(echo "$d" | tr / _)
  a="$OUT/$name.tar.xz"
  if nice -n 19 tar -C "$R" -cf - "$d" | nice -n 19 xz -T1 -6 > "$a.part" && xz -t "$a.part" && tar -tJf "$a.part" >/dev/null; then
    mv "$a.part" "$a"; rm -rf "$R/$d"; echo "archived $d -> $(du -h "$a" | cut -f1)"
  else
    rm -f "$a.part"; echo "FAILED $d (kept)"
  fi
  df -h / | tail -1
done
echo ARCHIVE-DONE
