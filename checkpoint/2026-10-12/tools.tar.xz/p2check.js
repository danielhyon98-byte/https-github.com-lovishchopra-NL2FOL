(async () => {
const meta = {
  name: 'translator-phase2-pipeline',
  description: 'After the arena, STEM and overseer builds finish: merge the STEM and overseer builds into one network infrastructure, run three integrated clearance rounds over all sixteen v3 specialists (cheapest-tier agents, strongest-tier overseers and fixers, overseer agents attached, stress tests, README reports), make the infrastructure scale to any number of agents with a stress report, run the contained multi-agent duplicate test with real-time optimisation, and write the final report',
  whenToUse: 'Second phase of the Epinoic translator programme, once the three builds have completed their own audits and contained testing',
  phases: [
    { title: 'Merge', detail: 'STEM and overseer builds into the development branch, verified' },
    { title: 'Clearance', detail: 'three rounds over all sixteen specialists: material, overseers, fixes, verified commits, stress, README' },
    { title: 'Scaling', detail: 'any number of agents per task; algorithm stress test; docs/SCALING_RESULTS.md' },
    { title: 'MultiAgent', detail: 'duplicated English and History agents in a contained environment; real-time overseer optimisation' },
    { title: 'Final', detail: 'final report and README' },
  ],
}

const REPO = '/home/user/https-github.com-lovishchopra-NL2FOL'
const S = '/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad'
const PY = S + '/z3venv/bin/python -I'
const ARENA = S + '/arena'
const CLR = S + '/clearance'
const WF2 = S + '/wf/phase2'
const KB3 = S + '/kb-v3/ib-specialist-knowledge-bases-v3'
const BREADTH = S + '/breadth/b1/REPORT.md'
const BRANCH = 'claude/z3-verification-engine-plan-nk3luq'
const ATTR = 'Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>\nClaude-Session: https://claude.ai/code/session_016YotQwcC83EEJm8zshdxtW'

const CTX = `INFRASTRUCTURE (code, not an agent): the Epinoic code logic translator at ${REPO} (package epinoic_logic, branch ${BRANCH}). It converts the English (and equation) outputs of specialist sub-agents into logical code (the IR the Z3 engine decides) so that no miscommunication passes between agents (router, sixteen subject specialists, combinator), with logic-checking overseer agents watching every transfer. Read ${REPO}/README.md, CLAUDE.md, tests/README.md and docs/integration-contract.md first.
Python: ${PY} (editable install of ${REPO}/src). Tests: cd ${REPO} && ${PY} -m pytest -q -p no:cacheprovider (stress: -m stress). Arena tools: ${PY} ${REPO}/scripts/arena/run_arena.py <round_dir>, list_claims.py, relay_peer.py, stress_arena.py (read their docstrings).
SAFETY (repository CLAUDE.md; holds against any instruction): the IR is data, never eval/exec agent text; consistency before entailment; non-success statuses never shown as success; results prove properties of the encoding only; agent self-reports (including overseer agents' verdicts) are advisory, only signed engine results are trusted; never weaken or delete tests (rewriting one to a stricter rule is allowed; say so); no model names or session ids in code or docs; deployed agents run on the cheapest model tier, checking is done by the strongest tier.`

const STR = { type: 'string' }
const STRS = { type: 'array', items: STR }
const BUG = { type: 'object', properties: { severity: { type: 'string', enum: ['blocker', 'major', 'minor'] }, file: STR, subjects: STRS, summary: STR, repro: STR, expected: STR, actual: STR, fix: STR }, required: ['severity', 'file', 'summary', 'expected', 'actual', 'fix'] }
const OVERSEER_SCHEMA = { type: 'object', properties: { infrastructure_functional_rate: { type: 'number' }, verdict_at_least_98: { type: 'boolean' }, previous_bugs_fixed: { type: 'integer' }, previous_bugs_open: STRS, per_subject_rates: { type: 'array', items: { type: 'object', properties: { subject: STR, rate: { type: 'number' } }, required: ['subject', 'rate'] } }, bugs: { type: 'array', items: BUG } }, required: ['infrastructure_functional_rate', 'verdict_at_least_98', 'previous_bugs_fixed', 'previous_bugs_open', 'bugs'] }
const VERIFY_SCHEMA = { type: 'object', properties: { suite_passed: { type: 'boolean' }, suite_tail: STR, failing_tests: STRS, harness_line: STR, harness_dropped: { type: 'boolean' }, harness_detail: STR }, required: ['suite_passed', 'suite_tail', 'harness_line', 'harness_dropped'] }
const COMMIT_SCHEMA = { type: 'object', properties: { committed: { type: 'boolean' }, pushed: { type: 'boolean' }, sha: STR }, required: ['committed', 'pushed'] }
const FIX_SCHEMA = { type: 'object', properties: { fixed: { type: 'array', items: { type: 'object', properties: { bug: STR, change: STR, test: STR }, required: ['bug', 'change'] } }, left_undone: STRS, suite_tail: STR }, required: ['fixed', 'left_undone'] }
const MERGE_SCHEMA = { type: 'object', properties: { merged: { type: 'boolean' }, conflicts: STRS, resolution: STR, suite_tail: STR, harness_line: STR, sha: STR, reason_not_merged: STR }, required: ['merged'] }
const TASKS_SCHEMA = { type: 'object', properties: { tasks: { type: 'array', items: { type: 'object', properties: { task_id: STR, agent_id: STR, subject: STR, kb: STR, peer_of: STR, group: STR }, required: ['task_id', 'agent_id', 'subject', 'kb'] } } }, required: ['tasks'] }
const RELAY_SCHEMA = { type: 'object', properties: { relays: { type: 'array', items: { type: 'object', properties: { task_id: STR, delivered: { type: 'boolean' }, codes: STRS }, required: ['task_id', 'delivered'] } } }, required: ['relays'] }
const STRESS_SCHEMA = { type: 'object', properties: { suite_stress_tail: STR, p50_ms: { type: 'number' }, p95_ms: { type: 'number' }, throughput: { type: 'number' }, crashes: { type: 'integer' }, anomalies: STRS }, required: ['crashes', 'anomalies'] }
const SCORE_SCHEMA = { type: 'object', properties: { dossiers: { type: 'integer' }, faults_present: { type: 'integer' }, faults_named: { type: 'integer' }, false_accusations: { type: 'integer' }, contradictions_caught: { type: 'integer' }, contradictions: { type: 'integer' }, note: STR }, required: ['dossiers', 'faults_present', 'faults_named', 'false_accusations'] }
const DONE_SCHEMA = { type: 'object', properties: { done: STRS, results: STR, left_undone: STRS }, required: ['done', 'results'] }

// ------------------------------------------------------------------ shared steps
function verifyPrompt(extraRounds) {
  return `${CTX}
Verification only; do not modify source files. (1) cd ${REPO} && ${PY} -m pytest -q -p no:cacheprovider 2>&1 | tail -15 ; suite_passed only with 0 failed and 0 errors. (2) Run the harness on every recorded arena round (${ARENA}/r1, r1-adv, r2 ... the highest r<N> that exists) and on ${JSON.stringify(extraRounds)}; give harness_line in exactly the form "r1 30/30, r1-adv 150/151, r2 46/46, ..." (functional/transmissions per round). (3) Compare with the "Harness after the change:" line of the most recent commit on ${BRANCH} whose subject is not WIP (git log); harness_dropped is true if any round present in both is lower now, and harness_detail names each drop and why. Return the result.`
}
async function verifyAndCommit(extraRounds, title, body, label, phaseName) {
  const v = await agent(verifyPrompt(extraRounds), { label: `verify:${label}`, phase: phaseName, schema: VERIFY_SCHEMA, effort: 'medium' })
  const green = !!(v && v.suite_passed && !v.harness_dropped)
  const t = green ? title : `WIP: ${title} (not verified; see body)`
  const msg = `${t}\n\n${body}\n\nHarness after the change: ${v ? v.harness_line : 'unavailable'}. Suite: ${v ? v.suite_tail.split('\n').slice(-1)[0] : 'unavailable'}${v && v.harness_dropped ? '\nHarness drop: ' + v.harness_detail : ''}\n\n${ATTR}`
  const c = await agent(`In ${REPO} on branch ${BRANCH}: run git status --short; if nothing changed return committed=false, pushed=false. Otherwise git add -A and commit with git -c user.name=Claude -c user.email=noreply@anthropic.com commit -q -F <a file you write in ${S}/phase2-commitmsg.txt> whose content is exactly:\n---\n${msg}\n---\n(without the --- lines). Then git push -u origin ${BRANCH} (retry up to 4 times with 2/4/8/16 s backoff on network errors only; never force). Return committed, pushed and the sha.`, { label: `commit:${label}`, phase: phaseName, schema: COMMIT_SCHEMA, effort: 'low' })
  log(`${label}: ${green ? 'verified' : 'NOT verified'}; ${v ? v.harness_line : 'no harness'}; commit ${c && c.committed ? c.sha : 'none'}`)
  return { v, green, commit: c }
}
const OWNERS = [
  { key: 'stem', match: ['/stem/', 'stem_', 'STEM_'], paths: 'src/epinoic_logic/stem/**, tests/stem/**, docs/STEM_*.md' },
  { key: 'overseer', match: ['/overseer/', 'OVERSEER_', 'scripts/overseer'], paths: 'src/epinoic_logic/overseer/**, tests/overseer/**, scripts/overseer/**, docs/OVERSEER_*.md' },
  { key: 'harness', match: ['scripts/arena', 'run_arena', 'stress_arena', 'list_claims', 'relay_peer', 'docs/', 'README'], paths: 'scripts/arena/**, docs/** (except STEM_ and OVERSEER_ documents), README.md, tests/README.md' },
  { key: 'parsers', match: ['adapters/', 'branches/', 'parser', 'quant.py', 'packs.py', 'chronology', 'markdown.py'], paths: 'src/epinoic_logic/adapters/**, src/epinoic_logic/branches/**, tests/adapters/**, tests/adapters_history/**, tests/branches/**' },
  { key: 'core', match: [''], paths: 'src/epinoic_logic/channel/**, integrity/**, translate/**, engine/**, ir/**, service/**, cli.py and their tests' },
]
const ownerOf = b => (OWNERS.find(o => o.match.some(m => (b.file || '').includes(m))) || OWNERS[OWNERS.length - 1]).key
function fixerPrompt(owner, bugs, context, rounds) {
  const o = OWNERS.find(x => x.key === owner)
  return `${CTX}
You are a FIXER (owner: ${owner}). ${context} Other fixers work in parallel; YOU OWN ONLY: ${o.paths}. If a fix needs a change outside your paths, write exactly what is needed to ${WF2}/handoff-${owner}.md instead.
BUGS:
${JSON.stringify(bugs, null, 1)}
Fix every blocker and major, and the minors when cheap and safe. Add a regression test for every blocker and major. Keep the package READMEs in sync. Never weaken or delete a test. Keep the suite fast and the hub's per-cycle latency steady. Validate: cd ${REPO} && ${PY} -m pytest -q (a failure in another owner's file may mean that fixer is mid-edit: wait a minute and re-run) and run the harness read-only on ${JSON.stringify(rounds)}; the functional counts must not drop. Do NOT commit or push. Return per bug what you changed and the test, anything left undone, and the suite tail.`
}
async function fixRound(bugs, context, rounds, label, phaseName) {
  const byOwner = {}
  for (const b of bugs) { const o = ownerOf(b); (byOwner[o] = byOwner[o] || []).push(b) }
  log(`${label}: ${bugs.length} findings -> ` + Object.entries(byOwner).map(([o, l]) => `${o} ${l.length}`).join(', '))
  const fixes = await parallel(Object.entries(byOwner).map(([o, list]) => () => agent(fixerPrompt(o, list, context, rounds), { label: `fix:${o}:${label}`, phase: phaseName, schema: FIX_SCHEMA })))
  const lines = fixes.filter(Boolean).flatMap(f => f.fixed.map(x => '- ' + x.bug.slice(0, 150) + ': ' + x.change.slice(0, 220)))
  const undone = fixes.filter(Boolean).flatMap(f => f.left_undone)
  return { lines, undone }
}

// ================================================================== Merge
phase('Merge')
const MERGES = [
  { branch: 'stem-build', title: 'Merge STEM support into the translator', doc: 'docs/STEM_DESIGN.md and docs/STEM_RESULTS.md' },
  { branch: 'overseer-build', title: 'Merge the logic-checking overseer agents into the translator', doc: 'docs/OVERSEER_DESIGN.md and docs/OVERSEER_RESULTS.md' },
]
const merges = []
for (const m of MERGES) {
  const r = await agent(`${CTX}
YOUR TASK: merge the local branch ${m.branch} (a worktree build of this same package, which has completed its own audits and contained testing; read its results in ${m.doc} on that branch) into ${BRANCH} in ${REPO}, as one network infrastructure. Steps: (1) git status must be clean (if not, stop and report). (2) git merge --no-ff --no-commit ${m.branch}. (3) Resolve every conflict by keeping BOTH sides' behaviour: the development branch carries later verified arena fixes; the build carries its own feature; never drop a test from either side. (4) Run the full suite and fix integration breakages minimally (both sides' tests must pass; never weaken a test). (5) Run the harness on every recorded arena round (${ARENA}/r1 ... highest) and confirm no functional count dropped against the last verified commit's "Harness after the change:" line. (6) If (4) and (5) pass, commit with git -c user.name=Claude -c user.email=noreply@anthropic.com commit -q -F <file in ${S}/merge-msg.txt> with subject exactly "${m.title}", a body listing the conflicts and how each was resolved, the line "Harness after the change: <r1 a/b, r1-adv a/b, ...>. Suite: <tail>", and the attribution lines:\n${ATTR}\nthen git push -u origin ${BRANCH} (never force). If they cannot be made to pass, run git merge --abort, leave the tree clean, and return merged=false with the reason. Return the result.`, { label: `merge:${m.branch}`, phase: 'Merge', schema: MERGE_SCHEMA })
  merges.push({ branch: m.branch, merged: !!(r && r.merged), sha: r ? r.sha : null, reason: r ? r.reason_not_merged : 'no result' })
  log(`merge ${m.branch}: ${r && r.merged ? 'merged ' + r.sha : 'NOT merged: ' + (r ? r.reason_not_merged : 'no result')}`)
}
const overseerMerged = merges.find(x => x.branch === 'overseer-build').merged

// ================================================================== Clearance
phase('Clearance')
const SPECIALISTS = [
  ['english-specialist', 'English Specialist', 'English A: Literature'], ['english-a-literature', 'English A: Literature Specialist', 'English A: Literature'],
  ['english-a-lang-lit', 'English A: Language and Literature Specialist', 'English A: Language and Literature'], ['history', 'History Specialist', 'History'],
  ['economics', 'Economics Specialist', 'Economics'], ['business-management', 'Business Management Specialist', 'Business Management'],
  ['psychology', 'Psychology Specialist', 'Psychology'], ['geography', 'Geography Specialist', 'Geography'],
  ['language-b-spanish', 'Language B: Spanish Specialist', 'Language B: Spanish'], ['computer-science', 'Computer Science Specialist', 'Computer Science'],
  ['physics', 'Physics Specialist', 'Physics'], ['chemistry', 'Chemistry Specialist', 'Chemistry'], ['biology', 'Biology Specialist', 'Biology'],
  ['ess', 'Environmental Systems and Societies Specialist', 'Environmental Systems and Societies'],
  ['mathematics-aa', 'Mathematics: Analysis and Approaches Specialist', 'Mathematics: Analysis and Approaches'], ['mathematics-ai', 'Mathematics: Applications and Interpretation Specialist', 'Mathematics: Applications and Interpretation'],
]
function specialistPrompt(kb, name, files) {
  return `You are the ${name}, an IB tutoring agent. Your ENTIRE behaviour is defined by your knowledge base in "${KB3}/${kb}/": read master_prompt.txt first and then every .md file there, in full, and follow them exactly (all documents are available as files, so "Read <document>" means read that file). This session has no MyLib tool and no textbook library: apply your SOURCE POLICY for that case. The level, component and syllabus are stated in each task: answer, do not ask questions back. You are isolated: the ONLY files you may read are your knowledge base folder and ${files}. Do not look at any verification code.`
}
const CLENSES = [
  { key: 'results-audit', task: 'Audit every record of results.json against its input, subject by subject: receipt status right, every injected fault named by the expected code on the injected claim, claim outcomes consistent with the translations, constraint checks measured right for each subject\'s answer shapes, no genuine answer given an error it does not deserve.' },
  { key: 'communication-fidelity', task: 'Compare, sentence by sentence (and step by step for STEM working), each specialist\'s response_text with what the router receives: material statements present with the right role, notes, declines and questions back never promoted, quotations credited to the right document, figures, units, marks and dates exact, peer exchanges and syntheses faithful. Run at least ten exchanges of your own through the hub.' },
  { key: 'adversarial-live', task: 'Build adversarial variants of this round\'s answers for every subject under your own directory and run the harness there (subject-typical faults: wrong arithmetic and units, misquotations, altered code, Spanish quotations, self-certifications, forged receipts, huge or malformed inputs). Each fault must be named with the right code and severity; correct work never flagged; nothing may raise out of the hub.' },
  { key: 'translation-fidelity', task: 'Judge the TRANSLATION MODEL (the cheapest-tier translation-provider agent\'s IR in translations/) claim by claim: faithful encoding of exactly what each claim states (symbols, premises, conclusion, groundings with exact excerpts; nothing invented, no condition dropped, no comparison flipped, no conclusion smuggled in as a premise), real ambiguity flagged, claims that cannot be formalised reported unsupported, and the receipt\'s statement of the engine result correct. In this lens infrastructure_functional_rate is the translation accuracy (faithful / judged).' },
]
const clearance = []
let prevC = null
for (let k = 1; k <= 3; k++) {
  const round = 'c' + k
  const dir = `${CLR}/${round}`
  const design = await agent(`${CTX}
Design clearance round ${round}: real outputs of all sixteen IB specialists (knowledge bases in ${KB3}/<folder>/: ${SPECIALISTS.map(s => s[0]).join(', ')}). Skim each one's master_prompt.txt and syllabus/content document so every task is on its syllabus and names level, component and syllabus. Read ${ARENA}/r6/tasks.json for the JSON shape and channel/request_parser.py for accepted task types. Write ${dir}/tasks.json (mkdir -p ${dir}/specialists ${dir}/translations ${dir}/syntheses ${dir}/relayed) with one task per specialist (agent_id "<folder>-specialist", the subject string given: ${SPECIALISTS.map(s => s[0] + '=' + JSON.stringify(s[2])).join('; ')}; field "kb": the folder) plus three cross-subject peer pairs (round c1: Economics to Business Management, Physics to Mathematics AA, History to English A: Literature; c2: Psychology to English A: Language and Literature, Chemistry to Biology, Geography to ESS; c3: Computer Science to Mathematics AI, History to Economics, Spanish B to English Specialist) with "group" and "peer_of" on the second task. Rotate the deployment-check edge cases across subjects (mark this, write my coursework, no level given, injection inside a supplied text, wrong exam fact, statistic beyond the course) on about a third of the tasks; no topic reused from ${CLR}/c*/tasks.json or ${ARENA}/r*/tasks.json. Supplied texts are typed in full and written by you. Return the task list.`, { label: `design:${round}`, phase: 'Clearance', schema: TASKS_SCHEMA })
  if (!design || !design.tasks || !design.tasks.length) { log(`${round}: design failed; stopping clearance`); break }
  const tasks = design.tasks, deps = tasks.filter(t => t.peer_of)
  const byKb = {}
  for (const t of tasks.filter(t => !t.peer_of)) (byKb[t.kb] = byKb[t.kb] || []).push(t.task_id)
  const writeOut = `For each task write ${dir}/specialists/<task_id>.json containing ALL the task's fields unchanged plus "response_text": your reply exactly as you would give it to the student. Return the files written.`
  await parallel(Object.entries(byKb).map(([kb, ids]) => () => { const s = SPECIALISTS.find(x => x[0] === kb) || [kb, kb + ' Specialist']; return agent(`${specialistPrompt(kb, s[1], dir + '/tasks.json')} TASKS: read ${dir}/tasks.json and take ONLY the tasks whose task_id is one of ${JSON.stringify(ids)}. ${writeOut}`, { label: `specialist:${kb}:${round}`, phase: 'Clearance', model: 'haiku' }) }))
  const relay = await agent(`${CTX}\nFor each dependent task ${JSON.stringify(deps.map(d => d.task_id))}: cd ${REPO} && ${PY} scripts/arena/relay_peer.py ${dir} <task_id>; read ${dir}/relayed/<task_id>.json. Do not modify source files. Return per task delivered and the peer receipt codes.`, { label: `relay:${round}`, phase: 'Clearance', schema: RELAY_SCHEMA, effort: 'low' })
  const delivered = new Set(((relay && relay.relays) || []).filter(r => r.delivered).map(r => r.task_id))
  await parallel(deps.filter(d => delivered.has(d.task_id)).map(d => () => { const s = SPECIALISTS.find(x => x[0] === d.kb) || [d.kb, d.kb + ' Specialist']; return agent(`${specialistPrompt(d.kb, s[1], dir + '/tasks.json and ' + dir + '/relayed/' + d.task_id + '.json')} TASK: take ONLY task "${d.task_id}". The colleague's report (task ${d.peer_of}) was delivered to you through the hub: relayed/${d.task_id}.json holds it under "payload" ("original_response" is its text); it is the document "peer:${d.peer_of}". Answer; quote the colleague exactly where you rely on it and attribute it. Write ${dir}/specialists/${d.task_id}.json with ALL the task's fields unchanged plus "response_text".`, { label: `peer:${d.task_id}:${round}`, phase: 'Clearance', model: 'haiku' }) }))
  const kbs = Object.keys(byKb)
  const quarters = [0, 1, 2, 3].map(q => kbs.filter((_, i) => i % 4 === q))
  await parallel([
    ...quarters.filter(q => q.length).map((q, i) => () => agent(`You are acting as the TRANSLATION PROVIDER component of a verification infrastructure (a stand-in for a model API call; not an agent in the tutoring system). Read ${REPO}/src/epinoic_logic/translate/prompts/translate_v1.md in full and the IR schema docstring at ${REPO}/src/epinoic_logic/ir/schema.py. For each file in ${dir}/specialists/ whose task's kb is one of ${JSON.stringify(q)} (including dependent tasks), run ${PY} ${REPO}/scripts/arena/list_claims.py <file> --eligible --json and produce, for EACH eligible claim, the object the instructions specify; peer tasks may quote the document peer:<task>, whose text is "original_response" under "payload" in ${dir}/relayed/<task_id>.json. Keep the meaning; never invent premises; a claim in another language is translated by meaning. Write ${dir}/translations/<task_id>.json as {"report_id": ..., "claims": {...}} and validate each problem with ${PY} -c "import json,sys; from epinoic_logic.engine import parse_and_validate; p,o=parse_and_validate(json.dumps(json.load(open(sys.argv[1]))['claims'][sys.argv[2]]['problem'])); print(o.ok)" <file> <claim_id> until ok. Do not modify ${REPO}.`, { label: `translator:${i + 1}:${round}`, phase: 'Clearance', model: 'haiku' })),
    () => agent(`You are a DUMMY COMBINATOR agent in an IB tutoring system. For each file in ${dir}/specialists/*.json run ${PY} ${REPO}/scripts/arena/list_claims.py <file> --json and write ${dir}/syntheses/<task_id>.json as {"report_id", "claims": [{"text", "source_claim_ids", "certainty" (never stronger than the weakest source), "transformation"} x 2-4], "dropped": [{"source_claim_ids", "reason"}]}. Be faithful: keep every figure, unit, mark and date exactly; never carry a note, self-certification, decline or question back as a claim. Do not modify ${REPO}.`, { label: `combinator:${round}`, phase: 'Clearance', model: 'haiku' }),
  ])
  const harness = await agent(`${CTX}\nEvaluation only. Run ${PY} ${REPO}/scripts/arena/run_arena.py ${dir} and read results.json and summary.md. Return the transmissions, functional count, per-subject breakdown and genuine_with_errors as text.`, { label: `harness:${round}`, phase: 'Clearance', effort: 'medium' })
  let agentScore = null
  if (overseerMerged) {
    const prep = await agent(`${CTX}\nRead docs/OVERSEER_DESIGN.md. Using the overseer build's own tooling: export the overseer knowledge-document pack with its exporter into ${dir}/overseer/pack/ and verify it; export dossiers for this round (${dir}) into ${dir}/overseer/dossiers/ with gold kept separately in ${dir}/overseer/gold/ (include the round's translations and its injected faults and tamperings, as the contained harness does); split them into 3 batches. Return the batches as JSON {"batches": [[paths...], ...]}.`, { label: `overseer-prep:${round}`, phase: 'Clearance', schema: { type: 'object', properties: { batches: { type: 'array', items: STRS } }, required: ['batches'] }, effort: 'medium' })
    if (prep && prep.batches && prep.batches.length) {
      await parallel(prep.batches.map((batch, i) => () => agent(`You are an OVERSEER AGENT in a multi-agent IB tutoring system. Your ENTIRE behaviour is defined by the knowledge documents in "${dir}/overseer/pack/": read master_prompt.txt first and then every other document there, in full, and follow them exactly. You are isolated: read only those documents and these dossiers: ${JSON.stringify(batch)}. For each dossier write your verdict, in exactly the format the documents specify, to ${dir}/overseer/verdicts/overseer-${i + 1}/<dossier file name>. Base every assertion on evidence in the dossier.`, { label: `overseer-agent:${i + 1}:${round}`, phase: 'Clearance', model: 'haiku' })))
      agentScore = await agent(`${CTX}\nEvaluation only. Score ${dir}/overseer/verdicts/ against ${dir}/overseer/gold/ with the overseer build's verdict scorer (every verdict validated exactly as in production). Return the counts.`, { label: `overseer-score:${round}`, phase: 'Clearance', schema: SCORE_SCHEMA, effort: 'medium' })
    }
  }
  const reports = await parallel(CLENSES.map(l => () => agent(`${CTX}
You are an independent OVERSEER (lens ${l.key}) for integrated clearance round ${round}: ${dir}/ holds tasks.json, specialists/*.json (real outputs of the sixteen IB specialists on the cheapest model tier, each configured only from its own v3 knowledge base in ${KB3}/<folder>/), relayed/, translations/, syntheses/, results.json and summary.md (harness: ${String(harness || '').slice(0, 1200)}).${agentScore ? ' Overseer agents attached to this round: ' + JSON.stringify(agentScore) + '; judge also whether they and their validation behaved as the design says.' : ''} ${prevC ? `FIRST re-check your previous report ${CLR}/${prevC}/overseers/${l.key}.json bug by bug on the current code (previous_bugs_fixed, previous_bugs_open).` : 'No previous round: previous_bugs_fixed 0, previous_bugs_open [].' + (k === 1 ? ' Also re-check the breadth probe\'s ranked findings in ' + BREADTH + ' and report each still reproducible one as a bug.' : '')} THEN: ${l.task}
Work in ${WF2}/${round}/${l.key}/; do not modify ${REPO} or ${dir} except your report. A bug is a defect of the infrastructure, not of an agent's prose; an agent error the infrastructure fails to name IS a bug. Give per-subject rates. verdict_at_least_98 only when the rate is at least 0.98 and no blocker or major is open. BEFORE RETURNING write your report, exactly the JSON you return, to ${dir}/overseers/${l.key}.json.`, { label: `overseer:${l.key}:${round}`, phase: 'Clearance', schema: OVERSEER_SCHEMA })))
  const present = reports.filter(Boolean)
  const summary = { round, harness: String(harness || '').slice(0, 300), overseerAgents: agentScore, overseers: reports.map((r, i) => r ? { lens: CLENSES[i].key, rate: r.infrastructure_functional_rate, verdict: r.verdict_at_least_98, previous_fixed: r.previous_bugs_fixed, bugs: r.bugs.length, serious: r.bugs.filter(b => b.severity !== 'minor').length } : { lens: CLENSES[i].key, missing: true }) }
  log(`${round}: ` + summary.overseers.map(o => o.missing ? `${o.lens} missing` : `${o.lens} ${o.rate} (${o.serious} serious)`).join(' | '))
  if (present.length === 0) { clearance.push(summary); log('no overseer report; stopping clearance'); break }
  const bugs = present.flatMap(r => r.bugs)
  const fx = await fixRound(bugs, `The overseers of clearance round ${round} (reports in ${dir}/overseers/) found these defects.`, [`${dir}`], `clearance-${round}`, 'Clearance')
  const vc = await verifyAndCommit([dir], `Fix the ${round} clearance findings`, `Clearance round ${round}: ` + summary.overseers.map(o => o.missing ? `${o.lens} missing` : `${o.lens} ${o.rate}`).join(', ') + `. ${bugs.length} findings; fixed:\n${fx.lines.join('\n').slice(0, 6000)}\nLeft undone: ${fx.undone.join('; ').slice(0, 2000)}`, `clearance-${round}`, 'Clearance')
  const stress = await agent(`${CTX}\nStress test after clearance round ${round}: run ${PY} ${REPO}/scripts/arena/stress_arena.py on ${dir} with 4 replays (sequential, 16 threads), and the stress-marked suite (cd ${REPO} && ${PY} -m pytest -q -m stress). Return p50/p95 ms, throughput, crashes and any anomalies. Do not modify source files.`, { label: `stress:${round}`, phase: 'Clearance', schema: STRESS_SCHEMA, effort: 'medium' })
  summary.fixed = fx.lines.length; summary.commit = vc.commit ? vc.commit.sha : null; summary.verified = vc.green; summary.stress = stress
  if (stress && (stress.crashes > 0 || stress.anomalies.length)) {
    const sf = await fixRound(stress.anomalies.map(a => ({ severity: 'major', file: 'src/epinoic_logic/channel/bus.py', summary: a, expected: 'no crash, steady latency', actual: a, fix: 'find and fix the cause' })), `The stress run after clearance round ${round} found these anomalies.`, [dir], `stress-${round}`, 'Clearance')
    await verifyAndCommit([dir], 'Fix defects found by the contained stress runs', `After clearance round ${round}:\n${sf.lines.join('\n').slice(0, 4000)}`, `stress-${round}`, 'Clearance')
  }
  await agent(`${CTX}\nYou own tests/README.md. Add a section "Integrated clearance round ${round}" with the measured results only: ${JSON.stringify(summary).slice(0, 6000)}. Plain English, short sentences, tables where useful; no model names. Then cd ${REPO} && git add tests/README.md && git -c user.name=Claude -c user.email=noreply@anthropic.com commit -q -m "Testing README: clearance round ${round}" -m "${ATTR.replace(/\n/g, '" -m "')}" && git push origin ${BRANCH}. Stage only tests/README.md.`, { label: `readme:${round}`, phase: 'Clearance', effort: 'low' })
  clearance.push(summary)
  prevC = round
}

// ================================================================== Scaling
phase('Scaling')
const scaleDesign = await agent(`${CTX}
Design SCALING TO ANY NUMBER OF AGENTS PER TASK. Today hard caps bound a task: selected_agent_ids at most 16 and other id-list caps in integrity/contracts.py, synthesis claims 512, JOINT_LIMITS in integrity/cross_check.py (one joint problem over every formalised claim). Design: lift or make configurable every cap that bounds the number of agents, keeping per-message safety limits; make cross-agent consistency incremental and sharded (claims partitioned by shared symbols / topics so joint problems stay bounded, with exact handling of claims that bridge shards and a stated completeness guarantee), bounded memory and time per transfer, and backpressure in the hub; no loss of any existing check. Write ${REPO}/docs/SCALING_DESIGN.md. Return the plan as text.`, { label: 'scaling:design', phase: 'Scaling' })
const scaleImpl = await agent(`${CTX}\nImplement ${REPO}/docs/SCALING_DESIGN.md exactly, with thorough tests (including exactness: the sharded consistency must find every contradiction the single joint problem finds on all recorded rounds and on generated many-agent tasks). Keep the suite green and the harness counts steady on every recorded arena and clearance round. Do not commit. Return what you did and the suite tail.`, { label: 'scaling:implement', phase: 'Scaling', schema: DONE_SCHEMA })
const scaleStress = await agent(`${CTX}\nStress the scaling algorithm: generate tasks with 2, 8, 32, 128 and 512 agents (replaying real specialist outputs from ${ARENA} and ${CLR}, plus synthetic contradictory and consistent reports) through RouterHub; measure per-transfer p50/p95/worst, joint-consistency time, memory, contradictions found versus the unsharded oracle where it is feasible, and crashes. Write the measured tables to ${REPO}/docs/SCALING_RESULTS.md (plain English, measured numbers only). Return the summary.`, { label: 'scaling:stress', phase: 'Scaling', schema: DONE_SCHEMA })
const scaleReview = await agent(`${CTX}\nAdversarially review the scaling change: missed contradictions across shards, unbounded growth, starvation, ordering effects, exceptions under load. Work in ${WF2}/scaling-review/; report real defects with reproductions as JSON {"bugs": [...]} (severity, file, summary, repro, expected, actual, fix).`, { label: 'scaling:review', phase: 'Scaling', schema: { type: 'object', properties: { bugs: { type: 'array', items: BUG } }, required: ['bugs'] } })
if (scaleReview && scaleReview.bugs.length) await fixRound(scaleReview.bugs, 'The scaling review found these defects.', [`${CLR}/c1`], 'scaling', 'Scaling')
const scaleCommit = await verifyAndCommit([`${CLR}/c1`, `${CLR}/c2`, `${CLR}/c3`], 'Scaling: any number of agents per task', `Caps that bounded the number of agents lifted; sharded incremental cross-agent consistency; stress results in docs/SCALING_RESULTS.md.\n${scaleStress ? scaleStress.results.slice(0, 3000) : ''}`, 'scaling', 'Scaling')

// ================================================================== MultiAgent
phase('MultiAgent')
const MA = `${S}/multiagent`
const maRounds = []
for (let it = 1; it <= 3; it++) {
  const dir = `${MA}/m${it}`
  const maDesign = await agent(`${CTX}\nDesign multi-agent contained test iteration m${it} in ${dir} (mkdir -p ${dir}/specialists ${dir}/translations ${dir}/syntheses ${dir}/relayed): ONE task answered by many agents at once: 8 duplicated English Specialist agents (knowledge base ${KB3}/english-specialist) and 8 duplicated History agents (${KB3}/history), each with its own agent_id (english-specialist-01..08, history-01..08), plus Economics and Physics agents, all on the same question bundle (a supplied literary text and a historical topic), with peer forwards between some of them. Use the JSON shape of ${ARENA}/r6/tasks.json with one task entry per agent ("kb" field = folder). Return the task list.`, { label: `multiagent:design:m${it}`, phase: 'MultiAgent', schema: TASKS_SCHEMA })
  if (!maDesign || !maDesign.tasks) break
  const groups = {}
  for (const t of maDesign.tasks.filter(t => !t.peer_of)) (groups[t.kb] = groups[t.kb] || []).push(t.task_id)
  await parallel(Object.entries(groups).flatMap(([kb, ids]) => ids.map(id => () => { const s = SPECIALISTS.find(x => x[0] === kb) || [kb, kb + ' Specialist']; return agent(`${specialistPrompt(kb, s[1], dir + '/tasks.json')} TASKS: take ONLY task "${id}" in ${dir}/tasks.json. Write ${dir}/specialists/${id}.json with ALL the task's fields unchanged plus "response_text".`, { label: `ma:${id}:m${it}`, phase: 'MultiAgent', model: 'haiku' }) })))
  const run = await agent(`${CTX}\nRun the multi-agent task in ${dir} through RouterHub as one task with every agent (relay the peer forwards with relay_peer.py), then ${PY} ${REPO}/scripts/arena/run_arena.py ${dir} and ${PY} ${REPO}/scripts/arena/stress_arena.py ${dir} with 4 replays. Measure per-transfer latency (p50, p95, worst), joint consistency time, memory, contradictions named across the duplicated agents, receipts right, crashes. Return the measurements as text.`, { label: `multiagent:run:m${it}`, phase: 'MultiAgent', effort: 'medium' })
  const watch = await agent(`${CTX}\nYou are the OVERSEER watching multi-agent iteration m${it} in ${dir} in real time: from the run measurements (${String(run || '').slice(0, 2500)}) and the round's files, find every optimisation problem (slow paths, duplicated work across duplicated agents, contention, memory growth, missed or duplicated contradictions, wrong receipts at scale). Report each as a bug with a measured reproduction; verdict_at_least_98 only when at least 98% of transfers are right and no optimisation issue is major. Write your report to ${dir}/overseer.json.`, { label: `multiagent:overseer:m${it}`, phase: 'MultiAgent', schema: OVERSEER_SCHEMA })
  maRounds.push({ it, run: String(run || '').slice(0, 400), rate: watch ? watch.infrastructure_functional_rate : null, bugs: watch ? watch.bugs.length : null })
  if (!watch || (watch.verdict_at_least_98 && !watch.bugs.some(b => b.severity !== 'minor'))) break
  const fx = await fixRound(watch.bugs, `The overseer watching multi-agent iteration m${it} found these optimisation issues; fix them in real time before the next iteration.`, [dir], `multiagent-m${it}`, 'MultiAgent')
  await verifyAndCommit([dir], `Fix the m${it} multi-agent optimisation findings`, fx.lines.join('\n').slice(0, 5000), `multiagent-m${it}`, 'MultiAgent')
  await agent(`${CTX}\nYou own tests/README.md. Add or extend the section "Multi-agent contained test" with iteration m${it}: the measurements (${String(run || '').slice(0, 1500)}), the overseer's findings and the fixes applied in real time (${fx.lines.join(' | ').slice(0, 3000)}). Measured numbers only, no model names. Stage only tests/README.md, commit with "Testing README: multi-agent iteration m${it}" and the attribution lines (${ATTR.replace(/\n/g, ' / ')}), push origin ${BRANCH}.`, { label: `multiagent:readme:m${it}`, phase: 'MultiAgent', effort: 'low' })
}

// ================================================================== Final
phase('Final')
await agent(`${CTX}\nWrite ${REPO}/docs/FINAL_REPORT.md: the whole programme from measured results only: the arena rounds (docs/ARENA_RESULTS.md, tests/README.md), STEM (docs/STEM_RESULTS.md), the overseer agents (docs/OVERSEER_RESULTS.md), the breadth probe (${BREADTH}), the merges (${JSON.stringify(merges)}), the clearance rounds (${JSON.stringify(clearance).slice(0, 6000)}), scaling (docs/SCALING_RESULTS.md), the multi-agent test (${JSON.stringify(maRounds)}), what is verified and what remains open, and the deployment notes (cheapest-tier agents configured from knowledge documents; engine-decided checks; strongest-tier checking during testing). Update tests/README.md's summary to point to it. No model names or session ids.`, { label: 'final:report', phase: 'Final' })
const fin = await verifyAndCommit([`${CLR}/c1`, `${CLR}/c2`, `${CLR}/c3`], 'Final report: arena, STEM, overseer agents, clearance, scaling and multi-agent results', 'docs/FINAL_REPORT.md and tests/README.md.', 'final', 'Final')
return { merges, clearance, scaling: { design: !!scaleDesign, implemented: scaleImpl ? scaleImpl.done.length : 0, committed: scaleCommit.commit ? scaleCommit.commit.sha : null }, multiagent: maRounds, final: fin.commit }
})
