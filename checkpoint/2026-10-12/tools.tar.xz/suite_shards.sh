#!/usr/bin/env bash
# Run the FULL pytest suite of a tree as parallel shards (16 Nov: about 39,000 tests no longer finish in one 2-hour
# process; the round-10 verification was stopped at 99% by that limit and then ran three shards by hand).
# One collection decides the tests. The collected files are split into N shards balanced by test count; each shard runs
# as its own pytest process with its own copy of the recorded rounds (the harness tests write into round directories).
# Every collected test must be accounted for by the shards' summaries: the suite is green only if every shard exits 0,
# no shard reports a failure or an error, and passed + skipped + xfailed + xpassed over all shards equals the number
# collected. Nothing is retried, skipped or deselected beyond the project's own configuration.
# Prints each shard's summary line, then ONE aggregate line in pytest's summary form, e.g.
#   "39129 passed, 1 skipped, 45 deselected, 1 xfailed in 2926.75s (3 shards of 39131 collected)"
# Exit 0 only when green.
# Usage: suite_shards.sh TREE_DIR ROUNDS_DIR "PYTHON [FLAGS]" N LOGDIR    (environment such as PYTHONPATH is inherited)
set -uo pipefail
T=$1; RND=$2; PY=$3; N=$4; L=$5
# Optional cap (21 Nov): if suite_shards.max next to this script holds a smaller number, run that many shards instead,
# so that fewer parallel pytest processes leave CPUs free and wall-clock timing tests are not squeezed by load. The
# tests, their bounds and the accounting are unchanged; the cap is printed so a reader sees it.
CAPF="$(cd "$(dirname "$0")" && pwd)/suite_shards.max"
if [ -f "$CAPF" ]; then CAP=$(tr -dc 0-9 < "$CAPF"); if [ -n "$CAP" ] && [ "$CAP" -ge 1 ] && [ "$CAP" -lt "$N" ]; then
  echo "shards capped at $CAP (requested $N) to leave CPUs free for the wall-clock timing tests"; N=$CAP; fi; fi
mkdir -p "$L"
# shellcheck disable=SC2086
(cd "$T" && EPINOIC_ARENA_ROUNDS="$RND" timeout --foreground 1800 $PY -m pytest -q -p no:cacheprovider --collect-only) > "$L/collect.log" 2>&1
CRC=$?
SEL=$(grep -oE '^[0-9]+(/[0-9]+)? tests? collected' "$L/collect.log" | tail -1 | grep -oE '^[0-9]+')
if [ $CRC -ne 0 ] || [ -z "$SEL" ]; then
  echo "collection failed (exit $CRC): $(tail -1 "$L/collect.log")"
  grep -E '^(ERROR|FAILED) ' "$L/collect.log" | head -20 | sed 's/^/  /'
  exit 1
fi
# shellcheck disable=SC2086
$PY - "$L/collect.log" "$N" "$L" "$SEL" <<'EOF' || exit 1
import collections, sys
log, n, out, sel = sys.argv[1], int(sys.argv[2]), sys.argv[3], int(sys.argv[4])
ids = [l.strip() for l in open(log, encoding='utf-8', errors='replace') if '::' in l and not l.startswith(('ERROR', 'FAILED', 'SKIPPED'))]
if len(ids) != sel:
    print(f'collection listing has {len(ids)} test ids but the summary says {sel} collected'); sys.exit(1)
files = collections.Counter(i.split('::', 1)[0] for i in ids)
shards = [[] for _ in range(n)]; load = [0] * n
for f, c in sorted(files.items(), key=lambda x: (-x[1], x[0])):
    k = load.index(min(load)); shards[k].append(f); load[k] += c
for k, s in enumerate(shards):
    with open(f'{out}/shard{k}.txt', 'w', encoding='utf-8') as fh:
        fh.write('\n'.join(sorted(s)) + '\n')
print(f'collected {sel} tests in {len(files)} files; shard loads {load}')
EOF
PIDS=()
for k in $(seq 0 $((N - 1))); do
  rm -rf "$L/rounds$k"; mkdir -p "$L/rounds$k"; cp -r "$RND/." "$L/rounds$k/"
  # shellcheck disable=SC2086,SC2046
  (cd "$T" && EPINOIC_ARENA_ROUNDS="$L/rounds$k" timeout --foreground 10800 $PY -m pytest -q -rs -p no:cacheprovider $(cat "$L/shard$k.txt")) > "$L/suite$k.log" 2>&1 &
  PIDS+=($!)
done
RCS=""
for p in "${PIDS[@]}"; do wait "$p"; RCS="$RCS $?"; done
# shellcheck disable=SC2086
$PY - "$L" "$N" "$SEL" $RCS <<'EOF'
import re, sys
L, n, sel = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
rcs = [int(x) for x in sys.argv[4:]]
keys = ['failed', 'passed', 'skipped', 'deselected', 'xfailed', 'xpassed', 'warnings', 'warning', 'errors', 'error']
tot = {k: 0 for k in keys}; secs = 0.0; bad = []
for k in range(n):
    lines = [l.strip().strip('=').strip() for l in open(f'{L}/suite{k}.log', encoding='utf-8', errors='replace')]
    summ = next((l for l in reversed(lines) if re.search(r'\bin [0-9.]+s\b', l) and re.search(r'\d+ (passed|failed|error)', l)), '')
    print(f'shard {k}: {summ or "no summary line (" + (lines[-1] if lines else "empty log") + ")"} (exit {rcs[k]})')
    if not summ or rcs[k] != 0:
        bad.append(k)
    for num, word in re.findall(r'(\d+) (failed|passed|skipped|deselected|xfailed|xpassed|warnings|warning|errors|error)\b', summ.split(' in ')[0]):
        tot[word] += int(num)
    m = re.search(r'\bin ([0-9.]+)s\b', summ)
    secs = max(secs, float(m.group(1))) if m else secs
    for l in lines:
        if l.startswith(('FAILED ', 'ERROR ', 'SKIPPED ')):
            print('  ' + l[:300])
fails = tot['failed'] + tot['errors'] + tot['error']
counted = tot['passed'] + tot['skipped'] + tot['xfailed'] + tot['xpassed'] + fails
parts = []
if fails:
    parts += [f"{tot['failed']} failed"] if tot['failed'] else []
parts.append(f"{tot['passed']} passed")
for w in ('skipped', 'deselected', 'xfailed', 'xpassed'):
    if tot[w]:
        parts.append(f'{tot[w]} {w}')
if tot['errors'] + tot['error']:
    parts.append(f"{tot['errors'] + tot['error']} errors")
if tot['warnings'] + tot['warning']:
    parts.append(f"{tot['warnings'] + tot['warning']} warnings")
line = ', '.join(parts) + f' in {secs:.2f}s ({n} shards of {sel} collected)'
if counted != sel:
    line += f'; ACCOUNTING: {counted} counted, {sel} collected'
print(line)
sys.exit(0 if (not bad and not fails and counted == sel) else 1)
EOF
