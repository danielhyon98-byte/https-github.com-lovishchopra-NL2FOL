import json, sys

C1 = sys.argv[1]
TASKS = C1 + "/tasks.json"
NOTES = C1 + "/design-notes.json"

bi = {
    "task_id": "bi-p8d",
    "group": "p8d",
    "subject": "Biology",
    "agent_id": "biology-specialist",
    "kb": "biology",
    "task_type": "data_based_question",
    "question": (
        "I'm a Biology HL student (the course first assessed in 2025; my exams are in May 2027). "
        "Paper 2 Section A data-based practice question. Researchers at Lowmere University (a fictional "
        "university; practice data written for this exercise) randomly allocated 24 volunteers to two groups "
        "of 12. The ice-water group held one hand in water at 2 °C for 3 minutes; the warm-water group held one "
        "hand in water at 35 °C for 3 minutes. Blood samples and heart rate were taken before immersion and at "
        "the end of immersion. Ice-water group: mean plasma adrenaline concentration 0.30 nmol dm⁻³ before and "
        "0.84 nmol dm⁻³ at the end of immersion; mean heart rate 68 beats min⁻¹ before and 85 beats min⁻¹ at "
        "the end of immersion. Warm-water group: mean plasma adrenaline concentration 0.32 nmol dm⁻³ before and "
        "0.36 nmol dm⁻³ at the end of immersion; mean heart rate 70 beats min⁻¹ before and 71 beats min⁻¹ at "
        "the end of immersion. The researchers compared the increase in adrenaline concentration between the two "
        "groups with a t-test for two independent samples and obtained t = 5.41; the critical value at p = 0.05 "
        "is 2.07. A Psychology student will use your answer to evaluate a study of stress and memory, so state "
        "each result clearly with its units. "
        "(a) Calculate the percentage increase in mean plasma adrenaline concentration in each group. [2] "
        "(b) Calculate the percentage change in mean heart rate in each group, and the mean duration of one "
        "cardiac cycle, in seconds, in the ice-water group at the end of immersion. [3] "
        "(c) State the number of degrees of freedom for the t-test, and what the result shows at p = 0.05. [2] "
        "(d) Explain how adrenaline secreted by the adrenal glands prepares the body for vigorous activity, "
        "including the role of its receptor in the plasma membrane and of cyclic AMP. [3] "
        "(e) Suggest one reason why these data do not show that adrenaline alone caused the rise in heart rate "
        "in the ice-water group. [1] "
        "Write no more than 300 words, plus working."
    ),
    "supplied_texts": [],
}

STUDY = (
    "The Lowmere stress and memory study (practice material written for this exercise; the researchers, "
    "Lowmere University and all results are fictional)\n\n"
    "Aim: to investigate whether adrenaline released during a stressful experience improves later memory for "
    "emotionally arousing images.\n\n"
    "Participants: 24 psychology undergraduates at Lowmere University (15 women and 9 men, aged 18 to 23) "
    "volunteered in return for course credit. People with heart or circulation problems were excluded. "
    "Participants were randomly allocated to two groups of 12.\n\n"
    "Procedure: each participant attended alone at 10 a.m. and was told that the study was about 'skin "
    "temperature and mood'. A nurse took a blood sample from the arm and recorded heart rate. The ice-water "
    "group then held one hand in water at 2 °C for 3 minutes; the warm-water group held one hand in water at "
    "35 °C for 3 minutes. Two participants in the ice-water group took their hand out before 3 minutes and "
    "were asked to put it back in; their data were kept. A second blood sample was taken and heart rate "
    "recorded at the end of immersion. Participants then viewed 40 photographs on a screen for 5 seconds "
    "each: 20 emotionally arousing (for example, a car crash and a snarling dog) and 20 neutral (for example, "
    "a kettle and a bus stop), in the same random order for everyone. One week later, without warning, each "
    "participant was given 10 minutes to write a short description of every photograph they could remember. "
    "A research assistant who knew which group each participant was in scored the descriptions. Participants "
    "were debriefed after the recall test.\n\n"
    "Physiological results: the adrenaline and heart-rate data were analysed by the Biology specialist "
    "(document peer:bi-p8d) and are not repeated here.\n\n"
    "Table 1: Mean number of photographs recalled after one week (out of 20 of each type)\n"
    "Group | Emotionally arousing | Neutral\n"
    "Ice-water group (n = 12) | 9.5 | 5.0\n"
    "Warm-water group (n = 12) | 7.0 | 5.5\n\n"
    "Within the ice-water group, the correlation between each participant's rise in adrenaline and the number "
    "of arousing photographs they recalled was r = +0.41.\n\n"
    "The researchers concluded: 'Adrenaline released under stress strengthens the memory of emotional events.'"
)

ps = {
    "task_id": "ps-p8d",
    "group": "p8d",
    "peer_of": "bi-p8d",
    "subject": "Psychology",
    "agent_id": "psychology-specialist",
    "kb": "psychology",
    "task_type": "essay",
    "question": (
        "I'm taking Psychology SL and sit Paper 2 in May 2027 (the guide first assessed in 2027). Paper 2 "
        "Section B practice. You have received the Biology specialist's analysis of the physiological data from "
        "the Lowmere study through the hub; it is supplied to you as the document peer:bi-p8d. Use it with the "
        "supplied description of the study. Where you rely on the Biology specialist's figures (the percentage "
        "increases in adrenaline and heart rate, and the t-test result), quote them exactly and attribute them "
        "to the Biology specialist. Evaluate the Lowmere study with reference to two or more of the following "
        "concepts: bias, causality, measurement, responsibility. [15] In your evaluation, use the Biology "
        "specialist's results to judge whether the ice-water task raised adrenaline and heart rate as the "
        "researchers intended, and how far the study supports the researchers' conclusion about a biological "
        "cause of better memory. Write no more than 500 words."
    ),
    "supplied_texts": [
        {
            "document_id": "doc-lowmere",
            "title": "The Lowmere stress and memory study (study description, supplied text)",
            "author": "Task data",
            "text": STUDY,
        }
    ],
}

tasks = json.load(open(TASKS, encoding="utf-8"))
before = json.dumps(tasks, ensure_ascii=False)
ids = {t["task_id"] for t in tasks}
assert len(tasks) == 22 and "bi-p8d" not in ids and "ps-p8d" not in ids
tasks += [bi, ps]
assert json.dumps(tasks[:22], ensure_ascii=False) == before
with open(TASKS, "w", encoding="utf-8") as f:
    f.write(json.dumps(tasks, indent=2, ensure_ascii=False) + "\n")

d = json.load(open(NOTES, encoding="utf-8"))
d["purpose"] = (
    "Real outputs of all sixteen v4 IB specialists crossing the hub, with four cross-subject peer relays "
    "(humanities-humanities: p8a, Economics to Business Management, and p8c, History to English A: Literature; "
    "STEM-STEM: p8b, Physics to Mathematics: Analysis and Approaches; STEM-humanities: p8d, Biology to "
    "Psychology), the first end-to-end test of the merged STEM support (ten STEM tasks are worked problems with "
    "given values, units, equations and results), and deployment-check edge cases on about a third of the "
    "standalone tasks, rotated away from round 7's subjects."
)
cv = d["conventions"]
cv["task_ids"] = (
    "<subject abbreviation>-t14 for the sixteen standalone tasks (round 7 used t13); "
    "<abbreviation>-p8a/p8b/p8c/p8d for the peer pairs. Both tasks of a pair carry the same group; the second "
    "also carries peer_of naming the first."
)
cv["cross_pairs"] = (
    "Daniel requires at least three cross pairs: one between two humanities subjects, one between two STEM "
    "subjects and one between a STEM and a humanities subject. Humanities-humanities: p8c (History to English "
    "A: Literature), and p8a (Economics to Business Management, two individuals-and-societies subjects). "
    "STEM-STEM: p8b (Physics to Mathematics: Analysis and Approaches). STEM-humanities: p8d (Biology to "
    "Psychology), added after the first design: the Biology specialist works a data-based question on a "
    "fictional stress study (adrenaline, heart rate, a t-test) and the Psychology specialist evaluates the same "
    "study through Paper 2 Section B concepts, quoting and attributing the Biology figures exactly."
)
cv["supplied_texts"] = cv["supplied_texts"] + (
    " The p8d study (Lowmere University, its researchers and its results) is fictional; its physiological "
    "givens are in bi-p8d's question text and its procedure and memory results in ps-p8d's supplied text."
)
cv["stem_givens"] = cv["stem_givens"] + (
    " bi-p8d follows this: all its values are in the question text and it has no supplied text."
)
cv["topics_checked"] = cv["topics_checked"] + (
    " The p8d pair (adrenaline, heart rate and a t-test in a cold-water stress study; evaluation of the study's "
    "claim about stress and emotional memory) was checked against arena/tasks.json, arena/r2 to r7 tasks.json "
    "and this round's first 22 tasks: no task used adrenaline, hormones, stress and memory, a t-test or "
    "cardiac cycles. Sleep and melatonin were avoided because ll-t14 is about teenage sleep. Heart rate appears "
    "in ps-t14 only as a scenario detail of conditioned fear, a different topic."
)
d["edge_case_share"] = (
    "7 of 24 tasks (7 of the 16 standalone tasks, about 29 per cent of all tasks); all six edge cases are "
    "covered, 'mark this' twice."
)
d["edge_case_rotation"] = d["edge_case_rotation"].replace(
    "No peer-pair task carries an edge case.",
    "No peer-pair task carries an edge case (p8d included).",
)
d["peer_pairs"].append({
    "group": "p8d",
    "first": "bi-p8d",
    "second": "ps-p8d",
    "direction": "Biology to Psychology",
    "kind": "STEM-humanities",
})
kinds = {"p8a": "humanities-humanities", "p8b": "STEM-STEM", "p8c": "humanities-humanities"}
for p in d["peer_pairs"]:
    p.setdefault("kind", kinds.get(p["group"]))
sc = d["stem_coverage"]
sc["branches"] = sc["branches"].replace(
    "sciences: ph-t14, ch-t14, bi-t14, ess-t14, ph-p8b;",
    "sciences: ph-t14, ch-t14, bi-t14, ess-t14, ph-p8b, bi-p8d (not probed; expected by subject);",
)
sc["what_to_watch"].extend([
    "bi-p8d: units outside the STEM unit table (nmol dm⁻³, beats min⁻¹) should give ST-UNIT-001 warnings at "
    "most; percentage changes 180% and 12.5% (adrenaline) and +25.0% and +1.43% (heart rate); the cardiac "
    "cycle 60 ÷ 85 = 0.706 s is the wrong-unit site; degrees of freedom 12 + 12 − 2 = 22 is a count.",
    "Cross-agent consistency in p8d: every Biology figure the Psychology report quotes (180%, 12.5%, 25.0%, "
    "1.43% or 1.4%, 0.71 s, 22 degrees of freedom, t = 5.41 > 2.07) must match peer:bi-p8d exactly and be "
    "attributed to the Biology specialist, never to the researchers' table; the Psychology report runs on the "
    "generic branch, so any agreement or conflict is for the overseers to note.",
])
sc["harness_mutation_sites"] = sc["harness_mutation_sites"] + (
    " bi-p8d holds all three sites (percentage chains, the 0.706 s cardiac cycle, values beside operators)."
)
sc["request_probe"] = sc["request_probe"] + (
    " The probe ran before p8d was added and did not cover bi-p8d; its routing to the sciences branch and its "
    "request quantities are expected from the subject, not confirmed."
)
d["tasks"]["bi-p8d"] = {
    "edge_case": None,
    "topic": "Adrenaline and heart rate in a cold-water stress study: percentage changes, cardiac cycle, t-test, adrenaline signalling (C2.1, C3.1)",
    "level": "HL",
    "component": "Paper 2 Section A data-based question",
    "syllabus": "Biology, first assessed 2025",
    "setter_notes": [
        "(a) Ice-water group (0.84 − 0.30) ÷ 0.30 × 100 = 180% increase; warm-water group (0.36 − 0.32) ÷ 0.32 × 100 = 12.5% increase.",
        "(b) Heart rate: ice-water (85 − 68) ÷ 68 × 100 = +25.0%; warm-water (71 − 70) ÷ 70 × 100 = +1.43% (1.4%). Cardiac cycle at 85 beats min⁻¹ = 60 ÷ 85 = 0.706 s (0.71 s).",
        "(c) Degrees of freedom 12 + 12 − 2 = 22; t = 5.41 > 2.07, so the null hypothesis is rejected: the increase in adrenaline was significantly greater in the ice-water group at p = 0.05 (a significant difference, not proof of cause).",
        "(d) Adrenaline, an amine, is hydrophilic and binds a G-protein-coupled receptor in the plasma membrane; cyclic AMP is produced as a second messenger and the pathway leads to glycogen breakdown (glucose for respiration); heart rate and ventilation rise, preparing for vigorous activity. Receptor types are HL (C2.1).",
        "(e) Sympathetic nerves from the medulla also speed the heart; the cold and pain of immersion are sensory input acting through nerves; the data are means and correlational within the ice-water group, so the rise in heart rate cannot be assigned to adrenaline alone.",
        "The question states every given in its text (stem_givens); the Psychology student's use is named so that results carry units.",
    ],
}
d["tasks"]["ps-p8d"] = {
    "edge_case": None,
    "topic": "Evaluating a fictional study of adrenaline, stress and memory for emotional images through concepts (peer of bi-p8d)",
    "level": "SL",
    "component": "Paper 2 Section B (one 15-mark discussion of a study through two or more named concepts)",
    "syllabus": "Psychology, first assessment 2027",
    "setter_notes": [
        "Relies on peer:bi-p8d: adrenaline rose 180% in the ice-water group and 12.5% in the warm-water group; heart rate +25.0% against +1.43%; t = 5.41 > 2.07 with 22 degrees of freedom. Any quotation of the Biology report must be exact and attributed to the Biology specialist; the study text deliberately leaves these figures out.",
        "Causality: adrenaline was not manipulated directly (cold, pain, discomfort and other stress responses differ between groups); the within-group correlation r = +0.41 on 12 participants is weak evidence of cause; the warm-water group gives a manipulation check that the Biology results support.",
        "Bias: the scorer knew each participant's group (researcher bias; no blind scoring); a small, self-selected undergraduate sample paid in course credit (sampling bias); two ice-water participants told to put their hands back in.",
        "Measurement: the blood draw itself may be stressful; free recall scored from written descriptions needs a scoring rule and inter-rater check; arousing images recalled better in both groups (9.5 and 7.0 of 20, against 5.0 and 5.5 for neutral images).",
        "Responsibility: deception ('skin temperature and mood'), discomfort and the right to withdraw (participants asked to put their hand back), course-credit incentive, debriefing only after a week.",
        "Assessment K12 and K38: two or more concepts are required for the top bands; the question names four. Study details are the supplied ones; no outside study figures are needed, and any cited real study beyond its broad finding needs a source.",
    ],
}
with open(NOTES, "w", encoding="utf-8") as f:
    f.write(json.dumps(d, indent=2, ensure_ascii=False))

json.load(open(TASKS, encoding="utf-8")); json.load(open(NOTES, encoding="utf-8"))
print("ok", len(tasks))
