from fractions import Fraction as F
import math
p = print
p("== PHYSICS ph-t14 (orbit)")
G=6.67e-11; M=6.4e23; R=3.4e6; h=1.6e6; r=R+h
GM=G*M; p("GM",GM)
g=GM/R**2; p("g surface",g)
T=2*math.pi*math.sqrt(r**3/GM); p("T s",T,"h",T/3600)
v=math.sqrt(GM/r); p("v orbit",v,"2pir/T",2*math.pi*r/T)
vesc=math.sqrt(2*GM/R); p("v esc",vesc)
p("== PHYSICS ph-p8b (SHM)")
m=0.50;k=50;x0=0.040
w=math.sqrt(k/m); p("omega",w); Tp=2*math.pi/w; p("T",Tp)
p("vmax",w*x0,"E",0.5*k*x0**2,"E alt",0.5*m*w**2*x0**2)
x=0.020; p("v at 2 cm",w*math.sqrt(x0**2-x**2)); p("T doubled mass",2*math.pi*math.sqrt(2*m/k))
p("== MAA p8b: 20 sqrt3",20*math.sqrt(3),"cm/s; physics speed cm/s",100*w*math.sqrt(x0**2-x**2))
p("== CHEMISTRY ch-t14")
mb=72.36-71.21; p("mass burned",round(mb,4)); n=mb/46.08; p("n",n)
Q=200.0*4.18*24.5; p("Q J",Q); dH=-Q/1000/n; p("dH kJ/mol",dH)
p("% error",(1367-abs(dH))/1367*100)
p("student: Q", 200.0*4.18*297.65, "dH", 200.0*4.18*297.65/1000/0.0250, "pct", (9952-1367)/1367*100)
p("== BIOLOGY bi-t14")
O={'AB':20,'Ab':12,'aB':7,'ab':21}; N=60
A=32; a=28; B=27; b=33
E={'AB':A*B/N,'Ab':A*b/N,'aB':a*B/N,'ab':a*b/N}; p("E",E)
chi=sum((O[k]-E[k])**2/E[k] for k in O); p("chi2",chi)
p("pop A", 189/60*12000, "mean", 189/60)
p("Lincoln", 48*60/9)
p("== ESS ess-t14")
GPP=2.5e4; Rp=1.5e4; NPP=GPP-Rp; p("NPP",NPP); p("GPP/solar %",GPP/5.0e6*100)
GSP=1800-1080; NSP=GSP-540; p("GSP",GSP,"NSP",NSP,"TE %",GSP/NPP*100)
p("== MAA maa-t14")
d=F(31-11,5); u1=11-2*d; p("d",d,"u1",u1); S=lambda n: F(n,2)*(2*u1+(n-1)*d); p("S20",S(20)); p("S22",S(22),"S23",S(23))
p("root", (-1+math.sqrt(8001))/4)
p("log eq x^2=25 -> x=5; check (x+4)(x-4)=",(5+4)*(5-4))
p("exp eq roots y=1/2,2 -> x=-1,1; check", 2*2**(2*1)-5*2**1+2, 2*2**(2*-1)-5*2**-1+2)
p("== MAI mai-t14")
b_=120; c_=95; A_=math.radians(72)
BC=math.sqrt(b_**2+c_**2-2*b_*c_*math.cos(A_)); p("BC",BC)
area=0.5*b_*c_*math.sin(A_); p("area",area)
sinB=c_*math.sin(A_)/BC; p("angle ABC",math.degrees(math.asin(sinB)))
per=b_+c_+BC; p("perimeter",per,"cost",per*18.50,"cost using 128",(120+95+128)*18.5)
p("pct error",abs(5500-area)/area*100)
p("== CS cs-t14")
p("3F",int('3F',16),bin(0x3F),"C4",int('C4',16),bin(0xC4),"A9",int('A9',16))
px=1600*400; bits=px*24; p("pixels",px,"bits",bits,"bytes",bits//8,"MB",bits/8/1e6)
p("8-bit bytes",px,"reduction %",(bits/8-px)/(bits/8)*100)
for A1 in (0,1):
  for B1 in (0,1):
    for C1 in (0,1):
      X=(A1 and B1) or ((not A1) and C1); Y=(not (A1 or B1)) or (A1 and not B1)
      p(A1,B1,C1,"X",int(bool(X)),"Y",int(bool(Y)),"notB",int(not B1))
p("== ECON ec-t14")
for yr,nom,defl in ((2023,612.0,118.0),(2024,655.2,124.8),(2025,682.5,131.4)):
  p(yr,"real GDP",nom/defl*100)
r24=655.2/124.8*100; r25=682.5/131.4*100; r23=612.0/118.0*100
p("growth 24-25",(r25-r24)/r24*100,"23-24",(r24-r23)/r23*100,"nominal 24-25",(682.5-655.2)/655.2*100)
p("unemp",550/12500*100,567/12600*100,762/12700*100)
p("real GDP per capita 2024",r24*1e9/24.2e6,"2025",r25*1e9/24.4e6)
p("real interest 2025",4.00-5.2)
p("== ECON ec-p8a")
p("imports",10.0-4.0,9.0-5.5,"tariff rev",150*3.5,"dom rev",600*4.0,750*5.5,750*5.5-600*4.0,(750*5.5-600*4.0)/(600*4.0)*100)
p("consumer spend",600*10,750*9,"foreign rev",600*6,600*3.5,"welfare loss",0.5*150*1.5+0.5*150*1.0)
p("== BM bm-p8a")
save_t=4000*(0.20-0.17); p("steel saved t",save_t,"saving",save_t*750,"net",save_t*750-15000)
net=save_t*750-15000; p("payback yrs",280000/net,"months frac",(280000/net-3)*12)
p("ARR",((5*net-280000)/5)/280000*100)
dfs=[0.943,0.890,0.840,0.792,0.747]; p("sum df",sum(dfs),"PV",net*sum(dfs),"NPV",net*sum(dfs)-280000)
net0=save_t*600-15000; p("pre-tariff net",net0,"NPV",net0*sum(dfs)-280000,"payback",280000/net0)
p("exact dfs",[round(1/1.06**n,4) for n in range(1,6)])
p("== BM bm-t14 cash flow")
ob=4500
cash=[9000,7500,11000]; credit_recv=[3000,4000,2500]
out=[5200+4000+1500+600, 4800+4000+1500+600+3000, 6100+4000+1500+600]
for i in range(3):
  inf=cash[i]+credit_recv[i]; net_=inf-out[i]; cb=ob+net_; p(["Jan","Feb","Mar"][i],"in",inf,"out",out[i],"net",net_,"open",ob,"close",cb); ob=cb
p("current ratio",13700/7000,"acid test",(13700-6200)/7000,"student acid",(13700-3000)/7000)
p("student: Jan in",9000+4000,"out (slip) 11100 net",13000-11100,"close",4500+1900,"Feb in",7500+2500,"net",10000-13900,"close",6400-3900,"Mar in",11000+5000,"net",16000-12200,"close",2500+3800)
p("== GEOG Spearman")
cnt=[214,186,151,97,88,61,42,45,23,19]
order=sorted(range(10),key=lambda i:cnt[i]); rk=[0]*10
for rnk,i in enumerate(order,1): rk[i]=rnk
d2=sum(((i+1)-rk[i])**2 for i in range(10)); p("sum d2",d2,"rs",1-6*d2/(10**3-10))
eqs=[24,22,23,18,15,16,12,13,9,11]
order=sorted(range(10),key=lambda i:eqs[i]); rk=[0]*10
for rnk,i in enumerate(order,1): rk[i]=rnk
d2=sum(((i+1)-rk[i])**2 for i in range(10)); p("EQS sum d2",d2,"rs",1-6*d2/990)
p("== PSYCH heart rate rise %",(108-72)/72*100)
p("== LL sleep 8h10-6h50 min",(8*60+10)-(6*60+50))
