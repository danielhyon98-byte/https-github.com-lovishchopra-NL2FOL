"""Read-only probe: how the STEM build (stem worktree source) routes each c1 subject and reads each STEM question.

Run with `python -I -B` so no bytecode is written into the repository. Imports only; nothing is verified or written.
"""
import json
import sys

STEM_SRC, TASKS = sys.argv[1], sys.argv[2]
sys.path.insert(0, STEM_SRC)
import epinoic_logic  # noqa: E402
from epinoic_logic.branches.registry import default_registry  # noqa: E402
from epinoic_logic.stem.document import build_document  # noqa: E402
from epinoic_logic.translate.subjects import resolve_profile  # noqa: E402

print("imported from:", epinoic_logic.__file__)
tasks = json.load(open(TASKS, encoding="utf-8"))
reg = default_registry()
for t in tasks:
    branch, profile = reg.for_subject(t["subject"])
    print(f"{t['task_id']:8} {t['subject'][:44]:44} -> branch={branch.key:16} profile={profile.key}")
print()
for t in tasks:
    branch, profile = reg.for_subject(t["subject"])
    if branch.key not in ("sciences", "mathematics", "computer_science"):
        continue
    doc = build_document("Answer.", request_text=t["question"], profile=profile.key)
    req = doc.request
    q = t["question"]
    quants = [q[a:b] for _n, a, b in req.quantities]
    targets = [(q[tg.start:tg.end] if tg.end > tg.start else "?", "approx" if tg.approx else "exact") for tg in req.targets]
    names = sorted({b.symbol if hasattr(b, "symbol") else str(b) for b in req.bindings})[:12]
    print(f"{t['task_id']}: {len(req.bindings)} bindings {names}; {len(quants)} quantities {quants[:14]}; targets {targets}")
    codes = sorted({f.code for f in doc.findings})
    if codes:
        print(f"    front-end findings on the request: {codes}")
