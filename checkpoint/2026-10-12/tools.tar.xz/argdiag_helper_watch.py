"""Print HELPER-NEEDED <round> once when the argdiag continuation starts a verify round whose helper lenses are collected."""
import json, os, re, sys
J = '/root/.claude/projects/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/subagents/workflows/wf_b4895ea7-478/journal.jsonl'
STATE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'argdiag-helper-watch.json')
done = set(json.load(open(STATE))) if os.path.exists(STATE) else {3}
try:
    rounds = {int(m.group(1)) for m in re.finditer(r'"label":"verify:(?:adversarial|rerun):(\d+):collect"', open(J).read())}
except OSError:
    rounds = set()
for r in sorted(rounds - done):
    print(f'HELPER-NEEDED round {r}', flush=True)
    done.add(r)
json.dump(sorted(done), open(STATE, 'w'))
