const fs = require('fs')
function load(path) {
  const src = fs.readFileSync(path, 'utf8')
  const head = src.slice(src.indexOf('const REPO'), src.indexOf('const LENSES'))
  const fnStart = src.indexOf('function englishPrompt')
  const fnEnd = src.indexOf('\n}\n', src.indexOf('function designPrompt')) + 3
  const body = head.replace(/^const INFRA[\s\S]*?\n}\n/m, '') + src.slice(fnStart, fnEnd)
  return new Function(body + '; return {englishPrompt, historyPrompt, dependentPrompt, designPrompt}')()
}
const a = load(process.argv[2]), b = load(process.argv[3])
const dep = { task_id: 'hi-p9', agent_id: 'history-specialist' }
let same = 0, diff = 0
for (const r of ['r5', 'r6', 'r7']) {
  for (const [n, f] of [['en', x => x.englishPrompt(r, ['en-t1'])], ['hi', x => x.historyPrompt(r, ['hi-t1'])], ['dep', x => x.dependentPrompt(r, dep, 'en-p9')], ['design', x => x.designPrompt(r, 3, 'english')]]) {
    const eq = f(a) === f(b)
    console.log(r, n, eq ? 'same' : 'CHANGED')
  }
}
