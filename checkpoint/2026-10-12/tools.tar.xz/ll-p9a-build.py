import json

src = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2/tasks.json"
dst = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2/revisions/ll-p9a.json"

tasks = json.load(open(src, encoding="utf-8"))
task = next(t for t in tasks if t["task_id"] == "ll-p9a")

paragraph = (
    "The email persuades by presenting Jordan's earlier answer as the first step of a commitment, so that the £4 request reads as a continuation rather than a new demand. "
    "The subject line and the closing sentences frame the whole appeal as a matter of memory: \"Jordan, you told us what you love. Here's how to keep it.\" "
    "The repeated \"told us\" makes Jordan's words the theatre's record, and the repeated verb \"keep\" turns affection into a task that the reader can carry out by joining. "
    "The phrase \"one more small step\" makes the same point through structure: the ask presupposes a step already taken, and the email's bookends, opening on what Jordan said and closing with \"Now help us keep it.\", enclose the money request within that earlier exchange. "
    "The price is reduced in the same way. "
    "The monthly figure, \"£4 a month\", comes first, and the annual total, \"£48 a year\", follows beside \"less than a family ticket to the panto you love.\" "
    "The annual sum is stated rather than hidden, but the comparison does not measure cost against that sum; it chooses a reference point in which the sum looks small, and it pairs the request with the panto the email says Jordan loves. "
    "Through these choices the email makes agreeing feel consistent and modest rather than large. "
    "The Psychology specialist explains this sequence as one in which \"a small agreement becomes a commitment that people then want to keep consistent\", and the repeated \"keep\" seems to dramatise that idea. "
    "The email itself never names such a mechanism, so the sense of commitment is built by its wording rather than stated. "
    "I have not used the study the Psychology specialist cites, as I cannot check it here. "
    "Two of its quotations do not match the email: it gives \"912 people in Callowfield were already Friends\", where the email reads \"912 people in Callowfield are already Friends\", and \"reminded survey respondents of the answer they had given\" comes from the Psychology scenario, not from the email."
)

sources = "Sources: Kestrel email (supplied text); Psychology specialist's explanation (supplied text)"

response_text = paragraph + "\n\n" + sources

out = dict(task)
out["response_text"] = response_text
out["feedback_handled"] = [
    {
        "flaw_id": "f1",
        "flaw": "The answer was set out in 2 paragraphs; the task requires one analytical paragraph.",
        "change": (
            "Merged the analysis, the caveat about the Psychology specialist's study and the two mismatched quotations into one analytical paragraph "
            "(337 words, within the 350-word limit). Removed the separate 'Model paragraph for practice' label line and the separate 'Note:' paragraph. "
            "The only line after the paragraph is the Sources line."
        ),
        "kept": (
            "All quotations from the email and from the Psychology specialist are unchanged and exact; the figures £4, £48 and 912 and the claims about "
            "the subject line, the bookends, the price ordering and the commitment mechanism are kept as written."
        ),
    }
]

json.dump(out, open(dst, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print("written", dst, len(paragraph.split()), "words in paragraph")
