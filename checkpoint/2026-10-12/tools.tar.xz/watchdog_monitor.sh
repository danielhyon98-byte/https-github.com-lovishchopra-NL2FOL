#!/usr/bin/env bash
# The watchdog Monitor's command (run it as a Monitor with timeout 1800000 and re-arm on expiry): watchdog.py prints one
# line per NEW anomaly (STALL, LOOP, LONG, ENDED); the grep drops the known-benign ones; the df check alarms below 3 GB.
S=/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad
while true; do
  python3 -I $S/watchdog.py 2>&1 | grep -vE "verify:integrate-g1 repeated|ENDED wf_67fbb3da-051|ENDED wf_37dc155b-976|ENDED wf_1995d50c-4a8|ENDED wf_b5e13a71-9be|ENDED wf_59d46933-83b|ENDED wf_29cf5868-ed8|ENDED wf_cfe0ab23-21c|ENDED wf_123b3a11-e4f|ENDED wf_4c9066f4-af9|ENDED wf_7d9bf3d3-145|ENDED wf_8c6a83e3-7bc|fresh-session-integration:g2:run|LONG wf_eee12853-0ae: fix:|verify:integrate-g2 repeated|verify:integrate-g4 repeated|fresh-session-integration:g3:run|correctness:g3:run|LONG wf_eee12853-0ae: gate:.*:g[45]|correctness:g[45]:run|combinator-faults:g4:run repeated|LOOP wf_eee12853-0ae: gate:.*:g[45] repeated|LONG wf_eee12853-0ae: push:pre-r8|LOOP wf_eee12853-0ae: push:pre-r8 repeated|LOOP wf_4c9066f4-af9: fix repeated"
  a=$(df -Pm / | awk 'NR==2{print $4}'); [ "$a" -lt 3000 ] && echo "DISK LOW: ${a} MB free"
  sleep 120
done
