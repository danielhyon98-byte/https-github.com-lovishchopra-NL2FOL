#!/usr/bin/env bash
# Mark the fully fledged prototype on Bruno's repository (Daniel, 2026-10-12: "push a fully fledged prototype repository
# into Bruno's main repo once round 8 testing and optimization testing and fixing is finished").
# Phase 2 commits "Prototype: integrated translator after round 8" (docs/PROTOTYPE.md)
# after round 8 (no optimisation check runs: Daniel, 17 Oct). The hourly publisher uploads it to verified-updates only after its simulation
# passed. This script then adds, at exactly that uploaded commit, the new branch "prototype" and the annotated tag
# "prototype-round8". Ordinary pushes of new refs only; an existing ref is never moved (it stops instead).
# Usage: release_prototype.sh [--dry-run]
set -euo pipefail
case "${1:-}" in ''|--dry-run) DRY=${1:-} ;; *) echo "usage: release_prototype.sh [--dry-run]"; exit 2 ;; esac
R=/home/user/https-github.com-lovishchopra-NL2FOL
BRANCH=prototype
TAG=prototype-round8
cd "$R"
timeout 120 git fetch -q epinoic "+refs/heads/verified-updates:refs/remotes/epinoic/verified-updates" || { echo "STOP: could not fetch verified-updates"; exit 1; }
# The uploaded commit whose source is the prototype commit (subject "Prototype: ...").
TARGET=""
for C in $(git log --format=%H refs/remotes/epinoic/verified-updates -40); do
  SRC=$(git log -1 --format=%B "$C" | sed -n 's/^Source-Commit: //p' | tail -1)
  [ -n "$SRC" ] || continue
  if [ "$(git log -1 --format=%s "$SRC" 2>/dev/null | grep -c '^Prototype: ')" -gt 0 ] && [ "$(git log -1 --format=%s "$C" | grep -c '^Hourly update')" -eq 0 ]; then TARGET=$C; break; fi
done
[ -n "$TARGET" ] || { echo "NOTHING: the prototype commit is not on verified-updates yet (it comes after round 8 and its fixes)"; exit 0; }
[ "$(git log -1 --format=%B "$TARGET" | grep -c 'SIMULATION OK')" -gt 0 ] || { echo "HOLD: $TARGET does not record a passing simulation"; exit 1; }
set +e; timeout 120 git ls-remote --exit-code epinoic "refs/heads/$BRANCH" "refs/tags/$TAG" >/dev/null 2>&1; RC=$?; set -e
if [ $RC -eq 0 ]; then echo "NOTHING: $BRANCH or $TAG already exists on Bruno's repository (never moved)"; exit 0; fi
[ $RC -eq 2 ] || { echo "STOP: could not reach Bruno's repository (ls-remote exit $RC)"; exit 1; }
echo "prototype: $(git log -1 --format='%h %s' "$TARGET")"
if [ "$DRY" = "--dry-run" ]; then echo "DRY RUN: would push branch $BRANCH and tag $TAG at $TARGET"; exit 0; fi
git -c user.name=Claude -c user.email=noreply@anthropic.com tag -a "$TAG" "$TARGET" -m "Prototype after arena round 8

The integrated translator: Z3 logic translator with STEM support, the logic-checking
overseer agents with their exportable knowledge pack, consolidation and the
self-duplicating pool, and the four-minute delivery rule with the overseer-selected
fallback above 90% accuracy. Simulated before upload (full suite and every recorded
arena round). See docs/PROTOTYPE.md and UPDATE_README.md. Results prove properties
of the encoded problems only."
timeout 300 git push epinoic "$TARGET:refs/heads/$BRANCH" "refs/tags/$TAG:refs/tags/$TAG"
timeout 120 git ls-remote epinoic "refs/heads/$BRANCH" "refs/tags/$TAG"
