#!/usr/bin/env bash
# Upload the overseer prototype to Bruno-ios/Epinoic-Logic-Translator, branch overseer-prototype (Daniel, 2026-10-12:
# "the overseer build should also be uploaded to Bruno's main repository; upload the prototype now; any updates are
# uploaded at the same hourly interval, only when final and not work in progress").
#
# A commit on the local branch overseer-build is final only when overseer_gate.py passes it (a verified build-step
# title, never WIP; a green suite, every tampering detected and no false alarm in its message; the build's journal
# shows the step before the commit completed and its evaluation passed) AND the publisher's own re-run of the full
# suite on exactly that tree, with every recorded arena round available, exits 0 with no failure, no error, no
# interruption, and at least as many tests passed as the build's evaluation passed and skipped.
# The overseer rebuild on the STEM-merged translator (its exact subject is overseer_gate.REBUILD_SUBJECT) is a candidate
# too; it is gated against the rebuild workflow's journal (runs.json "overseer-rebuild"), and held if that is missing.
# Every candidate that carries a merged development translator (the rebuild, or a later build step on its line) gets the
# gate's translator checks (overseer_gate.py check 5, against every translator merge on its line); lines of the
# development translator not kept verbatim (and how many of them were found rewritten) are reported in the note and the
# message, never a reason to hold.
# The newest final commit after the last upload is uploaded; newer candidates that fail are reported (HOLD).
# The uploaded commit's tree is exactly the source commit's tree plus UPDATE_README.md and docs/overseer-updates/.
# Its parent is the previous upload, or for the first upload the build's fork point, which is already in Bruno's
# history, so the branch's diff shows exactly the overseer work. One ordinary push; no other ref is touched.
# Before the push (Daniel, 17:45 UTC: "do not upload dysfunctional code; always run a simulation"; "create backup in
# repository not locally"): simulate.sh overseer replays the recorded arena rounds and runs the overseer's contained run
# over every recorded round on exactly the tree to upload (every gate must pass, or nothing is pushed), and the replaced
# head is kept in Bruno's repository as backup/overseer-prototype-previous (an ordinary push).
# Usage: publish_overseer.sh [--dry-run]     (PUBLISH_OVERSEER_EXPECT=<sha> stops unless that commit is selected)
set -euo pipefail
trap '[[ $- == *e* ]] && echo "STOP: unexpected failure at line $LINENO of publish_overseer.sh; nothing pushed"' ERR
case "${1:-}" in ''|--dry-run) DRY=${1:-} ;; *) echo "usage: publish_overseer.sh [--dry-run]"; exit 2 ;; esac
R=/home/user/https-github.com-lovishchopra-NL2FOL
SRC=overseer-build
FORK=ae7b1e62c848191293ac84e0ce4e7c140ddedccf
BR=overseer-prototype
S=$(cd "$(dirname "$0")" && pwd)
VPY=$S/z3venv/bin/python
# Bare "Sonnet" and "Fable" are literary vocabulary in this domain; only the capitalised model names are banned in
# notes, and in the tree only versioned model names (a fixture may quote "Sonnet 18").
NOTE_BAN='a7c3c8b5|/tmp/|/root/|/home/user/|session_0[0-9A-Za-z]|<scratch|scratchpad/|\.worktrees/|(^|[^[:alnum:]/.])(wf|fixcheck|pack-export|review-pub|arena-overseer|eval/pack-export)/|\b(Opus|Sonnet|Fable)\b|\b[Oo][Pp][Uu][Ss]\b|\b[Hh][Aa][Ii][Kk][Uu]\b|[Cc]laude[-_](opus|haiku|sonnet|fable)|[Cc]laude (cheapest|strongest)-tier|(cheapest|strongest)-tier model [0-9]'
TREE_BAN='a7c3c8b5|/tmp/claude-0|/root/\.claude|/home/user/|session_01[0-9A-Za-z]|<scratch|scratchpad/|claude-(opus|haiku|sonnet)|\b(Claude )?(Opus|Haiku|Sonnet) [0-9]\.[0-9]'
exec 9>"$S/.publish_overseer.lock"
flock -n 9 || { echo "STOP: another run of the overseer publisher is in progress"; exit 1; }
WORK=$(mktemp -d); trap 'rm -rf "$WORK"' EXIT
cd "$R"

WFDIR=/root/.claude/projects/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/subagents/workflows
RUN=$(python3 -I -c "import json,sys; print(json.load(open(sys.argv[1])).get('overseer') or '')" "$S/runs.json")
JOURNAL=$WFDIR/$RUN/journal.jsonl
[ -n "$RUN" ] && [ -s "$JOURNAL" ] || { echo "STOP: the overseer build's journal is missing ($JOURNAL)"; exit 1; }
# The overseer rebuild on the STEM-merged translator is committed by a separate workflow (runs.json key
# "overseer-rebuild"); its commit is gated against that workflow's journal. A missing rebuild journal holds only that
# candidate (REBUILD_JOURNAL stays empty) and never stops the run for the others.
# The subject is read from the gate (its one definition) with stderr kept apart, so a warning can never become part of it.
# Without a valid subject the rebuild could not be recognised (and the gate itself is suspect): every candidate is held.
set +e; REBUILD_SUBJ=$(python3 -I -c "import sys; sys.path.insert(0, sys.argv[1]); import overseer_gate as G; print(G.REBUILD_SUBJECT)" "$S" 2>"$WORK/gate-import.err"); IRC=$?; set -e
if [ $IRC -ne 0 ] || [[ "$REBUILD_SUBJ" != "Overseer rebuild: "?* ]] || [[ "$REBUILD_SUBJ" == *$'\n'* ]]; then
  echo "HOLD (candidates not uploaded); the rebuild subject could not be read from overseer_gate.py (exit $IRC: $(tail -1 "$WORK/gate-import.err")${REBUILD_SUBJ:+; read \"$(echo "$REBUILD_SUBJ" | tail -1)\"}), so no candidate is gated"
  echo "NOTHING uploaded: the gate is not usable"; exit 0
fi
REBUILD_RUN=$(python3 -I -c "import json,sys; print(json.load(open(sys.argv[1])).get('overseer-rebuild') or '')" "$S/runs.json")
REBUILD_JOURNAL=""
if [ -n "$REBUILD_RUN" ] && [ -s "$WFDIR/$REBUILD_RUN/journal.jsonl" ]; then REBUILD_JOURNAL=$WFDIR/$REBUILD_RUN/journal.jsonl; fi
STEM_SUBJ="Merge STEM support into the translator"
git rev-parse -q --verify "$FORK^{commit}" >/dev/null || { echo "STOP: the fork point $FORK is missing"; exit 1; }
git merge-base --is-ancestor "$FORK" "$SRC" || { echo "STOP: $SRC does not descend from the fork point"; exit 1; }
git merge-base --is-ancestor "$FORK" refs/remotes/epinoic/import/translator-baseline || { echo "STOP: the fork point is not in Bruno's history"; exit 1; }

# Where the branch stands on Bruno's repository. Exit 2 from ls-remote means no such branch; any other failure
# (network, authentication) stops, and is never taken as a first upload.
set +e; timeout 120 git ls-remote --exit-code epinoic "refs/heads/$BR" >/dev/null 2>&1; RC=$?; set -e
if [ $RC -eq 0 ]; then
  timeout 120 git fetch -q epinoic "+refs/heads/$BR:refs/remotes/epinoic/$BR" || { echo "STOP: could not fetch $BR"; exit 1; }
  PARENT=$(git rev-parse "refs/remotes/epinoic/$BR")
  PREV_SRC=$(git log -1 --format=%B "$PARENT" | sed -n 's/^Source-Commit: //p' | tail -1)
  [ -n "$PREV_SRC" ] || { echo "STOP: $BR's head carries no Source-Commit (changed by someone else?)"; exit 1; }
  git merge-base --is-ancestor "$PREV_SRC" "$SRC" || { echo "STOP: the last uploaded source $PREV_SRC is not in $SRC's history"; exit 1; }
  CHANGED=$(git diff --name-only "$PREV_SRC" "$PARENT" | grep -v -E '^(UPDATE_README\.md$|docs/overseer-updates/)' || true)
  [ -z "$CHANGED" ] || { echo "STOP: $BR's head differs from its recorded source outside the notes (changed by someone else?): $CHANGED"; exit 1; }
elif [ $RC -eq 2 ]; then
  PARENT=$FORK; PREV_SRC=$FORK
else
  echo "STOP: could not reach Bruno's repository (ls-remote exit $RC)"; exit 1
fi

# Why a suite re-run is not green enough to upload (empty when it is): exit 0, no interruption, a clean summary, and at
# least as many tests passed as the build's evaluation passed and skipped. Used for the publisher's own re-run and for
# the re-run recorded in a prepared simulation (LOG empty: only the summary and exit status are kept there).
suite_why() {  # exit-status summary log-or-empty recorded-passed recorded-skipped
  python3 -I - "$@" <<'PYEOF'
import re, sys
rc, tail, logp, rec_p, rec_s = int(sys.argv[1]), sys.argv[2], sys.argv[3], int(sys.argv[4]), int(sys.argv[5])
log = open(logp, errors="replace").read() if logp else ""
if rc != 0: print(f"pytest exit status {rc}: {tail}")
elif re.search(r"^!+ .*(KeyboardInterrupt|Interrupted).* !+$", log, re.M) or re.search(r"\b(KeyboardInterrupt|Interrupted)\b", tail): print("the run was interrupted")
elif not re.match(r"^\d+ passed(, \d+ (skipped|deselected|warnings?|xfailed|xpassed|subtests (passed|skipped|xfailed|xpassed)))* in [0-9.]+s", tail): print(f"unexpected summary: {tail}")
elif int(re.match(r"^(\d+)", tail).group(1)) < rec_p + rec_s: print(f"fewer tests passed ({tail}) than the build ran ({rec_p} passed, {rec_s} skipped)")
PYEOF
}

# Candidates newest first; the first that passes the gate and the re-run is uploaded. A commit whose subject only starts
# like the rebuild's is a candidate too, so the gate holds it with its reason instead of it being dropped silently.
CANDS=$(git log --format='%H%x09%s' "$PREV_SRC..$SRC" | awk -F'\t' -v rb="$REBUILD_SUBJ" '$2 ~ /^Overseer review round [0-9]+: fix / || $2 ~ /^Overseer contained round c[0-9]+: fix judge findings$/ || $2 == "Overseer agents: documentation and contained-test results" || $2 == rb || $2 ~ /^Overseer rebuild/ {print $1}')
if [ -z "$CANDS" ]; then echo "NOTHING: no final overseer commit after $(git rev-parse --short "$PREV_SRC")"; exit 0; fi
FINAL=""; RERUN=""; HOLDS=""; PRESIM=""
for C in $CANDS; do
  # The rebuild's commit is gated against the rebuild's journal, every other candidate against the build's.
  CJ=$JOURNAL
  if [ "$(git log -1 --format=%s "$C")" = "$REBUILD_SUBJ" ]; then
    if [ -z "$REBUILD_JOURNAL" ]; then HOLDS="$HOLDS; $(git rev-parse --short "$C"): the rebuild's journal is missing (no \"overseer-rebuild\" run in runs.json, or its journal is absent or empty)"; continue; fi
    CJ=$REBUILD_JOURNAL
  fi
  # The gate answers on stdout; stderr (a warning, or a crash's traceback) is kept apart so it can never be read as the
  # answer. A refusal is held with the gate's reason (or the crash's last line); an answer that is not "OK N M" is held.
  set +e; GATE=$(python3 -I "$S/overseer_gate.py" "$R" "$C" "$CJ" 2>"$WORK/gate.err"); GRC=$?; set -e
  GLINE=$(echo "$GATE" | tail -1); [ -n "$GLINE" ] || GLINE=$(tail -1 "$WORK/gate.err")
  if [ $GRC -ne 0 ]; then HOLDS="$HOLDS; $(git rev-parse --short "$C"): $GLINE"; continue; fi
  if ! [[ "$GLINE" =~ ^OK\ ([0-9]+)\ ([0-9]+)$ ]]; then HOLDS="$HOLDS; $(git rev-parse --short "$C"): the gate's answer is not \"OK <passed> <skipped>\": $GLINE"; continue; fi
  REC_PASSED=${BASH_REMATCH[1]}; REC_SKIPPED=${BASH_REMATCH[2]}
  # Hourly runs (HOURLY_FAST=1, Daniel: the check and upload take at most 2 min 30 s) use only a simulation prepared before
  # the hour (presim.sh writes simcache/overseer-<sha>.txt: the suite re-run, then simulate.sh overseer).
  if [ -n "${HOURLY_FAST:-}" ]; then
    CF="$S/simcache/overseer-$C.txt"
    if ! [ -s "$CF" ]; then HOLDS="$HOLDS; $(git rev-parse --short "$C"): its simulation is not prepared yet (runs before the next hour)"; continue; fi
    # awk, not grep, so a cache without a SIMULATION line (a simulation killed before its last line) holds, never stops.
    SIMLINE=$(awk '/^SIMULATION /{l=$0} END{print l}' "$CF")
    if [ -z "$SIMLINE" ]; then HOLDS="$HOLDS; $(git rev-parse --short "$C"): the prepared simulation did not finish (no SIMULATION line)"; continue; fi
    case "$SIMLINE" in "SIMULATION OK"*) ;; *) HOLDS="$HOLDS; $(git rev-parse --short "$C"): $SIMLINE"; continue ;; esac
    # A candidate that carries a merged development translator (the rebuild, or any later commit on its line) must have
    # been simulated with the translator floor (simulate.sh prints "harness: floor: ..."); a cache prepared before the
    # floor existed is held, never accepted (presim.sh prepares it again). The gate's own definition decides.
    set +e; TMERGE=$(python3 -I -c "import sys; sys.path.insert(0, sys.argv[1]); import overseer_gate as G; m = G.translator_merge(sys.argv[2], sys.argv[3]); print(m['translator'] if m else '-')" "$S" "$R" "$C" 2>"$WORK/tmerge.err"); TRC=$?; set -e
    if [ $TRC -ne 0 ] || ! [[ "$TMERGE" =~ ^(-|[0-9a-f]{40})$ ]]; then HOLDS="$HOLDS; $(git rev-parse --short "$C"): could not tell whether it carries a merged translator (exit $TRC: $(tail -1 "$WORK/tmerge.err"))"; continue; fi
    if [ "$TMERGE" != "-" ] && [ -z "$(awk '/^harness: floor: /{print; exit}' "$CF")" ]; then HOLDS="$HOLDS; $(git rev-parse --short "$C"): the prepared simulation predates the translator floor (no \"harness: floor:\" line, although it carries the translator merged at ${TMERGE:0:7}); presim.sh prepares it again"; continue; fi
    # The prepared suite re-run must meet the same bar as the slow path's own re-run ("suite: <summary> (exit N)").
    SUITELINE=$(awk '/^suite: /{print; exit}' "$CF")
    if ! [[ "$SUITELINE" =~ ^suite:\ (.*)\ \(exit\ ([0-9]+)\)$ ]]; then HOLDS="$HOLDS; $(git rev-parse --short "$C"): the prepared simulation records no suite re-run (${SUITELINE:-no suite line})"; continue; fi
    CTAIL=${BASH_REMATCH[1]}; CRC=${BASH_REMATCH[2]}
    WHY=$(suite_why "$CRC" "$CTAIL" "" "$REC_PASSED" "$REC_SKIPPED")
    if [ -n "$WHY" ]; then HOLDS="$HOLDS; $(git rev-parse --short "$C"): the prepared suite re-run is not green: $WHY"; continue; fi
    FINAL=$C; RERUN=$CTAIL; PRESIM=$CF; break
  fi
  # Re-run the full suite on exactly this tree, with private copies of every recorded round (nothing recorded changes).
  rm -rf "$WORK/tree" "$WORK/rounds"; mkdir -p "$WORK/tree" "$WORK/rounds"
  git archive "$C" | tar -x -C "$WORK/tree"
  for d in "$S"/arena/r[0-9]*; do [ -d "$d" ] && cp -r "$d" "$WORK/rounds/"; done
  # Hermetic, exactly as simulate.sh: tests that start "python -I" subprocesses ignore PYTHONPATH and would import the
  # shared editable install (the main checkout) instead of this tree. An overlay environment whose only path file lists
  # the tree's src first, then the shared environment's packages, makes every process import exactly this tree.
  set +e
  OVL_WHY=""
  if ! [ -x "$WORK/venv/bin/python" ]; then
    ZSP=$("$VPY" -c "import sysconfig; print(sysconfig.get_paths()['purelib'])") && "$VPY" -m venv --without-pip "$WORK/venv" >/dev/null 2>&1 \
      && OSP=$("$WORK/venv/bin/python" -c "import sysconfig; print(sysconfig.get_paths()['purelib'])") \
      && printf '%s\n%s\n' "$WORK/tree/src" "$ZSP" > "$OSP/00-tree-under-test.pth"
    [ $? -eq 0 ] || { rm -rf "$WORK/venv"; OVL_WHY="could not create the overlay environment"; }
  fi
  if [ -z "$OVL_WHY" ]; then
    GOT=$(cd / && "$WORK/venv/bin/python" -I -c "import epinoic_logic; print(epinoic_logic.__file__)" 2>&1)
    case "$GOT" in "$WORK/tree/src/"*) ;; *) OVL_WHY="the overlay environment imports $(echo "$GOT" | tail -1), not the tree under test" ;; esac
  fi
  set -e
  if [ -n "$OVL_WHY" ]; then HOLDS="$HOLDS; $(git rev-parse --short "$C"): the publisher's re-run could not start: $OVL_WHY"; continue; fi
  set +e
  (cd "$WORK/tree" && EPINOIC_ARENA_ROUNDS="$WORK/rounds" PYTHONPATH="$WORK/tree/src" timeout 1800 "$WORK/venv/bin/python" -m pytest -q -p no:cacheprovider) >"$WORK/pytest.log" 2>&1
  PRC=$?
  set -e
  TAIL=$(tail -1 "$WORK/pytest.log" | sed 's/=//g; s/^ *//; s/ *$//')
  WHY=$(suite_why "$PRC" "$TAIL" "$WORK/pytest.log" "$REC_PASSED" "$REC_SKIPPED")
  if [ -z "$WHY" ]; then FINAL=$C; RERUN=$TAIL; break; fi
  HOLDS="$HOLDS; $(git rev-parse --short "$C"): the publisher's re-run is not green: $WHY"
done
[ -n "$HOLDS" ] && echo "HOLD (candidates not uploaded)${HOLDS}"
if [ -z "$FINAL" ]; then echo "NOTHING uploaded: no candidate after $(git rev-parse --short "$PREV_SRC") passed every gate"; exit 0; fi
if [ -n "${PUBLISH_OVERSEER_EXPECT:-}" ] && [ "$(git rev-parse "$PUBLISH_OVERSEER_EXPECT")" != "$FINAL" ]; then echo "STOP: selected $(git rev-parse --short "$FINAL"), expected $PUBLISH_OVERSEER_EXPECT"; exit 1; fi
echo "gates passed for $(git rev-parse --short "$FINAL"): re-run $RERUN"

TMPIDX="$WORK/index"
GIT_INDEX_FILE=$TMPIDX git read-tree "$FINAL"
NUM=$(( $(git log --format=%B "$FORK..$PARENT" | grep -c '^Source-Commit: ' || true) + 1 ))
if [ "$PARENT" != "$FORK" ]; then git ls-tree -r "$PARENT" docs/overseer-updates | GIT_INDEX_FILE=$TMPIDX git update-index --index-info; fi
NEWNOTE="docs/overseer-updates/$(printf '%04d' "$NUM")-${FINAL:0:7}.md"
EARLIER=$(GIT_INDEX_FILE=$TMPIDX git ls-files docs/overseer-updates | sort -r)
python3 -I "$S/overseer_notes.py" --repo "$R" --from "$PREV_SRC" --to "$FINAL" --fork "$FORK" --number "$NUM" --journal "$JOURNAL" --rebuild-journal "$REBUILD_JOURNAL" --rerun "$RERUN" --out "$WORK/note.md" --index $EARLIER || { echo "STOP: the update note could not be written"; exit 1; }
if grep -qE "$NOTE_BAN" "$WORK/note.md"; then grep -nE "$NOTE_BAN" "$WORK/note.md" | head -3 | cut -c1-300 || true; echo "STOP: the update note contains a scratch or local path, session id or model name"; exit 1; fi
NOTEBLOB=$(git hash-object -w "$WORK/note.md")
GIT_INDEX_FILE=$TMPIDX git update-index --add --cacheinfo "100644,$NOTEBLOB,$NEWNOTE"
GIT_INDEX_FILE=$TMPIDX git update-index --add --cacheinfo "100644,$NOTEBLOB,UPDATE_README.md"
TREE=$(GIT_INDEX_FILE=$TMPIDX git write-tree)
# Content backstop over the whole tree, binary files included; a git grep failure stops.
set +e; HITS=$(git grep -nE "$TREE_BAN" "$TREE" -- . 2>&1); GRC=$?; set -e
if [ $GRC -eq 0 ]; then echo "STOP: the tree to upload contains a scratch path, session id or model name: $(echo "$HITS" | head -5)"; exit 1; fi
if [ $GRC -ne 1 ]; then echo "STOP: the content scan failed: $HITS"; exit 1; fi
DIFF=$(git diff --name-only "$FINAL" "$TREE") || { echo "STOP: could not compare the tree with the source commit"; exit 1; }
EXTRA=$(echo "$DIFF" | grep -v -E '^(UPDATE_README\.md$|docs/overseer-updates/)' | grep . || true)
if [ -n "$EXTRA" ]; then echo "STOP: tree differs from the source commit outside the update notes: $EXTRA"; exit 1; fi

SUBJ=$(git log -1 --format=%s "$FINAL")
# One reader takes the whole body (a "| head" under pipefail can cut its writer off and stop the run silently).
RECORD=$(git log -1 --format=%b "$FINAL" | python3 -I -c "import re, sys; sys.path.insert(0, sys.argv[1]); import overseer_notes as O; ls = [l for l in sys.stdin.read().split(chr(10)) if l.strip() and not re.match(r'^(Co-Authored-By|Claude-Session):', l)]; print(O.short(' '.join(ls[:3]), 600))" "$S")
# "On top of the translator as it stood at the fork point" is true only for sources without a later translator. The
# rebuild merges the development branch's head T (its second parent, possibly newer than the STEM merge) into the
# overseer branch; the overseer branch also changes translator files of its own (counted from T, not from the fork).
# overseer_notes.translator_basis is the one definition, shared with the note: T is the second parent of the newest
# first-parent merge that brought in a development translator. N counts the translator files the overseer side changed;
# M those that differ from T although the overseer side never changed them. LN and LK: every development line not kept
# verbatim and the files they are in, LR: how many of those were found rewritten, LB: the binary files that differ from T
# (overseer_gate.development_report, over every translator merge on the line: reported, never held).
# Prints "T STEM-or-dash N M LN LK LB LR T-subject".
TB=$(python3 -I - "$S" "$R" "$FINAL" <<'PYEOF'
import sys
sys.path.insert(0, sys.argv[1])
import overseer_notes as O
b = O.translator_basis(sys.argv[2], sys.argv[3])
if b:
    needs, merged = O.translator_changes(sys.argv[2], b, sys.argv[3])
    rep = O.G.development_report(sys.argv[2], sys.argv[3])
    subj = O.short(O.U.git(sys.argv[2], "log", "-1", "--format=%s", b["translator"]), 120)
    print(b["translator"], b["stem"] or "-", len(needs), len(merged), rep["not_verbatim"], rep["not_verbatim_files"], len(rep["binary"]), rep["m"], subj)
PYEOF
)
if [ -n "$TB" ]; then
  read -r TR_SHA TR_STEM TR_N TR_M TR_LN TR_LK TR_LB TR_LR TR_SUBJ <<<"$TB"
  if [ "$TR_STEM" != "-" ]; then TR_STEMTXT=", which includes STEM support from $(git rev-parse --short "$TR_STEM") (\"$STEM_SUBJ\")"; else TR_STEMTXT=""; fi
  if [ "$TR_N" -gt 0 ]; then TR_CHG="plus the changes the overseer needs in $TR_N translator file(s)"; else TR_CHG="with no translator changes of its own"; fi
  if [ "$TR_M" -gt 0 ]; then TR_CHG="$TR_CHG; $TR_M further translator file(s) differ from that translator although the overseer side never changed them"; fi
  # Line-level differences from the development translator are reported, never held (the gate holds lost or switched-off
  # tests and lost paths). LN counts every development line not there verbatim; LR of them were found rewritten.
  TR_LINES="Every development test is kept and none is switched off, and every changed path is kept; the line check reports
development lines not kept verbatim: $TR_LN in $TR_LK files ($TR_LR of them found rewritten: an import with the same or more names, or their tokens in order); behaviour verified by the full suite and the recorded rounds."
  if [ "$TR_LB" -gt 0 ]; then TR_LINES="$TR_LINES $TR_LB binary file(s) differ from that translator."; fi
  BASIS="knowledge-document pack, the contained harness and their tests, on the
translator as it stood at $(git rev-parse --short "$TR_SHA") (\"$TR_SUBJ\")$TR_STEMTXT,
verified together with the overseer by its evaluation, $TR_CHG.
$TR_LINES
Prototype: the overseer joins verified-updates through a verified merge.
Work-in-progress commits are not uploaded."
else
  BASIS="knowledge-document pack, the contained harness, their tests and the
translator changes the overseer needs, on top of the translator as it stood
at $(git rev-parse --short "$FORK"). Prototype: the translator fixes made after that point are on
verified-updates; the overseer joins verified-updates through a verified
merge. Work-in-progress commits are not uploaded."
fi
cat > "$WORK/msg" <<EOF
Overseer prototype: $SUBJ

Uploads the logic-checking overseer build exactly as verified in source
commit $FINAL on its build branch: the overseer package, its exportable
$BASIS
Recorded at the source commit: $RECORD
Suite re-run by the publisher on exactly the source tree: $RERUN
What this update changes, the bugs found, the fixes introduced and the
findings still open: UPDATE_README.md (every note is kept in
docs/overseer-updates/).

Source-Commit: $FINAL

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_016YotQwcC83EEJm8zshdxtW
EOF
if [ "$(grep -vE '^(Co-Authored-By|Claude-Session):' "$WORK/msg" | grep -cE "$NOTE_BAN")" -gt 0 ]; then echo "STOP: the commit message contains a scratch or local path, session id or model name"; exit 1; fi
# Functional simulation of exactly the tree to upload (the suite was just re-run on the same code by the gate above).
SIMRC=0
if [ -n "${PRESIM:-}" ]; then cp "$PRESIM" "$WORK/sim.txt"
else SIM_SKIP_SUITE=1 bash "$S/simulate.sh" overseer "$TREE" "$FINAL" > "$WORK/sim.txt" 2>&1 || SIMRC=$?; fi
cat "$WORK/sim.txt"
[ $SIMRC -eq 0 ] || { echo "HOLD: the simulation failed; nothing pushed"; exit 0; }
NEW=$(git -c user.name=Claude -c user.email=noreply@anthropic.com commit-tree "$TREE" -p "$PARENT" -F "$WORK/msg")
echo "prepared $NEW (parent $(git rev-parse --short "$PARENT"), tree $TREE, source $FINAL, update $NUM)"
if [ "$DRY" = "--dry-run" ]; then cp "$WORK/note.md" "$S/last-overseer-note.md"; git log -1 --format=%B "$NEW" > "$S/last-overseer-msg.txt"; echo "DRY RUN: not pushed (note and message copied to the scratchpad)"; exit 0; fi
if [ "$PARENT" != "$FORK" ]; then
  timeout 120 git push epinoic "$PARENT:refs/heads/backup/$BR-previous" || { echo "STOP: could not back up the previous head as backup/$BR-previous; nothing pushed"; exit 1; }
fi
timeout 300 git push epinoic "$NEW:refs/heads/$BR"
timeout 120 git ls-remote epinoic "refs/heads/$BR"
