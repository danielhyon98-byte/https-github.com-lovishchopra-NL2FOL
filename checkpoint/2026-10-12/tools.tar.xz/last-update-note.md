# Update 357: Verified update: Integration: fix the architecture findings after round 8

Published 2026-11-09 17:37 UTC. Source commit `c4f276c` on the development branch; the previous published source was `16d5a4a`. This update publishes the translator code exactly as verified at that commit (full suite green, harness replay counts not lower than the previous update). Results prove properties of the encoded problems only, never that a specialist's premises are true.

## What this update changes

27 commit(s) since the previous update; 515 files changed, 120544 insertions(+), 16145 deletions(-).

| Area | Added | Modified | Deleted | Renamed |
| --- | --- | --- | --- | --- |
| README.md | 0 | 1 | 0 | 0 |
| docs | 3 | 10 | 0 | 0 |
| flash-router | 20 | 6 | 1 | 2 |
| integration | 5 | 20 | 0 | 0 |
| overseer | 103 | 0 | 0 | 202 |
| pyproject.toml | 0 | 1 | 0 | 0 |
| scripts/arena | 2 | 5 | 0 | 0 |
| src/epinoic_logic/adapters | 0 | 8 | 0 | 0 |
| src/epinoic_logic/api | 12 | 0 | 0 | 0 |
| src/epinoic_logic/branches | 0 | 6 | 0 | 0 |
| src/epinoic_logic/channel | 2 | 5 | 0 | 0 |
| src/epinoic_logic/engine | 0 | 2 | 0 | 0 |
| src/epinoic_logic/integration | 1 | 6 | 0 | 0 |
| src/epinoic_logic/integrity | 0 | 3 | 0 | 0 |
| src/epinoic_logic/overseer | 0 | 0 | 1 | 0 |
| src/epinoic_logic/stem | 0 | 16 | 0 | 0 |
| src/epinoic_logic/translate | 1 | 6 | 0 | 0 |
| tests | 1 | 2 | 0 | 0 |
| tests/adapters | 0 | 3 | 0 | 0 |
| tests/branches | 4 | 2 | 0 | 0 |
| tests/channel | 10 | 4 | 0 | 0 |
| tests/contract | 0 | 2 | 0 | 0 |
| tests/e2e | 2 | 1 | 0 | 0 |
| tests/engine | 1 | 0 | 0 | 0 |
| tests/fixtures | 1 | 0 | 0 | 0 |
| tests/integration | 4 | 14 | 0 | 0 |
| tests/integrity | 1 | 0 | 0 | 0 |
| tests/overseer | 0 | 0 | 1 | 0 |
| tests/stem | 3 | 7 | 0 | 0 |
| tests/translate | 1 | 1 | 0 | 0 |

Commits, oldest first:

- `0d57d9d` Tests README: progress note 09:00 (change)
- `41d031a` Tests README: progress note 10:00 (change)
- `f2329df` Fix the c1 clearance findings (verified)
- `fe37c77` Prototype: integrated translator after round 8 (verified)
- `f3a7682` Tests README: progress note 03:00 (change)
- `57d86e1` Tests README: progress note 04:00 (change)
- `efb2aa4` Tests README: progress note 05:00 (change)
- `44af3eb` Tests README: progress note 06:00 (change)
- `7fc43c8` Tests README: progress note 07:00 (change)
- `fe6457b` Tests README: progress note 08:00 (change)
- `33d955f` Tests README: progress note 09:00 (change)
- `6e8b3c9` Tests README: progress note 10:00 (change)
- `b855c03` Tests README: progress note 11:00 (change)
- `1e6f7ce` Tests README: progress note 12:00 (change)
- `31a519c` Tests README: progress note 13:00 (change)
- `0752202` Tests README: progress note 14:00 (change)
- `5412209` Tests README: progress note 15:00 (change)
- `fda19ec` Tests README: progress note 16:00 (change)
- `32a5c0e` Fix the c1 clearance findings (verified)
- `089fb04` Tests README: progress note 20:00 (change)
- `ab44c8a` Integration: the overseer and the flash router as separate sub-projects, attached through the integration protocol (change)
- `5060a52` Fix the c1 clearance findings (verified)
- `3c29be0` Tests README: progress note 04:00 (change)
- `b570339` Integration: twofold review of combined answers through the flash router (change)
- `f3d338a` Integration: specialist feedback and revision function (change)
- `1935bf0` Tests README: progress note 18:00 (change)
- `c4f276c` Integration: fix the architecture findings after round 8 (change)

## Bugs and failures found since the previous update

### Fix the c1 clearance findings

Arena round 8 (integrated round c1): results-audit 0.1921, communication-fidelity 0.3962, adversarial-live 0.7561, stem-integration 0.1474, translation-fidelity 0.9424. 147 findings; fixed:

| Overseer lens | Rate | 98% verdict | Blockers | Majors | Minors |
| --- | --- | --- | --- | --- | --- |
| adversarial-live | 0.7561 | no | 0 | 21 | 4 |
| communication-fidelity | 0.3962 | no | 0 | 15 | 7 |
| results-audit | 0.1921 | no | 0 | 25 | 16 |
| stem-integration | 0.1474 | no | 0 | 28 | 9 |
| translation-fidelity | 0.9424 | no | 0 | 9 | 13 |

- **major** (adversarial-live) The STEM checks raise error-level INT-SUBJ-001 on correct working: 14 false errors on 5 of the 9 genuine STEM answers of c1 (ph-p8b 3, ph-t14 3, maa-t14 2, maa-p8b 5, cs-t14 1). Each one reproduces in a minimal answer of one or two lines. The README's promise…
- **major** (adversarial-live) The worked-arithmetic reader charges correct results with error-level INT-SUBJ-001 when the scale word is written once, after the result. '10.0 − 4.0 = 6.0 million tonnes per year' is read as 10.0 − 4.0 against 6,000,000. Three of the Economics specialist's k…
- **major** (adversarial-live) maa-t14 gets a false error-level INT-CONFLICT-001, 'specialist claims contradict each other' (m6.1, m7.7), and its synthesis gets a false INT-CONFLICT-002. m7.7 says that x = −5 is REJECTED because it does not satisfy x > 4. Its translation encodes the reject…
- **major** (adversarial-live) This is a regression caused by the round-7 glossary fix. A real contradiction between two specialists' formalized claims is no longer charged when the two translations gloss the shared symbol in slightly different words. It becomes INT-CONFLICT-004, a warning…
- **major** (adversarial-live) Five correct genuine answers get a false error-level INT-REQ-005, for three reasons. The specialist's 'Sources:' line counts against the word bound on the English branch: en-t14 measures 276 against 275, lit-t14 306 against 300 and ll-t14 306 against 300, but…
- **major** (adversarial-live) The request the router sends is made explicit wrongly, and the coverage check is blind as a result. maa-t14's request becomes items for Question 1's parts only. Questions 2 and 3 are not items, so an answer that leaves both unanswered gets no INT-REQ-004 (my…
- **major** (adversarial-live) A verbatim quotation of the peer, whose closing full stop sits inside the quotation marks where the source continues ', so the price rises …', is reported 'not found in the supplied texts' (INT-REQ-003, error). This happens on the genuine bm-p8a receipt and o…
- **major** (adversarial-live) A faithful synthesis is charged at error level with a student-facing text 'not composed of its synthesized claims' ('2'; '3'; …), although that text is exactly its claims joined. In the bm-t14 synthesis, claims open with the list markers '(2)' and '(3)'. The…
- **major** (adversarial-live) Round-7 bug 9 is still open for 'rather than', and the finding is now an error. A faithful paraphrase of 'X rather than Y' as 'X and not Y' or 'X, not Y' is charged INT-LEDGER-030, 'states the opposite of its cited source: it adds a negation its cited source…
- **major** (adversarial-live) Round-7 bug 10 and breadth finding 15 are still open for three kinds of edit. A true/false answer is flipped ('F.' to 'V.' for sp-t14 item 3a). A contrast is reversed ('control rather than defeat' to 'defeat rather than control'). A technical term is exchange…
- **major** (adversarial-live) Round-7 bug 11 and breadth finding 4 are still open in three shapes. In each, an altered quotation is reported only as unverifiable (CORE-SRC-003, warning) instead of refuted (INT-REQ-003, error). (1) A figure is changed inside a quotation of a supplied text:…
- **major** (adversarial-live) Breadth finding 5 is still reproducible on the Business branch, in two forms. The Economics specialist's words credited to a character of the supplied case ('The finance director says that "the price rises from $600 to $750 per tonne"') get no CORE-SRC-005. A…
- **major** (adversarial-live) Injected STEM faults still cross the hub unnamed, or named only as undecided. In the c1 harness, 9 of the 11 STEM failures are real misses; the other 2 were named with another right code. Relations whose operands carry count units are skipped silently: bi-t14…
- **major** (adversarial-live) Breadth findings 11 and 13 are still reproducible: wrong arithmetic crosses the Economics, Business and generic branches silently, or named only as 'not checked'. These are silent: parenthetical sums ('$11,400 (5,200 + 4,000 + 1,500 + 600)' and '$1,327.50 mil…
- **major** (adversarial-live) Breadth finding 14 is still reproducible: a figure the answer takes from a supplied table or stimulus is never compared with it. Five misread figures cross silently: ec-t14 'Table 1 shows unemployed people rising from 576 thousand' (the table says 567), ge-t1…
- **major** (adversarial-live) Breadth finding 16 is still reproducible: marks in marking feedback are never checked. 'Provisional mark: 6 out of 5', and a provisional total of 9 out of 11 against part marks of 3 + 2 + 1, both cross with no finding.
- **major** (adversarial-live) Self-certifications are named only in a few wordings. Four common forms go unnamed on 8 of the 9 branches tested; only the English branch names them, through ES-META-001. The four are 'All calculations above were checked by the verification engine and are con…
- **major** (adversarial-live) Breadth findings 9 and 17 (Psychology) are still reproducible. The splitter breaks after 'et al.', so 'Draganski et al.' and '(2004) is not relevant here, but Halvorsen et al.' become two claims. An invented study cited as 'Halvorsen et al. (2019)' or '(Halvo…
- **major** (adversarial-live) Breadth finding 9 (roles) is still reproducible, though the round-7 cases are fixed: part labels, 'Note:' and 'Next step:' lines are no longer material. Other non-claims still reach the router as material points: a decline of the task (ge-t14 g1.1), an offer…
- **major** (adversarial-live) Breadth finding 2 is still reproducible: the router is shown ENTAILED, counted as approved, on an encoding whose only premise restates the conclusion. In maa-t14 m6.1 the premise 'x + 4 > 0 and x − 4 > 0' entails the conclusion 'x > 4' trivially. The overseer…
- **major** (adversarial-live) Round-7 bug 2 is still open. The validation of overseer-agent verdicts refutes correct false-conflict accusations. Its re-check re-runs the same pooled encoding, so it cannot see a conflict that the pooling itself creates. The round-7 glossary form no longer…
- **major** (communication-fidelity) The STEM checks raise error-level INT-SUBJ-001 on correct working: 14 false errors on 5 of the 9 genuine STEM answers (ph-p8b 3, ph-t14 3, maa-t14 2, maa-p8b 5, cs-t14 1), all reproduced on the current code. A symbolic step is checked with a symbol bound to a…
- **major** (communication-fidelity) The economics worked-arithmetic reader charges correct results with error-level INT-SUBJ-001 when the scale word is written once, after the result: '10.0 − 4.0 = 6.0 million tonnes per year' is read as 10.0 − 4.0 against 6,000,000. Three of the Economics spec…
- **major** (communication-fidelity) Regression of the r7 fix for INT-CONFLICT-001: a real contradiction between two specialists is no longer charged when the two translations gloss the shared symbol in slightly different words. The English specialist denying the History specialist's date ('The…
- **major** (communication-fidelity) Breadth probe b1 finding 2 is still reproducible: the router is shown ENTAILED, counted as approved, on encodings whose only premise restates the conclusion. The transfer auditor names them circular (OVS-TRN-006) after delivery, but the receipt the router act…
- … and 122 more (minor first omitted).

### Prototype: integrated translator after round 8

Documents the integrated prototype after arena round 8 and its fixes (docs/PROTOTYPE.md): the translator with STEM support, the overseer agents and their pack, the delivery rule, measured results, the external review dispositions and what is not yet shown.

### Fix the c1 clearance findings

Follow-up to f2329df, whose independent push check held the upload: its rule meta-note let an agent's

| Overseer lens | Rate | 98% verdict | Blockers | Majors | Minors |
| --- | --- | --- | --- | --- | --- |
| adversarial-live | 0.7561 | no | 0 | 21 | 4 |
| communication-fidelity | 0.3962 | no | 0 | 15 | 7 |
| results-audit | 0.1921 | no | 0 | 25 | 16 |
| stem-integration | 0.1474 | no | 0 | 28 | 9 |
| translation-fidelity | 0.9424 | no | 0 | 9 | 13 |

- **major** (adversarial-live) The STEM checks raise error-level INT-SUBJ-001 on correct working: 14 false errors on 5 of the 9 genuine STEM answers of c1 (ph-p8b 3, ph-t14 3, maa-t14 2, maa-p8b 5, cs-t14 1). Each one reproduces in a minimal answer of one or two lines. The README's promise…
- **major** (adversarial-live) The worked-arithmetic reader charges correct results with error-level INT-SUBJ-001 when the scale word is written once, after the result. '10.0 − 4.0 = 6.0 million tonnes per year' is read as 10.0 − 4.0 against 6,000,000. Three of the Economics specialist's k…
- **major** (adversarial-live) maa-t14 gets a false error-level INT-CONFLICT-001, 'specialist claims contradict each other' (m6.1, m7.7), and its synthesis gets a false INT-CONFLICT-002. m7.7 says that x = −5 is REJECTED because it does not satisfy x > 4. Its translation encodes the reject…
- **major** (adversarial-live) This is a regression caused by the round-7 glossary fix. A real contradiction between two specialists' formalized claims is no longer charged when the two translations gloss the shared symbol in slightly different words. It becomes INT-CONFLICT-004, a warning…
- **major** (adversarial-live) Five correct genuine answers get a false error-level INT-REQ-005, for three reasons. The specialist's 'Sources:' line counts against the word bound on the English branch: en-t14 measures 276 against 275, lit-t14 306 against 300 and ll-t14 306 against 300, but…
- **major** (adversarial-live) The request the router sends is made explicit wrongly, and the coverage check is blind as a result. maa-t14's request becomes items for Question 1's parts only. Questions 2 and 3 are not items, so an answer that leaves both unanswered gets no INT-REQ-004 (my…
- **major** (adversarial-live) A verbatim quotation of the peer, whose closing full stop sits inside the quotation marks where the source continues ', so the price rises …', is reported 'not found in the supplied texts' (INT-REQ-003, error). This happens on the genuine bm-p8a receipt and o…
- **major** (adversarial-live) A faithful synthesis is charged at error level with a student-facing text 'not composed of its synthesized claims' ('2'; '3'; …), although that text is exactly its claims joined. In the bm-t14 synthesis, claims open with the list markers '(2)' and '(3)'. The…
- **major** (adversarial-live) Round-7 bug 9 is still open for 'rather than', and the finding is now an error. A faithful paraphrase of 'X rather than Y' as 'X and not Y' or 'X, not Y' is charged INT-LEDGER-030, 'states the opposite of its cited source: it adds a negation its cited source…
- **major** (adversarial-live) Round-7 bug 10 and breadth finding 15 are still open for three kinds of edit. A true/false answer is flipped ('F.' to 'V.' for sp-t14 item 3a). A contrast is reversed ('control rather than defeat' to 'defeat rather than control'). A technical term is exchange…
- **major** (adversarial-live) Round-7 bug 11 and breadth finding 4 are still open in three shapes. In each, an altered quotation is reported only as unverifiable (CORE-SRC-003, warning) instead of refuted (INT-REQ-003, error). (1) A figure is changed inside a quotation of a supplied text:…
- **major** (adversarial-live) Breadth finding 5 is still reproducible on the Business branch, in two forms. The Economics specialist's words credited to a character of the supplied case ('The finance director says that "the price rises from $600 to $750 per tonne"') get no CORE-SRC-005. A…
- **major** (adversarial-live) Injected STEM faults still cross the hub unnamed, or named only as undecided. In the c1 harness, 9 of the 11 STEM failures are real misses; the other 2 were named with another right code. Relations whose operands carry count units are skipped silently: bi-t14…
- **major** (adversarial-live) Breadth findings 11 and 13 are still reproducible: wrong arithmetic crosses the Economics, Business and generic branches silently, or named only as 'not checked'. These are silent: parenthetical sums ('$11,400 (5,200 + 4,000 + 1,500 + 600)' and '$1,327.50 mil…
- **major** (adversarial-live) Breadth finding 14 is still reproducible: a figure the answer takes from a supplied table or stimulus is never compared with it. Five misread figures cross silently: ec-t14 'Table 1 shows unemployed people rising from 576 thousand' (the table says 567), ge-t1…
- **major** (adversarial-live) Breadth finding 16 is still reproducible: marks in marking feedback are never checked. 'Provisional mark: 6 out of 5', and a provisional total of 9 out of 11 against part marks of 3 + 2 + 1, both cross with no finding.
- **major** (adversarial-live) Self-certifications are named only in a few wordings. Four common forms go unnamed on 8 of the 9 branches tested; only the English branch names them, through ES-META-001. The four are 'All calculations above were checked by the verification engine and are con…
- **major** (adversarial-live) Breadth findings 9 and 17 (Psychology) are still reproducible. The splitter breaks after 'et al.', so 'Draganski et al.' and '(2004) is not relevant here, but Halvorsen et al.' become two claims. An invented study cited as 'Halvorsen et al. (2019)' or '(Halvo…
- **major** (adversarial-live) Breadth finding 9 (roles) is still reproducible, though the round-7 cases are fixed: part labels, 'Note:' and 'Next step:' lines are no longer material. Other non-claims still reach the router as material points: a decline of the task (ge-t14 g1.1), an offer…
- **major** (adversarial-live) Breadth finding 2 is still reproducible: the router is shown ENTAILED, counted as approved, on an encoding whose only premise restates the conclusion. In maa-t14 m6.1 the premise 'x + 4 > 0 and x − 4 > 0' entails the conclusion 'x > 4' trivially. The overseer…
- **major** (adversarial-live) Round-7 bug 2 is still open. The validation of overseer-agent verdicts refutes correct false-conflict accusations. Its re-check re-runs the same pooled encoding, so it cannot see a conflict that the pooling itself creates. The round-7 glossary form no longer…
- **major** (communication-fidelity) The STEM checks raise error-level INT-SUBJ-001 on correct working: 14 false errors on 5 of the 9 genuine STEM answers (ph-p8b 3, ph-t14 3, maa-t14 2, maa-p8b 5, cs-t14 1), all reproduced on the current code. A symbolic step is checked with a symbol bound to a…
- **major** (communication-fidelity) The economics worked-arithmetic reader charges correct results with error-level INT-SUBJ-001 when the scale word is written once, after the result: '10.0 − 4.0 = 6.0 million tonnes per year' is read as 10.0 − 4.0 against 6,000,000. Three of the Economics spec…
- **major** (communication-fidelity) Regression of the r7 fix for INT-CONFLICT-001: a real contradiction between two specialists is no longer charged when the two translations gloss the shared symbol in slightly different words. The English specialist denying the History specialist's date ('The…
- **major** (communication-fidelity) Breadth probe b1 finding 2 is still reproducible: the router is shown ENTAILED, counted as approved, on encodings whose only premise restates the conclusion. The transfer auditor names them circular (OVS-TRN-006) after delivery, but the receipt the router act…
- … and 122 more (minor first omitted).

### Fix the c1 clearance findings

Three regressions of the round-8 fixes (f2329df), found by the publisher's simulation of 32a5c0e. Each one was hidden

| Overseer lens | Rate | 98% verdict | Blockers | Majors | Minors |
| --- | --- | --- | --- | --- | --- |
| adversarial-live | 0.7561 | no | 0 | 21 | 4 |
| communication-fidelity | 0.3962 | no | 0 | 15 | 7 |
| results-audit | 0.1921 | no | 0 | 25 | 16 |
| stem-integration | 0.1474 | no | 0 | 28 | 9 |
| translation-fidelity | 0.9424 | no | 0 | 9 | 13 |

- **major** (adversarial-live) The STEM checks raise error-level INT-SUBJ-001 on correct working: 14 false errors on 5 of the 9 genuine STEM answers of c1 (ph-p8b 3, ph-t14 3, maa-t14 2, maa-p8b 5, cs-t14 1). Each one reproduces in a minimal answer of one or two lines. The README's promise…
- **major** (adversarial-live) The worked-arithmetic reader charges correct results with error-level INT-SUBJ-001 when the scale word is written once, after the result. '10.0 − 4.0 = 6.0 million tonnes per year' is read as 10.0 − 4.0 against 6,000,000. Three of the Economics specialist's k…
- **major** (adversarial-live) maa-t14 gets a false error-level INT-CONFLICT-001, 'specialist claims contradict each other' (m6.1, m7.7), and its synthesis gets a false INT-CONFLICT-002. m7.7 says that x = −5 is REJECTED because it does not satisfy x > 4. Its translation encodes the reject…
- **major** (adversarial-live) This is a regression caused by the round-7 glossary fix. A real contradiction between two specialists' formalized claims is no longer charged when the two translations gloss the shared symbol in slightly different words. It becomes INT-CONFLICT-004, a warning…
- **major** (adversarial-live) Five correct genuine answers get a false error-level INT-REQ-005, for three reasons. The specialist's 'Sources:' line counts against the word bound on the English branch: en-t14 measures 276 against 275, lit-t14 306 against 300 and ll-t14 306 against 300, but…
- **major** (adversarial-live) The request the router sends is made explicit wrongly, and the coverage check is blind as a result. maa-t14's request becomes items for Question 1's parts only. Questions 2 and 3 are not items, so an answer that leaves both unanswered gets no INT-REQ-004 (my…
- **major** (adversarial-live) A verbatim quotation of the peer, whose closing full stop sits inside the quotation marks where the source continues ', so the price rises …', is reported 'not found in the supplied texts' (INT-REQ-003, error). This happens on the genuine bm-p8a receipt and o…
- **major** (adversarial-live) A faithful synthesis is charged at error level with a student-facing text 'not composed of its synthesized claims' ('2'; '3'; …), although that text is exactly its claims joined. In the bm-t14 synthesis, claims open with the list markers '(2)' and '(3)'. The…
- **major** (adversarial-live) Round-7 bug 9 is still open for 'rather than', and the finding is now an error. A faithful paraphrase of 'X rather than Y' as 'X and not Y' or 'X, not Y' is charged INT-LEDGER-030, 'states the opposite of its cited source: it adds a negation its cited source…
- **major** (adversarial-live) Round-7 bug 10 and breadth finding 15 are still open for three kinds of edit. A true/false answer is flipped ('F.' to 'V.' for sp-t14 item 3a). A contrast is reversed ('control rather than defeat' to 'defeat rather than control'). A technical term is exchange…
- **major** (adversarial-live) Round-7 bug 11 and breadth finding 4 are still open in three shapes. In each, an altered quotation is reported only as unverifiable (CORE-SRC-003, warning) instead of refuted (INT-REQ-003, error). (1) A figure is changed inside a quotation of a supplied text:…
- **major** (adversarial-live) Breadth finding 5 is still reproducible on the Business branch, in two forms. The Economics specialist's words credited to a character of the supplied case ('The finance director says that "the price rises from $600 to $750 per tonne"') get no CORE-SRC-005. A…
- **major** (adversarial-live) Injected STEM faults still cross the hub unnamed, or named only as undecided. In the c1 harness, 9 of the 11 STEM failures are real misses; the other 2 were named with another right code. Relations whose operands carry count units are skipped silently: bi-t14…
- **major** (adversarial-live) Breadth findings 11 and 13 are still reproducible: wrong arithmetic crosses the Economics, Business and generic branches silently, or named only as 'not checked'. These are silent: parenthetical sums ('$11,400 (5,200 + 4,000 + 1,500 + 600)' and '$1,327.50 mil…
- **major** (adversarial-live) Breadth finding 14 is still reproducible: a figure the answer takes from a supplied table or stimulus is never compared with it. Five misread figures cross silently: ec-t14 'Table 1 shows unemployed people rising from 576 thousand' (the table says 567), ge-t1…
- **major** (adversarial-live) Breadth finding 16 is still reproducible: marks in marking feedback are never checked. 'Provisional mark: 6 out of 5', and a provisional total of 9 out of 11 against part marks of 3 + 2 + 1, both cross with no finding.
- **major** (adversarial-live) Self-certifications are named only in a few wordings. Four common forms go unnamed on 8 of the 9 branches tested; only the English branch names them, through ES-META-001. The four are 'All calculations above were checked by the verification engine and are con…
- **major** (adversarial-live) Breadth findings 9 and 17 (Psychology) are still reproducible. The splitter breaks after 'et al.', so 'Draganski et al.' and '(2004) is not relevant here, but Halvorsen et al.' become two claims. An invented study cited as 'Halvorsen et al. (2019)' or '(Halvo…
- **major** (adversarial-live) Breadth finding 9 (roles) is still reproducible, though the round-7 cases are fixed: part labels, 'Note:' and 'Next step:' lines are no longer material. Other non-claims still reach the router as material points: a decline of the task (ge-t14 g1.1), an offer…
- **major** (adversarial-live) Breadth finding 2 is still reproducible: the router is shown ENTAILED, counted as approved, on an encoding whose only premise restates the conclusion. In maa-t14 m6.1 the premise 'x + 4 > 0 and x − 4 > 0' entails the conclusion 'x > 4' trivially. The overseer…
- **major** (adversarial-live) Round-7 bug 2 is still open. The validation of overseer-agent verdicts refutes correct false-conflict accusations. Its re-check re-runs the same pooled encoding, so it cannot see a conflict that the pooling itself creates. The round-7 glossary form no longer…
- **major** (communication-fidelity) The STEM checks raise error-level INT-SUBJ-001 on correct working: 14 false errors on 5 of the 9 genuine STEM answers (ph-p8b 3, ph-t14 3, maa-t14 2, maa-p8b 5, cs-t14 1), all reproduced on the current code. A symbolic step is checked with a symbol bound to a…
- **major** (communication-fidelity) The economics worked-arithmetic reader charges correct results with error-level INT-SUBJ-001 when the scale word is written once, after the result: '10.0 − 4.0 = 6.0 million tonnes per year' is read as 10.0 − 4.0 against 6,000,000. Three of the Economics spec…
- **major** (communication-fidelity) Regression of the r7 fix for INT-CONFLICT-001: a real contradiction between two specialists is no longer charged when the two translations gloss the shared symbol in slightly different words. The English specialist denying the History specialist's date ('The…
- **major** (communication-fidelity) Breadth probe b1 finding 2 is still reproducible: the router is shown ENTAILED, counted as approved, on encodings whose only premise restates the conclusion. The transfer auditor names them circular (OVS-TRN-006) after delivery, but the receipt the router act…
- … and 122 more (minor first omitted).

## Fixes introduced

### Fix the c1 clearance findings

- [critical] 14 false INT-SUBJ-001 on 5 of the 9 genuine c1 STEM answers (ph-p8b 3, ph-t14 3, maa-t14 2, maa-p8b 5, cs-t14 1) and 5 on breadth cs-2: ide: checks._step rule step-definition: in a symbolic step, a symbol the answer defines by a formula in the step's own symbols is read through that form…
- [critical] a cancelled mass may be zero, so a textbook derivation was refuted: checks._cancelled_factors rule cancelled-factor: a factor present in every term of the premise that the step cancels gets the side condition m ≠ 0 (SIDE_NZ, grounded as an assumption)
- [critical] a value restated in another unit was read as a new root or step with its unit dropped (also the lens's correct 'In hours, T = 10750 ÷ 3600 : relations._unit_restatement rule unit-restatement: the restatement becomes a cnv check, in SI, against the last value of the symbol stated in anoth…
- [critical] a unit written after a surd was folded into the radicand: parser: '20√3 cm s⁻¹' and '√2 m' read the unit as the whole value's (_odd_unit)
- [critical] rejected values, evaluation points, inequality answers and quoted values were decided as roots or steps: rejected values are no step; a negative square root is one case; rules integer-bound, evaluation-point (only when the cue word opens its clause), and quoted-relation (one pass, binary…
- [critical] a conditional Boolean statement was decided without its output's definition; truth tables and '=' derivations were never decided: rules boolean-output (document._request_bool_defs, bounded at 16) and boolean-derivation (continuation lines; look-back capped at 2,000 characters); truth tab…
- [critical] a Markdown dash list marker was read as a minus sign, and B5₁₆ as a restated digit: spans._list_is_math rule list-marker; relations rule based-composition
- [critical] steps after a balance were neither checked nor named (glued 'GMm/r²'; 'kx = mg, so x = k/(mg)'): spans rule glued-run; checks/relations rule letter-run
- [critical] count nouns ('÷ 60 quadrats', '÷ 85 beats') split the chain into label bindings, so nothing was checked or named: units rule count-noun ('quadrat' unit). Count nouns are read only by the STEM front end (stem_parse_unit / stem_is_unit_atom / stem_lookup_atom; counts flag), so the translat…
- [critical] a request value miscopied into mgh (h), or two request values swapped, was not named: relations._request_substitutions: an h that is no value of Planck's constant is tied to the height; rule initial-final
- [critical] prose shares ('X is P% of Y', 'A of the B (P%)') were neither checked nor named: relations._prose_shares rule prose-share (bounded at 64)
- [critical] a GDC truncated decimal ('0.309017…', '\ldots') left every relation holding it undecided: numbers.ExactNumber.cut and parser rule cut-decimal: half-width is a whole unit. A lone cut side still goes through rule ellipsis-rounding (also a cut per cent restated as a per cent). A symbol set…
- [major] 'A + B = 6.0 m²' after both values was left as an unchecked equation in an unknown: relations._bound_before rule bound-sum (not for Given lines, and not for a symbol glued to a bracket)
- [major] 'R = R₁ + R₂ = 10 Ω' with 2-s.f. bindings took h = 5, so a wrong total held: checks._bound_figures rule bound-figures: R1's trailing-zero rule uses the significant figures of the bound operands
- [major] a booklet constant stated wrongly ('g = 9.18 m s⁻²', 'π = 3.12') was not named, and V_m 22.4 was accepted: rule booklet-value: a giv check at warning, planned only when the value disagrees with the booklet, skipping the request's value and other bodies or conditions. Rule constant-statement…
- [major] a wrong mole ratio taken from the balanced equation was ACCEPTED: relations._mole_ratios rule mole-ratio: an exact ratio check at warning against the last equation that holds both species
- [major] a bidirectional override let the engine check a value the reader does not see: relations._bidi_controls rule bidi-control: any relation reaching into text governed by an embedding, override or isolate is ST-UNDEC-001 (one linear pass). The channel-wide refusal is handed off
- [major, adversarial-live 12] injected STEM faults crossed unnamed: 'T = 2π/10' then 'T = π/4 s'; 'cos(10t) = 4/2'; the cost restated as $6435; the per: Rules restated-line (no carried intervals), function-restatement and labelled-line, with exceptions for connectives, marks and repeated labels. Esc…
- [minor] false INT-SUBJ-004 warnings (hex digit C4, ordinal 'first', template blanks '____', show-that target applied to another part); ST-RANGE-001 on: same-shape hex digit and ordinal skips; blanks are no maths or emphasis; show-that targets are scoped to their part; exam and course years are excl…
- [minor] smaller misses: general term, step over a function application, '7 on the left (4 + 6)', unit after a non-ten power, relation after a 300-deep: rules general-term, function-atom, parenthetical-sum (warning; asides only), parser._unit_after_power, unread-group (ST-PARSE-001)
- [class sweep, found during the work] rule same-shape did quadratic work on hostile input (about 4 CPU s on a 20,000-character dash list): evaluations grouped by shape, each distinct slot set compared once, capped at 64 variants; every new reading is anchored, possessive and capped
- Bugs 1, 19, 29, 43 (scale part) and 50, all critical majors. A scale word written once after the stated result was applied to the result alone, so cor: In `branches/worked.py`, `_problem` now also reads the line in the result's scale when the stated result carries a scale word and no operand does.…

Left undone: The final full suite fails 2 tests outside the STEM paths. Both pin the old reading of cut decimals, and the exact changes are in handoff items 6 and 7. (a) tests/overseer/test_stem_completion.py STEM_TASK_CONTENT mai-t13 must go from 13 to 15: two new comparison checks, both holding. (b) tests/overseer/test_stem_repair10.py::test_d32_says_which_integrals_and_ellipses_are_checked and the overseer knowledge pack's D32 sentence: '0.333… × 3 = 1' is now decided.; tests/README.md must record the one rewritten STEM test (handoff item 1).; Channel: name bidi controls in any specialist response for…

### Fix the c1 clearance findings

- 6b, rule self-report-disclosed: rule meta-note frees a paragraph-level ES-META-001 only when a closed
- 6c, rule unverified-claims: every claim of the answer, whatever its materiality, carries a positive
- 6d, rule formal-label-withheld: FORMALLY CHECKED is withheld for every answer in the round-8 release.
- Fail-closed: a refusal-only rule that raises refuses the label with a reason naming the rule and the
- Seven attack rounds, each by three independent lenses (bypass, regression against f2329df and the
- Recorded round-8 deliveries (c1): 24 of 24 withheld before and after; mode, delivered flag and label
- An independent pre-commit review (tests, documents, safety) found three serious problems, fixed here

### Fix the c1 clearance findings

- The re-keyed round-7 overseer test (overseer/tests/overseer_tests/test_rebuild_rekeyed_r7.py) still expected the overseer
- Rule declined-bound (Decision 96) made a declined answer's word bounds not applicable, and the auditor then accepted the
- Rule derived-figures (Decision 90) traced a planted figure through any value the request or a supplied text implies,

## Verification

- Harness before (previous update): r7 177/177 (the recorded round 7 on a fresh copy, measured on 6947c2d's tree; the publisher's simulation measures every recorded round before upload). Suite: 16864 passed, 12 skipped, 45 deselected, 0 failed, 0 errors (default suite on 6947c2d's tree; the 12 skips are the round-dependent tests, which gave 151 passed with the recorded rounds 5 and 7).
- Harness after (this update): r1 30/30, r1-adv 150/151, r2 46/46, r3 46/46, r4 46/46, r5 46/46, r6 46/46, r7 177/177, c1 203/203. Suite: 23051 passed, 45 deselected, 1 xfailed, 28 warnings in 5537.90s (1:32:17). Exit code 0. The run used EPINOIC_ARENA_ROUNDS set to a copy of the recorded rounds (r1, r1-adv, r2 to r7). No test was skipped, and no skip line names EPINOIC_ARENA_ROUNDS. The only warnings are Pydantic serializer UserWarnings from the gate3 broken-identity-field tests. Full log: a private working copy
- Suite at this update: 23051 passed, 45 deselected, 1 xfailed, 28 warnings in 5537.90s (1:32:17). Exit code 0. The run used EPINOIC_ARENA_ROUNDS set to a copy of the recorded rounds (r1, r1-adv, r2 to r7). No test was skipped, and no skip line names EPINOIC_ARENA_ROUNDS. The only warnings are Pydantic serializer UserWarnings from the gate3 broken-identity-field tests. Full log: a private working copy

## Earlier updates

- docs/updates/0356-hourly-20261109-1700.md
- docs/updates/0355-hourly-20261109-1600.md
- docs/updates/0354-hourly-20261109-1500.md
- docs/updates/0353-hourly-20261109-1400.md
- docs/updates/0352-hourly-20261109-1300.md
- docs/updates/0351-hourly-20261109-1200.md
- docs/updates/0350-hourly-20261109-1102.md
- docs/updates/0349-hourly-20261109-1000.md
- docs/updates/0348-hourly-20261109-0900.md
- docs/updates/0347-hourly-20261109-0800.md
- docs/updates/0346-hourly-20261109-0700.md
- docs/updates/0345-hourly-20261109-0600.md
- docs/updates/0344-hourly-20261109-0500.md
- docs/updates/0343-hourly-20261109-0400.md
- docs/updates/0342-hourly-20261109-0300.md
- docs/updates/0341-hourly-20261109-0200.md
- docs/updates/0340-hourly-20261109-0100.md
- docs/updates/0339-hourly-20261109-0000.md
- docs/updates/0338-hourly-20261108-2300.md
- docs/updates/0337-hourly-20261108-2200.md
- docs/updates/0336-hourly-20261108-2100.md
- docs/updates/0335-hourly-20261108-2000.md
- docs/updates/0334-hourly-20261108-1900.md
- docs/updates/0333-hourly-20261108-1800.md
- docs/updates/0332-hourly-20261108-1700.md
- docs/updates/0331-hourly-20261108-1600.md
- docs/updates/0330-hourly-20261108-1500.md
- docs/updates/0329-hourly-20261108-1400.md
- docs/updates/0328-hourly-20261108-1300.md
- docs/updates/0327-hourly-20261108-1200.md
- docs/updates/0326-hourly-20261108-1100.md
- docs/updates/0325-hourly-20261108-1000.md
- docs/updates/0324-hourly-20261108-0900.md
- docs/updates/0323-hourly-20261108-0800.md
- docs/updates/0322-hourly-20261108-0700.md
- docs/updates/0321-hourly-20261108-0600.md
- docs/updates/0320-hourly-20261108-0500.md
- docs/updates/0319-hourly-20261108-0400.md
- docs/updates/0318-hourly-20261108-0300.md
- docs/updates/0317-hourly-20261108-0200.md
- docs/updates/0316-hourly-20261108-0100.md
- docs/updates/0315-hourly-20261108-0000.md
- docs/updates/0314-hourly-20261107-2300.md
- docs/updates/0313-hourly-20261107-2200.md
- docs/updates/0312-hourly-20261107-2100.md
- docs/updates/0311-hourly-20261107-2000.md
- docs/updates/0310-hourly-20261107-1900.md
- docs/updates/0309-hourly-20261107-1800.md
- docs/updates/0308-hourly-20261107-1700.md
- docs/updates/0307-hourly-20261107-1600.md
- docs/updates/0306-hourly-20261107-1500.md
- docs/updates/0305-hourly-20261107-1400.md
- docs/updates/0304-hourly-20261107-1300.md
- docs/updates/0303-hourly-20261107-1200.md
- docs/updates/0302-hourly-20261107-1100.md
- docs/updates/0301-hourly-20261107-1000.md
- docs/updates/0300-hourly-20261107-0900.md
- docs/updates/0299-hourly-20261107-0800.md
- docs/updates/0298-hourly-20261107-0700.md
- docs/updates/0297-hourly-20261107-0600.md
- docs/updates/0296-hourly-20261107-0500.md
- docs/updates/0295-hourly-20261107-0400.md
- docs/updates/0294-hourly-20261107-0300.md
- docs/updates/0293-hourly-20261107-0200.md
- docs/updates/0292-hourly-20261107-0100.md
- docs/updates/0291-hourly-20261107-0000.md
- docs/updates/0290-hourly-20261106-2300.md
- docs/updates/0289-hourly-20261106-2200.md
- docs/updates/0288-hourly-20261106-2100.md
- docs/updates/0287-hourly-20261106-2000.md
- docs/updates/0286-hourly-20261106-1900.md
- docs/updates/0285-hourly-20261106-1800.md
- docs/updates/0284-hourly-20261106-1700.md
- docs/updates/0283-hourly-20261106-1100.md
- docs/updates/0282-hourly-20261106-1000.md
- docs/updates/0281-hourly-20261106-0900.md
- docs/updates/0280-hourly-20261106-0800.md
- docs/updates/0279-hourly-20261106-0700.md
- docs/updates/0278-hourly-20261106-0600.md
- docs/updates/0277-hourly-20261106-0500.md
- docs/updates/0276-hourly-20261106-0400.md
- docs/updates/0275-hourly-20261106-0300.md
- docs/updates/0274-hourly-20261106-0200.md
- docs/updates/0273-hourly-20261106-0100.md
- docs/updates/0272-hourly-20261106-0000.md
- docs/updates/0271-hourly-20261105-2300.md
- docs/updates/0270-hourly-20261105-2200.md
- docs/updates/0269-hourly-20261105-2100.md
- docs/updates/0268-hourly-20261105-2000.md
- docs/updates/0267-hourly-20261105-1900.md
- docs/updates/0266-hourly-20261105-1800.md
- docs/updates/0265-hourly-20261105-1700.md
- docs/updates/0264-hourly-20261105-1601.md
- docs/updates/0263-hourly-20261105-1500.md
- docs/updates/0262-hourly-20261105-1400.md
- docs/updates/0261-hourly-20261105-1300.md
- docs/updates/0260-hourly-20261105-1200.md
- docs/updates/0259-hourly-20261105-1100.md
- docs/updates/0258-hourly-20261105-1000.md
- docs/updates/0257-hourly-20261105-0900.md
- docs/updates/0256-hourly-20261105-0800.md
- docs/updates/0255-hourly-20261105-0700.md
- docs/updates/0254-hourly-20261105-0600.md
- docs/updates/0253-hourly-20261105-0500.md
- docs/updates/0252-hourly-20261105-0400.md
- docs/updates/0251-hourly-20261105-0300.md
- docs/updates/0250-hourly-20261105-0200.md
- docs/updates/0249-hourly-20261105-0100.md
- docs/updates/0248-hourly-20261105-0000.md
- docs/updates/0247-hourly-20261104-2300.md
- docs/updates/0246-hourly-20261104-2200.md
- docs/updates/0245-hourly-20261104-2100.md
- docs/updates/0244-hourly-20261104-2000.md
- docs/updates/0243-hourly-20261104-1900.md
- docs/updates/0242-hourly-20261104-1800.md
- docs/updates/0241-hourly-20261104-1700.md
- docs/updates/0240-hourly-20261104-1600.md
- docs/updates/0239-hourly-20261104-1500.md
- docs/updates/0238-hourly-20261104-1400.md
- docs/updates/0237-hourly-20261104-1300.md
- docs/updates/0236-hourly-20261104-1200.md
- docs/updates/0235-hourly-20261104-1100.md
- docs/updates/0234-hourly-20261104-0900.md
- docs/updates/0233-hourly-20261104-0800.md
- docs/updates/0232-hourly-20261104-0700.md
- docs/updates/0231-hourly-20261104-0600.md
- docs/updates/0230-hourly-20261104-0500.md
- docs/updates/0229-hourly-20261104-0400.md
- docs/updates/0228-hourly-20261104-0300.md
- docs/updates/0227-hourly-20261104-0200.md
- docs/updates/0226-hourly-20261104-0100.md
- docs/updates/0225-hourly-20261104-0000.md
- docs/updates/0224-hourly-20261103-2300.md
- docs/updates/0223-hourly-20261103-2200.md
- docs/updates/0222-hourly-20261103-2100.md
- docs/updates/0221-hourly-20261103-2000.md
- docs/updates/0220-hourly-20261103-1900.md
- docs/updates/0219-hourly-20261103-1700.md
- docs/updates/0218-hourly-20261103-1600.md
- docs/updates/0217-hourly-20261103-1500.md
- docs/updates/0216-hourly-20261103-1400.md
- docs/updates/0215-hourly-20261103-1300.md
- docs/updates/0214-hourly-20261103-1201.md
- docs/updates/0213-hourly-20261103-1100.md
- docs/updates/0212-hourly-20261103-1000.md
- docs/updates/0211-hourly-20261103-0900.md
- docs/updates/0210-hourly-20261103-0800.md
- docs/updates/0209-hourly-20261103-0700.md
- docs/updates/0208-hourly-20261103-0600.md
- docs/updates/0207-hourly-20261103-0500.md
- docs/updates/0206-hourly-20261103-0401.md
- docs/updates/0205-hourly-20261103-0300.md
- docs/updates/0204-hourly-20261103-0200.md
- docs/updates/0203-hourly-20261103-0100.md
- docs/updates/0202-hourly-20261103-0000.md
- docs/updates/0201-hourly-20261102-2300.md
- docs/updates/0200-hourly-20261102-2200.md
- docs/updates/0199-hourly-20261102-2100.md
- docs/updates/0198-hourly-20261102-2000.md
- docs/updates/0197-hourly-20261102-1900.md
- docs/updates/0196-hourly-20261102-1743.md
- docs/updates/0195-hourly-20261102-1651.md
- docs/updates/0194-hourly-20261102-1529.md
- docs/updates/0193-hourly-20261102-1407.md
- docs/updates/0192-hourly-20261102-1311.md
- docs/updates/0191-hourly-20261102-1200.md
- docs/updates/0190-16d5a4a.md
- docs/updates/0189-hourly-20261031-0400.md
- docs/updates/0188-hourly-20261031-0300.md
- docs/updates/0187-hourly-20261031-0200.md
- docs/updates/0186-hourly-20261031-0100.md
- docs/updates/0185-9dec1e7.md
- docs/updates/0184-hourly-20261030-2300.md
- docs/updates/0183-hourly-20261030-2200.md
- docs/updates/0182-hourly-20261030-2100.md
- docs/updates/0181-hourly-20261030-2000.md
- docs/updates/0180-hourly-20261030-1900.md
- docs/updates/0179-hourly-20261030-1800.md
- docs/updates/0178-hourly-20261030-1701.md
- docs/updates/0177-hourly-20261030-1636.md
- docs/updates/0176-hourly-20261029-1801.md
- docs/updates/0175-hourly-20261029-1700.md
- docs/updates/0174-hourly-20261029-1611.md
- docs/updates/0173-hourly-20261029-1513.md
- docs/updates/0172-hourly-20261029-1407.md
- docs/updates/0171-hourly-20261029-1330.md
- docs/updates/0170-hourly-20261029-1210.md
- docs/updates/0169-hourly-20261029-1100.md
- docs/updates/0168-hourly-20261029-1000.md
- docs/updates/0167-hourly-20261029-0900.md
- docs/updates/0166-hourly-20261029-0800.md
- docs/updates/0165-hourly-20261029-0700.md
- docs/updates/0164-hourly-20261029-0600.md
- docs/updates/0163-hourly-20261029-0500.md
- docs/updates/0162-hourly-20261029-0400.md
- docs/updates/0161-hourly-20261029-0300.md
- docs/updates/0160-hourly-20261029-0200.md
- docs/updates/0159-hourly-20261029-0100.md
- docs/updates/0158-hourly-20261029-0000.md
- docs/updates/0157-hourly-20261028-2300.md
- docs/updates/0156-hourly-20261028-2200.md
- docs/updates/0155-hourly-20261028-2100.md
- docs/updates/0154-hourly-20261028-2000.md
- docs/updates/0153-hourly-20261028-1900.md
- docs/updates/0152-hourly-20261028-1800.md
- docs/updates/0151-hourly-20261028-1700.md
- docs/updates/0150-hourly-20261028-1600.md
- docs/updates/0149-hourly-20261028-1500.md
- docs/updates/0148-hourly-20261028-1411.md
- docs/updates/0147-hourly-20261028-1302.md
- docs/updates/0146-hourly-20261028-1203.md
- docs/updates/0145-hourly-20261028-1100.md
- docs/updates/0144-hourly-20261028-1003.md
- docs/updates/0143-hourly-20261028-0900.md
- docs/updates/0142-hourly-20261028-0800.md
- docs/updates/0141-hourly-20261028-0700.md
- docs/updates/0140-hourly-20261028-0600.md
- docs/updates/0139-hourly-20261028-0500.md
- docs/updates/0138-hourly-20261028-0400.md
- docs/updates/0137-hourly-20261028-0300.md
- docs/updates/0136-hourly-20261028-0200.md
- docs/updates/0135-hourly-20261028-0100.md
- docs/updates/0134-hourly-20261028-0000.md
- docs/updates/0133-hourly-20261027-2300.md
- docs/updates/0132-hourly-20261027-2200.md
- docs/updates/0131-hourly-20261027-2100.md
- docs/updates/0130-hourly-20261027-2000.md
- docs/updates/0129-hourly-20261027-1900.md
- docs/updates/0128-hourly-20261027-1800.md
- docs/updates/0127-hourly-20261027-1700.md
- docs/updates/0126-hourly-20261027-1616.md
- docs/updates/0125-hourly-20261027-1526.md
- docs/updates/0124-hourly-20261027-1402.md
- docs/updates/0123-hourly-20261027-1319.md
- docs/updates/0122-hourly-20261027-1213.md
- docs/updates/0121-hourly-20261027-1100.md
- docs/updates/0120-hourly-20261027-1000.md
- docs/updates/0119-hourly-20261027-0900.md
- docs/updates/0118-hourly-20261027-0800.md
- docs/updates/0117-hourly-20261027-0700.md
- docs/updates/0116-hourly-20261027-0600.md
- docs/updates/0115-hourly-20261027-0500.md
- docs/updates/0114-hourly-20261027-0400.md
- docs/updates/0113-hourly-20261027-0300.md
- docs/updates/0112-hourly-20261027-0200.md
- docs/updates/0111-hourly-20261027-0100.md
- docs/updates/0110-hourly-20261027-0000.md
- docs/updates/0109-hourly-20261026-2300.md
- docs/updates/0108-hourly-20261026-2200.md
- docs/updates/0107-hourly-20261026-2100.md
- docs/updates/0106-hourly-20261026-2000.md
- docs/updates/0105-hourly-20261026-1900.md
- docs/updates/0104-hourly-20261026-1800.md
- docs/updates/0103-hourly-20261026-1700.md
- docs/updates/0102-hourly-20261026-1600.md
- docs/updates/0101-hourly-20261026-1500.md
- docs/updates/0100-hourly-20261026-1400.md
- docs/updates/0099-hourly-20261026-1300.md
- docs/updates/0098-hourly-20261026-1200.md
- docs/updates/0097-hourly-20261026-1100.md
- docs/updates/0096-hourly-20261026-1000.md
- docs/updates/0095-hourly-20261026-0900.md
- docs/updates/0094-hourly-20261026-0800.md
- docs/updates/0093-hourly-20261026-0700.md
- docs/updates/0092-hourly-20261026-0600.md
- docs/updates/0091-hourly-20261026-0500.md
- docs/updates/0090-hourly-20261026-0400.md
- docs/updates/0089-hourly-20261026-0300.md
- docs/updates/0088-hourly-20261026-0200.md
- docs/updates/0087-hourly-20261026-0100.md
- docs/updates/0086-hourly-20261026-0000.md
- docs/updates/0085-hourly-20261025-2300.md
- docs/updates/0084-hourly-20261025-2200.md
- docs/updates/0083-hourly-20261025-2100.md
- docs/updates/0082-404aee2.md
- docs/updates/0081-hourly-20261025-1300.md
- docs/updates/0080-3adfd73.md
- docs/updates/0079-hourly-20261025-0400.md
- docs/updates/0078-hourly-20261025-0300.md
- docs/updates/0077-hourly-20261025-0200.md
- docs/updates/0076-hourly-20261025-0100.md
- docs/updates/0075-hourly-20261025-0001.md
- docs/updates/0074-hourly-20261024-2300.md
- docs/updates/0073-hourly-20261024-2200.md
- docs/updates/0072-hourly-20261024-2100.md
- docs/updates/0071-hourly-20261024-2000.md
- docs/updates/0070-hourly-20261024-1900.md
- docs/updates/0069-hourly-20261024-1800.md
- docs/updates/0068-hourly-20261024-1700.md
- docs/updates/0067-hourly-20261024-1600.md
- docs/updates/0066-hourly-20261024-1500.md
- docs/updates/0065-hourly-20261024-1400.md
- docs/updates/0064-hourly-20261024-1300.md
- docs/updates/0063-hourly-20261024-1200.md
- docs/updates/0062-hourly-20261024-1100.md
- docs/updates/0061-hourly-20261024-1000.md
- docs/updates/0060-hourly-20261024-0900.md
- docs/updates/0059-hourly-20261024-0800.md
- docs/updates/0058-hourly-20261024-0700.md
- docs/updates/0057-hourly-20261024-0600.md
- docs/updates/0056-hourly-20261024-0500.md
- docs/updates/0055-hourly-20261024-0400.md
- docs/updates/0054-hourly-20261024-0300.md
- docs/updates/0053-hourly-20261024-0200.md
- docs/updates/0052-hourly-20261024-0100.md
- docs/updates/0051-hourly-20261024-0000.md
- docs/updates/0050-hourly-20261023-2300.md
- docs/updates/0049-hourly-20261023-2200.md
- docs/updates/0048-hourly-20261023-2100.md
- docs/updates/0047-f34ff1d.md
- docs/updates/0046-hourly-20261023-2000.md
- docs/updates/0045-hourly-20261023-1900.md
- docs/updates/0044-hourly-20261023-1800.md
- docs/updates/0043-hourly-20261023-1700.md
- docs/updates/0042-hourly-20261018-0100.md
- docs/updates/0041-hourly-20261017-2300.md
- docs/updates/0040-hourly-20261017-2200.md
- docs/updates/0039-86ab0ba.md
- docs/updates/0038-hourly-20261017-1800.md
- docs/updates/0037-hourly-20261017-1700.md
- docs/updates/0036-hourly-20261017-1600.md
- docs/updates/0035-hourly-20261017-1500.md
- docs/updates/0034-hourly-20261017-1400.md
- docs/updates/0033-hourly-20261017-1300.md
- docs/updates/0032-hourly-20261017-1200.md
- docs/updates/0031-8a78efe.md
- docs/updates/0030-hourly-20261017-1000.md
- docs/updates/0029-hourly-20261017-0900.md
- docs/updates/0028-hourly-20261017-0800.md
- docs/updates/0027-hourly-20261017-0700.md
- docs/updates/0026-hourly-20261017-0600.md
- docs/updates/0025-hourly-20261017-0530.md
- docs/updates/0024-hourly-20261017-0500.md
- docs/updates/0023-hourly-20261017-0430.md
- docs/updates/0022-hourly-20261017-0400.md
- docs/updates/0021-hourly-20261017-0330.md
- docs/updates/0020-hourly-20261017-0300.md
- docs/updates/0019-hourly-20261017-0230.md
- docs/updates/0018-hourly-20261017-0200.md
- docs/updates/0017-hourly-20261017-0105.md
- docs/updates/0016-22d6a5b.md
- docs/updates/0015-hourly-20261017-0000.md
- docs/updates/0014-hourly-20261016-2300.md
- docs/updates/0013-hourly-20261016-2200.md
- docs/updates/0012-hourly-20261016-2102.md
- docs/updates/0011-hourly-20261016-2000.md
- docs/updates/0010-hourly-20261013-0002.md
- docs/updates/0009-hourly-20261012-2300.md
- docs/updates/0008-83e97e9.md
- docs/updates/0007-hourly-20261012-2100.md
- docs/updates/0006-hourly-20261012-2000.md
- docs/updates/0005-hourly-20261012-1902.md
- docs/updates/0004-hourly-20261012-1828.md
- docs/updates/0003-hourly-20261012-1755.md
- docs/updates/0002-99e435b.md
- docs/updates/0001-23707b9.md
