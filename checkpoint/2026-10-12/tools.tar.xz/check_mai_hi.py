import json, sys
from pathlib import Path
from epinoic_logic.adapters.sources import check_excerpt
from epinoic_logic.translate.contracts import SuppliedText
base = Path(sys.argv[1])
spec_hi = json.loads((base / "run1/specialists/hi-e1a.json").read_text())
relayed = json.loads((base / "run1/relayed/hi-e1a.json").read_text())
texts = {t["document_id"]: t["text"] for t in spec_hi["supplied_texts"]}
texts["peer:maa-e1a"] = relayed["payload"]["original_response"]
docs = {k: SuppliedText(document_id=k, title=k, author=None, text=v, locator_scheme="none") for k, v in texts.items()}
for name, listing in (("mai-e1", "list_mai-e1.json"), ("hi-e1a", "list_hi-e1a.json")):
    tr = json.loads((base / "run1/translations" / f"{name}.json").read_text())
    lst = json.loads((base / "run1/translator_work/mine" / listing).read_text())
    want = [c["claim_id"] for c in lst["claims"]]
    print(name, "report_id", tr["report_id"], "keys match eligible list:", sorted(tr["claims"]) == sorted(want), len(want))
    for cid in want:
        p = tr["claims"][cid]["problem"]
        if p is None:
            continue
        assert p["claim_id"] == cid, (cid, p["claim_id"])
        assert p["request_id"] == lst["request_id"], (p["request_id"], lst["request_id"])
        for item in [*p["premises"], *( [p["conclusion"]] if p["conclusion"] else [] ), *p["symbols"]]:
            g = item.get("grounding")
            if not g: continue
            for ref in g.get("source_refs", []):
                if ref.get("excerpt"):
                    loc = check_excerpt(ref["excerpt"], ref["document_id"], docs)
                    sub = ref["excerpt"] in texts.get(ref["document_id"], "")
                    if not (loc.located and sub):
                        print("  NOT LOCATED", cid, ref["document_id"], repr(ref["excerpt"]), loc.located, sub)
    print("  quotation check done for", name)
