import json
import os

SRC = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c1/tasks.json"
OUT_DIR = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c1/specialists"

RESPONSES = {}

RESPONSES["bi-t14"] = """(a) Mean density = 189 ÷ 60 quadrats = 3.15 plants per m². Each quadrat is 1 m², and the 28 quadrats without species A count as zero. [1]
Meadow area = 1.2 ha × 10,000 m² per ha = 12,000 m².
Population = 3.15 plants per m² × 12,000 m² = 37,800, or about 3.8 × 10⁴ plants (two significant figures, to match 1.2 ha). [1]
This assumes the 60 quadrats were placed at random and represent the whole meadow.

(b) Lincoln index: population = (M × C) ÷ R = (48 × 60) ÷ 9 = 2,880 ÷ 9 = 320 beetles. [1]
Assumption: marked beetles mix randomly with the unmarked beetles before the second catch, so each beetle is equally likely to be caught. [1]
Also, no beetles are born, die or migrate between the two catches, and the marks do not affect survival or behaviour. [1 spare]

(c) Expected quadrats with both species = 60 × (32 ÷ 60) × (27 ÷ 60) = (32 × 27) ÷ 60 = 864 ÷ 60 = 14.4 quadrats. [1]

(d) Null hypothesis: species A and B are independent, with no association between them.
Observed (expected) counts: both present 20 (14.4); A only 12 (17.6); B only 7 (12.6); neither 21 (15.4).
Expected values: A only = 32 × 33 ÷ 60 = 17.6; B only = 28 × 27 ÷ 60 = 12.6; neither = 28 × 33 ÷ 60 = 15.4. [1]
χ² = Σ(O − E)² ÷ E = 5.6² ÷ 14.4 + 5.6² ÷ 17.6 + 5.6² ÷ 12.6 + 5.6² ÷ 15.4 = 2.1778 + 1.7818 + 2.4889 + 2.0364 = 8.48 (no unit). [1]
Degrees of freedom = (2 − 1) × (2 − 1) = 1. Since 8.48 is greater than the critical value 3.84, the null hypothesis is rejected: the association is significant at p = 0.05. [1]
The association is positive: A and B were found together in 20 quadrats, against 14.4 expected. [1]
A significant association shows that the species occur together; it does not by itself show that they interact. [1 spare]

(e) Both species may need the same abiotic conditions, such as soil moisture or pH, so each is more likely to occur where the other is found. [1]

Mark tags are provisional: they come from my own illustrative plan, not from an official markscheme.
Next step: redo part (d) with different quadrat counts, checking that the expected values add up to the row and column totals.
Sources: your question and its data (supplied text); Biology course notes (course notes)"""

RESPONSES["bi-p8d"] = """(a) Ice-water group: (0.84 − 0.30) ÷ 0.30 × 100 = 180%, an increase of 180%. [1]
Warm-water group: (0.36 − 0.32) ÷ 0.32 × 100 = 12.5%, an increase of 12.5%. [1]

(b) Ice-water heart rate: (85 − 68) ÷ 68 × 100 = 25%, an increase of 25%. [1]
Warm-water heart rate: (71 − 70) ÷ 70 × 100 = 1.4%, an increase of 1.4%. [1]
Ice-water cardiac cycle at the end of immersion: one cycle = 60 s ÷ 85 beats = 0.71 s. [1]

(c) Degrees of freedom = n₁ + n₂ − 2 = 12 + 12 − 2 = 22 (no unit). [1]
Null hypothesis: there is no difference between the groups in the increase in adrenaline. Since t = 5.41 is greater than the critical value 2.07, the null hypothesis is rejected: the difference between the groups is significant at p = 0.05. [1]

(d) The adrenal glands secrete adrenaline into the blood, which carries it to target cells such as liver and muscle cells. [1]
Adrenaline is hydrophilic and cannot cross the membrane, so it binds to a specific receptor in the plasma membrane; this activates an enzyme that converts ATP into cyclic AMP, a second messenger inside the cell. [1]
Cyclic AMP activates enzymes that break down glycogen into glucose. [1]
The glucose is respired in muscle cells, releasing energy that is transferred to ATP for vigorous activity. [1 spare]

(e) Cold water also stimulates nerves that speed the heart, so the data do not separate the effect of adrenaline from that of nerve signals. [1]

Mark tags are provisional: they come from my own illustrative plan, not from an official markscheme.
Sources: your question and its data (supplied text); Biology course notes (course notes)"""


def main():
    with open(SRC, encoding="utf-8") as f:
        tasks = json.load(f)
    by_id = {t["task_id"]: t for t in tasks}
    os.makedirs(OUT_DIR, exist_ok=True)
    written = []
    for tid in ("bi-t14", "bi-p8d"):
        record = dict(by_id[tid])
        record["response_text"] = RESPONSES[tid].strip()
        path = os.path.join(OUT_DIR, tid + ".json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(record, f, ensure_ascii=False, indent=2)
            f.write("\n")
        written.append(path)
    for p in written:
        print(p)


if __name__ == "__main__":
    main()
