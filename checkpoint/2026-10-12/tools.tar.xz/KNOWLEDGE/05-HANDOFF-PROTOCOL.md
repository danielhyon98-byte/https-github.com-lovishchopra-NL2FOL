# Final handoff protocol (Daniel, 17 Oct ~14:10 UTC) — runs LAST, after the round-8 fixes are pushed

Daniel's order, verbatim: "good once every task prior to round 8 testing is complete push updates to main repo regardless of
bugs unless critical to infrastructure then continue with round 8 testing and once round 8 fixes are implemented push once
again then follow this protocol:" (the protocol below, pasted by him; it came from Bruno's side).

So the sequence is:
1. Finish every task before round 8 testing: argument diagnostics, overseer rebuild, pre-build, phase 2 up to the gate.
   Bounded repair loops end as soon as no CRITICAL issue is left (02-PRIORITIES defines critical).
2. Push to the main repository (Epinoic-AI/Epinoic-Logic-Translator: verified-updates via publish_final.sh, overseer-prototype
   via publish_overseer.sh). Remaining non-critical bugs are listed as known defects with measured numbers. Never main.
3. Round 8 testing, its fixes, push again (same rule).
4. This protocol (the handoff report). Rounds 9-10, scaling, the final report and the website integration are NOT started
   after it unless Daniel asks again; the protocol itself says Z3 and the overseer stay deferred for the website prototype.

## The protocol (verbatim)

Repository: https://github.com/Epinoic-AI/Epinoic-Logic-Translator

Bruno is preparing a new integration conversation. Your task now is to preserve/upload your existing work and leave an accurate final report. Do not start another implementation or repeat work that is already uploaded.

Read the applicable repository instructions. Inspect local changes, source HEAD and remote heads. Preserve other work and the existing branch/PR base. Check that a branch push cannot deploy or migrate; use your existing safe task branch, or a separate non-deploying preservation branch. Upload owned, non-secret work with an ordinary non-force push. Keep unfinished/unverified work clearly separated and labelled. Do not push to main, merge, deploy, change credentials/settings, migrate remotely or make paid calls. Do not upload .env/.dev.vars, tokens, raw student data, caches or generated outputs that repository rules exclude.

Commit a concise report at docs/handoff/final/08-logic-translator.md. Include:
- Clickable repository URL, branch URL, full source SHA/commit permalink and PR URL if present; scope and changed paths.
- What is implemented, tested, reviewed and deployed, each stated separately.
- Exported interfaces/versions; required inputs, outputs, dependencies and configuration names only.
- Relevant document/artifact paths and exact dependency pins; what supersedes older instructions.
- Checks actually run, their source SHA/runtime and results; synthetic/recorded versus live evidence. Reuse valid existing evidence; do not launch an expensive test campaign just to write this report.
- Remaining defects, decisions, missing assets/permissions, and unuploaded or interrupted work. If none, say so explicitly.
- Exact integration steps and the next owner/action.

Read back the remote branch after pushing and confirm its full SHA and tree match the intended source/report. A local commit or archive does not prove upload. If access blocks this, return the exact sanitized error and preserved-work location through the normal permission flow; never request credentials in chat or bypass restrictions.

Finish with the report's GitHub link, full source SHA, final report-containing branch SHA, and any remaining blocker. No external comments, email or cross-chat messages are requested.

DESIGNATED DESTINATION — VERIFY BEFORE UPLOAD
Repository: https://github.com/Epinoic-AI/Epinoic-Logic-Translator
Expected source/report branch: your existing owned translator work/preservation branches for source; docs/final-z3-handoff for the completion report (check it is unused and cannot deploy; preserve verified-updates)
Required report location inside that repository: docs/handoff/final/08-logic-translator.md

Confirm the actual GitHub owner/repository is exactly the destination above, not the old Bruno-ios path, a personal fork, a Z3 upstream fork, a scratch repository or a different Epinoic project. Preserve existing source directories and the established PR base. If your owned work is on another legitimate task branch, preserve it and identify that exact branch and reason in the report; do not silently relocate or overwrite work to match a name.

Reconcile your latest owned local commits and uncommitted files with the remote. Ensure every intended final source/document change is uploaded to this designated repository, and explicitly list any excluded, unfinished or still-local work. Update your completion report to match the uploaded code, current checks and limitations. Do not call the task uploaded/current solely because an older baseline or a report exists remotely.

After pushing, independently read the remote branch/ref and file tree. Verify the full final branch SHA, that the intended source commit is present in its history, that the expected source files are present, and that the report exists at the required path with the content you wrote. Account for the report commit separately from the source commit. If no source changes need uploading, verify that fact and still publish/verify the current report.

REQUIRED CLICKABLE LINKS — IN THE COMMITTED REPORT AND FINAL REPLY
- Repository: [Epinoic-Logic-Translator](https://github.com/Epinoic-AI/Epinoic-Logic-Translator).
- Exact uploaded source branch URL and source commit permalink (full SHA).
- Existing PR URL, if applicable; otherwise say no PR.
- Completion report URL at the path above. After its commit is pushed, put a commit-pinned report permalink in your final reply: https://github.com/Epinoic-AI/Epinoic-Logic-Translator/blob/<full-report-commit-SHA>/docs/handoff/final/08-logic-translator.md.
- Links to relevant component documentation, artifacts and dependency repositories, with exact pins where applicable.
A repository name, local filesystem path, short SHA or "pushed successfully" alone is not a sufficient handoff. State VERIFIED UPLOADED only after the remote checks succeed; otherwise state BLOCKED or PARTIALLY UPLOADED and identify exactly what is missing.

YOUR COMPONENT

Codex now observes verified-updates at 5a53c110465bb978dd1d8b9db31cc1d879f8eaa3, newer than the earlier a91a4f9, plus preserve/2026-10-16 branches. Recheck before acting. Do not repeat the initial upload.

Confirm the intended final translator code pin, report contract 0.2/engine and translator 0.4.0 accurately, and identify remaining unuploaded work. Explain the IR versus natural-language boundary, fixture-only /v1/outcomes service path, formal status versus release eligibility, signing/auth/hosting requirements and limits of the existing test evidence. Record missing referenced specifications/docs. If your session owns the preserved Overseer work, list its separate refs and verified versus unfinished status; do not present preservation branches as accepted releases. If another chat owns it, identify that boundary rather than writing its report for it.

Z3 and Overseer remain deferred for the website prototype. Do not integrate them, deploy a service, resume model experiments or clear unresolved findings merely to complete this handoff.

## Notes for whoever runs it
- This session owns the overseer work (overseer-prototype on the main repository, the preserve/2026-10-16/* branches, the
  overseer-build and rebuild work); list those refs with verified versus unfinished status.
- Access: pushes reach the repository through the old Bruno-ios path (GitHub answers "This repository moved" to
  Epinoic-AI/Epinoic-Logic-Translator). Before the report push, attach Epinoic-AI/Epinoic-Logic-Translator with add_repo
  (access push) and verify owner/repo and the branch by reading it back from that canonical name.
- docs/final-z3-handoff: check it does not exist (or is unused) and that no deployment or workflow triggers on it.
- The versions to report are read from the code at the final pin (contract, engine, translator), never from memory.
