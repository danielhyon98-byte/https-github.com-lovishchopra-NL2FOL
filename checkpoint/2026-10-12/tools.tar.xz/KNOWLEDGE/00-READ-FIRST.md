# Epinoic Z3 logic checker: compact knowledge for the next session

Read in this order: 00 (this), 01-STATE (where everything stands), 02-PRIORITIES (what to do next, in order),
03-RULES (Daniel's standing rules, latest first), 04-PROCEDURES (how the machinery works). The long-form record is
STANDING_INSTRUCTIONS.md (every instruction verbatim, dated) and RESUME.md (restoring a fresh container from the
checkpoint branch). These files sit in the checkpoint at checkpoint/2026-10-12/ on origin
(danielhyon98-byte/https-github.com-lovishchopra-NL2FOL), inside tools.tar.xz under KNOWLEDGE/.

## The goal (Daniel, 17 Oct ~05:50)
"I want a useable z3 logic checker infrastructure." Finish as many tasks as possible within the weekly usage limit,
no optimisation work, then continue next week from these files.

## The system in one paragraph
Sixteen IB specialist agents (cheapest model tier) answer students. The translator (package epinoic_logic in the
NL2FOL-named repo) turns each answer's claims into an allowlisted IR that a Z3 engine decides; STEM working is
checked by its own STEM support; a channel/hub (RouterHub) attaches signed receipts and integrity findings to every
transfer between agents; logic-checking overseer agents (Haiku) review blind dossiers with a knowledge pack, and only
signed engine results are trusted. A delivery rule gives the formal path four minutes, else the overseer selects the
most accurate candidate above 90% or the answer is withheld. An integration protocol and kit (Z3 and STEM REQUIRED)
let a fresh session layer the checker on top of the website (Epinoic-AI/epinoic-ai-website, Cloudflare Worker) and the
agents repository (epinoic-agent-training-API-connector). Z3 cannot run inside a Worker: it runs as a native Python
service (Cloudflare Container or external HTTPS with a bearer token).

## Repositories
- Dev repo (origin): danielhyon98-byte/https-github.com-lovishchopra-NL2FOL, branch claude/z3-verification-engine-plan-nk3luq
  (pushes allowed: that branch and checkpoint/2026-10-12 only).
- Main repo (Bruno's): Epinoic-AI/Epinoic-Logic-Translator, reached as Bruno-ios/Epinoic-Logic-Translator (redirect).
  Uploads ONLY through scratchpad publishers: verified-updates (verified line), overseer-prototype, backup/*-previous,
  prototype + tag prototype-round8 after round 8, the final release, preserve/*. Never touch import/translator-baseline.
- Z3 source mirror: danielhyon98-byte/https-github.com-Z3Prover-z3 (read reference).
- Website: Epinoic-AI/epinoic-ai-website (read-only until the LAST task; its AGENTS.md rules apply).
- Agents: danielhyon98-byte/epinoic-agent-training-API-connector (public; round-8 specialists are built from it).

- 05-HANDOFF-PROTOCOL.md: the governing order since 17 Oct ~14:10 and the final handoff protocol (verbatim). Read it before 02.
