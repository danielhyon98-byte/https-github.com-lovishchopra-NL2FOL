# Priorities (Daniel, 17 Oct ~05:50: "a useable z3 logic checker infrastructure"; no optimisation)

Do them in this order; a later item never delays an earlier one.

1. Translator correctness (the checker must not mislead): finish the end-to-end fixes (8 bugs) and the argument
   diagnostics (three accuracy issues: unchecked source labels, the missing link written in as a premise, no STEM method
   reference; the audit's security findings; false alarms) together with the 67 re-run review findings in translator code.
   Each commits only after independent verification, then is simulated and pushed (presim.sh, event_push.sh).
2. The rebuilt overseer on the STEM-merged translator, STEM integration complete, committed under REBUILD_SUBJECT and
   uploaded by publish_overseer.sh when its gates pass. The fast profile and planner stay deferred (SKIP_FLASH).
3. The integration protocol and kit (Z3 and STEM required; specialist, checks, overseer, combinator and flash-router
   ports; a playbook a fresh session can follow on the website and agents repositories) and the combinator sub-project:
   the pre-build, merged and adapted in phase 2's first step.
4. Phase 2 up to round 8: the overseer merge, the handoff fixes (round-7 handoffs, the 2 overseer re-run findings,
   external review leftovers), the delivery rule (four-minute formal budget, overseer-selected fallback above 90%,
   else withheld), the overseer reading every code and diagnostic, the integration gate (14 lenses; later rounds re-run
   only failing lenses) until clean.
5. Round 8 (connector-built specialists already answered), its fixes, verified commit, push check, push; prototype docs.
6. After round 8: the overseer and flash-router sub-projects (the router carries the pool's planning behind the overseer
   floor), twofold review of combined answers, specialist feedback, their lenses and fixes.
7. Rounds 9 and 10 with fixes, each pushed when verified.
8. Scaling (at most 32 agents; scalability tests only, never stress tests) and the all-sixteen multi-agent test.
9. Final report, comparison with the main repository, release readiness, final release.
10. LAST: website + connector integration with dummy agents through the kit (needs D1, D7, D14, D23, D25).

Deferred (optimisation; only if Daniel asks again): the fast profile and planner under 10% inaccuracy (bound: under
10%, never higher; the flash section of overseer-rebuild.js is kept, set SKIP_FLASH = false), the optimisation checks.

Before the weekly limit: refresh 01-STATE.md and run make_checkpoint.sh build && make_checkpoint.sh commit
(CHECKPOINT_TAG=2026-10-12), so the next session can restore everything (RESUME.md).
