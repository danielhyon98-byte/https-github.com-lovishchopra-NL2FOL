# Priorities (Daniel, 17 Oct ~05:50: "a useable z3 logic checker infrastructure"; no optimisation)

GOVERNING ORDER (Daniel, 17 Oct ~14:10; 05-HANDOFF-PROTOCOL.md): finish every task before round 8 testing -> push to the main
repository "regardless of bugs unless critical to infrastructure" -> round 8 testing and fixes -> push again -> the handoff
protocol (05-HANDOFF-PROTOCOL.md). Nothing after the protocol unless Daniel asks again.

HANDOFF FIRST, THEN CONTINUE (Daniel ~19:15 and ~19:30, 17 Oct): build the handoff package of the completed, verified prototype
(KNOWLEDGE/05-HANDOFF-PROTOCOL.md; run wf_4015a4e9-d80), then CONTINUE every workflow and the designated tasks below in order.

FOCUS (Daniel, 17 Oct ~16:10: "once prebuild is done focus on overseer build then translator fixes end to end fixes especially
with the website is not priority"): the pre-build is done; the overseer rebuild comes first, then the translator fixes (argument
diagnostics, end-to-end). The website is not a priority: no website work; phase 2 only finishes its running protocol step and then
waits for the rebuild. If the weekly usage runs short, pause the argument-diagnostics workflow before the rebuild, never the rebuild.

CRITICAL TO INFRASTRUCTURE (blocks a commit or a push; everything else is a known defect, listed with measured numbers):
(a) a security weakness: input that stalls or crashes the service (regular-expression blow-up, oversize or nested input),
    forged signatures, flags or diagnostics accepted, a supplied text that instructs the system, secrets exposed;
(b) a safety-boundary violation (repository CLAUDE.md): an existing check weakened, softened or silenced, a status upgraded,
    a non-success shown as success, model output evaluated, the IR allowlist widened, the signed binding inconsistent, a test
    weakened, skipped or deleted;
(c) the infrastructure broken: the suite failing, a crash, a recorded arena round losing functional count, the service or CLI
    failing to start, an incompatible contract or schema change, the simulation (presim) failing, the pack export failing.
Detection quality (misses, false alarms, wrong names, the 95% corpus bar, the overseer's fault and false-alarm thresholds) is
NOT critical: such bugs never block the push, and they are reported as measured. Bounded repair loops stop as soon as no
critical issue is left, or at their round limit.

Do them in this order; a later item never delays an earlier one.

1. Translator correctness (the checker must not mislead): finish the end-to-end fixes (8 bugs) and the argument
   diagnostics (three accuracy issues: unchecked source labels, the missing link written in as a premise, no STEM method
   reference; the audit's security findings; false alarms) together with the 67 re-run review findings in translator code.
   Each commits only after independent verification, then is simulated and pushed (presim.sh, event_push.sh).
   Argument diagnostics' extra commit gate: the first hold-out (corpus/holdout) is quoted to the repairers, so the final
   generalisation check is the sealed blind corpus/holdout2 (run wf_86c733b1-779; check MANIFEST.sha256 first, then run
   run_corpus.py on the staged tree and compare with holdout2-work/baseline-*-final: no family worse than 8a78efe on
   false alarms, naming clearly better). Report the hold-out-2 numbers as measured, whatever they are.
2. The rebuilt overseer on the STEM-merged translator, STEM integration complete, committed under REBUILD_SUBJECT and
   uploaded by publish_overseer.sh when its gates pass. The fast profile and planner stay deferred (SKIP_FLASH).
3. The integration protocol and kit (Z3 and STEM required; specialist, checks, overseer, combinator and flash-router
   ports; a playbook a fresh session can follow on the website and agents repositories) and the combinator sub-project:
   the pre-build, merged and adapted in phase 2's first step.
4. Phase 2 up to round 8: the overseer merge, the handoff fixes (round-7 handoffs, the 2 overseer re-run findings,
   external review leftovers), the delivery rule (four-minute formal budget, overseer-selected fallback above 90%,
   else withheld), the overseer reading every code and diagnostic, the integration gate (14 lenses; later rounds re-run
   only failing lenses) until clean.
5. Round 8 (connector-built specialists already answered), its fixes, verified commit, push check, push; prototype docs.
6. After round 8: the overseer and flash-router sub-projects (the router carries the pool's planning behind the overseer
   floor), twofold review of combined answers, specialist feedback, their lenses and fixes.
7. Rounds 9 and 10 with fixes, each pushed when verified.
8. Scaling (at most 32 agents; scalability tests only, never stress tests) and the all-sixteen multi-agent test.
9. Final report, comparison with the main repository, release readiness, final release.
10. (Superseded 17 Oct ~14:10: after the round-8 push the handoff protocol runs instead; rounds 9-10, scaling, final report and the
    website integration are not started unless Daniel asks again. The protocol keeps Z3 and the overseer deferred for the website.)

Deferred (optimisation; only if Daniel asks again): the fast profile and planner under 10% inaccuracy (bound: under
10%, never higher; the flash section of overseer-rebuild.js is kept, set SKIP_FLASH = false), the optimisation checks.

Before the weekly limit: refresh 01-STATE.md and run make_checkpoint.sh build && make_checkpoint.sh commit
(CHECKPOINT_TAG=2026-10-12), so the next session can restore everything (RESUME.md).

Daniel 31 Oct ~22:4x (verbatim): "then do round 9 and 10 once you are done with round 8" -> after round 8 and its fixes and push:
the post-round-8 architecture step, round 9 + fixes + push, round 10 + fixes + push (phase2-cont.js with args.continueAfterRound8),
THEN the handoff protocol. Weekly allowance: final checkpoint first at ~85%.
