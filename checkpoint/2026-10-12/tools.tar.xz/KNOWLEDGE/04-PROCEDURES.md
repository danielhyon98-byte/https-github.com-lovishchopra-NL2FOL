# Procedures (S = the scratchpad; R = the dev checkout; WF = the workflow journals folder)

## Publishing (hourly at hh:00 by the :58 routine; on demand after a new final commit)
- hourly_push.sh waits for hh:00, runs publish_final.sh (verified-updates) and publish_overseer.sh (overseer-prototype)
  with HOURLY_FAST=1. Only a commit with a final title (whitelist in publish_final.sh, event_push.sh, presim.sh:
  "Fix the end-to-end simulation findings", "^Argument diagnostics: ", "^Integration: ", "Fix the cN clearance
  findings", "Prototype: ...", merges, ...) whose prepared simulation passed (presim.sh -> simcache/) is uploaded;
  otherwise an hourly progress note. The replaced head is backed up as backup/<branch>-previous. Minimum gap 20 min.
- overseer_gate.py gates the overseer upload: REBUILD_SUBJECT must be a two-parent merge, its journal must show
  rebuild:merge, a clean rebuild:audit after the last merge step, eval:rebuild and commit:rebuild.
- After a verified fix commit: bash S/presim.sh, then bash S/event_push.sh (skips hh:56-hh:03).

## Workflows
- Resume after a VM restart or a stop: Workflow({scriptPath, resumeFromRunId}) with the SAME args (the rebuild's args are
  in S/wf/overseer-rebuild-args.json). The longest unchanged prefix of agent() calls replays from cache: edit only code
  and prompts of calls that have not run. Stopping a workflow kills its running agent; restart at a step boundary.
- Two agents per workflow at a time (4 CPUs); workflow agents cannot spawn sub-agents. Parallel work = helper workflows
  generated from the owning script so prompts are identical:
  - argument diagnostics: S/patches/argdiag-helper-cd.js and -e.js (results in S/wf/argdiag/fix-<k>/result.json,
    collected by the main workflow);
  - integration gate (phase 2): when S/wf/phase2/integrate/g<g>/DISPATCH.json appears, run
    python3 -I S/patches/make_gate_helper.py <phase2-pipeline.js> S/patches/gate-helper.js and launch it 3 times with
    args {g, keys} splitting the DISPATCH lenses (round 1: H1 fresh-session-integration, stem-soundness, correctness,
    combinator-faults, contained; H2 end-to-end, stem-precision, fidelity, formal-robustness, combinator-subrepo;
    H3 diagnostics-corpus, parser-safety, security, router-envelope). Collectors fall back to running a lens themselves
    after 3 hours.
  - flash arms (only if the flash section is re-enabled): S/patches/make_arm_helper.py, 4 parts per pilot round.
  - argument-diagnostics verification (from round 2): when repair:<n> returns and verify:corpus:<n+1> starts, rebuild
    S/patches/argdiag-verify-helper.js with python3 -I S/patches/make_argdiag_verify_helper.py <argdiag script> <out> and launch
    it with args {round: n+1, keys: ['adversarial', 'rerun']}; the main workflow's collectors read
    S/wf/argdiag/verify-<round>/<lens>/result.json (and run the lens themselves after 4 hours).
- Phase 2 launch (Daniel ~14:30 "accelerate"): as soon as the pre-build workflow wf_6d5b0a80-d5e has returned and PREBUILD.md
  exists. Phase 2 waits for the overseer rebuild commit (wait:rebuild) and, before the integration steps, for the
  argument-diagnostics commit (wait:argdiag): once phase 2 runs, commit the verified argdiag tree in its own worktree on the
  local branch argdiag-final (git -C <argdiag-integ> switch -c argdiag-final, commit "Argument diagnostics: ..."); phase 2
  merges it under "Argument diagnostics: merged into the integrated translator" (whitelisted for upload).
- Sub-branches (no new repositories): S/publish_subbranch.sh <combinator|flash-router|overseer> <verified commit> [reason].
- Publisher simulations (31 Oct): simulate.sh runs its test and contained runs under `timeout --foreground 5400` so that
  the hourly 100-second cut also ends them (before, each cut left an orphaned suite running up to 90 minutes).
- Fixers never defer a CRITICAL finding as performance work: an input that stalls the service (regex blow-up, quadratic
  scan) is a security weakness (02-PRIORITIES (a)); phase2-cont.js carries this rule (CRIT_STALL) since 31 Oct 09:2x.
- Watchdog: S/watchdog.py every 5 minutes (Monitor, re-arm every 30 minutes): STALL, LOOP, LONG, ENDED.
- Usage: list_events(session, kinds rate_limit_event) gives five_hour and seven_day utilization and reset times. When the
  five-hour window nears 90%, pause the newest agents (stop their workflows) and resume after its reset; a limit hit
  kills every running agent.

## Verification bar (every commit)
Full suite green (python -m pytest -q -p no:cacheprovider; never the stress selection), the arena harness on every
recorded round with no functional count lower (r1 30/30, r1-adv 150/151, r2-r6 46/46, r7 177/177, then c1...),
hygiene grep clean, an independent verifier for fixes; tests are never weakened or deleted.

## Restore next week
Follow RESUME.md (fetch checkpoint/2026-10-12, verify SHA256SUMS, fetch branches.bundle, recreate worktrees, unpack
wip.tar.xz and tools.tar.xz into the new scratchpad, rewrite the old scratchpad path, rebuild the venv:
python -m venv z3venv && z3venv/bin/pip install -e "R[dev,service,providers]"). Then read 01-STATE and 02-PRIORITIES and
resume or relaunch the workflows from their scripts.

## Resume after a platform update: check the cache hit (23 Oct)
On 23 Oct, after the weekly-limit stop and a VM restart, resuming argdiag (wf_0d5b0b62-dbd) and the deployment package
(wf_78542ca7-4b8) with the identical scriptPath and no args MISSED the result cache (new agent keys for unchanged prompts;
fixers a/b and both surveys started again). The rebuild (with args) hit. Rule: right after any resume, compare the first
"started" rows of journal.jsonl with earlier keys; a completed label starting again with a new key = miss: stop the run at
once and continue with a continuation script that reads the finished results from files (cache dump per label:
scratchpad/wf/cache/<run>.json). Current continuations: wf-scripts/argdiag-cont.js (from repair round 2; state in
wf/argdiag/cont/) and wf-scripts/z3-deployment-cont.js (from design; surveys in wf/z3-deploy/survey-*/result.json).
The argdiag round-3+ verify helper is still built from the ORIGINAL argdiag script (verifyPrompt unchanged).

## Regression closure after an unconverged repair loop (24 Oct)
- When a repair loop ends with high issues still open, classify each open issue against the COMMITTED BASE (regression: the
  base is right and the staged tree is not; security; gap: both wrong; improved; not reproduced). Close only regressions and
  security issues (narrow the new reading at its cause, or revert it), verify differentially (staged against base on every
  repro, corpora, arena receipts, new probes near every changed reading). Gaps become known defects for round 8. This target
  is fixed (the base), so it converges, unlike "no high open" against verifiers who plant new shapes each round.
- Argdiag: wf-scripts/argdiag-regression.js (base 7991e8b exported to wf/argdiag/regr/base-tree; round-6 staged tree = local ref
  argdiag-r6-snapshot and wf/argdiag/regr/r6-tree). Snapshot the staged tree as a local ref before any further repair.

## Commit with known defects (Daniel 24 Oct ~18:25: "Commit both (Recommended)")
- Overseer rebuild: wf-scripts/overseer-rebuild.js now commits after its last audit even with a high open
  (KNOWN_DEFECTS_APPROVED; backup .before-known-defects); every open issue goes to "Known defects" in the message. To apply it
  when the running instance returns uncommitted: resume with the SAME scriptPath and args (S/wf/overseer-rebuild-args.json),
  check the cache hit. BEFORE publish_overseer can upload it: write S/approvals/overseer-known-defects.json =
  {"audit_sha256": overseer_gate.audit_digest(<the last rebuild:audit result from the journal>), "approved_by": "Daniel",
  "decision": "...", "when": "..."}; overseer_gate.py (backup .before-known-defects) accepts a not-clean last audit only with
  that file and every open issue listed as "[severity] problem" in the message.
- Argument diagnostics: after the security fix verifies, commit the staged tree in .worktrees/argdiag-integ on the local branch
  argdiag-final (subject "Argument diagnostics: ...", with "Suite:" and "Harness after the change:" lines and a Known defects
  section), run simulate.sh translator argdiag-final argdiag-final; phase 2 (resumed 18:40, waiting for the rebuild commit)
  merges it under "Argument diagnostics: merged into the integrated translator" (the dev branch changed 19 of the same files).

## Gate helpers from round 4 (1 Nov)
- Launch the round-4+ gate helpers from S/patches/gate-helper-final.js (= gate-helper.js + FINAL_ONLY: the lens writes report.json once, as its last step; drafts go to draft.json). Reason: in g3 the correctness lens wrote a draft report.json at 05:54, the pipeline collector took it, and the lens's final report (07:12) added a critical finding; phase 2 had to be stopped and resumed with RECOLLECT. Args as before: {g, keys}; two lenses per helper.
- From g3 the pipeline counts a critical finding whatever its severity (the g2+ minor filter dropped critical minors).
- Budget decision: phase 2 reads S/wf/phase2/DECISION.json after round 8 (agent decision:architecture). Write {"skip_architecture": true, "by": "Daniel", "when": "<time>"} ONLY on Daniel's option 2 or 3; no file = option 1 (plan unchanged).
- Handoff refresh after an upload (1 Nov): template workflow S/wf-scripts/handoff-refresh-template-30oct.js (Write -> independent fact-check -> Fix; args {S, R, OUT, SRC, WEB, AGT, PRE}). For the next refresh: SRC = S/handoff/filled-30oct (the published documents), OUT = S/handoff/refresh-<date>, rewrite FACTS with the new pin's measured results (gate commits 35f1be1, 7f9ec18, the round-3 commit, their suite/harness numbers from the commit messages, the left_undone lists as known defects, KIT-HS-007 overseer port pending the architecture step), keep the placeholders {{VU_SHA}} {{VU_SHORT}} {{UPLOAD_STATUS}} {{SIM_LINE}} {{PORT_STATUS}}; then fill.py + push_handoff.sh and read back.
