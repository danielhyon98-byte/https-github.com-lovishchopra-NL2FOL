# Procedures (S = the scratchpad; R = the dev checkout; WF = the workflow journals folder)

## Publishing (hourly at hh:00 by the :58 routine; on demand after a new final commit)
- hourly_push.sh waits for hh:00, runs publish_final.sh (verified-updates) and publish_overseer.sh (overseer-prototype)
  with HOURLY_FAST=1. Only a commit with a final title (whitelist in publish_final.sh, event_push.sh, presim.sh:
  "Fix the end-to-end simulation findings", "^Argument diagnostics: ", "^Integration: ", "Fix the cN clearance
  findings", "Prototype: ...", merges, ...) whose prepared simulation passed (presim.sh -> simcache/) is uploaded;
  otherwise an hourly progress note. The replaced head is backed up as backup/<branch>-previous. Minimum gap 20 min.
- overseer_gate.py gates the overseer upload: REBUILD_SUBJECT must be a two-parent merge, its journal must show
  rebuild:merge, a clean rebuild:audit after the last merge step, eval:rebuild and commit:rebuild.
- After a verified fix commit: bash S/presim.sh, then bash S/event_push.sh (skips hh:56-hh:03).

## Workflows
- Resume after a VM restart or a stop: Workflow({scriptPath, resumeFromRunId}) with the SAME args (the rebuild's args are
  in S/wf/overseer-rebuild-args.json). The longest unchanged prefix of agent() calls replays from cache: edit only code
  and prompts of calls that have not run. Stopping a workflow kills its running agent; restart at a step boundary.
- Two agents per workflow at a time (4 CPUs); workflow agents cannot spawn sub-agents. Parallel work = helper workflows
  generated from the owning script so prompts are identical:
  - argument diagnostics: S/patches/argdiag-helper-cd.js and -e.js (results in S/wf/argdiag/fix-<k>/result.json,
    collected by the main workflow);
  - integration gate (phase 2): when S/wf/phase2/integrate/g<g>/DISPATCH.json appears, run
    python3 -I S/patches/make_gate_helper.py <phase2-pipeline.js> S/patches/gate-helper.js and launch it 3 times with
    args {g, keys} splitting the DISPATCH lenses (round 1: H1 fresh-session-integration, stem-soundness, correctness,
    combinator-faults, contained; H2 end-to-end, stem-precision, fidelity, formal-robustness, combinator-subrepo;
    H3 diagnostics-corpus, parser-safety, security, router-envelope). Collectors fall back to running a lens themselves
    after 3 hours.
  - flash arms (only if the flash section is re-enabled): S/patches/make_arm_helper.py, 4 parts per pilot round.
  - argument-diagnostics verification (from round 2): when repair:<n> returns and verify:corpus:<n+1> starts, rebuild
    S/patches/argdiag-verify-helper.js with python3 -I S/patches/make_argdiag_verify_helper.py <argdiag script> <out> and launch
    it with args {round: n+1, keys: ['adversarial', 'rerun']}; the main workflow's collectors read
    S/wf/argdiag/verify-<round>/<lens>/result.json (and run the lens themselves after 4 hours).
- Phase 2 launch (Daniel ~14:30 "accelerate"): as soon as the pre-build workflow wf_6d5b0a80-d5e has returned and PREBUILD.md
  exists. Phase 2 waits for the overseer rebuild commit (wait:rebuild) and, before the integration steps, for the
  argument-diagnostics commit (wait:argdiag): once phase 2 runs, commit the verified argdiag tree in its own worktree on the
  local branch argdiag-final (git -C <argdiag-integ> switch -c argdiag-final, commit "Argument diagnostics: ..."); phase 2
  merges it under "Argument diagnostics: merged into the integrated translator" (whitelisted for upload).
- Sub-branches (no new repositories): S/publish_subbranch.sh <combinator|flash-router|overseer> <verified commit> [reason].
- Publisher simulations (31 Oct): simulate.sh runs its test and contained runs under `timeout --foreground 5400` so that
  the hourly 100-second cut also ends them (before, each cut left an orphaned suite running up to 90 minutes).
- Fixers never defer a CRITICAL finding as performance work: an input that stalls the service (regex blow-up, quadratic
  scan) is a security weakness (02-PRIORITIES (a)); phase2-cont.js carries this rule (CRIT_STALL) since 31 Oct 09:2x.
- Watchdog: S/watchdog.py every 5 minutes (Monitor, re-arm every 30 minutes): STALL, LOOP, LONG, ENDED.
  Since 8 Nov it also prints one-shot MILESTONE lines for the phase-2 events listed in S/watch-milestones.txt ("<started|result> <label regex>"; state in S/watch-milestones.state, delete a line's entry there to re-arm it). Use it instead of long background watchers, which stop at the 2-hour background limit. Start S/hourly_push.sh without redirecting its output to hourly-push-<date>.log: the script writes that log itself.
- Usage: list_events(session, kinds rate_limit_event) gives five_hour and seven_day utilization and reset times. When the
  five-hour window nears 90%, pause the newest agents (stop their workflows) and resume after its reset; a limit hit
  kills every running agent.

## Verification bar (every commit)
Full suite green (python -m pytest -q -p no:cacheprovider; never the stress selection), the arena harness on every
recorded round with no functional count lower (r1 30/30, r1-adv 150/151, r2-r6 46/46, r7 177/177, then c1...),
hygiene grep clean, an independent verifier for fixes; tests are never weakened or deleted.

## Restore next week
Follow RESUME.md (fetch checkpoint/2026-10-12, verify SHA256SUMS, fetch branches.bundle, recreate worktrees, unpack
wip.tar.xz and tools.tar.xz into the new scratchpad, rewrite the old scratchpad path, rebuild the venv:
python -m venv z3venv && z3venv/bin/pip install -e "R[dev,service,providers]"). Then read 01-STATE and 02-PRIORITIES and
resume or relaunch the workflows from their scripts.

## Resume after a platform update: check the cache hit (23 Oct)
On 23 Oct, after the weekly-limit stop and a VM restart, resuming argdiag (wf_0d5b0b62-dbd) and the deployment package
(wf_78542ca7-4b8) with the identical scriptPath and no args MISSED the result cache (new agent keys for unchanged prompts;
fixers a/b and both surveys started again). The rebuild (with args) hit. Rule: right after any resume, compare the first
"started" rows of journal.jsonl with earlier keys; a completed label starting again with a new key = miss: stop the run at
once and continue with a continuation script that reads the finished results from files (cache dump per label:
scratchpad/wf/cache/<run>.json). Current continuations: wf-scripts/argdiag-cont.js (from repair round 2; state in
wf/argdiag/cont/) and wf-scripts/z3-deployment-cont.js (from design; surveys in wf/z3-deploy/survey-*/result.json).
The argdiag round-3+ verify helper is still built from the ORIGINAL argdiag script (verifyPrompt unchanged).

## Regression closure after an unconverged repair loop (24 Oct)
- When a repair loop ends with high issues still open, classify each open issue against the COMMITTED BASE (regression: the
  base is right and the staged tree is not; security; gap: both wrong; improved; not reproduced). Close only regressions and
  security issues (narrow the new reading at its cause, or revert it), verify differentially (staged against base on every
  repro, corpora, arena receipts, new probes near every changed reading). Gaps become known defects for round 8. This target
  is fixed (the base), so it converges, unlike "no high open" against verifiers who plant new shapes each round.
- Argdiag: wf-scripts/argdiag-regression.js (base 7991e8b exported to wf/argdiag/regr/base-tree; round-6 staged tree = local ref
  argdiag-r6-snapshot and wf/argdiag/regr/r6-tree). Snapshot the staged tree as a local ref before any further repair.

## Commit with known defects (Daniel 24 Oct ~18:25: "Commit both (Recommended)")
- Overseer rebuild: wf-scripts/overseer-rebuild.js now commits after its last audit even with a high open
  (KNOWN_DEFECTS_APPROVED; backup .before-known-defects); every open issue goes to "Known defects" in the message. To apply it
  when the running instance returns uncommitted: resume with the SAME scriptPath and args (S/wf/overseer-rebuild-args.json),
  check the cache hit. BEFORE publish_overseer can upload it: write S/approvals/overseer-known-defects.json =
  {"audit_sha256": overseer_gate.audit_digest(<the last rebuild:audit result from the journal>), "approved_by": "Daniel",
  "decision": "...", "when": "..."}; overseer_gate.py (backup .before-known-defects) accepts a not-clean last audit only with
  that file and every open issue listed as "[severity] problem" in the message.
- Argument diagnostics: after the security fix verifies, commit the staged tree in .worktrees/argdiag-integ on the local branch
  argdiag-final (subject "Argument diagnostics: ...", with "Suite:" and "Harness after the change:" lines and a Known defects
  section), run simulate.sh translator argdiag-final argdiag-final; phase 2 (resumed 18:40, waiting for the rebuild commit)
  merges it under "Argument diagnostics: merged into the integrated translator" (the dev branch changed 19 of the same files).

## Gate helpers from round 4 (1 Nov)
- Launch the round-4+ gate helpers from S/patches/gate-helper-final.js (= gate-helper.js + FINAL_ONLY: the lens writes report.json once, as its last step; drafts go to draft.json). Reason: in g3 the correctness lens wrote a draft report.json at 05:54, the pipeline collector took it, and the lens's final report (07:12) added a critical finding; phase 2 had to be stopped and resumed with RECOLLECT. Args as before: {g, keys}; two lenses per helper.
- From g3 the pipeline counts a critical finding whatever its severity (the g2+ minor filter dropped critical minors).
- Budget decision: phase 2 reads S/wf/phase2/DECISION.json after round 8 (agent decision:architecture). Write {"skip_architecture": true, "by": "Daniel", "when": "<time>"} ONLY on Daniel's option 2 or 3; no file = option 1 (plan unchanged).
- Handoff refresh after an upload (1 Nov): template workflow S/wf-scripts/handoff-refresh-template-30oct.js (Write -> independent fact-check -> Fix; args {S, R, OUT, SRC, WEB, AGT, PRE}). For the next refresh: SRC = S/handoff/filled-30oct (the published documents), OUT = S/handoff/refresh-<date>, rewrite FACTS with the new pin's measured results (gate commits 35f1be1, 7f9ec18, the round-3 commit, their suite/harness numbers from the commit messages, the left_undone lists as known defects, KIT-HS-007 overseer port pending the architecture step), keep the placeholders {{VU_SHA}} {{VU_SHORT}} {{UPLOAD_STATUS}} {{SIM_LINE}} {{PORT_STATUS}}; then fill.py + push_handoff.sh and read back.

## Simulations: run them from the main session (2 Nov lesson)
A workflow agent that starts simulate.sh in the background and then ends its turn (e.g. returns "Waiting for the simulation to finish.") gets its background job killed: the cache .tmp then holds only "Terminated" and nothing is cached. Run long simulations from the main session instead: `bash S/presim.sh` with run_in_background (it simulates the newest final commit on dev and the published source, caches atomically, and drops a run that died without a SIMULATION line). In fix workflows, end at the commit + checks; simulate afterwards from the main session.

## Full simulations exceed 2 hours (2 Nov)
The suite with the recorded rounds now takes ~82 min and the contained run 40+ min, so presim.sh run as a background command is killed at the 2-hour background limit. Run long simulations DETACHED: `setsid nohup bash <script> > <log> 2>&1 < /dev/null &` (see run_sim_16d5a4a.sh: takes the presim lock, caches like presim, then event_push.sh), and watch the log with a background until-loop (re-arm at 2 h). simulate.sh replays only the rounds the SOURCE commit's "Harness after the change" line records: a final commit must record every round (r1, r1-adv, r2-r7) or the simulation must take its floors from a commit that does. Suite cap in simulate.sh is 7200 s (was 5400).

## VM restarts at idle wakes (3 Nov)
The VM restarted at the 21:00 and 22:00 hourly wakes (uptime 0-1 min each time; disk kept), after idle hours. A detached simulation does not survive a restart: at every wake check uptime and the detached job's log, and re-start a killed simulation (its flock is released by the restart).

## Publisher run time near its 100 s cut (3-5 Nov)
publish_final.sh took 7-98 s per hourly run since 3 Nov (bimodal, cause not measured). hourly_push.sh and event_push.sh both cut it at 100 s (the hourly run must stay under 2 min 30 s). A cut round-8 upload is re-run with event_push.sh outside hh:56-hh:03 and read back; refs are never half-written.

## Verify with the recorded rounds supplied (7 Nov lesson)
Twelve suite tests (tests/overseer/test_rebuild_rekeyed_r7.py and others) SKIP unless EPINOIC_ARENA_ROUNDS names a directory
holding the recorded rounds; simulate.sh sets it (a copy of S/arena/r[0-9]* with specialists/), so a simulation can fail on a
test every earlier verification skipped (the c1 follow-up 32a5c0e: 22503 passed + 12 skipped in the landing; the presim: 1 failed).
Every landing or fix verification sets EPINOIC_ARENA_ROUNDS to a COPY of the rounds (S/landing/verify.sh does since 7 Nov 21:0x).

## Sub-project layout since architecture step 2 (8 Nov, ab44c8a)
The overseer is overseer/ (package epinoic_overseer, overseer/src, tests overseer/tests/overseer_tests, scripts overseer/scripts,
docs overseer/docs; docs/OVERSEER_DESIGN.md and docs/OVERSEER_RESULTS.md are pointer stubs), the flash router flash-router/src,
the combinator combinator/src. The shared venv has editable installs of all four. simulate.sh (backup simulate.sh.before-subprojects)
now lists every sub-project src of the tree under test before the shared packages, checks each package imports from the tree,
and runs the contained run from overseer/scripts/run_contained.py when scripts/overseer/ is gone. Check publish_overseer.sh and
overseer_gate.py for old paths before the next overseer upload. Worktree tests: PYTHONPATH=<wt>/src:<wt>/overseer/src:<wt>/flash-router/src.

## Disk (9 Nov lesson)
- The session's disk allowance is fixed (df "Avail" is what matters). Big, safe-to-drop items seen on 9 Nov: disposable
  git clones made for split checks (wf/phase2/integrate/arch2*/split*/clone, 1.2 GB each; outputs and logs beside them
  are the evidence to keep) and old pytest basetemps under /tmp/pytest-of-root (check mtime and open files first).
- Before removing anything: check its age, that no process has its cwd or an open file inside it, and that no running
  workflow prompt names the path. Record what was removed in 01-STATE.
