# State (refreshed at every hourly run; this copy: 2026-10-17 15:16 UTC)

## Published
- verified-updates (main repo): d872018 at 10:46 carries NEW code: source 8a78efe "Fix the end-to-end simulation findings"
  (presim OK); later hourly updates are progress notes on it (latest 1afc0f8 at 15:00). Backup branch backup/verified-updates-previous = the replaced head.
- overseer-prototype: held at 9547fc9. Candidates 6adbd64 and 87eaf86 fail the contained run (235/254 faults named and
  confirmed; 3 false alarms on genuine transfers).
- Dev branch: code tip 8a78efe "Fix the end-to-end simulation findings" (progress notes after it, latest 7991e8b) (verified clean on the third verification; simulated OK;
  pushed to origin; presim + event_push uploading it to verified-updates). The main checkout is clean again.

## In flight (workflow run ids; scripts under the workflows/scripts folder or scratchpad, see runs.json)
| Work | Run | State | Next |
|---|---|---|---|
| Overseer rebuild (STEM-merged translator, repairs, STEM completion) | wf_92057cdf-3e2, script wf-scripts/overseer-rebuild.js | STEM repair 2 staged (6479 passed, rounds unchanged, contained run 13/13 gates, 15/15 STEM mutations); STEM audit 3: 7 violations (1 high: a correct '<quantity> at <value> = <value>' statement read as a unit conversion, INT-SUBJ-001 false error; 4 medium; 2 low); STEM repair 3 of at most 8 running (strict rule: the critical-only change was NOT applied to this workflow) | audit -> eval -> commit REBUILD_SUBJECT -> publish_overseer |
| Translator fixes: argument diagnostics + 69 re-run review findings | wf_0d5b0b62-dbd (fixers done: a 72173b9, b b3c66f3, c 542d345, d 1f4f0f1, e 1e6103f) | INTEGRATED, staged in .worktrees/argdiag-integ on 8a78efe (suite green, rounds unchanged, dev corpus 44/44 named, 0/57 false alarms; hold-out 48/66 named, 9 unnamed, 9 missed, 13/68 controls flagged). verify:corpus:1 NOT ok: 25 issues (6 high: hold-out gate, 2 new false alarms ST-REF-001 x = 2.0F and INT-REQ-004 P(A u B), STEM wrong formula outside the table, unit conversion, contradictory givens); verify:invariants:1 NOT ok (2 high: regex blow-up in _ANSWER_AFTER_RE and _LABEL_GAP_RE; 1 medium: B7 pooling loosened INT-CONFLICT-001); adversarial:1 14 issues (2 high), rerun:1 21 (1 high); 66 issues in all. Repair prompt patched (issueText: every issue, most severe first; was cut at 16000 chars); run restarted 13:44 at the repair:1 boundary (task w7owmfr06); repair:1 running on all 66; then repair loop (at most 5 rounds) | repairs -> clean verify -> FINAL GATE on the sealed blind hold-out-2 (run wf_86c733b1-779, corpus/holdout2, MANIFEST.sha256; see 02-PRIORITIES) -> simulate.sh -> commit "Argument diagnostics: ..." -> push -> presim + event_push |
| Hold-out-2 (blind, sealed) | wf_86c733b1-779 | DONE: 136 cases (70 defects, 66 controls), audit ok, MANIFEST.sha256 (sha of manifest 921ff4fa...). Baseline 8a78efe = 22d6a5b: named 23, caught unnamed 30, missed 17, false alarms 31. Staged argdiag BEFORE repair (13:35): named 41, caught unnamed 16, missed 13, false alarms 22; every family's false alarms lower (formal 4->3, informal 3->1, evidence 12->9, stem 12->9) | final gate after the loop (never shown to repairers) |
| End-to-end fixes (8 bugs) | wf_88abd06f-53d | DONE: committed 8a78efe (suite 5667 passed; every round unchanged) | uploaded by event_push |
| Integration pre-build (protocol + kit, 5 ports incl. flash router; combinator sub-project) | wf_6d5b0a80-d5e, branch integ-prebuild | DONE 14:50 (PREBUILD.md): protocol 3dcee98/067da31/af10b4a (contract 2 medium + lows open); combinator c7a716e, repairs ecd5a58, 5697a62 (verify 3: 1 high V3-H1 role-other claim carried into a synthesis accepted silently, 3 medium, 4 low: open, handed to phase 2) | phase 2 merges and adapts it |
| PHASE 2 (round 8 pipeline) | wf_1683c1c3-d71 (task wgj03bzgu), args S/wf/phase2-args.json | RUNNING since 14:53: Protocol (merge integ-prebuild, decisions record) -> wait:rebuild -> merges, handoffs, delivery -> wait:argdiag (+ merge argdiag-final) -> integrate -> 14-lens gate -> round 8 + fixes + push -> STOP | gate helpers on DISPATCH.json; subproject/combinator after its gate is clean |
| Round-8 specialists from the connector (commit 5b60229) | wf_9cd8c3fd-6b2 | done: 16/16, pre.json updated | phase 2 skips them |
| Re-run review lenses | wf_e3e1992e-656 | done: 91 found, 88 confirmed, 69 new (9 blockers, 46 majors) | translator ones in argdiag; 2 overseer ones in phase 2 handoffs; complete list wf/rerun-lenses/handoff.json |
| Flash pilot | wf_3d0a1e9f-bb6 | done | REPORT.md: fast profile 5.6x faster, 15/37 vs 11/37 faults, 10 vs 3 false accusations; not adopted |

## Phase 2 script changes (17 Oct ~14:30-14:50, dry-run clean: patches/dry_p4.mjs)
- Launch as soon as the pre-build has returned (PREBUILD.md); it waits for the rebuild (wait:rebuild) and, before the integration
  steps, for the argument diagnostics (wait:argdiag: on the dev branch, or local branch argdiag-final which it merges as
  "Argument diagnostics: merged into the integrated translator").
- It STOPS after round 8, its fixes and the prototype commit (Daniel's order); args.continueAfterRound8 runs the rest. So the
  overseer sub-project (subproject/overseer), twofold review, rounds 9-10, scaling and the final report are not run.

## Not started (round 8 will not fit this week at the current usage; next week resumes here)
- After round 8: overseer + flash-router sub-projects, twofold review, feedback (inside phase 2), rounds 9-10, scaling,
  multi-agent, final report. The website/connector integration with dummy agents is the LAST task.

## Usage (weekly limit window resets Fri 23 Oct 16:00 UTC)
- 13:54: seven-day 73% used (about 3 points an hour; 85% near 18:00 UTC = final checkpoint); five-hour 13% (resets 17:50).
- Two agents per workflow at a time on this machine (4 CPUs); helper workflows add parallelism (04-PROCEDURES).

## Open decisions for Daniel / owners
- Sub-projects: NO new repositories (Daniel ~13:45: "just dont create new repos. just create sub branches"). Each verified sub-project is
  pushed to origin subproject/<name> by publish_subbranch.sh <name> <verified commit> (git subtree split, own tests on the split
  tree with the same commit's translator port, leak check, fast-forward only). DONE: subproject/flash-router = fcf2381 (split of
  flash-router/ at af10b4a, 19 tests passed). NEXT: combinator when its prebuild verification is clean; overseer after the
  post-round-8 overseer sub-project commit.
- Kit decisions D1-D27: DONE (run wf_a38215b5-e6e): wf/integration-kit/DECISIONS.md, 27 decided, reviewed twice (second review: 12
  medium/low, revised, not re-reviewed). Phase 2's protocol step adds it as integration/DECISIONS.md (documentation only; kit
  behaviour unchanged, fail-closed; the website integration is deferred per the handoff protocol).
- Argument diagnostics commit rule (Daniel ~15:00 "accept edits, go"): critical-only. The argdiag script now has a critical-issue
  judge (gate:<round>) after each verification round from round 2; the loop stops when nothing critical (security, safety
  boundary, broken infrastructure) is open; the rest are known defects (commit_ready in its result). TAKES EFFECT at the restart
  at the verify round 2 boundary (stop task w7owmfr06 when verify:corpus:2 starts, resume, launch the verify helper).
  NOT applied (the permission check refused further steps as 'security test removal'): the rebuild workflow, phase 2's gate
  loop and the upload checks; an overseer_gate.py relaxation was made and then UNDONE (Daniel: 'resolve all at your own discretion').
- Integration kit decisions D1 (Bruno lifts the website's Z3 deferral), D7 hosting, D14 budgets, D23 model ids, D25 the 25 s deadline.
