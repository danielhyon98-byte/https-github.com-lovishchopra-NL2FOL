# State (refreshed at every hourly run; this copy: 2026-10-17 08:00 UTC)

## Published
- verified-updates (main repo): 5bf4ad0 at 05:30, progress-only; code = source commit 22d6a5b "Fix the external review
  findings" (the last verified code). Backup branch backup/verified-updates-previous = the replaced head.
- overseer-prototype: held at 9547fc9. Candidates 6adbd64 and 87eaf86 fail the contained run (235/254 faults named and
  confirmed; 3 false alarms on genuine transfers).
- Dev branch tip d5ca8ef (04:00 progress note). The main checkout holds the end-to-end fixes as a STAGED merge
  (MERGE_HEAD) until they verify: never commit it by hand.

## In flight (workflow run ids; scripts under the workflows/scripts folder or scratchpad, see runs.json)
| Work | Run | State | Next |
|---|---|---|---|
| Overseer rebuild (STEM-merged translator, repairs, STEM completion) | wf_92057cdf-3e2, script wf-scripts/overseer-rebuild.js | STEM completion staged (suite 6251 passed, every round unchanged, contained run 13/13 gates); restarted 07:47 onto the SKIP_FLASH script; STEM audit running | STEM audit; then (patched script, restart at the step boundary) straight to eval + commit "Overseer rebuild: on the STEM-merged translator, with the faulty checks corrected"; fast profile/planner skipped (SKIP_FLASH) |
| Translator fixes: argument diagnostics + 69 re-run review findings | wf_0d5b0b62-dbd (fixers a, b); helpers wf_6ce9374f-e0a (c, d) and wf_21e69e8c-34c (e) | fixers a-e running again since 07:53 (main w0ey0lwp2, helpers whpwd4zno and w4ypkmgdr) | integrate (worktree .worktrees/argdiag-integ) -> 4 verify lenses (corpus, invariants, adversarial, rerun) -> repairs -> commit "Argument diagnostics: ..." |
| End-to-end fixes (8 bugs) | wf_88abd06f-53d | repair 2 running again since 07:53 (2 rejected fixes: ch-e1b fixed in the injector not the detector; ASCII unit exponents now false errors; maa-e1a still missed) | on clean verify: simulate.sh, commit "Fix the end-to-end simulation findings", push origin, presim + event_push |
| Integration pre-build (protocol + kit, 5 ports incl. flash router; combinator sub-project) | wf_6d5b0a80-d5e, branch integ-prebuild | protocol + kit committed on integ-prebuild (3dcee98: suite 5725 passed, +461 tests, all rounds identical); verify found 1 high (an unchecked answer could show 'Automatic checks passed') and 9 medium; repair 1 running; waiting for the E2E commit to build the combinator | PREBUILD.md |
| Round-8 specialists from the connector (commit 5b60229) | wf_9cd8c3fd-6b2 | done: 16/16, pre.json updated | phase 2 skips them |
| Re-run review lenses | wf_e3e1992e-656 | done: 91 found, 88 confirmed, 69 new (9 blockers, 46 majors) | translator ones in argdiag; 2 overseer ones in phase 2 handoffs; complete list wf/rerun-lenses/handoff.json |
| Flash pilot | wf_3d0a1e9f-bb6 | done | REPORT.md: fast profile 5.6x faster, 15/37 vs 11/37 faults, 10 vs 3 false accusations; not adopted |

## Not started
- Phase 2 (round 8 pipeline): .worktrees/scripts/phase2-pipeline.js (dry-run clean). Launch with args {pre: <round8-prep/pre.json>}
  once "Fix the end-to-end simulation findings" and "Argument diagnostics: ..." are committed (it waits for the rebuild).
- After round 8: overseer + flash-router sub-projects, twofold review, feedback (inside phase 2), rounds 9-10, scaling,
  multi-agent, final report. The website/connector integration with dummy agents is the LAST task.

## Usage (weekly limit window resets Fri 23 Oct 16:00 UTC)
- 07:58: seven-day 49% used; five-hour 4% (window resets 12:50 UTC; about 30% an hour with eight agents; check at 10:20).
- Two agents per workflow at a time on this machine (4 CPUs); helper workflows add parallelism (04-PROCEDURES).

## Open decisions for Daniel / owners
- Separate GitHub repositories for the overseer, combinator and flash router (sub-projects are split-ready; no repo created).
- Integration kit decisions D1 (Bruno lifts the website's Z3 deferral), D7 hosting, D14 budgets, D23 model ids, D25 the 25 s deadline.
- Z3 Prover mirror's failing upstream Actions: disable in settings (the API call was refused as CI bypass).
