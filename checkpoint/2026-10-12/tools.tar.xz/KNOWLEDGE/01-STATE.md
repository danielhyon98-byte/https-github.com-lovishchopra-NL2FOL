# State (refreshed at every hourly run; this copy: 2026-10-17 13:02 UTC)

## Published
- verified-updates (main repo): d872018 at 10:46 carries NEW code: source 8a78efe "Fix the end-to-end simulation findings"
  (presim OK); later hourly updates are progress notes on it (latest 6228971 at 13:00). Backup branch backup/verified-updates-previous = the replaced head.
- overseer-prototype: held at 9547fc9. Candidates 6adbd64 and 87eaf86 fail the contained run (235/254 faults named and
  confirmed; 3 false alarms on genuine transfers).
- Dev branch: code tip 8a78efe "Fix the end-to-end simulation findings" (progress notes after it, latest 2ac2b34) (verified clean on the third verification; simulated OK;
  pushed to origin; presim + event_push uploading it to verified-updates). The main checkout is clean again.

## In flight (workflow run ids; scripts under the workflows/scripts folder or scratchpad, see runs.json)
| Work | Run | State | Next |
|---|---|---|---|
| Overseer rebuild (STEM-merged translator, repairs, STEM completion) | wf_92057cdf-3e2, script wf-scripts/overseer-rebuild.js | STEM completion staged (suite 6251 passed, every round unchanged, contained run 13/13 gates); STEM repair 1 closed audit 1's six gaps; audit 2 (new planted faults) found 8 more (high: 'mod'/'div' operators misread and graded as errors; a given contradicting the request not named); STEM repair 2 of at most 3 running. If not clean after repair 3 the rebuild stays staged (Daniel decides) | STEM audit; then (patched script, restart at the step boundary) straight to eval + commit "Overseer rebuild: on the STEM-merged translator, with the faulty checks corrected"; fast profile/planner skipped (SKIP_FLASH) |
| Translator fixes: argument diagnostics + 69 re-run review findings | wf_0d5b0b62-dbd (fixers done: a 72173b9, b b3c66f3, c 542d345, d 1f4f0f1, e 1e6103f) | INTEGRATED, staged in .worktrees/argdiag-integ on 8a78efe (suite green, rounds unchanged, dev corpus 44/44 named, 0/57 false alarms; hold-out 48/66 named, 9 unnamed, 9 missed, 13/68 controls flagged). verify:corpus:1 NOT ok: 25 issues (6 high: hold-out gate, 2 new false alarms ST-REF-001 x = 2.0F and INT-REQ-004 P(A u B), STEM wrong formula outside the table, unit conversion, contradictory givens); other 3 lenses of round 1 running; then repair loop (at most 5 rounds) | repairs -> clean verify -> FINAL GATE on the sealed blind hold-out-2 (run wf_86c733b1-779, corpus/holdout2, MANIFEST.sha256; see 02-PRIORITIES) -> simulate.sh -> commit "Argument diagnostics: ..." -> push -> presim + event_push |
| End-to-end fixes (8 bugs) | wf_88abd06f-53d | DONE: committed 8a78efe (suite 5667 passed; every round unchanged) | uploaded by event_push |
| Integration pre-build (protocol + kit, 5 ports incl. flash router; combinator sub-project) | wf_6d5b0a80-d5e, branch integ-prebuild | protocol + kit (3dcee98, 067da31, af10b4a; playbook clean, contract 2 medium open); combinator built c7a716e (12 done, 9 left undone); verify:combinator:1 1 medium, 3 low; repair:combinator:1 running | verify -> PREBUILD.md |
| Round-8 specialists from the connector (commit 5b60229) | wf_9cd8c3fd-6b2 | done: 16/16, pre.json updated | phase 2 skips them |
| Re-run review lenses | wf_e3e1992e-656 | done: 91 found, 88 confirmed, 69 new (9 blockers, 46 majors) | translator ones in argdiag; 2 overseer ones in phase 2 handoffs; complete list wf/rerun-lenses/handoff.json |
| Flash pilot | wf_3d0a1e9f-bb6 | done | REPORT.md: fast profile 5.6x faster, 15/37 vs 11/37 faults, 10 vs 3 false accusations; not adopted |

## Not started (round 8 will not fit this week at the current usage; next week resumes here)
- Phase 2 (round 8 pipeline): .worktrees/scripts/phase2-pipeline.js (dry-run clean). Launch with args {pre: <round8-prep/pre.json>}
  once "Fix the end-to-end simulation findings" and "Argument diagnostics: ..." are committed (it waits for the rebuild).
- After round 8: overseer + flash-router sub-projects, twofold review, feedback (inside phase 2), rounds 9-10, scaling,
  multi-agent, final report. The website/connector integration with dummy agents is the LAST task.

## Usage (weekly limit window resets Fri 23 Oct 16:00 UTC)
- 12:56: seven-day 70% used (about 3 points an hour; 85% near 18:00 UTC = final checkpoint); five-hour 1% (new window, resets 17:50).
- Two agents per workflow at a time on this machine (4 CPUs); helper workflows add parallelism (04-PROCEDURES).

## Open decisions for Daniel / owners
- Separate GitHub repositories for the overseer, combinator and flash router (sub-projects are split-ready; no repo created).
- Integration kit decisions D1 (Bruno lifts the website's Z3 deferral), D7 hosting, D14 budgets, D23 model ids, D25 the 25 s deadline.
- Z3 Prover mirror's failing upstream Actions: disable in settings (the API call was refused as CI bypass).
