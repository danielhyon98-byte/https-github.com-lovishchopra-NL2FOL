# State (refreshed at every hourly run; this copy: 2026-10-17 11:01 UTC)

## Published
- verified-updates (main repo): d872018 at 10:46 carries NEW code: source 8a78efe "Fix the end-to-end simulation findings"
  (presim OK); later hourly updates are progress notes on it. Backup branch backup/verified-updates-previous = the replaced head.
- overseer-prototype: held at 9547fc9. Candidates 6adbd64 and 87eaf86 fail the contained run (235/254 faults named and
  confirmed; 3 false alarms on genuine transfers).
- Dev branch tip 8a78efe "Fix the end-to-end simulation findings" (verified clean on the third verification; simulated OK;
  pushed to origin; presim + event_push uploading it to verified-updates). The main checkout is clean again.

## In flight (workflow run ids; scripts under the workflows/scripts folder or scratchpad, see runs.json)
| Work | Run | State | Next |
|---|---|---|---|
| Overseer rebuild (STEM-merged translator, repairs, STEM completion) | wf_92057cdf-3e2, script wf-scripts/overseer-rebuild.js | STEM completion staged (suite 6251 passed, every round unchanged, contained run 13/13 gates); restarted 07:47 onto the SKIP_FLASH script; STEM audit found 6 issues (high: SI-prefixed ohm kOhm/MOhm not read as a unit, so correct conversions are reported as errors; medium: ST-DIM-001 missed with one unit-bearing operand; planted faults missed in several classes, e.g. combinations 5C2 = 10); STEM repair 1 running (up to 3) | STEM audit; then (patched script, restart at the step boundary) straight to eval + commit "Overseer rebuild: on the STEM-merged translator, with the faulty checks corrected"; fast profile/planner skipped (SKIP_FLASH) |
| Translator fixes: argument diagnostics + 69 re-run review findings | wf_0d5b0b62-dbd (fixers a, b); helpers wf_6ce9374f-e0a (c, d) and wf_21e69e8c-34c (e) | fixers a (72173b9, 30 done), b (b3c66f3, 17), c (542d345, 37; STEM family 12/12 named, 0 false alarms), d (1f4f0f1, 23), e (1e6103f, 14) all finished; INTEGRATE running in .worktrees/argdiag-integ on the dev tip 8a78efe | integrate (worktree .worktrees/argdiag-integ) -> 4 verify lenses (corpus, invariants, adversarial, rerun) -> repairs -> commit "Argument diagnostics: ..." |
| End-to-end fixes (8 bugs) | wf_88abd06f-53d | DONE: committed 8a78efe (suite 5667 passed; every round unchanged) | uploaded by event_push |
| Integration pre-build (protocol + kit, 5 ports incl. flash router; combinator sub-project) | wf_6d5b0a80-d5e, branch integ-prebuild | protocol + kit on integ-prebuild (3dcee98, repairs 067da31 and af10b4a); round-3 verification: playbook lens clean, contract lens 2 medium open (go to PREBUILD.md for phase 2); waiting for the E2E commit to build the combinator | PREBUILD.md |
| Round-8 specialists from the connector (commit 5b60229) | wf_9cd8c3fd-6b2 | done: 16/16, pre.json updated | phase 2 skips them |
| Re-run review lenses | wf_e3e1992e-656 | done: 91 found, 88 confirmed, 69 new (9 blockers, 46 majors) | translator ones in argdiag; 2 overseer ones in phase 2 handoffs; complete list wf/rerun-lenses/handoff.json |
| Flash pilot | wf_3d0a1e9f-bb6 | done | REPORT.md: fast profile 5.6x faster, 15/37 vs 11/37 faults, 10 vs 3 false accusations; not adopted |

## Not started (round 8 will not fit this week at the current usage; next week resumes here)
- Phase 2 (round 8 pipeline): .worktrees/scripts/phase2-pipeline.js (dry-run clean). Launch with args {pre: <round8-prep/pre.json>}
  once "Fix the end-to-end simulation findings" and "Argument diagnostics: ..." are committed (it waits for the rebuild).
- After round 8: overseer + flash-router sub-projects, twofold review, feedback (inside phase 2), rounds 9-10, scaling,
  multi-agent, final report. The website/connector integration with dummy agents is the LAST task.

## Usage (weekly limit window resets Fri 23 Oct 16:00 UTC)
- 10:58: seven-day 64% used (about 3 points an hour now; weekly limit near 22:00-23:00 UTC); five-hour 61% (resets 12:50).
- Two agents per workflow at a time on this machine (4 CPUs); helper workflows add parallelism (04-PROCEDURES).

## Open decisions for Daniel / owners
- Separate GitHub repositories for the overseer, combinator and flash router (sub-projects are split-ready; no repo created).
- Integration kit decisions D1 (Bruno lifts the website's Z3 deferral), D7 hosting, D14 budgets, D23 model ids, D25 the 25 s deadline.
- Z3 Prover mirror's failing upstream Actions: disable in settings (the API call was refused as CI bypass).
