"""Build the {label: result} map that dryrun-crit/dry_resume4.mjs reads, from a workflow journal.jsonl.
Usage: python3 -I journal_to_cached.py <journal.jsonl> <out.json>"""
import json, sys
labels, out = {}, {}
for line in open(sys.argv[1], encoding="utf-8"):
    e = json.loads(line)
    if e.get("type") == "started":
        labels[e.get("key")] = e.get("label")
    elif e.get("type") == "result" and e.get("key") in labels:
        out[labels[e["key"]]] = e.get("result")
json.dump(out, open(sys.argv[2], "w", encoding="utf-8"))
print(len(out), "labels with results;", sum(1 for v in out.values() if v is None), "null")
