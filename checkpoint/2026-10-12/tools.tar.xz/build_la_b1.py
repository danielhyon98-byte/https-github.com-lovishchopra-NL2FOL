import json
import os

SRC = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/breadth/b1/tasks.json"
OUT_DIR = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/breadth/b1/specialists"
WANT = ["la-1", "la-2", "la-3"]

RESPONSES = {
    "la-1": """
The poet uses the form of an inventory to present grief as a count the speaker can continue but never close. The objects in the grandmother's kitchen absorb the loss, the list's grammar withholds the speaker's feeling, and its last item turns the count back on the speaker herself.

Counting holds grief at a distance first. The verb in "I count what is left" makes listing the speaker's response to loss, and the fragment "Four cups, one chipped" has no finite verb, so the objects are described rather than felt. The numeral fixes what remains with exactness, while "left" carries both what survives and what has departed. The same control returns in "A tin of buttons nobody will sew", where the negated future cancels the object's purpose before it can be used, so the poem locates grief in a future that cannot be completed.

Time enters the inventory through wear. The bread knife, "worn to a crescent moon", is presented as a record of use: the metaphor lifts a domestic tool towards the sky, while "by sixty years of Sunday loaves" turns repetition into the grandmother's ritual care. The wear holds her presence in shape rather than in words. The opening works similarly: the kitchen "keeps its hours" and so carries on her routine, making absence a routine that runs on without its keeper.

The list's last item turns the count on the speaker, and the third stanza, unlike the catalogue before it, moves in full sentences. The imperative "ring Ellen" is written "underneath, as if it were a chore", so a reminder to make a call becomes an unfinished task. The speaker, who announces "I am Ellen", is the person the instruction names. The simile "like a letter that arrived too late" makes her a message delivered after it could matter, which suggests a guilt the poem leaves unnamed. Verbs return in the last stanza, "I stand", "goes on keeping", "I let it", so grief moves from the objects to the speaker's own action.

The inventory therefore presents grief as an account that cannot be balanced. The kitchen keeps its hours, the speaker counts what is left, and the last line, "and I let it", accepts the clock's keeping of her time rather than closing the list.

HL Paper 1 also requires a separate analysis of the second passage; this answer covers the poem only.
""",
    "la-2": """
The writer personifies the sea, which "might give up and lie down", so that Mara's waiting is cast as the sea's surrender. Giving up and lying down are human acts, and these verbs suggest that the water shares her resignation.

The writer also uses a long sentence in which the main clause comes last: "By the time the horn sounded, flat and tired across the water, she had forgotten why she had wanted so badly to leave." The delay mirrors the ferry's lateness, and "forgotten" arrives last, so the loss of purpose surfaces only at the end of the sentence.
""",
    "la-3": """
Task — Paper 2, SL — how and why two works present a character excluded from their community

What the task wants: a comparison of how and why two works present exclusion, argued inside every paragraph.

What earned credit: accurate plot knowledge of both works, and a relevant quotation, "misery made me a fiend", linked to the creature's exclusion.

Provisional marks: A 3–4/10 · B1 2/5 · B2 1–2/5 · C 2–3/5 · D 3/5 — total 11–14/30 — provisional

Why:
- A 3–4: both plots are known, but "why" is never answered; the interpretation stops at "exclusion is bad".
- B1 2: "Shelley uses lots of imagery and emotive language here to show he is lonely" names features and asserts an effect; no word is analysed.
- B2 1–2: the works are told one after the other; "both books about people who are excluded" is asserted, not analysed.
- C 2–3: a clear introduction, two work-based paragraphs and a conclusion, but the question's "how" and "why" do not shape the structure.
- D 3: clear and mostly accurate; register slips ("lots of", "very sad", "very effective"); spell the author's name Brontë.

Biggest gap: no paragraph compares the works. Each reports plot, then names a device, so the essay describes rather than answers "how and why".

Fix it:
1. Plan three body paragraphs, each opening with one comparative point about both works, such as how each outsider is refused.
2. In each paragraph, choose one exact moment per work and explain one key word: what "misery" does to the creature's account of himself, then the matching moment in Jane's narration.
3. Replace "Both books are very effective." and "Shelley and Bronte both want to show that exclusion is bad" with claims a moment supports; the second guesses intention.

Model: "Both novels exclude their outsider through appearance or status, but Shelley's creature is refused for how he looks, while Brontë's Jane is refused for her dependence, so the two works locate the cause of exclusion in different places."

Confidence: lower; one essay, no texts or official criteria supplied, quotations unchecked.
""",
}

with open(SRC, encoding="utf-8") as fh:
    tasks = json.load(fh)
by_id = {t["task_id"]: t for t in tasks}

os.makedirs(OUT_DIR, exist_ok=True)
for tid in WANT:
    src = by_id[tid]
    out = dict(src)
    out["response_text"] = RESPONSES[tid].strip()
    path = os.path.join(OUT_DIR, tid + ".json")
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)
        fh.write("\n")
    assert all(out[k] == src[k] for k in src), tid
    print(path, len(out["response_text"].split()))
