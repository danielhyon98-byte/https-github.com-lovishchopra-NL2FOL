export const meta = {
  name: 'arena-oversee-fix-loop',
  description: 'Consolidate pending fixes, then run arena rounds (fresh isolated specialist outputs, three overseers, owner-partitioned fixers, verified commits) until every overseer judges the translator infrastructure >= 98% functional; then stress and document',
  whenToUse: 'Continuing the live-arena quality loop for the Epinoic translator infrastructure',
  phases: [
    { title: 'Consolidate', detail: 'finish the interrupted consolidation fixes (diacritics, attribution alignment, long elision, caching)' },
    { title: 'Material', detail: 'fresh tasks, isolated Haiku specialists, hub relay, translator and combinator outputs' },
    { title: 'Oversee', detail: 'results-audit, communication-fidelity and adversarial-live overseers judge the round' },
    { title: 'Fix', detail: 'owner-partitioned fixers address every blocker and major with regression tests' },
    { title: 'Verify', detail: 'whole suite and harness on every round; repair if red; commit and push' },
    { title: 'Stress', detail: 'contained stress runs on every round and the stress-marked suite' },
    { title: 'Report', detail: 'arena and stress documents updated from the recorded rounds' },
  ],
}

const REPO = '/home/user/https-github.com-lovishchopra-NL2FOL'
const S = '/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad'
const PY = S + '/z3venv/bin/python -I'
const ARENA = S + '/arena'
const WF = S + '/wf/arena'
const EN_DOCS = S + '/english_specialist/english specialist knowledge docs 1.0/'
const HI_DOCS = S + '/history_specialist/ib-specialist-knowledge-docs-3.0/history/'
// From round 7 the specialists run on the founder's v3 knowledge bases (English Specialist v1.1, History v3);
// earlier rounds keep the documents they were generated with, so their cached steps replay unchanged.
const KB3 = S + '/kb-v3/ib-specialist-knowledge-bases-v3'
const v3 = round => parseInt(String(round).replace(/^r/, ''), 10) >= 7
const enDocs = round => v3(round) ? KB3 + '/english-specialist/' : EN_DOCS
const hiDocs = round => v3(round) ? KB3 + '/history/' : HI_DOCS
const v3Note = round => v3(round) ? ' All your documents are available to you as files, so "Read <document>" means read that file. This session has no MyLib tool and no textbook library: apply your SOURCE POLICY for that case. The level, paper and syllabus are stated in the task, so answer; do not ask questions back.' : ''
const MAX_ROUNDS = 5
const ATTRIBUTION = 'Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>\nClaude-Session: https://claude.ai/code/session_016YotQwcC83EEJm8zshdxtW'

const INFRA = `INFRASTRUCTURE UNDER TEST (code, not an agent): the Epinoic translator at ${REPO} (package epinoic_logic). It transfers outputs between agents (router, subject specialists, combinator) without logic flaws or miscommunication: agents never talk to each other directly; every output crosses the hub (RouterHub -> TranslatorChannel -> subject branch with integrity packs -> engine). Read ${REPO}/README.md, src/epinoic_logic/channel/README.md, src/epinoic_logic/integrity/README.md, src/epinoic_logic/branches/README.md, src/epinoic_logic/adapters/README.md and docs/ARENA_RESULTS.md first.
Venv python: ${PY}
Tests: cd ${REPO} && ${PY} -m pytest -q   (about 25 s; stress-marked tests: -m stress)
Harness: ${PY} ${REPO}/scripts/arena/run_arena.py <round_dir>   (read its docstring; results.json records carry every finding with its message, constraints, formal checks, per-outcome ambiguity flags and grounding counts, the synthesis receipt, and a genuine_with_errors list)
Claims as transmitted: ${PY} ${REPO}/scripts/arena/list_claims.py <specialist.json> [--eligible] [--json]
Peer relay: ${PY} ${REPO}/scripts/arena/relay_peer.py <round_dir> <task_id>
Stress: ${PY} ${REPO}/scripts/arena/stress_arena.py <round_dir> [replays]
No model names or session ids in anything you write. Never weaken or delete a test.`

// ------------------------------------------------------------------ schemas
const BUG = { type: 'object', properties: {
  severity: { type: 'string', enum: ['blocker', 'major', 'minor'] }, file: { type: 'string' }, summary: { type: 'string' },
  repro: { type: 'string' }, expected: { type: 'string' }, actual: { type: 'string' }, fix: { type: 'string' } },
  required: ['severity', 'file', 'summary', 'expected', 'actual', 'fix'] }
const OVERSEER_SCHEMA = { type: 'object', properties: {
  infrastructure_functional_rate: { type: 'number' }, verdict_at_least_98: { type: 'boolean' },
  previous_bugs_fixed: { type: 'integer' }, previous_bugs_open: { type: 'array', items: { type: 'string' } },
  extra_transmissions_run: { type: 'integer' }, bugs: { type: 'array', items: BUG } },
  required: ['infrastructure_functional_rate', 'verdict_at_least_98', 'previous_bugs_fixed', 'previous_bugs_open', 'extra_transmissions_run', 'bugs'] }
const FIX_SCHEMA = { type: 'object', properties: {
  fixed: { type: 'array', items: { type: 'object', properties: { bug: { type: 'string' }, change: { type: 'string' }, test: { type: 'string' } }, required: ['bug', 'change'] } },
  left_undone: { type: 'array', items: { type: 'string' } }, suite_tail: { type: 'string' }, harness: { type: 'string' } },
  required: ['fixed', 'left_undone', 'suite_tail'] }
const VERIFY_SCHEMA = { type: 'object', properties: {
  suite_passed: { type: 'boolean' }, suite_tail: { type: 'string' }, failing_tests: { type: 'array', items: { type: 'string' } },
  harness: { type: 'array', items: { type: 'object', properties: {
    round: { type: 'string' }, transmissions: { type: 'integer' }, functional: { type: 'integer' }, rate: { type: 'number' },
    genuine_with_errors: { type: 'array', items: { type: 'string' } }, failures: { type: 'array', items: { type: 'string' } } },
    required: ['round', 'transmissions', 'functional', 'rate'] } } },
  required: ['suite_passed', 'suite_tail', 'harness'] }
const COMMIT_SCHEMA = { type: 'object', properties: { committed: { type: 'boolean' }, pushed: { type: 'boolean' }, sha: { type: 'string' }, output: { type: 'string' } }, required: ['committed', 'pushed'] }
const DESIGN_SCHEMA = { type: 'object', properties: {
  tasks: { type: 'array', items: { type: 'object', properties: { task_id: { type: 'string' }, agent_id: { type: 'string' }, subject: { type: 'string' }, peer_of: { type: 'string' }, group: { type: 'string' } }, required: ['task_id', 'agent_id', 'subject'] } },
  topics: { type: 'array', items: { type: 'string' } } }, required: ['tasks', 'topics'] }
const RELAY_SCHEMA = { type: 'object', properties: { delivered: { type: 'boolean' }, relay_status: { type: 'string' }, relay_codes: { type: 'array', items: { type: 'string' } }, peer_receipt_codes: { type: 'array', items: { type: 'string' } }, claims: { type: 'integer' }, output: { type: 'string' } }, required: ['delivered'] }
const STRESS_SCHEMA = { type: 'object', properties: {
  runs: { type: 'array', items: { type: 'object', properties: { round: { type: 'string' }, replays: { type: 'integer' }, sequential: { type: 'string' }, threads16: { type: 'string' }, service: { type: 'string' }, crashes: { type: 'integer' } }, required: ['round', 'crashes'] } },
  stress_suite_tail: { type: 'string' }, anomalies: { type: 'array', items: { type: 'string' } } },
  required: ['runs', 'stress_suite_tail', 'anomalies'] }

// ------------------------------------------------------------------ owners (disjoint paths for parallel fixers)
const OWNERS = {
  channel: { paths: ['src/epinoic_logic/channel/**', 'src/epinoic_logic/integrity/**', 'src/epinoic_logic/translate/**', 'src/epinoic_logic/adapters/sources.py', 'src/epinoic_logic/engine/**', 'src/epinoic_logic/service/**', 'src/epinoic_logic/ir/**', 'tests/channel/**', 'tests/integrity/**', 'tests/translate/**', 'tests/engine/**', 'tests/service/**', 'tests/e2e/**', 'tests/stress/**'],
    keys: ['channel/', 'integrity/', 'translate/', 'adapters/sources.py', 'sources.py', 'engine/', 'service/', 'ir/', 'bus.py', 'ledger.py', 'grounding.py', 'cross_check', 'handoff.py', 'request_parser'] },
  history: { paths: ['src/epinoic_logic/branches/quant.py', 'src/epinoic_logic/branches/packs.py', 'src/epinoic_logic/branches/hub.py', 'src/epinoic_logic/branches/base.py', 'src/epinoic_logic/branches/README.md', 'src/epinoic_logic/adapters/history_specialist/**', 'tests/branches/**', 'tests/adapters_history/**'],
    keys: ['quant.py', 'packs.py', 'hub.py', 'branches/base.py', 'branches/README', 'history_specialist/', 'chronology.py'] },
  english: { paths: ['src/epinoic_logic/adapters/markdown.py', 'src/epinoic_logic/adapters/english_specialist/**', 'src/epinoic_logic/adapters/base.py', 'src/epinoic_logic/adapters/generic_structured.py', 'src/epinoic_logic/adapters/fixtures_multi_subject.py', 'src/epinoic_logic/adapters/README.md', 'src/epinoic_logic/branches/generic_parser.py', 'src/epinoic_logic/branches/registry.py', 'tests/adapters/**'],
    keys: ['markdown.py', 'english_specialist/', 'generic_parser.py', 'generic_structured', 'registry.py', 'adapters/base.py', 'adapters/README', 'fixtures_multi_subject'] },
  harness: { paths: ['scripts/arena/**', 'docs/**', 'README.md (repository root only)'],
    keys: ['scripts/arena', 'run_arena', 'stress_arena', 'list_claims', 'relay_peer', 'docs/', 'ARENA_RESULTS', 'STRESS_RESULTS'] },
}
function ownerOf(bug) {
  const f = String(bug.file || '') + ' ' + String(bug.fix || '')
  let best = null, bi = Infinity
  for (const [k, o] of Object.entries(OWNERS)) for (const key of o.keys) { const i = f.indexOf(key); if (i >= 0 && i < bi) { bi = i; best = k } }
  return best || 'channel'
}

// ------------------------------------------------------------------ prompt builders
function verifyPrompt(rounds) {
  return `${INFRA}
YOUR TASK: verification only; do NOT modify any file.
1. cd ${REPO} && ${PY} -m pytest -q -p no:cacheprovider 2>&1 | tail -15 . suite_passed is true only when the tail shows 0 failed and 0 errors. List any failing test ids.
2. For each round in ${JSON.stringify(rounds)}: run ${PY} ${REPO}/scripts/arena/run_arena.py ${ARENA}/<round> (it rewrites results.json and summary.md there), then read ${ARENA}/<round>/results.json and report transmissions, functional, functional_rate (as rate), genuine_with_errors (each as "file: codes"), and failures (each as "file [variant]: status codes or error"). If a round directory has no specialists/ directory, skip it.
Return the structured result.`
}
function commitPrompt(title, body) {
  return `In ${REPO} on branch claude/z3-verification-engine-plan-nk3luq: run git status --short; if nothing changed return committed=false, pushed=false. Otherwise git add -A and commit with: git -c user.name=Claude -c user.email=noreply@anthropic.com commit -q -F <a message file you write in ${S}/commitmsg.txt> where the message is exactly:
---
${title}

${body}

${ATTRIBUTION}
---
(without the --- lines). Then git push -u origin claude/z3-verification-engine-plan-nk3luq ; only if the push fails because of a network error retry up to 4 times waiting 2, 4, 8, 16 seconds. Never force-push, never rewrite history, never change any file content. Return committed, pushed, the new commit sha and the push output tail.`
}
function repairPrompt(v) {
  return `${INFRA}
The whole suite is red after parallel fixes. Tail:
${v ? v.suite_tail : '(verification unavailable)'}
Failing tests: ${v && v.failing_tests ? v.failing_tests.join(', ') : 'unknown'}
YOU OWN all of src/ and tests/ for this repair. Make the suite green by fixing the code (or a test only when it pins a rule an overseer report in ${ARENA}/*/overseers/*.json explicitly reversed: then rewrite it to assert the new rule more strictly, and say so). Never weaken or delete a test to pass. Keep the harness rates from dropping: run ${PY} ${REPO}/scripts/arena/run_arena.py on ${ARENA}/r3 and the latest round afterwards. Do NOT commit or push. Return what you changed and the suite tail.`
}
function overseerPrompt(lens, round, prev, pre) {
  const own = `${WF}/${round}/${lens.key}`
  return `${INFRA}
You are an independent OVERSEER (lens ${lens.key}) for arena round ${round}.
ROUND MATERIAL (real outputs of isolated specialist agents configured only from the English and History knowledge documents): ${ARENA}/${round}/ with tasks.json, specialists/*.json (including a peer exchange: one specialist's delivered report forwarded by the router to the other, relayed/<task>.json, and the second specialist's answer quoting it), translations/*.json (translator-provider output for eligible claims), syntheses/*.json (a dummy combinator's syntheses), results.json and summary.md (harness just run: ${pre ? pre.transmissions + ' transmissions, ' + pre.functional + ' functional; genuine_with_errors ' + JSON.stringify(pre.genuine_with_errors || []) : 'see results.json'}). Earlier rounds: ${ARENA}/r1, r1-adv, r2, r3${round !== 'r4' ? ', r4 ...' : ''}.
FIRST: re-check the previous round. Your lens's previous report is ${ARENA}/${prev}/overseers/${lens.key}.json and your previous probes and variants are under ${WF}/${prev}/${lens.key}/ (copy what you re-run into your own directory; never edit old directories). State, bug by bug, which of the previous report's bugs (and its previous_bugs_open / round2_bugs_open entries) are fixed in the current code; count them in previous_bugs_fixed and list the rest in previous_bugs_open.
THEN: ${lens.task}
Work only in your own directory ${own}/ (mkdir -p it); do not edit anything under ${REPO} or under ${ARENA}/${round}/ except the report file below.
The infrastructure must transfer outputs between agents without logic flaws or miscommunication: what the router receives must be what the specialist said (roles, materiality, quotations, figures, dates), every injected fault must be named on the receipt with the right code and severity, every stated arithmetic and chronology relation must be decided by the engine or reported undecided, a self-certification must never pass as a claim, a peer's report must reach the other specialist exactly as delivered and its quotations of the peer must be checked, a synthesis must not change what its sources said, and nothing may raise out of the hub.
A bug is a defect of the infrastructure (code, harness, docs), not of the specialist agents' prose; a specialist's or combinator's error that the infrastructure fails to name IS an infrastructure bug; a finding the infrastructure raises correctly against a genuine specialist or combinator error is NOT a bug. Judge infrastructure_functional_rate over every transmission you examined (this round's records and your own runs), counting a transmission functional only when its receipt is right and its delivered payload faithful; verdict_at_least_98 is true only when that rate is at least 0.98 and no blocker or major is open.
BEFORE RETURNING: write your report, exactly the JSON you return, to ${ARENA}/${round}/overseers/${lens.key}.json (mkdir -p the directory).`
}
const LENSES = [
  { key: 'results-audit', task: 'Audit every record of results.json against its inputs: is each receipt status right for its input, is every injected fault named by the expected code, are claim outcomes consistent with the translations and their diagnostics (an ENTAILED verdict must rest on the specialist\'s own statements and the record must say how many premises are ungrounded; an AMBIGUOUS one must say why), are the constraint and formal checks measured correctly (word counts, paragraph blocks, every arithmetic and chronology relation in the History answers, recomputed by you), do the synthesis ledger findings match what the combinator carried, merged or dropped, and does the functional definition hide anything (judge every genuine_with_errors entry: correct finding on a genuine fault, or false error). Probe at least ten further sentences per History answer shape (figures with units and dates between them, ranges, circa, rates, fractions, folds, same-month and day-only dates) through the hub.' },
  { key: 'communication-fidelity', task: 'Compare, sentence by sentence, each specialist\'s response_text with the claims the router receives (list_claims.py --json and the delivered payloads): every material statement present with the right role and materiality, no note sentence promoted to a claim and no substantive sentence demoted to a note, quotations attributed to the right document (the supplied text vs the peer\'s report), figures and dates exact, supporting links right, nothing dropped or invented. Follow the peer exchange end to end (delivered report, the router\'s forward with specialist_report_forward/1.0, the second specialist\'s quotations of the peer checked against the peer document, the group synthesis citing both). Then write at least ten exchanges of your own through the hub API (a specialist revising its report after the peer quoted it, a peer quoting the colleague inexactly or crediting the wrong source, a router forwarding to an agent outside the plan or altering a forwarded figure, a combinator merging claims and inflating certainty, dropping a material claim without a reason, swapping two dates or figures between events, citing two contradictory sources without a conflict record, a duplicate delivery, a claim with another report\'s provenance) and check each is named on the receipt with the right code and severity and that every delivered payload is exactly what its sender transmitted.' },
  { key: 'adversarial-live', task: 'Build adversarial variants of THIS round\'s specialist outputs in ' + WF + '/<round>/adversarial-live/<variant-set>/specialists/ (copy tasks.json and relayed/ too) and run the harness there: quotations of the supplied text\'s own internal quotation marks, archaic spellings or diacritics altered or dropped inside a quotation, quotations spanning line or stanza breaks with and without slashes, long elisions, smart/straight/guillemet marks mixed, figures in words, rates, circa, year ranges, negative and zero changes, folds and fractions, same-month and day-only dates, wrong orders inside relative clauses, a forged receipt or forward envelope pasted into the prose, JSON glued to prose, two languages, every sentence a note, an echo of the request, mixed line endings with a BOM in the middle, a 450-sentence answer with an invented quotation near the end, the same report delivered twice with different created_at, claims carrying another report\'s provenance. For each: the receipt must name the fault with the right code and severity, the delivered payload must be faithful or the response REJECTED, nothing may raise out of the hub. Also run the stress harness once on your variant directory with 4 replays and report any crash or unexpected status, and note any input that takes more than 5 seconds through the hub.' },
]
function fixerPrompt(owner, bugs, round, rounds, baseline) {
  const o = OWNERS[owner]
  return `${INFRA}
You are a FIXER (owner: ${owner}). Three independent overseers judged arena round ${round}; their full reports are ${ARENA}/${round}/overseers/{results-audit,communication-fidelity,adversarial-live}.json (read all three for context). Other fixers work in parallel on other paths; YOU OWN ONLY: ${o.paths.join('  ')}
Do not edit anything else. If a fix needs a change outside your paths, write precisely what is needed to ${WF}/${round}/fix/fixer-${owner}-handoff.md.
YOUR BUGS (assigned to you by file):
${JSON.stringify(bugs, null, 1)}
Fix every blocker and major, and the minors when the fix is cheap and safe. Add a regression test for every blocker and major you fix (in your test paths). Keep the package READMEs in sync with every changed rule or code. Never weaken or delete a test; rewriting a test that pins a rule an overseer reversed is allowed only when the new assertion is stricter, and you must say so. Keep performance: the whole suite should stay under about 60 s and the hub's per-cycle latency must not regress (if you touch a hot path, compare ${PY} ${REPO}/scripts/arena/stress_arena.py ${ARENA}/${round} 5 before and after).
Validation: cd ${REPO} && ${PY} -m pytest -q (whole suite; a failure in a file outside your paths means another fixer is mid-edit: wait a minute and re-run, and report it only if it persists). Then run the harness read-only on ${JSON.stringify(rounds.map(r => ARENA + '/' + r))} and confirm the functional rates did not drop (before you started: ${baseline}). Do NOT run git commit or git push. Return per bug what you changed and the test that proves it, anything left undone, the suite tail and the harness summary.`
}
function englishPrompt(round, ids) {
  return `You are the English Specialist, an IB tutoring agent. Your ENTIRE behaviour is defined by the knowledge documents in "${enDocs(round)}": read master_prompt.txt first and then every .md file there, in full, and follow them exactly (their non-negotiables, procedure, structures, style and examples).${v3Note(round)} You are isolated: do not read any other files except ${ARENA}/${round}/tasks.json, and do not look at any verification code.
TASKS: read ${ARENA}/${round}/tasks.json and take ONLY the tasks whose "task_id" is one of ${JSON.stringify(ids)}. For each, produce the deliverable the task asks for, exactly as you would for a student, using only the supplied_texts given in the task (for quotations) and your knowledge documents; label anything from memory as your documents require. Quote exactly from the supplied text, character for character, keeping its original spellings and punctuation.
OUTPUT: for each task write ${ARENA}/${round}/specialists/<task_id>.json (create directories) containing ALL the task's fields unchanged (including "group" where present) plus "response_text": your deliverable as plain prose (no headings, no labels, no markdown, no commentary about the method). Return the list of files written and the word count of each response.`
}
function historyPrompt(round, ids) {
  return `You are the History Specialist, an IB tutoring agent. Your ENTIRE behaviour is defined by the knowledge documents in "${hiDocs(round)}": read master_prompt.txt first and then every .md file there, in full, and follow them exactly (their non-negotiables, procedure, structures, style and examples).${v3Note(round)} You are isolated: do not read any other files except ${ARENA}/${round}/tasks.json, and do not look at any verification code.
TASKS: read ${ARENA}/${round}/tasks.json and take ONLY the tasks whose "task_id" is one of ${JSON.stringify(ids)}. For each, produce the deliverable the task asks for, exactly as you would for a student, using only your knowledge documents (there are no supplied texts unless a task gives one); label dates and figures from memory as your documents require. Run your Claim-Evidence-Analysis-Judgement-Link operation; give dated, exact evidence and a judgement by a criterion. A task written for a literature student is a self-contained paragraph of plain prose.
OUTPUT: for each task write ${ARENA}/${round}/specialists/<task_id>.json (create directories) containing ALL the task's fields unchanged (including "group" where present) plus "response_text": your deliverable as plain prose (no headings, no labels, no markdown, no commentary about the method). Return the list of files written and the word count of each response.`
}
function dependentPrompt(round, dep, peerTask) {
  const english = dep.agent_id.startsWith('english')
  const docs = english ? enDocs(round) : hiDocs(round)
  const role = english ? 'English Specialist' : 'History Specialist'
  const peerRole = english ? 'History specialist' : 'English specialist'
  const own = english
    ? 'quote exactly (character for character) from the text in the task\'s supplied_texts, and where you draw on the History specialist\'s paragraph quote it exactly from "original_response" and attribute it to the History specialist. Do not add historical facts of your own; use only what the History specialist transmitted and the supplied text.'
    : 'where you draw on the English specialist\'s paragraph quote it exactly (character for character) from "original_response" and attribute it to the English specialist; give dated evidence from your own knowledge, labelled from memory as your method requires; do not attribute to the English specialist anything it did not write.'
  return `You are the ${role}, an IB tutoring agent. Your ENTIRE behaviour is defined by the knowledge documents in "${docs}": read master_prompt.txt first and then every .md file there, in full, and follow them exactly.${v3Note(round)} You are isolated: the ONLY other files you may read are ${ARENA}/${round}/tasks.json and ${ARENA}/${round}/relayed/${dep.task_id}.json. Do not look at any verification code or any other file.
TASK: take ONLY the task whose "task_id" is "${dep.task_id}". The ${peerRole}'s paragraph (task ${peerTask}) has been delivered to you through the hub: relayed/${dep.task_id}.json holds, under "payload", its report exactly as transmitted ("original_response" is its paragraph; "claims" are the statements the hub extracted from it; "peer_receipt" lists what the hub found about it). It is supplied to you as the document "peer:${peerTask}". Produce the deliverable the task asks for, exactly as you would for a student: ${own}
OUTPUT: write ${ARENA}/${round}/specialists/${dep.task_id}.json containing ALL the task's fields unchanged (task_id, group, peer_of, subject, agent_id, task_type, question, supplied_texts) plus "response_text": your deliverable as plain prose (no headings, no labels, no markdown, no commentary about the method). Return the file written, its word count, and the exact phrases you quoted from the ${peerRole}'s paragraph.`
}
function translatorPrompt(round, dep, peerTask) {
  return `You are acting as the TRANSLATION PROVIDER component of a verification infrastructure (a stand-in for a model API call; you are not an agent in the tutoring system). Read the system instructions at ${REPO}/src/epinoic_logic/translate/prompts/translate_v1.md in full and the IR schema docstring at ${REPO}/src/epinoic_logic/ir/schema.py.
For each file in ${ARENA}/${round}/specialists/*.json run ${PY} ${REPO}/scripts/arena/list_claims.py <file> --eligible --json to get the eligible claims and the report_id/request_id. For EACH eligible claim produce the JSON object the instructions specify ({"problem": <IR 1.0 Problem with request_id and claim_id copied exactly from the listing>, "interpretation": {...}, "ambiguous": bool, "unsupported_reason": null|string}); encode atomic propositions grounded in the claim and its supporting claims (quotation groundings must carry the exact excerpt and document_id of a supplied text; the peer task ${dep.task_id} may quote the document peer:${peerTask}, whose text is "original_response" under "payload" in ${ARENA}/${round}/relayed/${dep.task_id}.json; specialist inferences as separate implication premises with kind specialist_inference; figures and dates from memory as general_knowledge). Keep the meaning; do not invent premises. Write ${ARENA}/${round}/translations/<task_id>.json as {"report_id": ..., "claims": {<claim_id>: <that object>, ...}}.
Validate each problem: cd ${REPO} && ${PY} -c "import json,sys; from epinoic_logic.engine import parse_and_validate; p,o=parse_and_validate(json.dumps(json.load(open(sys.argv[1]))['claims'][sys.argv[2]]['problem'])); print(o.ok, [d.model_dump() for d in o.diagnostics][:3])" <file> <claim_id> and fix your JSON until ok is True. Do not modify any file under ${REPO}. Return the files written, the number of problems per file and how many validated.`
}
function combinatorPrompt(round) {
  return `You are a DUMMY COMBINATOR agent in an IB tutoring system: you receive specialists' reports only in the form the infrastructure transmits them and write a short synthesis for the router. For each file in ${ARENA}/${round}/specialists/*.json run ${PY} ${REPO}/scripts/arena/list_claims.py <file> --json to see the claims the infrastructure extracted (claim ids, roles, materiality, texts). Then write ${ARENA}/${round}/syntheses/<task_id>.json as JSON: {"report_id": <from list_claims>, "claims": [ {"text": <one synthesized sentence for the router>, "source_claim_ids": [<ids you drew on>], "certainty": <"established"|"probable"|"possible", never stronger than the weakest source claim>, "transformation": <"carried"|"paraphrased"|"merged"|"narrowed">} x 2-4 ], "dropped": [ {"source_claim_ids": [<ids of material claims you left out>], "reason": <why>} ]}. Be faithful: do not add content the specialist did not assert, keep every figure and date exactly as the source states it and attached to the same event, do not merge claims that contradict each other, and never carry a note sentence (a from-memory label, a self-certification, a task-setting note) as a claim. Do not modify any file under ${REPO}. Return the files written.`
}
function designPrompt(round, k, firstAgent) {
  const a = 7 + 2 * k, b = 8 + 2 * k, p = 3 + k
  const englishFirst = firstAgent === 'english'
  const pair = englishFirst
    ? `group "p${p}": FIRST "en-p${p}" (agent english-specialist, subject "English A: Literature", task_type analytical_paragraph, one supplied text, no peer_of): one analytical paragraph of at most 250 words that will be passed to the History specialist as context; SECOND "hi-p${p}" (agent history-specialist, subject "History", task_type short_answer, "peer_of": "en-p${p}", supplied_texts []): says it has received the English specialist's paragraph through the hub as the document peer:en-p${p}, asks for one paragraph of at most 220 words outlining for a literature student the historical context of what the English specialist identifies, with dated evidence labelled from memory as the method requires, quoting the English specialist exactly where it draws on it and attributing it to the English specialist.`
    : `group "p${p}": FIRST "hi-p${p}" (agent history-specialist, subject "History", task_type short_answer, supplied_texts [], no peer_of): one paragraph of at most 200 words outlining for a literature student the historical context of a supplied literary text named in the question, with dated evidence labelled from memory; SECOND "en-p${p}" (agent english-specialist, subject "English A: Literature", task_type analytical_paragraph, "peer_of": "hi-p${p}", supplied_texts [that literary text]): says it has received the History specialist's context paragraph through the hub as the document peer:hi-p${p}, asks for one analytical paragraph of at most 300 words reading the text against that context, quoting the text exactly and quoting the History specialist exactly where it draws on it, attributed to the History specialist.`
  return `You design round ${round} of an arena that tests a translator infrastructure with real outputs of IB specialist agents. Read ${ARENA}/r4/tasks.json (and r2, r3 tasks.json) for the exact JSON shape, and for the texts and topics already used: do not reuse any text, author or historical topic from earlier rounds.
Write ${ARENA}/${round}/tasks.json (mkdir -p ${ARENA}/${round}/specialists ${ARENA}/${round}/translations ${ARENA}/${round}/syntheses ${ARENA}/${round}/relayed) with exactly six tasks:
- "en-t${a}" and "en-t${b}": subject "English A: Literature", agent english-specialist, task_type analytical_paragraph, each with one supplied public-domain text (document_id "doc-<short>", title, author, text): a poem or prose extract of 12 to 40 lines typed exactly with its original spellings and punctuation (one of them should contain internal quotation marks or dialogue, the other archaic spellings, apostrophe elisions or verse line breaks); a question naming a technique and asking for quotations, with a word limit ("no more than 300 words" or "about 250 words").
- "hi-t${a}": subject History, agent history-specialist, task_type essay, "To what extent ... ? Write one body paragraph only, following your method, in no more than 350 words, with dated and quantified evidence." on a new topic rich in dates, figures and changes over time.
- "hi-t${b}": subject History, agent history-specialist, task_type short_answer, "Outline, with dated and quantified evidence, ... Write no more than 200 words and give a judgement on ..." on another new topic with figures.
- ${pair}
Supplied texts must be typed in full exactly as you give them (they are the reference the infrastructure checks quotations against).${v3(round) ? ' The specialists now run on their v3 knowledge bases (' + KB3 + '/english-specialist/ and ' + KB3 + '/history/; skim each master_prompt.txt and the History content.md syllabus map): every History question names the level (SL or HL), the paper and the syllabus (the previous syllabus, sessions to November 2027, or the new syllabus, first exams May 2028) and stays on that syllabus; every English task names the course.' : ''} Return the task list (task_id, agent_id, subject, peer_of, group) and the topics used.`
}

// ------------------------------------------------------------------ helpers
function harnessLine(v) {
  if (!v || !v.harness) return 'Harness: verification unavailable.'
  return 'Harness after the change: ' + v.harness.map(h => `${h.round} ${h.functional}/${h.transmissions}`).join(', ') + '. Suite: ' + String(v.suite_tail || '').split('\n').filter(Boolean).slice(-1)[0]
}
async function verifyAndCommit(rounds, title, body, label) {
  let v = await agent(verifyPrompt(rounds), { label: `verify:${label}`, phase: 'Verify', schema: VERIFY_SCHEMA, effort: 'medium' })
  let repairs = 0
  while (v && !v.suite_passed && repairs < 2) {
    repairs++
    log(`suite red after ${label}; repair ${repairs}`)
    await agent(repairPrompt(v), { label: `repair:${label}:${repairs}`, phase: 'Verify', schema: FIX_SCHEMA })
    v = await agent(verifyPrompt(rounds), { label: `verify:${label}:after-repair-${repairs}`, phase: 'Verify', schema: VERIFY_SCHEMA, effort: 'medium' })
  }
  const green = !!(v && v.suite_passed)
  const t = green ? title : `WIP: ${title} (suite not green; see body)`
  const c = await agent(commitPrompt(t, body + '\n\n' + harnessLine(v) + (green ? '' : '\nSuite tail: ' + (v ? v.suite_tail : 'unavailable'))), { label: `commit:${label}`, phase: 'Verify', schema: COMMIT_SCHEMA, effort: 'low' })
  log(`${label}: suite ${green ? 'green' : 'RED'}; ${harnessLine(v)}; commit ${c && c.committed ? c.sha : 'none'}`)
  return { verify: v, green, commit: c }
}
function baselineOf(v) { return v && v.harness ? v.harness.map(h => `${h.round} ${h.functional}/${h.transmissions}`).join(', ') : 'unknown' }
function sev(bugs) { const c = { blocker: 0, major: 0, minor: 0 }; for (const b of bugs) c[b.severity] = (c[b.severity] || 0) + 1; return c }

// ================================================================== Consolidate
phase('Consolidate')
const allRounds = ['r1', 'r1-adv', 'r2', 'r3', 'r4']
const consolidation = await agent(`${INFRA}
You are a FIXER finishing an interrupted consolidation pass; you may edit any file under src/ and tests/ (not scripts/ or docs/). A previous attempt already made sentence splitting and chronology tokenizing linear (suite 140 s -> 23 s, committed). Read the round-3 overseer reports ${ARENA}/r3/overseers/*.json and the hand-off notes ${WF}/r3/fix/*.md.
Tasks:
 1. PERFORMANCE (finish): cache each supplied text's normalised forms and index maps keyed by (document_id, sha256 of the text) with a bounded LRU in translate/grounding.py and adapters/sources.py, and never locate the same excerpt in the same document twice within one parse or check. No change in any finding. Measure ${PY} ${REPO}/scripts/arena/stress_arena.py ${ARENA}/r3 10 before and after and report sequential p50/p95.
 2. DIACRITICS: a quotation that differs from the supplied text only in diacritics ('Bayardo San Román' vs 'Bayardo San Roman') is reported not found (INT-REQ-003 error + ES-SRC-001). Add a normalisation tier folding combining diacritics (NFKD, strip Mn) on both sides with the offset map kept; report such a match as a form difference (located, not ok, detail 'differs in diacritics') so the channel gives INT-REQ-010 and the packs a warning. Test on ${ARENA}/r1-adv/specialists/en-t2-diacritic-ellipsis.json (claim p4-q02) and a unit test.
 3. ATTRIBUTION CONSISTENCY: the History parser records NO SourceRef for an unlocated quotation whose sentence names no text (assumption 'quotation with no supplied text to check it against: ...'), and CorePack reports it as CORE-SRC-003. Align the English parser (_attribute) and branches/generic_parser.py to the same rule (located text wins; a named text is credited whether or not it holds the words; otherwise no SourceRef and the assumption), make sure CORE-SRC-003 covers the English branch, keep ES-SRC-008 / CORE-SRC-005 for named-but-wrong credits. Rewrite tests that pinned the old behaviour so they assert the new rule more strictly (say which).
 4. LONG ELISION on the generic branch: adapters/generic_structured.py source_findings must map check_excerpt's found_long_elision (and any form-difference status) to the inexact warning code, never the error branch; test.
 5. Anything else listed as undone in the hand-off notes that lies in src/ or tests/, if cheap and safe.
Validation: whole suite green; harness read-only on ${JSON.stringify(allRounds.map(r => ARENA + '/' + r))} with no rate drop (r4 41/41, r3 41/41, r2 41/41, r1 26/26, r1-adv 150/151 before you started; the one r1-adv failure is the empty response, correctly REJECTED). Do NOT commit or push. Return per task what you changed and the test that proves it, before/after timings, the suite tail and the harness summary.`, { label: 'consolidate', phase: 'Consolidate', schema: FIX_SCHEMA })
const consolidated = await verifyAndCommit(allRounds, 'Consolidate attribution, diacritics and long-elision handling across branches; cache normalised documents',
  'The English and generic parsers follow the History branch\'s attribution rule (an unlocated quotation naming no text carries no source reference and is reported as unverifiable); quotations differing only in diacritics are located as form differences; the generic branch reports long elisions as warnings; normalised supplied texts are cached so an excerpt is located once per document.\n\n' + (consolidation ? consolidation.fixed.map(f => '- ' + f.bug + ': ' + f.change).join('\n').slice(0, 3000) : 'Consolidation agent returned no report.'), 'consolidate')

// ================================================================== rounds
const rounds = []
let prev = 'r3'
let passed = false
let lastVerify = consolidated.verify
for (let k = 0; k < MAX_ROUNDS; k++) {
  const round = 'r' + (4 + k)
  if (k > 0) {
    phase('Material')
    const firstAgent = (k % 2 === 1) ? 'english' : 'history'
    const design = await agent(designPrompt(round, k, firstAgent), { label: `design:${round}`, phase: 'Material', schema: DESIGN_SCHEMA })
    if (!design || !design.tasks || design.tasks.length < 6) { log(`round ${round}: task design failed; stopping`); break }
    const dep = design.tasks.find(t => t.peer_of)
    if (!dep) { log(`round ${round}: no peer task in the design; stopping`); break }
    const enIds = design.tasks.filter(t => t.agent_id.startsWith('english') && t.task_id !== dep.task_id).map(t => t.task_id)
    const hiIds = design.tasks.filter(t => t.agent_id.startsWith('history') && t.task_id !== dep.task_id).map(t => t.task_id)
    await parallel([
      () => agent(englishPrompt(round, enIds), { label: `specialist:english:${round}`, phase: 'Material', model: 'haiku' }),
      () => agent(historyPrompt(round, hiIds), { label: `specialist:history:${round}`, phase: 'Material', model: 'haiku' }),
    ])
    const relay = await agent(`Run: cd ${REPO} && ${PY} scripts/arena/relay_peer.py ${ARENA}/${round} ${dep.task_id} . Then read ${ARENA}/${round}/relayed/${dep.task_id}.json and return delivered, the relay status and codes, the peer receipt codes and the number of claims delivered. Do not modify any file under ${REPO}.`, { label: `relay:${round}`, phase: 'Material', schema: RELAY_SCHEMA, effort: 'low' })
    if (!relay || !relay.delivered) { log(`round ${round}: the peer report was not delivered (${relay ? relay.output : 'no result'}); stopping`); break }
    await agent(dependentPrompt(round, dep, dep.peer_of), { label: `specialist:peer:${round}`, phase: 'Material', model: 'haiku' })
    await parallel([
      () => agent(translatorPrompt(round, dep, dep.peer_of), { label: `translator:${round}`, phase: 'Material', model: 'haiku' }),
      () => agent(combinatorPrompt(round), { label: `combinator:${round}`, phase: 'Material', model: 'haiku' }),
    ])
    allRounds.push(round)
    log(`round ${round}: material ready (${design.topics.join('; ')})`)
  }
  phase('Oversee')
  const pre = await agent(verifyPrompt([round]), { label: `harness:${round}`, phase: 'Oversee', schema: VERIFY_SCHEMA, effort: 'medium' })
  const preRound = pre && pre.harness ? pre.harness.find(h => h.round === round) : null
  const reports = await parallel(LENSES.map(l => () => agent(overseerPrompt(l, round, prev, preRound), { label: `overseer:${l.key}:${round}`, phase: 'Oversee', schema: OVERSEER_SCHEMA })))
  const named = LENSES.map((l, i) => ({ lens: l.key, report: reports[i] }))
  const present = named.filter(n => n.report)
  const summary = { round, harness: preRound, overseers: named.map(n => n.report ? { lens: n.lens, rate: n.report.infrastructure_functional_rate, verdict: n.report.verdict_at_least_98, previous_fixed: n.report.previous_bugs_fixed, previous_open: n.report.previous_bugs_open.length, bugs: sev(n.report.bugs) } : { lens: n.lens, missing: true }) }
  log(`round ${round}: ` + summary.overseers.map(o => o.missing ? `${o.lens} missing` : `${o.lens} ${o.rate} (${o.bugs.blocker}B/${o.bugs.major}M/${o.bugs.minor}m)`).join(' | '))
  rounds.push(summary)
  if (present.length === 0) { log('no overseer report arrived (API errors?); stopping the loop'); break }
  if (present.length === 3 && present.every(n => n.report.infrastructure_functional_rate >= 0.98 && n.report.verdict_at_least_98)) { passed = true; log(`round ${round}: all three overseers judge the infrastructure at least 98% functional`); break }
  phase('Fix')
  const bugs = present.flatMap(n => n.report.bugs.map(b => ({ ...b, lens: n.lens })))
  const byOwner = {}
  for (const b of bugs) { const o = ownerOf(b); (byOwner[o] = byOwner[o] || []).push(b) }
  log(`round ${round}: ${bugs.length} bugs -> ` + Object.entries(byOwner).map(([o, l]) => `${o} ${l.length}`).join(', '))
  const baseline = baselineOf(lastVerify)
  const fixes = await parallel(Object.entries(byOwner).map(([o, list]) => () => agent(fixerPrompt(o, list, round, allRounds, baseline), { label: `fix:${o}:${round}`, phase: 'Fix', schema: FIX_SCHEMA })))
  const fixedLines = fixes.filter(Boolean).flatMap(f => f.fixed.map(x => '- ' + x.bug.slice(0, 160) + ': ' + x.change.slice(0, 240)))
  const undone = fixes.filter(Boolean).flatMap(f => f.left_undone)
  summary.fixed = fixedLines.length
  summary.left_undone = undone
  const vc = await verifyAndCommit(allRounds, `Fix the ${round} arena overseer findings`,
    `Three overseers judged round ${round}: ` + summary.overseers.map(o => o.missing ? `${o.lens} missing` : `${o.lens} ${o.rate}`).join(', ') + `. ${bugs.length} findings (${JSON.stringify(sev(bugs))}) fixed by owner with regression tests:\n` + fixedLines.join('\n').slice(0, 6000) + (undone.length ? '\nLeft undone: ' + undone.join('; ').slice(0, 1500) : ''), `fix-${round}`)
  summary.commit = vc.commit ? vc.commit.sha : null
  summary.suite_green = vc.green
  lastVerify = vc.verify
  if (!vc.green) { log(`round ${round}: suite still red after repairs; stopping the loop`); break }
  prev = round
}
if (!passed) log(`loop ended without all three overseers at 98% after ${rounds.length} round(s)`)

// ================================================================== Stress
phase('Stress')
const stress = await agent(`${INFRA}
YOUR TASK: contained stress runs; do not modify any file under ${REPO}/src or tests.
1. For each round directory in ${JSON.stringify(allRounds.filter(r => r !== 'r1-adv').map(r => ARENA + '/' + r))}: run ${PY} ${REPO}/scripts/arena/stress_arena.py <dir> 10 (and 30 replays for the latest round ${allRounds[allRounds.length - 1]}); record the sequential p50/p95/p99, throughput, statuses and crashes, the 16-thread transmissions, REJECTED and crashes, and the service leg's status codes (503 is load shedding by design).
2. cd ${REPO} && ${PY} -m pytest -q -m stress 2>&1 | tail -5
Report any crash, any unexpected REJECTED status, any thread result that differs from the sequential one, and any latency regression against docs/STRESS_RESULTS.md as anomalies.`, { label: 'stress', phase: 'Stress', schema: STRESS_SCHEMA })
let stressFix = null
if (stress && stress.anomalies && stress.anomalies.length) {
  log('stress anomalies: ' + stress.anomalies.join(' | ').slice(0, 500))
  await agent(`${INFRA}
The contained stress runs reported anomalies:
${JSON.stringify(stress, null, 1)}
You own all of src/ and tests/. Root-cause each anomaly that is a defect (a crash, a wrong status under load, a thread result differing from the sequential one, a large latency regression), fix it with a regression test, keep the suite green and the harness rates unchanged on ${JSON.stringify(allRounds.map(r => ARENA + '/' + r))}. Do NOT commit. Return what you changed.`, { label: 'stress-fix', phase: 'Stress', schema: FIX_SCHEMA })
  stressFix = await verifyAndCommit(allRounds, 'Fix defects found by the contained stress runs', 'Stress anomalies: ' + stress.anomalies.join('; ').slice(0, 2000), 'stress-fix')
  lastVerify = stressFix.verify
}

// ================================================================== Report
phase('Report')
await agent(`${INFRA}
You own docs/ARENA_RESULTS.md, docs/STRESS_RESULTS.md and the root README.md only. Update them from this record of the arena loop (do not invent numbers; every figure below is measured):
CONSOLIDATION: ${JSON.stringify(consolidation ? consolidation.fixed.map(f => f.bug + ': ' + f.change) : [])}
ROUNDS: ${JSON.stringify(rounds, null, 1)}
LOOP PASSED (all three overseers >= 0.98): ${passed}
FINAL VERIFY: ${JSON.stringify(lastVerify)}
STRESS: ${JSON.stringify(stress)}
The per-round overseer reports with their bugs are in ${ARENA}/<round>/overseers/*.json; read them for the substance of each round. In docs/ARENA_RESULTS.md add one section per round from r4 on (material, verdicts per lens, what was found in one bullet list of the important themes, what the fix round changed, harness after), and a closing summary table of every round's three verdicts. State plainly whether the 98% bar was reached, by which round, and what remains open. Keep the honesty notes (translation outcomes are provider-dependent; an ENTAILED verdict proves only the encoded problem under its premises). In docs/STRESS_RESULTS.md add the final stress iteration with the measured numbers. In README.md keep the arena paragraph accurate. No model names or session ids. Do NOT commit.`, { label: 'report', phase: 'Report' })
const final = await verifyAndCommit(allRounds, 'Arena results: rounds 4 onward, overseer verdicts and final stress', 'Documents the arena loop from round 4: fresh isolated specialist outputs each round, three overseer verdicts, the fixes made, harness and stress numbers.', 'report')

return { passed, consolidation: consolidation ? consolidation.fixed.length : null, rounds, stress, stressFixed: !!stressFix, final: { green: final.green, harness: final.verify ? final.verify.harness : null, commit: final.commit } }
