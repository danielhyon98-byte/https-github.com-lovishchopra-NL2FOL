"""Write the update note that goes with every upload of the overseer prototype (Daniel, 2026-10-12).

The note explains what the upload changes, the bugs and failures found by the overseer build's review and contained
rounds in that interval, the fixes introduced, the findings still open at the published commit, and how the published
tree was verified. It is built only from git history and the overseer build's workflow journal (what each review,
fix and evaluation step returned), plus, for the overseer rebuild on the STEM-merged translator, the rebuild
workflow's journal (its rebuild:merge step and its eval:rebuild evaluation). Scratch paths, local paths, session ids
and model names are removed.

Usage: overseer_notes.py --repo R --from SRC_A --to SRC_B --fork FORK --number N --journal J --rerun TAIL
       --out FILE [--rebuild-journal RJ] [--published DATE] [--index PATH ...]
"""
import argparse
import datetime
import json
import os
import re
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import update_notes as U  # noqa: E402  (shared cleaning, commit listing and file-area helpers)
import overseer_gate as G  # noqa: E402  (one definition of the rebuild subject, the STEM merge and translator merges)
from overseer_gate import REBUILD_SUBJECT  # noqa: E402

os.environ["TZ"] = "UTC"

SEV = {"blocker": 0, "major": 1, "minor": 2}
REVIEW_RE = re.compile(r"^Overseer review round (\d+): ")
CONTAINED_RE = re.compile(r"^Overseer contained round (c\d+): ")
DOCS_SUBJECT = "Overseer agents: documentation and contained-test results"
STEM_MERGE_SUBJECT = "Merge STEM support into the translator"
FAULTFIX_SUBJECT = "Overseer: circular-translation severity, adjudicated genuine faults and STEM-ready checks"


def clean(text):
    t = re.sub(r"/home/user/[^\s'\"`),;]*?/\.worktrees/overseer/", "", str(text or ""))
    t = re.sub(r"(?<![\w/])\.worktrees/overseer/", "", t)
    t = re.sub(r"(?<![\w/])\.worktrees/(?:[^\s'\"`),;]*[^\s'\"`),;.])?", "a private working copy", t)
    t = re.sub(r"/home/user/(?:[^\s'\"`),;]*[^\s'\"`),;.])?", "a local path", t)
    t = re.sub(r"(?<![\w/.])(?:eval|fix|review|judge)/pack-export(?:[^\s'\"`),;]*[^\s'\"`),;.])?", "a private working copy", t)
    t = U.clean(t)
    t = re.sub(r"\bhaiku\b", "cheapest-tier model", t, flags=re.I)
    t = re.sub(r"\bopus\b", "strongest-tier model", t, flags=re.I)
    return re.sub(r"(?<!\.)\.\.(?=\s|$)", ".", t)


def short(text, n):
    t = " ".join(clean(text).split())
    return t if len(t) <= n else t[: n - 1].rstrip() + "…"


def journal_results(path, what="the build's journal"):
    """Last non-empty result per label (resumed runs repeat labels; failed steps return nothing)."""
    labels, out = {}, {}
    try:
        lines = open(path, encoding="utf-8", errors="replace").read().split("\n")
    except OSError:
        sys.exit(f"{what} is unreadable: {path}")
    for line in lines:
        try:
            e = json.loads(line)
        except ValueError:
            continue
        if e.get("type") == "started":
            labels[e.get("key")] = e.get("label")
        elif e.get("type") == "result" and e.get("result") is not None:
            out[labels.get(e.get("key"), "?")] = e["result"]
    return out


def review_rounds(res):
    rounds = {}
    for label, r in res.items():
        m = re.match(r"^review:([a-z-]+):(\d+)$", label)
        if m and isinstance(r, dict):
            rounds.setdefault(int(m.group(2)), {})[m.group(1)] = r.get("bugs") or []
    return rounds


def bug_lines(per_lens, limit):
    rows, items = [], []
    for lens, bugs in sorted(per_lens.items()):
        sev = {k: sum(1 for b in bugs if isinstance(b, dict) and b.get("severity") == k) for k in SEV}
        rows.append(f"| {lens} | {len(bugs)} | {sev['blocker']} | {sev['major']} | {sev['minor']} |")
        for b in bugs:
            if isinstance(b, dict):
                where = f" `{clean(b.get('file'))}`" if b.get("file") else ""
                items.append((SEV.get(b.get("severity"), 3), f"- **{b.get('severity', '?')}** ({lens}){where}: {short(b.get('summary', ''), 300)}"))
    items.sort(key=lambda x: x[0])
    shown = [s for _, s in items[:limit]]
    if len(items) > limit:
        shown.append(f"- … and {len(items) - limit} more lower-severity findings not shown.")
    table = ["| Reviewer | Findings | Blockers | Majors | Minors |", "| --- | --- | --- | --- | --- |"] + rows
    return table, shown


def eval_lines(ev):
    if not isinstance(ev, dict):
        return ["- Evaluation not recorded."]
    out = [f"- Tamperings detected: {ev.get('tamperings_detected')}/{ev.get('tamperings')}; false alarms on "
           f"{ev.get('genuine_transfers')} genuine transfers: {ev.get('false_alarms_on_genuine')}."]
    if ev.get("suite_tail"):
        out.append(f"- Suite: {short(ev['suite_tail'], 400)}")
    if ev.get("harness_rates"):
        out.append(f"- Arena replays with the overseer attached: {short(ev['harness_rates'], 700)}")
    if ev.get("harness_line"):
        out.append(f"- Translator harness on every recorded round: {short(ev['harness_line'], 500)}")
    if "contained_gates_ok" in ev:
        out.append(f"- Contained run, every gate passing: {'yes' if ev.get('contained_gates_ok') is True else 'no'}"
                   + (f" ({short(ev.get('contained_gates'), 500)})" if ev.get("contained_gates") else "") + ".")
    if "export_ok" in ev:
        out.append(f"- Knowledge-document pack exported and verified: {'yes' if ev.get('export_ok') else 'no'}"
                   + (f" ({short(ev.get('export_detail'), 300)})" if ev.get("export_detail") else "") + ".")
    return out


def fix_lines(fix, limit=40):
    if not isinstance(fix, dict):
        return [], []
    done = [f"- {short(d.get('item', ''), 200)}: {short(d.get('change', ''), 360)}" for d in fix.get("done") or [] if isinstance(d, dict)]
    if done:
        done = ["The fix step's own report (advisory; the verification below is what was measured):", ""] + done
    if len(done) > limit:
        done = done[:limit] + [f"- … and {len(done) - limit} more (see the source commit's tests)."]
    # Notes about the build's own workspace (other teams' uncommitted files) say nothing about the uploaded code.
    undone = [f"- {short(u, 360)}" for u in fix.get("left_undone") or [] if not re.search(r"main checkout|uncommitted", str(u), re.I)]
    return done, undone


def translator_basis(repo, to):
    """The translator a source carries when it is no longer the fork point's.

    T is the second parent of the newest merge on the source's first-parent line that brought in a development
    translator (its second parent descends from the development branch's STEM merge; overseer_gate.translator_merge),
    whatever that merge's subject: a later merge of a newer development head supersedes the rebuild. The rebuild subject
    only chooses the wording. Returns {"merge": M, "rebuild": M when M is the rebuild commit else None, "translator": T,
    "stem": the STEM merge}, or None when the source carries no later translator (only the fork point's, plus the
    overseer's own changes).
    """
    tm = G.translator_merge(repo, to)
    if not tm:
        return None
    msubj = U.git(repo, "log", "-1", "--format=%s", tm["merge"]).strip()
    return dict(tm, rebuild=tm["merge"] if msubj == REBUILD_SUBJECT else None)


def translator_changes(repo, basis, to):
    """Translator files that differ between T and the source, split into those the overseer side changed (before the
    merge, on the merge's first parent since its merge base with T, or after the merge) and those it never changed,
    which differ from T only because the merge itself changed or reverted them."""
    m, t = basis["merge"], basis["translator"]
    mb = U.git(repo, "merge-base", m + "^1", t).strip()
    ours = set(translator_files_since(repo, mb, m + "^1")) | set(translator_files_since(repo, m, to)) if mb else set()
    files = translator_files_since(repo, t, to)
    return [p for p in files if p in ours], [p for p in files if p not in ours]


def translator_files_since(repo, base, to):
    """Translator files (src outside the overseer package) that differ between base and to."""
    return [p for p in U.git(repo, "diff", "--name-only", base, to, "--", "src").split() if not p.startswith("src/epinoic_logic/overseer/")]


def kept_lines(report, limit=60):
    """The note's account of the development translator's lines in the uploaded tree (overseer_gate.development_report;
    never a reason to hold): the policy sentence, then the files with lines not kept verbatim, each with a count and how
    many of those were found rewritten."""
    n, k, m = report["not_verbatim"], report["not_verbatim_files"], report["m"]
    out = ["The gate holds a commit that drops a development test or switches one off (a skip or xfail mark, a skip in "
           "its body, a conftest or pytest option that leaves it out, ...), that deletes, reverts or takes wholesale from "
           "the overseer side a path the development side changed, or whose evaluation passes fewer tests than the "
           "translator's record; this is checked against every merge of the development translator on this line, and "
           "none of these applies here. Line by line, every non-blank line the development side added since each merge "
           "base was looked for in the uploaded file. Every line not there verbatim is counted below by file; of these, "
           "the lines found rewritten (as an import of the same module with the same or more names, or as a line holding "
           "their tokens in order) are counted again, and the rest were found none of these ways (a rewrite or refactor "
           "of development code, or a dropped line). They are reported, not held.", "",
           f"- development lines not kept verbatim: {n} in {k} files ({m} of them found rewritten: an import with the "
           "same or more names, or their tokens in order); behaviour verified by the full suite and the recorded rounds."]
    counts = {}
    for key in ("lines", "rewritten"):
        for p, v in report[key].items():
            counts.setdefault(p, [0, 0])[key == "rewritten"] += sum(c for _, c in v)
    rows = sorted(counts.items())
    out += [f"  - `{clean(p)}`: {a + b} line(s)" + (f", {b} of them found rewritten" if b else "") for p, (a, b) in rows[:limit]]
    if len(rows) > limit:
        out.append(f"  - … and {len(rows) - limit} more file(s).")
    if report["binary"]:
        out.append(f"- Binary files that differ from the translator's: {len(report['binary'])} ("
                   + ", ".join(f"`{clean(p)}`" for p in report["binary"][:20]) + (", …" if len(report["binary"]) > 20 else "") + ").")
    return out


def rebuild_lines(rb):
    """The rebuild step's own report, from the rebuild workflow's MERGE fields (advisory; the evaluation is measured)."""
    out = ["The rebuild step's own report (advisory; the verification below is what was measured):", ""]
    if rb.get("suite"):
        out.append(f"- Suite reported by the step: {short(rb['suite'], 300)}")
    harness = [short(h, 120) for h in rb.get("harness") or [] if str(h).strip()]
    if harness:
        out.append(f"- Translator harness reported by the step: {', '.join(harness)}")
    if rb.get("contained_gates"):
        out.append(f"- Contained gates reported by the step: {short(rb['contained_gates'], 500)}")
    if rb.get("stem_mutations"):
        out.append(f"- STEM mutations named and confirmed: {short(rb['stem_mutations'], 600)}")
    adj = [a for a in rb.get("adjudicated") or [] if str(a).strip()]
    if adj:
        out += ["", "Adjudicated genuine faults (each must be raised by the overseer):", ""] + [f"- {short(a, 360)}" for a in adj[:40]]
        if len(adj) > 40:
            out.append(f"- … and {len(adj) - 40} more.")
    tc = [t for t in rb.get("test_changes") or [] if isinstance(t, dict)]
    out += ["", "Test changes (none may weaken a test; each with the step's reason it is not weaker):", ""]
    out += [f"- `{clean(t.get('test'))}`: {short(t.get('change', ''), 300)} (why not weaker: {short(t.get('why_not_weaker', ''), 300)})" for t in tc[:60]] or ["- None reported."]
    if len(tc) > 60:
        out.append(f"- … and {len(tc) - 60} more (see the source commit's tests).")
    return out


def journal_events(path):
    """(label, type, result) in journal order; used where the order of steps matters (the rebuild's repair)."""
    labels, out = {}, []
    try:
        lines = open(path, encoding="utf-8", errors="replace").read().split("\n")
    except OSError:
        return out
    for line in lines:
        try:
            e = json.loads(line)
        except ValueError:
            continue
        if e.get("type") == "started":
            labels[e.get("key")] = e.get("label")
        elif e.get("type") in ("result", "failed"):
            out.append((labels.get(e.get("key")), e.get("type"), e.get("result")))
    return out


def main():
    ap = argparse.ArgumentParser()
    for k in ("repo", "from", "to", "fork", "journal", "rerun", "out"):
        ap.add_argument("--" + k, required=True)
    ap.add_argument("--number", type=int, required=True)
    ap.add_argument("--rebuild-journal", default="")
    ap.add_argument("--published", default="")
    ap.add_argument("--index", nargs="*", default=[])
    a = ap.parse_args()
    src_from = getattr(a, "from")
    git = lambda *x: U.git(a.repo, *x)  # noqa: E731
    cs = U.commits(a.repo, src_from, a.to)
    published_subjects = [c["subject"] for c in U.commits(a.repo, a.fork, a.to)]
    subj = git("log", "-1", "--format=%s", a.to).strip()
    body = git("log", "-1", "--format=%B", a.to)
    when = a.published or datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    fork_when = git("log", "-1", "--date=format-local:%Y-%m-%d %H:%M UTC", "--format=%cd", a.fork).strip()
    res = journal_results(a.journal)
    # The rebuild (a separate workflow) has its own journal: its step and evaluation are read only from that journal.
    rebuild_in_range = any(c["subject"] == REBUILD_SUBJECT for c in cs)
    rres = journal_results(a.rebuild_journal, "the rebuild's journal") if a.rebuild_journal and rebuild_in_range else {}
    first = src_from == a.fork
    in_range = sorted({int(m.group(1)) for m in (REVIEW_RE.match(c["subject"]) for c in cs) if m})
    contained_commits = list(dict.fromkeys(m.group(1) for m in (CONTAINED_RE.match(c["subject"]) for c in cs) if m))
    if subj == REBUILD_SUBJECT:
        ev_label, ev_res, ev_what = "eval:rebuild", rres, "the rebuild's journal"
    else:
        ev_label = "eval:final" if subj == DOCS_SUBJECT else f"eval:{CONTAINED_RE.match(subj).group(1)}" if CONTAINED_RE.match(subj) else f"eval:review-{in_range[-1]}" if in_range else None
        ev_res, ev_what = res, "the build's journal"
    if not ev_label or not isinstance(ev_res.get(ev_label), dict):
        sys.exit(f"{ev_what} has no evaluation result for the source commit ({ev_label})")
    evaluation = ev_res[ev_label]
    earlier_subjects = [c["subject"] for c in U.commits(a.repo, a.fork, src_from)] if not first else []
    # The translator the source carries: the fork point's (plus the overseer's changes), or, once the rebuild merged the
    # development branch in, that branch's head T (which may be newer than the STEM merge it contains).
    basis = translator_basis(a.repo, a.to)
    tr = basis["translator"] if basis else None
    stem = basis["stem"] if basis else None
    if basis:
        translator_files, merge_files = translator_changes(a.repo, basis, a.to)
    else:
        translator_files, merge_files = translator_files_since(a.repo, a.fork, a.to), []
    translator_areas = sorted({p.split("/")[2] for p in translator_files if len(p.split("/")) > 3})
    merge_areas = sorted({p.split("/")[2] for p in merge_files if len(p.split("/")) > 3})
    tr_subj = short(git("log", "-1", "--format=%s", tr).strip(), 120) if tr else ""
    tr_when = git("log", "-1", "--date=format-local:%Y-%m-%d %H:%M UTC", "--format=%cd", tr).strip() if tr else ""
    translator_side = set(git("rev-list", f"{src_from}..{tr}").split()) if tr else set()
    changes = (f"plus the changes the overseer needs in {len(translator_files)} translator file(s) ({', '.join(translator_areas)})"
               if translator_files else "with no translator changes of its own")
    if merge_files:
        changes += (f"; {len(merge_files)} further translator file(s) ({', '.join(merge_areas)}) differ from that translator "
                    "although the overseer side never changed them (the merge itself changed or reverted them)")
    stem_part = f"; it includes STEM support, merged at `{stem[:7]}` (\"{STEM_MERGE_SUBJECT}\")" if stem else ""

    md = [f"# Overseer prototype, update {a.number}: {clean(subj)}", "",
          f"Published {when}. Source commit `{a.to[:7]}` on the overseer build's branch; "
          + ("this is the first upload of the overseer prototype." if first else f"the previous upload's source was `{src_from[:7]}`."), "",
          "This branch carries the logic-checking overseer build exactly as verified at the source commit: the "
          "`epinoic_logic.overseer` package (the deterministic transfer audit, the overseer-agent verdict protocol and its "
          "validation, the observer hook on the channel and hub, consolidation of duplicated answers, repeated-fault "
          "suppression and the self-duplicating overseer pool), its exportable knowledge-document pack, the contained "
          "harness under `scripts/overseer/`, and their tests"
          + ((f", on the translator as it stood at `{tr[:7]}` (\"{tr_subj}\"{stem_part}), {changes}")
             if tr else
             f", plus the changes the overseer needs in {len(translator_files)} translator file(s) ({', '.join(translator_areas)})"
             if translator_files else "")
          + ". Work-in-progress commits are never uploaded as commits.", "",
          ("**Prototype status.** The overseer build was started from the translator as it stood at "
           f"`{a.fork[:7]}` ({fork_when}), a commit already in this repository's history. "
           + (f"The rebuild `{basis['rebuild'][:7]}` merged" if basis["rebuild"] else f"The merge `{basis['merge'][:7]}` brought in")
           + f" the development branch's translator as it stood at `{tr[:7]}` (\"{tr_subj}\", {tr_when}){stem_part}. "
           "This branch therefore carries that translator, verified together with the overseer by "
           # The same evaluation the Verification section reports for the source commit.
           + ("the rebuild's evaluation at the source commit" if ev_label == "eval:rebuild"
              else "the build's evaluation at the source commit")
           + " (under Verification below)"
           + f", {changes}. The overseer joins `verified-updates` through a "
           "verified merge after its build finishes. Findings still open at the source commit are listed below.")
          if tr else
          ("**Prototype status.** The overseer build was started from the translator as it stood at "
           f"`{a.fork[:7]}` ({fork_when}), a commit already in this repository's history. The translator fixes made after "
           "that point are not on this branch: the round-5 fixes are on the default branch `import/translator-baseline`, "
           "and the round-5 to round-7 fixes on `verified-updates`. The overseer joins `verified-updates` through a "
           "verified merge after its build finishes. Findings still open at the source commit are listed below."), "",
          "Scope: results prove properties of the encoded problems only, never that a specialist's premises are true. "
          "Overseer agents' verdicts are advisory: the infrastructure validates every verdict and trusts only signed "
          "engine results.", ""]

    rows, shortstat = U.area_stats(a.repo, src_from, a.to)
    md += ["## What this update changes", "", f"{len(cs)} commit(s) on the overseer build's branch "
           + ("since it started" if first else "since the previous upload") + f"; {shortstat or 'no file changes'}.", ""]
    if rows:
        md += ["| Area | Added | Modified | Deleted | Renamed |", "| --- | --- | --- | --- | --- |"]
        md += [f"| {k} | {v['A']} | {v['M']} | {v['D']} | {v['R']} |" for k, v in sorted(rows.items())]
        md.append("")
    to_sha = git("rev-parse", a.to).strip()
    md += ["Commits, oldest first:", ""]
    for c in cs:
        if c["sha"] in translator_side:
            # Translator history merged by the rebuild (its own WIP commits included) is part of the translator as it
            # stood at T, not overseer work in progress.
            tag = f"translator commit, included as it stood at `{tr[:7]}`"
        elif c["subject"].startswith("WIP"):
            later = next((d for d in cs if d["sha"] != c["sha"] and c["sha"][:7] in d["body"]), None)
            tag = "work in progress, not uploaded as a commit" + (f"; its content is included as completed and verified by `{later['sha'][:7]}`" if later else "")
        else:
            tag = "verified source of this upload" if c["sha"] == to_sha else "included"
        md.append(f"- `{c['sha'][:7]}` {short(c['subject'], 160)} ({tag})")
    md.append("")
    for doc in ("docs/OVERSEER_DESIGN.md", "docs/OVERSEER_AGENT_BRIEF.md", "docs/OVERSEER_RESULTS.md", "scripts/overseer/README.md"):
        if subprocess.run(["git", "-C", a.repo, "cat-file", "-e", f"{a.to}:{doc}"], capture_output=True).returncode == 0:
            md.append(f"- See `{doc}`.")
    md.append("")

    rr = review_rounds(res)
    judged = {}
    for k, v in res.items():
        m = re.match(r"^judge:([a-z-]+):(c\d+)$", k)
        if m and isinstance(v, dict):
            judged.setdefault(m.group(2), {})[m.group(1)] = v
    review_title = "Overseer review round {}: fix tamper-evasion, agent-abuse and precision findings"
    contained_title = "Overseer contained round {}: fix judge findings"
    # A round counts as fixed in the uploaded code only when its fix commit is in the uploaded history AND its fix
    # step returned a result (the build commits even when the fix step crashed part-way).
    review_fixed = {n for n in rr if review_title.format(n) in published_subjects and isinstance(res.get(f"review-fix:{n}"), dict)}
    contained_fixed = {r for r in judged if contained_title.format(r) in published_subjects and isinstance(res.get(f"fix:{r}"), dict)}

    def passed(r):
        js = judged.get(r, {})
        return len(js) >= 2 and all((j.get("infrastructure_functional_rate") or 0) >= 0.98 and (j.get("overseer_agent_rate") or 0) >= 0.98 and j.get("verdict_at_least_98") for j in js.values())

    def contained_state(r):
        if r in contained_fixed:
            return "fixed in the uploaded code"
        if passed(r):
            serious = any(isinstance(b, dict) and b.get("severity") in ("blocker", "major") for j in judged[r].values() for b in j.get("bugs") or [])
            return ("passed: both rates at least 0.98 by the judges' verdict"
                    + ("" if serious else "; no blocker or major listed") + "; its remaining findings were left by the build")
        if contained_title.format(r) in published_subjects:
            return "the fix step did not complete"
        if isinstance(res.get(f"fix:{r}"), dict):
            return "the fix step made no change to the code"
        return "fixes not in this upload"

    # Contained rounds are reported once: in the first upload whose source follows them (a round that passes has no
    # fix commit, so rounds are taken from the journal, not from commit titles).
    contained_new = [r for r in sorted(judged) if contained_title.format(r) not in earlier_subjects and not (passed(r) and DOCS_SUBJECT in earlier_subjects)]

    md += ["## Bugs and failures found in this interval", "",
           "Reviewer and judge reports are the build's independent checkers; each finding came with a reproduction.", ""]
    found = False
    for n in in_range:
        if n in rr:
            found = True
            table, items = bug_lines(rr[n], 25)
            md += [f"### Adversarial review round {n}", ""] + table + [""] + items + [""]
    for rnd in contained_new:
        found = True
        md += [f"### Contained round {rnd}: translator and live overseer agents ({contained_state(rnd)})", ""]
        for j, r in sorted(judged[rnd].items()):
            md.append(f"- {j}: infrastructure rate {r.get('infrastructure_functional_rate')}, overseer-agent rate "
                      f"{r.get('overseer_agent_rate')}, {len(r.get('bugs') or [])} finding(s).")
        md.append("")
    if rebuild_in_range:
        found = True
        md += ["### Rebuild audit (the one independent test for bugs and faults)", ""]
        evs = journal_events(a.rebuild_journal) if a.rebuild_journal else []
        # Every test in order (the workflow re-tests once after its one repair); a repair is a rebuild:merge result
        # that follows a test.
        idx = [i for i, (lab, _, _) in enumerate(evs) if lab == "rebuild:audit"]
        if not idx:
            md += ["The audit's result is missing from the rebuild's journal (not given, not run, or it did not complete).", ""]
        for n, i in enumerate(idx, 1):
            typ, aud = evs[i][1], evs[i][2]
            head = f"Test {n} of {len(idx)}" if len(idx) > 1 else "The test"
            if typ != "result" or not isinstance(aud, dict):
                md += [f"{head} did not complete (no result in the rebuild's journal).", ""]
                continue
            nxt = idx[n] if n < len(idx) else len(evs)
            repaired = any(lab == "rebuild:merge" and t == "result" and isinstance(r, dict) for lab, t, r in evs[i + 1:nxt])
            vs = [v for v in aud.get("violations") or [] if isinstance(v, dict)]
            line = f"{head}: " + ("ok, no violation reported." if aud.get("ok") is True and not vs else
                                  f"not clean, {len(vs)} violation(s) reported; "
                                  + ("a repair step followed and the tree was tested again." if repaired and n < len(idx) else
                                     "a repair step followed." if repaired else "no repair step followed, so they are not repaired."))
            md += [line + (f" Measured: {short(aud['measured'], 500)}" if aud.get("measured") else ""), ""]
            if vs:
                md += [f"- **{clean(v.get('severity') or 'unrated')}** ({clean(v.get('area') or '?')}): {short(v.get('problem', ''), 360)}" for v in vs[:40]]
                if len(vs) > 40:
                    md.append(f"- … and {len(vs) - 40} more.")
                md.append("")
    wips = [c for c in cs if c["subject"].startswith("WIP") and c["sha"] not in translator_side]
    if wips:
        found = True
        md += ["### Work-in-progress commits in this interval", "",
               "Not uploaded as commits; their content is included only as completed and verified by a later commit.", ""]
        md += [f"- `{c['sha'][:7]}` {short(c['subject'], 200)}" for c in wips] + [""]
    if not found:
        md += ["No review or contained-round findings were recorded in this interval.", ""]

    md += ["## Fixes introduced", ""]
    steps = [(f"Review round {n} fixes", f"review-fix:{n}") for n in in_range] + [(f"Contained round {r} fixes", f"fix:{r}") for r in contained_commits]
    # A contained fix step that returned but changed nothing has no commit; its report is still shown once.
    steps += [(f"Contained round {r} fix step (made no change to the code)", f"fix:{r}") for r in contained_new
              if r not in contained_commits and contained_title.format(r) not in published_subjects and isinstance(res.get(f"fix:{r}"), dict)]
    if rebuild_in_range:
        rb = rres.get("rebuild:merge")
        md += ["### Rebuild on the STEM-merged translator", ""]
        if not isinstance(rb, dict):
            md += ["The rebuild step's report is not available to this note (the rebuild's journal was not given or holds no result).", ""]
        else:
            _, undone = fix_lines(rb)
            md += rebuild_lines(rb) + ([""] + ["Left undone:"] + undone if undone else []) + [""]
    for c in cs:
        if c["subject"] == FAULTFIX_SUBJECT:
            paras = [p for p in c["body"].split("\n\n") if p.strip() and not re.match(r"^\s*(Co-Authored-By|Claude-Session):", p.strip())]
            md += [f"### Faulty checks corrected (`{c['sha'][:7]}`)", "",
                   f"Recorded in its commit message: {short(' '.join(paras[:2]), 700) if paras else 'nothing recorded'}", "",
                   "That step ran in a separate workflow; its own report is not part of this note. Its changes are included "
                   "in, and verified by, the source commit's evaluation below.", ""]
    for title, label in steps:
        fix = res.get(label)
        if not isinstance(fix, dict):
            md += [f"### {title}", "", "The fix step did not complete; its findings are listed as still open below.", ""]
            continue
        done, undone = fix_lines(fix)
        md += [f"### {title}", ""] + (done or ["The fix step reported no item list."]) + ([""] + ["Left undone:"] + undone if undone else []) + [""]
    if not steps and not rebuild_in_range and not any(c["subject"] == FAULTFIX_SUBJECT for c in cs):
        md += ["No fix step falls in this interval.", ""]

    md += ["## Findings still open at the source commit", ""]
    lenses = sorted({lens for per in rr.values() for lens in per})
    any_open = False
    for n in sorted(rr):
        if n in review_fixed:
            continue
        any_open = True
        table, items = bug_lines(rr[n], 25)
        why = "reported after the source commit; fixes not in this upload" if review_title.format(n) not in published_subjects else "the fix step did not complete"
        md += [f"### Adversarial review round {n} ({why})", "", "Reviewer reports, not yet reproduced by a fix step:", ""] + table + [""] + items + [""]
        pending = [lens for lens in lenses if lens not in rr[n]]
        if pending:
            md += [f"Not yet reported when this note was written: {', '.join(pending)}.", ""]
    for r in sorted(judged):
        if r in contained_fixed:
            continue
        bugs = {j: v.get("bugs") or [] for j, v in judged[r].items()}
        if any(bugs.values()):
            any_open = True
            table, items = bug_lines(bugs, 25)
            md += [f"### Contained round {r} judges ({contained_state(r)})", ""] + table + [""] + items + [""]
    # Items a fix step left undone stay listed until the build finishes; a later round may have addressed some.
    earlier_undone = []
    for label in [f"review-fix:{n}" for n in sorted(review_fixed) if n not in in_range] + [f"fix:{r}" for r in sorted(contained_fixed) if r not in contained_commits]:
        for u in fix_lines(res.get(label))[1]:
            if u not in earlier_undone:
                earlier_undone.append(u)
    in_range_undone = any(fix_lines(res.get(label))[1] for _, label in steps) or (rebuild_in_range and bool(fix_lines(rres.get("rebuild:merge"))[1]))
    if earlier_undone:
        any_open = True
        md += ["### Left undone by earlier fix steps", "", "As reported by those steps; a later round may have addressed some of them.", ""] + earlier_undone + [""]
    if in_range_undone:
        any_open = True
        md += ["The items this interval's fix steps left undone (under Fixes introduced) are also still open.", ""]
    if not any_open:
        md += ["None recorded: every review and contained round reported so far has its fixes in this upload, and no fix step left anything undone.", ""]

    if basis:
        # The development translator's lines in the uploaded tree (reported, never held: the gate holds lost tests and
        # lost paths, and the suite and the recorded rounds verify behaviour).
        md += ["## The development translator in the uploaded tree", ""] + kept_lines(G.development_report(a.repo, a.to)) + [""]
    paras = [p for p in body.split("\n\n")[1:] if p.strip() and not re.match(r"^\s*(Co-Authored-By|Claude-Session):", p.strip())]
    record = paras[0] if paras else "not recorded"
    md += ["## Verification", "",
           f"- Recorded at the source commit: {short(record, 500)}",
           f"- Re-run by the publisher on exactly the source tree before upload (every recorded round available): {short(a.rerun, 400)}",
           ("- The rebuild's evaluation at the source commit:" if ev_label == "eval:rebuild" else "- The build's evaluation at the source commit:")]
    md += ["  " + line for line in eval_lines(evaluation)]
    md.append("")
    if a.index:
        md += ["## Earlier overseer uploads", ""] + [f"- {p}" for p in a.index] + [""]
    with open(a.out, "w", encoding="utf-8") as fh:
        fh.write("\n".join(md).rstrip() + "\n")

if __name__ == "__main__":
    main()
