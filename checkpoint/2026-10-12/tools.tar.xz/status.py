"""Compact progress snapshot for the five-minute status updates (reads journals and files only; no model is called).

Prints, per workflow in runs.json: agents finished since the previous snapshot, agents in flight now, and the newest
activity; the arena round-7 material counts; new commits on the development branch and the build branches.
State of the previous snapshot is kept in status-state.json.
"""
import json
import os
import subprocess
import time

S = os.path.dirname(os.path.abspath(__file__))
WF = "/root/.claude/projects/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/subagents/workflows"
REPO = "/home/user/https-github.com-lovishchopra-NL2FOL"
STATE = os.path.join(S, "status-state.json")


def journal(wf):
    started, results, labels, ended = {}, [], {}, set()
    path = os.path.join(WF, wf, "journal.jsonl")
    if not os.path.exists(path):
        return None
    for line in open(path, encoding="utf-8", errors="replace"):
        try:
            e = json.loads(line)
        except ValueError:
            continue
        if e.get("type") == "started":
            started[e["key"]] = e.get("agentId")
            labels[e["key"]] = e.get("label", "?")
            ended.discard(e["key"])  # a resumed step reuses its key and is in flight again
        elif e.get("type") == "result":
            results.append(e["key"])
            ended.add(e["key"])
        elif e.get("type") == "failed":
            ended.add(e["key"])
    done = ended
    inflight = {}
    latest = {}
    for k in started:
        latest[labels[k]] = k  # dict order is journal order, so the newest start of each label wins
    for k, a in ((k, started[k]) for k in latest.values()):
        if k not in done and a and os.path.exists(os.path.join(WF, wf, f"agent-{a}.jsonl")):
            t = os.path.getmtime(os.path.join(WF, wf, f"agent-{a}.jsonl"))
            if time.time() - t < 3 * 3600:
                inflight[labels[k]] = t
    return {"done": [labels.get(k, "?") for k in results], "inflight": inflight, "mtime": os.path.getmtime(path)}


def git(*a):
    try:
        return subprocess.run(["git", "-C", REPO, *a], capture_output=True, text=True, check=True).stdout.strip()
    except subprocess.CalledProcessError:
        return ""


def main():
    now = time.time()
    try:
        prev = json.load(open(STATE))
    except (OSError, ValueError):
        prev = {}
    runs = json.load(open(os.path.join(S, "runs.json")))
    cur = {"t": now, "done": {}, "heads": {}}
    print(time.strftime("%H:%M UTC", time.gmtime(now)))
    for name in ("review-fixes", "overseer-rebuild", "phase2"):
        wf = runs.get(name)
        if not wf:
            print(f"- {name}: not started")
            continue
        j = journal(wf)
        if j is None:
            print(f"- {name}: no journal")
            continue
        n_before = prev.get("done", {}).get(name, len(j["done"]))
        new = j["done"][n_before:]
        cur["done"][name] = len(j["done"])
        fl = ", ".join(f"{l} ({(now - t) / 60:.0f}m idle)" if now - t > 300 else l for l, t in sorted(j["inflight"].items(), key=lambda x: -x[1])[:4])
        print(f"- {name}: {len(new)} finished since last ({', '.join(new[-6:]) or 'none'}); in flight: {fl or 'none'}")
    r7 = os.path.join(S, "arena", "r7")
    if os.path.isdir(r7):
        counts = {d: len(os.listdir(os.path.join(r7, d))) for d in ("specialists", "relayed", "translations", "syntheses", "overseers") if os.path.isdir(os.path.join(r7, d))}
        print(f"- round 7 files: {counts}; results.json {'present' if os.path.exists(os.path.join(r7, 'results.json')) else 'not yet'}")
    c1 = os.path.join(S, "clearance", "c1")
    if os.path.isdir(c1):
        counts = {d: len(os.listdir(os.path.join(c1, d))) for d in ("specialists", "relayed", "translations", "syntheses", "overseers") if os.path.isdir(os.path.join(c1, d))}
        print(f"- round 8 (c1) files: {counts}; results.json {'present' if os.path.exists(os.path.join(c1, 'results.json')) else 'not yet'}")
    print(f"- merge in progress on the development tree: {'yes' if os.path.exists(os.path.join(REPO, '.git', 'MERGE_HEAD')) else 'no'}")
    logs = sorted(f for f in os.listdir(S) if f.startswith("hourly-push-") and f.endswith(".log"))
    if logs:
        last = open(os.path.join(S, logs[-1]), encoding="utf-8", errors="replace").read().strip().splitlines()
        print(f"- last hourly push ({logs[-1][12:-4]}): {last[-1] if last else 'empty log'}")
    for ref in ("claude/z3-verification-engine-plan-nk3luq", "stem-build", "overseer-build"):
        head = git("rev-parse", "--short", ref)
        cur["heads"][ref] = head
        old = prev.get("heads", {}).get(ref)
        if old and old != head:
            print(f"- new commits on {ref}: " + "; ".join(git("log", "--format=%h %s", f"{old}..{ref}").splitlines()[:5]))
    json.dump(cur, open(STATE, "w"))


if __name__ == "__main__":
    main()
