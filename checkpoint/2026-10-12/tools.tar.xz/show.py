import json,sys
d=json.load(open(sys.argv[1]))
print("report_id=",d["report_id"],"request_id=",d["request_id"],"branch=",d["branch"])
for c in d["claims"]:
    print(f'-- {c["claim_id"]} role={c["role"]} mat={c["materiality"]} cert={c["certainty"]} elig={c["eligible"]} class={c["eligibility_class"]} sup={c["supporting_claim_ids"]} refs={[ (r.get("document_id"), r.get("excerpt"), r.get("located")) for r in c["source_refs"]]} assm={c["assumptions"]} adv={c["advisory_verification_status"]}')
    print("   TEXT:", c["text"])
