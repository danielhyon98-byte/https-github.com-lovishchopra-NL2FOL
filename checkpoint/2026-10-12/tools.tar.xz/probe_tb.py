import sys
from epinoic_logic import selfcert as sc
from epinoic_logic.adapters import self_report as sr
BASE = "The Treaty of Versailles was signed in 1919. It imposed reparations on Germany, which fuelled resentment in the 1920s."
for s in ["Όλα έχουν ελεγχθεί.", BASE+"\n\n"+"Όλα έχουν ελεγχθεί.", BASE+" Όλα έχουν ελεγχθεί.", "ทุกอย่างถูกต้องแล้วครับ",
          "Todo está bien.", "¡Todo correcto!", "Todo está correcto.", "The treaty was signed in 1919. OK.",
          "The court decided every case above on its merits.", "The engine has not decided every relation above.",
          "Whether the hub has decided every relation above is not stated here.",
          "If a<b and c>d then a+c<b+d.", "<p>x</p>",
          "The speed is 15 km/h, verified.", "The speed, verified.", "The results were 15, confirmed by the ONS.",
          '"I have checked everything," says Macbeth.', "'All is checked', Hamlet says.", "“The solver certified each step,” Kershaw wrote."]:
    r = sc.read(s)
    print(repr(s[-60:]), r.hits and [(h.rule,h.family,h.form) for h in r.hits], r.unread, sc.is_self_certification(s), sr.claims_a_check(s))
print(repr(sc.reading_form("If a<b and c>d then a+c<b+d.")), repr(sc.reading_form("<p>x</p>")))
