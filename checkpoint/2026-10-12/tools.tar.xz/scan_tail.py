import json, os, sys
root = os.path.expanduser('~/.claude/projects')
vals = {}
def walk(o):
    if isinstance(o, dict):
        for k, v in o.items():
            if k in ('suite_tail', 'stress_suite_tail') and isinstance(v, str):
                vals[v] = vals.get(v, 0) + 1
            else:
                walk(v)
    elif isinstance(o, list):
        for x in o: walk(x)
for dp, dn, fn in os.walk(root):
    for f in fn:
        if not f.endswith('.jsonl'): continue
        try:
            for line in open(os.path.join(dp, f), errors='replace'):
                if 'suite_tail' not in line: continue
                try: walk(json.loads(line))
                except Exception: pass
        except Exception: pass
n = len(vals); trail = [v for v in vals if v.endswith('\n') or v.split('\n')[-1].strip() == '']
print('distinct', n, 'trailing-empty-last', len(trail))
for v in list(vals)[:200]:
    last = v.split('\n')[-1]
    print(repr(last[-80:]), '| lines', v.count('\n')+1)
