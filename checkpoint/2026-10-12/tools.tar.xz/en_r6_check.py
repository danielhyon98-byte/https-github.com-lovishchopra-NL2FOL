import json
import re

BASE = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/arena/r6/"
for tid in ["en-t11", "en-t12"]:
    rec = json.load(open(BASE + "specialists/" + tid + ".json", encoding="utf-8"))
    source = rec["supplied_texts"][0]["text"]
    norm_source = re.sub(r"\s+", " ", source)
    quotes = re.findall(r'"([^"]+)"', rec["response_text"])
    print(tid, "quotes:", len(quotes))
    for q in quotes:
        parts = [p.strip() for p in q.split("/")]
        ok = all(re.sub(r"\s+", " ", p).rstrip(",.?!:;") in norm_source for p in parts)
        if not ok:
            print("  NOT FOUND:", repr(q))
    print("  fields:", sorted(rec.keys()))
