import json, os
BASE = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad"
CLR = BASE + "/clearance/c2"
spec = json.load(open(CLR + "/specialists/ess-p9c.json", encoding="utf-8"))
tasks = json.load(open(CLR + "/tasks.json", encoding="utf-8"))
task = [t for t in tasks if t["task_id"] == "ess-p9c"][0]
old = spec["response_text"]
parts = old.split("(d) [4]\n")
assert len(parts) == 2, "expected exactly one part (d) marker"
prefix = parts[0]
newd = open(BASE + "/round8-prep/ess-p9c-newd.txt", encoding="utf-8").read()
response = prefix + newd
handled = [{
    "flaw_id": "f1",
    "code": "INT-REQ-008",
    "handled": (
        "Changed. The old part (d) gave its judgement as one hedged sentence with no reasons. "
        "The new part (d) states an explicit judgement at an extent, with its condition ('worth including ... but not enough on its own, "
        "for storms of the kind recorded here'), and gives its reasons from material already in the answer: the runoff shares from part (b) "
        "(20.0% and 47.5%), the peak discharge values quoted from the Geography specialist (5.4 and 16.2 m3 s-1), and the built-up share "
        "(8% to 31%, attributed to the Geography specialist). No new figure was added. The two value-system views (ecocentric and technocentric) "
        "are described by what each view prioritises, not assigned to people. Part labels inside (d) (Strategy, Judgement and the view labels) "
        "were removed so the judgement reads as prose. Kept unchanged: the question and all its parts, the quoting task setting, the figures, "
        "the four quotations, parts (a) to (c), the next-step line and the sources line."
    ),
}]
out = dict(task)
out["response_text"] = response
out["feedback_handled"] = handled
os.makedirs(CLR + "/revisions", exist_ok=True)
with open(CLR + "/revisions/ess-p9c.json", "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=2)
print("written", CLR + "/revisions/ess-p9c.json", len(response))
