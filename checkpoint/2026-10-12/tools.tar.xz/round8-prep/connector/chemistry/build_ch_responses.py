import json, os

SRC = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2/tasks.json"
OUT = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad/clearance/c2/specialists"

responses = {}

responses["ch-t15"] = """
(a) Enthalpy change of the forward reaction [3]

N₂(g) + 3H₂(g) ⇌ 2NH₃(g)

Bonds broken: 1 × N≡N + 3 × H–H = 1 × 945 + 3 × 436 = 945 + 1308 = 2253 kJ [1]
Bonds formed: 6 × N–H (two NH₃ molecules, three N–H bonds each) = 6 × 391 = 2346 kJ [1]
ΔH = Σ(bonds broken) − Σ(bonds formed) = 2253 − 2346 = −93 kJ mol⁻¹ [1]

This value is for the reaction as written, which forms 2 mol of NH₃.

(b) Reason for the difference [1]

Average bond enthalpies are mean values taken over many compounds, and the calculation treats every species as a gas. The calculated value is therefore only an approximation of the true enthalpy change. [1]

(c) Limiting reactant and maximum volume of ammonia [3]

At the same temperature and pressure, equal volumes of gases contain equal numbers of molecules, so the volume ratio equals the mole ratio, N₂ : H₂ : NH₃ = 1 : 3 : 2.
Hydrogen needed for 600 cm³ of N₂ = 3 × 600 = 1800 cm³. Only 1500 cm³ of H₂ is available, so hydrogen is the limiting reactant. [1]
Check: nitrogen needed for 1500 cm³ of H₂ = 1500 ÷ 3 = 500 cm³. Since 600 cm³ is available, nitrogen is in excess.
Volume of NH₃ = 1500 cm³ H₂ × (2 ÷ 3) = 1000 cm³ [1]
Maximum volume of ammonia = 1.00 × 10³ cm³, at the same temperature and pressure. [1]

(d) Percentage yield [1]

percentage yield = actual yield ÷ theoretical yield × 100 = 150 cm³ ÷ 1000 cm³ × 100 = 15.0% [1]

(e) Equilibrium constant Kc at 700 K [3]

Concentration = amount ÷ volume, with V = 2.00 dm³:
[N₂] = 0.400 mol ÷ 2.00 dm³ = 0.200 mol dm⁻³
[H₂] = 1.20 mol ÷ 2.00 dm³ = 0.600 mol dm⁻³
[NH₃] = 0.200 mol ÷ 2.00 dm³ = 0.100 mol dm⁻³ [1]

Kc = [NH₃]² ÷ ([N₂][H₂]³) [1]
= (0.100)² ÷ (0.200 × 0.600³) = 0.0100 ÷ (0.200 × 0.216) = 0.0100 ÷ 0.0432 = 0.231 dm⁶ mol⁻² [1]

(f) Effect of an increase in temperature on Kc [2]

Kc decreases. [1]
The forward reaction is exothermic (ΔH is negative, as in part (a)). A rise in temperature shifts the position to the left, the endothermic direction, which absorbs the added heat. Fewer products and more reactants are present at equilibrium, so Kc falls. [1]

(g) Why high pressure and a moderate temperature are used [3]

High pressure: the position shifts to the right, the side with fewer gas molecules (2 mol of gas instead of 4 mol), which opposes the increase in pressure, so the equilibrium yield of ammonia increases. [1]
Higher pressure also increases the frequency of collisions between molecules, so the rate of reaction increases. [1]
Moderate temperature: a lower temperature would give a higher equilibrium yield, because the forward reaction is exothermic. However, fewer particles would then have energy at least equal to the activation energy, so the rate would be too slow. A moderate temperature gives a reasonable rate with an acceptable yield. [1]

If you work any of these parts yourself, paste your working and I will check it line by line.

Sources: your question (supplied text)
"""

responses["ch-p9b"] = """
Constants and data used: M(C) = 12.01, M(H) = 1.01, M(O) = 16.00 (from the question). Avogadro constant N_A = 6.02 × 10²³ mol⁻¹ (standard value). I assume the sucrose dissolved completely before the flask was made up to the mark.

(a) Molar mass of sucrose [1]

M(C₁₂H₂₂O₁₁) = 12(12.01) + 22(1.01) + 11(16.00) = 144.12 + 22.22 + 176.00 = 342.34 g mol⁻¹ [1]

(b) Concentration of the stock solution [2]

n(sucrose) = m ÷ M = 84.20 g ÷ 342.34 g mol⁻¹ = 0.245954 mol (unrounded) [1]
V = 250.0 cm³ = 0.2500 dm³
c(stock) = n ÷ V = 0.245954 mol ÷ 0.2500 dm³ = 0.98382 mol dm⁻³, so c(stock) = 0.984 mol dm⁻³ (3 s.f.) [1]

(c) Concentration of each diluted solution [2]

Each diluted solution is made up to 50.00 cm³, so c(diluted) = c(stock) × V(pipetted) ÷ 50.00 cm³. The unrounded stock concentration (0.98382 mol dm⁻³) is used. [1]
10.00 cm³: 0.98382 × (10.00 ÷ 50.00) = 0.19676 mol dm⁻³, so 0.197 mol dm⁻³ [1 for the values]
20.00 cm³: 0.98382 × (20.00 ÷ 50.00) = 0.39353 mol dm⁻³, so 0.394 mol dm⁻³
30.00 cm³: 0.98382 × (30.00 ÷ 50.00) = 0.59029 mol dm⁻³, so 0.590 mol dm⁻³
40.00 cm³: 0.98382 × (40.00 ÷ 50.00) = 0.78706 mol dm⁻³, so 0.787 mol dm⁻³

(d) Percentage uncertainty in the stock concentration [2]

Only the balance and flask uncertainties are used, as the question specifies.
Mass: 0.01 g ÷ 84.20 g × 100 = 0.0119% [1]
Volume: 0.30 cm³ ÷ 250.0 cm³ × 100 = 0.120%
For a quotient, the percentage uncertainties add: 0.0119% + 0.120% = 0.132%, so the percentage uncertainty is 0.13%. [1]

(e) Sucrose molecules in 1.00 cm³ of the most dilute solution [2]

The most dilute solution is the 10.00 cm³ dilution, with c = 0.19676 mol dm⁻³ (unrounded).
V = 1.00 cm³ = 1.00 × 10⁻³ dm³
n = c × V = 0.19676 mol dm⁻³ × 1.00 × 10⁻³ dm³ = 1.9676 × 10⁻⁴ mol [1]
N = n × N_A = 1.9676 × 10⁻⁴ mol × 6.02 × 10²³ mol⁻¹ = 1.18 × 10²⁰ molecules (3 s.f.) [1]
Using the rounded 0.197 mol dm⁻³ would give 1.19 × 10²⁰, so the unrounded value is carried.

(f) Why a volumetric flask is used [1]

A volumetric flask has a single calibrated mark and is designed to contain one precisely known volume, for example 250.0 cm³ ± 0.30 cm³ as in part (d). A measuring cylinder is less precise, so the volume of each solution, and therefore its concentration, would be less certain. [1]

Concentrations for the Biology student, in mol dm⁻³ (3 s.f.):
Stock solution: 0.984
Made from 10.00 cm³ of stock: 0.197
Made from 20.00 cm³ of stock: 0.394
Made from 30.00 cm³ of stock: 0.590
Made from 40.00 cm³ of stock: 0.787

If you want more practice, try part (e) for the 40.00 cm³ dilution.

Sources: your question (supplied text)
"""

tasks = json.load(open(SRC, encoding="utf-8"))
by_id = {t["task_id"]: t for t in tasks}
os.makedirs(OUT, exist_ok=True)
for tid in ["ch-t15", "ch-p9b"]:
    t = dict(by_id[tid])
    t["response_text"] = responses[tid].strip()
    path = os.path.join(OUT, tid + ".json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(t, f, ensure_ascii=False, indent=2)
    print(path)
