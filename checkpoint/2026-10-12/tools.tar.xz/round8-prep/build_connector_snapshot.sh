#!/bin/bash
# Snapshot of the agent-training connector's specialist definitions for the arena (Daniel, 17 Oct: "this is the updated
# repository from which from round 8 bug testing and fix process onwards you should refer to in creating the dummy
# specialist agents"). For each of the sixteen v4 knowledge bases: the "Instruction block to paste" from the slug's Claude
# Haiku 5.5 handoff (section 2 only; the builder sections are for people and builder sessions), the supplementary documents
# 01-04 and the shared answering core. Read-only on the connector clone; refreshed from origin first; commit recorded.
set -euo pipefail
D=/home/user/danielhyon98-byte/epinoic-agent-training-api-connector
OUT=$(cd "$(dirname "$0")" && pwd)/connector
git -C "$D" fetch -q --depth 1 origin HEAD && git -C "$D" reset -q --hard FETCH_HEAD
SHA=$(git -C "$D" rev-parse HEAD)
rm -rf "$OUT"; mkdir -p "$OUT/_shared"
cp "$D/agents/_shared/knowledge/00-answering-functionality-core.md" "$OUT/_shared/"
for kb in english-specialist english-a-literature english-a-lang-lit history economics business-management psychology geography language-b-spanish computer-science physics chemistry biology ess mathematics-aa mathematics-ai; do
  slug=$kb; [ "$kb" = language-b-spanish ] && slug=spanish-b
  mkdir -p "$OUT/$kb"
  awk '/\*\*Instruction block to paste:\*\*/{f=1} f&&/^```text/{s=1;next} s&&/^```/{exit} s{print}' "$D/agents/$slug/HANDOFF-CLAUDE-HAIKU-5-5.md" > "$OUT/$kb/instructions.txt"
  [ -s "$OUT/$kb/instructions.txt" ] || { echo "STOP: no instruction block for $slug"; exit 1; }
  cp "$D/agents/$slug/knowledge/"0[1-4]-*.md "$OUT/$kb/"
  [ "$(ls "$OUT/$kb/"0[1-4]-*.md | wc -l)" = 4 ] || { echo "STOP: $slug lacks 4 supplementary documents"; exit 1; }
done
printf '{"connector":"danielhyon98-byte/epinoic-agent-training-API-connector","commit":"%s","slug_map":{"language-b-spanish":"spanish-b"},"built":"%s"}\n' "$SHA" "$(date -u +%FT%TZ)" > "$OUT/SOURCE.json"
echo "connector snapshot $SHA: $(ls "$OUT" | grep -vc '^_\|SOURCE') specialists"
