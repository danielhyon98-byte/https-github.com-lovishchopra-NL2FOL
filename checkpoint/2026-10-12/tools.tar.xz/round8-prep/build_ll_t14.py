import json

base = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad"
tasks_path = base + "/clearance/c1/tasks.json"
response_path = base + "/round8-prep/ll-t14-response.txt"
out_path = base + "/clearance/c1/specialists/ll-t14.json"

with open(tasks_path, encoding="utf-8") as f:
    tasks = json.load(f)

matches = [t for t in tasks if t.get("task_id") == "ll-t14"]
assert len(matches) == 1, len(matches)
task = dict(matches[0])

with open(response_path, encoding="utf-8") as f:
    response_text = f.read().rstrip("\n")

task["response_text"] = response_text

with open(out_path, "w", encoding="utf-8") as f:
    json.dump(task, f, ensure_ascii=False, indent=2)
    f.write("\n")

# verify
with open(out_path, encoding="utf-8") as f:
    check = json.load(f)
assert check["task_id"] == "ll-t14"
assert check["response_text"] == response_text
for k in matches[0]:
    assert check[k] == matches[0][k], k
words = len(response_text.split("\n\n")[0].split())
print("keys:", sorted(check.keys()))
print("paragraph words:", words)
print("written:", out_path)
