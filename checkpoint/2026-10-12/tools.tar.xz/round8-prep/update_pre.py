"""Record in pre.json which specialists have written every standalone answer of round 8 (phase 2 skips them)."""
import json, os
S = '/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad'
d = json.load(open(S + '/clearance/c1/tasks.json')); ts = d['tasks'] if isinstance(d, dict) else d
by = {}
for t in ts:
    if not t.get('peer_of'):
        by.setdefault(t['kb'], []).append(t['task_id'])
def ok(tid):
    p = f"{S}/clearance/c1/specialists/{tid}.json"
    try:
        j = json.load(open(p)); return bool(str(j.get('response_text') or '').strip()) and j.get('task_id') == tid
    except Exception:
        return False
done = sorted(kb for kb, ids in by.items() if all(ok(i) for i in ids))
json.dump({"c1": {"tasks": ts, "deployedKbs": done}}, open(S + '/round8-prep/pre.json', 'w'))
print(f"{len(done)}/{len(by)} specialists done: {', '.join(done)}")
