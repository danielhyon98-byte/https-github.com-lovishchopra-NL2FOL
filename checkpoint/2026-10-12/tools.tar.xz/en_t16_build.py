import json, re, os
base = "/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad"
clear = os.path.join(base, "clearance/c3")
tasks = json.load(open(os.path.join(clear, "tasks.json"), encoding="utf-8"))
task = [t for t in tasks if t["task_id"] == "en-t16"]
assert len(task) == 1, len(task)
task = task[0]
resp = open(os.path.join(base, "en-t16-response.txt"), encoding="utf-8").read().strip()
source = task["supplied_texts"][0]["text"]
# check each double-quoted span in the analysis paragraph appears verbatim in the supplied text
para = resp.split("\n\nNext step:")[0]
quotes = re.findall(r'"([^"]+)"', para)
missing = []
for q in quotes:
    qq = q.strip().rstrip(",.").strip()
    inner = qq.strip("'")
    if inner and inner not in source:
        missing.append(q)
print("quotes checked:", len(quotes))
print("missing:", missing)
print("analysis words:", len(para.split()))
out = dict(task)
out["response_text"] = resp
os.makedirs(os.path.join(clear, "specialists"), exist_ok=True)
path = os.path.join(clear, "specialists", "en-t16.json")
with open(path, "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=2)
print(path)
