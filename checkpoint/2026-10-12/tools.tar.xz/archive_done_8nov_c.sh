#!/usr/bin/env bash
# 8 Nov: free disk by archiving finished round-8 fix outputs (r7-ovs-fix and contained-fix workflows done; landed as 5060a52).
# Waits for the running checkpoint build (it tars the scratchpad). Each directory is archived and the archive tested; the directory is removed only after that.
set -uo pipefail
S=/tmp/claude-0/-home-user/a7c3c8b5-0245-5e75-80f1-83ca77b220e6/scratchpad
OUT=$S/archives; mkdir -p "$OUT"
while pgrep -f "make_checkpoint.sh" >/dev/null; do sleep 20; done
mkdir -p "$OUT/summaries"
cp -p "$S/landing/r7test/summary.txt" "$OUT/summaries/r7test-summary.txt" 2>/dev/null
cp -p "$S/landing/r7test/contained-summary.txt" "$OUT/summaries/r7test-contained-summary.txt" 2>/dev/null
for d in r7fix landing/r7test; do
  [ -d "$S/$d" ] || continue
  name=$(echo "$d" | tr / _); a="$OUT/$name.tar.xz"
  if nice -n 19 tar -C "$S" -cf - "$d" | nice -n 19 xz -T1 -6 > "$a.part" && xz -t "$a.part" && tar -tJf "$a.part" >/dev/null; then
    mv "$a.part" "$a"; rm -rf "$S/$d"; echo "archived $d -> $(du -h "$a" | cut -f1)"
  else rm -f "$a.part"; echo "FAILED $d (left in place)"; fi
done
df -h / | tail -1
