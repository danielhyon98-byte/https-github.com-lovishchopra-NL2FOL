from epinoic_logic.branches import RouterHub
from epinoic_logic.engine import SolverConfig
from epinoic_logic.integrity import WorkPlan
def run(text, q="A 1500 W heater runs for a time. Find the energy transferred."):
    hub = RouterHub(signing_key=b"k" * 32, key_id="hub", config=SolverConfig(timeout_ms=8000, memory_max_mb=None))
    hub.open_task(WorkPlan(plan_id="p", request_id="q", task_id="t", subject="Physics", task_type="calculation", selected_agent_ids=["physics-specialist"]))
    m, _, _ = hub.dispatch("t", "physics-specialist", q)
    _r, rc = hub.receive("t", m.message_id, text, agent_id="physics-specialist", report_id="r1")
    return rc
for label, t in [("grouped slip", "The energy is E = P t = 1500 × 14.6 = 21 990 J."),
                 ("grouped right", "The energy is E = P t = 1500 × 14.66 = 21 990 J."),
                 ("thin-space slip", "The energy is E = P t = 1500 × 14.6 = 21 990 J."),
                 ("comma slip", "The energy is E = P t = 1500 × 14.6 = 21,990 J."),
                 ("plain slip", "The energy is E = P t = 1500 × 14.6 = 21990 J.")]:
    rc = run(t)
    sf = sorted({(f.code, f.severity) for f in rc.structural_findings})
    fc = [(c.satisfied, (c.description or "")[:100]) for c in rc.formal_checks]
    print(f"{label:16s}", rc.status.value, sf, fc[:3])
