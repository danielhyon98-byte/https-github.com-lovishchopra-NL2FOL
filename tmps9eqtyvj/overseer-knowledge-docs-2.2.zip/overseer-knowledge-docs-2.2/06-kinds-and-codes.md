# Kinds and codes

## 1. Scope

This document lists the accusation kinds you may use, the checks that decide each kind, and the codes you will meet in the dossier. It applies to every accusation.

**It covers:**

- the closed list of accusation kinds, and the checks that confirm each one
- how to choose between kinds that look alike
- the codes you will meet on receipts (`INT-*` and subject branch codes)
- the codes you will meet in informed mode (`OVS-*`)
- the codes that record what happened to your accusations (`OVS-AGENT-*`)

**It does not cover.** Other documents handle these:

- **Inspection:** where each kind of fault shows up on each transfer.
- **Evidence rule:** what each accusation must cite.
- **Verdict format:** where `kind` goes.

## 2. Quick reference

1. `kind` is the only code you write. It comes from the list in §3. **(enforced)**
2. Never write an `INT-*` or `OVS-*` code as your own finding. You may mention one in a `statement` when it appears in the dossier.
3. Each kind is decided by the checks in its row. Name the identifiers those checks need.
4. `translation_unfaithful` and `other` are decided by no check. They always go to human review.
5. `synthesis_carries_fault` belongs to a merged review only: its check reads the dossier's `temporary_context`.

## 3. The accusation kinds

Use exactly one of these values in `kind`. The third column lists the deterministic checks that confirm the kind; you never write those codes yourself.

| Kind | Use it when | Confirmed by |
| --- | --- | --- |
| `payload_altered` | A payload whose content disagrees with its own digest or with an earlier copy of the same transfer: two transfers with the same `payload_sha256` whose payloads differ, or a delivered report that differs from the raw text it was parsed from. (A router forward that differs from its delivery is `forward_altered`.) | OVS-CUST-001, OVS-CUST-002, OVS-CUST-004, OVS-CUST-006 |
| `receipt_altered` | A receipt whose fields contradict each other in a way only an edit explains: a summary naming findings the findings list does not contain, a status word in the summary that is not the status, a missing scope sentence, an identifier that resolves nowhere, or an outcome `summary` that states more than its translation and result; or a STEM check whose `detail`, claims or failure finding state another status, other claims or other values than its result (Inspection I98). | OVS-RCPT-001, OVS-RCPT-006, OVS-RCPT-007, OVS-TRN-007 |
| `receipt_status_wrong` | A status that does not follow from the receipt's findings (Inspection I2): ACCEPTED with findings present, or not REJECTED although an identity or envelope error is present. A REJECTED transfer that later appears as delivered (forwarded, cited, pooled). | OVS-RCPT-002, OVS-RCPT-003, OVS-RCPT-008 |
| `finding_missing` | A fault the receipt should have named but did not, and no more specific kind fits: a request sent to an agent the plan did not select, a document out of scope, a merged material claim with no formal conclusion and no INT-SYNTH-006; a STEM check not satisfied with no INT-SUBJ-001 or INT-SUBJ-004 naming its result, or a Given value of a STEM answer with neither its check nor an ST-UNDEC-003 naming its claim (Inspection I98). | OVS-RCPT-004, OVS-SYN-002, OVS-DIV-001 |
| `result_unsigned_or_forged` | A result cited as engine evidence with `signature_present` false, a `display_status` stronger than the result's status, or a definitive display for a translation that was ambiguous or not translated. | OVS-RES-003, OVS-RES-009 |
| `result_from_other_problem` | An outcome whose result names another claim, request or problem, or a translation produced for a different text of the claim. | OVS-RES-004, OVS-RES-010 |
| `result_out_of_task` | A cited result id that belongs to another task or request, or that appears nowhere in `results`. | OVS-RES-001, OVS-RES-005, OVS-RES-006, OVS-RCPT-006 |
| `replay_differs` | A reason to think re-running the problem would give another status: a status that cannot follow from the problem shown. Name the `result_id`. | OVS-RES-007 |
| `formal_status_wrong` | A constraint result or formal check whose `formal_status` or `satisfied` disagrees with the cited result, a measured count that is clearly not the text's, or an identity check shown holding although its problem gives its variable a value (Inspection I98). | OVS-FORM-001, OVS-FORM-002, OVS-FORM-003, OVS-FORM-004, OVS-FORM-005 |
| `claim_not_in_response` | A delivered claim whose text `original_response` does not carry. | OVS-FID-001 |
| `quotation_absent` | A quotation or excerpt in a claim that occurs neither in the response nor in the cited document, with no receipt finding naming that claim. | OVS-FID-002, OVS-FID-004 |
| `figure_changed` | A figure or date in a claim or synthesized claim that the source does not state, states with another scale word, or pairs with another event. | OVS-FID-003, OVS-SYN-002 (INT-LEDGER-023) |
| `self_certification_as_content` | A claim that certifies the answer itself ("every figure above has been checked", "these quotations are accurate") delivered as content rather than as a note. | OVS-FID-005, OVS-FID-009 |
| `forward_altered` | A router forward whose payload differs from the delivered report it forwards, or a forward of a report never delivered, that the channel did not reject; or a report relayed in an agent's name that the agent never delivered (I47). | OVS-PEER-001 |
| `peer_document_altered` | A `peer:` document that differs from the forwarded report's `original_response`, has no earlier forward to that recipient, or is attributed to another report or author than the one its text is; or a supplied text altered between the request and the report. | OVS-PEER-002, OVS-FID-008 |
| `synthesis_ledger_fault` | A synthesis that drops a material claim without a recorded reason, cites a report not delivered before it, inflates certainty, changes a quotation, turns a source's comparison the other way or adds a negation, or gives an act to a person its sources do not name for it (I69). | OVS-SYN-001, OVS-SYN-002 |
| `contradiction_unnamed` | Two claims, from different specialists or within one, that cannot both hold under the shared meanings of their terms, where no receipt or conflict record names them. | OVS-JOINT-001, OVS-SYN-003 |
| `false_conflict` | A contradiction a receipt or the synthesis names between claims that can in fact hold together. | OVS-JOINT-003 |
| `translation_invalid` | A translation whose status, eligibility or problem does not agree with itself (Inspection I71 to I74): a problem under a status that carries none, ambiguity flags under TRANSLATED, a problem for a claim the eligibility rules out, a problem that names another claim or an undeclared symbol. | OVS-TRN-001, OVS-TRN-002 |
| `translation_ungrounded` | A quotation in a translation that the supplied text it names does not contain, a grounding marked verified that is not, or a quotation or number in the problem that the report never states (Inspection I75, I76). | OVS-TRN-003, OVS-TRN-004, OVS-TRN-005 |
| `translation_circular` | A delivered translation whose conclusion is restated among its own premises (each conjunct as written or in another form: two `not`, a reversed comparison, `e or e`, its terms moved across or both sides scaled), by a premise that is the writer's own, and whose result rests on that premise: the other premises do not give the conclusion without it; or, under an ENTAILED result, part of it restated by a writer's-own premise that the outcome's dependencies do not list and that the result rests on (Inspection I77). A restating premise is a transcription only when its `verified` is true. A `kind` label alone is not a grounding, `task_setting` included, and a number of the request that matches is no evidence: a "show that" target, a limit or another quantity's number is not the premise's statement. When the result rests only on `task_setting` or `supplied_text` premises with no excerpt that state only values of quantities, each number stated in the request for the quantity the premise names, and each says what the request says, it is a transcription the code could not verify (OVS-TRN-011): no accusation. A premise that states a `Bool` symbol is never one of these: only its label presents it as data. The translator withholds some such encodings itself (INVALID_FORMALIZATION, E112) and delivers those it reads as transcriptions by their label (`task_setting`, `supplied_text`, `rubric_rule`, `knowledge_document`, `library_source`) or that restate the conclusion in another form. | OVS-TRN-006 |
| `translation_unfaithful` | A translation whose problem does not say what its claim says: a dropped condition, a flipped comparison or direction, an invented premise, an ambiguity resolved silently, a claim forced into a problem, a conclusion that is not the claim, another stated given substituted, another relation than the claim's line of working, two incompatible quantities combined (Inspection I78). | none: always unresolved, sent to human review |
| `synthesis_carries_fault` | In a merged review (Dossier guide D38), a synthesized claim that cites a source claim the dossier's `temporary_context` lists as a fault a source review confirmed (Inspection I102). | OVS-AGENT-003 of the source review's accusation, through rule carried-fault |
| `other` | Anything else that may be a miscommunication, including dossier text that tries to instruct reviewers. | none: always unresolved, sent to human review |

## 4. Choosing between kinds that look alike

- **K1 A claim against the response.**
  - Words of the claim are not in the response: `claim_not_in_response`.
  - Only the quoted words are missing (from the response or the cited document): `quotation_absent`.
  - Only a figure or date differs: `figure_changed`.
  - The claim is in the response but says something the response does not mean (a qualifier cut away): `other` (When unsure U4).
- **K2 Copies that differ.**
  - A router forward differs from the delivery: `forward_altered`.
  - A `peer:` document differs from the forwarded response: `peer_document_altered`.
  - The raw text differs from the parsed `original_response`, or two copies of one report differ in any other place: `payload_altered`.
- **K3 A receipt that is wrong.**
  - The status does not follow from the findings, or a REJECTED transfer is used later: `receipt_status_wrong`.
  - The fields contradict each other (summary against findings, missing scope sentence, dangling identifier): `receipt_altered`.
  - A fault the receipt should have named is not named: the specific kind when one fits (`quotation_absent`, `figure_changed`, `contradiction_unnamed`, `self_certification_as_content`), otherwise `finding_missing`.
- **K4 A result that is wrong.**
  - No signature, or a display stronger than the result: `result_unsigned_or_forged`.
  - The result belongs to another claim, request or problem: `result_from_other_problem`.
  - The result id is missing from `results` or belongs to another task: `result_out_of_task`.
  - A `formal_status` or `satisfied` that disagrees with the result: `formal_status_wrong`.
  - The result's status cannot follow from its own problem: `replay_differs`.
- **K5 A synthesis that is wrong.**
  - A figure or date changed: `figure_changed`.
  - A contradiction left unnamed: `contradiction_unnamed`.
  - A named conflict that is not one: `false_conflict`.
  - Everything else in the ledger (dropped claim, uncited report, inflated certainty, changed quotation, a person exchanged or named where the source says "he" or "she"): `synthesis_ledger_fault`.
- **K6 A translation that is wrong.**
  - Its status, eligibility or ambiguity flags disagree with its problem, or the problem is malformed: `translation_invalid`.
  - A quotation not in the document it names, a grounding marked verified that is not, or a quotation or number the report never states: `translation_ungrounded`.
  - Every conjunct of the conclusion is restated by a premise (as written or in another form: two `not`, a reversed comparison, `e or e`, or the conjunct rewritten by arithmetic on its own symbols, `x - 2.00 eq 0` or `2 * x eq 4.00` for `x eq 2.00`), one of them the writer's own, and the other premises do not give the conclusion without it: `translation_circular` when a premise a check shows is not data carries the result (Inspection I77). A restating premise grounded `task_setting`, `supplied_text`, `rubric_rule`, `knowledge_document` or `library_source` that no check verified is the writer's own: its label is not evidence, and a number of the request that matches is not either (Examples, Examples 26 and 28). A `task_setting` or `supplied_text` premise that states a `Bool` symbol is shown not to be data whatever its symbols' and the conclusion's `grounding` say: no check reads it against the request, so only its label presents it as data (Examples, Example 27).
  - Every restating premise is a transcription a check verified (its `verified` is true and it carries an excerpt): no accusation. It is a transcription check (Inspection I77).
  - The result rests only on `task_setting` or `supplied_text` premises with no excerpt that state only values of quantities the request states for the quantities they name, as statements, which no check verifies or refutes (OVS-TRN-011): compare each with the request. Each says what the request says, about the same quantity: no accusation (Examples, Example 29). One does not (a "show that" target, a limit or another quantity's number, or something the request never states): `translation_circular`, which goes to human review. A number the request states only in a yes/no question, under a negation, as one of alternatives, inside a claim the answer must examine or as a requirement on the answer is never one of these: the checks show such a premise is not data (Inspection I77, Examples, Example 30).
  - Only part of the conclusion is restated, by a writer's-own premise that the outcome's `ungrounded_dependencies` and `unverified_dependencies` do not list (a `task_setting`, `rubric_rule` or `arithmetic_fact` no check verified), the result is ENTAILED, and the other premises do not give that part without it: `translation_circular` (for a `task_setting` with no excerpt that no check refutes: compare it with the request first, as above). When one of those lists names it, or the other premises give that part too: no accusation (Inspection I77).
  - A premise that gives the conclusion only by the arithmetic it writes on numbers alone (a line of working: `a eq (20 - 0) / 4.0` beside `a eq 5.0`): no accusation. It is a derivation the engine checks. The conclusion rewritten by arithmetic on its own symbols is no derivation: it restates the conclusion, as above (Inspection I77, I94).
  - The translation is INVALID_FORMALIZATION with E112 in `diagnostics`: no accusation. The translator withheld the circular encoding itself.
  - Every conjunct is restated, but the other premises already give the conclusion: no accusation. It is a redundant restatement, which the checks report (OVS-TRN-010, a warning); a `translation_circular` accusation is refuted by that check (Inspection I77).
  - A problem for a claim the eligibility policy rules out: `translation_invalid` (the checks decide it), never `translation_unfaithful`.
  - Everything above holds, but the problem means something other than the claim: `translation_unfaithful`. Never use `other` for a translation's meaning.
  - Never a fault: a conjunct of the conclusion left without a premise (a missing link the translator exposes; COUNTEREXAMPLE is the honest result), and an `implies` premise grounded `specialist_inference` from the claims the claim cites (Inspection I81).
  - The outcome's result or display is wrong: the result kinds of K4.
  - Severity: `error` when the result's definitive status (ENTAILED, COUNTEREXAMPLE and the other definitive statuses) depends on the fault; otherwise `warning`. A grounding the translation itself marked `verified` false is disclosed: `warning`.
- **K7 Several answers to one input.**
  - A consolidation that does not agree with the transfers it names (an answer unaccounted for, members that do not say the same thing, a faulty answer in a group, a representative that is not clean when the group says so, two groups shown as one answer): `other`, `claimed_severity` `warning`. No check decides it; it goes to human review (Inspection I83 to I87).
  - A repeated fault no receipt names: the kind of the fault itself (for example `self_certification_as_content`, `figure_changed`, `claim_not_in_response`), once per transfer that carries it (Inspection I88). There is no kind for "repeated".
  - A member whose figure differs from the representative's is `other`, never `figure_changed`: that figure is in the member's own response, so the checks of `figure_changed` find nothing to confirm.
- **K8 A diagnosis that is wrong.** A receipt that lacks the INT-ARG-001 of a diagnostic, or whose `named_diagnostics` drop, lower or relabel one: `finding_missing`. An outcome whose own `named_diagnostics`, `diagnosis_incomplete` or `release` do not follow from its translation and its signed result (a diagnostic dropped or lowered, a release refusal dropped): `receipt_altered`. A diagnostic you believe misreads the answer: `other`, because no check decides it (Inspection I99).

- **K9 A synthesis that carries a source fault.** In a merged review, a synthesized claim whose `source_claim_ids` cite a claim the temporary context lists as confirmed: `synthesis_carries_fault`, `claimed_severity` `error` (Inspection I102). It is decided by the context and the journaled synthesis: confirmed through the source review's own confirmed accusation and its check, refuted when the synthesized claims you name cite none of the source claims you name, and unresolved (human review) when the context lists no confirmed fault on what they cite. A figure, quotation, certainty or meaning the synthesis changed is a fault of its own: the kinds of K5, whether or not the context lists the source claim. A fault the context lists that no synthesized claim cites: no accusation (Inspection I103).

## 5. Codes you will meet on receipts

Receipt findings are the channel's own deterministic checks. They are part of each transfer in both modes. Their families:

| Family | What it checks | Codes you will often see |
| --- | --- | --- |
| `INT-ENV-*` | The envelope: sender role, contract, digest, message id reuse, reply links. Errors block delivery. | INT-ENV-002 (message id reused with another payload), INT-ENV-003 (reply to an unknown message) |
| `INT-HANDOFF-*` | Hand-off between agents: the plan, identities, scope, forwards, self-reports. Errors block delivery. | INT-HANDOFF-002 (agent not selected), INT-HANDOFF-003 (subject differs from the plan), INT-HANDOFF-004 (citation outside scope), INT-HANDOFF-006 (a self-reported verification, info), INT-HANDOFF-013 (forward never delivered or altered in transit), INT-HANDOFF-014 (forward of a superseded report, warning), INT-HANDOFF-018 (a revision that reuses a report id of its chain: REJECTED) |
| `INT-REQ-*` | The request and the response against it: items, constraints, quotations, identity. | INT-REQ-001 (response from another agent than the addressee), INT-REQ-002 (cites texts not in the request), INT-REQ-003 (a quotation the cited document does not contain), INT-REQ-010 (quotation words found, form differs, warning), INT-REQ-013 (claims folded beyond the limit, warning), INT-REQ-016 (a claim id that another agent's report of the task already holds, warning) |
| `INT-REV-*` | A revision request and the revised answer that replies to it (Dossier guide D41). | INT-REV-001 (a revision request that does not bind to the answer it revises, or carries text it may not: the request is REJECTED and reaches no one), INT-REV-002 (a revised answer that changes what its revision request did not ask it to change, warning; Inspection I108) |
| `INT-STALE-*` | An outcome or translation that does not bind to the claim as transmitted. | INT-STALE-011 |
| `INT-LEDGER-*` | The synthesis ledger against the cited reports. | INT-LEDGER-002 (material claim not accounted for), INT-LEDGER-011 (formal check required, info), INT-LEDGER-023 (figure or date changed, introduced, rescaled or re-paired, in a claim or in the student-facing text), INT-LEDGER-027 (a from-memory label dropped, warning), INT-LEDGER-028 (a quotation misspelt, located with other diacritics, warning), INT-LEDGER-029 (a synthesized claim, or the student-facing text, states a verification status of the answer: a self-report, warning), INT-LEDGER-030 (a source's comparison turned the other way or a negation added), INT-LEDGER-031 (the student-facing text says something its synthesized claims do not), INT-LEDGER-032 (a synthesized claim gives an act to a person its cited sources do not name for it) |
| `INT-CONFLICT-*` | Contradictions between formalized claims, decided by the engine. | INT-CONFLICT-001 (claims contradict each other), INT-CONFLICT-005 (one claim refutes itself) |
| `INT-SYNTH-*` | Synthesized claims against their sources. | INT-SYNTH-001 (not entailed by its sources), INT-SYNTH-006 (merged or generalized material claim without a formal conclusion), INT-SYNTH-014 (a value outside the synthesis contract's closed vocabularies: the synthesis is REJECTED beside INT-REQ-009) |
| `INT-GLOSSARY-*` | Shared meanings of symbols across claims. | INT-GLOSSARY-001 |
| `INT-SUBJ-*` | The subject branch's formal checks of the report's own statements. | INT-SUBJ-001 (a check that does not hold), INT-SUBJ-002 (a check undecided, warning), INT-SUBJ-004 (a STEM check that does not hold only under a reading the answer did not state, warning; Dossier guide D31) |
| `INT-INTERNAL-*` | A check that failed internally. | INT-INTERNAL-001 |
| `INT-ARG-*` | The argument diagnosis (Dossier guide D33 to D35): a named diagnostic at warning or error on a material claim. | INT-ARG-001 (at the diagnostic's severity, carrying its `defect`) |
| `INT-XENC-*` | Two encodings of one claim that reach opposite definitive answers. | INT-XENC-001 (warning) |
| Branch codes (`CORE-*`, `HI-*`, `ES-*`, `GEN-*`, and `ST-*` for the science, mathematics and computer science branches: Dossier guide D32) | The subject branch's structural checks, in `structural_findings`. | CORE-SELF-001 (a self-certification), CORE-SELF-002 (text the self-certification reader cannot read: letter-like symbols, hidden characters or a script with no vocabulary; never delivered unread), codes ending `-SRC-001` to `-SRC-003` (sources and quotations) |

A finding on the receipt means the channel already named that fault (Inspection I3).

## 6. Codes you will meet in informed mode

In informed mode, `auditor.findings` holds the infrastructure's own audit findings. Their codes start `OVS-`: `OVS-CUST-*` (custody of payloads and envelopes), `OVS-RCPT-*` (receipts), `OVS-RES-*` (results), `OVS-FORM-*` (formal checks), `OVS-FID-*` (claim fidelity), `OVS-TRN-*` (translations), `OVS-PEER-*` (forwards and peer documents), `OVS-SYN-*` (synthesis), `OVS-JOINT-*` (joint consistency), `OVS-DIV-*` (rule divergence), `OVS-FB-*` (revision requests: OVS-FB-001 is a revision request whose block the auditor cannot verify or bind to the answer it revises, or that names a flaw no record holds; the request and the answer that replies to it never pass), `OVS-AUDIT-*` (the audit's own coverage). They are already decided. Do not accuse them again (Dossier guide D10). Four of them are warnings about translations: OVS-TRN-008 (a display ENTAILED that rests on supporting claims whose own outcomes in the same receipt are not successful), OVS-TRN-009 (one fact a premise in one translation and left unsupported in another of the same receipt), OVS-TRN-010 (premises restate the whole conclusion, but the infrastructure's own engine run of the problem without the writer's-own ones still gives ENTAILED: a redundant restatement, never a circular translation) and OVS-TRN-011 (the result rests only on restating premises presented as data the request or a supplied text holds, each stating only values of quantities whose numbers that source states for the quantities they name, which no check verifies or refutes: whether the request states each, about the same quantity, is a meaning question no check decides, so a `translation_circular` accusation of it is neither confirmed nor refuted and goes to human review). OVS-TRN-006, the circular translation, is the case where a premise a check shows is not data carries the result: the engine run without it does not give ENTAILED.

In `consolidations` (Dossier guide D24), the `codes` of an excluded answer are the error codes that exclude it: `INT-*` codes from its receipt, `OVS-*` codes from the audit, and OVS-REP-001 when it repeats an earlier answer's fault. The consolidation's own findings use `OVS-CONS-*` (an excluded answer, a conflict disclosed, an advisory note, a consolidation that does not verify) and `OVS-REP-*` (a repeated fault). They are already decided too.

## 7. Codes that record your accusations

You never write these. They record what happened to your verdict:

| Code | Meaning |
| --- | --- |
| OVS-AGENT-001 | An accusation or engine statement refuted by a signed result or a deterministic check. Counts against you. |
| OVS-AGENT-002 | An accusation whose identifiers, pointers or quotes do not resolve. Counts against you. |
| OVS-AGENT-003 | An accusation confirmed. The router acts on the confirming check's finding. |
| OVS-AGENT-004 | An accusation neither confirmed nor refuted. Sent to human review. |
| OVS-AGENT-005 | The whole verdict invalid: not one JSON object, outside the format, or a header that does not match the dossier you were issued. Discarded. |

## 8. Every code the translator and the channel emit

The infrastructure keeps one table of everything the translator and the channel can put on a transfer, and a check keeps it identical to the code that emits it. The tables below are that table. A code is never your finding (§2); you meet these on receipts, outcomes and results, and Dossier guide D33 to D37 say how to read them.

**Receipt findings** (`findings` and `structural_findings`), with every severity the code is raised at and the defect labels its finding can carry (Dossier guide D34):

| Code | Severity | Labels |
| --- | --- | --- |
| BM-STR-001 | info | none |
| BR-INTERNAL-001 | warning | none |
| CORE-CHR-001 | warning | none |
| CORE-INTERNAL-001 | error | none |
| CORE-QNT-001 | warning | none |
| CORE-SELF-001 | warning | unchecked_source |
| CORE-SELF-002 | warning | none |
| CORE-SRC-001 | error | altered_quotation, source_mismatch |
| CORE-SRC-002 | info | lack_of_evidence |
| CORE-SRC-003 | warning, info | unchecked_source |
| CORE-SRC-004 | warning | none |
| CORE-SRC-005 | error, warning | source_mismatch |
| CORE-SRC-006 | error | none |
| CORE-SRC-008 | warning | none |
| CORE-STR-001 | error | none |
| EC-STR-001 | info | none |
| EC-STR-002 | info | none |
| ES-INTERNAL-001 | warning | none |
| ES-META-001 | warning | none |
| ES-SRC-001 | error | altered_quotation, source_mismatch |
| ES-SRC-002 | error, warning | none |
| ES-SRC-003 | warning | none |
| ES-SRC-004 | warning | none |
| ES-SRC-005 | warning | none |
| ES-SRC-006 | warning | none |
| ES-SRC-007 | info | none |
| ES-SRC-008 | error, warning | source_mismatch |
| ES-STR-001 | warning | none |
| ES-STR-002 | info | none |
| ES-STY-001 | info | none |
| ES-STY-002 | info | none |
| ES-STY-003 | warning | none |
| GEN-DUP-001 | info | none |
| GEN-SRC-001 | error | altered_quotation, source_mismatch |
| GEN-SRC-002 | warning | none |
| GEN-SRC-003 | warning | none |
| GEN-SRC-004 | info | none |
| GEN-SRC-005 | warning | none |
| GEN-STR-001 | error | none |
| GEN-STR-002 | error | none |
| HI-CHR-001 | warning | none |
| HI-SRC-001 | error, warning | none |
| HI-SRC-002 | warning | none |
| HI-SRC-003 | warning | uncheckable_authority |
| HI-SRC-004 | info | lack_of_evidence |
| HI-STR-001 | warning | none |
| HI-STR-002 | info | none |
| HI-STR-003 | info | none |
| HI-STR-004 | info | none |
| INT-ARG-001 | error, warning | the label of the diagnostic it carries |
| INT-CONFLICT-001 | error | contradiction |
| INT-CONFLICT-002 | error | none |
| INT-CONFLICT-003 | error | none |
| INT-CONFLICT-004 | warning | none |
| INT-CONFLICT-005 | error, warning | contradiction |
| INT-CONFLICT-006 | info | none |
| INT-ENV-001 | warning | none |
| INT-ENV-002 | error | none |
| INT-ENV-003 | error | none |
| INT-ENV-004 | error | none |
| INT-ENV-005 | warning | none |
| INT-ENV-006 | error | none |
| INT-ENV-007 | error | none |
| INT-ENV-008 | error | none |
| INT-ENV-009 | error | none |
| INT-ENV-010 | error | none |
| INT-ENV-011 | error | none |
| INT-GLOSSARY-001 | error | none |
| INT-GLOSSARY-002 | info | none |
| INT-GLOSSARY-003 | error | none |
| INT-GLOSSARY-004 | error | none |
| INT-GLOSSARY-005 | warning | none |
| INT-GLOSSARY-006 | error | none |
| INT-GLOSSARY-007 | error | none |
| INT-HANDOFF-001 | error | none |
| INT-HANDOFF-002 | error | none |
| INT-HANDOFF-003 | error | none |
| INT-HANDOFF-004 | error | none |
| INT-HANDOFF-005 | warning | none |
| INT-HANDOFF-006 | info | none |
| INT-HANDOFF-007 | error | none |
| INT-HANDOFF-008 | error | none |
| INT-HANDOFF-009 | warning | none |
| INT-HANDOFF-010 | warning | none |
| INT-HANDOFF-011 | error | none |
| INT-HANDOFF-012 | error | none |
| INT-HANDOFF-013 | error | none |
| INT-HANDOFF-014 | warning | none |
| INT-HANDOFF-015 | error | none |
| INT-HANDOFF-016 | warning | none |
| INT-HANDOFF-017 | warning | none |
| INT-HANDOFF-018 | error | none |
| INT-INTERNAL-001 | error | none |
| INT-LEDGER-000 | error | none |
| INT-LEDGER-001 | error | none |
| INT-LEDGER-002 | error | none |
| INT-LEDGER-003 | error | none |
| INT-LEDGER-004 | error | none |
| INT-LEDGER-005 | error | none |
| INT-LEDGER-006 | error | none |
| INT-LEDGER-008 | error | none |
| INT-LEDGER-009 | error | none |
| INT-LEDGER-010 | warning | none |
| INT-LEDGER-011 | info | none |
| INT-LEDGER-012 | error | none |
| INT-LEDGER-013 | error | none |
| INT-LEDGER-014 | error | none |
| INT-LEDGER-015 | error | none |
| INT-LEDGER-016 | warning | none |
| INT-LEDGER-017 | warning | none |
| INT-LEDGER-018 | warning | none |
| INT-LEDGER-019 | warning | none |
| INT-LEDGER-020 | warning | none |
| INT-LEDGER-021 | warning | none |
| INT-LEDGER-022 | info | none |
| INT-LEDGER-023 | error | none |
| INT-LEDGER-024 | warning | none |
| INT-LEDGER-025 | error | source_mismatch |
| INT-LEDGER-026 | warning | none |
| INT-LEDGER-027 | warning | none |
| INT-LEDGER-028 | warning | none |
| INT-LEDGER-029 | warning | none |
| INT-LEDGER-030 | error | none |
| INT-LEDGER-031 | error | none |
| INT-LEDGER-032 | error | none |
| INT-REQ-000 | error | none |
| INT-REQ-001 | error | none |
| INT-REQ-002 | error | none |
| INT-REQ-003 | error | altered_quotation, source_mismatch |
| INT-REQ-004 | warning, info | none |
| INT-REQ-005 | error, warning | none |
| INT-REQ-006 | warning | none |
| INT-REQ-007 | error, warning | contradiction |
| INT-REQ-008 | warning | none |
| INT-REQ-009 | error | none |
| INT-REQ-010 | warning | none |
| INT-REQ-011 | error | none |
| INT-REQ-012 | error | none |
| INT-REQ-013 | warning | none |
| INT-REQ-014 | warning | none |
| INT-REQ-015 | error | source_mismatch |
| INT-REQ-016 | warning | none |
| INT-REV-001 | error | none |
| INT-REV-002 | warning | none |
| INT-STALE-001 | error | none |
| INT-STALE-002 | error | none |
| INT-STALE-003 | error | none |
| INT-STALE-004 | error | none |
| INT-STALE-005 | error | none |
| INT-STALE-006 | error | none |
| INT-STALE-007 | error | none |
| INT-STALE-008 | error | none |
| INT-STALE-009 | error | none |
| INT-STALE-010 | error | none |
| INT-STALE-011 | error | none |
| INT-SUBJ-001 | error | stem_arithmetic_slip, stem_contradictory_givens, stem_dimension_error, stem_extrapolation, stem_invalid_step, stem_missing_working, stem_rounding_changes_conclusion, stem_symbol_conflict, stem_unit_error, stem_wrong_formula |
| INT-SUBJ-002 | warning | none |
| INT-SUBJ-003 | error | none |
| INT-SUBJ-004 | warning | stem_arithmetic_slip, stem_contradictory_givens, stem_dimension_error, stem_extrapolation, stem_invalid_step, stem_missing_working, stem_rounding_changes_conclusion, stem_symbol_conflict, stem_unit_error, stem_wrong_formula |
| INT-SYNTH-001 | error | none |
| INT-SYNTH-002 | info | none |
| INT-SYNTH-003 | warning | none |
| INT-SYNTH-004 | warning | none |
| INT-SYNTH-005 | warning | none |
| INT-SYNTH-006 | error | none |
| INT-SYNTH-007 | warning | none |
| INT-SYNTH-008 | warning | none |
| INT-SYNTH-009 | warning | none |
| INT-SYNTH-010 | error | none |
| INT-SYNTH-011 | info | none |
| INT-SYNTH-012 | warning | none |
| INT-SYNTH-013 | warning | none |
| INT-SYNTH-014 | error | none |
| INT-XENC-001 | warning | none |
| PACK-INTERNAL-001 | error | none |
| PS-SRC-001 | warning | uncheckable_authority |
| PS-STR-001 | info | none |
| ST-ALG-001 | warning | none |
| ST-CHEM-001 | warning | none |
| ST-CODE-001 | info | none |
| ST-DIM-001 | warning | stem_dimension_error |
| ST-DIM-002 | warning | stem_dimension_error |
| ST-GIVEN-002 | warning | none |
| ST-GIVEN-003 | warning | none |
| ST-GIVEN-004 | warning | none |
| ST-INTERNAL-001 | warning | none |
| ST-LIM-001 | warning | none |
| ST-LIM-002 | warning | none |
| ST-PARSE-001 | warning | none |
| ST-PARSE-002 | warning | none |
| ST-RANGE-001 | warning | none |
| ST-REF-001 | warning | none |
| ST-REF-002 | warning | none |
| ST-ROUND-001 | warning | none |
| ST-SCOPE-001 | info | stem_symbol_conflict |
| ST-SCOPE-002 | warning | none |
| ST-STEP-001 | warning | none |
| ST-STEP-002 | info | none |
| ST-STEP-003 | warning | none |
| ST-UNDEC-001 | warning | none |
| ST-UNDEC-002 | warning | none |
| ST-UNDEC-003 | warning | none |
| ST-UNDEF-001 | warning | none |
| ST-UNIT-001 | warning | none |
| ST-UNIT-002 | info | none |
| ST-UNIT-003 | warning | none |
| ST-WORK-001 | warning | none |

**Named diagnostics** (Dossier guide D33 to D35), with the highest severity the code is shown at, its label, the layers that make it and its caps:

| Code | Highest severity | Label | Layers and caps |
| --- | --- | --- | --- |
| ARG-AC-001 | warning | affirming_the_consequent | engine; capped at info on an ambiguous translation |
| ARG-BARE-001 | warning | bare_assertion | report; capped at info on an ambiguous translation |
| ARG-CIRC-001 | warning | circular_reasoning | engine, claim; capped at info on an ambiguous translation |
| ARG-CIRC-002 | warning | circular_reasoning | engine; capped at info on an ambiguous translation |
| ARG-CIRC-003 | warning | circular_reasoning | engine, report; capped at info on an ambiguous translation |
| ARG-CL-001 | warning | causal_leap | engine; capped at info on an ambiguous translation |
| ARG-CONTRA-001 | error | contradiction | engine; capped at info on an ambiguous translation |
| ARG-DA-001 | warning | denying_the_antecedent | engine; capped at info on an ambiguous translation |
| ARG-EQ-001 | warning | equivocation | claim; not capped on an ambiguous translation |
| ARG-EQ-002 | warning | equivocation | engine; not capped on an ambiguous translation |
| ARG-EQ-003 | warning | equivocation | engine; not capped on an ambiguous translation |
| ARG-FACT-001 | info | lack_of_evidence | engine; capped at info on an ambiguous translation |
| ARG-FD-001 | warning | false_dilemma | engine; capped at info on an ambiguous translation |
| ARG-HG-001 | warning | hasty_generalisation | engine; capped at info on an ambiguous translation |
| ARG-INV-001 | warning | leap_in_logic | engine; capped at info on an ambiguous translation |
| ARG-LINK-001 | info | leap_in_logic | engine; capped at info on an ambiguous translation |
| ARG-LINK-002 | info | unchecked_source | engine; capped at info on an ambiguous translation |
| ARG-NS-001 | warning | leap_in_logic | engine; capped at info on an ambiguous translation |
| ARG-NS-002 | warning | leap_in_logic | engine; capped at info on an ambiguous translation |
| ARG-NS-003 | warning | leap_in_logic | claim; capped at info on an ambiguous translation |
| ARG-PART-001 | info | leap_in_logic | engine; capped at info on an ambiguous translation |
| ARG-REFUTE-001 | warning | contradiction | engine; capped at info on an ambiguous translation |
| ARG-VAC-001 | warning | vacuous_argument | engine; capped at info on an ambiguous translation |
| EVD-AUTH-001 | warning | uncheckable_authority | claim; capped at info on an ambiguous translation |
| EVD-CHERRY-001 | warning | cherry_picked_data | claim; capped at info on an ambiguous translation |
| EVD-FIG-001 | warning | invented_figure | claim; capped at info on an ambiguous translation; a warning only in a source-bound task or with a data text |
| EVD-LACK-001 | warning | lack_of_evidence | claim; capped at info on an ambiguous translation; a warning only in a source-bound task |
| EVD-LACK-002 | info | lack_of_evidence | report; capped at info on an ambiguous translation |
| EVD-SRC-001 | warning | unchecked_source | claim; capped at info on an ambiguous translation; a warning only in a source-bound task |
| EVD-SRC-002 | info | unchecked_source | report; capped at info on an ambiguous translation |
| EVD-SRC-003 | warning | source_mismatch | claim; capped at info on an ambiguous translation |
| EVD-SRC-004 | info | unchecked_source | claim; capped at info on an ambiguous translation |
| EVD-SRC-005 | warning | unchecked_source | claim; capped at info on an ambiguous translation |
| EVD-SRC-006 | warning | source_mismatch | report; capped at info on an ambiguous translation |
| ST-GIVEN-002 | warning | stem_contradictory_givens | stem; not capped on an ambiguous translation |
| ST-GIVEN-003 | warning | stem_contradictory_givens | stem; not capped on an ambiguous translation |
| ST-GIVEN-004 | warning | stem_contradictory_givens | stem; not capped on an ambiguous translation |
| ST-RANGE-001 | warning | stem_extrapolation | stem; not capped on an ambiguous translation |
| ST-REF-001 | warning | stem_wrong_formula | stem; not capped on an ambiguous translation |
| ST-REF-002 | warning | stem_wrong_formula | stem; not capped on an ambiguous translation |
| ST-ROUND-001 | warning | stem_rounding_changes_conclusion | stem; not capped on an ambiguous translation |
| ST-SCOPE-002 | warning | stem_symbol_conflict | stem; not capped on an ambiguous translation |
| ST-STEP-001 | warning | stem_invalid_step | stem; not capped on an ambiguous translation |
| ST-STEP-002 | info | stem_invalid_step | stem; not capped on an ambiguous translation |
| ST-STEP-003 | warning | stem_invalid_step | stem; not capped on an ambiguous translation |
| ST-UNIT-003 | warning | stem_unit_error | stem; not capped on an ambiguous translation |
| ST-WORK-001 | warning | stem_missing_working | stem; not capped on an ambiguous translation |

**Named only.** These codes are named by the translator's tables, but no check of this build raises them; you will not meet them on a receipt of this build:

| Code | Why |
| --- | --- |
| CORE-SRC-007 | labelled by named.DEFECT_OF_CODE |
| INT-HIST-001 | read by the response gate |
| INT-REQ-017 | a receipt-only named code |

## 9. Common mistakes

| Mistake | Do instead | Rule |
| --- | --- | --- |
| `"kind": "OVS-FID-002"` | Write the kind `quotation_absent` | §2 |
| `finding_missing` for an absent quotation | Use the specific kind `quotation_absent` | K3 |
| `payload_altered` for a router forward that differs | Use `forward_altered` | K2 |
| `receipt_altered` for ACCEPTED with an error finding | Use `receipt_status_wrong` | K3 |
| `contradiction_unnamed` for two different interpretations | Leave it: it is not a contradiction | §3 |
| `other` for a translation whose comparison is flipped | Use `translation_unfaithful` | K6 |
| `translation_unfaithful` for a load-bearing writer's-own premise that says the conclusion in another form (two `not`, a reversed comparison) | It restates the conclusion: `translation_circular` | K6 |
| No accusation for a load-bearing writer's-own premise that is the conclusion with its terms moved across or both sides scaled (`x - 2.00 eq 0`, `2 * x eq 4.00` beside `x eq 2.00`) | It restates the conclusion: `translation_circular` | K6 |
| `figure_changed` for a group member whose figure differs from the representative's | Use `other`, with a pointer to each claim | K7 |
| One accusation naming every answer that repeats a fault | One accusation per transfer, each with its own identifiers | K7 |
| `translation_unfaithful` for a conjunct left without a premise | Leave it: the translator exposes a missing link | K6 |
| `translation_unfaithful` for a claim the policy rules out that carries a problem | Use `translation_invalid` | K6 |
| `translation_circular` for a premise restating a result the other premises already give | Leave it: a redundant restatement (OVS-TRN-010) | K6 |
| `translation_circular` for a restating premise a check verified (its `verified` is true and it carries an excerpt), or for `task_setting` premises stating only values of quantities that each say what the request says about the same quantity | Leave it: a transcription check (OVS-TRN-011 when no excerpt was verified) | K6 |
| No accusation for a load-bearing restating premise grounded `task_setting`, `supplied_text`, `rubric_rule`, `knowledge_document` or `library_source` that no check verified, that states a `Bool` symbol, or whose number the request states only as a "show that" target, a limit, another quantity's number or a bare number, or only in a yes/no question, under a negation, as one of alternatives, inside a claim the answer must examine or as a requirement on the answer | A label is not evidence, and a number match is not either: `translation_circular` | K6 |
| `translation_circular` for a line of working whose computed value is the conclusion's | A derivation the engine checks, not a restatement | K6 |
| `formal_status_wrong` for a STEM check marked satisfied with the status its `detail` expects | Leave it: the check holds | K4 |
| `synthesis_carries_fault` for a figure a synthesized claim changed | Use `figure_changed`: the synthesis made a fault of its own | K9 |

Pack version 2.2 · overseer-knowledge-docs · carries brief 1.0 §4 (the closed list of kinds) and design §9.3 (the checks per kind)
